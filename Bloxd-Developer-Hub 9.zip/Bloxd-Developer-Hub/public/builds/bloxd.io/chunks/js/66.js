export const id = 66;
export const ids = [66, 80];
export const modules = {
    3967: (OO, KO, pO) => {
      pO.d(KO, {
        e: () => LO,
        f: () => QO
      });
      var XO = pO(918),
        bK = pO.n(XO),
        eO = pO(63),
        lO = pO(1051),
        vK = pO(3969),
        CO = pO(1533),
        hO = pO(1991),
        DO = pO(3972),
        MO = pO(976);
      const aK = new WeakMap;
      let oO = 0;

      function FO(OO) {
        let KO = aK.get(OO);
        return void 0 === KO && (KO = oO++, aK.set(OO, KO)), KO
      }

      function VO(OO) {
        let {
          piece: KO
        } = OO;
        return "space" === KO.kind ? (0, MO.jsx)(MO.Fragment, {
          children: KO.text
        }) : (0, MO.jsx)("span", {
          className: "DialogueWord",
          style: {
            "--word-delay": `${KO.delayMs}ms`
          },
          children: (0, MO.jsx)(vK.b, {
            text: "icon" === KO.kind ? `[[${KO.icon}]]` : KO.text
          })
        })
      }

      function LO(OO) {
        let {
          display: KO
        } = OO;
        const {
          selectedLanguage: pO
        } = (0, lO.D)(), XO = (0, eO.useMemo)((() => (0, DO.e)((0, DO.g)(KO).plan.pieces)), [KO, pO.code]);
        return (0, MO.jsxs)("div", {
          className: bK()("Dialogue", {
            DialogueAnimateIn: !1 !== KO.animateIn
          }),
          children: [KO.speakerName && (0, MO.jsx)(CO.d, {
            text: KO.speakerName,
            className: "DialogueSpeaker"
          }), (0, MO.jsx)("p", {
            className: "DialogueLine",
            children: XO.map(((OO, KO) => 1 === OO.length && "space" === OO[0].kind ? OO[0].text : (0, MO.jsx)("span", {
              className: "DialogueGlue",
              children: OO.map(((OO, KO) => (0, MO.jsx)(VO, {
                piece: OO
              }, KO)))
            }, KO)))
          })]
        })
      }
      const QO = (0, eO.memo)((function() {
        const OO = (0, hO.i)("dialogue");
        return (0, MO.jsx)("div", {
          className: "DialogueAnchor",
          "data-camera-keeper": "",
          role: "status",
          "aria-live": "polite",
          "aria-atomic": "true",
          children: OO && (0, MO.jsx)(LO, {
            display: OO
          }, FO(OO))
        })
      }))
    },
    3859: (OO, KO, pO) => {
        pO.r(KO), pO.d(KO, {
          default: () => kl
        });
        var XO = pO(63),
          bK = pO(918),
          eO = pO.n(bK),
          lO = pO(1349),
          vK = pO(1355),
          CO = pO(22),
          hO = pO(77),
          DO = pO(3868),
          MO = pO(3874),
          aK = pO(3880),
          oO = pO(3612),
          FO = pO(976);
        const VO = "/textures/docs/icons";

        function LO(OO) {
          let {
            name: KO,
            isTinted: pO,
            className: XO,
            style: bK
          } = OO;
          const lO = `${VO}/${KO}.png`;
          return pO ? (0, FO.jsxs)("span", {
            className: eO()("DocsPixelIcon", "Tinted", XO),
            "aria-hidden": "true",
            style: bK,
            children: [(0, FO.jsx)("span", {
              className: "DocsPixelIconTint",
              style: {
                maskImage: `url("${lO}")`,
                WebkitMaskImage: `url("${lO}")`
              }
            }), (0, FO.jsx)("img", {
              src: lO,
              alt: ""
            })]
          }) : (0, FO.jsx)("img", {
            className: eO()("DocsPixelIcon", XO),
            src: lO,
            alt: "",
            "aria-hidden": "true",
            style: bK
          })
        }
        const QO = 1500;

        function zK() {
          const [OO, KO] = (0, XO.useState)(null);
          (0, XO.useEffect)((() => {
            if (null === OO) return;
            const pO = setTimeout((() => {
              KO(null)
            }), QO);
            return () => {
              clearTimeout(pO)
            }
          }), [OO]);
          return [OO, OO => {
            (0, oO.d)(OO).then((() => {
              KO({
                text: OO,
                failed: !1
              })
            }), (pO => {
              console.error("Could not copy to the clipboard", pO), KO({
                text: OO,
                failed: !0
              })
            }))
          }]
        }

        function AO(OO) {
          let {
            text: KO,
            label: pO,
            className: XO
          } = OO;
          const [bK, lO] = zK(), vK = !1 === (null === bK || void 0 === bK ? void 0 : bK.failed);
          return (0, FO.jsxs)("button", {
            type: "button",
            className: eO()("DocsCopyButton", XO, {
              Copied: vK
            }),
            title: `Copy ${KO.length>40?"to clipboard":KO}`,
            "aria-label": pO ? void 0 : `Copy ${KO}`,
            onClick: OO => {
              OO.stopPropagation(), lO(KO)
            },
            children: [(0, FO.jsx)(LO, {
              name: vK ? "check" : "copy"
            }), pO && (0, FO.jsx)("span", {
              children: vK ? "Copied" : null !== bK && void 0 !== bK && bK.failed ? "Copy failed" : pO
            })]
          })
        }
        DO.b.registerLanguage("javascript", MO.c), DO.b.registerLanguage("typescript", aK.d);
        const fO = {
            js: "javascript",
            ts: "typescript",
            javascript: "javascript",
            typescript: "typescript"
          },
          dO = {
            javascript: "JavaScript",
            typescript: "TypeScript"
          },
          TO = 24;

        function NO(OO) {
          let {
            code: KO,
            lang: pO,
            compact: bK = !1
          } = OO;
          const lO = (0, XO.useMemo)((() => function(OO, KO) {
              const pO = fO[KO];
              return pO ? DO.b.highlight(OO, {
                language: pO
              }).value : OO.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            }(KO, pO)), [KO, pO]),
            vK = KO.split("\n").length,
            CO = !bK && vK > TO + 6,
            [hO, MO] = (0, XO.useState)(!1),
            aK = fO[pO];
          return (0, FO.jsxs)("div", {
            className: eO()("DocsCodeBlock", {
              Compact: bK,
              Collapsed: CO && !hO
            }),
            children: [!bK && (0, FO.jsxs)("div", {
              className: "DocsCodeBlockHeader",
              children: [(0, FO.jsx)("span", {
                className: "DocsCodeBlockLanguage",
                children: aK ? dO[aK] : "Text"
              }), (0, FO.jsx)(AO, {
                text: KO,
                label: "Copy"
              })]
            }), (0, FO.jsx)("pre", {
              children: (0, FO.jsx)("code", {
                className: "hljs",
                dangerouslySetInnerHTML: {
                  __html: lO
                }
              })
            }), CO && (0, FO.jsxs)("button", {
              type: "button",
              className: "DocsCodeBlockExpand",
              "aria-expanded": hO,
              onClick: () => {
                MO(!hO)
              },
              children: [(0, FO.jsx)(LO, {
                name: hO ? "chevron-up" : "chevron-down"
              }), hO ? "Show less" : `Show all ${vK} lines`]
            })]
          })
        }
        var IO = pO(3887);
        var yK = pO(3893);
        const gK = /^(?:export\s+)?(?:declare\s+)?(?:type|interface|enum|const enum)\s+([A-Za-z_$][\w$]*)/;

        function uO(OO) {
          const KO = new Map;
          let pO, XO = [],
            bK = !1;
          const eO = () => {
            pO && KO.set(pO.name, pO.lines.join("\n").trimEnd())
          };
          for (const lO of OO.split("\n")) {
            const OO = lO.match(gK);
            bK || lO.startsWith("/*") ? (bK || (eO(), pO = void 0), XO.push(lO), bK = !lO.includes("*/")) : OO ? (eO(), pO = {
              name: OO[1],
              lines: [...XO, lO]
            }, XO = []) : pO && (lO.startsWith(" ") || lO.startsWith("\t") || /^[}\])|]/.test(lO)) ? pO.lines.push(lO) : pO && "" !== lO.trim() && (eO(), pO = void 0)
          }
          return eO(), KO
        }

        function EO(OO) {
          return "methods" === OO || "callbacks" === OO || "settings" === OO
        }
        const jK = {
            readme: {
              icon: "code-block",
              summary: "Code blocks, boards and World Code, and the globals your code can use.",
              layout: "article"
            },
            snippets: {
              icon: "scroll",
              summary: "Ready-made code for common jobs, from moving players to running code every second.",
              layout: "snippets"
            },
            howTo: {
              icon: "book",
              summary: "Step-by-step guides for variations, plugins and full games.",
              layout: "article",
              navTitle: "All how-tos"
            },
            changelog: {
              icon: "calendar",
              summary: "What changed in the Code API, newest first.",
              layout: "changelog"
            },
            apiReference: {
              icon: "prompt",
              summary: "Every method on the api object, with parameters and return types.",
              layout: "methods"
            },
            callbacks: {
              icon: "bolt",
              summary: "Functions your world code defines to react to game events.",
              layout: "callbacks"
            },
            clientOptions: {
              icon: "player",
              summary: "Per-player options such as speed, health and camera.",
              layout: "settings",
              setterSnippet: (OO, KO) => `api.setClientOption(playerId, "${OO}", ${KO})`
            },
            entitySettings: {
              icon: "eye",
              summary: "How one player sees and interacts with another entity.",
              layout: "settings",
              setterSnippet: (OO, KO) => `api.setOtherEntitySetting(playerId, targetedEntityId, "${OO}", ${KO})`
            },
            mobSettings: {
              icon: "mob",
              summary: "Health, movement, combat and AI settings for mobs.",
              layout: "settings",
              setterSnippet: (OO, KO) => `api.setMobSetting(mobId, "${OO}", ${KO})`
            },
            vehicleSettings: {
              icon: "car",
              summary: "Movement, physics and camera settings for vehicles.",
              layout: "settings",
              setterSnippet: (OO, KO) => `api.setVehicleSetting(vehicleId, "${OO}", ${KO})`
            },
            meshEntities: {
              icon: "mesh",
              summary: "Spawn mesh entities and throwables, and attach meshes to nodes.",
              layout: "article"
            },
            qte: {
              icon: "stopwatch",
              summary: "Quick time events: progress bars, timed clicks and rhythm games.",
              layout: "article"
            },
            dialogueVoices: {
              icon: "speech-bubble",
              summary: "The voices dialogue is read out in, with a playground for making voices of your own.",
              layout: "article",
              hasVoicePlayground: !0
            },
            particles: {
              icon: "sparkle",
              summary: "Particle textures and presets, with a live effect playground.",
              layout: "article",
              gallery: "particles",
              hasParticlePlayground: !0
            },
            sounds: {
              icon: "music",
              summary: "Every sound effect and song you can play.",
              layout: "article",
              gallery: "sounds"
            },
            icons: {
              icon: "heart",
              summary: "Icons for styled text, from Bloxd icons to Font Awesome.",
              layout: "article",
              gallery: "icons",
              hasTextPlayground: !0
            },
            skins: {
              icon: "shirt",
              summary: "Skin parts, NPC skins and poses for players.",
              layout: "article",
              gallery: "skins"
            },
            blockNames: {
              icon: "grass-block",
              summary: "Every block name, with its texture and variants.",
              layout: "article",
              gallery: "blocks"
            },
            itemNames: {
              icon: "pickaxe",
              summary: "Every item name, with its texture.",
              layout: "article",
              gallery: "items"
            }
          },
          YO = {
            Variations: {
              icon: "layers",
              summary: "Alternate versions of a custom game, and matchmaking players between them."
            },
            Plugins: {
              icon: "puzzle",
              summary: "Reusable first-party World Code features, imported from @plugins."
            },
            "Building a SessionBasedGame": {
              icon: "trophy",
              summary: "A full team game: lobby, teams, map voting, rounds and a winner."
            },
            "Interactable NPCs": {
              icon: "speech-bubble",
              summary: "Entities players talk to or use, such as shopkeepers and guards."
            },
            Dialogue: {
              icon: "volume",
              summary: "Lines of dialogue below the crosshair, read out a syllable at a time in a voice."
            },
            "Project schematics": {
              icon: "blueprint",
              summary: "Build whole chunks from schematics stored with your project."
            }
          };

        function wO(OO) {
          return OO.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")
        }

        function iK(OO) {
          let KO = !1;
          return OO.split("\n").map((OO => (OO.startsWith("```") && (KO = !KO), !KO && /^#{3,} /.test(OO) ? OO.slice(1) : OO))).join("\n")
        }

        function rK(OO) {
          return "readme" === OO ? "getting-started" : wO(OO)
        }
        const PO = "## Glossary of Referenced Types";
        const mK = [{
            id: "welcome",
            slug: "",
            title: "Welcome",
            icon: "house",
            summary: "Run JavaScript in Bloxd, from a single block to a whole custom game.",
            layout: "article",
            markdown: "# Welcome to the Bloxd Code API\n\nWrite JavaScript that runs inside Bloxd: make a block launch players into the sky, give your world its own shop, or build a whole custom game with rounds, teams and a winner.\n\n## New to coding in Bloxd?\n\nStart with [Getting started](#readme), which explains code blocks, boards and World Code, and where each one runs. Then copy something from [Snippets](#snippets) into a code block and change it to see what happens.\n\n## Building a game\n\n[Callbacks](#callbacks) let your World Code react to players joining, chatting, breaking blocks and more. The [How-Tos](#howTo) walk through bigger features step by step, from plugins to a complete team game.\n\n## Looking something up\n\nThe [API Reference](#apiReference) lists every method on `api`. Settings for players, entities, mobs and vehicles each have their own page, and the Assets pages list every block, item, sound, particle, icon and skin name you can use. Press Ctrl K, or \u2318 K on a Mac, to search all of it.\n\n## What's new\n\nThe [Changelog](#changelog) lists what has changed in the Code API, newest first.\n\n## Get help\n\nAsk questions, report problems and suggest features on [our Discord](https://discord.gg/playbloxd)."
          }, ...yK.c.flatMap((OO => {
            const KO = {
              id: OO.id,
              slug: rK(OO.id),
              title: OO.title,
              markdown: OO.content,
              ...jK[OO.id]
            };
            if ("readme" === OO.id) return function(OO) {
              const KO = OO.markdown.indexOf(PO),
                pO = OO.markdown.indexOf("\n```", KO),
                XO = OO.markdown.indexOf("\n```", pO + 1);
              if (-1 === KO || -1 === pO || -1 === XO) throw new Error(`Getting started has no "${PO}" section with a code block`);
              const bK = OO.markdown.slice(KO + 31, pO).trim(),
                eO = [...uO(OO.markdown.slice(OO.markdown.indexOf("\n", pO + 1) + 1, XO))].map((OO => {
                  let [KO, pO] = OO;
                  return `## ${KO}\n\n\`\`\`ts\n${pO}\n\`\`\`\n`
                })),
                lO = OO.markdown.slice(OO.markdown.indexOf("\n", XO + 1) + 1);
              return [{
                ...OO,
                markdown: `${OO.markdown.slice(0,KO)}${lO}`
              }, {
                id: "types",
                slug: "types",
                title: "Types",
                icon: "tag",
                summary: "The types the API Reference's parameters and return values refer to.",
                layout: "article",
                markdown: `# Types\n\n${bK}\n\n${eO.join("\n")}`
              }]
            }(KO);
            if ("howTo" === OO.id) {
              const {
                parent: OO,
                guides: pO
              } = function(OO) {
                const [KO, ...pO] = OO.markdown.split(/^(?=## )/m), XO = [KO], bK = [];
                for (const lO of pO) {
                  var eO;
                  const KO = lO.indexOf("\n"),
                    pO = lO.slice(3, KO).trim(),
                    vK = lO.slice(KO + 1);
                  if (!vK.includes("```")) {
                    XO.push(lO);
                    continue
                  }
                  const CO = null !== (eO = YO[pO]) && void 0 !== eO ? eO : {
                    icon: "lightbulb",
                    summary: `How to use ${pO.toLowerCase()} in World Code.`
                  };
                  bK.push({
                    id: `${OO.id}${pO.split(/[^A-Za-z0-9]+/).map((OO=>OO.charAt(0).toUpperCase()+OO.slice(1))).join("")}`,
                    slug: `${OO.slug}-${wO(pO)}`,
                    title: pO,
                    layout: "article",
                    sourceAnchor: (0, IO.u)(pO),
                    markdown: `# ${pO}\n\n${iK(vK)}`,
                    ...CO
                  })
                }
                return {
                  parent: {
                    ...OO,
                    markdown: XO.join(""),
                    childPageIds: bK.map((OO => OO.id))
                  },
                  guides: bK
                }
              }(KO);
              return [OO, ...pO]
            }
            return [KO]
          }))],
          sO = [{
            title: "Get started",
            pageIds: ["welcome", "readme", "snippets", "changelog"]
          }, {
            title: "How-Tos",
            pageIds: ["howTo", ...mK.filter((OO => void 0 !== OO.sourceAnchor)).map((OO => OO.id))]
          }, {
            title: "Reference",
            pageIds: ["apiReference", "callbacks", "clientOptions", "types"]
          }, {
            title: "Settings",
            pageIds: ["entitySettings", "mobSettings", "vehicleSettings"]
          }, {
            title: "Systems",
            pageIds: ["meshEntities", "qte", "dialogueVoices"]
          }, {
            title: "Assets",
            pageIds: ["particles", "sounds", "icons", "skins", "blockNames", "itemNames"]
          }];

        function HO(OO) {
          return mK.find((KO => KO.id === OO))
        }
        const RO = new Map;

        function SO(OO) {
          let KO = RO.get(OO.id);
          return KO || (KO = (0, IO.y)(OO.markdown, "changelog" === OO.layout ? 3 : 2), RO.set(OO.id, KO)), KO
        }

        function JO(OO, KO) {
          return SO(OO).sections.some((OO => OO.heading.anchor === KO || OO.blocks.some((OO => "heading" === OO.kind && OO.anchor === KO))))
        }

        function cK(OO) {
          const [KO, ...pO] = OO.replace(/^#/, "").split("-"), XO = mK.find((OO => OO.id === KO));
          if (!XO) return null;
          const bK = pO.length > 0 ? (0, IO.u)(pO.join("-")) : "";
          for (const lO of null !== (eO = XO.childPageIds) && void 0 !== eO ? eO : []) {
            var eO;
            const OO = HO(lO);
            if (OO.sourceAnchor === bK) return {
              page: OO,
              anchor: ""
            };
            if (JO(OO, bK)) return {
              page: OO,
              anchor: bK
            }
          }
          return {
            page: XO,
            anchor: bK
          }
        }
        const BO = {
          Examples: {
            pageId: "snippets",
            anchor: ""
          },
          Notes: {
            pageId: "readme",
            anchor: "Globals"
          },
          "Glossary-of-Referenced-Types": {
            pageId: "types",
            anchor: ""
          }
        };

        function ZO(OO, KO) {
          let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
          const XO = KO.slug ? `${OO}/${KO.slug}` : OO;
          return pO ? `${XO}#${pO}` : XO
        }
        var GO = pO(3906);
        const qK = /^export\s+(?:declare\s+)?(?:type|interface|enum|const enum|class)\s+([A-Za-z_$][\w$]*)/,
          xK = new Set(["GameApi", "Console", "_TypeOf"]),
          nO = 4;

        function WO(OO) {
          let KO = OO.length;
          for (; KO > 0 && "" === OO[KO - 1].trim();) KO--;
          return OO.slice(0, KO)
        }

        function tK(OO) {
          var KO;
          const pO = WO(OO);
          if (null === (KO = pO.at(-1)) || void 0 === KO || !KO.trimEnd().endsWith("*/")) return {
            lines: pO,
            doc: ""
          };
          const XO = pO.findLastIndex((OO => OO.startsWith("/**")));
          return -1 === XO ? {
            lines: pO,
            doc: ""
          } : {
            lines: WO(pO.slice(0, XO)),
            doc: pO.slice(XO).join("\n")
          }
        }

        function kK(OO) {
          var KO;
          const pO = OO.split("\n"),
            XO = pO.flatMap(((OO, KO) => qK.test(OO) ? [KO] : []));
          let bK = tK(pO.slice(0, null !== (KO = XO[0]) && void 0 !== KO ? KO : pO.length)).doc;
          return XO.map(((OO, KO) => {
            var eO;
            const lO = tK(pO.slice(OO, null !== (eO = XO[KO + 1]) && void 0 !== eO ? eO : pO.length)),
              vK = {
                name: pO[OO].match(qK)[1],
                doc: bK,
                lines: lO.lines
              };
            return bK = lO.doc, vK
          }))
        }

        function UO(OO) {
          var KO;
          const pO = OO.match(/^readonly \[([\s\S]*)\]$/);
          return pO ? null !== (KO = pO[1].match(/"(?:[^"\\]|\\.)*"/g)) && void 0 !== KO ? KO : [] : null
        }

        function OK(OO) {
          if (!OO.startsWith("{") || !OO.endsWith("}")) return null;
          const KO = {
              keys: [],
              values: []
            },
            pO = OO => {
              const pO = OO.trim().match(/^(?:readonly\s+)?("[^"]*"|[\w$]+)\??:\s*([\s\S]*)$/);
              pO && (KO.keys.push(pO[1].startsWith('"') ? pO[1] : `"${pO[1]}"`), KO.values.push(pO[2].trim()))
            };
          let XO = 0,
            bK = "";
          for (const eO of OO.slice(1, -1)) "{[(".includes(eO) ? XO++ : "}])".includes(eO) && XO--, ";" === eO && 0 === XO ? (pO(bK), bK = "") : bK += eO;
          return pO(bK), KO
        }

        function KK(OO) {
          return OO.length > nO ? `\n\t| ${OO.join("\n\t| ")}` : OO.join(" | ")
        }

        function pK(OO, KO) {
          const pO = function(OO, KO) {
            return OO.replace(/\(_TypeOf\["([\w$]+)"\]\)\[keyof _TypeOf\["\1"\]\]/g, ((OO, pO) => {
              var XO;
              const bK = null === (XO = KO.get(pO)) || void 0 === XO ? void 0 : XO.object;
              return bK ? KK(bK.values) : OO
            })).replace(/\(_TypeOf\["([\w$]+)"\]\)\[[A-Za-z_$][\w$]*\]\[number\]/g, ((OO, pO) => {
              var XO, bK;
              const eO = null === (XO = KO.get(pO)) || void 0 === XO || null === (bK = XO.object) || void 0 === bK ? void 0 : bK.values.map(UO);
              return null !== eO && void 0 !== eO && eO.every((OO => null !== OO)) ? KK([...new Set(eO.flat())]) : OO
            })).replace(/\(_TypeOf\["([\w$]+)"\]\)\[number\]/g, ((OO, pO) => {
              var XO;
              const bK = null === (XO = KO.get(pO)) || void 0 === XO ? void 0 : XO.members;
              return bK ? KK(bK) : OO
            })).replace(/keyof _TypeOf\["([\w$]+)"\]/g, ((OO, pO) => {
              var XO;
              const bK = null === (XO = KO.get(pO)) || void 0 === XO ? void 0 : XO.object;
              return bK ? KK(bK.keys) : OO
            })).replace(/_TypeOf\["([\w$]+)"\]/g, ((OO, pO) => {
              var XO, bK;
              return null !== (XO = null === (bK = KO.get(pO)) || void 0 === bK ? void 0 : bK.text) && void 0 !== XO ? XO : OO
            }))
          }(OO.lines.join("\n").replace(/^export\s+(?:declare\s+)?/, ""), KO);
          return [OO.doc, pO].filter(Boolean).join("\n").replace(/\\(`|\$\{)/g, "$1").replace(/ +\n/g, "\n")
        }

        function XK(OO) {
          const KO = kK(OO),
            pO = function(OO) {
              const KO = new Map,
                pO = OO.find((OO => "_TypeOf" === OO.name));
              let XO = null;
              const bK = () => {
                if (XO) {
                  const OO = XO.lines.join("\n");
                  KO.set(XO.name, {
                    text: OO,
                    members: UO(OO),
                    object: OK(OO)
                  })
                }
              };
              for (const eO of pO.lines.slice(1, -1)) {
                const OO = eO.match(/^\t([\w$]+): (.+)$/);
                OO ? (bK(), XO = {
                  name: OO[1],
                  lines: [OO[2]]
                }) : XO && XO.lines.push(eO.replace(/^\t/, ""))
              }
              return bK(), KO
            }(KO),
            XO = new Map;
          for (const bK of KO) xK.has(bK.name) || XO.has(bK.name) || XO.set(bK.name, pK(bK, pO));
          return XO
        }
        let bp, eK, lK;

        function vp() {
          return eK ??= function(OO) {
            const KO = kK(OO).find((OO => "GameApi" === OO.name)),
              pO = new Map,
              XO = KO.lines;
            for (let eO = 0; eO < XO.length; eO++) {
              var bK;
              if (!XO[eO].trimStart().startsWith("/**")) continue;
              const OO = eO;
              for (; eO < XO.length && !XO[eO].includes("*/");) eO++;
              const KO = null === (bK = XO[eO + 1]) || void 0 === bK ? void 0 : bK.match(/^\s*([A-Za-z_$][\w$]*)\s*[<(]/);
              if (!KO) continue;
              let lO = null;
              const vK = [];
              let CO = "description",
                hO = !1;
              for (const pO of XO.slice(OO, eO + 1).join("\n").split("\n").map((OO => OO.replace(/^\s*\/\*\*\s?/, "").replace(/\s*\*\/\s*$/, "").replace(/^\s*\*\s?/, "").replace(/\\(`|\$\{)/g, "$1")))) {
                const OO = pO.match(/^@deprecated\s*(?:-\s*)?(.*)$/);
                OO ? (lO = OO[1].trim(), CO = "deprecation") : pO.startsWith("@") ? (CO = "otherTag", hO = !0) : "" === pO.trim() ? hO || (CO = "description", vK.push(pO)) : "deprecation" !== CO || /^[A-Z]/.test(pO.trim()) ? "otherTag" !== CO && (CO = "description", vK.push(pO)) : lO = `${lO} ${pO.trim()}`.trim()
              }
              pO.set(KO[1], {
                deprecation: lO,
                description: vK.join("\n").trim()
              })
            }
            return pO
          }(GO.default), eK
        }

        function CK() {
          if (!lK) {
            lK = new Map;
            for (const OO of mK) {
              const KO = (0, IO.x)(SO(OO)).flatMap((OO => OO.blocks));
              for (const OO of (0, IO.k)(KO))
                if ("ts" === OO.lang || "typescript" === OO.lang)
                  for (const [KO, pO] of uO(OO.code)) lK.set(KO, pO)
            }
            for (const [OO, KO] of(bp ??= XK(GO.default), bp)) lK.has(OO) || lK.set(OO, KO)
          }
          return lK
        }
        const hK = {
          BlockName: "blockNames",
          BlockNameOrId: "blockNames",
          ItemName: "itemNames",
          Song: "sounds",
          ParticlePresetId: "particles",
          PlayerPose: "skins",
          IngameIconName: "icons",
          ClientOptions: "clientOptions",
          ClientOption: "clientOptions",
          OtherEntitySettings: "entitySettings",
          OtherEntitySetting: "entitySettings",
          MobSettings: "mobSettings",
          MobSetting: "mobSettings",
          VehicleSetting: "vehicleSettings",
          SettableVehicleSetting: "vehicleSettings"
        };
        let DK;

        function MK() {
          if (!DK) {
            DK = new Map;
            for (const OO of mK)
              if (EO(OO.layout))
                for (const KO of SO(OO).sections) DK.has(KO.heading.text) || DK.set(KO.heading.text, {
                  pageId: OO.id,
                  anchor: KO.heading.anchor
                })
          }
          return DK
        }

        function ap(OO) {
          const KO = OO.trim().match(/^(?:api\.)?([A-Za-z_$][\w$]*)(?:\(.*\))?$/);
          return KO ? MK().get(KO[1]) : void 0
        }
        const oK = (0, XO.createContext)("/docs"),
          FK = (0, XO.createContext)(null),
          VK = (0, XO.createContext)(!1),
          LK = /#(?=\d*[a-fA-F])[0-9a-fA-F]{6}\b/g;

        function QK(OO) {
          const KO = OO.match(/^["']?(#[0-9a-fA-F]{6})["']?$/);
          return KO ? KO[1] : null
        }

        function zp(OO) {
          let {
            colour: KO
          } = OO;
          return (0, FO.jsx)("span", {
            className: "DocsColourSwatch",
            style: {
              background: KO
            },
            "aria-hidden": "true"
          })
        }

        function AK(OO) {
          const KO = [];
          let pO = 0;
          for (const XO of OO.matchAll(LK)) KO.push(OO.slice(pO, XO.index), (0, FO.jsx)(zp, {
            colour: XO[0]
          }), XO[0]), pO = XO.index + XO[0].length;
          return KO.push(OO.slice(pO)), KO
        }

        function fK(OO) {
          let {
            href: KO,
            children: pO
          } = OO;
          const bK = (0, XO.useContext)(oK);
          if (KO.startsWith("#")) {
            const OO = cK(KO);
            if (OO) return (0, FO.jsx)(lO.c, {
              to: ZO(bK, OO.page, OO.anchor),
              children: (0, FO.jsx)(VK.Provider, {
                value: !0,
                children: pO
              })
            })
          }
          return (0, FO.jsx)("a", {
            href: KO,
            target: "_blank",
            rel: "noopener noreferrer",
            children: (0, FO.jsx)(VK.Provider, {
              value: !0,
              children: pO
            })
          })
        }

        function dK(OO) {
          let {
            code: KO
          } = OO;
          const pO = (0, XO.useContext)(oK);
          if ((0, XO.useContext)(VK)) return (0, FO.jsx)("code", {
            className: "DocsInlineCode",
            children: KO
          });
          if (CK().has(KO)) return (0, FO.jsx)(yp, {
            type: KO
          });
          const bK = ap(KO);
          if (bK) return (0, FO.jsx)(lO.c, {
            className: "DocsInlineCode DocsSymbolLink",
            to: ZO(pO, HO(bK.pageId), bK.anchor),
            children: KO
          });
          const eO = QK(KO);
          return (0, FO.jsxs)("code", {
            className: "DocsInlineCode",
            children: [eO && (0, FO.jsx)(zp, {
              colour: eO
            }), KO]
          })
        }

        function TK(OO) {
          let {
            text: KO
          } = OO;
          const pO = [];
          let bK = 0;
          for (const XO of KO.matchAll(IO.e)) {
            XO.index > bK && pO.push(...AK(KO.slice(bK, XO.index)));
            const [, OO, eO, lO, vK, CO] = XO;
            OO ? pO.push((0, FO.jsx)(dK, {
              code: (0, IO.o)(OO, eO)
            })) : lO ? pO.push((0, FO.jsx)("strong", {
              children: (0, FO.jsx)(TK, {
                text: lO
              })
            })) : pO.push((0, FO.jsx)(fK, {
              href: CO,
              children: (0, FO.jsx)(TK, {
                text: vK
              })
            })), bK = XO.index + XO[0].length
          }
          return bK < KO.length && pO.push(...AK(KO.slice(bK))), (0, FO.jsx)(FO.Fragment, {
            children: pO.map(((OO, KO) => (0, FO.jsx)(XO.Fragment, {
              children: OO
            }, KO)))
          })
        }
        const NK = /("[^"]*"|'[^']*'|`[^`]*`)|([A-Za-z_$][\w$]*)|(\d+(?:\.\d+)?)|(\s+)|([^\w\s"'`$]+)/g,
          IK = new Set(["string", "number", "boolean", "null", "undefined", "void", "any", "unknown", "never", "object", "true", "false", "keyof", "typeof", "in", "extends", "readonly"]);

        function yp(OO) {
          let {
            type: KO
          } = OO;
          const pO = CK(),
            bK = [];
          for (const XO of KO.trim().matchAll(NK)) {
            const [OO, KO, eO, lO, vK] = XO;
            KO ? bK.push((0, FO.jsx)("span", {
              className: "DocsTypeString",
              children: OO
            })) : eO && pO.has(eO) ? bK.push((0, FO.jsx)(YK, {
              name: eO,
              definition: pO.get(eO)
            })) : eO ? bK.push((0, FO.jsx)("span", {
              className: IK.has(eO) ? "DocsTypeKeyword" : "DocsTypeName",
              children: OO
            })) : lO ? bK.push((0, FO.jsx)("span", {
              className: "DocsTypeNumber",
              children: OO
            })) : vK ? bK.push(" ") : bK.push((0, FO.jsx)("span", {
              className: "DocsTypePunctuation",
              children: OO
            }))
          }
          return (0, FO.jsx)("code", {
            className: "DocsInlineCode DocsTypeText",
            children: bK.map(((OO, KO) => (0, FO.jsx)(XO.Fragment, {
              children: OO
            }, KO)))
          })
        }
        const gp = 480,
          uK = 6,
          EK = "a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex='-1'])";
        let jp = 0;

        function YK(OO) {
          let {
            name: KO,
            definition: pO
          } = OO;
          const bK = (0, XO.useContext)(oK),
            eO = hK[KO],
            vK = (0, XO.useRef)(null),
            CO = (0, XO.useRef)(null),
            DO = (0, XO.useRef)(null),
            [MO, aK] = (0, XO.useState)(!1),
            [oO, VO] = (0, XO.useState)(null),
            QO = (0, XO.useRef)(),
            zK = (0, XO.useContext)(FK),
            [AO] = (0, XO.useState)((() => "DocsTypePopover-" + jp++)),
            fO = () => {
              clearTimeout(QO.current), aK(!0)
            },
            dO = () => {
              clearTimeout(QO.current), QO.current = setTimeout((() => {
                aK(!1)
              }), 120)
            };
          return (0, XO.useEffect)((() => {
            if (!MO) return;
            const OO = OO => {
              if ("Escape" === OO.key) {
                var KO, pO;
                if (null !== (KO = CO.current) && void 0 !== KO && KO.contains(document.activeElement)) null === (pO = vK.current) || void 0 === pO || pO.focus();
                aK(!1)
              }
            };
            return document.addEventListener("keydown", OO), () => {
              document.removeEventListener("keydown", OO)
            }
          }), [MO]), (0, XO.useEffect)((() => () => {
            clearTimeout(QO.current)
          }), []), (0, XO.useLayoutEffect)((() => {
            if (!MO || !vK.current || !CO.current) return void VO(null);
            const OO = vK.current.getBoundingClientRect(),
              KO = CO.current.offsetHeight,
              pO = Math.min(gp, window.innerWidth - 32),
              XO = Math.min(Math.max(16, OO.left), window.innerWidth - pO - 16),
              bK = OO.bottom + uK + KO < window.innerHeight;
            VO({
              left: XO,
              top: bK ? OO.bottom + uK : Math.max(16, OO.top - uK - KO)
            })
          }), [MO]), (0, FO.jsxs)(FO.Fragment, {
            children: [(0, FO.jsx)("button", {
              type: "button",
              ref: vK,
              className: "DocsTypeLink",
              "aria-expanded": MO,
              "aria-describedby": MO ? AO : void 0,
              onMouseEnter: fO,
              onMouseLeave: dO,
              onFocus: fO,
              onBlur: dO,
              onKeyDown: OO => {
                "Tab" === OO.key && !OO.shiftKey && DO.current && (OO.preventDefault(), DO.current.focus())
              },
              onClick: fO,
              children: KO
            }), MO && (0, hO.createPortal)((0, FO.jsxs)("span", {
              ref: CO,
              id: AO,
              className: "DocsTypePopover",
              role: "tooltip",
              style: oO ? {
                left: oO.left,
                top: oO.top,
                maxWidth: gp
              } : {
                visibility: "hidden"
              },
              onMouseEnter: fO,
              onMouseLeave: dO,
              onFocus: fO,
              onBlur: dO,
              children: [(0, FO.jsxs)("span", {
                className: "DocsTypePopoverHeader",
                children: [(0, FO.jsx)("span", {
                  className: "DocsTypePopoverTitle",
                  children: KO
                }), eO && (0, FO.jsxs)(lO.c, {
                  ref: DO,
                  className: "DocsTypePopoverLink",
                  to: ZO(bK, HO(eO)),
                  onClick: () => {
                    aK(!1)
                  },
                  onKeyDown: OO => {
                    if ("Tab" === OO.key) {
                      var KO;
                      if (OO.preventDefault(), OO.shiftKey || !vK.current || ! function(OO, KO) {
                          const pO = [...document.querySelectorAll(EK)],
                            XO = pO.slice(pO.indexOf(OO) + 1).find((OO => OO.getClientRects().length > 0 && !(null !== KO && void 0 !== KO && KO.contains(OO))));
                          return null === XO || void 0 === XO || XO.focus(), void 0 !== XO
                        }(vK.current, CO.current)) null === (KO = vK.current) || void 0 === KO || KO.focus();
                      OO.shiftKey || aK(!1)
                    }
                  },
                  children: [HO(eO).title, (0, FO.jsx)(LO, {
                    name: "arrow-right"
                  })]
                })]
              }), (0, FO.jsx)(NO, {
                lang: "ts",
                code: pO,
                compact: !0
              })]
            }), null !== zK && void 0 !== zK ? zK : document.body)]
          })
        }
        var wK = pO(171),
          ip = pO(3908),
          rp = pO(3912),
          PK = pO(3916);
        const mp = {
          progressBar: {
            RP: 30,
            k_: .075,
            p_: 5,
            qm: !1,
            description: [{
              str: "Click repeatedly to complete!"
            }],
            e_: "fa-solid fa-computer-mouse",
            scale: 3,
            rotation: 15
          },
          timedClick: {
            h_: 3e3,
            icon: "fa-solid fa-computer-mouse",
            label: [{
              str: "Click to complete the QTE!"
            }],
            M_: !0,
            scale: 3,
            rotation: 15,
            o_: !1
          },
          gravityBar: {
            RP: 30,
            L_: .25,
            Q_: 3,
            A_: .8,
            gravity: 1,
            f_: 1.5,
            T_: 8,
            N_: 4,
            qm: !1,
            description: [{
              str: "Hold to catch!"
            }],
            icon: "Moonfish"
          },
          precisionBar: {
            speed: .5,
            Y_: .15,
            label: [{
              str: "Click when the marker is within the green zone."
            }],
            icon: "",
            scale: 1,
            rotation: 0
          },
          rhythmClick: {
            R_: 5,
            S_: 1200,
            J_: .15,
            B_: 3,
            label: [{
              str: "Click when the circles align!"
            }],
            icon: ""
          }
        };
        var sK = pO(243),
          HK = pO(1608);

        function RK(OO) {
          return OO.startsWith("fa-")
        }
        const SK = {
            text: "Text",
            icon: "Icon",
            progressBar: "Progress bar",
            keyBinding: "Key binding",
            other: "Other"
          },
          JK = {
            text: "Text",
            icon: {
              icon: "Pixelated Heart"
            },
            progressBar: {
              type: "ProgressBar",
              progress: .5
            },
            keyBinding: {
              type: "StyledKeyBinding",
              action: "jump"
            }
          };

        function cp(OO) {
          return "string" === typeof OO ? "text" : "entityName" in OO || "translationKey" in OO ? "other" : (0, sK.yb)(OO) ? "progressBar" : (0, sK.ub)(OO) ? "keyBinding" : "icon" in OO ? "icon" : "str" in OO && "string" === typeof OO.str ? "text" : "other"
        }
        const BK = [{
            path: ["style", "color"],
            label: "Colour",
            field: {
              kind: "colour"
            },
            defaultText: "The surrounding text's"
          }, {
            path: ["style", "fontSize"],
            label: "Font size",
            field: {
              kind: "size"
            },
            defaultText: "1em"
          }, {
            path: ["style", "fontWeight"],
            label: "Font weight",
            field: {
              kind: "choice",
              options: ["normal", "bold", "100", "200", "300", "400", "500", "600", "700", "800", "900"]
            },
            defaultText: "normal"
          }, {
            path: ["style", "fontStyle"],
            label: "Font style",
            field: {
              kind: "choice",
              options: ["normal", "italic"]
            },
            defaultText: "normal"
          }, {
            path: ["style", "opacity"],
            label: "Opacity",
            field: {
              kind: "fraction"
            },
            defaultText: "1"
          }],
          ZK = {
            text: [{
              path: ["str"],
              label: "Text",
              field: {
                kind: "text",
                multiline: !0
              },
              isRequired: !0
            }, ...BK],
            icon: [{
              path: ["icon"],
              label: "Icon",
              field: {
                kind: "icon"
              },
              isRequired: !0
            }, {
              path: ["style", "color"],
              label: "Colour",
              field: {
                kind: "colour"
              },
              defaultText: "None, or the text's for Font Awesome"
            }, {
              path: ["style", "fontSize"],
              label: "Size",
              field: {
                kind: "size"
              },
              defaultText: "1.8em"
            }, {
              path: ["style", "opacity"],
              label: "Opacity",
              field: {
                kind: "fraction"
              },
              defaultText: "1"
            }],
            progressBar: [{
              path: ["progress"],
              label: "Progress",
              field: {
                kind: "fraction"
              },
              isRequired: !0
            }, {
              path: ["width"],
              label: "Width",
              field: {
                kind: "size"
              },
              defaultText: "4em"
            }, {
              path: ["height"],
              label: "Height",
              field: {
                kind: "size"
              },
              defaultText: "0.7em"
            }, {
              path: ["colours"],
              label: "Fill colours",
              field: {
                kind: "colours"
              },
              defaultText: "#ffffff"
            }, {
              path: ["backgroundColour"],
              label: "Track colour",
              field: {
                kind: "colour"
              },
              defaultText: "rgba(0, 0, 0, 0.45)"
            }],
            keyBinding: [{
              path: ["action"],
              label: "Action",
              field: {
                kind: "choice",
                options: HK.i
              },
              isRequired: !0
            }, ...BK],
            other: []
          };

        function GK(OO) {
          return "string" === typeof OO ? {
            str: OO
          } : OO
        }

        function qp(OO, KO) {
          let pO = GK(OO);
          for (const XO of KO) pO = pO && "object" === typeof pO ? pO[XO] : void 0;
          return pO
        }

        function xp(OO, KO, pO) {
          const XO = (OO, bK) => {
            var eO;
            const lO = KO[bK],
              vK = {
                ...OO
              };
            if (bK === KO.length - 1) return void 0 === pO ? delete vK[lO] : vK[lO] = pO, vK;
            const CO = XO(null !== (eO = OO[lO]) && void 0 !== eO ? eO : {}, bK + 1);
            return 0 === Object.keys(CO).length ? delete vK[lO] : vK[lO] = CO, vK
          };
          return function(OO) {
            const KO = Object.keys(OO);
            return "string" === typeof OO.str && 1 === KO.length ? OO.str : OO
          }(XO(GK(OO), 0))
        }

        function nK(OO, KO) {
          const pO = cp(OO),
            XO = ZK[pO].find((OO => OO.path.join(".") === KO.join("."))),
            bK = null !== XO && void 0 !== XO && XO.isRequired && "other" !== pO ? qp(JK[pO], KO) : void 0;
          return xp(OO, KO, bK)
        }

        function WK(OO) {
          switch (cp(OO)) {
            case "text":
              return String(qp(OO, ["str"]));
            case "icon":
              return String(qp(OO, ["icon"]));
            case "progressBar":
              return `${Math.round(100*Number(qp(OO,["progress"])))}%`;
            case "keyBinding":
              return String(qp(OO, ["action"]));
            case "other":
              return JSON.stringify(OO)
          }
        }
        const tp = /^[A-Za-z_$][\w$]*$/;

        function kp(OO) {
          if (Array.isArray(OO)) return `[${OO.map(kp).join(", ")}]`;
          if (OO && "object" === typeof OO) {
            const KO = Object.entries(OO).map((OO => {
              let [KO, pO] = OO;
              return `${tp.test(KO)?KO:JSON.stringify(KO)}: ${kp(pO)}`
            }));
            return 0 === KO.length ? "{}" : `{ ${KO.join(", ")} }`
          }
          return JSON.stringify(OO)
        }

        function UK(OO) {
          const KO = OO.map(kp),
            pO = `[${KO.join(", ")}]`;
          return pO.length <= 60 ? pO : `[\n${KO.map((OO=>`    ${OO},`)).join("\n")}\n]`
        }
        const Op = {
          "\n": "\\n",
          "\r": "\\r",
          "\t": "\\t"
        };

        function Kp(OO) {
          let KO = "";
          for (let bK = 0; bK < OO.length; bK++) {
            const eO = OO[bK];
            if ("\\" === eO) {
              var pO;
              const XO = null !== (pO = OO[bK + 1]) && void 0 !== pO ? pO : "";
              KO += "'" === XO ? "'" : eO + XO, bK++
            } else if ('"' === eO) KO += '\\"';
            else {
              var XO;
              KO += null !== (XO = Op[eO]) && void 0 !== XO ? XO : eO
            }
          }
          return `"${KO}"`
        }

        function pp(OO) {
          if ("string" === typeof OO) return !0;
          if (!OO || "object" !== typeof OO || Array.isArray(OO)) return !1;
          const KO = OO;
          return "ProgressBar" === KO.type ? "number" === typeof KO.progress : "StyledKeyBinding" === KO.type ? HK.i.includes(KO.action) : "string" === typeof KO.icon || "string" === typeof KO.str || "string" === typeof KO.entityName || "string" === typeof KO.translationKey
        }

        function Xp(OO) {
          let KO;
          try {
            KO = function(OO) {
              let KO = "",
                pO = "",
                XO = 0;
              const bK = () => {
                KO += pO.replace(/([A-Za-z_$][\w$]*)\s*:/g, '"$1":').replace(/,(\s*[\]}])/g, "$1"), pO = ""
              };
              for (; XO < OO.length;) {
                const eO = OO.slice(XO).search(/["'`]|\/\//);
                if (-1 === eO) {
                  pO += OO.slice(XO);
                  break
                }
                pO += OO.slice(XO, XO + eO);
                const lO = XO + eO,
                  vK = OO[lO];
                if ("/" === vK) {
                  const KO = OO.indexOf("\n", lO);
                  XO = -1 === KO ? OO.length : KO;
                  continue
                }
                if (bK(), "`" === vK) throw new Error("Use quotes rather than template strings.");
                let CO = lO + 1;
                for (; CO < OO.length && OO[CO] !== vK;) CO += "\\" === OO[CO] ? 2 : 1;
                if (CO >= OO.length) throw new Error("A string is missing its closing quote.");
                const hO = OO.slice(lO + 1, CO);
                KO += Kp(hO), XO = CO + 1
              }
              return bK(), JSON.parse(KO)
            }(OO.trim())
          } catch (XO) {
            return {
              parts: null,
              error: XO instanceof SyntaxError ? "This isn't a valid array yet." : XO.message
            }
          }
          if (!Array.isArray(KO)) return {
            parts: null,
            error: 'Styled text is an array, e.g. ["Hello ", { str: "world" }]'
          };
          const pO = KO.findIndex((OO => !pp(OO)));
          return -1 !== pO ? {
            parts: null,
            error: `Part ${pO+1} isn't one Bloxd draws: use a string, { str }, { icon }, a ProgressBar or a StyledKeyBinding.`
          } : {
            parts: KO,
            error: null
          }
        }
        const bX = 1 / wK.h.clientTicksPerSecond,
          ep = 700,
          lp = {
            type: null,
            parameters: null,
            state: null,
            isActive: !1
          },
          vX = {
            progressBar: mp.progressBar.e_,
            timedClick: mp.timedClick.icon,
            gravityBar: mp.gravityBar.icon,
            precisionBar: mp.precisionBar.icon,
            rhythmClick: mp.rhythmClick.icon
          };

        function Cp(OO) {
          let {
            type: KO
          } = OO;
          const [pO, bK] = (0, XO.useState)("ready"), [lO, vK] = (0, XO.useState)(1), [CO, hO] = (0, XO.useState)(!0), DO = (0, XO.useRef)(null), MO = (0, XO.useRef)(null), aK = (0, XO.useRef)(null), oO = (0, XO.useRef)(new Set), VO = (0, XO.useRef)(!1), QO = vX[KO], zK = (0, XO.useMemo)((() => ({
            getState: () => {
              var OO, KO;
              return null !== (OO = null === (KO = aK.current) || void 0 === KO ? void 0 : KO.getState()) && void 0 !== OO ? OO : lp
            },
            onFrame: OO => (oO.current.add(OO), () => {
              oO.current.delete(OO)
            })
          })), []);
          (0, XO.useEffect)((() => {
            const OO = DO.current,
              KO = MO.current;
            if (!OO || !KO) return;
            const pO = new ResizeObserver((() => {
              vK(OO.clientWidth / Math.max(1, KO.offsetWidth))
            }));
            return pO.observe(OO), () => {
              pO.disconnect()
            }
          }), []), (0, XO.useEffect)((() => {
            var OO;
            if ("playing" !== pO) return;
            let XO = !1;
            const eO = new PK.g[KO](mp[KO], (OO => {
              XO = !0, hO(!1), bK(OO ? "succeeded" : "failed")
            }), (() => {}));
            aK.current = eO;
            let lO = 0,
              vK = performance.now(),
              CO = requestAnimationFrame((function OO(KO) {
                for (lO += Math.min(.25, (KO - vK) / 1e3), vK = KO; lO >= bX && !XO;) lO -= bX, eO.handleTick(bX);
                for (const pO of oO.current) pO();
                XO || (CO = requestAnimationFrame(OO))
              }));
            return null === (OO = DO.current) || void 0 === OO || OO.focus({
              preventScroll: !0
            }), () => {
              cancelAnimationFrame(CO), eO.tearDown(), aK.current = null, VO.current = !1
            }
          }), [pO, KO]), (0, XO.useEffect)((() => {
            if (CO) return;
            const OO = setTimeout((() => {
              hO(!0)
            }), ep);
            return () => {
              clearTimeout(OO)
            }
          }), [CO]);
          const AO = OO => {
            var KO;
            "playing" === pO && VO.current !== OO && (VO.current = OO, null === (KO = aK.current) || void 0 === KO || KO.handleMouseInput(OO))
          };
          return (0, FO.jsxs)("div", {
            className: "DocsQteDemo",
            children: [(0, FO.jsxs)("div", {
              ref: DO,
              className: eO()("DocsQteStage", {
                Playing: "playing" === pO
              }),
              tabIndex: "playing" === pO ? 0 : -1,
              role: "playing" === pO ? "button" : void 0,
              "aria-label": "playing" === pO ? `${KO} quick time event: click or press Space` : void 0,
              onPointerDown: OO => {
                0 === OO.button && AO(!0)
              },
              onPointerUp: () => {
                AO(!1)
              },
              onPointerLeave: () => {
                AO(!1)
              },
              onPointerCancel: () => {
                AO(!1)
              },
              onKeyDown: OO => {
                "playing" !== pO || " " !== OO.key && "Enter" !== OO.key || (OO.preventDefault(), AO(!0))
              },
              onKeyUp: OO => {
                "playing" !== pO || " " !== OO.key && "Enter" !== OO.key || AO(!1)
              },
              children: [(0, FO.jsx)("div", {
                ref: MO,
                className: "DocsQteScreen",
                style: {
                  transform: `scale(${lO})`
                },
                children: "playing" === pO && (0, FO.jsx)(rp.c.Provider, {
                  value: zK,
                  children: (0, FO.jsx)(ip.b, {
                    qte: {
                      type: KO,
                      parameters: mp[KO]
                    }
                  })
                })
              }), "playing" !== pO && (0, FO.jsxs)("div", {
                className: "DocsQteOverlay",
                children: ["ready" !== pO && (0, FO.jsxs)("div", {
                  className: eO()("DocsQteResult", "succeeded" === pO ? "Succeeded" : "Failed"),
                  children: [(0, FO.jsx)(LO, {
                    name: "succeeded" === pO ? "check" : "cross",
                    isTinted: !0
                  }), (0, FO.jsx)("span", {
                    children: "succeeded" === pO ? "Succeeded: onPlayerFinishQTE gets true" : "Failed: onPlayerFinishQTE gets false"
                  })]
                }), (0, FO.jsxs)("button", {
                  type: "button",
                  className: "DocsQtePlay",
                  disabled: !CO,
                  onClick: () => {
                    bK("playing")
                  },
                  children: [(0, FO.jsx)(LO, {
                    name: "ready" === pO ? "play" : "replay"
                  }), (0, FO.jsx)("span", {
                    children: "ready" === pO ? `Try ${KO}` : "Play again"
                  })]
                })]
              })]
            }), QO && !RK(QO) && (0, FO.jsxs)("p", {
              className: "DocsQteCaption",
              children: ["The ", (0, FO.jsx)("code", {
                children: QO
              }), " icon is a Bloxd item, so it shows in game only."]
            })]
          })
        }

        function hp(OO) {
          let {
            level: KO,
            text: pO,
            anchor: XO,
            className: bK
          } = OO;
          const lO = `h${Math.min(KO,6)}`;
          return (0, FO.jsxs)(lO, {
                id: XO,
                className: eO()("DocsHeading", bK),
                children: [(0, FO.jsx)(TK, {
                      text: pO
                    }), (0, FO.jsx)("a", {
                        className: "DocsHeadingAnchor",
                        href: `#${XO}`,
                        "aria-label": `Link to ${pO.replace(/`/g,"")}`,children:"#"})]})}function Dp(OO){let{items:KO,ordered:pO}=OO;const XO=pO?"ol":"ul";return(0,FO.jsx)(XO,{className:"DocsList",children:KO.map(((OO,KO)=>(0,FO.jsxs)("li",{children:[(0,FO.jsx)(TK,{text:OO.text}),OO.children.length>0&&(0,FO.jsx)(Dp,{items:OO.children,ordered:pO})]},KO)))})}function Mp(OO){const KO=OO[0],pO="paragraph"===(null===KO||void 0===KO?void 0:KO.kind)?KO.text.toLowerCase():"";return/^\*\*(warning|important|caution)/.test(pO)?"warning":/^\*\*(tip|prefer)/.test(pO)?"tip":"note"}function aX(OO){let{block:KO}=OO;switch(KO.kind){case"heading":return(0,FO.jsx)(hp,{level:KO.level,text:KO.text,anchor:KO.anchor});case"paragraph":return(0,FO.jsx)("p",{children:(0,FO.jsx)(TK,{text:KO.text})});case"code":{const OO="ts"===KO.lang?function(OO){const KO=OO.match(/^api\.addQTE\(playerId, \{\s*type: "(\w+)"/);return KO&&Object.hasOwn(mp,KO[1])?KO[1]:null}(KO.code):null;return(0,FO.jsxs)(FO.Fragment,{children:[(0,FO.jsx)(NO,{code:KO.code,lang:KO.lang}),OO&&(0,FO.jsx)(Cp,{type:OO})]})}case"table":return(0,FO.jsx)("div",{className:"DocsTableScroll",children:(0,FO.jsxs)("table",{className:"DocsTable",children:[(0,FO.jsx)("thead",{children:(0,FO.jsx)("tr",{children:KO.header.map(((OO,KO)=>(0,FO.jsx)("th",{children:(0,FO.jsx)(TK,{text:OO})},KO)))})}),(0,FO.jsx)("tbody",{children:KO.rows.map(((OO,KO)=>(0,FO.jsx)("tr",{children:OO.map(((OO,KO)=>(0,FO.jsx)("td",{children:(0,FO.jsx)(TK,{text:OO})},KO)))},KO)))})]})});case"list":return(0,FO.jsx)(Dp,{items:KO.items,ordered:KO.ordered});case"quote":return(0,FO.jsx)("aside",{className:eO()("DocsCallout",Mp(KO.blocks)),children:(0,FO.jsx)(op,{blocks:KO.blocks})});case"rule":return(0,FO.jsx)("hr",{className:"DocsRule"})}}function op(OO){let{blocks:KO}=OO;return(0,FO.jsx)(FO.Fragment,{children:KO.map(((OO,KO)=>(0,FO.jsx)(aX,{block:OO},KO)))})}var Fp=pO(3899),Vp=pO(3902);function Lp(OO){return"blocks"===OO||"items"===OO}const Qp=new Map;function zX(OO){let KO=Qp.get(OO);return KO||(KO=function(OO){const KO={entries:[],legend:[],notes:[],examples:[]};let pO=!1;for(const eO of OO.split(/\r?\n/).slice(1)){if(eO.startsWith("#")){const OO=eO.replace(/^# ?/,""),XO=OO.match(/^\s+([A-Z]+)\s+=\s+(\w+)\s+->\s+(.+)$/);XO?KO.legend.push({code:XO[1],meaning:XO[2],usage:XO[3].trim()}):/^Examples:/.test(OO.trim())?pO=!0:pO&&OO.trim()?KO.examples.push(OO.trim()):OO.trim()&&!/^\s/.test(OO)&&KO.notes.push(OO.trim());continue}const OO=eO.trim().match(/^(.+?)(?:\s+\[([A-Z,]+)\])?$/);var XO,bK;OO&&KO.entries.push({name:OO[1],variants:null!==(XO=null===(bK=OO[2])||void 0===bK?void 0:bK.split(","))&&void 0!==XO?XO:[]})}return KO}("blocks"===OO?Fp:Vp),Qp.set(OO,KO)),KO}function Ap(OO){let{className:KO,value:pO,placeholder:XO,label:bK,onChange:eO,count:lO,children:vK}=OO;return(0,FO.jsxs)("div",{className:KO,children:[(0,FO.jsx)(LO,{name:"magnifying-glass"}),(0,FO.jsx)("input",{type:"search",value:pO,placeholder:XO,"aria-label":bK,onChange:OO=>{eO(OO.target.value)}}),vK,lO&&(0,FO.jsxs)("span",{className:"DocsFilterCount",children:[lO.visible," of ",lO.total]})]})}var fp=pO(933);function dp(OO){const KO=OO.trim().match(/^(` {
                          1,
                          2
                        })\ s * ([ ^ `]+?)\s*\1$/);return KO?KO[2]:null}function Tp(OO){return"paragraph"===OO.kind&&""===OO.text.trim()}function Np(OO){const KO={name:OO.heading.text,description:[],params:[],returns:null};let pO="description";for(const bK of OO.blocks)if(!Tp(bK))if("heading"===bK.kind&&/^Parameters:?$/.test(bK.text))pO="params";else if("heading"===bK.kind&&/^Returns:?$/.test(bK.text))pO="returns",KO.returns={type:"",description:[]};else if("params"!==pO||"table"!==bK.kind){if("returns"===pO&&"paragraph"===bK.kind&&""===KO.returns.type){const OO=dp(bK.text);if(null!==OO){KO.returns.type=OO.replaceAll("\\|","|");continue}}"returns"===pO?KO.returns.description.push(bK):KO.description.push(bK)}else for(const[OO,pO,eO]of bK.rows){var XO;KO.params.push({name:OO,type:null!==(XO=dp(pO))&&void 0!==XO?XO:pO,description:null!==eO&&void 0!==eO?eO:""})}return KO}const Ip=/^\*\*(Type|Default|Example):\*\*\s*(.*)$/;function yX(OO){return OO.filter((OO=>!Tp(OO)))}const gX=/^[\w][\w .'&!:()-]*$/,upO=/^` [ ^ `]+`( ? : [\s, ] * `[^`] + `)*$/;function Ep(OO){var KO;if("code"===OO.kind&&"text"===OO.lang){const KO=OO.code.split("\n").map((OO=>OO.trim())).filter(Boolean);return KO.length>0&&KO.every((OO=>gX.test(OO)))?KO.map((OO=>({name:OO}))):null}return"paragraph"===OO.kind&&upO.test(OO.text.trim())?[...OO.text.matchAll(/`([ ^ `]+)` / g)].flatMap((OO => OO[1].split(/,\s*/).map((OO => ({
                              name: OO.trim()
                            }))))): "table" === OO.kind && null !== (KO = OO.header[0]) && void 0 !== KO && KO.startsWith("Song") ? OO.rows.map((OO => {
                              let [KO, pO] = OO;
                              return {
                                name: KO.replace(/`/g, ""),
                                caption: pO
                              }
                            })) : null
                          }

                          function jX(OO) {
                            const KO = [];
                            for (const pO of OO) {
                              const OO = Ep(pO),
                                XO = KO.at(-1),
                                bK = "table" === pO.kind;
                              OO ? "names" === (null === XO || void 0 === XO ? void 0 : XO.kind) && XO.isSongs === bK ? XO.names.push(...OO) : KO.push({
                                kind: "names",
                                names: OO,
                                isSongs: bK
                              }) : KO.push({
                                kind: "block",
                                block: pO
                              })
                            }
                            return KO
                          }
                          const Yp = {
                            icons: "icon",
                            particles: "particle",
                            sounds: "sound",
                            skins: "skin",
                            blocks: "block",
                            items: "item"
                          };

                          function wp(OO, KO) {
                            return `${Yp[OO]}-${(0,IO.u)(KO)}`
                          }
                          const iX = new WeakMap;

                          function rX(OO, KO, pO) {
                            let XO = iX.get(KO);
                            if (!XO) {
                              XO = new Map;
                              const pO = new Set;
                              for (const bK of (0, IO.x)(KO)) {
                                const KO = jX(yX(bK.blocks)).map((KO => {
                                  if ("block" === KO.kind) return KO;
                                  return {
                                    kind: "names",
                                    names: KO.names.map((KO => {
                                      var XO, eO;
                                      const lO = wp(OO, KO.name);
                                      let vK = lO;
                                      for (let OO = 2; pO.has(vK); OO++) vK = `${lO}-${OO}`;
                                      return pO.add(vK), {
                                        ...KO,
                                        anchor: vK,
                                        heading: null !== (XO = null === (eO = bK.heading) || void 0 === eO ? void 0 : eO.text) && void 0 !== XO ? XO : ""
                                      }
                                    })),
                                    isSongs: KO.isSongs
                                  }
                                }));
                                XO.set(bK.blocks, KO)
                              }
                              iX.set(KO, XO)
                            }
                            const bK = XO.get(pO);
                            if (!bK) throw new Error("Gallery blocks must be the page's intro or one of its sections");
                            return bK
                          }
                          const Pp = "/textures/docs/skinPreviews",
                            mX = [{
                              heading: "NPC Skins",
                              prefix: "npc"
                            }, {
                              heading: "Poses",
                              prefix: "pose"
                            }];
                          var sp = pO(3500),
                            Hp = pO(3520);

                          function Rp(OO) {
                            return Object.hasOwn(sp.f, OO) ? sp.f[OO] : null
                          }
                          const Sp = {
                            dir1: [-1, -1, -1],
                            dir2: [1, 1, 1],
                            texture: "bubble",
                            minLifeTime: .2,
                            maxLifeTime: .6,
                            minEmitPower: 2,
                            maxEmitPower: 2,
                            minSize: .25,
                            maxSize: .35,
                            manualEmitCount: 20,
                            gravity: [0, -10, 0],
                            colorGradients: [{
                              timeFraction: 0,
                              minColor: [60, 60, 150, 1],
                              maxColor: [200, 200, 255, 1]
                            }],
                            velocityGradients: [{
                              timeFraction: 0,
                              factor: 1,
                              factor2: 1
                            }],
                            blendMode: Hp.d.Standard
                          };

                          function Jp(OO, KO, pO) {
                            return KO + (pO - KO) * OO()
                          }

                          function cX(OO, KO, pO) {
                            return OO + (KO - OO) * pO
                          }

                          function Bp(OO) {
                            return OO.length > 0 && "timeFraction" in OO[0]
                          }

                          function Zp(OO, KO) {
                            if (0 === OO.colorGradients.length) return [{
                              at: 0,
                              colour: [1, 1, 1, 1]
                            }];
                            if (!Bp(OO.colorGradients)) {
                              const pO = OO.colorGradients,
                                {
                                  color: XO
                                } = pO[Math.floor(KO() * pO.length) % pO.length];
                              return [{
                                at: 0,
                                colour: [XO[0] / 255, XO[1] / 255, XO[2] / 255, 1]
                              }]
                            }
                            return [...OO.colorGradients].sort(((OO, KO) => OO.timeFraction - KO.timeFraction)).map((OO => {
                              var pO, XO, bK;
                              const eO = OO.minColor,
                                lO = null !== (pO = OO.maxColor) && void 0 !== pO ? pO : eO,
                                vK = KO(),
                                CO = [cX(eO[0], lO[0], vK) / 255, cX(eO[1], lO[1], vK) / 255, cX(eO[2], lO[2], vK) / 255, cX(null !== (XO = eO[3]) && void 0 !== XO ? XO : 1, null !== (bK = lO[3]) && void 0 !== bK ? bK : 1, vK)];
                              return {
                                at: OO.timeFraction,
                                colour: CO
                              }
                            }))
                          }

                          function Gp(OO, KO, pO, XO) {
                            const bK = Jp(XO, OO.minEmitPower, OO.maxEmitPower),
                              eO = KO => Jp(XO, Math.min(OO.dir1[KO], OO.dir2[KO]), Math.max(OO.dir1[KO], OO.dir2[KO])) * bK,
                              lO = [...OO.velocityGradients].sort(((OO, KO) => OO.timeFraction - KO.timeFraction)).map((OO => ({
                                at: OO.timeFraction,
                                factor: Jp(XO, OO.factor, OO.factor2)
                              })));
                            return {
                              pos: [Jp(XO, KO[0], pO[0]), Jp(XO, KO[1], pO[1]), Jp(XO, KO[2], pO[2])],
                              dir: [eO(0), eO(1), eO(2)],
                              age: 0,
                              life: Jp(XO, OO.minLifeTime, OO.maxLifeTime),
                              size: Jp(XO, OO.minSize, OO.maxSize),
                              colours: Zp(OO, XO),
                              velocityFactors: lO
                            }
                          }

                          function qX(OO, KO, pO, XO) {
                            if (KO < OO[0].at) return pO(Math.min(1, OO.length - 1));
                            for (let bK = 0; bK < OO.length - 1; bK++)
                              if (KO <= OO[bK + 1].at) {
                                const eO = OO[bK + 1].at - OO[bK].at;
                                return XO(pO(bK), pO(bK + 1), eO > 0 ? (KO - OO[bK].at) / eO : 1)
                              } return pO(OO.length - 1)
                          }

                          function xX(OO) {
                            return qX(OO.colours, OO.age / OO.life, (KO => OO.colours[KO].colour), ((OO, KO, pO) => [cX(OO[0], KO[0], pO), cX(OO[1], KO[1], pO), cX(OO[2], KO[2], pO), cX(OO[3], KO[3], pO)]))
                          }

                          function np(OO, KO, pO) {
                            if (OO.age += pO, OO.age >= OO.life) return !1;
                            const XO = function(OO) {
                              return 0 === OO.velocityFactors.length ? 1 : qX(OO.velocityFactors, OO.age / OO.life, (KO => OO.velocityFactors[KO].factor), cX)
                            }(OO) * pO;
                            for (let eO = 0; eO < 3; eO++) {
                              var bK;
                              OO.pos[eO] += OO.dir[eO] * XO, OO.dir[eO] += (null !== (bK = KO[eO]) && void 0 !== bK ? bK : 0) * pO
                            }
                            return !0
                          }

                          function Wp(OO) {
                            return String(Math.round(1e6 * OO) / 1e6)
                          }

                          function tX(OO) {
                            return `[${OO.map(Wp).join(", ")}]`
                          }

                          function kX(OO, KO) {
                            const pO = `${KO}    `;
                            return `[\n${(Bp(OO)?OO.map((OO=>{const KO=[`${pO}    timeFraction: ${Wp(OO.timeFraction)},`,`${pO}    minColor: ${tX(OO.minColor)},`];return OO.maxColor&&KO.push(`${pO}    maxColor: ${tX(OO.maxColor)},`),`${pO}{\n${KO.join("\n")}\n${pO}},`})):OO.map((OO=>`
                            $ {
                              pO
                            } {
                              color: $ {
                                tX(OO.color)
                              }
                            }, `))).join("\n")}\n${KO}]`
                          }
                          const Up = "let [x, y, z] = thisPos\ny += 1\napi.playParticleEffect({\n",
                            OX = "    pos1: [x, y, z],\n    pos2: [x + 1, y + 1, z + 1],";
                          const KX = .6;

                          function pX(OO, KO) {
                            return `${KO?"song":"sound"}:${OO}`
                          }
                          let XX = {
                              track: null,
                              volume: KX
                            },
                            bb = null,
                            eX = 0,
                            lX = 0;
                          const vb = new Set;

                          function CX(OO) {
                            XX = {
                              ...XX,
                              ...OO
                            }, vb.forEach((OO => {
                              OO()
                            }))
                          }

                          function hX(OO) {
                            XX.track && CX({
                              track: {
                                ...XX.track,
                                ...OO
                              }
                            })
                          }

                          function DX(OO) {
                            const [KO, pO] = (0, XO.useState)((() => OO(XX))), bK = (0, XO.useRef)(OO);
                            return bK.current = OO, (0, XO.useEffect)((() => {
                              const OO = () => {
                                pO((() => bK.current(XX)))
                              };
                              return vb.add(OO), OO(), () => {
                                vb.delete(OO)
                              }
                            }), []), KO
                          }

                          function MX() {
                            eX++;
                            const OO = bb;
                            bb = null, null === OO || void 0 === OO || OO.stop()
                          }

                          function ab(OO, KO) {
                            let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                            MX();
                            const bK = eX,
                              {
                                track: eO
                              } = XX,
                              lO = eO && eO.name === OO && eO.isSong === KO ? eO.duration : 0;
                            lX = XO, CX({
                              track: {
                                name: OO,
                                isSong: KO,
                                status: "loading",
                                duration: lO
                              }
                            }), Promise.all([pO.e(200), pO.e(230)]).then((() => pO(37867))).then((pO => {
                              let {
                                playDocsSound: eO
                              } = pO;
                              bK === eX && (bb = eO(OO, KO, XX.volume, XO, {
                                onPlay: OO => {
                                  bK === eX && hX({
                                    status: "playing",
                                    duration: OO
                                  })
                                },
                                onEnd: OO => {
                                  var KO, pO;
                                  bK === eX && (bb = null, OO ? CX({
                                    track: null
                                  }) : (lX = null !== (KO = null === (pO = XX.track) || void 0 === pO ? void 0 : pO.duration) && void 0 !== KO ? KO : 0, hX({
                                    status: "paused"
                                  })))
                                }
                              }))
                            })).catch((KO => {
                              console.error(`Could not play docs sound ${OO}`, KO), bK === eX && CX({
                                track: null
                              })
                            }))
                          }

                          function oX() {
                            const {
                              track: OO
                            } = XX;
                            if (!OO) return;
                            if ("playing" === OO.status && bb) return lX = bb.fV(), bb.pause(), void hX({
                              status: "paused"
                            });
                            if ("loading" === OO.status) return MX(), void hX({
                              status: "paused"
                            });
                            if (bb) return void bb.resume();
                            const KO = OO.duration > 0 && lX >= OO.duration - .05;
                            ab(OO.name, OO.isSong, KO ? 0 : lX)
                          }

                          function FX() {
                            var OO;
                            return bb && "playing" === (null === (OO = XX.track) || void 0 === OO ? void 0 : OO.status) ? bb.fV() : lX
                          }

                          function VX(OO) {
                            var KO;
                            null === (KO = bb) || void 0 === KO || KO.setVolume(OO), CX({
                              volume: OO
                            })
                          }

                          function LX() {
                            MX(), lX = 0, CX({
                              track: null
                            })
                          }
                          const QX = (0, XO.createContext)(null);
                          let zb = null;

                          function AX() {
                            const [OO, KO] = (0, XO.useState)(null);
                            return (0, XO.useEffect)((() => {
                              let OO = !1;
                              return zb ??= Promise.all([pO.e(62), pO.e(65), pO.e(63), pO.e(64), pO.e(183), pO.e(85), pO.e(208)]).then((() => pO(37858))), zb.then((pO => {
                                OO || KO(pO)
                              }), (OO => {
                                console.error("Could not load the docs gallery's textures", OO), zb = null
                              })), () => {
                                OO = !0
                              }
                            }), []), OO
                          }
                          const fX = 24,
                            dX = /^[a-z]+_(\d+(_\d+)?|none)$/;

                          function TX(OO, KO) {
                            const pO = "skins" === OO ? function(OO, KO) {
                              const pO = mX.find((KO => OO.startsWith(KO.heading)));
                              return pO ? function(OO, KO) {
                                return `${OO}-${KO}`
                              }(pO.prefix, KO) : null
                            }(KO.heading, KO.name) : null;
                            return null === pO ? null : `${Pp}/${pO}.webp`
                          }

                          function NX(OO) {
                            let {
                              kind: KO,
                              entry: pO,
                              assets: bK,
                              renderedUrl: lO
                            } = OO;
                            const {
                              name: vK
                            } = pO, [CO, hO] = (0, XO.useState)(!1);
                            if ("icons" === KO && RK(vK)) return (0, FO.jsx)(fp.d, {
                              className: "DocsTileIcon",
                              name: vK
                            });
                            let DO = null;
                            var MO;
                            if ("icons" === KO) DO = null !== (MO = null === bK || void 0 === bK ? void 0 : bK.getIngameIconUrl(vK)) && void 0 !== MO ? MO : null;
                            else if ("particles" === KO) {
                              var aK, oO, VO;
                              DO = null !== (aK = null === bK || void 0 === bK ? void 0 : bK.getParticleTextureUrl(null !== (oO = null === (VO = Rp(vK)) || void 0 === VO ? void 0 : VO.texture) && void 0 !== oO ? oO : vK)) && void 0 !== aK ? aK : null
                            } else "skins" === KO && (DO = null !== lO && void 0 !== lO ? lO : dX.test(vK) ? `/textures/charSkins/previews/${vK}_preview.png` : null);
                            return !DO || CO ? (0, FO.jsx)(LO, {
                              className: "DocsTileIcon Placeholder",
                              name: "skins" === KO ? "person" : "image"
                            }) : (0, FO.jsx)("img", {
                              className: eO()("DocsTileImage", {
                                Pixelated: "skins" !== KO
                              }),
                              src: DO,
                              srcSet: DO === lO ? `${DO} 2x` : void 0,
                              alt: "",
                              loading: "lazy",
                              onError: () => {
                                console.warn(`Docs gallery: could not load ${DO}`), hO(!0)
                              }
                            })
                          }

                          function IX(OO) {
                            let {
                              entry: KO,
                              isSong: pO
                            } = OO;
                            const XO = DX((OO => {
                                let {
                                  track: XO
                                } = OO;
                                return (null === XO || void 0 === XO ? void 0 : XO.name) === KO.name && XO.isSong === pO ? XO.status : null
                              })),
                              bK = null !== XO && "paused" !== XO;
                            return (0, FO.jsxs)("button", {
                              type: "button",
                              id: KO.anchor,
                              className: eO()("DocsSoundTile", {
                                Playing: bK
                              }),
                              "data-docs-track": pX(KO.name, pO),
                              "aria-label": bK ? `Pause ${KO.name}` : `Play ${KO.name}`,
                              onClick: () => {
                                null !== XO ? oX() : ab(KO.name, pO)
                              },
                              children: [(0, FO.jsx)("span", {
                                className: "DocsSoundPlay",
                                children: (0, FO.jsx)(LO, {
                                  name: bK ? "pause" : "play"
                                })
                              }), (0, FO.jsx)("code", {
                                className: "DocsSoundName",
                                children: KO.name
                              }), KO.caption && (0, FO.jsx)("span", {
                                className: "DocsSoundCaption",
                                children: KO.caption
                              })]
                            })
                          }

                          function yb(OO) {
                            let {
                              kind: KO,
                              names: pO,
                              isSongs: bK
                            } = OO;
                            const lO = AX(),
                              [vK, CO] = zK(),
                              hO = !1 === (null === vK || void 0 === vK ? void 0 : vK.failed) ? vK.text : null,
                              DO = (0, XO.useContext)(QX),
                              [MO, aK] = (0, XO.useState)(""),
                              oO = MO.trim().toLowerCase(),
                              VO = oO ? pO.filter((OO => OO.name.toLowerCase().includes(oO))) : pO;
                            return (0, FO.jsxs)("div", {
                              className: "DocsGallery",
                              children: [pO.length > fX && (0, FO.jsx)(Ap, {
                                className: "DocsGalleryFilter",
                                value: MO,
                                placeholder: `Filter ${pO.length} names\u2026`,
                                label: "Filter names",
                                onChange: aK,
                                count: oO ? {
                                  visible: VO.length,
                                  total: pO.length
                                } : null
                              }), (0, FO.jsx)("div", {
                                className: eO()("DocsGalleryGrid", `Kind-${KO}`, {
                                  Songs: bK
                                }),
                                children: VO.map((OO => {
                                  if ("sounds" === KO) return (0, FO.jsx)(IX, {
                                    entry: OO,
                                    isSong: bK
                                  }, OO.anchor);
                                  if (DO && "particles" === KO && Rp(OO.name)) return (0, FO.jsxs)("button", {
                                    type: "button",
                                    id: OO.anchor,
                                    className: eO()("DocsTile Previewable", {
                                      Copied: hO === OO.name
                                    }),
                                    title: `Play "${OO.name}" in the playground and copy its name`,
                                    onClick: () => {
                                      DO(OO.name), CO(OO.name)
                                    },
                                    children: [(0, FO.jsxs)("span", {
                                      className: "DocsTilePreview",
                                      children: [(0, FO.jsx)(NX, {
                                        kind: KO,
                                        entry: OO,
                                        assets: lO,
                                        renderedUrl: null
                                      }), (0, FO.jsx)("span", {
                                        className: "DocsTilePlayBadge",
                                        children: (0, FO.jsx)(LO, {
                                          name: "play"
                                        })
                                      })]
                                    }), (0, FO.jsx)("span", {
                                      className: "DocsTileName",
                                      children: hO === OO.name ? "Copied!" : OO.name
                                    })]
                                  }, OO.anchor);
                                  const pO = TX(KO, OO);
                                  return (0, FO.jsxs)("button", {
                                    type: "button",
                                    id: OO.anchor,
                                    className: eO()("DocsTile", {
                                      Copied: hO === OO.name
                                    }),
                                    title: `Copy "${OO.name}"`,
                                    onClick: () => {
                                      CO(OO.name)
                                    },
                                    children: [(0, FO.jsx)("span", {
                                      className: eO()("DocsTilePreview", {
                                        Rendered: null !== pO
                                      }),
                                      children: (0, FO.jsx)(NX, {
                                        kind: KO,
                                        entry: OO,
                                        assets: lO,
                                        renderedUrl: pO
                                      })
                                    }), (0, FO.jsx)("span", {
                                      className: "DocsTileName",
                                      children: hO === OO.name ? "Copied!" : OO.name
                                    })]
                                  }, OO.anchor)
                                }))
                              })]
                            })
                          }

                          function gb(OO) {
                            let {
                              kind: KO,
                              content: pO,
                              blocks: XO
                            } = OO;
                            return (0, FO.jsx)(FO.Fragment, {
                              children: rX(KO, pO, XO).map(((OO, pO) => "block" === OO.kind ? (0, FO.jsx)(aX, {
                                block: OO.block
                              }, pO) : (0, FO.jsx)(yb, {
                                kind: KO,
                                names: OO.names,
                                isSongs: OO.isSongs
                              }, pO)))
                            })
                          }
                          const uX = [{
                            pageId: "readme"
                          }, {
                            pageId: "snippets",
                            countNoun: "snippets"
                          }, {
                            pageId: "apiReference",
                            countNoun: "methods"
                          }, {
                            pageId: "callbacks",
                            countNoun: "callbacks"
                          }, {
                            pageId: "howTo"
                          }, {
                            pageId: "clientOptions",
                            countNoun: "options"
                          }];

                          function EX(OO) {
                            let {
                              cards: KO = uX,
                              label: pO = "Start here"
                            } = OO;
                            const bK = (0, XO.useContext)(oK);
                            return (0, FO.jsx)("nav", {
                              className: "DocsLandingCards",
                              "aria-label": pO,
                              children: KO.map((OO => {
                                let {
                                  pageId: KO,
                                  countNoun: pO
                                } = OO;
                                const XO = HO(KO);
                                return (0, FO.jsxs)(lO.c, {
                                  to: ZO(bK, XO),
                                  className: "DocsLandingCard",
                                  children: [(0, FO.jsx)("span", {
                                    className: "DocsLandingCardIcon",
                                    children: (0, FO.jsx)(LO, {
                                      name: XO.icon
                                    })
                                  }), (0, FO.jsx)("span", {
                                    className: "DocsLandingCardTitle",
                                    children: XO.title
                                  }), (0, FO.jsx)("span", {
                                    className: "DocsLandingCardSummary",
                                    children: XO.summary
                                  }), pO && (0, FO.jsxs)("span", {
                                    className: "DocsLandingCardCount",
                                    children: [SO(XO).sections.length, " ", pO]
                                  })]
                                }, KO)
                              }))
                            })
                          }
                          const jb = 240;

                          function YX(OO) {
                            let {
                              faces: KO
                            } = OO;
                            return (0, FO.jsxs)("span", {
                              className: "DocsCube",
                              "aria-hidden": "true",
                              children: [(0, FO.jsx)("span", {
                                className: "DocsCubeFace Top",
                                style: {
                                  backgroundImage: `url("${KO.top}")`
                                }
                              }), (0, FO.jsx)("span", {
                                className: "DocsCubeFace Left",
                                style: {
                                  backgroundImage: `url("${KO.left}")`
                                }
                              }), (0, FO.jsx)("span", {
                                className: "DocsCubeFace Right",
                                style: {
                                  backgroundImage: `url("${KO.right}")`
                                }
                              })]
                            })
                          }

                          function wX(OO) {
                            let {
                              src: KO
                            } = OO;
                            const [pO, bK] = (0, XO.useState)(!1);
                            return pO ? null : (0, FO.jsx)("img", {
                              src: KO,
                              alt: "",
                              loading: "lazy",
                              onError: () => {
                                console.warn(`Docs catalogue: could not load ${KO}`), bK(!0)
                              }
                            })
                          }

                          function ib(OO) {
                            let {
                              kind: KO
                            } = OO;
                            const pO = zX(KO),
                              bK = AX(),
                              lO = (0, vK.p)(),
                              [CO, hO] = (0, XO.useState)(""),
                              [DO, MO] = (0, XO.useState)(null),
                              [aK, oO] = (0, XO.useState)(jb),
                              [VO, QO] = (0, XO.useState)(null),
                              zK = (0, XO.useRef)(null),
                              fO = CO.trim().toLowerCase();
                            (0, XO.useEffect)((() => {
                              const OO = (0, IO.s)(lO.hash),
                                XO = pO.entries.find((pO => wp(KO, pO.name) === OO));
                              if (XO) zK.current = XO.name, hO(XO.name), MO(null), QO(XO.name);
                              else if (null !== zK.current) {
                                const OO = zK.current;
                                zK.current = null, hO((KO => KO === OO ? "" : KO)), QO(null)
                              }
                            }), [pO, KO, lO.hash, lO.key]), (0, XO.useEffect)((() => {
                              var OO;
                              null !== VO && (null === (OO = document.getElementById(wp(KO, VO))) || void 0 === OO || OO.scrollIntoView({
                                block: "center"
                              }))
                            }), [KO, VO]);
                            const dO = pO.entries.filter((OO => (!fO || OO.name.toLowerCase().includes(fO)) && (!DO || OO.variants.includes(DO))));
                            return (0, FO.jsxs)("div", {
                              className: "DocsCatalogue",
                              children: [pO.notes.length > 0 && (0, FO.jsx)("div", {
                                className: "DocsProse",
                                children: pO.notes.map((OO => (0, FO.jsx)("p", {
                                  children: OO
                                }, OO)))
                              }), pO.legend.length > 0 && (0, FO.jsx)("div", {
                                className: "DocsTableScroll",
                                children: (0, FO.jsxs)("table", {
                                  className: "DocsTable DocsVariantLegend",
                                  children: [(0, FO.jsx)("thead", {
                                    children: (0, FO.jsxs)("tr", {
                                      children: [(0, FO.jsx)("th", {
                                        children: "Code"
                                      }), (0, FO.jsx)("th", {
                                        children: "Variant"
                                      }), (0, FO.jsx)("th", {
                                        children: "Name to use"
                                      })]
                                    })
                                  }), (0, FO.jsx)("tbody", {
                                    children: pO.legend.map((OO => (0, FO.jsxs)("tr", {
                                      children: [(0, FO.jsx)("td", {
                                        children: (0, FO.jsx)("button", {
                                          type: "button",
                                          className: eO()("DocsVariantChip", {
                                            Active: DO === OO.code
                                          }),
                                          "aria-pressed": DO === OO.code,
                                          title: `Show only ${KO} with ${OO.meaning} variants`,
                                          onClick: () => {
                                            MO(DO === OO.code ? null : OO.code)
                                          },
                                          children: OO.code
                                        })
                                      }), (0, FO.jsx)("td", {
                                        children: OO.meaning
                                      }), (0, FO.jsx)("td", {
                                        children: (0, FO.jsx)("code", {
                                          className: "DocsInlineCode",
                                          children: OO.usage
                                        })
                                      })]
                                    }, OO.code)))
                                  })]
                                })
                              }), pO.examples.length > 0 && (0, FO.jsx)(NO, {
                                lang: "text",
                                code: pO.examples.join("\n")
                              }), (0, FO.jsx)(Ap, {
                                className: "DocsFilterBar",
                                value: CO,
                                placeholder: `Search ${pO.entries.length} ${KO}\u2026`,
                                label: `Search ${KO}`,
                                onChange: OO => {
                                  hO(OO), oO(jb)
                                },
                                count: fO || DO ? {
                                  visible: dO.length,
                                  total: pO.entries.length
                                } : null,
                                children: DO && (0, FO.jsxs)("button", {
                                  type: "button",
                                  className: "DocsVariantChip Active",
                                  onClick: () => {
                                    MO(null)
                                  },
                                  children: [DO, " ", (0, FO.jsx)(LO, {
                                    name: "cross"
                                  })]
                                })
                              }), (0, FO.jsx)("div", {
                                className: "DocsCatalogueGrid",
                                children: dO.slice(0, aK).map((OO => {
                                  const pO = "blocks" === KO ? null === bK || void 0 === bK ? void 0 : bK.getBlockFaces(OO.name) : null,
                                    XO = bK && !pO ? bK.getItemTextureUrl(OO.name) : null;
                                  return (0, FO.jsxs)("div", {
                                    id: wp(KO, OO.name),
                                    className: eO()("DocsCatalogueTile", {
                                      Linked: OO.name === VO
                                    }),
                                    children: [(0, FO.jsxs)("span", {
                                      className: "DocsCatalogueTexture",
                                      children: [pO && (0, FO.jsx)(YX, {
                                        faces: pO
                                      }), XO && (0, FO.jsx)(wX, {
                                        src: XO
                                      })]
                                    }), (0, FO.jsx)("span", {
                                      className: "DocsCatalogueName",
                                      children: OO.name
                                    }), OO.variants.length > 0 && (0, FO.jsx)("span", {
                                      className: "DocsCatalogueVariants",
                                      children: OO.variants.map((OO => (0, FO.jsx)("span", {
                                        children: OO
                                      }, OO)))
                                    }), (0, FO.jsx)(AO, {
                                      text: OO.name,
                                      className: "DocsCatalogueCopy"
                                    })]
                                  }, OO.name)
                                }))
                              }), dO.length > aK && (0, FO.jsxs)("button", {
                                type: "button",
                                className: "DocsShowMore",
                                onClick: () => {
                                  oO(dO.length)
                                },
                                children: ["Show all ", dO.length]
                              }), 0 === dO.length && (0, FO.jsxs)("p", {
                                className: "DocsEmpty",
                                children: ["No ", KO, " match."]
                              })]
                            })
                          }
                          var rb = pO(3964),
                            PX = pO(1406);
                          const mb = .95 * rb.e;

                          function sX(OO) {
                            return /^\s*```/.test(OO)
                          }

                          function HX(OO, KO) {
                            const pO = [
                              []
                            ];
                            let XO = !1;
                            for (const bK of OO.split("\n")) !XO && KO(bK) && pO.at(-1).length > 0 && pO.push([]), sX(bK) && (XO = !XO), pO.at(-1).push(bK);
                            return pO.map((OO => OO.join("\n").trim())).filter(Boolean)
                          }

                          function RX(OO, KO) {
                            const pO = `${"#".repeat(KO)} `,
                              XO = [];
                            let bK = !1;
                            for (const eO of OO.split("\n")) sX(eO) ? bK = !bK : !bK && eO.startsWith(pO) && XO.push(eO.slice(pO.length).trim());
                            return XO
                          }

                          function SX(OO) {
                            return OO.markdown.replace(/^\s*# .*\n/, "").trim()
                          }
                          class JX {
                            constructor(OO, KO) {
                              this.origin = KO, this.pages = void 0, this.partPaths = new Map;
                              const pO = OO.map((OO => {
                                const KO = function(OO, KO) {
                                  const pO = OO.map((OO => KO(OO) + 2)),
                                    XO = pO.reduce(((OO, KO) => OO + KO), 0),
                                    bK = XO / Math.ceil(XO / mb),
                                    eO = [];
                                  let lO = 0;
                                  return OO.forEach(((OO, KO) => {
                                    const XO = pO[KO];
                                    (0 === eO.length || lO + XO > mb || lO + XO / 2 > bK) && (eO.push([]), lO = 0), eO.at(-1).push(OO), lO += XO
                                  })), eO
                                }(HX(SX(OO), (OO => OO.startsWith("## "))).flatMap((OO => {
                                  var KO;
                                  const pO = null !== (KO = RX(OO, 2)[0]) && void 0 !== KO ? KO : "";
                                  if (OO.length <= mb) return [{
                                    markdown: OO,
                                    section: pO
                                  }];
                                  let XO = !1;
                                  return HX(OO, (OO => {
                                    const KO = XO && "" !== OO.trim();
                                    return XO = "" === OO.trim(), KO
                                  })).map((OO => ({
                                    markdown: OO,
                                    section: pO
                                  })))
                                })), (KO => this.resolveLinks(OO, KO.markdown).length));
                                return {
                                  page: OO,
                                  groups: KO.length > 1 ? KO : []
                                }
                              }));
                              for (const {
                                  page: XO,
                                  groups: bK
                                }
                                of pO) bK.forEach(((OO, KO) => {
                                const pO = (0, rb.t)(XO.slug, KO);
                                for (const bK of OO.flatMap((OO => [...RX(OO.markdown, 2), ...RX(OO.markdown, 3)]))) {
                                  const OO = `${XO.id}#${(0,IO.u)(bK)}`;
                                  this.partPaths.has(OO) || this.partPaths.set(OO, pO)
                                }
                              }));
                              this.pages = pO.map((OO => {
                                let {
                                  page: KO,
                                  groups: pO
                                } = OO;
                                return {
                                  page: KO,
                                  path: (0, rb.s)(KO.slug),
                                  markdown: `# ${KO.title}\n\n${this.resolveLinks(KO,SX(KO))}\n`,
                                  parts: pO.map(((OO, XO) => this.renderPart(KO, OO, XO, pO.length)))
                                }
                              }))
                            }
                            url(OO) {
                              return `${this.origin}${OO}`
                            }
                            getPage(OO) {
                              return this.pages.find((KO => KO.page.id === OO))
                            }
                            oversizedFiles() {
                              return this.pages.flatMap((OO => (OO.parts.length > 0 ? OO.parts : [{
                                path: OO.path,
                                label: "",
                                markdown: OO.markdown
                              }]).filter((OO => OO.markdown.length > rb.e))))
                            }
                            markdownUrl(OO, KO) {
                              const pO = KO && this.partPaths.get(`${OO.id}#${KO}`) || (0, rb.s)(OO.slug);
                              return this.url(KO ? `${pO}#${KO}` : pO)
                            }
                            resolveLinks(OO, KO) {
                              return KO.replace(/\]\((#[^)]+)\)/g, ((KO, pO) => {
                                var XO;
                                const bK = null !== (XO = cK(pO)) && void 0 !== XO ? XO : this.samePageTarget(OO, pO);
                                return bK ? `](${this.markdownUrl(bK.page,bK.anchor)})` : KO
                              }))
                            }
                            samePageTarget(OO, KO) {
                              const pO = (0, IO.u)(KO.slice(1));
                              return JO(OO, pO) ? {
                                page: OO,
                                anchor: pO
                              } : null
                            }
                            renderPart(OO, KO, pO, XO) {
                              const bK = function(OO) {
                                  const KO = OO.map((OO => OO.section)).filter(Boolean);
                                  if (0 === KO.length) return "";
                                  const pO = KO[0],
                                    XO = KO.at(-1);
                                  return pO === XO ? pO : `${pO} to ${XO}`
                                }(KO),
                                eO = KO.map((OO => OO.markdown)).join("\n\n"),
                                lO = bK ? `It covers ${bK}. ` : "",
                                vK = `Part ${pO+1} of ${XO} of [${OO.title}](${this.url((0,rb.s)(OO.slug))}). ${lO}[llms.txt](${this.url(rb.i)}) lists every part.`;
                              return {
                                path: (0, rb.t)(OO.slug, pO),
                                label: bK,
                                markdown: `# ${OO.title}, part ${pO+1} of ${XO}\n\n${vK}\n\n${this.resolveLinks(OO,eO)}\n`
                              }
                            }
                            llmsTxt(OO) {
                              const KO = ["# Bloxd Code API", "", "> JavaScript that runs inside Bloxd, in code blocks, boards and World Code: from a block that launches players into the sky to a whole custom game. Code calls methods on the `api` object and defines callbacks that react to game events.", "", `Each link is a page of the docs as Markdown. A page longer than about ${cb(rb.e)} tokens is also split into parts, listed under it, so that each fits a small context window. People read the same docs at ${this.url("/docs")}.`];
                              for (const pO of sO) {
                                KO.push("", `## ${pO.title}`, "");
                                for (const OO of pO.pageIds) {
                                  const pO = this.getPage(OO),
                                    {
                                      page: XO,
                                      parts: bK
                                    } = pO,
                                    eO = `About ${cb(pO.markdown.length)} tokens${bK.length>0?`, in ${bK.length} parts:`:"."}`;
                                  KO.push(`- [${XO.title}](${this.url(pO.path)}): ${XO.summary} ${eO}`), bK.forEach(((OO, pO) => {
                                    KO.push(`  - [Part ${pO+1}${OO.label?`: ${OO.label}`:""}](${this.url(OO.path)})`)
                                  }))
                                }
                              }
                              return KO.push("", "## Optional", "", `- [Every page in one file](${this.url(rb.h)}): About ${cb(OO.length)} tokens, for a model with a large context window.`, ""), KO.join("\n")
                            }
                            llmsFullTxt() {
                              return sO.flatMap((OO => OO.pageIds.map((OO => this.getPage(OO).markdown)))).join("\n---\n\n")
                            }
                            files() {
                              const OO = this.llmsFullTxt(),
                                KO = this.llmsTxt(OO),
                                pO = new Map([
                                  [rb.m, KO],
                                  [rb.i, KO],
                                  [rb.h, OO]
                                ]);
                              for (const XO of this.pages) {
                                pO.set(XO.path, XO.markdown);
                                for (const OO of XO.parts) pO.set(OO.path, OO.markdown)
                              }
                              return pO
                            }
                          }

                          function cb(OO) {
                            return `${Math.max(1,Math.round(OO/4e3))}K`
                          }
                          let BX = null;

                          function ZX() {
                            return BX ??= new JX(mK, PX.e), BX
                          }
                          const GX = [{
                            name: "ChatGPT",
                            url: "https://chatgpt.com/?hints=search&q="
                          }, {
                            name: "Claude",
                            url: "https://claude.ai/new?q="
                          }];

                          function qb(OO) {
                            return ZX().getPage(OO.id).parts.length > 0 ? `Read ${rb.j}, then the parts of the Bloxd Code API's ${OO.title} page it lists, so I can ask questions about it.` : `Read ${PX.e}${(0,rb.s)(OO.slug)} so I can ask questions about it. ${rb.j} lists every page of the Bloxd Code API docs.`
                          }

                          function xb(OO) {
                            let {
                              page: KO
                            } = OO;
                            const [pO, XO] = zK();
                            return (0, FO.jsxs)("div", {
                              className: "DocsPageAgentActions",
                              children: [(0, FO.jsxs)("button", {
                                type: "button",
                                className: "DocsPageAgentAction",
                                onClick: () => {
                                  XO(ZX().getPage(KO.id).markdown)
                                },
                                children: [(0, FO.jsx)(LO, {
                                  name: !1 === (null === pO || void 0 === pO ? void 0 : pO.failed) ? "check" : "copy"
                                }), (0, FO.jsx)("span", {
                                  children: pO ? pO.failed ? "Copy failed" : "Copied" : "Copy page"
                                })]
                              }), GX.map((OO => (0, FO.jsxs)("a", {
                                className: "DocsPageAgentAction",
                                href: `${OO.url}${encodeURIComponent(qb(KO))}`,
                                target: "_blank",
                                rel: "noreferrer",
                                children: [(0, FO.jsx)(LO, {
                                  name: "external-link"
                                }), (0, FO.jsxs)("span", {
                                  children: ["Open in ", OO.name]
                                })]
                              }, OO.name)))]
                            })
                          }

                          function nX(OO) {
                            return `#${[0,1,2].map((KO=>Math.round(Math.min(255,Math.max(0,OO[KO]))).toString(16).padStart(2,"0"))).join("")}`
                          }

                          function WX(OO) {
                            return [parseInt(OO.slice(1, 3), 16), parseInt(OO.slice(3, 5), 16), parseInt(OO.slice(5, 7), 16)]
                          }

                          function tb(OO) {
                            let {
                              label: KO,
                              min: pO,
                              max: XO,
                              step: bK,
                              low: eO,
                              high: lO,
                              onChange: vK
                            } = OO;
                            return (0, FO.jsxs)("div", {
                              className: "DocsControl",
                              children: [(0, FO.jsxs)("div", {
                                className: "DocsControlLabel",
                                children: [(0, FO.jsx)("span", {
                                  children: KO
                                }), (0, FO.jsx)("span", {
                                  className: "DocsControlValue",
                                  children: eO === lO ? eO : `${eO}\u2013${lO}`
                                })]
                              }), (0, FO.jsxs)("div", {
                                className: "DocsParticleRange",
                                children: [(0, FO.jsx)("input", {
                                  type: "range",
                                  min: pO,
                                  max: XO,
                                  step: bK,
                                  value: Math.min(XO, eO),
                                  "aria-label": `Minimum ${KO.toLowerCase()}`,
                                  onChange: OO => {
                                    const KO = Number(OO.target.value);
                                    vK(KO, Math.max(KO, lO))
                                  }
                                }), (0, FO.jsx)("input", {
                                  type: "range",
                                  min: pO,
                                  max: XO,
                                  step: bK,
                                  value: Math.min(XO, lO),
                                  "aria-label": `Maximum ${KO.toLowerCase()}`,
                                  onChange: OO => {
                                    const KO = Number(OO.target.value);
                                    vK(Math.min(KO, eO), KO)
                                  }
                                })]
                              })]
                            })
                          }

                          function kb(OO) {
                            let {
                              label: KO,
                              min: pO,
                              max: XO,
                              step: bK,
                              value: eO,
                              onChange: lO,
                              format: vK = String
                            } = OO;
                            return (0, FO.jsxs)("div", {
                              className: "DocsControl",
                              children: [(0, FO.jsxs)("div", {
                                className: "DocsControlLabel",
                                children: [(0, FO.jsx)("span", {
                                  children: KO
                                }), (0, FO.jsx)("span", {
                                  className: "DocsControlValue",
                                  children: vK(eO)
                                })]
                              }), (0, FO.jsx)("input", {
                                type: "range",
                                min: pO,
                                max: XO,
                                step: bK,
                                value: Math.min(XO, Math.max(pO, eO)),
                                "aria-label": KO,
                                onChange: OO => {
                                  lO(Number(OO.target.value))
                                }
                              })]
                            })
                          }

                          function UX(OO) {
                            let {
                              opts: KO,
                              onChange: pO
                            } = OO;
                            const XO = KO.colorGradients;
                            if (!Bp(XO)) return (0, FO.jsxs)("div", {
                              className: "DocsControl",
                              children: [(0, FO.jsx)("div", {
                                className: "DocsControlLabel",
                                children: (0, FO.jsx)("span", {
                                  children: "Colours, one per particle"
                                })
                              }), (0, FO.jsx)("div", {
                                className: "DocsParticleSwatches",
                                children: XO.map(((OO, KO) => (0, FO.jsx)("input", {
                                  type: "color",
                                  value: nX(OO.color),
                                  "aria-label": `Colour ${KO+1}`,
                                  onChange: OO => {
                                    const bK = [...XO];
                                    bK[KO] = {
                                      color: WX(OO.target.value)
                                    }, pO(bK)
                                  }
                                }, KO)))
                              })]
                            });
                            const bK = (OO, KO) => {
                              const bK = [...XO];
                              bK[OO] = KO, pO(bK)
                            };
                            return (0, FO.jsxs)("div", {
                              className: "DocsControl",
                              children: [(0, FO.jsxs)("div", {
                                className: "DocsControlLabel",
                                children: [(0, FO.jsx)("span", {
                                  children: "Colour over lifetime"
                                }), (0, FO.jsx)("span", {
                                  className: "DocsControlValue",
                                  children: "min \xb7 max"
                                })]
                              }), XO.map(((OO, KO) => {
                                var pO;
                                const XO = null !== (pO = OO.maxColor) && void 0 !== pO ? pO : OO.minColor;
                                return (0, FO.jsxs)("div", {
                                  className: "DocsParticleStop",
                                  children: [(0, FO.jsxs)("span", {
                                    className: "DocsParticleStopTime",
                                    children: [Math.round(100 * OO.timeFraction), "%"]
                                  }), (0, FO.jsx)("span", {
                                    className: "DocsParticleStopBar",
                                    style: {
                                      background: `linear-gradient(90deg, ${nX(OO.minColor)}, ${nX(XO)})`
                                    }
                                  }), (0, FO.jsx)("input", {
                                    type: "color",
                                    value: nX(OO.minColor),
                                    "aria-label": `Minimum colour at ${Math.round(100*OO.timeFraction)}%`,
                                    onChange: pO => {
                                      bK(KO, {
                                        ...OO,
                                        minColor: [...WX(pO.target.value), OO.minColor[3]]
                                      })
                                    }
                                  }), (0, FO.jsx)("input", {
                                    type: "color",
                                    value: nX(XO),
                                    "aria-label": `Maximum colour at ${Math.round(100*OO.timeFraction)}%`,
                                    onChange: pO => {
                                      bK(KO, {
                                        ...OO,
                                        maxColor: [...WX(pO.target.value), XO[3]]
                                      })
                                    }
                                  })]
                                }, KO)
                              }))]
                            })
                          }
                          const Ob = [-.5, -.5, -.5],
                            Kb = [.5, .5, .5],
                            pb = [0, 1, 2, 3, 4, 5, 6, 7].map((OO => [1 & OO ? Kb[0] : Ob[0], 2 & OO ? Kb[1] : Ob[1], 4 & OO ? Kb[2] : Ob[2]]));class Xb {
                            constructor() {
                              this.tints = new WeakMap
                            }
                            get(OO, KO, pO, XO) {
                              const bK = Math.round(31 * KO),
                                eO = Math.round(31 * pO),
                                lO = Math.round(31 * XO),
                                vK = `${bK}|${eO}|${lO}`;
                              let CO = this.tints.get(OO);
                              (!CO || CO.size > 2e3) && (CO = new Map, this.tints.set(OO, CO));
                              let hO = CO.get(vK);
                              if (hO) return hO;
                              hO = document.createElement("canvas"), hO.width = OO.naturalWidth || 16, hO.height = OO.naturalHeight || 16;
                              const DO = hO.getContext("2d");
                              return DO ? (DO.imageSmoothingEnabled = !1, DO.drawImage(OO, 0, 0, hO.width, hO.height), DO.globalCompositeOperation = "multiply", DO.fillStyle = `rgb(${bK/31*255}, ${eO/31*255}, ${lO/31*255})`, DO.fillRect(0, 0, hO.width, hO.height), DO.globalCompositeOperation = "destination-in", DO.drawImage(OO, 0, 0, hO.width, hO.height)) : console.warn("Particle preview: no 2D canvas context to tint a texture with"), CO.set(vK, hO), hO
                            }
                          }

                          function be(OO) {
                            let {
                              opts: KO,
                              textureUrl: pO,
                              burst: bK,
                              paused: eO
                            } = OO;
                            const lO = (0, XO.useRef)(null),
                              vK = (0, XO.useRef)(KO);
                            vK.current = KO;
                            const CO = (0, XO.useRef)(eO);
                            CO.current = eO;
                            const hO = (0, XO.useRef)(null),
                              DO = (0, XO.useRef)(null),
                              MO = (0, XO.useMemo)((() => Math.min(16, Math.max(1.6, 1.05 * function(OO) {
                                let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Math.random;
                                const pO = [-.5, -.5, -.5],
                                  XO = [.5, .5, .5];
                                let bK = .5;
                                for (let eO = 0; eO < 40; eO++) {
                                  const eO = Gp(OO, pO, XO, KO),
                                    lO = Math.max(eO.life / 30, .001);
                                  for (; np(eO, OO.gravity, lO);) bK = Math.max(bK, Math.hypot(eO.pos[0], eO.pos[1], eO.pos[2]) + eO.size / 2)
                                }
                                return bK
                              }(KO)))), [KO]),
                              aK = (0, XO.useRef)(MO);
                            return aK.current = MO, (0, XO.useEffect)((() => {
                              if (hO.current = null, !pO) return;
                              const OO = new Image;
                              let KO = !1;
                              return OO.onload = () => {
                                KO || (hO.current = OO)
                              }, OO.onerror = () => {
                                console.warn(`Particle preview: could not load the texture ${pO}`)
                              }, OO.src = pO, () => {
                                KO = !0
                              }
                            }), [pO]), (0, XO.useEffect)((() => {
                              var OO;
                              null === (OO = DO.current) || void 0 === OO || OO.call(DO)
                            }), [KO, bK]), (0, XO.useEffect)((() => {
                              const OO = lO.current,
                                KO = null === OO || void 0 === OO ? void 0 : OO.getContext("2d");
                              if (!OO || !KO) return void console.warn("Particle preview: no 2D canvas context to draw on");
                              const pO = new Xb;
                              let XO = [],
                                bK = 0,
                                eO = -.7,
                                MO = aK.current,
                                oO = performance.now(),
                                FO = 0,
                                VO = !0,
                                LO = null;
                              const QO = () => {
                                const OO = vK.current,
                                  KO = Math.min(400, Math.max(0, Math.ceil(OO.manualEmitCount)));
                                XO = [];
                                for (let pO = 0; pO < KO; pO++) XO.push(Gp(OO, Ob, Kb, Math.random));
                                bK = 0
                              };
                              DO.current = QO, QO();
                              const zK = lO => {
                                FO = requestAnimationFrame(zK);
                                const DO = Math.min(.05, (lO - oO) / 1e3);
                                if (oO = lO, !VO) return;
                                const AO = window.devicePixelRatio || 1,
                                  fO = Math.round(OO.clientWidth * AO),
                                  dO = Math.round(OO.clientHeight * AO);
                                if (0 === fO || 0 === dO) return;
                                OO.width === fO && OO.height === dO || (OO.width = fO, OO.height = dO);
                                const TO = vK.current;
                                null === LO && (eO += .18 * DO), MO += (aK.current - MO) * Math.min(1, 4 * DO);
                                const NO = .6 * DO;
                                XO = XO.filter((OO => np(OO, TO.gravity, NO))), 0 !== XO.length || CO.current || (bK += DO, bK > .6 && QO());
                                const IO = function(OO, KO, pO, XO) {
                                  const bK = 3.2 * XO,
                                    eO = .44 * Math.min(OO, KO) * bK / XO,
                                    lO = Math.cos(pO),
                                    vK = Math.sin(pO),
                                    CO = Math.cos(.42),
                                    hO = Math.sin(.42);
                                  return (pO, XO, DO) => {
                                    const MO = pO * vK + DO * lO,
                                      aK = bK - (XO * hO + MO * CO);
                                    if (aK < .05) return null;
                                    const oO = eO / aK;
                                    return {
                                      x: OO / 2 + (pO * lO - DO * vK) * oO,
                                      y: KO / 2 - (XO * CO - MO * hO) * oO,
                                      scale: oO,
                                      depth: aK
                                    }
                                  }
                                }(fO, dO, eO, MO);
                                ! function(OO, KO, pO, XO, bK) {
                                  const eO = OO.createLinearGradient(0, 0, 0, pO);
                                  eO.addColorStop(0, "#23262d"), eO.addColorStop(1, "#16181c"), OO.globalCompositeOperation = "source-over", OO.globalAlpha = 1, OO.fillStyle = eO, OO.fillRect(0, 0, KO, pO);
                                  const lO = (KO, pO) => {
                                      const bK = XO(KO[0], KO[1], KO[2]),
                                        eO = XO(pO[0], pO[1], pO[2]);
                                      bK && eO && (OO.beginPath(), OO.moveTo(bK.x, bK.y), OO.lineTo(eO.x, eO.y), OO.stroke())
                                    },
                                    vK = Math.ceil(bK) + 1,
                                    CO = Ob[1];
                                  OO.lineWidth = 1, OO.strokeStyle = "rgba(255, 255, 255, 0.07)";
                                  for (let hO = -vK; hO <= vK; hO++) lO([hO + .5, CO, .5 - vK], [hO + .5, CO, vK + .5]), lO([.5 - vK, CO, hO + .5], [vK + .5, CO, hO + .5]);
                                  OO.strokeStyle = "rgba(255, 255, 255, 0.28)", OO.setLineDash([4, 4]);
                                  for (const hO of pb)
                                    for (const OO of pb) {
                                      const KO = [0, 1, 2].filter((KO => hO[KO] !== OO[KO]));
                                      1 === KO.length && hO[KO[0]] < OO[KO[0]] && lO(hO, OO)
                                    }
                                  OO.setLineDash([])
                                }(KO, fO, dO, IO, MO);
                                const yK = hO.current,
                                  gK = XO.map((OO => ({
                                    particle: OO,
                                    at: IO(OO.pos[0], OO.pos[1], OO.pos[2])
                                  }))).filter((OO => null !== OO.at)).sort(((OO, KO) => KO.at.depth - OO.at.depth));
                                KO.imageSmoothingEnabled = !1;
                                for (const OO of function(OO) {
                                    switch (OO) {
                                      case Hp.d.OneOne:
                                        return [{
                                          operation: "lighter",
                                          usesAlpha: !1
                                        }];
                                      case Hp.d.Add:
                                        return [{
                                          operation: "lighter",
                                          usesAlpha: !0
                                        }];
                                      case Hp.d.Multiply:
                                        return [{
                                          operation: "multiply",
                                          usesAlpha: !0
                                        }];
                                      case Hp.d.MultiplyAdd:
                                        return [{
                                          operation: "multiply",
                                          usesAlpha: !0
                                        }, {
                                          operation: "lighter",
                                          usesAlpha: !0
                                        }];
                                      default:
                                        return [{
                                          operation: "source-over",
                                          usesAlpha: !0
                                        }]
                                    }
                                  }(TO.blendMode)) {
                                  KO.globalCompositeOperation = OO.operation;
                                  for (const {
                                      particle: XO,
                                      at: bK
                                    }
                                    of gK) {
                                    const [eO, lO, vK, CO] = xX(XO), hO = Math.max(1, XO.size * bK.scale);
                                    KO.globalAlpha = OO.usesAlpha ? Math.min(1, Math.max(0, CO)) : 1, yK ? KO.drawImage(pO.get(yK, eO, lO, vK), bK.x - hO / 2, bK.y - hO / 2, hO, hO) : (KO.fillStyle = `rgb(${255*eO}, ${255*lO}, ${255*vK})`, KO.fillRect(bK.x - hO / 2, bK.y - hO / 2, hO, hO))
                                  }
                                }
                                KO.globalCompositeOperation = "source-over", KO.globalAlpha = 1
                              };
                              FO = requestAnimationFrame(zK);
                              const AO = new IntersectionObserver((OO => {
                                let [KO] = OO;
                                VO = KO.isIntersecting
                              }));
                              AO.observe(OO);
                              const fO = KO => {
                                  LO = KO.clientX, OO.setPointerCapture(KO.pointerId)
                                },
                                dO = OO => {
                                  null !== LO && (eO += .01 * (OO.clientX - LO), LO = OO.clientX)
                                },
                                TO = () => {
                                  LO = null
                                };
                              return OO.addEventListener("pointerdown", fO), OO.addEventListener("pointermove", dO), OO.addEventListener("pointerup", TO), OO.addEventListener("pointercancel", TO), () => {
                                cancelAnimationFrame(FO), AO.disconnect(), DO.current = null, OO.removeEventListener("pointerdown", fO), OO.removeEventListener("pointermove", dO), OO.removeEventListener("pointerup", TO), OO.removeEventListener("pointercancel", TO)
                              }
                            }), []), (0, FO.jsx)("canvas", {
                              ref: lO,
                              className: "DocsParticleCanvas",
                              role: "img",
                              "aria-label": `Preview of a ${KO.texture} particle effect. Drag to turn the view.`
                            })
                          }
                          const eb = ["aura", "stomp", "brainRot", "mobTameSuccess", "mango", "redFirecrackerLarge"],
                            lb = [{
                              mode: Hp.d.OneOne,
                              label: "0 \xb7 OneOne (glow)"
                            }, {
                              mode: Hp.d.Standard,
                              label: "1 \xb7 Standard"
                            }, {
                              mode: Hp.d.Add,
                              label: "2 \xb7 Add"
                            }, {
                              mode: Hp.d.Multiply,
                              label: "3 \xb7 Multiply"
                            }, {
                              mode: Hp.d.MultiplyAdd,
                              label: "4 \xb7 MultiplyAdd"
                            }],
                            ve = (0, XO.forwardRef)((function(OO, KO) {
                              var pO, bK;
                              let {
                                textures: lO
                              } = OO;
                              const vK = AX(),
                                CO = (0, XO.useRef)(null),
                                [hO, DO] = (0, XO.useState)(Sp),
                                [MO, aK] = (0, XO.useState)("example"),
                                [oO, VO] = (0, XO.useState)(0),
                                [QO, zK] = (0, XO.useState)(!1),
                                fO = OO => {
                                  const KO = "example" === OO ? Sp : Rp(OO);
                                  KO && (DO(KO), aK(OO))
                                };
                              (0, XO.useImperativeHandle)(KO, (() => ({
                                preview: OO => {
                                  var KO;
                                  fO(OO), null === (KO = CO.current) || void 0 === KO || KO.scrollIntoView({
                                    behavior: "smooth",
                                    block: "start"
                                  })
                                }
                              })));
                              const dO = OO => {
                                  DO({
                                    ...hO,
                                    ...OO
                                  }), aK(null)
                                },
                                TO = function(OO, KO) {
                                  if (null !== KO) return `${Up}    presetId: "${KO}",\n${OX}\n})`;
                                  const pO = OO.velocityGradients.map((OO => `        {\n            timeFraction: ${Wp(OO.timeFraction)},\n            factor: ${Wp(OO.factor)},\n            factor2: ${Wp(OO.factor2)},\n        },`)),
                                    XO = [`    dir1: ${tX(OO.dir1)},`, `    dir2: ${tX(OO.dir2)},`, OX, `    texture: "${OO.texture}",`, `    minLifeTime: ${Wp(OO.minLifeTime)},`, `    maxLifeTime: ${Wp(OO.maxLifeTime)},`, `    minEmitPower: ${Wp(OO.minEmitPower)},`, `    maxEmitPower: ${Wp(OO.maxEmitPower)},`, `    minSize: ${Wp(OO.minSize)},`, `    maxSize: ${Wp(OO.maxSize)},`, `    manualEmitCount: ${Wp(OO.manualEmitCount)},`, `    gravity: ${tX(OO.gravity)},`, `    colorGradients: ${kX(OO.colorGradients,"    ")},`, `    velocityGradients: ${pO.length>0?`[\n${pO.join("\n")}\n    ]`:"[]"},`, `    blendMode: ${Wp(OO.blendMode)},`];
                                  return void 0 !== OO.hideDist && XO.push(`    hideDist: ${Wp(OO.hideDist)},`), `${Up}${XO.join("\n")}\n})`
                                }(hO, null === MO || "example" === MO ? null : MO),
                                IO = lO.includes(hO.texture) ? lO : [...lO, hO.texture];
                              return (0, FO.jsxs)("section", {
                                ref: CO,
                                className: "DocsPlayground DocsParticlePlayground",
                                "aria-label": "Particle effect playground",
                                children: [(0, FO.jsxs)("header", {
                                  className: "DocsPlaygroundHeader",
                                  children: [(0, FO.jsxs)("div", {
                                    children: [(0, FO.jsx)("div", {
                                      className: "DocsPlaygroundTitle",
                                      children: "Try it: particle effects"
                                    }), (0, FO.jsx)("div", {
                                      className: "DocsPlaygroundHint",
                                      children: "Pick a preset or change the settings, and the burst replays. Drag the preview to turn it."
                                    })]
                                  }), (0, FO.jsx)(AO, {
                                    text: TO,
                                    label: "Copy code"
                                  })]
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsPlaygroundPresets",
                                  children: [(0, FO.jsx)("button", {
                                    type: "button",
                                    className: eO()("DocsVariantChip", {
                                      Active: "example" === MO
                                    }),
                                    onClick: () => {
                                      fO("example")
                                    },
                                    children: "Example"
                                  }), eb.filter((OO => null !== Rp(OO))).map((OO => (0, FO.jsx)("button", {
                                    type: "button",
                                    className: eO()("DocsVariantChip", {
                                      Active: MO === OO
                                    }),
                                    onClick: () => {
                                      fO(OO)
                                    },
                                    children: OO
                                  }, OO))), (0, FO.jsxs)("select", {
                                    className: "DocsParticleSelect",
                                    value: null !== MO && void 0 !== MO ? MO : "custom",
                                    "aria-label": "Preset",
                                    onChange: OO => {
                                      fO(OO.target.value)
                                    },
                                    children: [(0, FO.jsx)("option", {
                                      value: "example",
                                      children: "Example effect"
                                    }), null === MO && (0, FO.jsx)("option", {
                                      value: "custom",
                                      children: "Custom"
                                    }), sp.d.map((OO => (0, FO.jsx)("option", {
                                      value: OO,
                                      children: OO
                                    }, OO)))]
                                  })]
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsParticleBody",
                                  children: [(0, FO.jsxs)("div", {
                                    className: "DocsParticleStageWrap",
                                    children: [(0, FO.jsx)(be, {
                                      opts: hO,
                                      textureUrl: null !== (pO = null === vK || void 0 === vK ? void 0 : vK.getParticleTextureUrl(hO.texture)) && void 0 !== pO ? pO : null,
                                      burst: oO,
                                      paused: QO
                                    }), (0, FO.jsxs)("div", {
                                      className: "DocsParticleStageButtons",
                                      children: [(0, FO.jsxs)("button", {
                                        type: "button",
                                        className: "DocsParticleStageButton",
                                        onClick: () => {
                                          VO(oO + 1)
                                        },
                                        children: [(0, FO.jsx)(LO, {
                                          name: "replay"
                                        }), (0, FO.jsx)("span", {
                                          children: "Replay"
                                        })]
                                      }), (0, FO.jsxs)("button", {
                                        type: "button",
                                        className: "DocsParticleStageButton",
                                        "aria-pressed": QO,
                                        onClick: () => {
                                          zK(!QO)
                                        },
                                        children: [(0, FO.jsx)(LO, {
                                          name: QO ? "play" : "pause"
                                        }), (0, FO.jsx)("span", {
                                          children: QO ? "Loop" : "Stop looping"
                                        })]
                                      })]
                                    })]
                                  }), (0, FO.jsxs)("div", {
                                    className: "DocsParticleControls",
                                    children: [(0, FO.jsxs)("div", {
                                      className: "DocsControl",
                                      children: [(0, FO.jsxs)("div", {
                                        className: "DocsControlLabel",
                                        children: [(0, FO.jsx)("span", {
                                          children: "Texture"
                                        }), (0, FO.jsx)("code", {
                                          className: "DocsControlValue",
                                          children: hO.texture
                                        })]
                                      }), (0, FO.jsx)("div", {
                                        className: "DocsParticleTextures",
                                        children: IO.map((OO => {
                                          var KO;
                                          const pO = null !== (KO = null === vK || void 0 === vK ? void 0 : vK.getParticleTextureUrl(OO)) && void 0 !== KO ? KO : null;
                                          return (0, FO.jsx)("button", {
                                            type: "button",
                                            className: eO()("DocsParticleTexture", {
                                              Active: hO.texture === OO
                                            }),
                                            title: OO,
                                            "aria-label": OO,
                                            "aria-pressed": hO.texture === OO,
                                            onClick: () => {
                                              dO({
                                                texture: OO
                                              })
                                            },
                                            children: pO ? (0, FO.jsx)("img", {
                                              src: pO,
                                              alt: ""
                                            }) : (0, FO.jsx)(LO, {
                                              name: "image"
                                            })
                                          }, OO)
                                        }))
                                      })]
                                    }), (0, FO.jsx)(kb, {
                                      label: "Particles",
                                      min: 1,
                                      max: 400,
                                      step: 1,
                                      value: hO.manualEmitCount,
                                      onChange: OO => {
                                        dO({
                                          manualEmitCount: OO
                                        })
                                      }
                                    }), (0, FO.jsx)(tb, {
                                      label: "Lifetime",
                                      min: .05,
                                      max: 3,
                                      step: .05,
                                      low: hO.minLifeTime,
                                      high: hO.maxLifeTime,
                                      onChange: (OO, KO) => {
                                        dO({
                                          minLifeTime: OO,
                                          maxLifeTime: KO
                                        })
                                      }
                                    }), (0, FO.jsx)(tb, {
                                      label: "Emit power",
                                      min: 0,
                                      max: 40,
                                      step: .5,
                                      low: hO.minEmitPower,
                                      high: hO.maxEmitPower,
                                      onChange: (OO, KO) => {
                                        dO({
                                          minEmitPower: OO,
                                          maxEmitPower: KO
                                        })
                                      }
                                    }), (0, FO.jsx)(tb, {
                                      label: "Size",
                                      min: .05,
                                      max: 2,
                                      step: .05,
                                      low: hO.minSize,
                                      high: hO.maxSize,
                                      onChange: (OO, KO) => {
                                        dO({
                                          minSize: OO,
                                          maxSize: KO
                                        })
                                      }
                                    }), (0, FO.jsx)(kb, {
                                      label: "Gravity (up)",
                                      min: -40,
                                      max: 40,
                                      step: 1,
                                      value: null !== (bK = hO.gravity[1]) && void 0 !== bK ? bK : 0,
                                      onChange: OO => {
                                        var KO, pO;
                                        dO({
                                          gravity: [null !== (KO = hO.gravity[0]) && void 0 !== KO ? KO : 0, OO, null !== (pO = hO.gravity[2]) && void 0 !== pO ? pO : 0]
                                        })
                                      }
                                    }), (0, FO.jsxs)("div", {
                                      className: "DocsControl",
                                      children: [(0, FO.jsx)("div", {
                                        className: "DocsControlLabel",
                                        children: (0, FO.jsx)("span", {
                                          children: "Blend mode"
                                        })
                                      }), (0, FO.jsx)("select", {
                                        className: "DocsParticleSelect",
                                        value: hO.blendMode,
                                        "aria-label": "Blend mode",
                                        onChange: OO => {
                                          dO({
                                            blendMode: Number(OO.target.value)
                                          })
                                        },
                                        children: lb.map((OO => {
                                          let {
                                            mode: KO,
                                            label: pO
                                          } = OO;
                                          return (0, FO.jsx)("option", {
                                            value: KO,
                                            children: pO
                                          }, KO)
                                        }))
                                      })]
                                    }), (0, FO.jsx)(UX, {
                                      opts: hO,
                                      onChange: OO => {
                                        dO({
                                          colorGradients: OO
                                        })
                                      }
                                    })]
                                  })]
                                }), (0, FO.jsx)(NO, {
                                  code: TO,
                                  lang: "ts"
                                })]
                              })
                            }));
                          var Cb = pO(3668),
                            hb = pO(1533);

                          function Db(OO, KO) {
                            return OO ? Cb.b.includes(KO) ? OO.getIngameIconUrl(KO) : OO.getItemIconUrl(KO) : null
                          }

                          function Mb(OO) {
                            var KO, pO, XO;
                            let {
                              part: bK,
                              assets: lO
                            } = OO;
                            const vK = Db(lO, bK.icon),
                              CO = null !== (KO = null === (pO = bK.style) || void 0 === pO ? void 0 : pO.fontSize) && void 0 !== KO ? KO : "1.8em",
                              hO = (0, sK.Ub)(bK.style);
                            return (0, FO.jsxs)("span", {
                              className: eO()("DocsBloxdTextIcon", {
                                Missing: !vK
                              }),
                              style: {
                                width: CO,
                                height: CO,
                                opacity: null === (XO = bK.style) || void 0 === XO ? void 0 : XO.opacity
                              },
                              title: vK ? void 0 : `No Bloxd icon, item or block is called "${bK.icon}"`,
                              children: [vK && hO && (0, FO.jsx)("span", {
                                className: "DocsBloxdTextIconTint",
                                style: {
                                  background: hO,
                                  maskImage: `url("${vK}")`,
                                  WebkitMaskImage: `url("${vK}")`
                                }
                              }), vK ? (0, FO.jsx)("img", {
                                src: vK,
                                alt: "",
                                className: eO()({
                                  Tinted: hO
                                })
                              }) : (0, FO.jsx)(LO, {
                                name: "image"
                              })]
                            })
                          }

                          function ae(OO) {
                            let {
                              parts: KO,
                              className: pO
                            } = OO;
                            const XO = AX(),
                              bK = [];
                            let lO = [];
                            const vK = OO => {
                              lO.length > 0 && (bK.push((0, FO.jsx)(hb.d, {
                                text: lO
                              }, `run-${OO}`)), lO = [])
                            };
                            return KO.forEach(((OO, KO) => {
                              "icon" !== cp(OO) || RK(OO.icon) ? lO.push(OO) : (vK(KO), bK.push((0, FO.jsx)(Mb, {
                                part: OO,
                                assets: XO
                              }, `icon-${KO}`)))
                            })), vK(KO.length), (0, FO.jsx)("div", {
                              className: eO()("DocsStyledTextPreview", pO),
                              children: bK
                            })
                          }
                          const ob = ["0.75em", "1em", "1.25em", "1.5em", "2em", "3em"];
                          let Fb = null;

                          function Vb(OO) {
                            if (Fb ??= document.createElement("canvas").getContext("2d"), !Fb) return "#000000";
                            Fb.fillStyle = "#000000", Fb.fillStyle = OO;
                            const KO = Fb.fillStyle;
                            return KO.startsWith("#") ? KO : "#000000"
                          }

                          function Lb(OO) {
                            let {
                              value: KO,
                              label: pO,
                              onChange: XO
                            } = OO;
                            return (0, FO.jsxs)("span", {
                              className: "DocsColourInput",
                              children: [(0, FO.jsx)("input", {
                                type: "color",
                                value: Vb(KO),
                                "aria-label": `${pO} picker`,
                                onChange: OO => {
                                  XO(OO.target.value)
                                }
                              }), (0, FO.jsx)("input", {
                                type: "text",
                                value: KO,
                                placeholder: "#ffb914 or gold",
                                "aria-label": pO,
                                spellCheck: !1,
                                onChange: OO => {
                                  XO(OO.target.value)
                                }
                              })]
                            })
                          }

                          function Qb(OO) {
                            let {
                              value: KO,
                              fontAwesomeIcons: pO,
                              onChange: bK
                            } = OO;
                            const lO = AX(),
                              [vK, CO] = (0, XO.useState)(RK(KO) ? "fontAwesome" : "bloxd"),
                              [hO, DO] = (0, XO.useState)(""),
                              MO = hO.trim().toLowerCase(),
                              aK = "bloxd" === vK ? Cb.b : pO,
                              oO = MO ? aK.filter((OO => OO.toLowerCase().includes(MO))) : aK;
                            return (0, FO.jsxs)("div", {
                              className: "DocsIconPicker",
                              children: [(0, FO.jsx)("input", {
                                type: "text",
                                value: KO,
                                "aria-label": "Icon name",
                                spellCheck: !1,
                                onChange: OO => {
                                  bK(OO.target.value)
                                }
                              }), (0, FO.jsx)("p", {
                                className: "DocsTextFieldHint",
                                children: "Pick one below, or type any item or block name."
                              }), (0, FO.jsxs)("div", {
                                className: "DocsIconPickerTabs",
                                role: "tablist",
                                children: [
                                  ["bloxd", "fontAwesome"].map((OO => (0, FO.jsx)("button", {
                                    type: "button",
                                    role: "tab",
                                    "aria-selected": vK === OO,
                                    className: eO()("DocsVariantChip", {
                                      Active: vK === OO
                                    }),
                                    onClick: () => {
                                      CO(OO)
                                    },
                                    children: "bloxd" === OO ? `Bloxd icons (${Cb.b.length})` : `Font Awesome (${pO.length})`
                                  }, OO))), (0, FO.jsx)("input", {
                                    type: "search",
                                    value: hO,
                                    placeholder: "Filter\u2026",
                                    "aria-label": "Filter icons",
                                    onChange: OO => {
                                      DO(OO.target.value)
                                    }
                                  })
                                ]
                              }), (0, FO.jsxs)("div", {
                                className: "DocsIconPickerGrid",
                                role: "tabpanel",
                                children: [oO.map((OO => {
                                  const pO = "bloxd" === vK ? Db(lO, OO) : null;
                                  return (0, FO.jsx)("button", {
                                    type: "button",
                                    title: OO,
                                    "aria-label": OO,
                                    "aria-pressed": OO === KO,
                                    className: eO()("DocsIconPickerOption", {
                                      Active: OO === KO
                                    }),
                                    onClick: () => {
                                      bK(OO)
                                    },
                                    children: "fontAwesome" === vK ? (0, FO.jsx)(fp.d, {
                                      name: OO
                                    }) : pO ? (0, FO.jsx)("img", {
                                      src: pO,
                                      alt: ""
                                    }) : (0, FO.jsx)(LO, {
                                      name: "image"
                                    })
                                  }, OO)
                                })), 0 === oO.length && (0, FO.jsxs)("p", {
                                  className: "DocsTextFieldHint",
                                  children: ["No icons match \u201c", hO, "\u201d."]
                                })]
                              })]
                            })
                          }

                          function ze(OO) {
                            let {
                              property: KO,
                              value: pO,
                              fontAwesomeIcons: XO,
                              onChange: bK
                            } = OO;
                            const {
                              field: eO,
                              label: lO
                            } = KO, vK = OO => "" !== OO || KO.isRequired ? OO : void 0;
                            switch (eO.kind) {
                              case "text":
                                return eO.multiline ? (0, FO.jsx)("textarea", {
                                  value: String(null !== pO && void 0 !== pO ? pO : ""),
                                  rows: 2,
                                  "aria-label": lO,
                                  onChange: OO => {
                                    bK(OO.target.value)
                                  }
                                }) : (0, FO.jsx)("input", {
                                  type: "text",
                                  value: String(null !== pO && void 0 !== pO ? pO : ""),
                                  "aria-label": lO,
                                  onChange: OO => {
                                    bK(vK(OO.target.value))
                                  }
                                });
                              case "size":
                                return (0, FO.jsx)("input", {
                                  type: "text",
                                  value: String(null !== pO && void 0 !== pO ? pO : ""),
                                  placeholder: KO.defaultText,
                                  list: "DocsTextSizeSuggestions",
                                  "aria-label": lO,
                                  spellCheck: !1,
                                  onChange: OO => {
                                    bK(vK(OO.target.value.trim()))
                                  }
                                });
                              case "colour":
                                return (0, FO.jsx)(Lb, {
                                  value: String(null !== pO && void 0 !== pO ? pO : ""),
                                  label: lO,
                                  onChange: OO => {
                                    bK(vK(OO))
                                  }
                                });
                              case "colours": {
                                const OO = Array.isArray(pO) ? pO : [],
                                  KO = OO => {
                                    bK(OO.length > 0 ? OO : void 0)
                                  };
                                return (0, FO.jsxs)("div", {
                                  className: "DocsColourList",
                                  children: [OO.map(((pO, XO) => (0, FO.jsxs)("span", {
                                    className: "DocsColourListRow",
                                    children: [(0, FO.jsx)(Lb, {
                                      value: pO,
                                      label: `${lO} ${XO+1}`,
                                      onChange: pO => {
                                        KO(OO.map(((OO, KO) => KO === XO ? pO : OO)))
                                      }
                                    }), (0, FO.jsx)("button", {
                                      type: "button",
                                      className: "DocsTextIconButton",
                                      "aria-label": `Remove colour ${XO+1}`,
                                      onClick: () => {
                                        KO(OO.filter(((OO, KO) => KO !== XO)))
                                      },
                                      children: (0, FO.jsx)(LO, {
                                        name: "cross"
                                      })
                                    })]
                                  }, XO))), (0, FO.jsxs)("button", {
                                    type: "button",
                                    className: "DocsTextAddButton",
                                    onClick: () => {
                                      var pO;
                                      KO([...OO, null !== (pO = OO.at(-1)) && void 0 !== pO ? pO : "#ffffff"])
                                    },
                                    children: [(0, FO.jsx)(LO, {
                                      name: "plus"
                                    }), 0 === OO.length ? "Add a colour" : "Add a colour to the gradient"]
                                  })]
                                })
                              }
                              case "fraction": {
                                var CO;
                                const OO = "number" === typeof pO ? pO : Number(null !== (CO = KO.defaultText) && void 0 !== CO ? CO : 0);
                                return (0, FO.jsxs)("span", {
                                  className: "DocsFractionInput",
                                  children: [(0, FO.jsx)("input", {
                                    type: "range",
                                    min: 0,
                                    max: 1,
                                    step: .01,
                                    value: OO,
                                    "aria-label": lO,
                                    onChange: OO => {
                                      bK(Number(OO.target.value))
                                    }
                                  }), (0, FO.jsx)("output", {
                                    children: OO.toFixed(2)
                                  })]
                                })
                              }
                              case "choice":
                                return (0, FO.jsxs)("select", {
                                  value: String(null !== pO && void 0 !== pO ? pO : ""),
                                  "aria-label": lO,
                                  onChange: OO => {
                                    bK(vK(OO.target.value))
                                  },
                                  children: [!KO.isRequired && (0, FO.jsxs)("option", {
                                    value: "",
                                    children: ["Default (", KO.defaultText, ")"]
                                  }), eO.options.map((OO => (0, FO.jsx)("option", {
                                    value: OO,
                                    children: OO
                                  }, OO)))]
                                });
                              case "icon":
                                return (0, FO.jsx)(Qb, {
                                  value: String(null !== pO && void 0 !== pO ? pO : ""),
                                  fontAwesomeIcons: XO,
                                  onChange: bK
                                })
                            }
                          }

                          function Ab(OO) {
                            let KO;
                            try {
                              KO = JSON.parse(OO)
                            } catch (pO) {
                              return {
                                part: null,
                                error: `Not valid JSON yet: ${pO.message}`
                              }
                            }
                            return pp(KO) ? {
                              part: KO,
                              error: null
                            } : {
                              part: null,
                              error: "Not a part Bloxd draws: use a string or an object such as { entityName } or { translationKey }."
                            }
                          }

                          function fb(OO) {
                            let {
                              parts: KO,
                              index: pO,
                              fontAwesomeIcons: bK,
                              onChange: eO,
                              ypO: lO,
                              onClose: vK
                            } = OO;
                            const CO = (0, XO.useContext)(FK),
                              DO = (0, XO.useRef)(null),
                              MO = KO[pO],
                              aK = cp(MO),
                              [oO, VO] = (0, XO.useState)((() => JSON.stringify(MO, null, 2))),
                              QO = (0, XO.useMemo)((() => "other" === aK ? Ab(oO).error : null), [aK, oO]);
                            (0, XO.useEffect)((() => {
                              var OO;
                              null === (OO = DO.current) || void 0 === OO || OO.focus()
                            }), []);
                            const zK = (0, FO.jsx)("div", {
                              className: "DocsTextDialogOverlay",
                              onMouseDown: OO => {
                                OO.target === OO.currentTarget && vK()
                              },
                              children: (0, FO.jsxs)("div", {
                                ref: DO,
                                className: "DocsTextDialog",
                                role: "dialog",
                                "aria-modal": "true",
                                "aria-label": `Edit part ${pO+1}: ${SK[aK]}`,
                                tabIndex: -1,
                                onKeyDown: OO => {
                                  "Escape" === OO.key ? (OO.stopPropagation(), vK()) : "Tab" === OO.key && DO.current && function(OO, KO) {
                                    const pO = Array.from(OO.querySelectorAll(EK)),
                                      XO = pO[0],
                                      bK = pO.at(-1);
                                    if (!XO || !bK) return;
                                    const eO = document.activeElement;
                                    !KO.shiftKey || eO !== XO && eO !== OO ? KO.shiftKey || eO !== bK || (KO.preventDefault(), XO.focus()) : (KO.preventDefault(), bK.focus())
                                  }(DO.current, OO)
                                },
                                children: [(0, FO.jsxs)("header", {
                                  className: "DocsTextDialogHeader",
                                  children: [(0, FO.jsxs)("div", {
                                    children: [(0, FO.jsxs)("div", {
                                      className: "DocsTextDialogKind",
                                      children: ["Part ", pO + 1]
                                    }), (0, FO.jsx)("div", {
                                      className: "DocsTextDialogTitle",
                                      children: SK[aK]
                                    })]
                                  }), (0, FO.jsx)("button", {
                                    type: "button",
                                    className: "DocsTextIconButton",
                                    "aria-label": "Close",
                                    onClick: vK,
                                    children: (0, FO.jsx)(LO, {
                                      name: "cross"
                                    })
                                  })]
                                }), (0, FO.jsx)(ae, {
                                  parts: KO,
                                  className: "DocsTextDialogPreview"
                                }), (0, FO.jsx)("div", {
                                  className: "DocsTextDialogFields",
                                  children: "other" === aK ? (0, FO.jsxs)("label", {
                                    className: "DocsTextField",
                                    children: [(0, FO.jsx)("span", {
                                      className: "DocsTextFieldLabel",
                                      children: "JSON"
                                    }), (0, FO.jsx)("textarea", {
                                      className: "DocsTextJson",
                                      value: oO,
                                      rows: 6,
                                      spellCheck: !1,
                                      onChange: OO => {
                                        VO(OO.target.value);
                                        const KO = Ab(OO.target.value);
                                        null !== KO.part && eO(KO.part)
                                      }
                                    }), QO && (0, FO.jsx)("span", {
                                      className: "DocsTextFieldError",
                                      children: QO
                                    })]
                                  }) : ZK[aK].map((OO => {
                                    const KO = qp(MO, OO.path),
                                      pO = OO.isRequired ? JSON.stringify(nK(MO, OO.path)) === JSON.stringify(MO) : void 0 === KO;
                                    return (0, FO.jsxs)("div", {
                                      className: "DocsTextField",
                                      children: [(0, FO.jsxs)("div", {
                                        className: "DocsTextFieldLabel",
                                        children: [(0, FO.jsx)("span", {
                                          children: OO.label
                                        }), (0, FO.jsxs)("button", {
                                          type: "button",
                                          className: "DocsTextResetButton",
                                          disabled: pO,
                                          "aria-label": `Reset ${OO.label.toLowerCase()} to default`,
                                          onClick: () => {
                                            eO(nK(MO, OO.path))
                                          },
                                          children: [(0, FO.jsx)(LO, {
                                            name: "replay"
                                          }), "Reset"]
                                        })]
                                      }), (0, FO.jsx)(ze, {
                                        property: OO,
                                        value: KO,
                                        fontAwesomeIcons: bK,
                                        onChange: KO => {
                                          eO(xp(MO, OO.path, KO))
                                        }
                                      }), !OO.isRequired && (0, FO.jsxs)("span", {
                                        className: "DocsTextFieldHint",
                                        children: ["Default: ", OO.defaultText]
                                      })]
                                    }, OO.path.join("."))
                                  }))
                                }), (0, FO.jsxs)("footer", {
                                  className: "DocsTextDialogFooter",
                                  children: [(0, FO.jsxs)("button", {
                                    type: "button",
                                    className: "DocsTextRemoveButton",
                                    onClick: lO,
                                    children: [(0, FO.jsx)(LO, {
                                      name: "trash"
                                    }), "Remove part"]
                                  }), (0, FO.jsx)("button", {
                                    type: "button",
                                    className: "DocsTextDoneButton",
                                    onClick: vK,
                                    children: "Done"
                                  })]
                                }), (0, FO.jsx)("datalist", {
                                  id: "DocsTextSizeSuggestions",
                                  children: ob.map((OO => (0, FO.jsx)("option", {
                                    value: OO
                                  }, OO)))
                                })]
                              })
                            });
                            return CO ? (0, hO.createPortal)(zK, CO) : zK
                          }
                          const db = [{
                              label: "Icon and text",
                              parts: [{
                                icon: "Pixelated Heart"
                              }, " You gained a life!"]
                            }, {
                              label: "Coloured words",
                              parts: ["Welcome to ", {
                                str: "Sky Castle",
                                style: {
                                  color: "#ffb914",
                                  fontWeight: "bold"
                                }
                              }, ", adventurer!"]
                            }, {
                              label: "Achievement",
                              parts: [{
                                icon: "fa-solid fa-trophy",
                                style: {
                                  color: "gold"
                                }
                              }, {
                                str: " Achievement unlocked: ",
                                style: {
                                  opacity: .8
                                }
                              }, {
                                str: "Master Builder",
                                style: {
                                  color: "#4f94f1",
                                  fontStyle: "italic"
                                }
                              }]
                            }, {
                              label: "Loading bar",
                              parts: ["Charging ", {
                                type: "ProgressBar",
                                progress: .65,
                                colours: ["#4f94f1", "#9be15d"]
                              }, " Press ", {
                                type: "StyledKeyBinding",
                                action: "jump"
                              }]
                            }],
                            Tb = Object.keys(JK);

                          function Nb(OO) {
                            let {
                              fontAwesomeIcons: KO
                            } = OO;
                            const [pO, bK] = (0, XO.useState)(db[0].parts), [lO, vK] = (0, XO.useState)((() => UK(db[0].parts))), [CO, hO] = (0, XO.useState)(null), [DO, MO] = (0, XO.useState)(!1), [aK, oO] = (0, XO.useState)(null), [VO, QO] = (0, XO.useState)(!1), [zK, AO] = (0, XO.useState)(null), fO = (0, XO.useRef)(null), dO = UK(pO);
                            (0, XO.useLayoutEffect)((() => {
                              var OO;
                              if (!zK) return;
                              const KO = OO => {
                                  var KO;
                                  return null === (KO = fO.current) || void 0 === KO ? void 0 : KO.querySelector(`[data-focus-key="${OO}"]`)
                                },
                                pO = KO(zK.key);
                              null === (OO = pO && !pO.disabled ? pO : KO(zK.fallback)) || void 0 === OO || OO.focus(), AO(null)
                            }), [zK]);
                            const TO = OO => {
                                bK(OO), vK(UK(OO)), hO(null)
                              },
                              IO = OO => {
                                TO(pO.filter(((KO, pO) => pO !== OO))), AO({
                                  key: `edit-${Math.min(OO,pO.length-2)}`,
                                  fallback: "add"
                                })
                              },
                              yK = (OO, KO) => {
                                const XO = [...pO],
                                  [bK] = XO.splice(OO, 1);
                                XO.splice(OO + KO, 0, bK), TO(XO);
                                AO({
                                  key: `${KO<0?"up":"down"}-${OO+KO}`,
                                  fallback: `edit-${OO+KO}`
                                })
                              };
                            return (0, FO.jsxs)("section", {
                              ref: fO,
                              className: "DocsPlayground DocsTextEditor",
                              "aria-label": "Styled text editor",
                              children: [(0, FO.jsx)("header", {
                                className: "DocsPlaygroundHeader",
                                children: (0, FO.jsxs)("div", {
                                  children: [(0, FO.jsx)("div", {
                                    className: "DocsPlaygroundTitle",
                                    children: "Styled text editor"
                                  }), (0, FO.jsx)("div", {
                                    className: "DocsPlaygroundHint",
                                    children: "Add parts, click one to style it, and copy the code. The preview draws it as the game does."
                                  })]
                                })
                              }), (0, FO.jsx)("div", {
                                className: "DocsPlaygroundPresets",
                                children: db.map((OO => (0, FO.jsx)("button", {
                                  type: "button",
                                  className: eO()("DocsVariantChip", {
                                    Active: dO === UK(OO.parts)
                                  }),
                                  onClick: () => {
                                    TO(OO.parts)
                                  },
                                  children: OO.label
                                }, OO.label)))
                              }), (0, FO.jsx)(ae, {
                                parts: pO,
                                className: "DocsTextEditorPreview"
                              }), (0, FO.jsxs)("div", {
                                className: "DocsTextEditorBody",
                                children: [(0, FO.jsxs)("div", {
                                  className: "DocsTextEditorPanel",
                                  children: [(0, FO.jsx)("div", {
                                    className: "DocsTextEditorPanelTitle",
                                    children: "Parts"
                                  }), (0, FO.jsxs)("ol", {
                                    className: "DocsTextParts",
                                    children: [pO.map(((OO, KO) => {
                                      const XO = cp(OO);
                                      return (0, FO.jsxs)("li", {
                                        className: "DocsTextPart",
                                        children: [(0, FO.jsxs)("button", {
                                          type: "button",
                                          className: "DocsTextPartMain",
                                          "data-focus-key": `edit-${KO}`,
                                          "aria-label": `Edit part ${KO+1}, ${SK[XO]}`,
                                          onClick: () => {
                                            oO(KO)
                                          },
                                          children: [(0, FO.jsx)("span", {
                                            className: "DocsTextPartKind",
                                            children: SK[XO]
                                          }), (0, FO.jsx)(ae, {
                                            parts: [OO],
                                            className: "DocsTextPartPreview"
                                          }), "text" !== XO && (0, FO.jsx)("code", {
                                            className: "DocsTextPartName",
                                            children: WK(OO)
                                          })]
                                        }), (0, FO.jsxs)("span", {
                                          className: "DocsTextPartActions",
                                          children: [(0, FO.jsx)("button", {
                                            type: "button",
                                            className: "DocsTextIconButton",
                                            "aria-label": `Move part ${KO+1} up`,
                                            "data-focus-key": `up-${KO}`,
                                            disabled: 0 === KO,
                                            onClick: () => {
                                              yK(KO, -1)
                                            },
                                            children: (0, FO.jsx)(LO, {
                                              name: "chevron-up"
                                            })
                                          }), (0, FO.jsx)("button", {
                                            type: "button",
                                            className: "DocsTextIconButton",
                                            "aria-label": `Move part ${KO+1} down`,
                                            "data-focus-key": `down-${KO}`,
                                            disabled: KO === pO.length - 1,
                                            onClick: () => {
                                              yK(KO, 1)
                                            },
                                            children: (0, FO.jsx)(LO, {
                                              name: "chevron-down"
                                            })
                                          }), (0, FO.jsx)("button", {
                                            type: "button",
                                            className: "DocsTextIconButton",
                                            "aria-label": `Remove part ${KO+1}`,
                                            onClick: () => {
                                              IO(KO)
                                            },
                                            children: (0, FO.jsx)(LO, {
                                              name: "cross"
                                            })
                                          })]
                                        })]
                                      }, KO)
                                    })), 0 === pO.length && (0, FO.jsx)("li", {
                                      className: "DocsTextPartsEmpty",
                                      children: "No parts yet. Add one below."
                                    })]
                                  }), (0, FO.jsxs)("div", {
                                    className: "DocsTextAddPart",
                                    onKeyDown: OO => {
                                      "Escape" === OO.key && VO && (OO.stopPropagation(), QO(!1), AO({
                                        key: "add",
                                        fallback: "add"
                                      }))
                                    },
                                    children: [(0, FO.jsxs)("button", {
                                      type: "button",
                                      className: "DocsTextAddPartButton",
                                      "data-focus-key": "add",
                                      "aria-expanded": VO,
                                      "aria-controls": "DocsTextAddPartMenu",
                                      onClick: () => {
                                        QO(!VO)
                                      },
                                      children: [(0, FO.jsx)(LO, {
                                        name: "plus"
                                      }), "Add a part", (0, FO.jsx)(LO, {
                                        name: VO ? "chevron-up" : "chevron-down"
                                      })]
                                    }), VO && (0, FO.jsx)("ul", {
                                      id: "DocsTextAddPartMenu",
                                      className: "DocsTextAddPartMenu",
                                      children: Tb.map((OO => (0, FO.jsx)("li", {
                                        children: (0, FO.jsx)("button", {
                                          type: "button",
                                          onClick: () => {
                                            (OO => {
                                              TO([...pO, JK[OO]]), QO(!1), oO(pO.length)
                                            })(OO)
                                          },
                                          children: SK[OO]
                                        })
                                      }, OO)))
                                    })]
                                  })]
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsTextEditorPanel",
                                  children: [(0, FO.jsxs)("div", {
                                    className: "DocsTextEditorPanelTitle",
                                    children: ["Code", (0, FO.jsxs)("button", {
                                      type: "button",
                                      className: "DocsTextEditCodeButton",
                                      "aria-pressed": DO,
                                      onClick: () => {
                                        MO(!DO)
                                      },
                                      children: [(0, FO.jsx)(LO, {
                                        name: DO ? "check" : "pencil"
                                      }), DO ? "Done" : "Edit"]
                                    })]
                                  }), DO ? (0, FO.jsxs)(FO.Fragment, {
                                    children: [(0, FO.jsx)("textarea", {
                                      className: "DocsPlaygroundInput",
                                      value: lO,
                                      spellCheck: !1,
                                      "aria-label": "Styled text as code",
                                      onChange: OO => {
                                        vK(OO.target.value);
                                        const KO = Xp(OO.target.value);
                                        hO(KO.error), KO.parts && bK(KO.parts)
                                      }
                                    }), CO && (0, FO.jsx)("p", {
                                      className: "DocsPlaygroundError",
                                      children: CO
                                    })]
                                  }) : (0, FO.jsx)(NO, {
                                    lang: "js",
                                    code: `api.sendMessage(playerId, ${dO})`
                                  })]
                                })]
                              }), null !== aK && aK < pO.length && (0, FO.jsx)(fb, {
                                parts: pO,
                                index: aK,
                                fontAwesomeIcons: KO,
                                onChange: OO => {
                                  ((OO, KO) => {
                                    TO(pO.map(((pO, XO) => XO === OO ? KO : pO)))
                                  })(aK, OO)
                                },
                                ypO: () => {
                                  IO(aK), oO(null)
                                },
                                onClose: () => {
                                  oO(null), AO({
                                    key: `edit-${aK}`,
                                    fallback: "add"
                                  })
                                }
                              })]
                            })
                          }
                          var Ib = pO(3977),
                            ye = pO(3967),
                            ge = pO(3972),
                            ub = pO(3984);
                          const Eb = 40,
                            je = 800,
                            Yb = 150,
                            wb = 8e3,
                            ie = 2e3;

                          function re(OO, KO) {
                            return 12 * Math.log2(KO / OO)
                          }

                          function Pb(OO, KO) {
                            return Math.round(OO * 2 ** (KO / 12) * 10) / 10
                          }

                          function me(OO) {
                            return `${OO} ms`
                          }

                          function sb(OO) {
                            return `${OO} st`
                          }
                          const Hb = [{
                            key: "variationSemitones",
                            label: "Word variation",
                            max: 6
                          }, {
                            key: "declineSemitones",
                            label: "Fall over a sentence",
                            max: 12
                          }, {
                            key: "questionRiseSemitones",
                            label: "Question rise",
                            max: 12
                          }, {
                            key: "exclaimLiftSemitones",
                            label: "Exclamation lift",
                            max: 12
                          }];

                          function Rb(OO) {
                            let {
                              synth: KO,
                              onChange: pO
                            } = OO;
                            const XO = (0, Ib.l)(KO);
                            return (0, FO.jsxs)("div", {
                              className: "DocsVoiceControls",
                              children: [(0, FO.jsxs)("div", {
                                className: "DocsVoiceGroup",
                                children: [(0, FO.jsx)("div", {
                                  className: "DocsVoiceGroupTitle",
                                  children: "Voice"
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsControl",
                                  children: [(0, FO.jsx)("div", {
                                    className: "DocsControlLabel",
                                    children: (0, FO.jsx)("span", {
                                      children: "Tone"
                                    })
                                  }), (0, FO.jsx)("div", {
                                    className: "DocsVoiceWaveforms",
                                    children: Ib.g.map((OO => (0, FO.jsx)("button", {
                                      type: "button",
                                      className: eO()("DocsVariantChip", {
                                        Active: KO.waveform === OO
                                      }),
                                      "aria-pressed": KO.waveform === OO,
                                      onClick: () => {
                                        pO({
                                          waveform: OO
                                        })
                                      },
                                      children: OO
                                    }, OO)))
                                  })]
                                }), (0, FO.jsx)(kb, {
                                  label: "Pitch",
                                  min: 0,
                                  max: re(Eb, je),
                                  step: .1,
                                  value: re(Eb, KO.pitchHz),
                                  format: () => `${KO.pitchHz} Hz`,
                                  onChange: OO => {
                                    pO({
                                      pitchHz: Pb(Eb, OO)
                                    })
                                  }
                                }), (0, FO.jsx)(kb, {
                                  label: "Time per syllable",
                                  min: 25,
                                  max: 200,
                                  step: 1,
                                  value: KO.syllableMs,
                                  format: me,
                                  onChange: OO => {
                                    pO({
                                      syllableMs: OO
                                    })
                                  }
                                }), (0, FO.jsx)(kb, {
                                  label: "Volume",
                                  min: 0,
                                  max: 2,
                                  step: .05,
                                  value: KO.volume,
                                  onChange: OO => {
                                    pO({
                                      volume: OO
                                    })
                                  }
                                })]
                              }), (0, FO.jsxs)("div", {
                                className: "DocsVoiceGroup",
                                children: [(0, FO.jsx)("div", {
                                  className: "DocsVoiceGroupTitle",
                                  children: "Each blip"
                                }), (0, FO.jsx)(kb, {
                                  label: "Length",
                                  min: 10,
                                  max: 300,
                                  step: 1,
                                  value: KO.durationMs,
                                  format: me,
                                  onChange: OO => {
                                    pO({
                                      durationMs: OO
                                    })
                                  }
                                }), (0, FO.jsx)(kb, {
                                  label: "Fade in",
                                  min: 0,
                                  max: XO.durationMs,
                                  step: 1,
                                  value: XO.attackMs,
                                  format: me,
                                  onChange: OO => {
                                    pO({
                                      attackMs: OO
                                    })
                                  }
                                }), (0, FO.jsx)(kb, {
                                  label: "Fade out",
                                  min: 0,
                                  max: XO.durationMs - XO.attackMs,
                                  step: 1,
                                  value: XO.releaseMs,
                                  format: me,
                                  onChange: OO => {
                                    pO({
                                      releaseMs: OO
                                    })
                                  }
                                }), (0, FO.jsx)(kb, {
                                  label: "Glide",
                                  min: -12,
                                  max: 12,
                                  step: .1,
                                  value: KO.glideSemitones,
                                  format: sb,
                                  onChange: OO => {
                                    pO({
                                      glideSemitones: OO
                                    })
                                  }
                                }), (0, FO.jsxs)("label", {
                                  className: "DocsVoiceToggle",
                                  children: [(0, FO.jsx)("input", {
                                    type: "checkbox",
                                    checked: null !== KO.lowpassHz,
                                    onChange: OO => {
                                      pO({
                                        lowpassHz: OO.target.checked ? ie : null
                                      })
                                    }
                                  }), (0, FO.jsx)("span", {
                                    children: "Muffle with a filter"
                                  })]
                                }), null !== KO.lowpassHz && (0, FO.jsx)(kb, {
                                  label: "Filter",
                                  min: 0,
                                  max: re(Yb, wb),
                                  step: .1,
                                  value: re(Yb, KO.lowpassHz),
                                  format: () => `${KO.lowpassHz} Hz`,
                                  onChange: OO => {
                                    pO({
                                      lowpassHz: Pb(Yb, OO)
                                    })
                                  }
                                })]
                              }), (0, FO.jsxs)("div", {
                                className: "DocsVoiceGroup",
                                children: [(0, FO.jsx)("div", {
                                  className: "DocsVoiceGroupTitle",
                                  children: "Intonation"
                                }), Hb.map((OO => {
                                  let {
                                    key: XO,
                                    label: bK,
                                    max: eO
                                  } = OO;
                                  return (0, FO.jsx)(kb, {
                                    label: bK,
                                    min: 0,
                                    max: eO,
                                    step: .1,
                                    value: KO.intonation[XO],
                                    format: sb,
                                    onChange: OO => {
                                      pO({
                                        intonation: {
                                          ...KO.intonation,
                                          [XO]: OO
                                        }
                                      })
                                    }
                                  }, XO)
                                }))]
                              })]
                            })
                          }
                          const Sb = Object.keys(Ib.k),
                            Jb = ["Welcome, traveller. The road ahead is long.", "Have you seen my lost sheep anywhere?", "Watch out, the bridge is about to collapse!"];

                          function ce(OO) {
                            var KO;
                            const pO = JSON.stringify((0, Ib.l)(OO));
                            return null !== (KO = Sb.find((OO => JSON.stringify((0, Ib.l)(Ib.k[OO])) === pO))) && void 0 !== KO ? KO : null
                          }

                          function Bb(OO) {
                            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                            if ("object" !== typeof OO || null === OO) return JSON.stringify(OO);
                            return `{\n${Object.entries(OO).map((OO=>{let[pO,XO]=OO;return`${KO}    ${pO}: ${Bb(XO,`${KO}    `)},`})).join("\n")}\n${KO}}`
                          }

                          function Zb(OO, KO, pO) {
                            const XO = ce(OO),
                              bK = [`    line: ${JSON.stringify(KO)},`];
                            return pO && bK.push(`    speakerName: ${JSON.stringify(pO)},`), bK.push("    voice,"), `const voice = ${XO?JSON.stringify(XO):Bb((0,Ib.l)(OO))}\n\napi.setClientOption(playerId, "dialogue", {\n${bK.join("\n")}\n})`
                          }
                          const Gb = 400,
                            qe = 90;
                          let xe = null;

                          function nb(OO, KO, pO) {
                            return xe ??= new AudioContext, xe.resume(), (0, ub.c)(xe, xe.destination, OO, KO, pO, (() => {}))
                          }

                          function Wb() {
                            const [OO, KO] = (0, XO.useState)(Ib.k.regular), [pO, bK] = (0, XO.useState)(Jb[0]), [lO, vK] = (0, XO.useState)("Innkeeper"), [CO, hO] = (0, XO.useState)(0), DO = DX((OO => OO.volume)), MO = (0, XO.useRef)(null), aK = (0, XO.useRef)(0), oO = (0, XO.useRef)(0), VO = () => {
                              var OO;
                              null === (OO = MO.current) || void 0 === OO || OO.call(MO), MO.current = null
                            };
                            (0, XO.useEffect)((() => () => {
                              var OO;
                              null === (OO = MO.current) || void 0 === OO || OO.call(MO), window.clearTimeout(aK.current)
                            }), []);
                            const QO = (0, XO.useMemo)((() => ({
                                line: pO,
                                speakerName: lO || void 0,
                                voice: OO
                              })), [pO, lO, OO]),
                              zK = (0, XO.useRef)(QO);
                            zK.current = QO;
                            const fO = ce(OO),
                              dO = OO => {
                                window.clearTimeout(aK.current), VO();
                                const {
                                  plan: KO,
                                  synth: pO
                                } = (0, ge.g)(OO);
                                pO && (MO.current = nb(pO, KO.blips, DO)), hO((OO => OO + 1))
                              },
                              TO = Zb(OO, pO, lO);
                            return (0, FO.jsxs)("section", {
                              className: "DocsPlayground DocsVoicePlayground",
                              "aria-label": "Voice playground",
                              children: [(0, FO.jsxs)("header", {
                                className: "DocsPlaygroundHeader",
                                children: [(0, FO.jsxs)("div", {
                                  children: [(0, FO.jsx)("div", {
                                    className: "DocsPlaygroundTitle",
                                    children: "Try it: voices"
                                  }), (0, FO.jsx)("div", {
                                    className: "DocsPlaygroundHint",
                                    children: "Start from a preset and change it to suit your character. The line replays as you go."
                                  })]
                                }), (0, FO.jsx)(AO, {
                                  text: TO,
                                  label: "Copy code"
                                })]
                              }), (0, FO.jsxs)("div", {
                                className: "DocsPlaygroundPresets",
                                children: [Sb.map((OO => (0, FO.jsx)("button", {
                                  type: "button",
                                  className: eO()("DocsVariantChip", {
                                    Active: fO === OO
                                  }),
                                  "aria-pressed": fO === OO,
                                  onClick: () => {
                                    (OO => {
                                      const pO = Ib.k[OO];
                                      KO(pO), dO({
                                        ...QO,
                                        voice: pO
                                      })
                                    })(OO)
                                  },
                                  children: OO
                                }, OO))), !fO && (0, FO.jsx)("span", {
                                  className: "DocsVariantChip Active DocsVoiceCustomChip",
                                  children: "custom"
                                })]
                              }), (0, FO.jsxs)("div", {
                                className: "DocsVoiceBody",
                                children: [(0, FO.jsxs)("div", {
                                  className: "DocsVoiceScene",
                                  children: [(0, FO.jsx)("div", {
                                    className: "DocsVoiceStage",
                                    children: (0, FO.jsx)(ye.e, {
                                      display: QO
                                    }, CO)
                                  }), (0, FO.jsxs)("form", {
                                    className: "DocsVoiceLineRow",
                                    onSubmit: OO => {
                                      OO.preventDefault(), dO(QO)
                                    },
                                    children: [(0, FO.jsx)("input", {
                                      value: pO,
                                      "aria-label": "Line",
                                      placeholder: "Type a line to hear it",
                                      onChange: OO => {
                                        bK(OO.target.value)
                                      }
                                    }), (0, FO.jsxs)("button", {
                                      type: "submit",
                                      className: "DocsVoiceSpeakButton",
                                      children: [(0, FO.jsx)(LO, {
                                        name: "play"
                                      }), (0, FO.jsx)("span", {
                                        children: "Speak"
                                      })]
                                    })]
                                  }), (0, FO.jsx)("div", {
                                    className: "DocsVoiceSamples",
                                    children: Jb.map((OO => (0, FO.jsx)("button", {
                                      type: "button",
                                      className: eO()("DocsVariantChip", {
                                        Active: pO === OO
                                      }),
                                      onClick: () => {
                                        var KO;
                                        bK(KO = OO), dO({
                                          ...QO,
                                          line: KO
                                        })
                                      },
                                      children: OO
                                    }, OO)))
                                  }), (0, FO.jsxs)("label", {
                                    className: "DocsVoiceSpeaker",
                                    children: [(0, FO.jsx)("span", {
                                      children: "Speaker"
                                    }), (0, FO.jsx)("input", {
                                      value: lO,
                                      placeholder: "No name",
                                      onChange: OO => {
                                        vK(OO.target.value)
                                      }
                                    })]
                                  })]
                                }), (0, FO.jsx)(Rb, {
                                  synth: OO,
                                  onChange: pO => {
                                    const XO = {
                                      ...OO,
                                      ...pO
                                    };
                                    KO(XO);
                                    const bK = {
                                        ...QO,
                                        voice: XO
                                      },
                                      eO = performance.now();
                                    if (eO - oO.current >= qe) {
                                      oO.current = eO, VO();
                                      const OO = (0, ge.g)(bK).plan.blips[0];
                                      OO && (MO.current = nb((0, Ib.l)(XO), [{
                                        ...OO,
                                        atMs: 0
                                      }], DO))
                                    }
                                    window.clearTimeout(aK.current), aK.current = window.setTimeout((() => {
                                      dO(zK.current)
                                    }), Gb)
                                  }
                                })]
                              }), (0, FO.jsx)(NO, {
                                code: TO,
                                lang: "ts"
                              })]
                            })
                          }
                          var te = pO(3996);
                          const ke = /(`{1,2})\s*(.+?)\s*\1(?!`)/g,
                            Ub = String.raw`(?:async\s+)?(?:function\b|\(|[A-Za-z_$][\w$]*\s*=>)`,
                            Oe = [
                              [new RegExp(String.raw`([A-Za-z_$][\w$]*)\s*(?:=(?![=>])|:)\s*${Ub}`, "g"), te.s],
                              [/\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g],
                              [/([A-Za-z_$][\w$]*)\s*\([^()]*\)\s*\{/g, te.s]
                            ];

                          function Ke(OO) {
                            return `${OO.pageId}#${OO.anchor}`
                          }
                          let pe, Xe, bl;

                          function ee(OO) {
                            const KO = (0, IO.i)(OO),
                              pO = new Set;
                            for (const [, , XO] of KO.matchAll(IO.c)) {
                              const OO = XO.startsWith("#") ? cK(XO) : null,
                                KO = OO ? Ke({
                                  pageId: OO.page.id,
                                  anchor: OO.anchor
                                }) : null;
                              null !== KO && (pe || (pe = new Set(mK.flatMap((OO => EO(OO.layout) ? SO(OO).sections.map((KO => Ke({
                                pageId: OO.id,
                                anchor: KO.heading.anchor
                              }))) : [])))), pe).has(KO) && pO.add(KO)
                            }
                            for (const [, , XO] of KO.matchAll(ke)) {
                              const OO = ap(XO);
                              OO && pO.add(Ke(OO))
                            }
                            return pO
                          }

                          function le(OO, KO) {
                            const pO = new Set,
                              XO = function(OO) {
                                return OO.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "").replace(/"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'/g, '""')
                              }(OO);
                            for (const [, bK] of XO.matchAll(/\bapi\.([A-Za-z_$][\w$]*)/g)) pO.add(bK);
                            for (const [bK, eO] of Oe)
                              for (const [, OO] of(0, te.i)(XO, bK, eO)) KO.has(OO) && pO.add(OO);
                            return pO
                          }

                          function vl(OO, KO, pO, XO) {
                            const bK = OO.get(KO);
                            bK ? !XO && bK.some((OO => OO.pageId === pO.pageId)) || bK.push(pO) : OO.set(KO, [pO])
                          }
                          const Ce = /^[A-Za-z_$][\w$]*$/;

                          function he(OO) {
                            return Ce.test(OO.name) ? OO.name : "options"
                          }

                          function De(OO, KO) {
                            const pO = OO.params.map(he).join(", ");
                            return KO ? `${OO.name} = (${pO}) => {\n\t\n}` : `api.${OO.name}(${pO})`
                          }

                          function Me(OO) {
                            let {
                              method: KO,
                              isCallback: pO
                            } = OO;
                            return (0, FO.jsxs)("div", {
                              className: "DocsSignature",
                              children: [(0, FO.jsxs)("span", {
                                className: "DocsSignatureCode",
                                children: [pO ? (0, FO.jsxs)(FO.Fragment, {
                                  children: [(0, FO.jsx)("span", {
                                    className: "DocsSignatureName",
                                    children: KO.name
                                  }), (0, FO.jsx)("span", {
                                    className: "DocsTypePunctuation",
                                    children: " = ("
                                  })]
                                }) : (0, FO.jsxs)(FO.Fragment, {
                                  children: [(0, FO.jsx)("span", {
                                    className: "DocsSignatureObject",
                                    children: "api."
                                  }), (0, FO.jsx)("span", {
                                    className: "DocsSignatureName",
                                    children: KO.name
                                  }), (0, FO.jsx)("span", {
                                    className: "DocsTypePunctuation",
                                    children: "("
                                  })]
                                }), KO.params.map(((OO, pO) => (0, FO.jsxs)(XO.Fragment, {
                                  children: [pO > 0 && (0, FO.jsx)("span", {
                                    className: "DocsTypePunctuation",
                                    children: ", "
                                  }), (0, FO.jsx)("a", {
                                    className: "DocsSignatureParam",
                                    href: `#${KO.name}-${he(OO)}`,
                                    children: OO.name
                                  })]
                                }, OO.name))), (0, FO.jsx)("span", {
                                  className: "DocsTypePunctuation",
                                  children: pO ? ") => " : ")"
                                }), pO && !KO.returns && (0, FO.jsx)("span", {
                                  className: "DocsTypeKeyword",
                                  children: "void"
                                })]
                              }), KO.returns && KO.returns.type && (0, FO.jsxs)("span", {
                                className: "DocsSignatureReturns",
                                children: [!pO && (0, FO.jsx)("span", {
                                  className: "DocsSignatureArrow",
                                  children: "\u2192"
                                }), (0, FO.jsx)(yp, {
                                  type: KO.returns.type
                                })]
                              })]
                            })
                          }

                          function al(OO) {
                            let {
                              title: KO,
                              references: pO
                            } = OO;
                            const bK = (0, XO.useContext)(oK);
                            return (0, FO.jsxs)("div", {
                              className: "DocsCardReferences",
                              children: [(0, FO.jsx)("span", {
                                className: "DocsCardReferencesTitle",
                                children: KO
                              }), pO.map((OO => (0, FO.jsx)(lO.c, {
                                to: ZO(bK, HO(OO.pageId), OO.anchor),
                                children: OO.label
                              }, `${OO.pageId}#${OO.anchor}`)))]
                            })
                          }

                          function oe(OO) {
                            var KO, pO;
                            let {
                              pageId: XO,
                              anchor: bK
                            } = OO;
                            const eO = Ke({
                                pageId: XO,
                                anchor: bK
                              }),
                              lO = null !== (KO = function() {
                                if (!bl) {
                                  bl = new Map;
                                  const XO = new Set(mK.filter((OO => "callbacks" === OO.layout)).flatMap((OO => SO(OO).sections.map((OO => OO.heading.text)))));
                                  for (const bK of mK)
                                    if ("article" === bK.layout || "snippets" === bK.layout)
                                      for (const eO of (0, IO.x)(SO(bK)))
                                        for (const {
                                            code: lO
                                          }
                                          of(0, IO.k)(eO.blocks))
                                          for (const vK of le(lO, XO)) {
                                            const XO = MK().get(vK);
                                            if (XO) {
                                              var OO, KO, pO;
                                              const lO = {
                                                pageId: bK.id,
                                                anchor: null !== (OO = null === (KO = eO.heading) || void 0 === KO ? void 0 : KO.anchor) && void 0 !== OO ? OO : "",
                                                label: null !== (pO = bK.navTitle) && void 0 !== pO ? pO : bK.title
                                              };
                                              vl(bl, Ke(XO), lO, !1)
                                            }
                                          }
                                }
                                return bl
                              }().get(eO)) && void 0 !== KO ? KO : [],
                              vK = null !== (pO = function() {
                                if (!Xe) {
                                  Xe = new Map;
                                  const OO = HO("changelog");
                                  for (const KO of SO(OO).sections) {
                                    const pO = new Set(KO.blocks.flatMap((OO => [...ee(OO)])));
                                    for (const XO of pO) {
                                      const pO = {
                                        pageId: OO.id,
                                        anchor: KO.heading.anchor,
                                        label: KO.heading.text
                                      };
                                      vl(Xe, XO, pO, !0)
                                    }
                                  }
                                }
                                return Xe
                              }().get(eO)) && void 0 !== pO ? pO : [];
                            return 0 === lO.length && 0 === vK.length ? null : (0, FO.jsxs)("footer", {
                              className: "DocsCardFooter",
                              children: [lO.length > 0 && (0, FO.jsx)(al, {
                                title: "Used in",
                                references: lO
                              }), vK.length > 0 && (0, FO.jsx)(al, {
                                title: "Changelog",
                                references: vK
                              })]
                            })
                          }

                          function Fe(OO) {
                            let {
                              method: KO,
                              pageId: pO,
                              anchor: XO,
                              isCallback: bK
                            } = OO;
                            const eO = bK ? void 0 : vp().get(KO.name),
                              lO = KO.description.length > 0 || null === eO || void 0 === eO || !eO.description ? KO.description : (0, IO.B)(eO.description);
                            return (0, FO.jsxs)("article", {
                              className: "DocsCard DocsMethodCard",
                              children: [(0, FO.jsxs)("header", {
                                className: "DocsCardHeader",
                                children: [(0, FO.jsx)(hp, {
                                  level: 2,
                                  text: KO.name,
                                  anchor: XO,
                                  className: "DocsCardTitle"
                                }), (0, FO.jsx)(AO, {
                                  text: De(KO, bK),
                                  label: bK ? "Copy handler" : "Copy call",
                                  className: "DocsCardCopy"
                                })]
                              }), (0, FO.jsx)(Me, {
                                method: KO,
                                isCallback: bK
                              }), eO && null !== eO.deprecation && (0, FO.jsxs)("aside", {
                                className: "DocsCallout warning DocsDeprecation",
                                children: [(0, FO.jsx)("strong", {
                                  children: "Deprecated"
                                }), eO.deprecation && (0, FO.jsxs)(FO.Fragment, {
                                  children: [": ", (0, FO.jsx)(TK, {
                                    text: (vK = eO.deprecation, (0, te.z)(vK, /[a-z][\w$]*[A-Z][\w$]*\b/g, (0, te.o)("`\\w"), (OO => {
                                      let [KO] = OO;
                                      return MK().has(KO) ? `\`${KO}\`` : KO
                                    })))
                                  })]
                                })]
                              }), lO.length > 0 && (0, FO.jsx)("div", {
                                className: "DocsProse DocsCardBody",
                                children: (0, FO.jsx)(op, {
                                  blocks: lO
                                })
                              }), KO.params.length > 0 && (0, FO.jsxs)("section", {
                                className: "DocsCardPart",
                                children: [(0, FO.jsx)("h3", {
                                  className: "DocsCardPartTitle",
                                  children: "Parameters"
                                }), (0, FO.jsx)("dl", {
                                  className: "DocsParamList",
                                  children: KO.params.map((OO => (0, FO.jsxs)("div", {
                                    id: `${KO.name}-${he(OO)}`,
                                    className: "DocsParam",
                                    children: [(0, FO.jsxs)("dt", {
                                      children: [(0, FO.jsx)("code", {
                                        className: "DocsParamName",
                                        children: OO.name
                                      }), (0, FO.jsx)(yp, {
                                        type: OO.type
                                      })]
                                    }), OO.description && (0, FO.jsx)("dd", {
                                      children: (0, FO.jsx)(TK, {
                                        text: OO.description
                                      })
                                    })]
                                  }, OO.name)))
                                })]
                              }), KO.returns && (KO.returns.type || KO.returns.description.length > 0) && (0, FO.jsxs)("section", {
                                className: "DocsCardPart",
                                children: [(0, FO.jsx)("h3", {
                                  className: "DocsCardPartTitle",
                                  children: "Returns"
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsReturns",
                                  children: [KO.returns.type && (0, FO.jsx)(yp, {
                                    type: KO.returns.type
                                  }), KO.returns.description.length > 0 && (0, FO.jsx)("div", {
                                    className: "DocsProse",
                                    children: (0, FO.jsx)(op, {
                                      blocks: KO.returns.description
                                    })
                                  })]
                                })]
                              }), (0, FO.jsx)(oe, {
                                pageId: pO,
                                anchor: XO
                              })]
                            });
                            var vK
                          }

                          function Ve(OO) {
                            var KO;
                            return null !== OO.defaultValue && "undefined" !== OO.defaultValue ? OO.defaultValue : null !== (KO = OO.example) && void 0 !== KO ? KO : "value"
                          }

                          function Le(OO) {
                            let {
                              setting: KO,
                              pageId: pO,
                              anchor: XO,
                              setterSnippet: bK
                            } = OO;
                            const eO = null === KO.defaultValue ? null : QK(KO.defaultValue);
                            return (0, FO.jsxs)("article", {
                              className: "DocsCard DocsSettingCard",
                              children: [(0, FO.jsxs)("header", {
                                className: "DocsCardHeader",
                                children: [(0, FO.jsx)(hp, {
                                  level: 2,
                                  text: KO.name,
                                  anchor: XO,
                                  className: "DocsCardTitle"
                                }), (0, FO.jsx)(AO, {
                                  text: bK(KO.name, Ve(KO)),
                                  label: "Copy setter",
                                  className: "DocsCardCopy"
                                })]
                              }), (0, FO.jsxs)("dl", {
                                className: "DocsSettingFacts",
                                children: [(0, FO.jsxs)("div", {
                                  children: [(0, FO.jsx)("dt", {
                                    children: "Type"
                                  }), (0, FO.jsx)("dd", {
                                    children: (0, FO.jsx)(yp, {
                                      type: KO.type
                                    })
                                  })]
                                }), null !== KO.defaultValue && (0, FO.jsxs)("div", {
                                  children: [(0, FO.jsx)("dt", {
                                    children: "Default"
                                  }), (0, FO.jsx)("dd", {
                                    children: (0, FO.jsxs)("code", {
                                      className: "DocsInlineCode DocsDefaultValue",
                                      children: [eO && (0, FO.jsx)(zp, {
                                        colour: eO
                                      }), KO.defaultValue]
                                    })
                                  })]
                                }), null !== KO.example && (0, FO.jsxs)("div", {
                                  children: [(0, FO.jsx)("dt", {
                                    children: "Example"
                                  }), (0, FO.jsx)("dd", {
                                    children: (0, FO.jsx)("code", {
                                      className: "DocsInlineCode",
                                      children: KO.example
                                    })
                                  })]
                                })]
                              }), KO.description.length > 0 && (0, FO.jsx)("div", {
                                className: "DocsProse DocsCardBody",
                                children: (0, FO.jsx)(op, {
                                  blocks: KO.description
                                })
                              }), (0, FO.jsx)(oe, {
                                pageId: pO,
                                anchor: XO
                              })]
                            })
                          }

                          function Qe(OO) {
                            let {
                              section: KO
                            } = OO;
                            return (0, FO.jsxs)("article", {
                              className: "DocsCard DocsSnippetCard",
                              children: [(0, FO.jsx)(hp, {
                                level: 2,
                                text: KO.heading.text,
                                anchor: KO.heading.anchor,
                                className: "DocsCardTitle"
                              }), (0, FO.jsx)("div", {
                                className: "DocsProse",
                                children: (0, FO.jsx)(op, {
                                  blocks: KO.blocks
                                })
                              })]
                            })
                          }

                          function zl(OO) {
                            let {
                              section: KO
                            } = OO;
                            return (0, FO.jsxs)("section", {
                              className: "DocsProse DocsArticleSection",
                              children: [(0, FO.jsx)(hp, {
                                level: KO.heading.level,
                                text: KO.heading.text,
                                anchor: KO.heading.anchor
                              }), (0, FO.jsx)(op, {
                                blocks: KO.blocks
                              })]
                            })
                          }
                          const Ae = {
                            methods: "methods",
                            callbacks: "callbacks",
                            settings: "settings",
                            changelog: "updates",
                            snippets: "snippets",
                            article: "sections"
                          };

                          function fe(OO) {
                            let {
                              page: KO,
                              section: pO
                            } = OO;
                            if ("methods" === KO.layout || "callbacks" === KO.layout) return (0, FO.jsx)(Fe, {
                              method: Np(pO),
                              pageId: KO.id,
                              anchor: pO.heading.anchor,
                              isCallback: "callbacks" === KO.layout
                            });
                            if ("settings" === KO.layout) {
                              const OO = function(OO) {
                                const KO = {
                                  name: OO.heading.text,
                                  type: "",
                                  defaultValue: null,
                                  example: null,
                                  description: []
                                };
                                for (const XO of OO.blocks) {
                                  var pO;
                                  if (Tp(XO)) continue;
                                  const OO = "paragraph" === XO.kind ? XO.text.match(Ip) : null;
                                  if (!OO) {
                                    KO.description.push(XO);
                                    continue
                                  }
                                  const bK = null !== (pO = dp(OO[2])) && void 0 !== pO ? pO : OO[2];
                                  "Type" === OO[1] ? KO.type = bK : "Default" === OO[1] ? KO.defaultValue = bK : "" !== bK && (KO.example = bK)
                                }
                                return KO.type ? KO : null
                              }(pO);
                              if (OO) return (0, FO.jsx)(Le, {
                                setting: OO,
                                pageId: KO.id,
                                anchor: pO.heading.anchor,
                                setterSnippet: KO.setterSnippet
                              })
                            }
                            return "snippets" === KO.layout ? (0, FO.jsx)(Qe, {
                              section: pO
                            }) : "changelog" === KO.layout ? (0, FO.jsxs)("section", {
                              className: "DocsChangelogEntry",
                              children: [(0, FO.jsx)("div", {
                                className: "DocsChangelogDate",
                                children: (0, FO.jsx)(hp, {
                                  level: 2,
                                  text: pO.heading.text,
                                  anchor: pO.heading.anchor
                                })
                              }), (0, FO.jsx)("div", {
                                className: "DocsProse DocsChangelogBody",
                                children: (0, FO.jsx)(op, {
                                  blocks: yX(pO.blocks)
                                })
                              })]
                            }) : KO.gallery ? (0, FO.jsxs)("section", {
                              className: "DocsProse DocsArticleSection",
                              children: [(0, FO.jsx)(hp, {
                                level: pO.heading.level,
                                text: pO.heading.text,
                                anchor: pO.heading.anchor
                              }), (0, FO.jsx)(gb, {
                                kind: KO.gallery,
                                content: SO(KO),
                                blocks: pO.blocks
                              })]
                            }) : (0, FO.jsx)(zl, {
                              section: pO
                            })
                          }

                          function de(OO) {
                            let {
                              page: KO,
                              onTocChange: pO
                            } = OO;
                            const bK = SO(KO),
                              [eO, lO] = (0, XO.useState)(""),
                              vK = "article" !== KO.layout,
                              CO = Lp(KO.gallery) ? KO.gallery : null,
                              hO = null !== CO,
                              DO = eO.trim().toLowerCase(),
                              MO = (0, XO.useRef)(null),
                              aK = (0, XO.useCallback)((OO => {
                                var KO;
                                null === (KO = MO.current) || void 0 === KO || KO.preview(OO)
                              }), []),
                              oO = (0, XO.useMemo)((() => {
                                if (!KO.hasParticlePlayground) return [];
                                const OO = jX(bK.intro).find((OO => "names" === OO.kind && !OO.names.some((OO => null !== Rp(OO.name)))));
                                return "names" === (null === OO || void 0 === OO ? void 0 : OO.kind) ? OO.names.map((OO => OO.name)) : []
                              }), [KO, bK]),
                              VO = (0, XO.useMemo)((() => {
                                if (!KO.hasTextPlayground) return [];
                                const OO = bK.sections.flatMap((OO => OO.blocks.flatMap((OO => {
                                  var KO;
                                  return (null !== (KO = Ep(OO)) && void 0 !== KO ? KO : []).flatMap((OO => RK(OO.name) ? [OO.name] : []))
                                }))));
                                return [...new Set(OO)]
                              }), [KO, bK]),
                              LO = (0, XO.useMemo)((() => DO ? bK.sections.filter((OO => function(OO, KO) {
                                return !!OO.heading.text.toLowerCase().includes(KO) || OO.blocks.some((OO => (0, IO.i)(OO).toLowerCase().includes(KO)))
                              }(OO, DO))) : bK.sections), [bK, DO]),
                              QO = (0, XO.useMemo)((() => function(OO, KO) {
                                return "article" !== OO.layout ? KO.map((OO => ({
                                  anchor: OO.heading.anchor,
                                  text: OO.heading.text,
                                  level: 2
                                }))) : KO.flatMap((OO => {
                                  const KO = OO.blocks.flatMap((OO => "heading" === OO.kind && 3 === OO.level ? [{
                                    anchor: OO.anchor,
                                    text: OO.text,
                                    level: 3
                                  }] : []));
                                  return [{
                                    anchor: OO.heading.anchor,
                                    text: OO.heading.text,
                                    level: 2
                                  }, ...KO]
                                }))
                              }(KO, LO)), [KO, LO]);
                            return (0, XO.useEffect)((() => {
                              pO(QO)
                            }), [QO, pO]), (0, FO.jsxs)("article", {
                              className: "DocsPage",
                              children: [(0, FO.jsxs)("header", {
                                className: "DocsPageHeader",
                                children: [(0, FO.jsx)("h1", {
                                  className: "DocsPageTitle",
                                  children: bK.title || KO.title
                                }), (0, FO.jsx)("p", {
                                  className: "DocsPageSummary",
                                  children: KO.summary
                                }), (0, FO.jsx)(xb, {
                                  page: KO
                                }), vK && (0, FO.jsx)("div", {
                                  className: "DocsPageStats",
                                  children: (0, FO.jsxs)("span", {
                                    children: [(0, FO.jsx)("strong", {
                                      children: bK.sections.length
                                    }), " ", Ae[KO.layout]]
                                  })
                                })]
                              }), "" === KO.slug && (0, FO.jsx)(EX, {}), CO && (0, FO.jsx)(ib, {
                                kind: CO
                              }, CO), KO.hasParticlePlayground && (0, FO.jsx)(ve, {
                                ref: MO,
                                textures: oO
                              }), !hO && bK.intro.length > 0 && (0, FO.jsx)("div", {
                                className: "DocsProse DocsPageIntro",
                                children: KO.gallery ? (0, FO.jsx)(QX.Provider, {
                                  value: KO.hasParticlePlayground ? aK : null,
                                  children: (0, FO.jsx)(gb, {
                                    kind: KO.gallery,
                                    content: bK,
                                    blocks: bK.intro
                                  })
                                }) : (0, FO.jsx)(op, {
                                  blocks: yX(bK.intro)
                                })
                              }), KO.hasTextPlayground && (0, FO.jsx)(Nb, {
                                fontAwesomeIcons: VO
                              }), KO.hasVoicePlayground && (0, FO.jsx)(Wb, {}), KO.childPageIds && (0, FO.jsx)(EX, {
                                cards: KO.childPageIds.map((OO => ({
                                  pageId: OO
                                }))),
                                label: KO.title
                              }), vK && (0, FO.jsx)(Ap, {
                                className: "DocsFilterBar",
                                value: eO,
                                placeholder: `Filter ${bK.sections.length} ${Ae[KO.layout]}\u2026`,
                                label: `Filter ${Ae[KO.layout]}`,
                                onChange: lO,
                                count: DO ? {
                                  visible: LO.length,
                                  total: bK.sections.length
                                } : null
                              }), !hO && (0, FO.jsxs)("div", {
                                className: `DocsSections Layout-${KO.layout}`,
                                children: [LO.map((OO => (0, FO.jsx)(fe, {
                                  page: KO,
                                  section: OO
                                }, OO.heading.anchor))), 0 === LO.length && (0, FO.jsxs)("p", {
                                  className: "DocsEmpty",
                                  children: ["No ", Ae[KO.layout], " match \u201c", eO, "\u201d."]
                                })]
                              })]
                            })
                          }
                          const Te = /^(\d+)(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(\d{4})$/;

                          function Ne(OO) {
                            let {
                              entry: KO,
                              isActive: pO,
                              onNavigate: XO,
                              label: bK,
                              children: lO
                            } = OO;
                            return (0, FO.jsx)("a", {
                              href: `#${KO.anchor}`,
                              "aria-label": bK,
                              className: eO()(`Level${KO.level}`, {
                                Active: pO
                              }),
                              "aria-current": pO ? "location" : void 0,
                              onClick: OO => {
                                OO.preventDefault(), XO(KO.anchor)
                              },
                              children: lO
                            })
                          }

                          function Ie(OO) {
                            let {
                              toc: KO,
                              activeAnchor: pO,
                              onNavigate: bK
                            } = OO;
                            const lO = Math.max(0, KO.findIndex((OO => OO.anchor === pO))),
                              vK = (0, XO.useRef)(null),
                              CO = (0, XO.useRef)(!1);
                            (0, XO.useEffect)((() => {
                              var OO, pO;
                              const XO = null === (OO = vK.current) || void 0 === OO ? void 0 : OO.closest(".DocsToc"),
                                bK = null === (pO = vK.current) || void 0 === pO ? void 0 : pO.querySelector(".DocsTimelineNotch.Active");
                              if (!XO || !bK) return;
                              let eO = 0;
                              if (lO === KO.length - 1) eO = XO.scrollHeight;
                              else if (lO > 0) {
                                const OO = XO.getBoundingClientRect(),
                                  KO = bK.getBoundingClientRect();
                                eO = XO.scrollTop + KO.top + KO.height / 2 - (OO.top + XO.clientHeight / 2)
                              }
                              XO.scrollTo({
                                top: eO,
                                behavior: CO.current ? "smooth" : "auto"
                              }), CO.current = !0
                            }), [lO, KO.length]);
                            const hO = [];
                            return KO.forEach(((OO, KO) => {
                              var pO, XO, bK;
                              const eO = function(OO) {
                                  const KO = OO.trim().match(Te);
                                  return KO ? {
                                    day: KO[1],
                                    month: `${KO[2]} ${KO[3]}`
                                  } : null
                                }(OO.text),
                                lO = null !== (pO = null === eO || void 0 === eO ? void 0 : eO.month) && void 0 !== pO ? pO : null;
                              null !== lO && (null === (XO = hO.at(-1)) || void 0 === XO ? void 0 : XO.month) === lO || hO.push({
                                month: lO,
                                entries: []
                              }), hO.at(-1).entries.push({
                                entry: OO,
                                day: null !== (bK = null === eO || void 0 === eO ? void 0 : eO.day) && void 0 !== bK ? bK : null,
                                index: KO
                              })
                            })), (0, FO.jsx)("ol", {
                              ref: vK,
                              className: "DocsTimeline",
                              children: hO.map((OO => {
                                let {
                                  month: KO,
                                  entries: pO
                                } = OO;
                                return (0, FO.jsxs)("li", {
                                  className: "DocsTimelineMonth",
                                  children: [KO && (0, FO.jsx)("span", {
                                    className: "DocsTimelineMonthName",
                                    children: KO
                                  }), (0, FO.jsx)("ol", {
                                    children: pO.map((OO => {
                                      let {
                                        entry: KO,
                                        day: pO,
                                        index: XO
                                      } = OO;
                                      return (0, FO.jsx)("li", {
                                        className: eO()("DocsTimelineNotch", {
                                          Passed: XO < lO,
                                          Active: XO === lO
                                        }),
                                        children: (0, FO.jsx)(Ne, {
                                          entry: KO,
                                          isActive: XO === lO,
                                          onNavigate: bK,
                                          label: KO.text,
                                          children: (0, FO.jsx)("span", {
                                            className: "DocsTimelineDay",
                                            children: null !== pO && void 0 !== pO ? pO : KO.text
                                          })
                                        })
                                      }, KO.anchor)
                                    }))
                                  })]
                                }, pO[0].entry.anchor)
                              }))
                            })
                          }

                          function yl(OO) {
                            let {
                              isChangelog: KO,
                              toc: pO,
                              activeAnchor: XO,
                              onNavigate: bK
                            } = OO;
                            return 0 === pO.length ? null : (0, FO.jsxs)(FO.Fragment, {
                              children: [(0, FO.jsx)("div", {
                                className: "DocsTocTitle",
                                children: KO ? "Updates" : "On this page"
                              }), KO ? (0, FO.jsx)(Ie, {
                                toc: pO,
                                activeAnchor: XO,
                                onNavigate: bK
                              }) : (0, FO.jsx)("ul", {
                                children: pO.map((OO => (0, FO.jsx)("li", {
                                  children: (0, FO.jsx)(Ne, {
                                    entry: OO,
                                    isActive: OO.anchor === XO,
                                    onNavigate: bK,
                                    children: OO.text.replace(/`/g, "")
                                  })
                                }, OO.anchor)))
                              })]
                            })
                          }
                          const gl = {
                              methods: "Method",
                              callbacks: "Callback",
                              settings: "Setting",
                              changelog: "Update",
                              snippets: "Snippet",
                              article: "Section"
                            },
                            ue = {
                              icons: "Icon",
                              particles: "Particle",
                              sounds: "Sound",
                              skins: "Skin",
                              blocks: "Block",
                              items: "Item"
                            },
                            Ee = 20,
                            jl = 10,
                            Ye = 40,
                            we = 120;
                          let il;

                          function rl(OO) {
                            const KO = OO.gallery;
                            if (!KO) return [];
                            if (Lp(KO)) return function(OO) {
                              return zX(OO).entries.map((OO => OO.name))
                            }(KO).map((pO => ({
                              page: OO,
                              anchor: wp(KO, pO),
                              title: pO,
                              kind: ue[KO],
                              text: "",
                              listedUnder: OO.title
                            })));
                            const pO = SO(OO);
                            return (0, IO.x)(pO).flatMap((XO => {
                              const bK = XO.heading ? `${OO.title} \u203a ${XO.heading.text.replace(/\s*\(\d+[^)]*\)$/,"")}` : OO.title;
                              return rX(KO, pO, XO.blocks).flatMap((pO => "names" !== pO.kind ? [] : pO.names.map((XO => {
                                const eO = pO.isSongs ? "Song" : ue[KO];
                                return {
                                  page: OO,
                                  anchor: XO.anchor,
                                  title: XO.name,
                                  kind: eO,
                                  text: "",
                                  listedUnder: bK
                                }
                              }))))
                            }))
                          }

                          function Pe(OO, KO, pO) {
                            const XO = OO.title.toLowerCase();
                            let bK = 0;
                            if (XO === KO) bK = 100;
                            else if (XO.startsWith(KO)) bK = 80;
                            else if (XO.includes(KO)) bK = 60;
                            else if (pO.every((OO => XO.includes(OO)))) bK = 45;
                            else {
                              if (!OO.text.toLowerCase().includes(KO)) return 0;
                              bK = 20
                            }
                            return bK - Math.min(XO.length / 10, 9) + ("Page" === OO.kind ? 8 : "Method" === OO.kind ? 3 : 0) - (OO.listedUnder ? Ee : 0)
                          }

                          function ml(OO, KO) {
                            const pO = OO.toLowerCase().indexOf(KO),
                              XO = Math.max(0, pO - we / 3);
                            return `${XO>0?"\u2026":""}${OO.slice(XO,XO+we)}${XO+we<OO.length?"\u2026":""}`
                          }

                          function se(OO) {
                            let {
                              text: KO,
                              query: pO
                            } = OO;
                            const XO = pO ? KO.toLowerCase().indexOf(pO) : -1;
                            return -1 === XO ? (0, FO.jsx)(FO.Fragment, {
                              children: KO
                            }) : (0, FO.jsxs)(FO.Fragment, {
                              children: [KO.slice(0, XO), (0, FO.jsx)("mark", {
                                children: KO.slice(XO, XO + pO.length)
                              }), KO.slice(XO + pO.length)]
                            })
                          }

                          function He(OO) {
                            let {
                              basePath: KO,
                              onClose: pO
                            } = OO;
                            const bK = (0, vK.s)(),
                              [lO, CO] = (0, XO.useState)(""),
                              [hO, DO] = (0, XO.useState)(0),
                              MO = (0, XO.useRef)(null),
                              aK = (0, XO.useRef)(null),
                              oO = lO.trim().toLowerCase(),
                              VO = (0, XO.useMemo)((() => {
                                const OO = (il || (il = mK.flatMap((OO => {
                                  const KO = SO(OO);
                                  return [{
                                    page: OO,
                                    anchor: "",
                                    title: OO.title,
                                    kind: "Page",
                                    text: OO.summary
                                  }, ...KO.sections.flatMap((KO => {
                                    const pO = KO.blocks.filter((OO => "paragraph" === OO.kind)).map(IO.i).join(" ").replace(/[`*]/g, ""),
                                      XO = {
                                        page: OO,
                                        anchor: KO.heading.anchor,
                                        title: KO.heading.text.replace(/`/g, ""),
                                        kind: gl[OO.layout],
                                        text: pO
                                      },
                                      bK = KO.blocks.flatMap((KO => "article" === OO.layout && "heading" === KO.kind && 3 === KO.level ? [{
                                        page: OO,
                                        anchor: KO.anchor,
                                        title: KO.text.replace(/`/g, ""),
                                        kind: "Section",
                                        text: XO.title
                                      }] : []));
                                    return [XO, ...bK]
                                  })), ...rl(OO)]
                                }))), il);
                                if (!oO) return OO.filter((OO => "Page" === OO.kind));
                                const KO = oO.split(/\s+/);
                                let pO = 0;
                                return OO.map((OO => ({
                                  entry: OO,
                                  score: Pe(OO, oO, KO)
                                }))).filter((OO => OO.score > 0)).sort(((OO, KO) => KO.score - OO.score)).filter((OO => !OO.entry.listedUnder || (pO++, pO <= jl))).slice(0, Ye).map((OO => OO.entry))
                              }), [oO]);
                            (0, XO.useEffect)((() => {
                              DO(0)
                            }), [oO]), (0, XO.useEffect)((() => {
                              const OO = document.activeElement instanceof HTMLElement ? document.activeElement : null;
                              return () => {
                                null === OO || void 0 === OO || OO.focus()
                              }
                            }), []), (0, XO.useEffect)((() => {
                              var OO, KO;
                              null === (OO = MO.current) || void 0 === OO || null === (KO = OO.querySelector(".Active")) || void 0 === KO || KO.scrollIntoView({
                                block: "nearest"
                              })
                            }), [hO]);
                            const QO = OO => {
                              bK(ZO(KO, OO.page, OO.anchor)), pO()
                            };
                            return (0, FO.jsx)("div", {
                              className: "DocsSearchOverlay",
                              onMouseDown: OO => {
                                OO.target === OO.currentTarget && pO()
                              },
                              children: (0, FO.jsxs)("div", {
                                className: "DocsSearchDialog",
                                role: "dialog",
                                "aria-modal": "true",
                                "aria-label": "Search the docs",
                                onMouseDown: OO => {
                                  OO.target !== aK.current && OO.preventDefault()
                                },
                                onKeyDown: OO => {
                                  if ("Escape" === OO.key) pO();
                                  else if ("Tab" === OO.key) {
                                    var KO;
                                    OO.preventDefault(), null === (KO = aK.current) || void 0 === KO || KO.focus()
                                  }
                                },
                                children: [(0, FO.jsxs)("div", {
                                  className: "DocsSearchInputRow",
                                  children: [(0, FO.jsx)(LO, {
                                    name: "magnifying-glass"
                                  }), (0, FO.jsx)("input", {
                                    ref: aK,
                                    autoFocus: !0,
                                    value: lO,
                                    placeholder: "Search methods, callbacks, settings and guides\u2026",
                                    "aria-label": "Search the docs",
                                    "aria-controls": "DocsSearchResults",
                                    "aria-activedescendant": VO.length > 0 ? `DocsSearchResult-${hO}` : void 0,
                                    onChange: OO => {
                                      CO(OO.target.value)
                                    },
                                    onKeyDown: OO => {
                                      if ("ArrowDown" === OO.key || "ArrowUp" === OO.key) {
                                        OO.preventDefault();
                                        const KO = "ArrowDown" === OO.key ? 1 : -1;
                                        DO((hO + KO + VO.length) % Math.max(VO.length, 1))
                                      } else "Enter" === OO.key && VO[hO] && QO(VO[hO])
                                    }
                                  }), (0, FO.jsx)("kbd", {
                                    children: "Esc"
                                  })]
                                }), (0, FO.jsxs)("ul", {
                                  id: "DocsSearchResults",
                                  ref: MO,
                                  className: "DocsSearchResults",
                                  role: "listbox",
                                  children: [!oO && (0, FO.jsx)("li", {
                                    className: "DocsSearchHint",
                                    children: "Jump to a page"
                                  }), VO.map(((OO, KO) => {
                                    var pO;
                                    return (0, FO.jsxs)("li", {
                                      id: `DocsSearchResult-${KO}`,
                                      role: "option",
                                      "aria-selected": KO === hO,
                                      className: eO()("DocsSearchResult", {
                                        Active: KO === hO
                                      }),
                                      onMouseMove: () => {
                                        DO(KO)
                                      },
                                      onClick: () => {
                                        QO(OO)
                                      },
                                      children: [(0, FO.jsx)(LO, {
                                        name: OO.page.icon
                                      }), (0, FO.jsxs)("div", {
                                        className: "DocsSearchResultText",
                                        children: [(0, FO.jsx)("div", {
                                          className: "DocsSearchResultTitle",
                                          children: (0, FO.jsx)(se, {
                                            text: OO.title,
                                            query: oO
                                          })
                                        }), OO.text && (0, FO.jsx)("div", {
                                          className: "DocsSearchResultSnippet",
                                          children: (0, FO.jsx)(se, {
                                            text: ml(OO.text, oO),
                                            query: oO
                                          })
                                        })]
                                      }), (0, FO.jsx)("span", {
                                        className: "DocsSearchResultMeta",
                                        children: "Page" === OO.kind ? "Page" : null !== (pO = OO.listedUnder) && void 0 !== pO ? pO : `${OO.kind} \xb7 ${OO.page.title}`
                                      })]
                                    }, `${OO.page.id}#${OO.anchor}`)
                                  })), oO && 0 === VO.length && (0, FO.jsxs)("li", {
                                    className: "DocsSearchHint",
                                    children: ["Nothing matches \u201c", lO, "\u201d."]
                                  })]
                                })]
                              })
                            })
                          }

                          function Re(OO, KO) {
                            if (KO < 10) return `${OO.toFixed(1)}s`;
                            const pO = Math.floor(OO);
                            return `${Math.floor(pO/60)}:${String(pO%60).padStart(2,"0")}`
                          }

                          function Se() {
                            const OO = DX((OO => OO.track)),
                              KO = DX((OO => OO.volume)),
                              [pO, bK] = (0, XO.useState)(0),
                              lO = (0, XO.useRef)(KX);
                            if ((0, XO.useEffect)((() => {
                                if (!OO) return;
                                if (bK(FX()), "playing" !== OO.status) return;
                                let KO = 0;
                                const pO = () => {
                                  bK(FX()), KO = requestAnimationFrame(pO)
                                };
                                return KO = requestAnimationFrame(pO), () => {
                                  cancelAnimationFrame(KO)
                                }
                              }), [OO]), !OO) return null;
                            const vK = "paused" !== OO.status,
                              CO = Math.min(pO, OO.duration);
                            return (0, FO.jsx)("div", {
                              className: "DocsSoundPlayerDock",
                              children: (0, FO.jsxs)("section", {
                                className: "DocsSoundPlayer",
                                "aria-label": "Sound player",
                                children: [(0, FO.jsx)("button", {
                                  type: "button",
                                  className: "DocsSoundPlayerToggle",
                                  "aria-label": vK ? `Pause ${OO.name}` : `Play ${OO.name}`,
                                  onClick: oX,
                                  children: (0, FO.jsx)(LO, {
                                    name: vK ? "pause" : "play"
                                  })
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsSoundPlayerTrack",
                                  children: [(0, FO.jsxs)("div", {
                                    className: "DocsSoundPlayerTitle",
                                    children: [(0, FO.jsx)("code", {
                                      children: OO.name
                                    }), (0, FO.jsx)("span", {
                                      children: OO.isSong ? "Song" : "Sound"
                                    })]
                                  }), (0, FO.jsxs)("div", {
                                    className: "DocsSoundPlayerScrubber",
                                    children: [(0, FO.jsx)("span", {
                                      children: Re(CO, OO.duration)
                                    }), (0, FO.jsx)("input", {
                                      type: "range",
                                      min: 0,
                                      max: OO.duration || 1,
                                      step: .01,
                                      value: CO,
                                      disabled: 0 === OO.duration,
                                      "aria-label": "Position",
                                      "aria-valuetext": `${Re(CO,OO.duration)} of ${Re(OO.duration,OO.duration)}`,
                                      onChange: OO => {
                                        const KO = Number(OO.target.value);
                                        ! function(OO) {
                                          var KO;
                                          lX = OO, null === (KO = bb) || void 0 === KO || KO.seek(OO)
                                        }(KO), bK(KO)
                                      }
                                    }), (0, FO.jsx)("span", {
                                      children: OO.duration > 0 ? Re(OO.duration, OO.duration) : "\u2013"
                                    })]
                                  })]
                                }), (0, FO.jsxs)("div", {
                                  className: "DocsSoundPlayerVolume",
                                  children: [(0, FO.jsx)("button", {
                                    type: "button",
                                    "aria-label": 0 === KO ? "Unmute" : "Mute",
                                    onClick: () => {
                                      0 === KO ? VX(lO.current) : (lO.current = KO, VX(0))
                                    },
                                    children: (0, FO.jsx)(LO, {
                                      name: "volume",
                                      className: eO()({
                                        Muted: 0 === KO
                                      })
                                    })
                                  }), (0, FO.jsx)("input", {
                                    type: "range",
                                    min: 0,
                                    max: 1,
                                    step: .01,
                                    value: KO,
                                    "aria-label": "Volume",
                                    onChange: OO => {
                                      VX(Number(OO.target.value))
                                    }
                                  })]
                                }), (0, FO.jsx)("button", {
                                  type: "button",
                                  className: "DocsSoundPlayerClose",
                                  "aria-label": "Close the player",
                                  onClick: () => {
                                    var KO;
                                    null === (KO = document.querySelector(`[data-docs-track="${CSS.escape(pX(OO.name,OO.isSong))}"]`)) || void 0 === KO || KO.focus(), LX()
                                  },
                                  children: (0, FO.jsx)(LO, {
                                    name: "cross"
                                  })
                                })]
                              })
                            })
                          }
                          var Je = pO(36);
                          const cl = "docsTheme",
                            Be = window.matchMedia("(prefers-color-scheme: light)");

                          function Ze(OO) {
                            let {
                              theme: KO,
                              onChange: pO
                            } = OO;
                            const XO = "dark" === KO ? "light" : "dark";
                            return (0, FO.jsx)("button", {
                              type: "button",
                              className: "DocsIconButton DocsThemeToggle",
                              "aria-label": `Switch to ${XO} theme`,
                              title: `Switch to ${XO} theme`,
                              onClick: () => {
                                pO(XO)
                              },
                              children: (0, FO.jsx)(LO, {
                                name: "dark" === KO ? "moon" : "sun"
                              })
                            })
                          }
                          const Ge = "https://github.com/Bloxdy/code-api",
                            ql = "https://discord.gg/playbloxd",
                            xl = 180,
                            ne = /Mac|iPhone|iPad/.test(navigator.userAgent);

                          function We(OO) {
                            let {
                              basePath: KO,
                              activePageId: pO,
                              onNavigate: XO
                            } = OO;
                            return (0, FO.jsx)("nav", {
                              className: "DocsNav",
                              "aria-label": "Documentation",
                              children: sO.map((OO => (0, FO.jsxs)("div", {
                                className: "DocsNavGroup",
                                children: [(0, FO.jsx)("div", {
                                  className: "DocsNavGroupTitle",
                                  children: OO.title
                                }), OO.pageIds.map((OO => {
                                  var bK;
                                  const vK = HO(OO);
                                  return (0, FO.jsxs)(lO.c, {
                                    to: ZO(KO, vK),
                                    className: eO()("DocsNavLink", {
                                      Active: vK.id === pO
                                    }),
                                    "aria-current": vK.id === pO ? "page" : void 0,
                                    onClick: XO,
                                    children: [(0, FO.jsx)(LO, {
                                      name: vK.icon
                                    }), (0, FO.jsx)("span", {
                                      children: null !== (bK = vK.navTitle) && void 0 !== bK ? bK : vK.title
                                    })]
                                  }, vK.id)
                                }))]
                              }, OO.title)))
                            })
                          }

                          function tl(OO) {
                            let {
                              basePath: KO,
                              pageId: pO
                            } = OO;
                            const XO = sO.flatMap((OO => OO.pageIds)),
                              bK = XO.indexOf(pO),
                              eO = bK > 0 ? HO(XO[bK - 1]) : null,
                              vK = bK < XO.length - 1 ? HO(XO[bK + 1]) : null;
                            return (0, FO.jsxs)("nav", {
                              className: "DocsPager",
                              "aria-label": "Pages",
                              children: [eO ? (0, FO.jsxs)(lO.c, {
                                className: "DocsPagerLink Previous",
                                to: ZO(KO, eO),
                                children: [(0, FO.jsx)("span", {
                                  className: "DocsPagerLabel",
                                  children: "Previous"
                                }), (0, FO.jsx)("span", {
                                  className: "DocsPagerTitle",
                                  children: eO.title
                                })]
                              }) : (0, FO.jsx)("span", {}), vK && (0, FO.jsxs)(lO.c, {
                                className: "DocsPagerLink Next",
                                to: ZO(KO, vK),
                                children: [(0, FO.jsx)("span", {
                                  className: "DocsPagerLabel",
                                  children: "Next"
                                }), (0, FO.jsx)("span", {
                                  className: "DocsPagerTitle",
                                  children: vK.title
                                })]
                              })]
                            })
                          }

                          function kl(OO) {
                            let {
                              basePath: KO,
                              embedded: pO = !1
                            } = OO;
                            const {
                              pageSlug: bK = ""
                            } = (0, vK.w)(), hO = (0, vK.p)(), DO = (0, vK.s)(), MO = (aK = bK, mK.find((OO => OO.slug === aK)));
                            var aK;
                            const [oO, VO] = function() {
                              const [OO, KO] = (0, XO.useState)((() => {
                                const OO = Je.e.getItem(cl);
                                return "dark" === OO || "light" === OO ? OO : null
                              })), [pO, bK] = (0, XO.useState)(Be.matches ? "light" : "dark");
                              return (0, XO.useEffect)((() => {
                                const OO = () => {
                                  bK(Be.matches ? "light" : "dark")
                                };
                                return Be.addEventListener("change", OO), () => {
                                  Be.removeEventListener("change", OO)
                                }
                              }), []), [null !== OO && void 0 !== OO ? OO : pO, OO => {
                                Je.e.setItem(cl, OO), KO(OO)
                              }]
                            }(), [QO, zK] = (0, XO.useState)(null), [AO, fO] = (0, XO.useState)(!1), [dO, TO] = (0, XO.useState)(!1), [NO, yK] = (0, XO.useState)([]), gK = function(OO, KO) {
                              const [pO, bK] = (0, XO.useState)("");
                              return (0, XO.useEffect)((() => {
                                if (!KO) return;
                                let pO = 0;
                                const XO = () => {
                                    var XO, eO;
                                    pO = 0;
                                    const lO = KO.getBoundingClientRect().top + xl;
                                    let vK = null !== (XO = null === (eO = OO[0]) || void 0 === eO ? void 0 : eO.anchor) && void 0 !== XO ? XO : "";
                                    for (const KO of OO) {
                                      const OO = document.getElementById(KO.anchor);
                                      OO && OO.getBoundingClientRect().top <= lO && (vK = KO.anchor)
                                    }
                                    KO.scrollTop + KO.clientHeight >= KO.scrollHeight - 2 && KO.scrollTop > 0 && OO.length > 0 && (vK = OO[OO.length - 1].anchor), bK(vK)
                                  },
                                  eO = () => {
                                    pO || (pO = requestAnimationFrame(XO))
                                  };
                                return XO(), KO.addEventListener("scroll", eO, {
                                  passive: !0
                                }), () => {
                                  cancelAnimationFrame(pO), KO.removeEventListener("scroll", eO)
                                }
                              }), [OO, KO]), pO
                            }(NO, QO), uO = "" === bK && hO.hash ? function(OO) {
                              const KO = (0, IO.s)(OO);
                              if (JO(HO("welcome"), KO)) return null;
                              const pO = Object.hasOwn(BO, KO) ? BO[KO] : null;
                              if (pO) return {
                                page: HO(pO.pageId),
                                anchor: pO.anchor
                              };
                              const XO = HO("readme");
                              return JO(XO, KO) ? {
                                page: XO,
                                anchor: KO
                              } : cK(`#${KO}`)
                            }(hO.hash) : null;
                            (0, XO.useEffect)((() => (CO.d.set({
                              musicOnFromPage: !1
                            }), () => {
                              CO.d.set({
                                musicOnFromPage: !0
                              }), LX()
                            })), []), (0, XO.useEffect)((() => {
                              const OO = OO => {
                                const KO = OO.target;
                                if (KO.closest(".DocsTextDialog")) return;
                                const pO = KO.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(KO.tagName);
                                "k" === OO.key && (OO.metaKey || OO.ctrlKey) || "/" === OO.key && !pO ? (OO.preventDefault(), TO(!0)) : "Escape" === OO.key && fO(!1)
                              };
                              return window.addEventListener("keydown", OO), () => {
                                window.removeEventListener("keydown", OO)
                              }
                            }), []);
                            const EO = (0, XO.useRef)(null);
                            (0, XO.useLayoutEffect)((() => {
                              var OO, KO;
                              if (!QO) return;
                              const pO = EO.current === hO.pathname;
                              EO.current = hO.pathname;
                              const XO = (0, IO.s)(hO.hash),
                                bK = XO ? document.getElementById(XO) : null;
                              if (null === (OO = QO.querySelector(".DocsTargeted")) || void 0 === OO || OO.classList.remove("DocsTargeted"), null === bK || void 0 === bK || null === (KO = bK.closest(".DocsCard, .DocsParam, .DocsTile, .DocsSoundTile")) || void 0 === KO || KO.classList.add("DocsTargeted"), bK) {
                                var eO;
                                const OO = bK.matches(".DocsTile, .DocsSoundTile, .DocsCatalogueTile");
                                (null !== (eO = bK.closest(".DocsChangelogEntry")) && void 0 !== eO ? eO : bK).scrollIntoView({
                                  block: OO ? "center" : "start",
                                  behavior: pO ? "smooth" : "auto"
                                })
                              } else pO || QO.scrollTo({
                                top: 0
                              })
                            }), [QO, hO.pathname, hO.hash, hO.key]);
                            const jK = (0, XO.useCallback)((() => {
                                fO(!1)
                              }), []),
                              YO = (0, XO.useCallback)((OO => {
                                DO({
                                  hash: OO
                                })
                              }), [DO]);
                            if (uO) return (0, FO.jsx)(vK.d, {
                              replace: !0,
                              to: ZO(KO, uO.page, uO.anchor)
                            });
                            if (!MO) return (0, FO.jsx)(vK.d, {
                              replace: !0,
                              to: KO
                            });
                            const wO = pO ? "div" : "main";
                            return (0, FO.jsx)(oK.Provider, {
                              value: KO,
                              children: (0, FO.jsx)(FK.Provider, {
                                value: QO,
                                children: (0, FO.jsxs)("div", {
                                  ref: zK,
                                  className: eO()("DocsSite", {
                                    Embedded: pO,
                                    NavOpen: AO
                                  }),
                                  "data-theme": oO,
                                  children: [(0, FO.jsxs)("header", {
                                    className: "DocsTopBar",
                                    children: [(0, FO.jsx)("button", {
                                      type: "button",
                                      className: "DocsIconButton DocsMenuButton",
                                      "aria-label": AO ? "Close menu" : "Open menu",
                                      "aria-expanded": AO,
                                      onClick: () => {
                                        fO(!AO)
                                      },
                                      children: (0, FO.jsx)(LO, {
                                        name: AO ? "cross" : "menu"
                                      })
                                    }), (0, FO.jsxs)(lO.c, {
                                      to: KO,
                                      className: "DocsBrand",
                                      children: [(0, FO.jsx)("img", {
                                        src: "/favicon.svg",
                                        alt: "",
                                        width: 28,
                                        height: 28
                                      }), (0, FO.jsx)("span", {
                                        className: "DocsBrandName",
                                        children: "Bloxd"
                                      }), (0, FO.jsx)("span", {
                                        className: "DocsBrandTag",
                                        children: "Code API"
                                      })]
                                    }), (0, FO.jsxs)("button", {
                                      type: "button",
                                      className: "DocsSearchTrigger",
                                      onClick: () => {
                                        TO(!0)
                                      },
                                      children: [(0, FO.jsx)(LO, {
                                        name: "magnifying-glass"
                                      }), (0, FO.jsx)("span", {
                                        className: "DocsSearchTriggerLabel",
                                        children: "Search docs"
                                      }), (0, FO.jsxs)("kbd", {
                                        children: [ne ? "\u2318" : "Ctrl", " K"]
                                      })]
                                    }), (0, FO.jsxs)("div", {
                                      className: "DocsTopBarLinks",
                                      children: [(0, FO.jsxs)("a", {
                                        href: ql,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "DocsTopBarLink",
                                        children: [(0, FO.jsx)(LO, {
                                          name: "discord"
                                        }), (0, FO.jsx)("span", {
                                          children: "Discord"
                                        })]
                                      }), (0, FO.jsxs)("a", {
                                        href: Ge,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "DocsTopBarLink",
                                        children: [(0, FO.jsx)(LO, {
                                          name: "external-link"
                                        }), (0, FO.jsx)("span", {
                                          children: "GitHub"
                                        })]
                                      }), !pO && (0, FO.jsxs)(lO.c, {
                                        to: "/",
                                        className: "DocsTopBarLink DocsPlayLink",
                                        children: [(0, FO.jsx)(LO, {
                                          name: "play"
                                        }), (0, FO.jsx)("span", {
                                          children: "Play Bloxd"
                                        })]
                                      }), (0, FO.jsx)(Ze, {
                                        theme: oO,
                                        onChange: VO
                                      })]
                                    })]
                                  }), (0, FO.jsxs)("div", {
                                    className: "DocsSiteBody",
                                    children: [(0, FO.jsx)("aside", {
                                      className: "DocsSidebar",
                                      children: (0, FO.jsx)(We, {
                                        basePath: KO,
                                        activePageId: MO.id,
                                        onNavigate: jK
                                      })
                                    }), (0, FO.jsx)("div", {
                                      className: "DocsNavScrim",
                                      onClick: jK
                                    }), (0, FO.jsxs)(wO, {
                                      className: "DocsMain",
                                      children: [(0, FO.jsx)(de, {
                                        page: MO,
                                        onTocChange: yK
                                      }, MO.id), (0, FO.jsx)(tl, {
                                        basePath: KO,
                                        pageId: MO.id
                                      })]
                                    }), (0, FO.jsx)("aside", {
                                      className: eO()("DocsToc", {
                                        Timeline: "changelog" === MO.layout
                                      }),
                                      "aria-label": "On this page",
                                      children: (0, FO.jsx)(yl, {
                                        isChangelog: "changelog" === MO.layout,
                                        toc: NO,
                                        activeAnchor: gK,
                                        onNavigate: YO
                                      })
                                    })]
                                  }), (0, FO.jsx)(Se, {}), dO && (0, FO.jsx)(He, {
                                    basePath: KO,
                                    onClose: () => {
                                      TO(!1)
                                    }
                                  })]
                                })
                              })
                            })
                          }
                        }, 3887: (OO, KO, pO) => {
                          pO.d(KO, {
                            B: () => aK,
                            c: () => XO,
                            e: () => lO,
                            i: () => LO,
                            k: () => VO,
                            o: () => vK,
                            s: () => bK,
                            u: () => eO,
                            x: () => FO,
                            y: () => oO
                          });
                          const XO = /\[([^\]]+)\]\((#[^)]+|[^)\s]+)\)/g;

                          function bK(OO) {
                            try {
                              return decodeURIComponent(OO.slice(1))
                            } catch {
                              return OO.slice(1)
                            }
                          }

                          function eO(OO) {
                            return OO.replace(/`/g, "").trim().replace(/[^\w{}$-]+/g, "-").replace(/^-+|-+$/g, "")
                          }
                          const lO = new RegExp(`${/(`{1,2})(.+?)\1(?!`)|\*\*(.+?)\*\*|/.source}${XO.source}`, "g");

                          function vK(OO, KO) {
                            return 2 === OO.length ? KO.replace(/^ (.*) $/, "$1") : KO
                          }

                          function CO(OO) {
                            return "" === OO.trim()
                          }

                          function hO(OO) {
                            const KO = [];
                            for (const pO of OO.trim().replace(/^\|/, "").replace(/\|$/, "").split("|")) KO.length > 0 && KO[KO.length - 1].endsWith("\\") ? KO[KO.length - 1] += `|${pO}` : KO.push(pO);
                            return KO.map((OO => OO.trim().replaceAll("\\|", "|")))
                          }
                          const DO = /^([ \t]*)([-*]|\d+\.)[ \t]+(.*)$/;

                          function MO(OO) {
                            const KO = [],
                              pO = [{
                                indent: -1,
                                items: KO
                              }];
                            let XO = null;
                            for (const bK of OO) {
                              const OO = bK.match(DO);
                              if (!OO) {
                                XO && (XO.text += ` ${bK.trim()}`);
                                continue
                              }
                              const KO = OO[1].replace(/\t/g, "  ").length;
                              for (; KO <= pO[pO.length - 1].indent;) pO.pop();
                              XO = {
                                text: OO[3].trim(),
                                children: []
                              }, pO[pO.length - 1].items.push(XO), pO.push({
                                indent: KO,
                                items: XO.children
                              })
                            }
                            return KO
                          }

                          function aK(OO) {
                            const KO = OO.replace(/\r\n/g, "\n").split("\n"),
                              pO = [];
                            let XO = 0;
                            for (; XO < KO.length;) {
                              const OO = KO[XO];
                              if (CO(OO)) {
                                XO++;
                                continue
                              }
                              const bK = OO.match(/^\s*```\s*(\w*)\s*$/);
                              if (bK) {
                                const OO = [];
                                for (XO++; XO < KO.length && !/^\s*```\s*$/.test(KO[XO]);) OO.push(KO[XO]), XO++;
                                XO++, pO.push({
                                  kind: "code",
                                  lang: bK[1] || "text",
                                  code: OO.join("\n").replace(/\s+$/, "")
                                });
                                continue
                              }
                              const lO = OO.match(/^(#{1,6})\s+(.+?)\s*#*$/);
                              if (lO) {
                                const OO = lO[2].trim();
                                pO.push({
                                  kind: "heading",
                                  level: lO[1].length,
                                  text: OO,
                                  anchor: eO(OO)
                                }), XO++;
                                continue
                              }
                              if (/^\s*(-{3,}|\*{3,})\s*$/.test(OO)) {
                                pO.push({
                                  kind: "rule"
                                }), XO++;
                                continue
                              }
                              if (OO.trim().startsWith("|") && XO + 1 < KO.length && /^\s*\|[\s:|-]+\|\s*$/.test(KO[XO + 1])) {
                                const bK = hO(OO),
                                  eO = [];
                                for (XO += 2; XO < KO.length && KO[XO].trim().startsWith("|");) eO.push(hO(KO[XO])), XO++;
                                pO.push({
                                  kind: "table",
                                  header: bK,
                                  rows: eO
                                });
                                continue
                              }
                              if (OO.startsWith(">")) {
                                const OO = [];
                                for (; XO < KO.length && KO[XO].startsWith(">");) OO.push(KO[XO].replace(/^>\s?/, "")), XO++;
                                pO.push({
                                  kind: "quote",
                                  blocks: aK(OO.join("\n"))
                                });
                                continue
                              }
                              if (DO.test(OO)) {
                                const bK = [],
                                  eO = /^\s*\d+\./.test(OO);
                                for (; XO < KO.length && !CO(KO[XO]) && (DO.test(KO[XO]) || /^\s+\S/.test(KO[XO]));) bK.push(KO[XO]), XO++;
                                pO.push({
                                  kind: "list",
                                  ordered: eO,
                                  items: MO(bK)
                                });
                                continue
                              }
                              const vK = [];
                              for (; XO < KO.length && !CO(KO[XO]) && !/^\s*```/.test(KO[XO]) && !/^#{1,6}\s/.test(KO[XO]) && !KO[XO].startsWith(">") && !DO.test(KO[XO]) && (!KO[XO].trim().startsWith("|") || 0 !== vK.length);) vK.push(KO[XO].trim()), XO++;
                              0 === vK.length && (vK.push(KO[XO].trim()), XO++), pO.push({
                                kind: "paragraph",
                                text: vK.join(" ")
                              })
                            }
                            return pO
                          }

                          function oO(OO) {
                            let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
                            const pO = aK(OO);
                            let XO = "";
                            const bK = [],
                              eO = [],
                              lO = new Map;
                            for (const hO of pO) {
                              if ("heading" === hO.kind) {
                                var vK;
                                const OO = (null !== (vK = lO.get(hO.anchor)) && void 0 !== vK ? vK : 0) + 1;
                                lO.set(hO.anchor, OO), OO > 1 && (hO.anchor = `${hO.anchor}-${OO}`)
                              }
                              if ("heading" === hO.kind && 1 === hO.level && !XO) {
                                XO = hO.text;
                                continue
                              }
                              if ("heading" === hO.kind && hO.level <= KO) {
                                eO.push({
                                  heading: hO,
                                  blocks: []
                                });
                                continue
                              }
                              const OO = eO.at(-1);
                              OO ? OO.blocks.push(hO) : bK.push(hO)
                            }
                            const CO = OO => {
                              for (;
                                "rule" === (null === (KO = OO.at(-1)) || void 0 === KO ? void 0 : KO.kind);) {
                                var KO;
                                OO.pop()
                              }
                            };
                            CO(bK);
                            for (const hO of eO) CO(hO.blocks);
                            return {
                              title: XO,
                              intro: bK,
                              sections: eO
                            }
                          }

                          function FO(OO) {
                            return [{
                              heading: null,
                              blocks: OO.intro
                            }, ...OO.sections.map((OO => ({
                              heading: OO.heading,
                              blocks: OO.blocks
                            })))]
                          }

                          function VO(OO) {
                            return OO.flatMap((OO => "code" === OO.kind ? [OO] : "quote" === OO.kind ? VO(OO.blocks) : []))
                          }

                          function LO(OO) {
                            switch (OO.kind) {
                              case "heading":
                              case "paragraph":
                                return OO.text;
                              case "code":
                                return OO.code;
                              case "table":
                                return [OO.header, ...OO.rows].map((OO => OO.join(" "))).join(" ");
                              case "list": {
                                const KO = OO => OO.map((OO => `${OO.text} ${KO(OO.children)}`)).join(" ");
                                return KO(OO.items)
                              }
                              case "quote":
                                return OO.blocks.map(LO).join(" ");
                              case "rule":
                                return ""
                            }
                          }
                        }, 3969: (OO, KO, pO) => {
                          pO.d(KO, {
                            b: () => vK
                          });
                          var XO = pO(63),
                            bK = pO(243),
                            eO = pO(1546),
                            lO = pO(976);

                          function vK(OO) {
                            let {
                              text: KO
                            } = OO;
                            const pO = [];
                            let vK = "";
                            return (0, bK.cc)(KO).forEach(((OO, KO) => {
                              if ("string" === typeof OO || !(0, eO.d)(OO.icon)) return void(vK += "string" === typeof OO ? OO : OO.icon);
                              const bK = Math.max(0, vK.trimEnd().search(/\S{1,12}$/));
                              pO.push((0, lO.jsxs)(XO.Fragment, {
                                children: [vK.slice(0, bK), (0, lO.jsxs)("span", {
                                  className: "InlineIconTextGlue",
                                  children: [vK.slice(bK), (0, lO.jsx)("span", {
                                    className: "InlineIconTextIcon",
                                    role: "img",
                                    "aria-label": OO.icon,
                                    children: (0, lO.jsx)(eO.b, {
                                      itemName: OO.icon,
                                      amount: 0
                                    })
                                  })]
                                })]
                              }, KO)), vK = ""
                            })), pO.push(vK), (0, lO.jsx)(lO.Fragment, {
                              children: pO
                            })
                          }
                        }, 3908: (OO, KO, pO) => {
                          pO.d(KO, {
                            f: () => zK,
                            b: () => QO
                          });
                          var XO = pO(63),
                            bK = pO(1263),
                            eO = pO(1533),
                            lO = pO(3912),
                            vK = pO(976);
                          const CO = (0, XO.memo)((function(OO) {
                            let {
                              initialParameters: KO
                            } = OO;
                            const pO = (0, XO.useRef)(null),
                              bK = (0, XO.useRef)(null),
                              CO = (0, XO.useRef)(0),
                              hO = (0, XO.useRef)(null),
                              DO = KO.description,
                              MO = KO.e_,
                              {
                                scale: aK,
                                rotation: oO
                              } = null !== KO && void 0 !== KO ? KO : {},
                              FO = (0, lO.e)();
                            return (0, XO.useEffect)((() => {
                              const OO = FO.onFrame((() => {
                                const OO = FO.getState();
                                if (!OO.isActive || !pO.current || !bK.current) return;
                                const KO = OO.state;
                                if (pO.current.value = KO.progress, KO.clickCount > CO.current) {
                                  CO.current = KO.clickCount;
                                  const OO = bK.current;
                                  OO.classList.add("pulse"), hO.current = setTimeout((() => {
                                    OO.classList.remove("pulse")
                                  }), 100)
                                }
                              }));
                              return () => {
                                clearTimeout(hO.current), OO()
                              }
                            }), [FO]), (0, vK.jsx)(vK.Fragment, {
                              children: (0, vK.jsxs)("div", {
                                className: "QTEProgressBarWrapper",
                                style: {
                                  ...null !== aK && {
                                    "--scale": aK
                                  },
                                  ...null !== oO && {
                                    "--rotation": `${oO}deg`
                                  }
                                },
                                children: [(0, vK.jsx)("progress", {
                                  id: "catch",
                                  max: 100,
                                  className: "QTEProgressBar",
                                  ref: pO
                                }), (0, vK.jsx)("span", {
                                  className: "QTEProgressBarInteractionIndicator",
                                  ref: bK,
                                  children: (0, vK.jsx)(eO.d, {
                                    text: [{
                                      icon: MO
                                    }]
                                  })
                                }), (0, vK.jsx)("div", {
                                  className: "QTEProgressBarDescription",
                                  children: (0, vK.jsx)(eO.d, {
                                    text: DO
                                  })
                                })]
                              })
                            })
                          }));
                          var hO = pO(918),
                            DO = pO.n(hO);
                          const MO = 2 * Math.PI * 90,
                            aK = (0, XO.memo)((function(OO) {
                              let {
                                initialParameters: KO
                              } = OO;
                              const pO = (0, XO.useRef)(null),
                                bK = (0, XO.useRef)(null),
                                CO = (0, XO.useRef)(null),
                                hO = KO.label,
                                aK = KO.icon,
                                oO = KO.M_,
                                {
                                  scale: FO,
                                  rotation: VO,
                                  o_: LO
                                } = null !== KO && void 0 !== KO ? KO : {},
                                QO = (0, lO.e)();
                              return (0, XO.useEffect)((() => {
                                const OO = QO.onFrame((() => {
                                  var OO, KO;
                                  const XO = QO.getState();
                                  if (!XO.isActive || !bK.current) return;
                                  const eO = XO.state,
                                    lO = null !== (OO = eO.timeRemaining) && void 0 !== OO ? OO : 0,
                                    vK = null !== (KO = eO.h_) && void 0 !== KO ? KO : 1,
                                    hO = MO * (1 - lO / vK);
                                  bK.current.style.strokeDashoffset = `${hO}`, pO.current && (pO.current.style.opacity = lO > 0 ? "1" : "0"), CO.current && oO && (CO.current.textContent = `${(lO/1e3).toFixed(1)}s`)
                                }));
                                return () => {
                                  OO()
                                }
                              }), [QO, oO]), (0, vK.jsxs)("div", {
                                className: "QTETimedClick",
                                ref: pO,
                                style: {
                                  ...null !== FO && {
                                    "--scale": FO
                                  },
                                  ...null !== VO && {
                                    "--rotation": `${VO}deg`
                                  }
                                },
                                children: [(0, vK.jsxs)("div", {
                                  className: "QTETimedClickCircleContainer",
                                  children: [(0, vK.jsxs)("svg", {
                                    className: "QTETimedClickCircularProgress",
                                    viewBox: "0 0 200 200",
                                    children: [(0, vK.jsx)("circle", {
                                      className: "QTETimedClickProgressTrack",
                                      cx: "100",
                                      cy: "100",
                                      r: 90,
                                      fill: "none",
                                      strokeWidth: "12"
                                    }), (0, vK.jsx)("circle", {
                                      className: "QTETimedClickProgressArc",
                                      cx: "100",
                                      cy: "100",
                                      r: 90,
                                      fill: "none",
                                      strokeWidth: "12",
                                      strokeLinecap: "square",
                                      strokeDasharray: MO,
                                      ref: bK
                                    })]
                                  }), (0, vK.jsx)("div", {
                                    className: "QTETimedClickCenterContent",
                                    children: (0, vK.jsx)(eO.d, {
                                      text: [{
                                        icon: aK
                                      }],
                                      className: DO()("QTETimedClickInnerText", {
                                        QTETimedClickBreathe: LO
                                      })
                                    })
                                  })]
                                }), (0, vK.jsxs)("div", {
                                  className: "QTETimedClickRightTextContainer",
                                  children: [(0, vK.jsx)(eO.d, {
                                    text: hO,
                                    className: "QTETimedClickLabelText"
                                  }), oO && (0, vK.jsx)("span", {
                                    className: "QTETimedClickTimeText",
                                    ref: CO
                                  })]
                                })]
                              })
                            })),
                            oO = (0, XO.memo)((function(OO) {
                              let {
                                initialParameters: KO
                              } = OO;
                              const pO = (0, XO.useRef)(null),
                                bK = (0, XO.useRef)(null),
                                CO = (0, XO.useRef)(null),
                                hO = (0, XO.useRef)(!1),
                                DO = KO.description,
                                MO = null === KO || void 0 === KO ? void 0 : KO.icon,
                                aK = (0, lO.e)();
                              return (0, XO.useEffect)((() => {
                                const OO = aK.onFrame((() => {
                                  const OO = aK.getState();
                                  if (!OO.isActive) return;
                                  const KO = OO.state;
                                  if (pO.current) {
                                    const OO = 100 * (KO.catchZonePosition - KO.L_ / 2);
                                    pO.current.style.left = `${OO}%`, pO.current.style.width = 100 * KO.L_ + "%", KO.isCatching !== hO.current && (hO.current = KO.isCatching, KO.isCatching ? pO.current.classList.add("catching") : pO.current.classList.remove("catching"))
                                  }
                                  bK.current && (bK.current.style.left = 100 * KO.moverPosition + "%"), CO.current && (CO.current.value = KO.progress)
                                }));
                                return () => {
                                  OO()
                                }
                              }), [aK]), (0, vK.jsxs)("div", {
                                className: "QTEGravityBar",
                                children: [(0, vK.jsx)("div", {
                                  className: "QTEGravityBarDescription",
                                  children: (0, vK.jsx)(eO.d, {
                                    text: DO
                                  })
                                }), (0, vK.jsx)("progress", {
                                  max: 100,
                                  className: "QTEGravityBarProgress",
                                  ref: CO
                                }), (0, vK.jsxs)("div", {
                                  className: "QTEGravityBarTrack",
                                  children: [(0, vK.jsx)("div", {
                                    className: "QTEGravityBarCatchZone",
                                    ref: pO
                                  }), (0, vK.jsx)("div", {
                                    className: "QTEGravityBarMover",
                                    ref: bK,
                                    children: (0, vK.jsx)("span", {
                                      children: MO && (0, vK.jsx)(eO.d, {
                                        text: [{
                                          icon: MO,
                                          style: {
                                            fontSize: "4rem"
                                          }
                                        }]
                                      })
                                    })
                                  })]
                                })]
                              })
                            }));
                          var FO = pO(533);
                          const VO = (0, XO.memo)((function(OO) {
                              let {
                                initialParameters: KO
                              } = OO;
                              const pO = (0, XO.useRef)(null),
                                bK = KO.label,
                                CO = KO.Y_,
                                {
                                  icon: hO,
                                  scale: DO,
                                  rotation: MO
                                } = null !== KO && void 0 !== KO ? KO : {},
                                aK = 100 * (.5 - CO / 2),
                                oO = 100 * CO,
                                VO = (0, lO.e)();
                              return (0, XO.useEffect)((() => {
                                const OO = VO.onFrame((() => {
                                  const OO = VO.getState();
                                  if (!OO.isActive || !pO.current) return;
                                  const KO = OO.state;
                                  pO.current.style.left = 100 * KO.markerPosition + "%"
                                }));
                                return () => {
                                  OO()
                                }
                              }), [VO]), (0, vK.jsxs)("div", {
                                className: "QTEPrecisionBarWrapper",
                                style: {
                                  ...!(0, FO.I)(DO) && {
                                    "--scale": DO
                                  },
                                  ...!(0, FO.I)(MO) && {
                                    "--rotation": `${MO}deg`
                                  }
                                },
                                children: [hO && (0, vK.jsx)(eO.d, {
                                  text: [{
                                    icon: hO
                                  }],
                                  className: "QTEPrecisionBarIcon"
                                }), (0, vK.jsxs)("div", {
                                  className: "QTEPrecisionBarTrack",
                                  children: [(0, vK.jsx)("div", {
                                    className: "QTEPrecisionBarSuccessZone",
                                    style: {
                                      left: `${aK}%`,
                                      width: `${oO}%`
                                    }
                                  }), (0, vK.jsx)("div", {
                                    className: "QTEPrecisionBarMarker",
                                    ref: pO
                                  })]
                                }), (0, vK.jsx)("div", {
                                  className: "QTEPrecisionBarLabel",
                                  children: (0, vK.jsx)(eO.d, {
                                    text: bK
                                  })
                                })]
                              })
                            })),
                            LO = (0, XO.memo)((function(OO) {
                              let {
                                initialParameters: KO
                              } = OO;
                              const pO = (0, XO.useRef)(null),
                                [bK, CO] = (0, XO.useState)((() => new Array(KO.R_).fill("pending"))),
                                [hO, DO] = (0, XO.useState)((() => {
                                  const OO = KO.B_;
                                  return (0, FO.I)(OO) || OO <= 0 ? [] : new Array(OO).fill("pending")
                                })),
                                MO = KO.label,
                                {
                                  icon: aK
                                } = KO,
                                oO = (0, XO.useRef)(0),
                                VO = (0, XO.useRef)(0),
                                LO = (0, XO.useRef)([]),
                                QO = (0, lO.e)();
                              return (0, XO.useEffect)((() => {
                                const OO = QO.onFrame((() => {
                                  const OO = QO.getState();
                                  if (!OO.isActive || !pO.current) return;
                                  const KO = OO.state,
                                    XO = 30 + 60 * KO.outerCircleProgress;
                                  if (pO.current.setAttribute("r", String(XO)), !0 === KO.lastClickResult && KO.successes > oO.current) {
                                    pO.current.classList.remove("QTERhythmClickOuterCircle--miss"), pO.current.classList.add("QTERhythmClickOuterCircle--hit");
                                    const OO = setTimeout((() => {
                                      var OO;
                                      null === (OO = pO.current) || void 0 === OO || OO.classList.remove("QTERhythmClickOuterCircle--hit")
                                    }), 200);
                                    LO.current.push(OO)
                                  } else if (!1 === KO.lastClickResult && KO.misses > VO.current) {
                                    pO.current.classList.remove("QTERhythmClickOuterCircle--hit"), pO.current.classList.add("QTERhythmClickOuterCircle--miss");
                                    const OO = setTimeout((() => {
                                      var OO;
                                      null === (OO = pO.current) || void 0 === OO || OO.classList.remove("QTERhythmClickOuterCircle--miss")
                                    }), 200);
                                    LO.current.push(OO)
                                  }
                                  KO.successes === oO.current && KO.misses === VO.current || (oO.current = KO.successes, VO.current = KO.misses, CO((OO => {
                                    const pO = [...OO];
                                    for (let XO = 0; XO < KO.R_; XO++) pO[XO] = XO < KO.successes ? "success" : "pending";
                                    return pO
                                  })), DO((OO => {
                                    if (0 === OO.length) return OO;
                                    const pO = [...OO];
                                    for (let XO = 0; XO < pO.length; XO++) pO[XO] = XO < KO.misses ? "miss" : "pending";
                                    return pO
                                  })))
                                }));
                                return () => {
                                  OO();
                                  for (const OO of LO.current) clearTimeout(OO);
                                  LO.current = []
                                }
                              }), [QO]), (0, vK.jsxs)("div", {
                                className: "QTERhythmClickWrapper",
                                children: [(0, vK.jsx)("div", {
                                  className: "QTERhythmClickProgress",
                                  children: bK.map(((OO, KO) => (0, vK.jsx)("div", {
                                    className: "QTERhythmClickDot" + ("success" === OO ? " QTERhythmClickDot--success" : " QTERhythmClickDot--pendingSuccess")
                                  }, KO)))
                                }), (0, vK.jsxs)("div", {
                                  className: "QTERhythmClickCircleContainer",
                                  children: [(0, vK.jsxs)("svg", {
                                    className: "QTERhythmClickSvg",
                                    viewBox: "0 0 200 200",
                                    children: [(0, vK.jsx)("circle", {
                                      className: "QTERhythmClickInnerCircle",
                                      cx: "100",
                                      cy: "100",
                                      r: 30
                                    }), (0, vK.jsx)("circle", {
                                      className: "QTERhythmClickOuterCircle",
                                      cx: "100",
                                      cy: "100",
                                      r: 90,
                                      ref: pO
                                    })]
                                  }), aK && (0, vK.jsx)("div", {
                                    className: "QTERhythmClickCenterContent",
                                    children: (0, vK.jsx)(eO.d, {
                                      text: [{
                                        icon: aK
                                      }],
                                      className: "QTERhythmClickIcon"
                                    })
                                  })]
                                }), hO.length > 0 && (0, vK.jsx)("div", {
                                  className: "QTERhythmClickProgress",
                                  children: hO.map(((OO, KO) => (0, vK.jsx)("div", {
                                    className: "QTERhythmClickDot" + ("miss" === OO ? " QTERhythmClickDot--miss" : " QTERhythmClickDot--pendingMiss")
                                  }, KO)))
                                }), (0, vK.jsx)("div", {
                                  className: "QTERhythmClickLabel",
                                  children: (0, vK.jsx)(eO.d, {
                                    text: MO
                                  })
                                })]
                              })
                            }));

                          function QO(OO) {
                            let {
                              qte: KO
                            } = OO;
                            switch (KO.type) {
                              case "progressBar":
                                return (0, vK.jsx)(CO, {
                                  initialParameters: KO.parameters
                                });
                              case "timedClick":
                                return (0, vK.jsx)(aK, {
                                  initialParameters: KO.parameters
                                });
                              case "gravityBar":
                                return (0, vK.jsx)(oO, {
                                  initialParameters: KO.parameters
                                });
                              case "precisionBar":
                                return (0, vK.jsx)(VO, {
                                  initialParameters: KO.parameters
                                });
                              case "rhythmClick":
                                return (0, vK.jsx)(LO, {
                                  initialParameters: KO.parameters
                                });
                              default:
                                return console.warn("Unknown QTE type"), null
                            }
                          }
                          const zK = (0, XO.memo)((function() {
                            const [OO, KO] = (0, XO.useState)({
                              type: null,
                              parameters: null,
                              state: null,
                              isActive: !1
                            });
                            return (0, bK.f)("qteStateUpdated", (OO => {
                              KO(OO)
                            })), OO.isActive && OO.type ? (0, vK.jsx)("div", {
                              className: "QTE",
                              "data-camera-keeper": "",
                              children: (0, vK.jsx)(QO, {
                                qte: OO
                              })
                            }) : null
                          }))
                        }, 3912: (OO, KO, pO) => {
                          pO.d(KO, {
                            c: () => vK,
                            e: () => CO
                          });
                          var XO = pO(63),
                            bK = pO(1146),
                            eO = pO(3916);
                          const lO = {
                              getState: () => eO.e.getCurrentState(),
                              onFrame: bK.g
                            },
                            vK = (0, XO.createContext)(lO);

                          function CO() {
                            return (0, XO.useContext)(vK)
                          }
                        }, 3972: (OO, KO, pO) => {
                          pO.d(KO, {
                            e: () => rK,
                            g: () => iK
                          });
                          var XO = pO(3977),
                            bK = pO(243);
                          const eO = 120,
                            lO = 260,
                            vK = 1.15,
                            CO = 1.2,
                            hO = 2,
                            DO = 1.08,
                            MO = .8,
                            aK = .95,
                            oO = 8,
                            FO = "[\"')\\]\u300d\u300f\uff09]*",
                            VO = new RegExp(`[.!?\u2026\u3002\uff01\uff1f]${FO}$`),
                            LO = new RegExp(`[?\uff1f]${FO}$`),
                            QO = new RegExp(`[!\uff01]${FO}$`),
                            zK = /[,;:\u3001\uff0c\uff1b\uff1a]$/,
                            AO = "\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uac00-\\ud7af\\uf900-\\ufaff",
                            fO = new RegExp(`[${AO}]`),
                            dO = new RegExp(`[${AO}]|[^${AO}]+`, "g"),
                            TO = /[aeiouy\u0430\u0435\u0438\u043e\u0443\u044b\u044d\u044e\u044f\u03b1\u03b5\u03b7\u03b9\u03bf\u03c5\u03c9]+/g;

                          function NO(OO) {
                            let KO = 2166136261;
                            for (let pO = 0; pO < OO.length; pO++) KO ^= OO.charCodeAt(pO), KO = Math.imul(KO, 16777619);
                            return (KO >>> 0) / 4294967295 * 2 - 1
                          }

                          function IO(OO) {
                            var KO;
                            if (fO.test(OO)) return 1;
                            const pO = OO.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase(),
                              XO = pO.replace(/[^0-9]/g, "");
                            if (XO.length > 0 && !/\p{L}/u.test(pO)) return Math.min(XO.length, 4);
                            const bK = null !== (KO = pO.match(TO)) && void 0 !== KO ? KO : [];
                            if (0 === bK.length) {
                              var eO, lO;
                              const OO = null !== (eO = null === (lO = pO.match(/\p{L}/gu)) || void 0 === lO ? void 0 : lO.length) && void 0 !== eO ? eO : 0;
                              return 0 === OO ? 0 : Math.min(Math.max(1, Math.round(OO / 2.5)), oO)
                            }
                            const vK = pO.replace(/[^\p{L}]/gu, ""),
                              CO = bK.length > 1 && "e" === bK.at(-1) && vK.endsWith("e") && !vK.endsWith("le") && !/[\u00e9\u00e8\u00ea]$/i.test(OO.replace(/[^\p{L}]/gu, ""));
                            return Math.min(bK.length - (CO ? 1 : 0), oO)
                          }

                          function yK(OO) {
                            return OO.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "")
                          }

                          function gK(OO) {
                            const KO = OO.replace(/[^\p{L}]/gu, "");
                            return KO.length >= 2 && KO === KO.toUpperCase() && KO !== KO.toLowerCase()
                          }

                          function uO(OO, KO) {
                            var pO;
                            const oO = KO && (0, XO.l)(KO),
                              FO = null !== (pO = null === oO || void 0 === oO ? void 0 : oO.syllableMs) && void 0 !== pO ? pO : XO.d,
                              AO = function(OO) {
                                const KO = [];
                                for (const XO of (0, bK.cc)(OO))
                                  if ("string" === typeof XO)
                                    for (const OO of XO.split(/(\s+)/)) {
                                      if ("" === OO) continue;
                                      if (/^\s+$/.test(OO)) {
                                        KO.push({
                                          kind: "space",
                                          text: OO
                                        });
                                        continue
                                      }
                                      if (!fO.test(OO)) {
                                        KO.push({
                                          kind: "word",
                                          text: OO,
                                          delayMs: 0
                                        });
                                        continue
                                      }
                                      let XO = !0;
                                      for (const bK of null !== (pO = OO.match(dO)) && void 0 !== pO ? pO : []) {
                                        var pO;
                                        const OO = KO.at(-1);
                                        XO || "word" !== (null === OO || void 0 === OO ? void 0 : OO.kind) || fO.test(bK) || /[\p{L}\p{N}]/u.test(bK) ? (XO || KO.push({
                                          kind: "space",
                                          text: "\u200b"
                                        }), KO.push({
                                          kind: "word",
                                          text: bK,
                                          delayMs: 0
                                        }), XO = !1) : OO.text += bK
                                      }
                                    } else KO.push({
                                      kind: "icon",
                                      text: XO.icon,
                                      delayMs: 0
                                    });
                                return KO
                              }(OO),
                              TO = [];
                            let uO = [];
                            for (const XO of AO) "space" !== XO.kind && (uO.push(XO), VO.test(XO.text) && (TO.push(uO), uO = []));
                            TO.push(uO);
                            const EO = [];
                            let jK = 0;
                            for (const XO of TO) {
                              var YO, wO;
                              const OO = null !== (YO = null === (wO = XO.at(-1)) || void 0 === wO ? void 0 : wO.text) && void 0 !== YO ? YO : "",
                                KO = LO.test(OO),
                                pO = QO.test(OO),
                                bK = XO.map((OO => "word" === OO.kind ? IO(OO.text) : 1)),
                                AO = bK.findLastIndex((OO => OO > 0));
                              for (const [LO, QO] of XO.entries()) {
                                const OO = "word" === QO.kind,
                                  XO = bK[LO];
                                QO.delayMs = jK;
                                for (let bK = 0; oO && bK < XO; bK++) {
                                  const {
                                    intonation: eO
                                  } = oO;
                                  let lO = AO > 0 ? -eO.declineSemitones * (LO / AO) : 0;
                                  lO += NO(`${yK(QO.text)}|${bK}`) * eO.variationSemitones;
                                  const VO = Math.min(1, eO.variationSemitones);
                                  let zK = oO.glideSemitones,
                                    fO = 1;
                                  pO && (lO += eO.exclaimLiftSemitones, fO *= vK), KO && LO === AO && (lO += eO.questionRiseSemitones * (XO > 1 ? .5 + .5 * bK / (XO - 1) : 1), bK === XO - 1 && (zK = Math.abs(zK) + eO.questionRiseSemitones / 2)), OO && gK(QO.text) && (lO += hO * VO, fO *= CO), XO > 1 && 0 === bK && (lO += MO * VO, fO *= DO), EO.push({
                                    atMs: jK + bK * FO,
                                    semitones: lO,
                                    glideSemitones: zK,
                                    durationMs: bK < XO - 1 ? Math.min(oO.durationMs, FO * aK) : oO.durationMs,
                                    level: fO
                                  })
                                }
                                jK += XO * FO + (VO.test(QO.text) ? lO : zK.test(QO.text) ? eO : 0)
                              }
                            }
                            return {
                              pieces: AO.map((OO => "space" === OO.kind ? OO : "icon" === OO.kind ? {
                                kind: "icon",
                                icon: OO.text,
                                delayMs: OO.delayMs
                              } : {
                                kind: "word",
                                text: OO.text,
                                delayMs: OO.delayMs
                              })),
                              blips: EO
                            }
                          }
                          var EO = pO(1051),
                            jK = pO(1109),
                            YO = pO(1558);

                          function wO(OO) {
                            if ("string" === typeof OO) return OO;
                            const KO = jK.f.get().getCurrentLanguageCode();
                            return (0, EO.s)(KO, OO.translationKey, (0, EO.q)(OO.params, YO.c.shown))
                          }

                          function iK(OO) {
                            const KO = void 0 === OO.voice ? null : (0, XO.m)(OO.voice),
                              pO = KO && (0, XO.l)(KO);
                            return {
                              plan: uO(wO(OO.line), pO),
                              synth: pO
                            }
                          }

                          function rK(OO) {
                            const KO = [];
                            let pO = [];
                            for (const [bK, eO] of OO.entries()) {
                              var XO;
                              "space" === eO.kind && (" " !== eO.text || "icon" !== (null === (XO = OO[bK + 1]) || void 0 === XO ? void 0 : XO.kind)) ? (pO.length > 0 && KO.push(pO), KO.push([eO]), pO = []) : pO.push(eO)
                            }
                            return pO.length > 0 && KO.push(pO), KO
                          }
                        }, 3984: (OO, KO, pO) => {
                          pO.d(KO, {
                            c: () => DO,
                            g: () => MO
                          });
                          var XO = pO(3988),
                            bK = pO(22);
                          const eO = .25,
                            lO = .85,
                            vK = .02,
                            CO = .01;

                          function hO(OO, KO, pO, XO, bK, eO, vK) {
                            const {
                              waveform: CO,
                              pitchHz: hO,
                              attackMs: DO,
                              releaseMs: MO,
                              lowpassHz: aK
                            } = pO, oO = bK + XO.durationMs / 1e3, FO = hO * 2 ** (XO.semitones / 12), VO = OO.createOscillator();
                            VO.type = CO, VO.frequency.setValueAtTime(FO, bK), VO.frequency.exponentialRampToValueAtTime(FO * 2 ** (XO.glideSemitones / 12), oO);
                            const LO = bK + Math.min(DO, XO.durationMs) / 1e3,
                              QO = OO.createGain();
                            QO.gain.setValueAtTime(0, bK), QO.gain.linearRampToValueAtTime(eO, LO), QO.gain.linearRampToValueAtTime(eO * lO, Math.max(LO, oO - MO / 1e3)), QO.gain.linearRampToValueAtTime(0, oO);
                            const zK = [VO];
                            if (null !== aK) {
                              const KO = OO.createBiquadFilter();
                              KO.type = "lowpass", KO.frequency.value = aK, zK.push(KO)
                            }
                            zK.push(QO, KO);
                            for (let lO = 1; lO < zK.length; lO++) zK[lO - 1].connect(zK[lO]);
                            return VO.onended = () => {
                              for (const OO of zK.slice(0, -1)) OO.disconnect();
                              vK()
                            }, VO.start(bK), VO.stop(oO), VO
                          }

                          function DO(OO, KO, pO, XO, bK, lO) {
                            if (0 === XO.length) return lO(), () => {};
                            const DO = eO * pO.volume * bK,
                              MO = OO.createGain();
                            MO.connect(KO);
                            const aK = OO.currentTime + vK,
                              oO = new Set;
                            for (const eO of XO) {
                              const KO = hO(OO, MO, pO, eO, aK + eO.atMs / 1e3, DO * eO.level, (() => {
                                oO.delete(KO), 0 === oO.size && (MO.disconnect(), lO())
                              }));
                              oO.add(KO)
                            }
                            return () => {
                              const KO = OO.currentTime;
                              MO.gain.setTargetAtTime(0, KO, CO);
                              for (const OO of oO) try {
                                OO.stop(KO + 5 * CO)
                              } catch {}
                            }
                          }

                          function MO(OO, KO) {
                            var pO;
                            const eO = XO.b.ctx,
                              lO = XO.b.masterGain;
                            if (!eO || !lO || !bK.d.get("soundOnFromAd")) return () => {};
                            const vK = XO.b;
                            return null === (pO = vK._autoResume) || void 0 === pO || pO.call(vK), DO(eO, lO, OO, KO, bK.d.get("soundVolume"), (() => {
                              var OO;
                              null === (OO = vK._autoSuspend) || void 0 === OO || OO.call(vK)
                            }))
                          }
                        }, 3916: (OO, KO, pO) => {
                          pO.d(KO, {
                            e: () => fO,
                            g: () => QO
                          });
                          var XO = pO(1148),
                            bK = pO(26);
                          var eO = pO(256);
                          var lO = pO(533);
                          var vK = pO(1964),
                            CO = pO(3923),
                            hO = pO(3952),
                            DO = pO(3962);
                          class MO {
                            constructor(OO, KO, pO, XO, bK, eO) {
                              this.id = OO, this.type = KO, this.parameters = pO, this.tearDownNotification = XO, this.onDonePromise = bK, this.resolveRequest = eO
                            }
                          }
                          const aK = new Set(["primary-fire", "alt-fire", "TouchDig", "TouchInteract", "TouchBoost"]);
                          class oO {
                            constructor(OO, KO, pO, XO, bK, eO) {
                              this.id = OO, this.type = KO, this.parameters = pO, this.resolveRequest = XO, this.onDonePromise = bK, this.tearDownNotification = eO, this.mouseSub = null, this.stopInputActions = null, this.stopShellTicks = null, this.tickSub = null, this.implementation = void 0, this.isCompleted = !1;
                              const lO = QO[KO];
                              if (!lO) throw console.error(`No QTE implementation registered for type: ${KO}`), new Error(`No QTE implementation registered for type: ${KO}`);
                              this.implementation = new lO(pO, (OO => {
                                this.isCompleted = !0, this.resolveRequest(OO)
                              }), this.tearDownNotification), this.setupInputHandlers()
                            }
                            setupInputHandlers() {
                              this.mouseSub = bK.i.subscribe("QTEMouseState", (OO => {
                                let {
                                  isDown: KO
                                } = OO;
                                this.isCompleted || this.implementation.handleMouseInput(KO)
                              })), this.stopInputActions = (0, hO.h)((OO => {
                                this.isCompleted || !aK.has(OO.action) && !(0, hO.f)(OO) || this.implementation.handleMouseInput(OO.down)
                              })), this.tickSub = bK.i.subscribe("noaTick", (OO => {
                                if (this.isCompleted) return;
                                const KO = OO / 1e3;
                                this.implementation.handleTick(KO)
                              })), this.stopShellTicks = (0, CO.v)((() => {
                                this.isCompleted || this.implementation.handleTick(vK.p / 1e3)
                              }))
                            }
                            cleanup() {
                              var OO, KO;
                              this.mouseSub && (bK.i.unsubscribe(this.mouseSub), this.mouseSub = null), null === (OO = this.stopInputActions) || void 0 === OO || OO.call(this), this.stopInputActions = null, null === (KO = this.stopShellTicks) || void 0 === KO || KO.call(this), this.stopShellTicks = null, this.tickSub && (bK.i.unsubscribe(this.tickSub), this.tickSub = null)
                            }
                            async waitUntilDone() {
                              await this.onDonePromise
                            }
                            getState() {
                              return this.implementation.getState()
                            }
                            tearDown() {
                              this.isCompleted = !0, this.cleanup(), this.implementation.tearDown()
                            }
                          }
                          const FO = new XO.b,
                            VO = new Map;
                          let LO = null;
                          const QO = {
                            progressBar: class {
                              constructor(OO, KO, pO) {
                                var XO, bK, eO, lO;
                                this.resolveRequest = KO, this.tearDownNotification = pO, this.progress = 0, this.k_ = void 0, this.p_ = void 0, this.qm = void 0, this.isCompleted = !1, this.clickCount = 0, this.parameters = void 0, this.type = "progressBar";
                                const vK = OO;
                                this.k_ = null !== (XO = vK.k_) && void 0 !== XO ? XO : .075, this.p_ = null !== (bK = vK.p_) && void 0 !== bK ? bK : 1, this.progress = null !== (eO = vK.RP) && void 0 !== eO ? eO : 30, this.qm = null !== (lO = vK.qm) && void 0 !== lO && lO, this.parameters = vK
                              }
                              handleMouseInput(OO) {
                                OO && !this.isCompleted && (this.clickCount++, this.progress += this.p_, this.progress >= 100 && this.complete(!0))
                              }
                              handleTick() {
                                if (!this.isCompleted)
                                  if (this.progress -= this.k_, this.qm && this.progress <= 0) this.complete(!1);
                                  else if (this.progress <= 0) this.progress = 0;
                                else if (this.progress >= 100) return void this.complete(!0)
                              }
                              complete(OO) {
                                this.isCompleted = !0, this.resolveRequest(OO)
                              }
                              getState() {
                                return {
                                  type: this.type,
                                  parameters: this.parameters,
                                  state: {
                                    progress: this.progress,
                                    clickCount: this.clickCount
                                  },
                                  isActive: !0
                                }
                              }
                              tearDown() {
                                this.tearDownNotification()
                              }
                            },
                            timedClick: class {
                              constructor(OO, KO, pO) {
                                var XO;
                                this.resolveRequest = KO, this.tearDownNotification = pO, this.startTime = void 0, this.timeWindowMs = void 0, this.isCompleted = !1, this.parameters = void 0, this.type = "timedClick", this.parameters = OO, this.timeWindowMs = null !== (XO = this.parameters.h_) && void 0 !== XO ? XO : 3e3, this.startTime = Date.now()
                              }
                              handleMouseInput(OO) {
                                if (!OO || this.isCompleted) return;
                                Date.now() - this.startTime <= this.timeWindowMs && this.complete(!0)
                              }
                              handleTick() {
                                if (this.isCompleted) return;
                                Date.now() - this.startTime > this.timeWindowMs && this.complete(!1)
                              }
                              complete(OO) {
                                this.isCompleted = !0, this.resolveRequest(OO)
                              }
                              getState() {
                                const OO = Date.now() - this.startTime,
                                  KO = Math.max(0, this.timeWindowMs - OO);
                                return {
                                  type: this.type,
                                  parameters: this.parameters,
                                  state: {
                                    timeRemaining: KO,
                                    h_: this.timeWindowMs
                                  },
                                  isActive: !0
                                }
                              }
                              tearDown() {
                                this.tearDownNotification()
                              }
                            },
                            gravityBar: class {
                              constructor(OO, KO, pO) {
                                var XO;
                                this.resolveRequest = KO, this.tearDownNotification = pO, this.parameters = void 0, this.type = "gravityBar", this.catchZonePosition = .5, this.catchZoneVelocity = 0, this.isMouseDown = !1, this.moverPosition = .5, this.moverTarget = Math.random(), this.ticksUntilDirectionChange = void 0, this.progress = void 0, this.isCompleted = !1;
                                const bK = OO;
                                this.parameters = {
                                  ...bK,
                                  L_: eO.e.clamp(bK.L_, .05, 1)
                                }, this.progress = null !== (XO = bK.RP) && void 0 !== XO ? XO : 30, this.ticksUntilDirectionChange = this.randomNumTicksUntilDirectionChange()
                              }
                              handleMouseInput(OO) {
                                this.isMouseDown = OO
                              }
                              handleTick(OO) {
                                this.isCompleted || (this.updateMover(), this.updateCatchZone(), this.updateProgress(OO))
                              }
                              updateMover() {
                                this.ticksUntilDirectionChange--, (this.ticksUntilDirectionChange <= 0 || Math.abs(this.moverPosition - this.moverTarget) < .02) && this.pickNewMoverTarget();
                                const OO = Math.sign(this.moverTarget - this.moverPosition);
                                this.moverPosition += OO * this.parameters.Q_ * .004, this.moverPosition = Math.max(0, Math.min(1, this.moverPosition))
                              }
                              pickNewMoverTarget() {
                                this.moverTarget = Math.random(), this.ticksUntilDirectionChange = this.randomNumTicksUntilDirectionChange()
                              }
                              randomNumTicksUntilDirectionChange() {
                                const OO = eO.e.clamp(1 - .7 * this.parameters.A_, 0, 1.4);
                                return Math.floor(60 * OO + 40 * Math.random())
                              }
                              updateCatchZone() {
                                this.isMouseDown ? this.catchZoneVelocity += .001 * this.parameters.f_ : this.catchZoneVelocity -= .001 * this.parameters.gravity, this.catchZoneVelocity *= .92, this.catchZoneVelocity = eO.e.clampAbs(this.catchZoneVelocity, .03), this.catchZonePosition += this.catchZoneVelocity;
                                const OO = this.parameters.L_ / 2,
                                  KO = OO,
                                  pO = 1 - OO;
                                this.catchZonePosition <= KO ? (this.catchZonePosition = KO, this.catchZoneVelocity = 0) : this.catchZonePosition >= pO && (this.catchZonePosition = pO, this.catchZoneVelocity = 0)
                              }
                              isMoverInCatchZone() {
                                const OO = this.parameters.L_ / 2;
                                return this.moverPosition >= this.catchZonePosition - OO && this.moverPosition <= this.catchZonePosition + OO
                              }
                              updateProgress(OO) {
                                this.isMoverInCatchZone() ? this.progress += this.parameters.T_ * OO : this.progress -= this.parameters.N_ * OO, this.progress >= 100 ? (this.progress = 100, this.complete(!0)) : this.parameters.qm && this.progress <= 0 ? (this.progress = 0, this.complete(!1)) : this.progress < 0 && (this.progress = 0)
                              }
                              complete(OO) {
                                this.isCompleted = !0, this.resolveRequest(OO)
                              }
                              getState() {
                                return {
                                  type: this.type,
                                  parameters: this.parameters,
                                  state: {
                                    catchZonePosition: this.catchZonePosition,
                                    L_: this.parameters.L_,
                                    moverPosition: this.moverPosition,
                                    progress: this.progress,
                                    isCatching: this.isMoverInCatchZone()
                                  },
                                  isActive: !0
                                }
                              }
                              tearDown() {
                                this.tearDownNotification()
                              }
                            },
                            precisionBar: class {
                              constructor(OO, KO, pO) {
                                var XO, bK, lO, vK, CO;
                                this.resolveRequest = KO, this.tearDownNotification = pO, this.startTime = void 0, this.speed = void 0, this.Y_ = void 0, this.isCompleted = !1, this.markerPosition = 0, this.parameters = void 0, this.type = "precisionBar";
                                const hO = OO;
                                this.parameters = {
                                  ...hO,
                                  speed: null !== (XO = hO.speed) && void 0 !== XO ? XO : .5,
                                  Y_: eO.e.clamp(hO.Y_, .05, 1),
                                  label: null !== (bK = hO.label) && void 0 !== bK ? bK : [{
                                    str: "Click when the marker is within the green zone."
                                  }],
                                  icon: null !== (lO = hO.icon) && void 0 !== lO ? lO : null,
                                  scale: null !== (vK = hO.scale) && void 0 !== vK ? vK : 1,
                                  rotation: null !== (CO = hO.rotation) && void 0 !== CO ? CO : 0
                                }, this.speed = this.parameters.speed, this.Y_ = this.parameters.Y_, this.startTime = Date.now()
                              }
                              handleMouseInput(OO) {
                                if (OO) {
                                  this.updateMarkerPosition();
                                  const OO = Math.abs(this.markerPosition - .5) <= this.Y_ / 2;
                                  this.complete(OO)
                                }
                              }
                              handleTick() {
                                this.isCompleted || this.updateMarkerPosition()
                              }
                              updateMarkerPosition() {
                                const OO = (Date.now() - this.startTime) / 1e3 * this.speed % 1;
                                this.markerPosition = OO <= .5 ? 2 * OO : 2 - 2 * OO
                              }
                              complete(OO) {
                                this.isCompleted = !0, this.resolveRequest(OO)
                              }
                              getState() {
                                return this.updateMarkerPosition(), {
                                  type: this.type,
                                  parameters: this.parameters,
                                  state: {
                                    markerPosition: this.markerPosition
                                  },
                                  isActive: !0
                                }
                              }
                              tearDown() {
                                this.tearDownNotification()
                              }
                            },
                            rhythmClick: class {
                              constructor(OO, KO, pO) {
                                this.resolveRequest = KO, this.tearDownNotification = pO, this.parameters = void 0, this.type = "rhythmClick", this.shrinkStartTime = void 0, this.isCompleted = !1, this.successes = 0, this.misses = 0, this.lastClickResult = null, this.parameters = OO, this.shrinkStartTime = Date.now()
                              }
                              handleMouseInput(OO) {
                                if (!OO || this.isCompleted) return;
                                const KO = this.getOuterCircleProgress();
                                if (KO <= this.parameters.J_ && KO >= -this.parameters.J_) {
                                  if (this.successes++, this.lastClickResult = !0, this.successes >= this.parameters.R_) return void this.complete(!0)
                                } else this.handleMiss();
                                this.shrinkStartTime = Date.now()
                              }
                              handleMiss() {
                                this.misses++, this.lastClickResult = !1, !(0, lO.I)(this.parameters.B_) && this.misses > this.parameters.B_ ? this.complete(!1) : this.shrinkStartTime = Date.now()
                              }
                              handleTick() {
                                if (this.isCompleted) return;
                                this.getOuterCircleProgress() < -this.parameters.J_ && this.handleMiss()
                              }
                              getOuterCircleProgress() {
                                return 1 - (Date.now() - this.shrinkStartTime) / this.parameters.S_
                              }
                              complete(OO) {
                                this.isCompleted = !0, this.resolveRequest(OO)
                              }
                              getState() {
                                return {
                                  type: this.type,
                                  parameters: this.parameters,
                                  state: {
                                    outerCircleProgress: this.getOuterCircleProgress(),
                                    successes: this.successes,
                                    R_: this.parameters.R_,
                                    misses: this.misses,
                                    lastClickResult: this.lastClickResult
                                  },
                                  isActive: !0
                                }
                              }
                              tearDown() {
                                this.tearDownNotification()
                              }
                            }
                          };

                          function zK() {
                            (0, DO.j)(vK.u.Qte, LO ? vK.u.Qte : 0), LO ? bK.i.pl("qteStateUpdated", LO.getState()) : bK.i.pl("qteStateUpdated", {
                              type: null,
                              typeSpecificParameters: null,
                              isActive: !1
                            })
                          }
                          class AO {
                            constructor(OO, KO) {
                              this.resultPromise = OO, this.tearDownQTE = KO
                            }
                            static create(OO, KO, pO) {
                              const XO = Promise.race([OO, KO]);
                              return new AO(XO, pO)
                            }
                            async getResult() {
                              return await this.resultPromise
                            }
                          }
                          class fO {
                            static queueQTE(OO, KO, pO) {
                              let XO, bK;
                              const eO = new Promise((OO => {
                                  XO = OO
                                })),
                                lO = new Promise((OO => {
                                  bK = () => {
                                    OO("qteTornDown")
                                  }
                                })),
                                vK = Promise.race([eO, lO]).then((() => {})),
                                CO = new MO(OO, KO, pO, bK, vK, XO);
                              return VO.set(OO, CO), FO.enqueue(CO), LO || this.processNextQTE(), AO.create(eO, lO, bK)
                            }
                            static async processNextQTE() {
                              if (LO || FO.fX()) return void(FO.fX() && LO && (LO = null, zK()));
                              const OO = await FO.dequeue();
                              if (!VO.has(OO.id)) return void await this.processNextQTE();
                              VO.delete(OO.id);
                              const KO = new oO(OO.id, OO.type, OO.parameters, OO.resolveRequest, OO.onDonePromise, OO.tearDownNotification);
                              LO = KO, zK();
                              try {
                                await KO.waitUntilDone()
                              } catch (pO) {
                                console.error("Error while waiting for QTE to resolve:", pO.stack)
                              }
                              LO === KO && (LO.cleanup(), LO = null, zK()), await this.processNextQTE()
                            }
                            static cancelQTE(OO) {
                              if (LO && LO.id === OO) return LO.tearDown(), LO = null, zK(), void this.processNextQTE();
                              const KO = VO.get(OO);
                              KO && (VO.delete(OO), KO.tearDownNotification())
                            }
                            static getCurrentState() {
                              return LO ? LO.getState() : {
                                type: null,
                                parameters: null,
                                state: null,
                                isActive: !1
                              }
                            }
                            static reset() {
                              LO && (LO.tearDown(), LO = null), VO.forEach(((OO, KO) => {
                                this.cancelQTE(KO)
                              })), FO.emptyQueue(), VO.clear(), zK()
                            }
                          }
                        }, 3988: (OO, KO, pO) => {
                          pO.d(KO, {
                            Howl: () => XO.Howl,
                            b: () => XO.Howler
                          });
                          var XO = pO(3992);
                          XO.Howler._mobileUnloaded = !0
                        }, 3996: (OO, KO, pO) => {
                          function XO(OO) {
                            return {
                              notAfter: OO
                            }
                          }
                          pO.d(KO, {
                            B: () => MO,
                            e: () => CO,
                            i: () => hO,
                            l: () => vK,
                            o: () => XO,
                            s: () => bK,
                            u: () => eO,
                            x: () => lO,
                            z: () => DO
                          });
                          const bK = XO("\\w$."),
                            eO = XO("\\w.,");

                          function lO(OO) {
                            return KO => CO(KO, OO)
                          }

                          function vK(OO) {
                            return KO => !OO.test(KO.input.slice(0, KO.index))
                          }

                          function CO(OO, KO) {
                            return OO.index > 0 && new RegExp(`[${KO}]`).test(OO.input[OO.index - 1])
                          }

                          function hO(OO, KO, pO) {
                            return function(OO) {
                              return void 0 !== OO && "function" !== typeof OO
                            }(pO) ? function(OO, KO, pO) {
                              const XO = KO.flags.replace(/[gy]/g, ""),
                                bK = new RegExp(`[^${pO}](?:${KO.source})`, `${XO}g`),
                                eO = [],
                                lO = pO => {
                                  const XO = pO.index + pO[0].length;
                                  return ("" === pO[0] ? aK(OO, KO, XO) : XO) - 1
                                },
                                vK = new RegExp(`(?:${KO.source})`, `${XO}y`).exec(OO);
                              if (vK) {
                                if (eO.push(vK), !KO.global) return eO;
                                bK.lastIndex = lO(vK)
                              }
                              for (let CO = bK.exec(OO); CO; CO = bK.exec(OO)) {
                                const pO = aK(OO, KO, CO.index) - CO.index;
                                if (CO[0] = CO[0].slice(pO), CO.index += pO, eO.push(CO), !KO.global) break;
                                bK.lastIndex = lO(CO)
                              }
                              return eO
                            }(OO, KO, pO.notAfter) : function(OO, KO, pO) {
                              const XO = new RegExp(KO.source, `${KO.flags.replace(/[gy]/g,"")}g`),
                                bK = [];
                              for (let eO = XO.exec(OO); eO; eO = XO.exec(OO))
                                if (!pO || pO(eO)) {
                                  if (bK.push(eO), !KO.global) break;
                                  "" === eO[0] && (XO.lastIndex = aK(OO, KO, XO.lastIndex))
                                } else XO.lastIndex = aK(OO, KO, eO.index);
                              return bK
                            }(OO, KO, pO)
                          }

                          function DO(OO, KO, pO, XO) {
                            let bK = "",
                              eO = 0;
                            for (const lO of hO(OO, KO, pO)) bK += OO.slice(eO, lO.index) + XO(lO), eO = lO.index + lO[0].length;
                            return bK + OO.slice(eO)
                          }

                          function MO(OO, KO, pO) {
                            const XO = [];
                            let bK = 0;
                            for (const eO of hO(OO, KO, pO)) XO.push(OO.slice(bK, eO.index)), bK = eO.index + eO[0].length;
                            return [...XO, OO.slice(bK)]
                          }

                          function aK(OO, KO, pO) {
                            var XO;
                            return pO + (KO.unicode && (null !== (XO = OO.codePointAt(pO)) && void 0 !== XO ? XO : 0) > 65535 ? 2 : 1)
                          }
                        }, 3952: (OO, KO, pO) => {
                          pO.d(KO, {
                            d: () => CO,
                            f: () => eO,
                            h: () => vK
                          });
                          var XO = pO(1964),
                            bK = pO(3955);

                          function eO(OO) {
                            let {
                              action: KO,
                              flags: pO
                            } = OO;
                            return "mid-fire" === KO && 0 !== (pO & XO.b.AltLeftClick)
                          }
                          const lO = new Set;

                          function vK(OO) {
                            return lO.add(OO), () => {
                              lO.delete(OO)
                            }
                          }

                          function CO(OO) {
                            const KO = bK.e[255 & OO];
                            if (void 0 === KO) return;
                            const pO = OO >>> 8 & 255,
                              eO = {
                                action: KO,
                                down: 0 !== (pO & XO.b.Down),
                                flags: pO,
                                press: OO >>> 16
                              };
                            for (const XO of lO) XO(eO)
                          }
                        }, 3964: (OO, KO, pO) => {
                          pO.d(KO, {
                            e: () => bK,
                            h: () => CO,
                            i: () => eO,
                            j: () => lO,
                            m: () => vK,
                            o: () => LO,
                            s: () => DO,
                            t: () => MO,
                            u: () => VO,
                            x: () => oO
                          });
                          var XO = pO(1406);
                          const bK = 24e3,
                            eO = "/docs/llms.txt",
                            lO = `${XO.e}${eO}`,
                            vK = "/llms.txt",
                            CO = "/docs/llms-full.txt";

                          function hO(OO) {
                            return OO || "index"
                          }

                          function DO(OO) {
                            return `/docs/${hO(OO)}.md`
                          }

                          function MO(OO, KO) {
                            return `/docs/${hO(OO)}/${KO+1}.md`
                          }
                          const aK = /^\/docs\/([a-z0-9-]+)(?:\/(\d+))?\.md$/;

                          function oO(OO) {
                            const KO = aK.exec(OO);
                            return null === KO ? null : {
                              name: KO[1],
                              part: void 0 === KO[2] ? null : Number(KO[2])
                            }
                          }
                          const FO = /^(?:\/studio)?\/docs(?:\/([a-z0-9-]+)(?:\/(\d+))?)?\/?$/;

                          function VO(OO) {
                            const KO = FO.exec(OO);
                            if (null === KO) return null;
                            const [, pO = "", XO] = KO;
                            return void 0 === XO ? DO(pO) : MO(pO, Number(XO) - 1)
                          }

                          function LO(OO) {
                            return `/docsHtml/${hO(OO)}.html`
                          }
                        }, 3977: (OO, KO, pO) => {
                          pO.d(KO, {
                            d: () => bK,
                            g: () => XO,
                            k: () => eO,
                            l: () => CO,
                            m: () => lO
                          });
                          const XO = ["sine", "triangle", "square", "sawtooth"],
                            bK = 55,
                            eO = {
                              soft: {
                                waveform: "sine",
                                pitchHz: 300,
                                glideSemitones: -.5,
                                durationMs: 80,
                                attackMs: 6,
                                releaseMs: 18,
                                lowpassHz: null,
                                volume: .6,
                                intonation: {
                                  variationSemitones: 1.2,
                                  declineSemitones: 1.5,
                                  questionRiseSemitones: 3.5,
                                  exclaimLiftSemitones: 1.5
                                },
                                syllableMs: 60
                              },
                              regular: {
                                waveform: "triangle",
                                pitchHz: 195,
                                glideSemitones: -.6,
                                durationMs: 70,
                                attackMs: 2,
                                releaseMs: 12,
                                lowpassHz: null,
                                volume: 1,
                                intonation: {
                                  variationSemitones: 1.5,
                                  declineSemitones: 2,
                                  questionRiseSemitones: 4,
                                  exclaimLiftSemitones: 2
                                },
                                syllableMs: 52
                              },
                              dark: {
                                waveform: "sawtooth",
                                pitchHz: 80,
                                glideSemitones: -.6,
                                durationMs: 85,
                                attackMs: 6,
                                releaseMs: 16,
                                lowpassHz: 420,
                                volume: 1.05,
                                intonation: {
                                  variationSemitones: 1,
                                  declineSemitones: 3.5,
                                  questionRiseSemitones: 2.5,
                                  exclaimLiftSemitones: 1
                                },
                                syllableMs: 64
                              },
                              "high-pitched": {
                                waveform: "triangle",
                                pitchHz: 300,
                                glideSemitones: -.8,
                                durationMs: 55,
                                attackMs: 2,
                                releaseMs: 10,
                                lowpassHz: null,
                                volume: .8,
                                intonation: {
                                  variationSemitones: 2.2,
                                  declineSemitones: 2,
                                  questionRiseSemitones: 5,
                                  exclaimLiftSemitones: 3
                                },
                                syllableMs: 44
                              },
                              gruff: {
                                waveform: "sawtooth",
                                pitchHz: 105,
                                glideSemitones: -.8,
                                durationMs: 75,
                                attackMs: 4,
                                releaseMs: 14,
                                lowpassHz: 900,
                                volume: .85,
                                intonation: {
                                  variationSemitones: 1.2,
                                  declineSemitones: 3,
                                  questionRiseSemitones: 3,
                                  exclaimLiftSemitones: 2
                                },
                                syllableMs: 58
                              },
                              lively: {
                                waveform: "square",
                                pitchHz: 230,
                                glideSemitones: .6,
                                durationMs: 55,
                                attackMs: 2,
                                releaseMs: 10,
                                lowpassHz: 2400,
                                volume: .5,
                                intonation: {
                                  variationSemitones: 2.6,
                                  declineSemitones: 1.5,
                                  questionRiseSemitones: 5,
                                  exclaimLiftSemitones: 3.5
                                },
                                syllableMs: 44
                              },
                              posh: {
                                waveform: "triangle",
                                pitchHz: 175,
                                glideSemitones: 1.2,
                                durationMs: 90,
                                attackMs: 6,
                                releaseMs: 20,
                                lowpassHz: 2e3,
                                volume: 1,
                                intonation: {
                                  variationSemitones: 2,
                                  declineSemitones: 4,
                                  questionRiseSemitones: 5,
                                  exclaimLiftSemitones: 2.5
                                },
                                syllableMs: 60
                              },
                              mechanical: {
                                waveform: "square",
                                pitchHz: 140,
                                glideSemitones: 0,
                                durationMs: 60,
                                attackMs: 0,
                                releaseMs: 4,
                                lowpassHz: 1400,
                                volume: .55,
                                intonation: {
                                  variationSemitones: 0,
                                  declineSemitones: 0,
                                  questionRiseSemitones: 0,
                                  exclaimLiftSemitones: 0
                                },
                                syllableMs: 62
                              }
                            };

                          function lO(OO) {
                            return "string" !== typeof OO ? OO : Object.hasOwn(eO, OO) ? eO[OO] : null
                          }

                          function vK(OO, KO, pO) {
                            return Math.min(pO, Math.max(KO, OO))
                          }

                          function CO(OO) {
                            const KO = vK(OO.durationMs, 10, 500),
                              pO = vK(OO.attackMs, 0, KO),
                              {
                                intonation: bK
                              } = OO;
                            return {
                              waveform: XO.includes(OO.waveform) ? OO.waveform : "sine",
                              pitchHz: vK(OO.pitchHz, 20, 4e3),
                              glideSemitones: vK(OO.glideSemitones, -24, 24),
                              durationMs: KO,
                              attackMs: pO,
                              releaseMs: vK(OO.releaseMs, 0, KO - pO),
                              lowpassHz: null === OO.lowpassHz ? null : vK(OO.lowpassHz, 20, 2e4),
                              volume: vK(OO.volume, 0, 2),
                              intonation: {
                                variationSemitones: vK(bK.variationSemitones, 0, 6),
                                declineSemitones: vK(bK.declineSemitones, 0, 12),
                                questionRiseSemitones: vK(bK.questionRiseSemitones, 0, 12),
                                exclaimLiftSemitones: vK(bK.exclaimLiftSemitones, 0, 12)
                              },
                              syllableMs: vK(OO.syllableMs, 25, 200)
                            }
                          }
                        }
                      }; Object.freeze(modules);
                      for (const OO in modules) Object.freeze(modules[OO]);