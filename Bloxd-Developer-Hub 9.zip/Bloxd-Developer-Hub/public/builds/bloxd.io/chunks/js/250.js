export const id = 250;
export const ids = [250];
export const modules = {
  38819: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      f: () => lO
    });
    var XO = pO(1561);
    let bK = !1;

    function eO() {
      bK = !0
    }

    function lO() {
      bK && (bK = !1, (0, XO.d)())
    }
  },
  38831: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      g: () => lO
    });
    var XO = pO(2567);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= pO.e(193).then((() => pO(34916))).then((OO => {
        let {
          ITEM_SPRITES: KO,
          ITEM_SPRITES_WITHOUT_FILE: pO,
          ITEM_FILES_WITHOUT_SPRITE: eO
        } = OO;
        bK = function(OO, KO, pO) {
          const bK = new Set,
            eO = (0, XO.w)(KO);
          let lO = 0;
          for (const [XO, vK] of OO.entries()) XO === eO[lO] ? lO++ : bK.add(vK);
          if ("" !== pO)
            for (const vK of pO.split(XO.r)) bK.add(vK);
          return bK
        }(KO.split(XO.r), pO, eO)
      }), (OO => {
        throw eO = null, OO
      })), eO
    }

    function vK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = bK) || void 0 === pO ? void 0 : pO.has(OO)) && void 0 !== KO && KO
    }
  },
  38812: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadIcons: () => uO,
      setIconFileOverrides: () => EO,
      wasmIconLookups: () => HO,
      wasmIconQueries: () => sO
    });
    var XO = pO(3692),
      bK = pO(3660),
      eO = pO(38819),
      lO = pO(1561),
      vK = pO(1556),
      CO = pO(2560),
      hO = pO(2567);
    let DO = null,
      MO = null;

    function aK(OO) {
      const KO = OO.startsWith(hO.k),
        [pO, XO = pO, bK = pO] = (KO ? OO.slice(hO.k.length) : OO).split(hO.g);
      return {
        top: pO,
        left: XO,
        right: bK,
        half: KO
      }
    }

    function oO(OO) {
      const KO = null === DO ? void 0 : (0, CO.c)(OO),
        pO = void 0 === KO ? 0 : DO.codes[KO];
      return 0 === pO ? void 0 : DO.pool[pO - 1]
    }
    var FO = pO(2557),
      VO = pO(3647),
      LO = pO(3686),
      QO = pO(38828);
    const zK = "item:";
    let AO = null,
      fO = null,
      dO = null,
      TO = null,
      NO = !1,
      IO = !1,
      yK = null,
      gK = 0;

    function uO() {
      return IO || (IO = !0, (0, LO.h)().then((OO => {
        OO && (0, lO.d)()
      }))), dO ??= Promise.all([(0, FO.h)(), (MO ??= pO.e(1).then((() => pO(40657))).then((OO => {
        let {
          BLOCK_FACE_RUNS: KO,
          BLOCK_FACES: pO,
          MAX_FACE_ITEM_ID: XO
        } = OO;
        DO = {
          codes: (0, hO.A)(KO, XO + 1),
          pool: pO.split(hO.r).map(aK)
        }
      }), (OO => {
        throw MO = null, OO
      })), MO), (0, QO.g)(), pO.e(199).then((() => pO(35217)))]).then((OO => {
        let [, , KO, pO] = OO;
        KO.loadBundledTextures(), AO = KO, fO = pO, (0, lO.d)()
      }), (OO => {
        dO = null, console.warn("[bloxd-wasm-client] the item icon tables did not load, so item icons stay blank", OO)
      })), dO
    }

    function EO(OO) {
      yK = OO, gK++, (0, lO.d)()
    }

    function jK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = yK) || void 0 === pO ? void 0 : pO.itemSprite(OO)) && void 0 !== KO ? KO : AO.itemSpriteUrl(OO)
    }

    function YO(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = yK) || void 0 === pO ? void 0 : pO.blockTexture(OO)) && void 0 !== KO ? KO : AO.blockTextureUrl(OO)
    }

    function wO(OO) {
      var KO;
      return null !== (KO = (0, FO.d)(OO)) && void 0 !== KO ? KO : OO
    }

    function iK(OO, KO) {
      var pO, XO, bK;
      return null !== (pO = null !== (XO = null !== (bK = YO(OO)) && void 0 !== bK ? bK : null === KO || void 0 === KO ? void 0 : KO.rotated[OO]) && void 0 !== XO ? XO : null === KO || void 0 === KO ? void 0 : KO.animated[OO]) && void 0 !== pO ? pO : AO.notFoundUrl()
    }

    function rK(OO) {
      return void 0 !== (0, CO.c)(OO) ? OO : /^[1-9][0-9]*$/.test(OO) ? (0, CO.e)(Number(OO)) : void 0
    }

    function PO(OO) {
      var KO;
      if (OO.startsWith(zK)) {
        var pO;
        const KO = (0, FO.d)(OO.slice(5));
        return null !== (pO = void 0 === KO ? null : jK(KO)) && void 0 !== pO ? pO : AO.notFoundUrl()
      }
      return null !== (KO = AO.particleUrl(OO)) && void 0 !== KO ? KO : AO.notFoundUrl()
    }

    function mK(OO, KO) {
      return "StairsBlock" === OO ? OO : KO ? "SlabBlock" : "CubeBlock"
    }
    const sO = {
        async blockIcon(OO) {
          var KO;
          let {
            name: XO,
            size: bK,
            lineWidth: eO
          } = OO;
          await uO();
          const vK = null !== (KO = rK(XO)) && void 0 !== KO ? KO : XO,
            hO = (0, LO.e)(vK, bK, eO);
          if (null !== hO) return hO;
          const DO = oO(vK),
            MO = (0, CO.c)(vK),
            aK = void 0 === MO || null === fO ? void 0 : fO.itemTypeNameOf(MO);
          if (null === AO || void 0 === DO) return "";
          const FO = [DO.top, DO.left, DO.right].some((OO => null === YO(OO))),
            QO = FO ? await (TO ??= pO.e(187).then((() => pO(33017))).then((OO => (NO && (NO = !1, (0, lO.d)()), {
              rotated: OO.rotatedBlockTextures,
              animated: OO.animatedBlockTextures
            })), (OO => (TO = null, NO = !0, console.warn("[bloxd-wasm-client] the built block atlas did not load, so some block icons stay blank", OO), null))), TO) : null;
          if (FO && null === QO) return "";
          const zK = {
              top: iK(DO.top, QO),
              left: iK(DO.left, QO),
              right: iK(DO.right, QO),
              itemType: mK(aK, DO.half)
            },
            dO = 0 === gK ? vK : `${vK}#${gK}`;
          return (await (0, VO.d)()).drawBlockIconUrl(dO, bK, eO, (() => zK))
        }
      },
      HO = {
        itemIcon: function(OO) {
          var KO, pO;
          if (null === AO) return uO(), vK.DEFAULT_CLIENT_PAGE_SOURCES.lookups.itemIcon(OO);
          if ((0, bK.g)(OO)) return {
            kind: "icon",
            url: null !== (pO = AO.ingameIconUrl(OO)) && void 0 !== pO ? pO : AO.notFoundUrl()
          };
          if (OO.startsWith(bK.b)) return {
            kind: "icon",
            url: PO(OO.slice(bK.b.length))
          };
          if (0 === (0, CO.f)()) return (0, eO.d)(), vK.DEFAULT_CLIENT_PAGE_SOURCES.lookups.itemIcon(OO);
          const lO = null !== (KO = rK(OO)) && void 0 !== KO ? KO : OO,
            hO = (0, CO.c)(lO),
            DO = void 0 === hO ? void 0 : fO.itemTypeNameOf(hO);
          if (void 0 !== oO(lO)) return {
            kind: "drawnBlock"
          };
          const MO = function(OO) {
            var KO;
            return null !== (KO = jK(wO(OO))) && void 0 !== KO ? KO : AO.notFoundUrl()
          }(lO);
          if ((0, LO.f)(lO) && ! function(OO) {
              return null !== yK && (null !== yK.itemSprite(wO(OO)) || null !== yK.model(OO))
            }(lO)) return {
            kind: "model",
            url: MO
          };
          if ("Gun" === DO) return {
            kind: "gun",
            url: MO
          };
          if (void 0 !== hO && "GrayscaleArmour" === fO.itemTypeOf(hO) || Object.hasOwn(XO.e, lO)) {
            var aK;
            const KO = null !== (aK = (0, XO.h)(OO)) && void 0 !== aK ? aK : (0, XO.h)(lO);
            if (KO) return {
              kind: "item",
              url: MO,
              tint: KO
            }
          }
          return {
            kind: "item",
            url: MO
          }
        },
        hasIcon: function(OO) {
          return void 0 !== rK(OO) || (0, bK.g)(OO) || OO.startsWith(bK.b)
        },
        isItemName: function(OO) {
          return void 0 !== rK(OO)
        }
      }
  },
  38828: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => vK
    });
    var XO = pO(38831);
    let bK = null,
      eO = null;

    function lO() {
      return bK ??= pO.e(53).then((() => pO(40661))).catch((OO => {
        throw bK = null, OO
      })), bK
    }

    function vK() {
      return eO ??= Promise.all([lO(), (0, XO.g)()]).then((OO => {
        let [KO] = OO;
        return KO
      }), (OO => {
        throw eO = null, OO
      })), eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);