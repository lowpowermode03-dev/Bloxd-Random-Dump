export const id = 51;
export const ids = [51];
export const modules = {
  37020: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      e: () => eO
    });
    const XO = new WeakMap;

    function bK(OO, KO) {
      return XO.set(OO, KO), OO
    }

    function eO(OO) {
      var KO;
      return null !== (KO = XO.get(OO)) && void 0 !== KO ? KO : null
    }
  },
  41314: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      WasmPreviewHost: () => AK,
      pageBuiltInAnimationPack: () => aK,
      pagePreviews: () => UO,
      previewModule: () => ZO
    });
    var XO = pO(2951),
      bK = pO(536);
    const eO = "[bloxd-wasm-client]";

    function lO(OO) {
      const KO = {
        wasm: "unknown",
        client: String(bK.e)
      };
      try {
        var pO;
        KO.wasm = null !== (pO = null === OO || void 0 === OO ? void 0 : OO.uO()) && void 0 !== pO ? pO : KO.wasm
      } catch {}
      return KO
    }
    async function vK(OO) {
      if (OO.length < 2 || 31 !== OO[0] || 139 !== OO[1]) return OO;
      if ("undefined" === typeof DecompressionStream) {
        const {
          ungzip: KO
        } = await pO.e(206).then((() => pO(35443)));
        return KO(OO)
      }
      const KO = new Blob([OO]).stream().pipeThrough(new DecompressionStream("gzip"));
      return new Uint8Array(await new Response(KO).arrayBuffer())
    }

    function CO(OO, KO, XO, bK) {
      Promise.resolve().then((() => pO(39002))).then((pO => {
        let {
          reportDataLoadFailure: eO
        } = pO;
        eO(OO, KO, XO, bK)
      }), (KO => {
        console.warn(`${eO} ${OO} didn't load, and the report couldn't be sent`, XO.error, KO)
      }))
    }
    const hO = [3e4, 12e4, 3e5];
    class DO {
      constructor(OO) {
        this.deps = OO, this.loading = null, this.reported = !1, this.retries = 0, this.resolveSet = () => {}, this.set = new Promise((OO => {
          this.resolveSet = OO
        }))
      }
      provide(OO) {
        return this.loading ??= this.load(OO), this.loading
      }
      whenSet() {
        return this.set
      }
      async load(OO) {
        const KO = lO(OO),
          pO = await async function(OO, KO) {
            let pO;
            try {
              pO = await OO()
            } catch (XO) {
              return {
                stage: "fetch",
                error: XO
              }
            }
            try {
              return KO(pO) ? null : {
                stage: "decode",
                error: null
              }
            } catch (XO) {
              return {
                stage: "decode",
                error: XO
              }
            }
          }((() => this.deps.fetch()), (KO => {
            const pO = OO.boO(KO);
            return pO && this.resolveSet(KO), pO
          }));
        if (null !== pO) {
          if ("fetch" === pO.stage) {
            this.loading = null;
            const KO = hO[this.retries++];
            void 0 !== KO && this.deps.later((() => {
              this.provide(OO)
            }), KO)
          }
          this.reported || (this.reported = !0, this.deps.onFailed(pO, KO))
        }
      }
    }
    let MO = null;

    function aK() {
      return MO ??= new DO({
        fetch: async () => vK(await (0, XO.y)(oO(), {
          priority: "low"
        })),
        onFailed: (OO, KO) => {
          CO("builtInAnimations", oO(), OO, KO)
        },
        later: (OO, KO) => {
          setTimeout(OO, KO)
        }
      }), MO
    }

    function oO() {
      return pO(41318)
    }
    var FO = pO(2947),
      VO = pO(34910),
      LO = pO(38841),
      QO = pO(1056),
      zK = pO(236),
      AO = pO(38855),
      fO = pO(39075),
      dO = pO(39020),
      TO = pO(39026),
      NO = pO(39029),
      IO = pO(38867),
      yK = pO(39089),
      gK = pO(39096),
      uO = pO(38873),
      EO = pO(38959),
      jK = pO(39059),
      YO = pO(39083),
      wO = pO(40627),
      iK = pO(38871);
    const rK = "[bloxd-previews]",
      PO = 4e5,
      mK = 0,
      sO = 1,
      HO = 1,
      RO = 2,
      SO = 3,
      JO = 0,
      cK = 1,
      BO = 2;

    function ZO(OO) {
      const KO = OO,
        pO = (0, AO.L)(OO),
        XO = (0, AO.q)(OO);
      return null !== pO && null !== XO && "function" === typeof KO.kaO && "function" === typeof KO.paO && "function" === typeof KO.XaO ? KO : null
    }

    function GO(OO, KO, pO) {
      let [XO, bK] = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [OO, KO], eO = Math.min(Number.isFinite(pO) && pO > 0 ? pO : 1, 2);
      const lO = Math.max(0, XO, OO) * Math.max(0, bK, KO) * eO * eO;
      return lO > PO && (eO *= Math.sqrt(PO / lO)), [Math.max(1, Math.floor(Math.max(0, OO) * eO)), Math.max(1, Math.floor(Math.max(0, KO) * eO))]
    }

    function qK() {
      return pO(41320)
    }
    async function xK(OO, KO) {
      const XO = await (0, uO.J)();
      if (null === XO || (0, AO.s)(XO) || "webgpu" !== XO.backend || (0, uO.e)()) return;
      const bK = (0, AO.O)(OO);
      if (null !== bK) {
        const pO = `WebGPU failed at home (${OO}${void 0===KO?"":`: ${KO instanceof Error?KO.message:(0,iK.d)(KO)}`}) and ${bK}`;
        return console.warn(`${rK} ${pO}: the previews stop`, null !== KO && void 0 !== KO ? KO : ""), void(0, uO.s)(pO)
      }(0, uO.p)();
      try {
        await async function(OO, KO, XO) {
          var bK;
          const eO = (0, FO.S)(),
            {
              flushCrashReports: vK,
              reportRenderReload: CO
            } = await Promise.resolve().then((() => pO(39002)));
          CO("webgpu", "start_failed" === OO ? 0 : 1, lO(eO ? (0, FO.G)() : null), {
            cause: OO,
            error: "lost" === OO && null !== (bK = (0, AO.S)(eO ? (0, AO.L)((0, FO.G)()) : null)) && void 0 !== bK ? bK : KO,
            context: {
              adapter: XO,
              boundAtMs: "start_failed" === OO ? null : (0, uO.H)()
            }
          }), await vK(EO.e)
        }(OO, KO, XO.adapter)
      } catch (eO) {
        console.warn(`${rK} WebGPU failed at home (${OO}), and its report couldn't be sent`, eO)
      }(0, EO.m)()
    }
    async function nO() {
      if (!(0, FO.S)()) {
        const OO = await (0, uO.J)();
        if (null === OO || (0, AO.s)(OO)) return null;
        if (await (0, VO.h)(await OO.load(), LO.e), !(0, FO.S)()) return null
      }
      return ZO((0, FO.G)())
    }
    class WO {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.page = OO, this.host = KO, this.id = pO, this.canvas = XO, this.size = bK, this.models = void 0, this.images = void 0, this.write = void 0, this.outcomes = [], this.closed = !1, this.quiet = 0, this.settled = [];
        const lO = {
            ...eO.images,
            glbUrl: OO => {
              var KO;
              return null !== (KO = this.models.drawnUrl(OO)) && void 0 !== KO ? KO : eO.images.glbUrl(OO)
            }
          },
          vK = KO => OO.modelFile(KO);
        this.images = new fO.d(lO, (OO => {
          console.warn(`${rK} image ${OO.key.kind}:${OO.key.index}:${OO.key.word} failed`, OO.error)
        }), {
          fetchFile: vK,
          fetchImage: KO => OO.imageFile(KO)
        }), OO.startModels(), this.models = new dO.h(eO.files, ((KO, pO) => OO.buildModel(KO, pO)), (OO => {
          console.warn(`${rK} model file ${OO.file} (${OO.url}) failed`, OO.error)
        }), {
          fetchFile: vK,
          onWritten: (OO, KO) => {
            this.images.glbWritten(OO, KO)
          },
          onTaken: (OO, KO) => {
            this.images.glbTaken(OO, KO)
          }
        }), this.write = (OO, KO, pO) => {
          if (this.closed) return !0;
          if (OO === dO.d) {
            const OO = new DataView(pO.buffer, pO.byteOffset, NO.d),
              XO = OO.getUint32(0, !0),
              bK = OO.getUint32(NO.f, !0),
              eO = this.page.hostCall(BO, (() => this.host.zFO(this.id, XO, KO, pO.subarray(NO.d))));
            return this.outcomes.push([bK, eO]), !0
          }
          return OO === fO.c && (this.page.hostCall(void 0, (() => {
            this.host.foO(this.id, pO)
          })), !0)
        }
      }
      get isClosed() {
        return this.closed
      }
      get isStopped() {
        return this.page.isStopped
      }
      resize(OO, KO, pO) {
        if (this.closed) return;
        const [XO, bK] = GO(OO, KO, this.page.dpr(), pO);
        XO === this.size[0] && bK === this.size[1] || (this.size = [XO, bK], this.page.hostCall(void 0, (() => {
          this.host.resize(this.id, XO, bK)
        })))
      }
      setMob(OO, KO, pO, XO) {
        return this.closed ? 0 : this.page.hostCall(0, (() => this.page.called(this.host.yFO(this.id, OO, KO, pO, XO))))
      }
      setPet(OO, KO, pO, XO) {
        return this.closed ? 0 : this.page.hostCall(0, (() => this.page.called(this.host.uoO(this.id, OO, KO, pO, XO))))
      }
      setPlayer(OO, KO, pO) {
        return this.closed ? 0 : this.page.hostCall(0, (() => this.page.called(this.host.ToO(this.id, OO, KO, pO))))
      }
      setFigure(OO, KO, pO, XO) {
        return this.closed ? 0 : this.page.hostCall(0, (() => this.page.called(this.host.NoO(this.id, OO, KO, pO, XO))))
      }
      replay() {
        return this.closed ? 0 : this.page.hostCall(0, (() => this.page.called(this.host.replay(this.id))))
      }
      get orbit() {
        if (this.closed) return null;
        const OO = this.page.hostCall(null, (() => this.host.orbit(this.id)));
        return null === OO || OO.length < 3 ? null : {
          alpha: OO[0],
          beta: OO[1],
          radius: OO[2]
        }
      }
      setOrbit(OO) {
        let {
          alpha: KO,
          beta: pO,
          radius: XO
        } = OO;
        this.closed || this.page.hostCall(void 0, (() => {
          this.host.gFO(this.id, KO, pO, XO)
        }))
      }
      untilSettled() {
        return this.closed || this.page.isStopped ? Promise.resolve() : (this.quiet = 0, new Promise((OO => {
          this.settled.push(OO)
        })))
      }
      packChanged() {
        this.quiet = 0, this.models.refresh(), (0, yK.h)(this.images)
      }
      feed() {
        this.models.drain(this.write);
        for (const [OO, KO] of this.outcomes) {
          const pO = KO === JO ? [] : [KO === cK ? OO : (OO | dO.g) >>> 0];
          this.models.taken(OO, pO)
        }
        this.outcomes.length = 0, this.images.drain(this.write)
      }
      collect(OO) {
        let KO = !1;
        if (OO) {
          const OO = this.host.woO(this.id);
          for (const KO of OO) this.models.request(KO);
          const pO = this.host.YoO(this.id);
          pO.length > 0 && this.images.onEvent(pO), KO = OO.length > 0 || pO.length > 0
        }
        const pO = this.page.modelsUnavailable ? 0 : this.models.asking + this.models.unanswered,
          XO = KO || pO > 0 || this.images.waiting > 0 || this.images.inFlight > 0;
        this.quiet = XO ? 0 : this.quiet + 1, this.quiet >= 3 && this.resolveSettled()
      }
      close() {
        this.closed || (this.closed = !0, this.page.closePreview(this), this.resolveSettled())
      }
      abandon() {
        this.resolveSettled()
      }
      dispose(OO) {
        this.page.hostCall(void 0, (() => {
          const KO = this.host.close(this.id);
          KO.length > 0 && this.images.onEvent(KO), this.page.isTrapped || OO.XaO(this.id)
        })), this.images.dispose(), this.canvas.remove()
      }
      resolveSettled() {
        const OO = this.settled;
        this.settled = [];
        for (const KO of OO) KO()
      }
    }
    class tK {
      constructor(OO) {
        this.deps = OO, this.module = null, this.host = null, this.opening = null, this.pageCanvas = null, this.samples = 1, this.binding = null, this.sessionEnds = 0, this.lastEndReturned = !0, this.previews = new Map, this.nextId = 1, this.frameId = null, this.stopped = !1, this.loggedErrors = new Set, this.modelsListener = {
          onUnavailable: OO => {
            this.modelsFailed(OO)
          },
          onDecoderFailed: OO => {
            this.loggedErrors.has("modelDecoder") || (this.loggedErrors.add("modelDecoder"), console.warn(`${rK} the Draco decoder didn't load: models waiting on it won't draw`, OO))
          },
          onWorkerLost: OO => {
            this.loggedErrors.has("modelWorker") || (this.loggedErrors.add("modelWorker"), console.warn(`${rK} a model worker was lost: ${OO}`))
          }
        }, this.modelsRestarted = !1, this.costs = [], this.models = null, this.unavailable = !1, this.animations = null, this.animationTable = null, this.moduleLoad = null, this.prefetched = !1, this.prefetchedFiles = new Map, this.shaderPackArgs = null, this.hX = {
          setShaderPack: (OO, KO, pO, XO, bK) => (this.shaderPackArgs = [OO, KO, pO, XO, bK], this.handOverShaderPack(), !0)
        }, this.frame = OO => {
          this.frameId = null;
          const KO = this.host;
          if (null !== KO && 0 !== this.previews.size && !this.settleIfTrapped() && !this.stopped) try {
            this.drawFrame(KO, OO)
          } catch (pO) {
            if (!this.stopIfTrapped(pO) && (this.stop(), (0, AO.t)(pO))) return void this.deps.onWebGpuFailed("frames_refused", pO);
            console.warn(`${rK} the previews stopped: their frame threw`, pO)
          }
        }, OO.pack.onChange((() => {
          this.packChanged()
        })), OO.game.onGameChange((() => {
          this.tellInGame()
        }))
      }
      packChanged() {
        if (!this.stopped)
          for (const OO of this.previews.values()) OO.packChanged()
      }
      dpr() {
        return this.deps.dpr()
      }
      get sessionBound() {
        var OO, KO;
        return null !== (OO = null === (KO = this.host) || void 0 === KO ? void 0 : KO.attached()) && void 0 !== OO && OO
      }
      get open() {
        return this.previews.size
      }
      get frameCostMs() {
        return 0 === this.costs.length ? 0 : this.costs.reduce(((OO, KO) => OO + KO), 0) / this.costs.length
      }
      async bindSession(OO, KO, pO) {
        const XO = this.binding,
          bK = this.sessionEnds;
        try {
          const eO = this.hostOf(OO);
          if (!eO.AoO()) {
            const KO = (0, jK.d)().sampleCount,
              lO = await pO(KO);
            if (this.sessionEnds !== bK) return this.keepRendererOfEndedSession(OO, eO, lO, KO, XO), KO;
            if (!eO.OoO(lO)) throw new Error("the page has a renderer already");
            (0, uO.w)(performance.now()), this.samples = KO, (0, YO.h)((0, AO.q)(OO))
          }
          if (!eO.attach(KO)) throw new Error("the page's renderer is lent to another session");
          return this.samples
        } finally {
          this.binding === XO && this.endBinding()
        }
      }
      keepRendererOfEndedSession(OO, KO, pO, XO, bK) {
        if (!this.lastEndReturned || null !== this.binding && this.binding !== bK) try {
          pO.free()
        } catch (eO) {
          console.warn(`${rK} an ended session's renderer didn't free`, eO)
        } else KO.OoO(pO) && ((0, uO.w)(performance.now()), this.samples = XO, (0, YO.h)(this.registryOf(OO)))
      }
      async beginSession() {
        var OO;
        let KO = () => {};
        const pO = new Promise((OO => {
          KO = OO
        }));
        this.binding = {
          done: pO,
          release: KO
        }, await (null === (OO = this.opening) || void 0 === OO ? void 0 : OO.catch((() => null)));
        const XO = this.pageCanvas;
        return this.pageCanvas = null, XO
      }
      endSession(OO) {
        var KO, pO;
        if (this.sessionEnds++, this.lastEndReturned = OO, this.endBinding(), OO) {
          try {
            var XO;
            null === (XO = this.host) || void 0 === XO || XO.detach()
          } catch (bK) {
            return void console.warn(`${rK} the session's core kept the page's renderer`, bK)
          }!0 === (null === (KO = this.host) || void 0 === KO ? void 0 : KO.attached()) && console.warn(`${rK} the session's core kept the page's renderer: it ended inside its frame`), null !== this.module && !0 === (null === (pO = this.host) || void 0 === pO ? void 0 : pO.AoO()) && (0, YO.h)(this.registryOf(this.module))
        }
      }
      endBinding() {
        var OO;
        null === (OO = this.binding) || void 0 === OO || OO.release(), this.binding = null
      }
      async openPreview(OO, KO, pO, XO) {
        const bK = await this.renderingHost(),
          eO = this.module;
        if (null === bK || null === eO) throw new Error("this page can't draw previews: it has no renderer build");
        if (this.animations ??= this.loadAnimations(bK), this.deps.pack.wanted(), this.isStopped) throw new Error("the previews stopped");
        this.guarded((() => {
          this.deps.provideBuiltInAnimationPack(eO)
        }));
        const lO = this.nextId++,
          vK = this.deps.createCanvas(),
          [CO, hO] = GO(KO, pO, this.deps.dpr(), XO);
        vK.width = CO, vK.height = hO;
        if (!this.guarded((() => (eO.paO(lO, vK), bK.open(lO, CO, hO, OO))))) throw this.hostCall(void 0, (() => {
          eO.XaO(lO)
        })), new Error("the page's renderer is lent to a session that is running");
        this.restartModelsIfFailed();
        const DO = new WO(this, bK, lO, vK, [CO, hO], this.deps);
        return this.previews.set(lO, DO), this.startFrames(), DO
      }
      prefetch() {
        if (this.prefetched || this.isStopped || (0, uO.e)() || null !== (0, uO.F)()) return;
        this.prefetched = !0;
        (null === this.module ? this.loadModule() : Promise.resolve(this.module)).then((OO => {
          null === OO || this.isStopped || (this.startModels(), this.fetchAnimationTable().catch((() => {})), this.prefetchPlayerFiles())
        }), (() => {}))
      }
      modelFile(OO) {
        return this.prefetchedOr(OO, this.deps.fetchModel)
      }
      imageFile(OO) {
        return this.prefetchedOr(OO, XO.y)
      }
      prefetchedOr(OO, KO) {
        const pO = this.prefetchedFiles.get(OO);
        return void 0 === pO ? KO(OO) : pO.catch((() => KO(OO)))
      }
      async prefetchPlayerFiles() {
        const OO = this.deps.playerFile().then((OO => this.deps.files.url(OO))),
          KO = await Promise.all([OO, this.deps.images.lifeformAtlasUrl(yK.b)]).catch((() => null));
        if (null === KO) return;
        const [pO, XO] = KO, bK = (OO, KO) => {
          if (null === OO) return;
          const pO = KO(OO);
          this.prefetchedFiles.set(OO, pO), pO.catch((() => {
            this.prefetchedFiles.delete(OO)
          }))
        };
        bK(pO, (OO => this.modelFile(OO))), bK(XO, (OO => this.imageFile(OO)))
      }
      loadModule() {
        return this.moduleLoad ??= this.deps.loadModule().then((OO => (null === OO && (this.moduleLoad = null), OO)), (OO => {
          throw this.moduleLoad = null, OO
        })), this.moduleLoad
      }
      fetchAnimationTable() {
        return this.animationTable ??= this.deps.fetchAnimations().catch((OO => {
          throw this.animationTable = null, OO
        })), this.animationTable
      }
      get modelsUnavailable() {
        return this.unavailable
      }
      startModels() {
        this.models ??= this.deps.startModels(this.modelsListener).catch((OO => (this.modelsFailed(OO), () => new Promise((() => {})))))
      }
      buildModel(OO, KO) {
        return this.startModels(), this.models.then((pO => pO(OO, KO))).then((OO => this.unavailable ? new Promise((() => {})) : OO))
      }
      restartModelsIfFailed() {
        this.unavailable && !this.modelsRestarted && 0 === this.previews.size && (this.modelsRestarted = !0, this.models = null, this.unavailable = !1, this.startModels())
      }
      modelsFailed(OO) {
        this.unavailable = !0, this.loggedErrors.has("models") || (this.loggedErrors.add("models"), console.warn(`${rK} the model workers didn't start: models won't draw in the previews`, OO))
      }
      called(OO) {
        return 0 !== OO && this.logError(OO, 0), OO
      }
      closePreview(OO) {
        this.previews.delete(OO.id), null !== this.module && OO.dispose(this.module), 0 === this.previews.size && null !== this.frameId && (this.deps.cancelFrame(this.frameId), this.frameId = null)
      }
      hostOf(OO) {
        if (null !== this.module && this.module !== OO) throw new Error("a second renderer module on one page");
        return this.module = OO, null === this.host && (this.host = this.guarded((() => new OO.kaO)), this.tellInGame(), this.handOverShaderPack()), this.host
      }
      tellInGame() {
        const {
          host: OO
        } = this;
        null !== OO && this.outsideCall("the game's start or end", (() => {
          OO.IoO(this.deps.game.inGame())
        }))
      }
      handOverShaderPack() {
        const {
          host: OO,
          shaderPackArgs: KO
        } = this;
        null !== OO && null !== KO && this.outsideCall("the shader pack's hand-over", (() => {
          OO.GDO(...KO) || console.warn(`${rK} the host refused the shader pack: previews draw without it at home`)
        }))
      }
      outsideCall(OO, KO) {
        try {
          this.hostCall(void 0, KO)
        } catch (pO) {
          this.stop(), console.warn(`${rK} the previews stopped: ${OO} threw`, pO)
        }
      }
      async loadAnimations(OO) {
        const KO = lO(null),
          pO = this.module;
        try {
          KO.wasm = null === pO ? KO.wasm : this.hostCall(KO.wasm, (() => pO.uO()))
        } catch {}
        let XO, bK;
        try {
          XO = await this.fetchAnimationTable()
        } catch (eO) {
          return void this.deps.onAnimationsFailed({
            stage: "fetch",
            error: eO
          }, KO)
        }
        if (!this.settleIfTrapped()) {
          try {
            bK = OO.doO(XO)
          } catch (eO) {
            if (this.stopIfTrapped(eO)) return;
            return void this.deps.onAnimationsFailed({
              stage: "decode",
              error: eO
            }, KO)
          }
          bK || this.deps.onAnimationsFailed({
            stage: "decode",
            error: null
          }, KO)
        }
      }
      async renderingHost() {
        if (null !== this.binding && await this.binding.done, this.settleIfTrapped()) return null;
        const OO = this.host;
        return null !== OO && this.guarded((() => OO.AoO())) ? OO : (this.opening ??= this.openAtHome().finally((() => {
          this.opening = null
        })), this.opening)
      }
      async openAtHome() {
        var OO;
        const KO = null !== (OO = this.module) && void 0 !== OO ? OO : await this.loadModule();
        if (null === KO) return null;
        const pO = this.hostOf(KO),
          XO = () => this.guarded((() => pO.AoO()));
        if (XO()) return pO;
        if (null !== (0, uO.F)() || (0, uO.e)()) return null;
        const bK = this.deps.createCanvas();
        bK.width = 1, bK.height = 1;
        const eO = await this.deps.openExtras();
        if (this.settleIfTrapped()) return null;
        const lO = (0, jK.d)().sampleCount;
        let vK;
        try {
          vK = await (0, AO.w)(KO, "previewRenderer", bK, lO, wO.c, eO)
        } catch (CO) {
          throw CO instanceof IO.b ? this.stopForTrap(CO) : (0, AO.v)(CO) && await this.deps.onWebGpuFailed("start_failed", CO), CO
        }
        return this.guarded((() => pO.OoO(vK))) ? ((0, uO.w)(performance.now()), this.samples = lO, this.pageCanvas = bK, (0, YO.h)(this.registryOf(KO)), pO) : XO() ? pO : null
      }
      startFrames() {
        null !== this.frameId || this.isStopped || (this.frameId = this.deps.requestFrame(this.frame))
      }
      drawFrame(OO, KO) {
        for (const lO of this.previews.values()) lO.feed();
        if (this.stopped) return;
        const pO = this.deps.now(),
          XO = OO.frame(KO);
        this.costs.push(this.deps.now() - pO), this.costs.length > 120 && this.costs.shift();
        const bK = 0 !== (256 & XO),
          eO = 255 & XO;
        for (const lO of this.previews.values()) {
          if (this.stopped) return;
          lO.collect(bK)
        }
        if (!this.stopped) {
          if (bK) {
            const KO = OO.jFO();
            for (let OO = 0; OO + 1 < KO.length; OO += 2) this.logError(KO[OO], KO[OO + 1])
          }
          if (eO === HO) return this.stop(), void this.deps.onWebGpuFailed("lost");
          if (eO === RO) return this.stop(), void this.deps.onFatal(OO.LoO(), OO.QoO());
          if (eO === SO) return this.stop(), void console.warn(`${rK} the previews stopped: the page's renderer went with its session`);
          (0, zK.b)(KO), this.startFrames()
        }
      }
      get isStopped() {
        return this.stopped || this.isTrapped
      }
      get isTrapped() {
        return null !== this.module && ((0, IO.h)(this.module) || "failed" === (0, FO.C)())
      }
      hostCall(OO, KO) {
        if (this.settleIfTrapped()) return OO;
        try {
          return KO()
        } catch (pO) {
          if (this.stopIfTrapped(pO)) return OO;
          throw pO
        }
      }
      guarded(OO) {
        if (this.settleIfTrapped()) throw new Error("the previews stopped: their module trapped");
        try {
          return OO()
        } catch (KO) {
          throw this.stopIfTrapped(KO), KO
        }
      }
      registryOf(OO) {
        return {
          KaO: (KO, pO) => {
            this.hostCall(void 0, (() => {
              OO.KaO(KO, pO)
            }))
          },
          taO: KO => {
            this.hostCall(void 0, (() => {
              OO.taO(KO)
            }))
          }
        }
      }
      settleIfTrapped() {
        return !!this.isTrapped && (this.stopped || (this.stop(), (0, YO.h)(null)), !0)
      }
      stopIfTrapped(OO) {
        return !(null === this.module || !(0, IO.j)(this.module, OO)) && (this.stopForTrap(OO), !0)
      }
      stopForTrap(OO) {
        this.stop(), (0, YO.h)(null), (0, FO.T)(OO)
      }
      stop() {
        this.stopped = !0;
        for (const OO of this.previews.values()) OO.abandon()
      }
      logError(OO, KO) {
        const pO = `${OO}:${KO}`;
        this.loggedErrors.has(pO) || (this.loggedErrors.add(pO), console.warn(`${rK} error ${OO} (detail ${KO})`))
      }
    }
    let kK = null;

    function UO() {
      return kK ??= new tK(function() {
        const OO = (0, TO.u)(QO.clientSideServerUrls.staticUrl, {
          packUrl: OO => {
            var KO, pO;
            return null !== (KO = null === (pO = yK.d.current) || void 0 === pO ? void 0 : pO.modelUrl(OO)) && void 0 !== KO ? KO : null
          }
        });
        return {
          loadModule: nO,
          startModels: async OO => {
            const {
              pageModelPool: KO
            } = await pO.e(38).then((() => pO(41387))), {
              pool: XO
            } = KO(OO);
            return (OO, KO) => XO.build(OO, KO)
          },
          fetchAnimations: async () => vK(await (0, XO.y)(qK())),
          playerFile: async () => (await (0, TO.q)()).PLAYER_FILE,
          onAnimationsFailed: (OO, KO) => {
            CO("previewAnimations", qK(), OO, KO)
          },
          provideBuiltInAnimationPack: OO => {
            aK().provide(OO)
          },
          openExtras: uO.z,
          files: OO,
          images: (0, yK.j)((0, fO.m)(OO.url), (() => yK.d.current)),
          pack: yK.d,
          game: gK.e,
          fetchModel: OO => (0, TO.k)(OO),
          createCanvas: () => document.createElement("canvas"),
          dpr: () => window.devicePixelRatio,
          now: () => performance.now(),
          requestFrame: OO => requestAnimationFrame(OO),
          cancelFrame: OO => {
            cancelAnimationFrame(OO)
          },
          onWebGpuFailed: xK,
          onFatal: (OO, KO) => {
            console.error(`${rK} the previews stopped: renderer error ${OO} (detail ${KO})`)
          }
        }
      }()), kK
    }
    var OK = pO(518),
      KK = pO(37020),
      pK = pO(2560);
    const XK = {
      wave: 0,
      clap: 1,
      point: 2,
      shrug: 3,
      cheer: 4,
      sit: 5,
      beeFly: 6,
      bow: 7,
      jesterDance: 8,
      mobIdle: 9,
      caveGolem: 10,
      magmaGolem: 11,
      frostWraith: 12,
      tikiTerror: 13,
      gunReady: 14,
      gunAimed: 15
    };
    const bp = "[bloxd-previews]",
      eK = new Uint32Array(5);

    function lK(OO) {
      return OK.h.indexOf(OO)
    }
    const vp = new WeakSet;

    function CK(OO) {
      const KO = (0, KK.e)(OO),
        pO = null === KO ? -1 : hK(KO);
      return -1 !== pO ? pO : (vp.has(OO) || (vp.add(OO), console.warn(`${bp} an animation the previews' table lacks: the mob idles instead`)), -1)
    }

    function hK(OO) {
      var KO;
      return null !== (KO = XK[OO]) && void 0 !== KO ? KO : -1
    }

    function DK(OO, KO) {
      const {
        canvas: pO
      } = KO;
      pO.style.width = "100%", pO.style.height = "100%", pO.style.display = "block", OO.appendChild(pO)
    }

    function MK(OO) {
      const KO = OO.getBoundingClientRect();
      return [KO.width, KO.height]
    }
    class ap {
      constructor(OO, KO) {
        this.preview = OO, this.showView = KO
      }
      show(OO) {
        this.showView(this.preview, OO)
      }
      resize(OO, KO) {
        this.preview.resize(OO, KO)
      }
      close() {
        this.preview.close()
      }
    }
    class oK {
      constructor(OO) {
        this.preview = OO, this.ready = void 0, this.dev = void 0, this.built = !1, this.cosmetics = {}, this.emote = null, this.detachControls = void 0, this.detachControls = function(OO) {
          const {
            canvas: KO
          } = OO;
          let pO = null;
          const XO = OO => {
              var XO;
              pO = {
                pointer: OO.pointerId,
                x: OO.clientX,
                y: OO.clientY
              }, null === (XO = KO.setPointerCapture) || void 0 === XO || XO.call(KO, OO.pointerId)
            },
            bK = KO => {
              var XO;
              const bK = OO.orbit;
              if ((null === (XO = pO) || void 0 === XO ? void 0 : XO.pointer) !== KO.pointerId || null === bK) return;
              const eO = KO.clientX - pO.x,
                lO = KO.clientY - pO.y;
              pO = {
                ...pO,
                x: KO.clientX,
                y: KO.clientY
              }, OO.setOrbit({
                alpha: bK.alpha - .01 * eO,
                beta: Math.min(Math.PI - .01, Math.max(.01, bK.beta - .01 * lO)),
                radius: bK.radius
              })
            },
            eO = OO => {
              var KO;
              (null === (KO = pO) || void 0 === KO ? void 0 : KO.pointer) === OO.pointerId && (pO = null)
            },
            lO = KO => {
              const pO = OO.orbit;
              if (null === pO) return;
              KO.preventDefault();
              const XO = KO.deltaY * (KO.deltaMode === WheelEvent.DOM_DELTA_LINE ? 40 : KO.deltaMode === WheelEvent.DOM_DELTA_PAGE ? 800 : 1),
                bK = Math.min(100, Math.max(5, pO.radius + .08 * XO));
              OO.setOrbit({
                ...pO,
                radius: bK
              })
            };
          return KO.style.touchAction = "none", KO.addEventListener("pointerdown", XO), KO.addEventListener("pointermove", bK), KO.addEventListener("pointerup", eO), KO.addEventListener("pointercancel", eO), KO.addEventListener("wheel", lO, {
            passive: !1
          }), () => {
            KO.removeEventListener("pointerdown", XO), KO.removeEventListener("pointermove", bK), KO.removeEventListener("pointerup", eO), KO.removeEventListener("pointercancel", eO), KO.removeEventListener("wheel", lO)
          }
        }(OO), this.dev = {
          setCamera: KO => {
            let {
              yaw: pO,
              pitch: XO,
              radius: bK
            } = KO;
            const eO = OO.orbit;
            null !== eO && OO.setOrbit({
              alpha: pO,
              beta: XO,
              radius: null !== bK && void 0 !== bK ? bK : eO.radius
            })
          },
          canvas: () => OO.canvas,
          isolateHead: () => {
            console.warn(`${bp} isolateHead: noa's character preview only`)
          }
        }, this.apply(), this.ready = OO.untilSettled().then((() => {
          if (OO.isStopped) throw new Error(`${bp} the previews stopped before the character drew`);
          this.built = !0
        }))
      }
      isReady() {
        return this.built && !this.preview.isClosed
      }
      setCosmetic(OO, KO) {
        this.cosmetics[OO] = KO, this.apply()
      }
      playEmote(OO) {
        null === OO || OO !== this.emote ? (this.emote = OO, this.apply()) : this.preview.replay()
      }
      untilDrawn(OO) {
        return this.preview.untilSettled()
      }
      resize(OO, KO) {
        this.preview.resize(OO, KO)
      }
      close() {
        this.detachControls(), this.preview.close()
      }
      apply() {
        var OO;
        this.preview.setPlayer(JSON.stringify(this.cosmetics), eK, null === (OO = this.emote) ? -1 : hK(OO))
      }
    }

    function FK(OO, KO) {
      let {
        mobType: pO,
        variation: XO,
        animation: bK
      } = KO;
      OO.setMob(lK(pO), null !== XO && void 0 !== XO ? XO : "", 1, CK(bK))
    }

    function VK(OO, KO) {
      let {
        mobType: pO,
        variation: XO,
        metaInfo: bK,
        tamed: eO
      } = KO;
      OO.setPet(lK(pO), XO, bK, eO)
    }
    const LK = {
      aimed: .533 / 1.15 * 1.1,
      ready: .16 / .85 * 1.1
    };
    class QK {
      constructor(OO, KO, pO, XO) {
        this.preview = null, this.closed = !1, this.figure = null, this.shown = !1, this.order = "", this.span = {
          left: 0,
          width: 0
        }, this.lineup = [0, 0], this.given = null, this.loaded = !1, OO(pO.width, XO[1], XO).then((OO => {
          if (this.closed) return void OO.close();
          const {
            style: pO
          } = OO.canvas;
          pO.position = "absolute", pO.top = "0", pO.visibility = "hidden", DK(KO, OO), this.preview = OO, this.apply()
        })).catch((OO => {
          console.error(`${bp} couldn't open a lineup figure`, OO)
        }))
      }
      update(OO, KO, pO, XO, bK) {
        this.figure = OO, this.shown = KO, this.order = pO, this.span = XO, this.lineup = bK, this.apply()
      }
      close() {
        var OO;
        this.closed = !0, null === (OO = this.preview) || void 0 === OO || OO.close(), this.preview = null
      }
      apply() {
        const {
          preview: OO,
          figure: KO,
          lineup: pO
        } = this;
        if (null === OO || null === KO) return;
        if (this.given !== KO) {
          var XO;
          this.given = KO, this.loaded = !1;
          const pO = null === KO.XE ? 0 : null !== (XO = (0, pK.c)(KO.XE)) && void 0 !== XO ? XO : 0;
          OO.setFigure(function(OO) {
            return JSON.stringify(Object.fromEntries(OO.cosmetics))
          }(KO), pO, CK(KO.animation), KO.size), OO.untilSettled().then((() => {
            this.given === KO && (this.loaded = !0, this.apply())
          }))
        }
        const {
          left: bK,
          width: eO
        } = this.span;
        OO.resize(eO, pO[1], pO);
        const {
          style: lO
        } = OO.canvas;
        lO.left = `${bK}px`, lO.width = `${eO}px`, lO.zIndex = this.order, lO.visibility = this.shown && this.loaded ? "visible" : "hidden"
      }
    }
    class zp {
      constructor(OO, KO) {
        this.open = KO, this.layer = void 0, this.figures = [], this.view = {
          figures: [],
          shown: []
        }, this.size = void 0, this.size = MK(OO), this.layer = document.createElement("div");
        const {
          style: pO
        } = this.layer;
        pO.position = "relative", pO.isolation = "isolate", pO.overflow = "hidden", pO.width = "100%", pO.height = "100%", pO.pointerEvents = "none", OO.appendChild(this.layer)
      }
      show(OO) {
        this.view = OO, this.place()
      }
      resize(OO, KO) {
        this.size = [OO, KO], this.place()
      }
      close() {
        for (const OO of this.figures) OO.close();
        this.figures = [], this.layer.remove()
      }
      place() {
        const {
          figures: OO,
          shown: KO
        } = this.view;
        for (const XO of this.figures.splice(OO.length)) XO.close();
        const {
          size: pO
        } = this;
        OO.forEach(((XO, bK) => {
          var eO;
          const lO = function(OO, KO, pO, XO) {
            let [bK, eO] = XO;
            const lO = (OO + .5) * bK / KO,
              vK = Math.min(Math.max(bK / KO, 2 * pO * eO), 2 * Math.max(lO, bK - lO));
            return {
              left: lO - vK / 2,
              width: vK
            }
          }(bK, OO.length, function(OO) {
            let {
              animation: KO,
              size: pO
            } = OO;
            const {
              aimed: XO,
              ready: bK
            } = LK;
            return (CK(KO) === XK.gunAimed ? XO : bK) * pO
          }(XO), pO);
          this.figures[bK] ??= new QK(this.open, this.layer, lO, pO), this.figures[bK].update(XO, null !== (eO = KO[bK]) && void 0 !== eO && eO, function(OO, KO) {
            return String(Math.round(1e3 * OO) + KO)
          }(XO.size, bK), lO, pO)
        }))
      }
    }
    class AK {
      constructor(OO) {
        this.page = OO
      }
      async openMob(OO) {
        return new ap(await this.open(OO, mK), FK)
      }
      async openPet(OO) {
        return new ap(await this.open(OO, mK), VK)
      }
      openMobLineup(OO) {
        return new zp(OO, ((OO, KO, pO) => this.page.openPreview(mK, OO, KO, pO)))
      }
      async openCharacter(OO) {
        return new oK(await this.open(OO, sO))
      }
      async open(OO, KO) {
        const [pO, XO] = MK(OO), bK = await this.page.openPreview(KO, pO, XO);
        return DK(OO, bK), bK
      }
    }
  },
  35255: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => FO,
      B: () => VO,
      E: () => QO,
      e: () => XO,
      f: () => bK,
      g: () => aK,
      j: () => LO,
      m: () => DO,
      p: () => zK,
      s: () => CO,
      t: () => hO,
      x: () => oO
    });
    const XO = [{
      numLines: 7,
      charsPerLine: 16,
      uiFontSize: 3.3,
      ingameFontSize: 25
    }, {
      numLines: 5,
      charsPerLine: 11,
      uiFontSize: 4.6,
      ingameFontSize: 36
    }, {
      numLines: 3,
      charsPerLine: 7,
      uiFontSize: 7.5,
      ingameFontSize: 58
    }];

    function bK(OO, KO) {
      const {
        numLines: pO,
        charsPerLine: bK
      } = XO[KO];
      return AO(OO, pO, bK, !1)
    }
    const eO = 7 / 8,
      lO = .25,
      vK = 8;

    function CO(OO, KO) {
      return {
        width: Math.min(OO, vK) - 2 * lO,
        height: Math.min(KO, vK) - 2 * lO
      }
    }

    function hO(OO, KO, pO) {
      const bK = CO(OO, KO),
        {
          numLines: lO,
          charsPerLine: vK
        } = XO[pO];
      return {
        numLines: Math.max(1, Math.floor(lO / eO * bK.height)),
        charsPerLine: Math.max(1, Math.floor(vK * bK.width))
      }
    }

    function DO(OO, KO, pO, XO) {
      const {
        numLines: bK,
        charsPerLine: eO
      } = hO(pO, XO, KO);
      return AO(OO, bK, eO, !1)
    }
    const MO = 32e3;

    function aK(OO) {
      return OO.slice(0, MO)
    }
    const oO = 512e3,
      FO = 64,
      VO = oO;

    function LO(OO, KO) {
      const pO = Math.max(0, VO - KO),
        XO = Math.min(oO, pO);
      return OO.slice(0, XO)
    }
    const QO = {
      book: {
        numLines: 13,
        charsPerLine: 19,
        uiFontSize: 1.95
      },
      jG: {
        numLines: 1,
        charsPerLine: 19,
        uiFontSize: 1.95
      },
      nameTag: {
        numLines: 1,
        charsPerLine: 13,
        uiFontSize: 4.6
      }
    };

    function zK(OO, KO) {
      const {
        numLines: pO,
        charsPerLine: XO
      } = QO[KO];
      return AO(OO, pO, XO, !1)
    }

    function AO(OO, KO, pO, XO, bK) {
      (bK || XO) && (OO = OO.slice(0, null !== bK && void 0 !== bK ? bK : KO * pO));
      const eO = OO.split("\n");
      if (eO.length > KO && eO.splice(KO, eO.length - KO), !XO)
        for (let lO = 0; lO < eO.length; lO++) {
          const OO = eO[lO];
          OO.length > pO && (eO[lO] = OO.substring(0, pO), eO.length < KO && eO.splice(lO + 1, 0, OO.substring(pO)))
        }
      return eO.join("\n")
    }
  },
  41318: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/builtInAnimations.anim.36d8b13aae7e273ec8e8.gz"
  },
  41320: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/previewAnimations.dat.24d2343c38c8f9b3fb85.gz"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);