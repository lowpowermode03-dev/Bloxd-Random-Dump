export const id = 331;
export const ids = [331];
export const modules = {
  40579: (OO, KO, pO) => {
    function XO(OO) {
      return Math.floor(OO / 8)
    }

    function bK(OO) {
      return 1 << OO % 8
    }
    pO.d(KO, {
      OptimizeIndices: () => lO
    });
    class eO {
      constructor(OO) {
        this.size = OO, this._byteArray = new Uint8Array(Math.ceil(this.size / 8))
      }
      get(OO) {
        if (OO >= this.size) throw new RangeError("Bit index out of range");
        const KO = XO(OO),
          pO = bK(OO);
        return 0 !== (this._byteArray[KO] & pO)
      }
      set(OO, KO) {
        if (OO >= this.size) throw new RangeError("Bit index out of range");
        const pO = XO(OO),
          eO = bK(OO);
        KO ? this._byteArray[pO] |= eO : this._byteArray[pO] &= ~eO
      }
    }

    function lO(OO) {
      const KO = [],
        pO = OO.length / 3;
      for (let eO = 0; eO < pO; eO++) KO.push([OO[3 * eO], OO[3 * eO + 1], OO[3 * eO + 2]]);
      const XO = new Map;
      for (let eO = 0; eO < KO.length; eO++) {
        const OO = KO[eO];
        for (const KO of OO) {
          let OO = XO.get(KO);
          OO || XO.set(KO, OO = []), OO.push(eO)
        }
      }
      const bK = new eO(pO),
        lO = [],
        vK = OO => {
          const pO = [OO];
          for (; pO.length > 0;) {
            const OO = pO.pop();
            if (!bK.get(OO)) {
              bK.set(OO, !0), lO.push(KO[OO]);
              for (const eO of KO[OO]) {
                const OO = XO.get(eO);
                if (!OO) return;
                for (const KO of OO) bK.get(KO) || pO.push(KO)
              }
            }
          }
        };
      for (let eO = 0; eO < pO; eO++) bK.get(eO) || vK(eO);
      let CO = 0;
      for (const eO of lO) OO[CO++] = eO[0], OO[CO++] = eO[1], OO[CO++] = eO[2]
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);