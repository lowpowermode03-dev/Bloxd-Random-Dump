export const id = 295;
export const ids = [295];
export const modules = {
  39873: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ReadExrDataAsync: () => MK,
      _ExrTextureLoader: () => DK
    });
    var XO = pO(37061),
      bK = pO(35664),
      eO = pO(38140);
    const lO = 4,
      vK = 4,
      CO = 1,
      hO = 2,
      DO = 8,
      MO = 65536,
      aK = MO >> 3,
      oO = 14,
      FO = 65537,
      VO = 1 << oO,
      LO = VO - 1,
      QO = 59,
      zK = 63,
      AO = 2 + zK - QO;
    var fO, dO;

    function TO(OO, KO) {
      const pO = new Uint8Array(OO);
      let XO = 0;
      for (; 0 != pO[KO.value + XO];) XO += 1;
      const bK = (new TextDecoder).decode(pO.slice(KO.value, KO.value + XO));
      return KO.value = KO.value + XO + 1, bK
    }

    function NO(OO, KO) {
      const pO = OO.getInt32(KO.value, !0);
      return KO.value += lO, pO
    }

    function IO(OO, KO) {
      const pO = OO.getUint32(KO.value, !0);
      return KO.value += lO, pO
    }

    function yK(OO, KO) {
      const pO = OO.getUint8(KO.value);
      return KO.value += CO, pO
    }

    function gK(OO, KO) {
      const pO = OO.getUint16(KO.value, !0);
      return KO.value += hO, pO
    }

    function uO(OO, KO) {
      const pO = OO[KO.value];
      return KO.value += CO, pO
    }

    function EO(OO, KO) {
      let pO;
      return pO = "getBigInt64" in DataView.prototype ? Number(OO.getBigInt64(KO.value, !0)) : OO.getUint32(KO.value + 4, !0) + Number(OO.getUint32(KO.value, !0) << 32), KO.value += DO, pO
    }

    function jK(OO, KO) {
      const pO = OO.getFloat32(KO.value, !0);
      return KO.value += vK, pO
    }

    function YO(OO, KO) {
      return (0, eO.d)(gK(OO, KO))
    }

    function wO(OO, KO) {
      return (0, eO.i)((0, bK.Clamp)(jK(OO, KO), -eO.g, eO.g))
    }

    function iK(OO, KO, pO, XO) {
      switch (pO) {
        case "string":
        case "stringvector":
        case "iccProfile":
          return function(OO, KO, pO) {
            const XO = (new TextDecoder).decode(new Uint8Array(OO).slice(KO.value, KO.value + pO));
            return KO.value = KO.value + pO, XO
          }(OO.buffer, KO, XO);
        case "chlist":
          return function(OO, KO, pO) {
            const XO = KO.value,
              bK = [];
            for (; KO.value < XO + pO - 1;) {
              const pO = TO(OO.buffer, KO),
                XO = NO(OO, KO),
                eO = yK(OO, KO);
              KO.value += 3;
              const lO = NO(OO, KO),
                vK = NO(OO, KO);
              bK.push({
                name: pO,
                pixelType: XO,
                pLinear: eO,
                xSampling: lO,
                ySampling: vK
              })
            }
            return KO.value += 1, bK
          }(OO, KO, XO);
        case "chromaticities":
          return function(OO, KO) {
            return {
              redX: jK(OO, KO),
              redY: jK(OO, KO),
              greenX: jK(OO, KO),
              greenY: jK(OO, KO),
              blueX: jK(OO, KO),
              blueY: jK(OO, KO),
              whiteX: jK(OO, KO),
              whiteY: jK(OO, KO)
            }
          }(OO, KO);
        case "compression":
          return function(OO, KO) {
            return yK(OO, KO)
          }(OO, KO);
        case "box2i":
          return function(OO, KO) {
            return {
              xMin: NO(OO, KO),
              yMin: NO(OO, KO),
              xMax: NO(OO, KO),
              yMax: NO(OO, KO)
            }
          }(OO, KO);
        case "lineOrder":
          return function(OO, KO) {
            const pO = yK(OO, KO);
            return dO[pO]
          }(OO, KO);
        case "float":
          return jK(OO, KO);
        case "v2f":
          return function(OO, KO) {
            return [jK(OO, KO), jK(OO, KO)]
          }(OO, KO);
        case "v3f":
          return function(OO, KO) {
            return [jK(OO, KO), jK(OO, KO), jK(OO, KO)]
          }(OO, KO);
        case "int":
          return NO(OO, KO);
        case "rational":
          return function(OO, KO) {
            return [NO(OO, KO), IO(OO, KO)]
          }(OO, KO);
        case "timecode":
          return function(OO, KO) {
            return [IO(OO, KO), IO(OO, KO)]
          }(OO, KO);
        case "preview":
          return KO.value += XO, "skipped";
        default:
          return void(KO.value += XO)
      }
    }

    function rK(OO) {
      for (let KO = 1; KO < OO.length; KO++) {
        const pO = OO[KO - 1] + OO[KO] - 128;
        OO[KO] = pO
      }
    }

    function PO(OO, KO) {
      let pO = 0,
        XO = Math.floor((OO.length + 1) / 2),
        bK = 0;
      const eO = OO.length - 1;
      for (; !(bK > eO) && (KO[bK++] = OO[pO++], !(bK > eO));) KO[bK++] = OO[XO++]
    }! function(OO) {
      OO[OO.NO_COMPRESSION = 0] = "NO_COMPRESSION", OO[OO.RLE_COMPRESSION = 1] = "RLE_COMPRESSION", OO[OO.ZIPS_COMPRESSION = 2] = "ZIPS_COMPRESSION", OO[OO.ZIP_COMPRESSION = 3] = "ZIP_COMPRESSION", OO[OO.PIZ_COMPRESSION = 4] = "PIZ_COMPRESSION", OO[OO.PXR24_COMPRESSION = 5] = "PXR24_COMPRESSION"
    }(fO || (fO = {})),
    function(OO) {
      OO[OO.INCREASING_Y = 0] = "INCREASING_Y", OO[OO.DECREASING_Y = 1] = "DECREASING_Y"
    }(dO || (dO = {}));
    const mK = 20000630;

    function sO(OO, KO) {
      if (OO.getUint32(0, !0) != mK) throw new Error("Incorrect OpenEXR format");
      const pO = OO.getUint8(4),
        bK = OO.getUint8(5),
        eO = {
          singleTile: !!(2 & bK),
          longName: !!(4 & bK),
          deepFormat: !!(8 & bK),
          multiPart: !!(16 & bK)
        };
      KO.value = 8;
      const lO = {};
      let vK = !0;
      for (; vK;) {
        const pO = TO(OO.buffer, KO);
        if (pO) {
          const bK = TO(OO.buffer, KO),
            eO = iK(OO, KO, bK, IO(OO, KO));
          void 0 === eO ? XO.b.Warn(`Unknown header attribute type ${bK}'.`) : lO[pO] = eO
        } else vK = !1
      }
      if (0 != (-5 & bK)) throw new Error("Unsupported file format");
      return {
        version: pO,
        spec: eO,
        ...lO
      }
    }
    const HO = 32768,
      RO = 65535;

    function SO(OO, KO, pO, XO, bK) {
      for (; pO < OO;) KO = KO << 8 | uO(XO, bK), pO += 8;
      return {
        l: KO >> (pO -= OO) & (1 << OO) - 1,
        c: KO,
        lc: pO
      }
    }

    function JO(OO, KO, pO, XO) {
      return {
        c: OO = OO << 8 | uO(pO, XO),
        lc: KO += 8
      }
    }

    function cK(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      if (OO == KO) {
        if (XO < 8) {
          const OO = JO(pO, XO, bK, eO);
          pO = OO.c, XO = OO.lc
        }
        let OO = pO >> (XO -= 8);
        if (OO = new Uint8Array([OO])[0], vK.value + OO > CO) return null;
        const KO = lO[vK.value - 1];
        for (; OO-- > 0;) lO[vK.value++] = KO
      } else {
        if (!(vK.value < CO)) return null;
        lO[vK.value++] = OO
      }
      return {
        c: pO,
        lc: XO
      }
    }
    const BO = new Array(59);

    function ZO(OO, KO, pO, XO, bK, eO) {
      const lO = KO;
      let vK = 0,
        CO = 0;
      for (; XO <= bK; XO++) {
        if (lO.value - KO.value > pO) return;
        let hO = SO(6, vK, CO, OO, lO);
        const DO = hO.l;
        if (vK = hO.c, CO = hO.lc, eO[XO] = DO, DO == zK) {
          if (lO.value - KO.value > pO) throw new Error("Error in HufUnpackEncTable");
          hO = SO(8, vK, CO, OO, lO);
          let DO = hO.l + AO;
          if (vK = hO.c, CO = hO.lc, XO + DO > bK + 1) throw new Error("Error in HufUnpackEncTable");
          for (; DO--;) eO[XO++] = 0;
          XO--
        } else if (DO >= QO) {
          let OO = DO - QO + 2;
          if (XO + OO > bK + 1) throw new Error("Error in HufUnpackEncTable");
          for (; OO--;) eO[XO++] = 0;
          XO--
        }
      }! function(OO) {
        for (let pO = 0; pO <= 58; ++pO) BO[pO] = 0;
        for (let pO = 0; pO < FO; ++pO) BO[OO[pO]] += 1;
        let KO = 0;
        for (let pO = 58; pO > 0; --pO) {
          const OO = KO + BO[pO] >> 1;
          BO[pO] = KO, KO = OO
        }
        for (let pO = 0; pO < FO; ++pO) {
          const KO = OO[pO];
          KO > 0 && (OO[pO] = KO | BO[KO]++ << 6)
        }
      }(eO)
    }

    function GO(OO) {
      return 63 & OO
    }

    function qK(OO) {
      return OO >> 6
    }

    function xK(OO, KO, pO, XO, bK, eO) {
      const lO = pO.value,
        vK = IO(KO, pO),
        CO = IO(KO, pO);
      pO.value += 4;
      const hO = IO(KO, pO);
      if (pO.value += 4, vK < 0 || vK >= FO || CO < 0 || CO >= FO) throw new Error("Wrong HUF_ENCSIZE");
      const DO = new Array(FO),
        MO = new Array(VO);
      ! function(OO) {
        for (let KO = 0; KO < VO; KO++) OO[KO] = {}, OO[KO].len = 0, OO[KO].lit = 0, OO[KO].p = null
      }(MO);
      if (ZO(OO, pO, XO - (pO.value - lO), vK, CO, DO), hO > 8 * (XO - (pO.value - lO))) throw new Error("Wrong hufUncompress");
      ! function(OO, KO, pO, XO) {
        for (; KO <= pO; KO++) {
          const pO = qK(OO[KO]),
            bK = GO(OO[KO]);
          if (pO >> bK) throw new Error("Invalid table entry");
          if (bK > oO) {
            const OO = XO[pO >> bK - oO];
            if (OO.len) throw new Error("Invalid table entry");
            if (OO.lit++, OO.p) {
              const KO = OO.p;
              OO.p = new Array(OO.lit);
              for (let pO = 0; pO < OO.lit - 1; ++pO) OO.p[pO] = KO[pO]
            } else OO.p = new Array(1);
            OO.p[OO.lit - 1] = KO
          } else if (bK) {
            let OO = 0;
            for (let eO = 1 << oO - bK; eO > 0; eO--) {
              const eO = XO[(pO << oO - bK) + OO];
              if (eO.len || eO.p) throw new Error("Invalid table entry");
              eO.len = bK, eO.lit = KO, OO++
            }
          }
        }
      }(DO, vK, CO, MO),
      function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        let hO = 0,
          DO = 0;
        const MO = lO,
          aK = Math.trunc(XO.value + (bK + 7) / 8);
        for (; XO.value < aK;) {
          let bK = JO(hO, DO, pO, XO);
          for (hO = bK.c, DO = bK.lc; DO >= oO;) {
            const lO = KO[hO >> DO - oO & LO];
            if (lO.len) {
              DO -= lO.len;
              const OO = cK(lO.lit, eO, hO, DO, pO, XO, vK, CO, MO);
              OO && (hO = OO.c, DO = OO.lc)
            } else {
              if (!lO.p) throw new Error("hufDecode issues");
              let KO;
              for (KO = 0; KO < lO.lit; KO++) {
                const oO = GO(OO[lO.p[KO]]);
                for (; DO < oO && XO.value < aK;) bK = JO(hO, DO, pO, XO), hO = bK.c, DO = bK.lc;
                if (DO >= oO && qK(OO[lO.p[KO]]) == (hO >> DO - oO & (1 << oO) - 1)) {
                  DO -= oO;
                  const OO = cK(lO.p[KO], eO, hO, DO, pO, XO, vK, CO, MO);
                  OO && (hO = OO.c, DO = OO.lc);
                  break
                }
              }
              if (KO == lO.lit) throw new Error("HufDecode issues")
            }
          }
        }
        const FO = 8 - bK & 7;
        for (hO >>= FO, DO -= FO; DO > 0;) {
          const OO = KO[hO << oO - DO & LO];
          if (!OO.len) throw new Error("HufDecode issues");
          {
            DO -= OO.len;
            const KO = cK(OO.lit, eO, hO, DO, pO, XO, vK, CO, MO);
            KO && (hO = KO.c, DO = KO.lc)
          }
        }
      }(DO, MO, OO, pO, hO, CO, eO, bK, {
        value: 0
      })
    }

    function nO(OO) {
      return 65535 & OO
    }

    function WO(OO) {
      const KO = nO(OO);
      return KO > 32767 ? KO - 65536 : KO
    }

    function tK(OO, KO) {
      const pO = WO(OO),
        XO = WO(KO),
        bK = pO + (1 & XO) + (XO >> 1);
      return {
        a: bK,
        b: bK - XO
      }
    }

    function kK(OO, KO) {
      const pO = nO(OO),
        XO = nO(KO),
        bK = pO - (XO >> 1) & RO;
      return {
        a: XO + bK - HO & RO,
        b: bK
      }
    }

    function UO(OO, KO, pO, XO, bK, eO, lO) {
      const vK = lO < 16384,
        CO = pO > bK ? bK : pO;
      let hO, DO, MO = 1;
      for (; MO <= CO;) MO <<= 1;
      for (MO >>= 1, hO = MO, MO >>= 1; MO >= 1;) {
        DO = 0;
        const lO = DO + eO * (bK - hO),
          CO = eO * MO,
          aK = eO * hO,
          oO = XO * MO,
          FO = XO * hO;
        let VO, LO, QO, zK;
        for (; DO <= lO; DO += aK) {
          let bK = DO;
          const eO = DO + XO * (pO - hO);
          for (; bK <= eO; bK += FO) {
            const pO = bK + oO,
              XO = bK + CO,
              eO = XO + oO;
            if (vK) {
              let lO = tK(OO[bK + KO], OO[XO + KO]);
              VO = lO.a, QO = lO.b, lO = tK(OO[pO + KO], OO[eO + KO]), LO = lO.a, zK = lO.b, lO = tK(VO, LO), OO[bK + KO] = lO.a, OO[pO + KO] = lO.b, lO = tK(QO, zK), OO[XO + KO] = lO.a, OO[eO + KO] = lO.b
            } else {
              let lO = kK(OO[bK + KO], OO[XO + KO]);
              VO = lO.a, QO = lO.b, lO = kK(OO[pO + KO], OO[eO + KO]), LO = lO.a, zK = lO.b, lO = kK(VO, LO), OO[bK + KO] = lO.a, OO[pO + KO] = lO.b, lO = kK(QO, zK), OO[XO + KO] = lO.a, OO[eO + KO] = lO.b
            }
          }
          if (pO & MO) {
            const pO = bK + CO;
            let XO;
            XO = vK ? tK(OO[bK + KO], OO[pO + KO]) : kK(OO[bK + KO], OO[pO + KO]), VO = XO.a, OO[pO + KO] = XO.b, OO[bK + KO] = VO
          }
        }
        if (bK & MO) {
          let bK = DO;
          const eO = DO + XO * (pO - hO);
          for (; bK <= eO; bK += FO) {
            const pO = bK + oO;
            let XO;
            XO = vK ? tK(OO[bK + KO], OO[pO + KO]) : kK(OO[bK + KO], OO[pO + KO]), VO = XO.a, OO[pO + KO] = XO.b, OO[bK + KO] = VO
          }
        }
        hO = MO, MO >>= 1
      }
      return DO
    }

    function OK(OO) {
      return new DataView(OO.array.buffer, OO.offset.value, OO.size)
    }

    function KK(OO) {
      const KO = OO.viewer.buffer.slice(OO.offset.value, OO.offset.value + OO.size),
        pO = new Uint8Array(function(OO) {
          let KO = OO.byteLength;
          const pO = [];
          let XO = 0;
          const bK = new DataView(OO);
          for (; KO > 0;) {
            const OO = bK.getInt8(XO++);
            if (OO < 0) {
              const eO = -OO;
              KO -= eO + 1;
              for (let OO = 0; OO < eO; OO++) pO.push(bK.getUint8(XO++))
            } else {
              const eO = OO;
              KO -= 2;
              const lO = bK.getUint8(XO++);
              for (let OO = 0; OO < eO + 1; OO++) pO.push(lO)
            }
          }
          return pO
        }(KO)),
        XO = new Uint8Array(pO.length);
      return rK(pO), PO(pO, XO), new DataView(XO.buffer)
    }

    function pK(OO) {
      const KO = OO.array.slice(OO.offset.value, OO.offset.value + OO.size),
        pO = fflate.unzlibSync(KO),
        XO = new Uint8Array(pO.length);
      return rK(pO), PO(pO, XO), new DataView(XO.buffer)
    }

    function XK(OO) {
      const KO = OO.array.slice(OO.offset.value, OO.offset.value + OO.size),
        pO = fflate.unzlibSync(KO),
        XO = OO.lines * OO.channels * OO.width,
        bK = 1 == OO.type ? new Uint16Array(XO) : new Uint32Array(XO);
      let eO = 0,
        lO = 0;
      const vK = new Array(4);
      for (let CO = 0; CO < OO.lines; CO++)
        for (let KO = 0; KO < OO.channels; KO++) {
          let KO = 0;
          switch (OO.type) {
            case 1:
              vK[0] = eO, vK[1] = vK[0] + OO.width, eO = vK[1] + OO.width;
              for (let XO = 0; XO < OO.width; ++XO) {
                KO += pO[vK[0]++] << 8 | pO[vK[1]++], bK[lO] = KO, lO++
              }
              break;
            case 2:
              vK[0] = eO, vK[1] = vK[0] + OO.width, vK[2] = vK[1] + OO.width, eO = vK[2] + OO.width;
              for (let XO = 0; XO < OO.width; ++XO) {
                KO += pO[vK[0]++] << 24 | pO[vK[1]++] << 16 | pO[vK[2]++] << 8, bK[lO] = KO, lO++
              }
          }
        }
      return new DataView(bK.buffer)
    }

    function bp(OO) {
      const KO = OO.viewer,
        pO = {
          value: OO.offset.value
        },
        XO = new Uint16Array(OO.width * OO.scanlineBlockSize * (OO.channels * OO.type)),
        bK = new Uint8Array(aK);
      let eO = 0;
      const lO = new Array(OO.channels);
      for (let hO = 0; hO < OO.channels; hO++) lO[hO] = {}, lO[hO].start = eO, lO[hO].end = lO[hO].start, lO[hO].nx = OO.width, lO[hO].ny = OO.lines, lO[hO].size = OO.type, eO += lO[hO].nx * lO[hO].ny * lO[hO].size;
      const vK = gK(KO, pO),
        CO = gK(KO, pO);
      if (CO >= aK) throw new Error("Wrong PIZ_COMPRESSION BITMAP_SIZE");
      if (vK <= CO)
        for (let hO = 0; hO < CO - vK + 1; hO++) bK[hO + vK] = yK(KO, pO);
      const DO = new Uint16Array(MO),
        oO = function(OO, KO) {
          let pO = 0;
          for (let bK = 0; bK < MO; ++bK)(0 == bK || OO[bK >> 3] & 1 << (7 & bK)) && (KO[pO++] = bK);
          const XO = pO - 1;
          for (; pO < MO;) KO[pO++] = 0;
          return XO
        }(bK, DO),
        FO = IO(KO, pO);
      xK(OO.array, KO, pO, FO, XO, eO);
      for (let hO = 0; hO < OO.channels; ++hO) {
        const OO = lO[hO];
        for (let KO = 0; KO < lO[hO].size; ++KO) UO(XO, OO.start + KO, OO.nx, OO.size, OO.ny, OO.nx * OO.size, oO)
      }! function(OO, KO, pO) {
        for (let XO = 0; XO < pO; ++XO) KO[XO] = OO[KO[XO]]
      }(DO, XO, eO);
      let VO = 0;
      const LO = new Uint8Array(XO.buffer.byteLength);
      for (let MO = 0; MO < OO.lines; MO++)
        for (let KO = 0; KO < OO.channels; KO++) {
          const OO = lO[KO],
            pO = OO.nx * OO.size,
            bK = new Uint8Array(XO.buffer, OO.end * hO, pO * hO);
          LO.set(bK, VO), VO += pO * hO, OO.end += pO
        }
      return new DataView(LO.buffer)
    }
    var eK, lK = pO(38172);
    ! function(OO) {
      OO[OO.Float = 0] = "Float", OO[OO.HalfFloat = 1] = "HalfFloat"
    }(eK || (eK = {}));
    class vp {}
    async function CK(OO, KO, pO, XO) {
      const bK = {
        size: 0,
        viewer: KO,
        array: new Uint8Array(KO.buffer),
        offset: pO,
        width: OO.dataWindow.xMax - OO.dataWindow.xMin + 1,
        height: OO.dataWindow.yMax - OO.dataWindow.yMin + 1,
        channels: OO.channels.length,
        channelLineOffsets: {},
        scanOrder: () => 0,
        bytesPerLine: 0,
        outLineWidth: 0,
        lines: 0,
        scanlineBlockSize: 0,
        inputSize: null,
        type: 0,
        uncompress: null,
        getter: () => 0,
        format: 5,
        outputChannels: 0,
        decodeChannels: {},
        blockCount: null,
        byteArray: null,
        linearSpace: !1,
        textureType: 0
      };
      switch (OO.compression) {
        case fO.NO_COMPRESSION:
          bK.lines = 1, bK.uncompress = OK;
          break;
        case fO.RLE_COMPRESSION:
          bK.lines = 1, bK.uncompress = KK;
          break;
        case fO.ZIPS_COMPRESSION:
          bK.lines = 1, bK.uncompress = pK, await lK.k.LoadScriptAsync(vp.FFLATEUrl);
          break;
        case fO.ZIP_COMPRESSION:
          bK.lines = 16, bK.uncompress = pK, await lK.k.LoadScriptAsync(vp.FFLATEUrl);
          break;
        case fO.PIZ_COMPRESSION:
          bK.lines = 32, bK.uncompress = bp;
          break;
        case fO.PXR24_COMPRESSION:
          bK.lines = 16, bK.uncompress = XK, await lK.k.LoadScriptAsync(vp.FFLATEUrl);
          break;
        default:
          throw new Error(fO[OO.compression] + " is unsupported")
      }
      bK.scanlineBlockSize = bK.lines;
      const eO = {};
      for (const vK of OO.channels) switch (vK.name) {
        case "R":
        case "G":
        case "B":
        case "A":
        case "Y":
          eO[vK.name] = !0, bK.type = vK.pixelType
      }
      let lO = !1;
      if (eO.R && eO.G && eO.B && eO.A) bK.outputChannels = 4, bK.decodeChannels = {
        R: 0,
        G: 1,
        B: 2,
        A: 3
      };
      else if (eO.R && eO.G && eO.B) lO = !0, bK.outputChannels = 4, bK.decodeChannels = {
        R: 0,
        G: 1,
        B: 2,
        A: 3
      };
      else if (eO.R && eO.G) bK.outputChannels = 2, bK.decodeChannels = {
        R: 0,
        G: 1
      };
      else if (eO.R) bK.outputChannels = 1, bK.decodeChannels = {
        R: 0
      };
      else {
        if (!eO.Y) throw new Error("EXRLoader.parse: file contains unsupported data channels.");
        bK.outputChannels = 1, bK.decodeChannels = {
          Y: 0
        }
      }
      if (1 === bK.type) switch (XO) {
        case eK.Float:
          bK.getter = YO, bK.inputSize = hO;
          break;
        case eK.HalfFloat:
          bK.getter = gK, bK.inputSize = hO
      } else {
        if (2 !== bK.type) throw new Error("Unsupported pixelType " + bK.type + " for " + OO.compression);
        switch (XO) {
          case eK.Float:
            bK.getter = jK, bK.inputSize = vK;
            break;
          case eK.HalfFloat:
            bK.getter = wO, bK.inputSize = vK
        }
      }
      bK.blockCount = bK.height / bK.scanlineBlockSize;
      for (let vK = 0; vK < bK.blockCount; vK++) EO(KO, pO);
      const CO = bK.width * bK.height * bK.outputChannels;
      switch (XO) {
        case eK.Float:
          bK.byteArray = new Float32Array(CO), bK.textureType = 1, lO && bK.byteArray.fill(1, 0, CO);
          break;
        case eK.HalfFloat:
          bK.byteArray = new Uint16Array(CO), bK.textureType = 2, lO && bK.byteArray.fill(15360, 0, CO);
          break;
        default:
          throw new Error("Unsupported type: " + XO)
      }
      let DO = 0;
      for (const vK of OO.channels) void 0 !== bK.decodeChannels[vK.name] && (bK.channelLineOffsets[vK.name] = DO * bK.width), DO += 2 * vK.pixelType;
      return bK.bytesPerLine = bK.width * DO, bK.outLineWidth = bK.width * bK.outputChannels, "INCREASING_Y" === OO.lineOrder ? bK.scanOrder = OO => OO : bK.scanOrder = OO => bK.height - 1 - OO, 4 == bK.outputChannels ? (bK.format = 5, bK.linearSpace = !0) : (bK.format = 6, bK.linearSpace = !1), bK
    }

    function hK(OO, KO, pO, XO) {
      const bK = {
        value: 0
      };
      for (let eO = 0; eO < OO.height / OO.scanlineBlockSize; eO++) {
        const lO = NO(pO, XO) - KO.dataWindow.yMin;
        OO.size = IO(pO, XO), OO.lines = lO + OO.scanlineBlockSize > OO.height ? OO.height - lO : OO.scanlineBlockSize;
        const vK = OO.size < OO.lines * OO.bytesPerLine && OO.uncompress ? OO.uncompress(OO) : OK(OO);
        XO.value += OO.size;
        for (let pO = 0; pO < OO.scanlineBlockSize; pO++) {
          const XO = eO * OO.scanlineBlockSize,
            lO = pO + OO.scanOrder(XO);
          if (lO >= OO.height) continue;
          const CO = pO * OO.bytesPerLine,
            hO = (OO.height - 1 - lO) * OO.outLineWidth;
          for (let pO = 0; pO < OO.channels; pO++) {
            const XO = KO.channels[pO].name,
              eO = OO.channelLineOffsets[XO],
              lO = OO.decodeChannels[XO];
            if (void 0 !== lO) {
              bK.value = CO + eO;
              for (let KO = 0; KO < OO.width; KO++) {
                const pO = hO + KO * OO.outputChannels + lO;
                OO.byteArray && (OO.byteArray[pO] = OO.getter(vK, bK))
              }
            }
          }
        }
      }
    }
    vp.DefaultOutputType = eK.HalfFloat, vp.FFLATEUrl = "https://unpkg.com/fflate@0.8.2";
    class DK {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData(OO, KO, pO, XO, bK) {
        throw ".exr not supported in Cube."
      }
      loadData(OO, KO, pO) {
        const bK = new DataView(OO.buffer),
          eO = {
            value: 0
          },
          lO = sO(bK, eO);
        CK(lO, bK, eO, vp.DefaultOutputType).then((OO => {
          hK(OO, lO, bK, eO);
          const XO = lO.dataWindow.xMax - lO.dataWindow.xMin + 1,
            vK = lO.dataWindow.yMax - lO.dataWindow.yMin + 1;
          pO(XO, vK, KO.generateMipMaps, !1, (() => {
            const pO = KO.qb();
            KO.format = lO.format, KO.type = OO.textureType, KO.invertY = !1, KO._gammaSpace = !lO.linearSpace, OO.byteArray && pO._uploadDataToTextureDirectly(KO, OO.byteArray, 0, 0, void 0, !0)
          }))
        })).catch((OO => {
          XO.b.Error("Failed to load EXR texture: ", OO)
        }))
      }
    }
    async function MK(OO) {
      const KO = new DataView(OO),
        pO = {
          value: 0
        },
        bK = sO(KO, pO);
      try {
        const OO = await CK(bK, KO, pO, eK.Float);
        return hK(OO, bK, KO, pO), OO.byteArray ? {
          width: bK.dataWindow.xMax - bK.dataWindow.xMin + 1,
          height: bK.dataWindow.yMax - bK.dataWindow.yMin + 1,
          data: new Float32Array(OO.byteArray)
        } : (XO.b.Error("Failed to decode EXR data: No byte array available."), {
          width: 0,
          height: 0,
          data: null
        })
      } catch (eO) {
        XO.b.Error("Failed to load EXR data: ", eO)
      }
      return {
        width: 0,
        height: 0,
        data: null
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);