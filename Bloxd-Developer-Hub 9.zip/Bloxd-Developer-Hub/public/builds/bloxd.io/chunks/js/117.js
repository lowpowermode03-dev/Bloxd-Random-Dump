export const id = 117;
export const ids = [117];
export const modules = {
  5703: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ShaderPackPublishForm: () => AO
    });
    var XO = pO(63),
      bK = pO(5678),
      eO = pO(173),
      lO = pO(5709),
      vK = pO(933),
      CO = pO(1271),
      hO = pO(1475),
      DO = pO(1004),
      MO = pO(5711),
      aK = pO(5730),
      oO = pO(1329),
      FO = pO(1051),
      VO = pO(5739),
      LO = pO(5786),
      QO = pO(5674),
      zK = pO(976);

    function AO(OO) {
      var KO, pO, MO;
      let {
        existing: AO,
        onPublished: dO
      } = OO;
      const {
        t: NO
      } = (0, FO.D)(), {
        userContext: IO,
        isUserContextUpdating: yK
      } = (0, DO.d)(), [gK, uO] = (0, XO.useState)(null), [EO, jK] = (0, XO.useState)(0), [YO, wO] = (0, XO.useState)(null !== (KO = null === AO || void 0 === AO ? void 0 : AO.name) && void 0 !== KO ? KO : ""), iK = (0, XO.useRef)(YO), rK = (0, XO.useRef)(""), PO = OO => {
        iK.current = OO, wO(OO)
      }, [mK, sO] = (0, XO.useState)(null !== (pO = null === AO || void 0 === AO ? void 0 : AO.description) && void 0 !== pO ? pO : ""), HO = (0, XO.useRef)(mK), RO = (0, XO.useRef)(""), SO = OO => {
        HO.current = OO, sO(OO)
      }, [JO, cK] = (0, XO.useState)(!1), {
        loading: BO,
        error: ZO,
        setError: GO,
        onFiles: qK
      } = (0, aK.h)((async OO => {
        const KO = await (0, VO.loadPageShaderPackCompiler)();
        if (!KO) return void GO(NO("shaderPack:compilerUnavailable"));
        const pO = await (0, LO.f)(KO, OO.files);
        if (uO({
            pack: OO,
            validation: pO,
            sourceBytes: (0, lO.w)(OO.files)
          }), !AO) {
          var XO;
          if ("" !== iK.current.trim() && iK.current !== rK.current || (rK.current = (0, bK.H)(OO.manifest.name.trim(), bK.w), PO(rK.current)), "" === HO.current.trim() || HO.current === RO.current) RO.current = (0, bK.H)((null !== (XO = OO.manifest.description) && void 0 !== XO ? XO : "").trim(), bK.s), SO(RO.current);
          jK((OO => OO + 1))
        }
      })), xK = !yK && !IO.isLoggedIn() && !eO.e.offlineMode, nO = YO.trim(), WO = nO.length < bK.x, tK = null !== gK && !1 !== (null === (MO = gK.validation) || void 0 === MO ? void 0 : MO.ok) && !BO && !WO && !xK && !yK;
      return (0, zK.jsxs)("div", {
        className: "ShaderPackPublishForm",
        children: [(0, zK.jsx)("p", {
          className: "ShaderPackPublishIntro",
          children: AO ? NO("shaderPackListing:uploadIntro", {
            minutes: String(bK.B / 6e4)
          }) : NO("shaderPackListing:publishIntro")
        }), (0, zK.jsx)(TO, {}), xK && (0, zK.jsx)("div", {
          className: "ShaderPackPublishNote Warning",
          children: NO("shaderPackListing:publishNeedsLogin")
        }), (0, zK.jsx)(aK.e, {
          busy: BO,
          disabled: BO || JO,
          onFiles: OO => {
            uO(null), qK(OO)
          }
        }), gK && (0, zK.jsxs)("div", {
          className: "ShaderPackPublishSummary",
          children: [(0, zK.jsx)("div", {
            className: "ShaderPackPublishPackName",
            children: gK.pack.manifest.name
          }), (0, zK.jsxs)("div", {
            className: "ShaderPackPublishPackSize",
            children: [NO("shaderPackListing:sizeValue", {
              kilobytes: String((0, QO.O)(gK.sourceBytes))
            }), " \xb7", " ", NO("shaderPackListing:filesValue", {
              files: String(gK.pack.files.length)
            })]
          }), (0, zK.jsx)(fO, {
            picked: gK
          })]
        }), !AO && (0, zK.jsxs)(zK.Fragment, {
          children: [(0, zK.jsxs)("label", {
            className: "ShaderPackPublishField",
            children: [(0, zK.jsx)("span", {
              children: NO("general:name")
            }), (0, zK.jsx)(hO.e, {
              className: "ShaderPackPublishInput",
              defaultValue: YO,
              maxLength: bK.w,
              onValueChange: PO
            }, EO), gK && WO && (0, zK.jsx)("span", {
              className: "ShaderPackPublishHint",
              children: NO("shaderPackListing:nameTooShort", {
                min: String(bK.x)
              })
            })]
          }), (0, zK.jsxs)("label", {
            className: "ShaderPackPublishField",
            children: [(0, zK.jsx)("span", {
              children: NO("general:description")
            }), (0, zK.jsx)(hO.e, {
              className: "ShaderPackPublishInput ShaderPackPublishDescription",
              defaultValue: mK,
              maxLength: bK.s,
              onValueChange: SO,
              useTextarea: !0
            }, EO)]
          })]
        }), ZO && (0, zK.jsx)("div", {
          className: "ShaderPackPublishNote Error",
          children: ZO
        }), (0, zK.jsxs)(CO.m, {
          className: "ShaderPackPublishButton",
          disabled: !tK,
          loading: JO,
          onClick: () => {
            !async function() {
              var OO;
              if (!gK) return;
              const {
                name: KO,
                description: pO
              } = null !== AO && void 0 !== AO ? AO : {
                name: nO,
                description: mK.trim()
              }, XO = {
                packId: null !== (OO = null === AO || void 0 === AO ? void 0 : AO.packId) && void 0 !== OO ? OO : null,
                name: KO,
                description: pO,
                apiVersion: gK.pack.manifest.apiVersion,
                files: (0, lO.v)(gK.pack.files),
                keepCircleShadows: !0 === gK.pack.manifest.keepCircleShadows
              };
              if ((new TextEncoder).encode(JSON.stringify(XO)).byteLength > 1024 * bK.G) GO(NO("shaderPackListing:publishTooBig", {
                kilobytes: String(bK.G)
              }));
              else {
                cK(!0), GO(null);
                try {
                  dO(await oO.c.publishShaderPack(IO, XO))
                } catch (eO) {
                  console.error("Failed to publish the shader pack", eO), GO((0, QO.w)(eO, NO, "shaderPackListing:publishFailed"))
                } finally {
                  cK(!1)
                }
              }
            }()
          },
          children: [(0, zK.jsx)(vK.d, {
            name: "upload"
          }), " ", NO(AO ? "shaderPackListing:uploadButton" : "shaderPackListing:publishButton")]
        })]
      })
    }

    function fO(OO) {
      let {
        picked: KO
      } = OO;
      const {
        t: pO
      } = (0, FO.D)(), {
        validation: XO
      } = KO;
      return null === XO ? (0, zK.jsx)("div", {
        className: "ShaderPackPublishNote",
        children: pO("shaderPackListing:publishUnchecked")
      }) : XO.ok ? (0, zK.jsxs)(zK.Fragment, {
        children: [(0, zK.jsxs)("div", {
          className: "ShaderPackPublishNote Ready",
          children: [(0, zK.jsx)(vK.d, {
            name: "circle-check"
          }), " ", pO("shaderPackListing:publishReady")]
        }), XO.offInStrict.length > 0 && (0, zK.jsxs)(zK.Fragment, {
          children: [(0, zK.jsxs)("div", {
            className: "ShaderPackPublishNote Warning",
            children: [(0, zK.jsx)(vK.d, {
              name: "triangle-exclamation"
            }), " ", pO("shaderPack:offInStrict")]
          }), (0, zK.jsx)(MO.c, {
            diagnostics: XO.offInStrict,
            t: pO
          })]
        })]
      }) : (0, zK.jsxs)(zK.Fragment, {
        children: [(0, zK.jsxs)("div", {
          className: "ShaderPackPublishNote Error",
          children: [(0, zK.jsx)(vK.d, {
            name: "triangle-exclamation"
          }), " ", pO("shaderPackListing:publishHasErrors")]
        }), (0, zK.jsx)(MO.c, {
          diagnostics: XO.errors,
          more: XO.moreErrors,
          t: pO
        })]
      })
    }
    const dO = "\0";

    function TO() {
      const {
        t: OO
      } = (0, FO.D)(), [KO, pO] = OO("shaderPackListing:bloxdhubHelp", {
        site: dO
      }).split(dO);
      return (0, zK.jsxs)("p", {
        className: "ShaderPackPublishIntro",
        children: [KO, (0, zK.jsx)("a", {
          className: "ShaderPackPublishLink",
          href: bK.i,
          target: "_blank",
          rel: "noopener noreferrer",
          children: bK.d
        }), pO]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);