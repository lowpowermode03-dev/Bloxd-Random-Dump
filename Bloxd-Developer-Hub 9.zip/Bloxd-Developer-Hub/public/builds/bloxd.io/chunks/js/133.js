export const id = 133;
export const ids = [133];
export const modules = {
  7177: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdFirebaseSdk: () => CO
    });
    var XO = pO(1528),
      bK = pO(2302),
      eO = pO(105),
      lO = pO(94),
      vK = pO(1507);
    class CO {
      constructor() {}
      static async setup() {
        try {
          return await CO.setupInternal()
        } catch (OO) {
          return console.error("Failed to setup Firebase SDK:", OO), null
        }
      }
      static async setupInternal() {
        const OO = await Promise.all([pO.e(247), pO.e(246)]).then((() => pO(38603))),
          KO = await Promise.all([pO.e(247), pO.e(248)]).then((() => pO(38632))),
          DO = await Promise.all([pO.e(247), pO.e(249)]).then((() => pO(38634))),
          MO = OO.initializeApp(hO);
        (0, bK.D)(), window.gtag("config", hO.measurementId), (0, bK.x)(), window.gtag("config", "AW-16469618203");
        const aK = KO.getAnalytics(MO),
          oO = {
            portal: eO.currentUrl.getSearchParam("portal") || "root",
            loggedIn: !1
          };
        KO.setUserProperties(aK, oO);
        const FO = DO.getAuth();
        DO.useDeviceLanguage(FO);
        const VO = new DO.GoogleAuthProvider;
        VO.setCustomParameters({
          prompt: "select_account"
        });
        const LO = new DO.OAuthProvider("apple.com"),
          QO = new DO.OAuthProvider("microsoft.com");
        QO.setCustomParameters({
          prompt: "select_account",
          tenant: "consumers"
        });
        const zK = {
          [XO.b.GOOGLE]: {
            provider: VO,
            RNSignInMessage: "googleSignInWithPopup",
            RNCurrentUserMessage: "googleGetCurrentUser",
            RNSignOutMessage: "googleSignOut"
          },
          [XO.b.APPLE]: {
            provider: LO,
            RNSignInMessage: "appleSignInWithPopup",
            RNCurrentUserMessage: "appleGetCurrentUser",
            RNSignOutMessage: "appleSignOut"
          },
          [XO.b.MICROSOFT]: {
            provider: QO,
            RNSignInMessage: "microsoftSignInWithPopup",
            RNCurrentUserMessage: "microsoftGetCurrentUser",
            RNSignOutMessage: "microsoftSignOut"
          }
        };
        window.gtag("set", {
          cookie_flags: "SameSite=None;Secure"
        }), await new Promise((OO => {
          const KO = DO.onIdTokenChanged(FO, (pO => {
            KO(), OO()
          }))
        }));
        class AO extends CO {
          setUserProperties(OO) {
            KO.setUserProperties(aK, OO)
          }
          onIdTokenChanged(OO) {
            DO.onIdTokenChanged(FO, OO)
          }
          async signInWithPopup(OO) {
            var KO;
            const pO = await DO.signInWithPopup(FO, zK[OO].provider);
            return null !== (KO = null === pO || void 0 === pO ? void 0 : pO.user) && void 0 !== KO ? KO : null
          }
          async getCurrentUser(OO) {
            const KO = FO.currentUser;
            if (!KO) return null;
            const {
              signInProvider: pO
            } = await KO.getIdTokenResult(!1);
            return pO === zK[OO].provider.providerId ? KO : null
          }
          async signOut(OO) {
            null !== await this.getCurrentUser(OO) && await DO.signOut(FO)
          }
        }
        class fO extends CO {
          setUserProperties(OO) {
            KO.setUserProperties(aK, OO)
          }
          onIdTokenChanged(OO) {
            DO.onIdTokenChanged(FO, OO)
          }
          async signInWithPopup(OO) {
            return await (0, vK.k)(zK[OO].RNSignInMessage, {
              firebaseUserContextType: OO
            }).then((async KO => {
              var pO;
              let bK;
              switch (OO) {
                case XO.b.GOOGLE:
                  bK = DO.GoogleAuthProvider.credential(KO.googleIdToken);
                  break;
                case XO.b.APPLE:
                  bK = LO.credential({
                    idToken: KO.appleIdToken
                  });
                  break;
                case XO.b.MICROSOFT:
                  bK = QO.credential({
                    idToken: KO.microsoftIdToken
                  });
                  break;
                default:
                  return null
              }
              const eO = await DO.signInWithCredential(FO, bK);
              return null !== (pO = null === eO || void 0 === eO ? void 0 : eO.user) && void 0 !== pO ? pO : null
            })).catch((KO => (console.error(`Failed to sign in with ${OO} popup:`, KO), null)))
          }
          async getCurrentUser(OO) {
            const KO = FO.currentUser;
            if (KO) {
              const {
                signInProvider: pO
              } = await KO.getIdTokenResult(!1);
              if (pO === zK[OO].provider.providerId) return KO
            }
            return await (0, vK.k)(zK[OO].RNCurrentUserMessage, {}).then((async KO => {
              var pO;
              let bK;
              switch (OO) {
                case XO.b.GOOGLE:
                  bK = DO.GoogleAuthProvider.credential(KO.googleIdToken);
                  break;
                case XO.b.APPLE:
                  bK = LO.credential({
                    idToken: KO.appleIdToken
                  });
                  break;
                case XO.b.MICROSOFT:
                  bK = QO.credential({
                    idToken: KO.microsoftIdToken
                  });
                  break;
                default:
                  return null
              }
              const eO = await DO.signInWithCredential(FO, bK);
              return null !== (pO = null === eO || void 0 === eO ? void 0 : eO.user) && void 0 !== pO ? pO : null
            })).catch((KO => (console.error(`Failed to get current ${OO} user from React Native wrapper`, KO), null)))
          }
          async signOut(OO) {
            (0, vK.o)(zK[OO].RNSignOutMessage, {});
            const KO = FO.currentUser;
            if (KO) {
              const {
                signInProvider: pO
              } = await KO.getIdTokenResult(!1);
              pO === zK[OO].provider.providerId && await DO.signOut(FO)
            }
          }
        }
        return (0, lO.isMobileApp)() ? new fO : new AO
      }
    }
    const hO = {
      apiKey: "AIzaSyCJ-G6m_NyA3P021v-ugDmMmkcKysUebSE",
      authDomain: "bloxd-ee1aa.firebaseapp.com",
      projectId: "bloxd-ee1aa",
      storageBucket: "bloxd-ee1aa.appspot.com",
      messagingSenderId: "758847442742",
      appId: "1:758847442742:web:7bb74eb261641e30f02d97",
      measurementId: bK.b
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);