export const id = 333;
export const ids = [333];
export const modules = {
  59068: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      postprocessVertexShader: () => lO
    });
    var XO = pO(37907);
    const bK = "postprocessVertexShader",
      eO = "attribute vec2 position;uniform vec2 scale;varying vec2 vUV;const vec2 madd=vec2(0.5,0.5);\n#define CUSTOM_VERTEX_DEFINITIONS\nvoid main(void) {\n#define CUSTOM_VERTEX_MAIN_BEGIN\nvUV=(position*madd+madd)*scale;gl_Position=vec4(position,0.0,1.0);\n#define CUSTOM_VERTEX_MAIN_END\n}";
    XO.b.ShadersStore[bK] || (XO.b.ShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);