export const id = 43;
export const ids = [43];
export const modules = {
  3852: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      installRenderDebug: () => lp,
      renderDebugPlayable: () => Cp,
      startRenderDebug: () => vX
    });
    var XO = pO(2412),
      bK = pO(22),
      eO = pO(26),
      lO = pO(1136);
    class vK {
      constructor(OO, KO) {
        this.print = OO, this.now = KO, this.shown = 0, this.JK = 0, this.sections = 0, this.second = -1 / 0, this.inSecond = 0, this.Sp = [], this.dropped = 0
      }
      line(OO) {
        const KO = this.now();
        if (KO - this.second >= 1e3 && (this.second = KO, this.inSecond = 0), this.shown >= 400 || this.inSecond >= 20) return this.JK++, void this.store(OO);
        this.shown++, this.inSecond++, this.print(400 === this.shown ? `${OO} (the last line here: the rest go to bloxdDebug.save())` : OO)
      }
      keep(OO) {
        this.sections++, this.store(OO)
      }
      store(OO) {
        this.Sp.push(`${new Date(Date.now()).toISOString()} ${OO}`), this.Sp.length > 2e4 && (this.Sp.shift(), this.dropped++)
      }
      dump() {
        return [`${this.shown} lines logged (above); kept here: ${this.JK} lines past the console's budget, ${this.sections} sections; ${this.dropped} oldest dropped`, ...this.Sp].join("\n")
      }
    }
    let CO = null;

    function hO() {
      if (null === CO) {
        const OO = new vK((OO => {
          (0, XO.i)("render", OO)
        }), (() => performance.now()));
        (0, XO.f)("render", (() => OO.dump())), CO = OO
      }
      return CO
    }

    function DO(OO) {
      hO().line(OO)
    }

    function MO(OO) {
      hO().keep(OO)
    }

    function aK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 4096;
      return OO.length <= KO ? OO : `${OO.slice(0,KO)}... (${OO.length-KO} more characters)`
    }
    const oO = 3e4,
      FO = 1e3;

    function VO() {
      return "visible" === document.visibilityState && "inGame" === bK.d.get("gameState") && (0, lO.l)()
    }

    function LO(OO) {
      ! function(OO, KO, pO) {
        let XO = 0;
        const bK = setInterval((() => {
          KO() && (XO += FO, XO >= OO && (clearInterval(bK), pO()))
        }), FO)
      }(oO, VO, (() => {
        OO().then((() => {
          DO(`saved for the player after ${oO/1e3} s of play`), (0, XO.v)(), eO.i.pl("chat", {
            content: [{
              str: "Saved a debug file to your downloads: please send it to us with a screenshot of the game.",
              style: {
                color: "#ffd84a"
              }
            }]
          })
        }))
      }))
    }
    const QO = ["+x", "-x", "+y", "-y", "+z", "-z", "dir6", "dir7"];

    function zK(OO) {
      return 7 & OO
    }

    function AO(OO) {
      return OO >>> 11 & 1
    }

    function fO(OO) {
      return [1 + (OO >>> 18 & 63), 1 + (OO >>> 24 & 63)]
    }

    function dO(OO, KO) {
      const [pO, , XO] = OO, bK = zK(XO), eO = function(OO, KO, pO) {
        return KO + (1 === (22 >>> OO & 1) ? 4 - pO : pO) & 3
      }(bK, AO(XO), KO), lO = bK >>> 1, [vK, CO] = fO(pO), hO = 1 === eO || 2 === eO ? vK : 0, DO = eO >= 2 ? CO : 0, MO = [63 & pO, pO >>> 6 & 63, pO >>> 12 & 63];
      return MO[2 === lO ? 0 : 2] += hO, MO[1 === lO ? 0 : 1] += DO, MO
    }

    function TO(OO) {
      const KO = Math.max(...fO(OO[0]));
      return 1 === KO ? "1" : KO <= 4 ? "2-4" : KO <= 16 ? "5-16" : "17-64"
    }
    const NO = 16;

    function IO(OO) {
      let KO = 2166136261;
      for (let pO = 0; pO < OO.length; pO++) KO = Math.imul(KO ^ OO[pO], 16777619);
      return KO >>> 0
    }

    function yK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 12;
      const XO = Math.max(0, KO - pO),
        bK = Math.min(OO.length, KO + pO),
        eO = [];
      for (let lO = XO; lO < bK; lO++) {
        const pO = OO[lO].toString(16).padStart(2, "0");
        eO.push(lO === KO ? `[${pO}]` : pO)
      }
      return eO.join(" ")
    }
    const gK = {
        NO_ERROR: 0,
        POINTS: 0,
        ARRAY_BUFFER: 34962,
        ELEMENT_ARRAY_BUFFER: 34963,
        ARRAY_BUFFER_BINDING: 34964,
        ELEMENT_ARRAY_BUFFER_BINDING: 34965,
        COPY_READ_BUFFER: 36662,
        COPY_WRITE_BUFFER: 36663,
        COPY_READ_BUFFER_BINDING: 36662,
        COPY_WRITE_BUFFER_BINDING: 36663,
        UNIFORM_BUFFER: 35345,
        UNIFORM_BUFFER_BINDING: 35368,
        PIXEL_UNPACK_BUFFER: 35052,
        PIXEL_UNPACK_BUFFER_BINDING: 35055,
        TRANSFORM_FEEDBACK_BUFFER: 35982,
        TRANSFORM_FEEDBACK_BUFFER_BINDING: 35983,
        TRANSFORM_FEEDBACK: 36386,
        TRANSFORM_FEEDBACK_BINDING: 36389,
        INTERLEAVED_ATTRIBS: 35980,
        RASTERIZER_DISCARD: 35977,
        STREAM_READ: 35041,
        CURRENT_PROGRAM: 35725,
        LINK_STATUS: 35714,
        VERTEX_SHADER: 35633,
        FRAGMENT_SHADER: 35632,
        DEPTH_FUNC: 2932,
        DEPTH_CLEAR_VALUE: 2931,
        SAMPLES: 32937,
        DRAW_FRAMEBUFFER: 36009,
        DEPTH_ATTACHMENT: 36096,
        FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE: 36048,
        FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE: 33302,
        FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE: 33297,
        DRAW_FRAMEBUFFER_BINDING: 36006,
        ACTIVE_UNIFORMS: 35718,
        ACTIVE_UNIFORM_BLOCKS: 35382,
        UNIFORM_BLOCK_BINDING: 35391,
        UNIFORM_BLOCK_INDEX: 35386,
        INVALID_INDEX: 4294967295,
        MAX_VERTEX_ATTRIBS: 34921,
        VERTEX_ATTRIB_ARRAY_ENABLED: 34338,
        VERTEX_ATTRIB_ARRAY_SIZE: 34339,
        VERTEX_ATTRIB_ARRAY_STRIDE: 34340,
        VERTEX_ATTRIB_ARRAY_TYPE: 34341,
        VERTEX_ATTRIB_ARRAY_POINTER: 34373,
        VERTEX_ATTRIB_ARRAY_BUFFER_BINDING: 34975,
        VERTEX_ATTRIB_ARRAY_INTEGER: 35069,
        VERTEX_ATTRIB_ARRAY_DIVISOR: 35070,
        CURRENT_VERTEX_ATTRIB: 34342,
        TEXTURE_2D: 3553,
        TEXTURE0: 33984,
        ACTIVE_TEXTURE: 34016,
        TEXTURE_BINDING_2D: 32873,
        READ_FRAMEBUFFER: 36008,
        READ_FRAMEBUFFER_BINDING: 36010,
        COLOR_ATTACHMENT0: 36064,
        RGBA_INTEGER: 36249,
        UNSIGNED_INT: 5125,
        RGBA32UI: 36208,
        RGBA16UI: 36214,
        UNSIGNED_INT_SAMPLER_2D: 36306,
        UNPACK_ROW_LENGTH: 3314,
        UNPACK_SKIP_ROWS: 3315,
        UNPACK_SKIP_PIXELS: 3316,
        FLOAT: 5126,
        FLOAT_VEC2: 35664,
        FLOAT_VEC3: 35665,
        FLOAT_VEC4: 35666,
        INT_VEC2: 35667,
        INT_VEC3: 35668,
        INT_VEC4: 35669,
        UNSIGNED_INT_VEC2: 36294,
        UNSIGNED_INT_VEC3: 36295,
        UNSIGNED_INT_VEC4: 36296,
        FLOAT_MAT3: 35675,
        FLOAT_MAT4: 35676
      },
      uO = "_vs2fs_location0",
      EO = 0,
      jK = 4,
      YO = 6,
      wO = [0, 1, 2, 0, 2, 3],
      iK = 2048,
      rK = 4,
      PO = 256,
      mK = 64,
      sO = 268435456,
      HO = 65536,
      RO = [],
      SO = new WeakMap,
      JO = new WeakMap,
      cK = {
        context: null,
        inProbe: !1,
        pendingCheck: null,
        shadowBytes: 0,
        uncopied: 0
      };
    let BO = 1;
    const ZO = new WeakMap;

    function GO(OO) {
      if (null === OO) return 0;
      let KO = ZO.get(OO);
      return void 0 === KO && (KO = BO++, ZO.set(OO, KO)), KO
    }

    function qK(OO, KO, pO, XO, bK, eO) {
      const lO = cK.pendingCheck;
      if (null === lO) return;
      const vK = "undefined" !== typeof WebGL2RenderingContext && OO instanceof WebGL2RenderingContext,
        CO = {
          gl: OO,
          program: pO,
          call: XO,
          Xl: bK,
          instances: eO,
          attributes: [],
          group: -1,
          chunk: "",
          pages: []
        };
      if (lO.draws.push(CO), vK) try {
        const XO = function(OO) {
          const KO = [],
            pO = new Map,
            XO = Math.min(16, OO.getParameter(gK.MAX_VERTEX_ATTRIBS));
          for (let bK = 0; bK < XO; bK++) {
            if (!OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_ENABLED)) continue;
            const XO = OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING),
              eO = OO.getVertexAttribOffset(bK, gK.VERTEX_ATTRIB_ARRAY_POINTER),
              lO = OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_STRIDE),
              vK = OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_SIZE),
              CO = OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_TYPE),
              hO = "VERTEX_ATTRIB_ARRAY_INTEGER" in OO && OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_INTEGER),
              DO = "VERTEX_ATTRIB_ARRAY_DIVISOR" in OO ? OO.getVertexAttrib(bK, gK.VERTEX_ATTRIB_ARRAY_DIVISOR) : 0;
            pO.set(bK, {
              buffer: XO,
              offset: eO,
              stride: lO
            }), KO.push(`@${bK} buf#${GO(XO)} +${eO} stride ${lO} ${vK}x0x${CO.toString(16)}${hO?" int":""} div ${DO}`)
          }
          return {
            lines: KO,
            byLocation: pO
          }
        }(OO);
        if (CO.attributes = XO.lines, "inst" === pO.terrain) {
          const {
            group: bK,
            chunk: vK
          } = function(OO, KO, pO) {
            const XO = KO.get(YO),
              bK = OO.getVertexAttrib(YO, gK.CURRENT_VERTEX_ATTRIB),
              eO = XO ? `+${XO.offset}` : bK ? Array.from(bK).slice(0, 3).join(",") : "?";
            let lO = pO.groups.get(eO);
            return void 0 === lO && (lO = pO.groups.size, pO.groups.set(eO, lO)), {
              group: lO,
              chunk: eO
            }
          }(OO, XO.byLocation, lO);
          CO.group = bK, CO.chunk = vK;
          for (const OO of [EO, jK]) {
            var hO;
            const KO = null === (hO = XO.byLocation.get(OO)) || void 0 === hO ? void 0 : hO.buffer;
            KO && CO.pages.push({
              kind: "buf",
              buffer: KO
            })
          }! function(OO, KO, pO, XO, bK, eO, lO) {
            const vK = XO.get(EO),
              CO = lO.parts.get(eO);
            if (void 0 === CO && lO.parts.size >= rK) return;
            const hO = Math.min(bK, mK, PO - (null !== CO && void 0 !== CO ? CO : 0));
            if (null === vK || void 0 === vK || !vK.buffer || hO <= 0) return;
            const DO = xK(OO, KO, pO);
            if (!DO) return;
            const MO = vK.stride || 12,
              aK = UO(OO, vK.buffer, vK.offset, (hO - 1) * MO + 12),
              oO = new DataView(aK.buffer),
              FO = function(OO, KO) {
                const pO = function(OO) {
                    const KO = pK.get(OO);
                    if (void 0 !== KO && (null === KO || OO.isProgram(KO))) return KO;
                    cK.inProbe = !0;
                    let pO = null;
                    try {
                      pO = nO(OO, OK, KK, "fed", "the record feed")
                    } finally {
                      cK.inProbe = !1
                    }
                    return pK.set(OO, pO), pO
                  }(OO),
                  XO = pO ? kK(OO, pO, KO, (() => {
                    OO.drawArraysInstanced(gK.POINTS, 0, 1, KO)
                  }), "decode probe input (the record feed)") : null;
                return XO ? new Uint32Array(XO.buffer) : null
              }(OO, hO);
            FO || lO.fed.failed++;
            const VO = kK(OO, DO, 4 * hO, (() => {
              OO.drawArraysInstanced(gK.POINTS, 0, 4, hO)
            }));
            if (!VO) return;
            lO.parts.set(eO, (null !== CO && void 0 !== CO ? CO : 0) + hO);
            for (let LO = 0; LO < hO; LO++) {
              const OO = LO * MO,
                KO = [oO.getUint32(OO, !0), oO.getUint32(OO + 4, !0), oO.getUint32(OO + 8, !0)],
                pO = FO ? [FO[3 * LO], FO[3 * LO + 1], FO[3 * LO + 2]] : KO;
              FO && (lO.fed.records++, pO.some(((OO, pO) => OO !== KO[pO])) && (lO.fed.differing++, lO.fed.first.length < 8 && lO.fed.first.push(`part ${eO} instance ${LO}: fed ${pO.map(vp).join(" ")} buffer ${KO.map(vp).join(" ")}`)));
              for (let XO = 0; XO < 4; XO++) {
                const OO = 3 * (4 * LO + XO);
                lO.vertices.push({
                  record: pO,
                  slot: XO,
                  group: eO,
                  gpu: [VO[OO], VO[OO + 1], VO[OO + 2]]
                })
              }
            }
          }(OO, KO, pO, XO.byLocation, eO, bK, lO)
        } else {
          const XO = XK(OO, KO, 16),
            eO = XK(OO, KO, 8);
          for (const OO of [XO, eO]) OO && CO.pages.push({
            kind: "tex",
            texture: OO
          });
          XO && function(OO, KO, pO, XO, bK, eO) {
            if (eO.parts.size >= rK) return;
            const lO = xK(OO, KO, pO);
            if (!lO) return;
            let vK = 6 * PO;
            const CO = [];
            for (const [oO, FO] of bK) {
              const OO = Math.min(FO, vK, Math.max(6, 6 * Math.floor(PO / bK.length)));
              OO > 0 && (CO.push([oO, OO]), vK -= OO)
            }
            const hO = CO.reduce(((OO, KO) => {
                let [, pO] = KO;
                return OO + pO
              }), 0),
              DO = kK(OO, lO, hO, (() => {
                for (const [KO, pO] of CO) OO.drawArrays(gK.POINTS, KO, pO)
              }));
            if (!DO) return;
            let MO = 0;
            for (const [oO, FO] of CO) {
              const KO = Math.floor(oO / 6),
                pO = Math.floor((oO + FO - 1) / 6) - KO + 1,
                bK = bp(OO, XO, iK, KO, pO);
              for (let OO = oO; OO < oO + FO; OO++, MO++) {
                var aK;
                const pO = 4 * (Math.floor(OO / 6) - KO),
                  XO = [bK[pO], bK[pO + 1], bK[pO + 2]];
                eO.parts.set(bK[pO + 3], (null !== (aK = eO.parts.get(bK[pO + 3])) && void 0 !== aK ? aK : 0) + (OO % 6 === 0 ? 1 : 0)), eO.vertices.push({
                  record: XO,
                  slot: wO[OO % 6],
                  group: bK[pO + 3],
                  gpu: [DO[3 * MO], DO[3 * MO + 1], DO[3 * MO + 2]]
                })
              }
            }
          }(OO, KO, pO, XO, bK, lO)
        }
      } catch (MO) {
        DO(`decode probe failed on program #${pO.id}: ${String(MO)}`)
      }
    }

    function xK(OO, KO, pO) {
      if (void 0 !== pO.probe) return pO.probe && WO(OO, KO, pO.probe), pO.probe;
      pO.probe = null, cK.inProbe = !0;
      try {
        pO.probe = function(OO, KO) {
          return nO(OO, KO.vertex, KO.fragment, uO, `program #${KO.id}'s twin`)
        }(OO, pO)
      } finally {
        cK.inProbe = !1
      }
      return pO.probe && WO(OO, KO, pO.probe), pO.probe
    }

    function nO(OO, KO, pO, XO, bK) {
      const eO = [OO.createShader(gK.VERTEX_SHADER), OO.createShader(gK.FRAGMENT_SHADER)],
        lO = OO.createProgram();
      if (!lO || !eO[0] || !eO[1]) return null;
      OO.shaderSource(eO[0], KO), OO.shaderSource(eO[1], pO);
      for (const CO of eO) OO.compileShader(CO), OO.attachShader(lO, CO);
      OO.transformFeedbackVaryings(lO, [XO], gK.INTERLEAVED_ATTRIBS), OO.linkProgram(lO);
      for (const CO of eO) OO.deleteShader(CO);
      var vK;
      return OO.getProgramParameter(lO, gK.LINK_STATUS) ? lO : (DO(`decode probe: ${bK} failed to link: ${aK(null!==(vK=OO.getProgramInfoLog(lO))&&void 0!==vK?vK:"",300)}`), OO.deleteProgram(lO), null)
    }

    function WO(OO, KO, pO) {
      const XO = OO.getProgramParameter(KO, gK.ACTIVE_UNIFORM_BLOCKS);
      for (let vK = 0; vK < XO; vK++) {
        const XO = OO.getActiveUniformBlockName(KO, vK),
          bK = null === XO ? gK.INVALID_INDEX : OO.getUniformBlockIndex(pO, XO);
        bK !== gK.INVALID_INDEX && OO.uniformBlockBinding(pO, bK, OO.getActiveUniformBlockParameter(KO, vK, gK.UNIFORM_BLOCK_BINDING))
      }
      const bK = OO.getParameter(gK.CURRENT_PROGRAM);
      OO.useProgram(pO);
      const eO = OO.getProgramParameter(KO, gK.ACTIVE_UNIFORMS),
        lO = OO.getActiveUniforms(KO, [...Array(eO).keys()], gK.UNIFORM_BLOCK_INDEX);
      for (let vK = 0; vK < eO; vK++) {
        const XO = OO.getActiveUniform(KO, vK);
        if (!XO || -1 !== lO[vK]) continue;
        const bK = XO.name.replace(/\[0\]$/, "");
        for (let eO = 0; eO < XO.size; eO++) {
          const lO = XO.size > 1 ? `${bK}[${eO}]` : XO.name,
            vK = OO.getUniformLocation(KO, lO),
            CO = OO.getUniformLocation(pO, lO);
          vK && CO && tK(OO, CO, XO.type, OO.getUniform(KO, vK))
        }
      }
      OO.useProgram(bK)
    }

    function tK(OO, KO, pO, XO) {
      const bK = ArrayBuffer.isView(XO) ? Array.from(XO) : [Number(XO)];
      switch (pO) {
        case gK.FLOAT:
          return void OO.uniform1f(KO, bK[0]);
        case gK.FLOAT_VEC2:
          return void OO.uniform2fv(KO, bK);
        case gK.FLOAT_VEC3:
          return void OO.uniform3fv(KO, bK);
        case gK.FLOAT_VEC4:
          return void OO.uniform4fv(KO, bK);
        case gK.FLOAT_MAT3:
          return void OO.uniformMatrix3fv(KO, !1, bK);
        case gK.FLOAT_MAT4:
          return void OO.uniformMatrix4fv(KO, !1, bK);
        case gK.UNSIGNED_INT:
          return void OO.uniform1ui(KO, bK[0]);
        case gK.UNSIGNED_INT_VEC2:
          return void OO.uniform2uiv(KO, bK);
        case gK.UNSIGNED_INT_VEC3:
          return void OO.uniform3uiv(KO, bK);
        case gK.UNSIGNED_INT_VEC4:
          return void OO.uniform4uiv(KO, bK);
        case gK.INT_VEC2:
          return void OO.uniform2iv(KO, bK);
        case gK.INT_VEC3:
          return void OO.uniform3iv(KO, bK);
        case gK.INT_VEC4:
          return void OO.uniform4iv(KO, bK);
        default:
          OO.uniform1i(KO, bK[0])
      }
    }

    function kK(OO, KO, pO, XO) {
      let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "decode probe";
      const eO = OO.getParameter(gK.CURRENT_PROGRAM),
        lO = OO.getParameter(gK.TRANSFORM_FEEDBACK_BINDING),
        vK = OO.getParameter(gK.TRANSFORM_FEEDBACK_BUFFER_BINDING),
        CO = OO.getParameter(gK.COPY_READ_BUFFER_BINDING),
        hO = OO.isEnabled(gK.RASTERIZER_DISCARD),
        MO = OO.createTransformFeedback(),
        aK = OO.createBuffer();
      cK.inProbe = !0;
      try {
        const eO = OO.getError();
        eO !== gK.NO_ERROR && DO(`GL error 0x${eO.toString(16)} pending before the decode probe (the renderer's)`), OO.useProgram(KO), OO.bindTransformFeedback(gK.TRANSFORM_FEEDBACK, MO), OO.bindBuffer(gK.TRANSFORM_FEEDBACK_BUFFER, aK), OO.bufferData(gK.TRANSFORM_FEEDBACK_BUFFER, 12 * pO, gK.STREAM_READ), OO.bindBufferBase(gK.TRANSFORM_FEEDBACK_BUFFER, 0, aK), OO.enable(gK.RASTERIZER_DISCARD), OO.beginTransformFeedback(gK.POINTS), XO(), OO.endTransformFeedback(), OO.bindBufferBase(gK.TRANSFORM_FEEDBACK_BUFFER, 0, null);
        const lO = OO.getError();
        if (lO !== gK.NO_ERROR) return DO(`${bK}: GL error 0x${lO.toString(16)} on the feedback draw`), null;
        const vK = new Float32Array(3 * pO);
        return OO.bindBuffer(gK.COPY_READ_BUFFER, aK), OO.getBufferSubData(gK.COPY_READ_BUFFER, 0, vK), vK
      } finally {
        hO || OO.disable(gK.RASTERIZER_DISCARD), OO.bindTransformFeedback(gK.TRANSFORM_FEEDBACK, lO), OO.bindBuffer(gK.TRANSFORM_FEEDBACK_BUFFER, vK), OO.bindBuffer(gK.COPY_READ_BUFFER, CO), OO.deleteTransformFeedback(MO), OO.deleteBuffer(aK), OO.useProgram(eO), cK.inProbe = !1
      }
    }

    function UO(OO, KO, pO, XO) {
      const bK = OO.getParameter(gK.COPY_READ_BUFFER_BINDING),
        eO = new Uint8Array(XO);
      return OO.bindBuffer(gK.COPY_READ_BUFFER, KO), OO.getBufferSubData(gK.COPY_READ_BUFFER, pO, eO), OO.bindBuffer(gK.COPY_READ_BUFFER, bK), eO
    }
    const OK = `#version 300 es\nlayout(location = ${EO}) in uvec3 record;\nflat out uvec3 fed;\nvoid main() {\n\tfed = record;\n\tgl_Position = vec4(0.0);\n\tgl_PointSize = 1.0;\n}\n`,
      KK = "#version 300 es\nprecision highp float;\nout vec4 color;\nvoid main() {\n\tcolor = vec4(0.0);\n}\n",
      pK = new WeakMap;

    function XK(OO, KO, pO) {
      const XO = OO.getProgramParameter(KO, gK.ACTIVE_UNIFORMS),
        bK = OO.getParameter(gK.ACTIVE_TEXTURE);
      try {
        for (let bK = 0; bK < XO; bK++) {
          const XO = OO.getActiveUniform(KO, bK);
          if ((null === XO || void 0 === XO ? void 0 : XO.type) !== gK.UNSIGNED_INT_SAMPLER_2D) continue;
          const eO = OO.getUniformLocation(KO, XO.name),
            lO = eO ? OO.getUniform(KO, eO) : -1;
          if (lO < 0) continue;
          OO.activeTexture(gK.TEXTURE0 + lO);
          const vK = OO.getParameter(gK.TEXTURE_BINDING_2D);
          if (vK && JO.get(vK) === pO) return vK
        }
        return null
      } finally {
        OO.activeTexture(bK)
      }
    }

    function bp(OO, KO, pO, XO, bK) {
      const eO = new Uint32Array(4 * bK),
        lO = OO.getParameter(gK.READ_FRAMEBUFFER_BINDING),
        vK = OO.createFramebuffer();
      OO.bindFramebuffer(gK.READ_FRAMEBUFFER, vK), OO.framebufferTexture2D(gK.READ_FRAMEBUFFER, gK.COLOR_ATTACHMENT0, gK.TEXTURE_2D, KO, 0);
      try {
        let KO = 0;
        for (; KO < bK;) {
          const lO = XO + KO,
            vK = lO % pO,
            CO = Math.min(bK - KO, pO - vK);
          OO.readPixels(vK, Math.floor(lO / pO), CO, 1, gK.RGBA_INTEGER, gK.UNSIGNED_INT, eO.subarray(4 * KO, 4 * (KO + CO))), KO += CO
        }
      } finally {
        OO.bindFramebuffer(gK.READ_FRAMEBUFFER, lO), OO.deleteFramebuffer(vK)
      }
      return eO
    }

    function eK(OO, KO, pO) {
      let XO = 0,
        bK = 0;
      for (let CO = 0; CO < KO.bytes.length; CO += HO) {
        XO++;
        const OO = Math.min(CO + HO, KO.bytes.length);
        IO(KO.bytes.subarray(CO, OO)) !== IO(pO.subarray(CO, OO)) && bK++
      }
      const eO = `${OO} ${KO.bytes.length} B cpu ${IO(KO.bytes).toString(16)} gpu ${IO(pO).toString(16)}, ${bK}/${XO} blocks differ${KO.missed?`, ${KO.missed} GPU-side writes uncopied`:""}`;
      if (0 === bK) return eO;
      const {
        count: lO,
        offsets: vK
      } = function(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 8;
        const XO = Math.min(OO.length, KO.length);
        let bK = Math.abs(OO.length - KO.length);
        const eO = [];
        for (let lO = 0; lO < XO; lO++) OO[lO] !== KO[lO] && (bK++, eO.length < pO && eO.push(lO));
        return {
          count: bK,
          offsets: eO
        }
      }(KO.bytes, pO);
      return MO([`${eO}: ${lO} bytes differ`, ...vK.map((OO => `  +${OO}: cpu ${yK(KO.bytes,OO)} | gpu ${yK(pO,OO)}`))].join("\n")), `${eO}: ${lO} bytes differ, first at ${vK.join(", ")} (context in the saved file)`
    }

    function lK(OO) {
      if (0 === OO.vertices.length) return void DO(`decode probe (${OO.reason}): no terrain draw probed (${OO.draws.length} seen)`);
      const KO = function(OO) {
          const KO = new Map;
          for (const XO of OO) {
            const OO = KO.get(XO.group);
            OO ? OO.push(XO) : KO.set(XO.group, [XO])
          }
          const pO = {
            vertices: OO.length,
            mismatches: 0,
            byDirection: new Array(8).fill(0),
            byDiagonal: [0, 0],
            byBand: {},
            translations: new Map,
            first: []
          };
          for (const [XO, bK] of KO) {
            const OO = new Map,
              KO = bK.map((KO => {
                const pO = dO(KO.record, KO.slot),
                  XO = [KO.gpu[0] - pO[0], KO.gpu[1] - pO[1], KO.gpu[2] - pO[2]],
                  bK = XO.map((OO => Math.round(64 * OO))).join(","),
                  eO = OO.get(bK);
                return eO ? eO.count++ : OO.set(bK, {
                  count: 1,
                  offset: XO
                }), pO
              }));
            let eO = [0, 0, 0],
              lO = 0;
            for (const pO of OO.values()) pO.count > lO && (lO = pO.count, eO = pO.offset);
            pO.translations.set(XO, eO), bK.forEach(((OO, XO) => {
              var bK;
              const lO = [KO[XO][0] + eO[0], KO[XO][1] + eO[1], KO[XO][2] + eO[2]];
              if (lO.every(((KO, pO) => {
                  return XO = OO.gpu[pO], bK = KO, Math.abs(XO - bK) <= Math.max(.001, 1e-6 * Math.abs(bK));
                  var XO, bK
                }))) return;
              pO.mismatches++, pO.byDirection[zK(OO.record[2])]++, pO.byDiagonal[AO(OO.record[2])]++;
              const vK = TO(OO.record);
              pO.byBand[vK] = (null !== (bK = pO.byBand[vK]) && void 0 !== bK ? bK : 0) + 1, pO.first.length < NO && pO.first.push({
                ...OO,
                expected: lO
              })
            }))
          }
          return pO
        }(OO.vertices),
        pO = KO.byDirection.map(((OO, KO) => OO ? `${QO[KO]} ${OO}` : "")).filter(Boolean).join(" "),
        XO = Object.entries(KO.byBand).map((OO => {
          let [KO, pO] = OO;
          return `${KO}: ${pO}`
        })).join(" ");
      if (DO(`decode probe (${OO.reason}): ${KO.mismatches}/${KO.vertices} vertices differ from the CPU decode over ${OO.parts.size} parts, in the probe's own transform feedback draw (the frame's draws can still differ)` + (KO.mismatches ? ` by direction [${pO}] diagonal [0: ${KO.byDiagonal[0]} 1: ${KO.byDiagonal[1]}] extent [${XO}]` : "")), OO.fed.records > 0 || OO.fed.failed > 0) {
        DO(`decode probe input: ${OO.fed.differing}/${OO.fed.records} instanced records the vertex input fed differ from the buffer's readback` + (OO.fed.differing ? " (H2: the GPU's vertex copy differs, unless the feed's own integer pass-through is the fault)" : "") + (OO.fed.failed ? `; the feed failed on ${OO.fed.failed} draws, whose decode is held to the buffer's readback` : ""));
        for (const KO of OO.fed.first) DO(`  ${KO}`)
      }
      for (const bK of KO.first) {
        const [OO, KO, pO] = bK.record;
        DO(`  mismatch part ${bK.group} r0 ${OO.toString(16)} r1 ${KO.toString(16)} r2 ${pO.toString(16)} slot ${bK.slot} (${QO[zK(pO)]}): expected ${bK.expected.map(CK).join(",")} gpu ${bK.gpu.map(CK).join(",")}`)
      }
      MO(`decode probe translations: ${[...KO.translations].map((OO=>{let[KO,pO]=OO;return`${KO}: ${pO.map(CK).join(",")}`})).join("; ")}`)
    }

    function vp(OO) {
      return OO.toString(16)
    }

    function CK(OO) {
      return Number.isInteger(OO) ? String(OO) : OO.toFixed(3)
    }

    function hK(OO) {
      return null !== cK.pendingCheck ? Promise.resolve() : new Promise((KO => {
        let pO = !1;
        const XO = {
          reason: OO,
          terrainDraws: 0,
          draws: [],
          vertices: [],
          parts: new Map,
          groups: new Map,
          fed: {
            records: 0,
            differing: 0,
            first: [],
            failed: 0
          }
        };
        cK.pendingCheck = XO;
        const bK = () => {
            cK.pendingCheck = null;
            try {
              ! function(OO) {
                DO(`draw ranges (${OO.reason}): ${OO.terrainDraws} terrain draws in the frame, the first ${OO.draws.length} here`);
                for (const KO of OO.draws) {
                  const OO = KO.Xl.slice(0, 8).map((OO => {
                      let [KO, pO] = OO;
                      return `${KO}+${pO}`
                    })).join(" "),
                    pO = KO.Xl.length > 8 ? ` (+${KO.Xl.length-8} ranges)` : "";
                  DO(`  #${KO.program.id} ${KO.program.terrain} ${KO.call} ${OO}${pO} x${KO.instances}${KO.group>=0?` part ${KO.group} chunk ${KO.chunk}`:""} | ${KO.attributes.join(" | ")}`)
                }
              }(XO), lK(XO);
              XO.draws.some((OO => "undefined" !== typeof WebGL2RenderingContext && OO.gl instanceof WebGL2RenderingContext)) || 0 === XO.draws.length ? function(OO) {
                const KO = [],
                  pO = new Map;
                for (const XO of OO)
                  if ("undefined" !== typeof WebGL2RenderingContext && XO.gl instanceof WebGL2RenderingContext)
                    for (const OO of XO.pages) pO.set("buf" === OO.kind ? OO.buffer : OO.texture, {
                      page: OO,
                      gl: XO.gl
                    });
                for (const [XO, {
                    page: bK,
                    gl: eO
                  }] of pO) {
                  const OO = SO.get(XO);
                  if (!OO) {
                    KO.push(`${bK.kind}#${GO(XO)}: no CPU copy (${cK.uncopied} pages over the copy budget)`);
                    continue
                  }
                  if ("buf" === bK.kind) {
                    KO.push(eK(`buf#${OO.id}`, OO, UO(eO, bK.buffer, 0, OO.bytes.length)));
                    continue
                  }
                  const pO = bp(eO, bK.texture, OO.width, 0, OO.width * OO.height),
                    lO = 16 === OO.texelBytes ? new Uint8Array(pO.buffer) : new Uint8Array(new Uint16Array(pO).buffer);
                  KO.push(eK(`tex#${OO.id} (${16===OO.texelBytes?"records":"light"})`, OO, lO))
                }
                for (const XO of KO) DO(`page readback ${XO}`)
              }(XO.draws) : DO("page readback: none on WebGL1 (no buffer readback)")
            } catch (OO) {
              DO(`check failed: ${String(OO)}`)
            }
            KO()
          },
          eO = () => {
            if (XO.draws.length > 0 && !pO) return pO = !0, void setTimeout(bK, 0);
            pO || requestAnimationFrame(eO)
          };
        requestAnimationFrame(eO), setTimeout((() => {
          pO || (pO = !0, bK())
        }), 5e3)
      }))
    }
    const DK = 20,
      MK = 24;

    function ap(OO, KO, pO) {
      if (!OO) return;
      const XO = OO[KO];
      "function" === typeof XO && (OO[KO] = pO(XO))
    }
    let oK = !1;
    const FK = new WeakMap,
      VK = new WeakMap,
      LK = new WeakMap,
      QK = {
        gl: 0,
        lost: 0
      };
    let zp = {
        inst: {
          draws: 0,
          faces: 0
        },
        tex: {
          draws: 0,
          faces: 0
        },
        other: {
          draws: 0,
          faces: 0
        }
      },
      AK = {
        buffer: 0,
        texture: 0
      },
      fK = 0;

    function dK(OO, KO, pO) {
      return Reflect.apply(OO, KO, pO)
    }

    function TK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
      if (OO instanceof ArrayBuffer) return new Uint8Array(OO, KO, pO || void 0);
      if (!ArrayBuffer.isView(OO)) return null;
      const XO = "BYTES_PER_ELEMENT" in OO ? OO.BYTES_PER_ELEMENT : 1,
        bK = OO.byteOffset + KO * XO,
        eO = pO ? pO * XO : OO.byteLength - KO * XO;
      return new Uint8Array(OO.buffer, bK, Math.max(0, eO))
    }

    function NK(OO, KO) {
      const pO = function(OO) {
        switch (OO) {
          case gK.ARRAY_BUFFER:
            return gK.ARRAY_BUFFER_BINDING;
          case gK.ELEMENT_ARRAY_BUFFER:
            return gK.ELEMENT_ARRAY_BUFFER_BINDING;
          case gK.COPY_READ_BUFFER:
            return gK.COPY_READ_BUFFER_BINDING;
          case gK.COPY_WRITE_BUFFER:
            return gK.COPY_WRITE_BUFFER_BINDING;
          case gK.UNIFORM_BUFFER:
            return gK.UNIFORM_BUFFER_BINDING;
          case gK.PIXEL_UNPACK_BUFFER:
            return gK.PIXEL_UNPACK_BUFFER_BINDING;
          case gK.TRANSFORM_FEEDBACK_BUFFER:
            return gK.TRANSFORM_FEEDBACK_BUFFER_BINDING;
          default:
            return 0
        }
      }(KO);
      return pO ? OO.getParameter(pO) : null
    }

    function IK(OO) {
      const KO = SO.get(OO);
      KO && (cK.shadowBytes -= KO.bytes.length, SO.delete(OO))
    }

    function yp(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
      IK(OO), cK.shadowBytes + KO > sO ? cK.uncopied++ : (cK.shadowBytes += KO, SO.set(OO, {
        id: GO(OO),
        bytes: new Uint8Array(KO),
        width: pO,
        height: XO,
        texelBytes: bK,
        missed: 0
      }))
    }

    function gp(OO, KO) {
      for (const pO of ["deleteBuffer", "deleteTexture"]) ap(OO, pO, (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return pO[0] && IK(pO[0]), dK(OO, this, pO)
      }));
      ap(OO, "shaderSource", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return pO[0] && "string" === typeof pO[1] && FK.set(pO[0], pO[1]), dK(OO, this, pO)
      })), ap(OO, "attachShader", (OO => function() {
        for (var KO, pO = arguments.length, XO = new Array(pO), bK = 0; bK < pO; bK++) XO[bK] = arguments[bK];
        const eO = XO[0],
          lO = null !== (KO = VK.get(eO)) && void 0 !== KO ? KO : [];
        return lO.push(XO[1]), VK.set(eO, lO), dK(OO, this, XO)
      })), ap(OO, "linkProgram", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO);
        return cK.inProbe || function(OO, KO) {
          var pO;
          "undefined" !== typeof HTMLCanvasElement && OO.canvas instanceof HTMLCanvasElement && function(OO) {
            if (ip.has(OO)) return;
            ip.add(OO);
            for (const KO of ["webglcontextlost", "webglcontextrestored", "webglcontextcreationerror"]) OO.addEventListener(KO, (OO => {
              QK.lost < DK && (QK.lost++, DO(`${KO}${"statusMessage"in OO?`: ${String(OO.statusMessage)}`:""}`))
            }))
          }(OO.canvas);
          cK.context ??= OO;
          const XO = null !== (pO = VK.get(KO)) && void 0 !== pO ? pO : [];
          let bK = "",
            eO = "";
          for (const CO of XO) {
            var lO;
            const OO = null !== (lO = FK.get(CO)) && void 0 !== lO ? lO : "";
            /\bgl_Position\b/.test(OO) ? bK = OO : eO = OO
          }
          const vK = {
            id: GO(KO),
            gl: OO,
            vertex: bK,
            fragment: eO,
            terrain: EK(bK),
            checked: !1,
            firstDraw: !1
          };
          if (LK.set(KO, vK), RO.push([KO, vK]), null !== vK.terrain) {
            const KO = XO.map((KO => {
              var pO;
              return null !== (pO = OO.getShaderInfoLog(KO)) && void 0 !== pO ? pO : ""
            })).filter((OO => "" !== OO.trim()));
            KO.length > 0 && MO(`program #${vK.id} (${vK.terrain}) shader logs:\n${aK(KO.join("\n"))}`)
          }
        }(this, pO[0]), bK
      })), ap(OO, "bufferData", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO);
        if (!cK.inProbe) {
          const OO = NK(this, pO[0]);
          if (OO) {
            var eO, lO, vK;
            const KO = "number" === typeof pO[1] ? null : TK(pO[1], null !== (eO = pO[3]) && void 0 !== eO ? eO : 0, null !== (lO = pO[4]) && void 0 !== lO ? lO : 0);
            var CO;
            if (yp(OO, "number" === typeof pO[1] ? pO[1] : null !== (vK = null === KO || void 0 === KO ? void 0 : KO.length) && void 0 !== vK ? vK : 0), KO) null === (CO = SO.get(OO)) || void 0 === CO || CO.bytes.set(KO)
          }
        }
        return bK
      })), ap(OO, "bufferSubData", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO);
        if (!cK.inProbe) {
          var eO, lO;
          const OO = NK(this, pO[0]),
            KO = OO ? SO.get(OO) : void 0,
            XO = TK(pO[2], null !== (eO = pO[3]) && void 0 !== eO ? eO : 0, null !== (lO = pO[4]) && void 0 !== lO ? lO : 0);
          if (KO && XO) {
            const OO = pO[1];
            KO.bytes.set(XO.subarray(0, Math.max(0, KO.bytes.length - OO)), OO), uK("buffer", KO, OO, XO.length)
          }
        }
        return bK
      })), KO && (ap(OO, "copyBufferSubData", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO);
        if (!cK.inProbe) {
          const [OO, KO, XO, bK, eO] = pO, lO = NK(this, OO), vK = NK(this, KO), CO = lO ? SO.get(lO) : void 0, hO = vK ? SO.get(vK) : void 0;
          hO && (CO ? hO.bytes.set(CO.bytes.slice(XO, XO + eO), bK) : hO.missed++)
        }
        return bK
      })), ap(OO, "texStorage2D", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO),
          [, , eO, lO, vK] = pO;
        if (!cK.inProbe && (eO === gK.RGBA32UI || eO === gK.RGBA16UI)) {
          const OO = this.getParameter(gK.TEXTURE_BINDING_2D),
            KO = eO === gK.RGBA32UI ? 16 : 8;
          OO && (JO.set(OO, KO), yp(OO, lO * vK * KO, lO, vK, KO))
        }
        return bK
      })), ap(OO, "texSubImage2D", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO);
        return !cK.inProbe && pO.length >= 9 && pO[0] === gK.TEXTURE_2D && 0 === pO[1] && function(OO, KO) {
          var pO;
          const XO = OO.getParameter(gK.TEXTURE_BINDING_2D),
            bK = XO ? SO.get(XO) : void 0;
          if (!bK) return;
          const [, , eO, lO, vK, CO] = KO;
          let hO = TK(KO[8], null !== (pO = KO[9]) && void 0 !== pO ? pO : 0);
          if (null === hO && "number" === typeof KO[8]) {
            const pO = NK(OO, gK.PIXEL_UNPACK_BUFFER),
              XO = pO ? SO.get(pO) : void 0;
            hO = XO ? XO.bytes.subarray(KO[8]) : null
          }
          if (null === hO) return void bK.missed++;
          const DO = OO.getParameter(gK.UNPACK_ROW_LENGTH) || vK,
            MO = OO.getParameter(gK.UNPACK_SKIP_ROWS),
            aK = OO.getParameter(gK.UNPACK_SKIP_PIXELS),
            oO = bK.texelBytes;
          for (let FO = 0; FO < CO; FO++) {
            const OO = ((MO + FO) * DO + aK) * oO,
              KO = ((lO + FO) * bK.width + eO) * oO;
            bK.bytes.set(hO.subarray(OO, OO + vK * oO), KO)
          }
          uK("texture", bK, (lO * bK.width + eO) * oO, vK * CO * oO)
        }(this, pO), bK
      })), ap(OO, "copyTexSubImage2D", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = pO[0] === gK.TEXTURE_2D ? this.getParameter(gK.TEXTURE_BINDING_2D) : null,
          eO = bK ? SO.get(bK) : void 0;
        return eO && eO.missed++, dK(OO, this, pO)
      })));
      for (const pO of ["drawArrays", "drawElements", "drawArraysInstanced", "drawElementsInstanced"]) ap(OO, pO, (OO => function() {
        for (var KO = arguments.length, XO = new Array(KO), bK = 0; bK < KO; bK++) XO[bK] = arguments[bK];
        const eO = dK(OO, this, XO);
        return cK.inProbe || YK(this, pO, XO), eO
      }));
      ap(OO, "getExtension", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        const bK = dK(OO, this, pO);
        return bK && "object" === typeof bK && function(OO, KO, pO) {
          const XO = {
            WEBGL_multi_draw: ["multiDrawArraysWEBGL", "multiDrawElementsWEBGL", "multiDrawArraysInstancedWEBGL", "multiDrawElementsInstancedWEBGL"],
            ANGLE_instanced_arrays: ["drawArraysInstancedANGLE", "drawElementsInstancedANGLE"]
          };
          if (!(KO in XO) || pO.bloxdRenderDebug) return;
          pO.bloxdRenderDebug = !0;
          for (const bK of XO[KO]) {
            const KO = pO[bK];
            "function" === typeof KO && (pO[bK] = function() {
              for (var XO = arguments.length, eO = new Array(XO), lO = 0; lO < XO; lO++) eO[lO] = arguments[lO];
              const vK = Reflect.apply(KO, pO, eO);
              return cK.inProbe || YK(OO, bK, eO), vK
            })
          }
        }(this, pO[0], bK), bK
      }))
    }

    function uK(OO, KO, pO, XO) {
      AK[OO] += XO, fK < 32 && KO.bytes.length >= 1 << 20 && (fK++, MO(`upload ${OO} #${KO.id} +${pO} ${XO} B`))
    }

    function EK(OO) {
      if (!OO.includes("decodeQuad")) return null;
      return !/^\s*#version 300 es/.test(OO) || /in uvec3 _p2vs_location0\b/.test(OO) ? "inst" : "tex"
    }

    function jp(OO, KO, pO) {
      var XO;
      if (pO.checked) return;
      pO.checked = !0;
      const bK = OO.getProgramParameter(KO, gK.LINK_STATUS),
        eO = (null !== (XO = OO.getProgramInfoLog(KO)) && void 0 !== XO ? XO : "").trim();
      var lO;
      null === pO.terrain && bK || (DO(`program #${pO.id} ${null!==(lO=pO.terrain)&&void 0!==lO?lO:"other"} link ${bK?"ok":"FAILED"}${eO?`: ${aK(eO,300)}`:""}`), eO && MO(`program #${pO.id} link log:\n${aK(eO)}`))
    }

    function YK(OO, KO, pO) {
      var XO;
      const bK = OO.getParameter(gK.CURRENT_PROGRAM),
        eO = bK ? LK.get(bK) : void 0;
      if (!bK || !eO) return;
      const lO = null !== (XO = eO.terrain) && void 0 !== XO ? XO : "other",
        {
          Xl: vK,
          instances: CO
        } = function(OO, KO) {
          switch (OO) {
            case "drawArrays":
              return {
                Xl: [
                  [KO[1], KO[2]]
                ], instances: 1
              };
            case "drawArraysInstanced":
            case "drawArraysInstancedANGLE":
              return {
                Xl: [
                  [KO[1], KO[2]]
                ], instances: KO[3]
              };
            case "drawElements":
              return {
                Xl: [
                  [0, KO[1]]
                ], instances: 1
              };
            case "drawElementsInstanced":
            case "drawElementsInstancedANGLE":
              return {
                Xl: [
                  [0, KO[1]]
                ], instances: KO[4]
              };
            case "multiDrawArraysWEBGL": {
              const OO = KO[1],
                pO = KO[3],
                XO = KO[2],
                bK = KO[4],
                eO = [];
              for (let lO = 0; lO < KO[5]; lO++) eO.push([OO[XO + lO], pO[bK + lO]]);
              return {
                Xl: eO,
                instances: 1
              }
            }
            default:
              return {
                Xl: [], instances: 0
              }
          }
        }(KO, pO),
        hO = "inst" === eO.terrain ? CO : vK.reduce(((OO, KO) => {
          let [, pO] = KO;
          return OO + pO
        }), 0) / 6;
      if (zp[lO].draws++, zp[lO].faces += hO, null === eO.terrain) return;
      if (cK.context = OO, !eO.firstDraw) {
        eO.firstDraw = !0, jp(OO, bK, eO), wK || (wK = !0, DO(function(OO) {
          var KO;
          const pO = OO.getParameter(gK.DEPTH_FUNC),
            XO = {
              513: "less",
              514: "equal",
              515: "lequal",
              516: "greater",
              518: "gequal",
              519: "always"
            };
          let bK = "default framebuffer";
          if ("DRAW_FRAMEBUFFER" in OO && OO.getParameter(gK.DRAW_FRAMEBUFFER_BINDING)) {
            const KO = OO;
            bK = KO.getFramebufferAttachmentParameter(gK.DRAW_FRAMEBUFFER, gK.DEPTH_ATTACHMENT, gK.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE) ? `depth ${String(KO.getFramebufferAttachmentParameter(gK.DRAW_FRAMEBUFFER,gK.DEPTH_ATTACHMENT,gK.FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE))} bits type 0x${Number(KO.getFramebufferAttachmentParameter(gK.DRAW_FRAMEBUFFER,gK.DEPTH_ATTACHMENT,gK.FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE)).toString(16)}` : "no depth attachment"
          }
          const eO = OO.getParameter(gK.DEPTH_CLEAR_VALUE);
          return `depth ${null!==(KO=XO[pO])&&void 0!==KO?KO:`0x${pO.toString(16)}`} clear ${eO}${516===pO||518===pO?" (reverse-Z)":""}, samples ${String(OO.getParameter(gK.SAMPLES))}, ${bK}`
        }(OO)));
        const pO = OO.getError();
        pO !== gK.NO_ERROR && QK.gl < DK && (QK.gl++, DO(`GL error 0x${pO.toString(16)} after program #${eO.id}'s first terrain draw (${KO})`))
      }
      const MO = cK.pendingCheck;
      null !== MO && (MO.terrainDraws++, MO.draws.length < MK && qK(OO, bK, eO, KO, vK, CO))
    }
    let wK = !1;
    const ip = new WeakSet;
    const rp = ["maxStorageBuffersPerShaderStage", "maxStorageBufferBindingSize", "maxBufferSize", "maxUniformBufferBindingSize", "minUniformBufferOffsetAlignment", "maxTextureDimension2D", "maxTextureArrayLayers", "maxVertexBuffers", "maxVertexAttributes", "maxVertexBufferArrayStride", "maxBindGroups", "maxColorAttachmentBytesPerSample"];
    let PK = !1;
    const mp = new WeakSet,
      sK = new WeakMap,
      HK = new WeakMap,
      RK = {
        uncaptured: 0,
        compile: 0
      };
    let SK = 0,
      JK = !1,
      cp = null,
      BK = {
        draws: 0,
        faces: 0
      };

    function ZK(OO) {
      const KO = globalThis[OO];
      return null === KO || void 0 === KO ? void 0 : KO.prototype
    }

    function GK(OO) {
      return OO && "function" === typeof OO[Symbol.iterator] ? [...OO].sort().join(" ") : ""
    }

    function qp(OO, KO) {
      const pO = null !== OO && void 0 !== OO ? OO : {},
        XO = null !== KO && void 0 !== KO ? KO : Object.keys(Object.getPrototypeOf(pO)).concat(Object.keys(pO));
      return [...new Set(XO)].filter((OO => "number" === typeof pO[OO])).map((OO => `${OO} ${String(pO[OO])}`)).join(", ")
    }

    function xp(OO, KO) {
      var pO;
      const XO = null !== (pO = KO.vertex) && void 0 !== pO ? pO : {};
      if (XO.module && mp.has(XO.module)) {
        var bK;
        const pO = String(null !== (bK = XO.entryPoint) && void 0 !== bK ? bK : "");
        if (pO.startsWith("vs_packed") && sK.set(OO, pO), !JK) {
          var eO, lO, vK, CO, hO;
          JK = !0;
          const OO = null !== (eO = KO.depthStencil) && void 0 !== eO ? eO : {},
            XO = null !== (lO = KO.multisample) && void 0 !== lO ? lO : {},
            bK = String(null !== (vK = OO.depthCompare) && void 0 !== vK ? vK : "");
          DO(`WebGPU terrain pipeline ${pO}: depth ${String(null!==(CO=OO.format)&&void 0!==CO?CO:"none")} ${bK}${bK.startsWith("greater")?" (reverse-Z)":""}, MSAA ${String(null!==(hO=XO.count)&&void 0!==hO?hO:1)}`)
        }
      }
    }

    function nK(OO) {
      ap(OO, "setPipeline", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return HK.set(this, pO[0]), Reflect.apply(OO, this, pO)
      }));
      for (const KO of ["draw", "drawIndexed", "drawIndirect", "drawIndexedIndirect"]) ap(OO, KO, (OO => function() {
        const pO = HK.get(this),
          XO = pO ? sK.get(pO) : void 0;
        for (var bK = arguments.length, eO = new Array(bK), lO = 0; lO < bK; lO++) eO[lO] = arguments[lO];
        return void 0 !== XO && WK(KO, XO, eO), Reflect.apply(OO, this, eO)
      }))
    }

    function WK(OO, KO, pO) {
      var XO;
      (BK.draws++, "draw" === OO || "drawIndexed" === OO) && (BK.faces += pO[0] * (null !== (XO = pO[1]) && void 0 !== XO ? XO : 1) / 6);
      if (null !== cp && cp.length < MK) {
        const XO = ("draw" === OO ? ["vertices", "instances", "firstVertex", "firstInstance"] : "drawIndexed" === OO ? ["indices", "instances", "firstIndex", "baseVertex", "firstInstance"] : ["indirectOffset"]).map(((KO, XO) => {
          const bK = OO.endsWith("Indirect") ? pO[1] : pO[XO];
          return `${KO} ${String(null!==bK&&void 0!==bK?bK:"instances"===KO?1:0)}`
        }));
        cp.push(`  ${KO} ${OO} ${XO.join(" ")}`)
      }
    }

    function tp() {
      if (PK || "undefined" === typeof navigator || !("gpu" in navigator)) return;
      PK = !0, ap(ZK("GPU"), "requestAdapter", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return Reflect.apply(OO, this, pO).then((OO => {
          var KO;
          OO ? function(OO) {
            var KO;
            const pO = null !== (KO = OO.info) && void 0 !== KO ? KO : {};
            DO(`WebGPU adapter ${["vendor","architecture","device","description"].map((OO=>{var KO;return`${OO} "${String(null!==(KO=pO[OO])&&void 0!==KO?KO:"")}"`})).join(" ")}${OO.isFallbackAdapter?" (fallback)":""}`), DO(`WebGPU adapter features ${GK(OO.features)}`), DO(`WebGPU adapter limits ${qp(OO.limits,rp)}`), MO(`WebGPU adapter all limits ${qp(OO.limits,null)}`)
          }(OO) : DO(`WebGPU requestAdapter(${JSON.stringify(null!==(KO=pO[0])&&void 0!==KO?KO:{})}) gave none`);
          return OO
        }))
      })), ap(ZK("GPUAdapter"), "requestDevice", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return Reflect.apply(OO, this, pO).then((OO => (function(OO) {
          DO(`WebGPU device features ${GK(OO.features)}`), DO(`WebGPU device limits ${qp(OO.limits,rp)}`), OO.addEventListener("uncapturederror", (OO => {
            if (RK.uncaptured < DK) {
              var KO, pO, XO;
              RK.uncaptured++;
              const bK = OO.error;
              DO(`WebGPU uncaptured ${null!==(KO=null===bK||void 0===bK||null===(pO=bK.constructor)||void 0===pO?void 0:pO.name)&&void 0!==KO?KO:"error"}: ${aK(String(null!==(XO=null===bK||void 0===bK?void 0:bK.message)&&void 0!==XO?XO:""),600)}`)
            }
          }));
          const KO = OO.lost;
          null === KO || void 0 === KO || KO.then((OO => {
            var KO;
            DO(`WebGPU device lost (${String(OO.reason)}): ${aK(String(null!==(KO=OO.message)&&void 0!==KO?KO:""),600)}`)
          }))
        }(OO), OO)), (OO => {
          throw DO(`WebGPU requestDevice failed: ${String(OO)}`), OO
        }))
      }));
      const OO = ZK("GPUDevice");
      ap(OO, "createShaderModule", (OO => function() {
        for (var KO, pO, XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
        const lO = Reflect.apply(OO, this, bK);
        return function(OO, KO) {
          const pO = KO.includes("decodeQuad");
          pO && mp.add(OO);
          const XO = OO.getCompilationInfo;
          null === XO || void 0 === XO || XO.call(OO).then((OO => {
            if (0 === OO.messages.length && !pO) return;
            const KO = {};
            for (const pO of OO.messages) {
              var XO;
              KO[String(pO.type)] = (null !== (XO = KO[String(pO.type)]) && void 0 !== XO ? XO : 0) + 1
            }
            const bK = OO.messages.map((OO => `${String(OO.type)} ${String(OO.lineNum)}:${String(OO.linePos)} ${String(OO.message)}`)).join("\n");
            RK.compile < DK && (RK.compile++, DO(`WebGPU ${pO?"terrain ":""}shader module compiled: ${JSON.stringify(KO)}${bK?` first: ${aK(bK.split("\n")[0],300)}`:""}`)), bK && MO(`WebGPU shader module messages:\n${aK(bK)}`)
          }))
        }(lO, String(null !== (KO = (null !== (pO = bK[0]) && void 0 !== pO ? pO : {}).code) && void 0 !== KO ? KO : "")), lO
      })), ap(OO, "createRenderPipeline", (OO => function() {
        for (var KO, pO = arguments.length, XO = new Array(pO), bK = 0; bK < pO; bK++) XO[bK] = arguments[bK];
        const eO = Reflect.apply(OO, this, XO);
        return xp(eO, null !== (KO = XO[0]) && void 0 !== KO ? KO : {}), eO
      })), ap(OO, "createRenderPipelineAsync", (OO => function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        return Reflect.apply(OO, this, pO).then((OO => {
          var KO;
          return xp(OO, null !== (KO = pO[0]) && void 0 !== KO ? KO : {}), OO
        }))
      })), ap(ZK("GPUCanvasContext"), "configure", (OO => function() {
        for (var KO, pO = arguments.length, XO = new Array(pO), bK = 0; bK < pO; bK++) XO[bK] = arguments[bK];
        const eO = null !== (KO = XO[0]) && void 0 !== KO ? KO : {};
        var lO, vK;
        SK++ < 3 && DO(`WebGPU canvas ${String(eO.format)} ${String(null!==(lO=eO.colorSpace)&&void 0!==lO?lO:"srgb")} alpha ${String(null!==(vK=eO.alphaMode)&&void 0!==vK?vK:"opaque")}`);
        return Reflect.apply(OO, this, XO)
      })), nK(ZK("GPURenderPassEncoder")), nK(ZK("GPURenderBundleEncoder"))
    }
    const kp = 1e4,
      UK = 5e3;
    let Op = null,
      Kp = !1,
      pp = "1",
      Xp = !1,
      bX = null,
      ep = 0;

    function lp() {
      Kp || (Kp = !0, pp = "0" === (0, XO.m)("faceCull") ? "0" : "1", window.bloxdRenderDebug = {
        faceCull: pp
      }, DO("quality steps off while the topic is on (util/weakGpu.ts): no stepped MSAA or scale, no weak-GPU tier"), oK || "undefined" === typeof window || (oK = !0, "undefined" !== typeof WebGL2RenderingContext && gp(WebGL2RenderingContext.prototype, !0), "undefined" !== typeof WebGLRenderingContext && gp(WebGLRenderingContext.prototype, !1)), tp(), (0, XO.d)("renderProbe", (() => {
        Mp("console")
      })), hp(), setInterval(aX, UK))
    }

    function vX(OO) {
      var KO, pO;
      lp(), Op = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.backend) && void 0 !== KO ? KO : null, DO(null === OO ? "backend: none picked (no renderer build)" : `backend ${OO.backend}: reason ${OO.reason}, source ${OO.source}, adapter ${OO.adapter?`${OO.adapter.vendor}/${OO.adapter.architecture}`:"none"}, renderer param ${null!==(pO=(0,XO.m)("renderer"))&&void 0!==pO?pO:"none"}, faceCull ${"0"===pp?"off (whole parts)":"on"}`)
    }

    function Cp() {
      setTimeout((() => {
        Mp(kp / 1e3 + " s after playable")
      }), kp), LO((() => {
        var OO;
        return null !== (OO = bX) && void 0 !== OO ? OO : Promise.resolve()
      }))
    }

    function hp() {
      requestAnimationFrame((() => {
        ep++, hp()
      }))
    }

    function Dp() {
      var OO, KO;
      if (Xp) return;
      Xp = !0;
      const pO = window.bloxdRenderDebug;
      DO(`renderer caps ${null!==(OO=null===pO||void 0===pO?void 0:pO.caps)&&void 0!==OO?OO:"(not noted)"}; terrain fetch ${null!==(KO=null===pO||void 0===pO?void 0:pO.fetch)&&void 0!==KO?KO:"(not noted)"}`);
      const XO = cK.context;
      if (XO) {
        for (const OO of function(OO) {
            var KO;
            const pO = [],
              XO = OO.getExtension("WEBGL_debug_renderer_info"),
              bK = XO ? OO.getParameter(XO.UNMASKED_VENDOR_WEBGL) : "(masked)",
              eO = XO ? OO.getParameter(XO.UNMASKED_RENDERER_WEBGL) : "(masked)";
            pO.push(`GL ${String(OO.getParameter(OO.VERSION))} | ${String(OO.getParameter(OO.SHADING_LANGUAGE_VERSION))} | ${String(OO.getParameter(OO.VENDOR))} / ${String(OO.getParameter(OO.RENDERER))}`), pO.push(`GL unmasked ${bK} / ${eO}`);
            const lO = [
              ["MAX_TEXTURE_SIZE", OO.MAX_TEXTURE_SIZE],
              ["MAX_VERTEX_ATTRIBS", OO.MAX_VERTEX_ATTRIBS],
              ["MAX_VERTEX_UNIFORM_VECTORS", OO.MAX_VERTEX_UNIFORM_VECTORS],
              ["MAX_VERTEX_TEXTURE_IMAGE_UNITS", OO.MAX_VERTEX_TEXTURE_IMAGE_UNITS],
              ["MAX_COMBINED_TEXTURE_IMAGE_UNITS", OO.MAX_COMBINED_TEXTURE_IMAGE_UNITS],
              ["MAX_VARYING_VECTORS", OO.MAX_VARYING_VECTORS],
              ["MAX_RENDERBUFFER_SIZE", OO.MAX_RENDERBUFFER_SIZE]
            ];
            "MAX_UNIFORM_BLOCK_SIZE" in OO && lO.push(["MAX_UNIFORM_BLOCK_SIZE", OO.MAX_UNIFORM_BLOCK_SIZE], ["MAX_VERTEX_UNIFORM_BLOCKS", OO.MAX_VERTEX_UNIFORM_BLOCKS], ["MAX_SAMPLES", OO.MAX_SAMPLES], ["MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS", OO.MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS]), pO.push(`GL limits ${lO.map((KO=>{let[pO,XO]=KO;return`${pO} ${String(OO.getParameter(XO))}`})).join(", ")}`);
            const vK = (KO, pO) => {
              const XO = OO.getShaderPrecisionFormat(KO, OO.HIGH_FLOAT),
                bK = OO.getShaderPrecisionFormat(KO, OO.HIGH_INT);
              return `${pO} highp float ${XO?`${XO.rangeMin}/${XO.rangeMax}/${XO.precision}`:"?"} int ${bK?`${bK.rangeMin}/${bK.rangeMax}/${bK.precision}`:"?"}`
            };
            pO.push(`GL precision ${vK(OO.VERTEX_SHADER,"VS")}, ${vK(OO.FRAGMENT_SHADER,"FS")}`);
            const CO = OO.getContextAttributes();
            return pO.push(`GL context ${JSON.stringify(CO)} drawingBuffer ${OO.drawingBufferWidth}x${OO.drawingBufferHeight}${"drawingBufferFormat"in OO?` format 0x${Number(OO.drawingBufferFormat).toString(16)}`:""}${"drawingBufferColorSpace"in OO?` ${String(OO.drawingBufferColorSpace)}`:""}`), pO.push(`GL extensions ${(null!==(KO=OO.getSupportedExtensions())&&void 0!==KO?KO:[]).join(" ")}`), pO
          }(XO)) DO(OO);
        ! function() {
          if (!cK.context) return;
          let OO = 0,
            KO = 0;
          for (const [pO, XO] of RO) !XO.gl.isContextLost() && XO.gl.isProgram(pO) && (KO++, jp(XO.gl, pO, XO), null !== XO.terrain && OO++);
          DO(`programs: ${KO} live of ${RO.length} linked, ${OO} packed terrain; CPU page copies ${Math.round(cK.shadowBytes/1048576)} MiB (${cK.uncopied} over budget)`)
        }()
      }
    }

    function Mp(OO) {
      return bX ??= async function(OO) {
        Dp(), "webgpu" === Op ? await
        function(OO) {
          if (null !== cp) return Promise.resolve();
          const KO = [];
          return cp = KO, new Promise((pO => {
            setTimeout((() => {
              cp = null, DO(`WebGPU draw ranges (${OO}): ${KO.length} terrain draws recorded in a second (first ${MK}; bundles replay without new ones)`);
              for (const OO of KO) DO(OO);
              pO()
            }), 1e3)
          }))
        }(OO): await hK(OO);
        DO(`check (${OO}) done: bloxdDebug.save() downloads it all`)
      }(OO).catch((KO => {
        DO(`check (${OO}) failed: ${String(KO)}`)
      })).finally((() => {
        bX = null
      })), bX
    }

    function aX() {
      const OO = OO => ep ? (OO / ep).toFixed(1) : "0",
        KO = function() {
          const OO = BK;
          return BK = {
            draws: 0,
            faces: 0
          }, OO
        }(),
        pO = function() {
          const OO = zp;
          return zp = {
            inst: {
              draws: 0,
              faces: 0
            },
            tex: {
              draws: 0,
              faces: 0
            },
            other: {
              draws: 0,
              faces: 0
            }
          }, OO
        }(),
        XO = function() {
          const OO = AK;
          return AK = {
            buffer: 0,
            texture: 0
          }, OO
        }(),
        bK = "webgpu" === Op ? [`terrain ${OO(KO.draws)} draws ${OO(KO.faces)} faces a frame (bundles' replays uncounted)`] : ["inst", "tex", "other"].filter((OO => pO[OO].draws > 0)).map((KO => `${KO} ${OO(pO[KO].draws)} draws ${OO(pO[KO].faces)} faces a frame`));
      DO(`${ep} frames: ${bK.join(", ")||"no draws"}; uploaded ${Math.round(XO.buffer/1024)} KiB to buffers, ${Math.round(XO.texture/1024)} KiB to data textures`), ep = 0
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);