export const id = 11;
export const ids = [11];
export const modules = {
  35130: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => aK,
      k: () => MO
    });
    var XO = pO(8311),
      bK = pO(35137),
      eO = pO(35139),
      lO = pO(7854),
      vK = pO(1263),
      CO = pO(63),
      hO = pO(77),
      DO = pO(976);

    function MO() {
      var OO;
      return (0, vK.h)(bK.d, (0, bK.l)()), (0, DO.jsx)(DO.Fragment, {
        children: null === (OO = (0, bK.l)()) || void 0 === OO ? void 0 : OO.content
      })
    }

    function aK(OO) {
      var KO;
      let {
        show: pO
      } = OO;
      (0, vK.h)(bK.d, (0, bK.l)());
      const hO = null === (KO = (0, bK.l)()) || void 0 === KO ? void 0 : KO.menu;
      return (0, CO.useEffect)((() => {
        var OO;
        pO || (null === hO || void 0 === hO || null === (OO = hO.onClose) || void 0 === OO || OO.call(hO), (0, eO.q)())
      }), [pO, hO]), (0, CO.useEffect)((() => pO ? (0, lO.f)(eO.y, eO.f) : void 0), [pO]), (0, DO.jsx)(XO.e, {
        showing: pO,
        globallyUniqueKey: "clientGameMenu",
        children: null === hO || void 0 === hO ? void 0 : hO.content
      })
    }

    function oO(OO) {
      let {
        placement: KO = "bottom"
      } = OO;
      return (0, DO.jsx)("div", {
        id: `clientGameHud-${KO}`,
        style: {
          display: "contents"
        }
      })
    }

    function FO(OO) {
      let {
        children: KO,
        placement: pO = "bottom"
      } = OO;
      const [XO, bK] = (0, CO.useState)(null);
      return (0, CO.useEffect)((() => {
        bK(document.getElementById(`clientGameHud-${pO}`))
      }), [pO]), XO ? (0, hO.createPortal)(KO, XO) : null
    }
  },
  35072: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      i: () => oO,
      k: () => aK,
      l: () => VO,
      m: () => FO,
      p: () => DO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(35075),
      vK = pO(26),
      CO = pO(1969),
      hO = pO(976);

    function DO(OO, KO) {
      const pO = (0, XO.useRef)(null);
      return (0, XO.useLayoutEffect)((() => (lO.d.set(OO, pO.current, KO), () => {
        lO.d.set(OO, null)
      })), [OO, KO]), pO
    }
    const MO = "touchKeysChanged",
      aK = {
        Crouch: "C",
        Jump: "J",
        Use: "U",
        Primary: "P",
        Attack: "A",
        Game: "G",
        Context: "X"
      },
      oO = (0, XO.forwardRef)((function(OO, KO) {
        let {
          slot: pO,
          canvasZone: bK = !1,
          lit: lO = !1,
          label: CO,
          className: DO,
          children: aK,
          ...oO
        } = OO;
        return (0, XO.useEffect)((() => (vK.i.pl(MO), () => {
          vK.i.pl(MO)
        })), []), (0, hO.jsx)("div", {
          ref: KO,
          className: eO()("TouchKeyHit", `TouchSlot${pO}`, DO, {
            CanvasZone: bK
          }),
          ...oO,
          children: (0, hO.jsxs)("div", {
            className: eO()("TouchKey", {
              Lit: lO,
              Labelled: void 0 !== CO
            }),
            children: [aK, void 0 !== CO && (0, hO.jsx)("span", {
              className: "TouchKeyLabel",
              children: CO
            })]
          })
        })
      }));

    function FO(OO, KO) {
      (0, XO.useEffect)((() => () => {
        KO.current && (KO.current = !1, (0, CO.u)(OO, !1, {
          isTrusted: !0,
          timeStamp: performance.now()
        }))
      }), [])
    }

    function VO(OO, KO) {
      const pO = KO ? [aK.Context] : [aK.Primary, aK.Context];
      return OO.filter((OO => null !== OO)).slice(0, pO.length).map(((OO, KO) => {
        const bK = pO[KO];
        return (0, hO.jsx)(XO.Fragment, {
          children: OO.render(bK)
        }, `${OO.id}:${bK}`)
      }))
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  35232: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      f: () => CO
    });
    var XO = pO(63),
      bK = pO(22),
      eO = pO(1263),
      lO = pO(35072);

    function vK(OO, KO, pO) {
      let XO = null;
      for (const eO of document.querySelectorAll(".TouchComponentsButtons .TouchKeyHit")) {
        const lO = eO.getBoundingClientRect();
        var bK;
        if (lO.height > 0 && lO.top > pO && lO.left < KO && lO.right > OO) XO = Math.min(null !== (bK = XO) && void 0 !== bK ? bK : lO.top, lO.top)
      }
      return XO
    }

    function CO(OO, KO) {
      const {
        isTouchScreen: pO
      } = (0, bK.l)(["isTouchScreen"]), CO = (0, XO.useRef)(null);
      (0, eO.f)(lO.e, (() => {
        var OO;
        null === (OO = CO.current) || void 0 === OO || OO.call(CO)
      })), (0, XO.useEffect)((() => {
        const XO = null === OO || void 0 === OO ? void 0 : OO.closest(KO),
          bK = document.querySelector(".BottomRightElements");
        if (!pO || !OO || !XO || !bK) return;
        const eO = () => {
          ! function(OO, KO) {
            const pO = OO.getBoundingClientRect(),
              XO = vK(pO.left, pO.right, -1 / 0),
              bK = KO.getBoundingClientRect().bottom + parseFloat(getComputedStyle(KO).bottom),
              eO = null === XO ? "0px" : `${Math.ceil(bK-XO+4)}px`;
            KO.style.getPropertyValue("--touch-keys-reach") !== eO && KO.style.setProperty("--touch-keys-reach", eO)
          }(OO, XO)
        };
        CO.current = eO;
        const lO = new ResizeObserver(eO);
        return lO.observe(OO), lO.observe(bK), window.addEventListener("resize", eO), () => {
          CO.current = null, lO.disconnect(), window.removeEventListener("resize", eO), XO.style.setProperty("--touch-keys-reach", "0px")
        }
      }), [pO, OO, KO])
    }
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  35322: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    const XO = new Map;

    function bK(OO) {
      var KO;
      return null === OO ? null : null !== (KO = XO.get(OO)) && void 0 !== KO ? KO : null
    }

    function eO(OO, KO) {
      return XO.set(OO, KO), () => {
        XO.get(OO) === KO && XO.delete(OO)
      }
    }
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  36818: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => dO,
      D: () => fO,
      G: () => aK,
      J: () => VO,
      L: () => QO,
      N: () => bK,
      e: () => DO,
      f: () => CO,
      h: () => AO,
      i: () => hO,
      l: () => vK,
      n: () => lO,
      p: () => eO,
      q: () => NO,
      u: () => oO,
      w: () => TO,
      z: () => IO
    });
    var XO = pO(8458);

    function bK(OO) {
      return Math.floor(OO).toLocaleString("en-US")
    }
    const eO = 2e3,
      lO = .005,
      vK = .001,
      CO = 2,
      hO = "Fluid Tank",
      DO = "Coolant Mixer",
      MO = 144;

    function aK(OO) {
      const KO = OO.split("|")[0];
      return (0, XO.n)(KO) ? KO === XO.e ? "cryo" : "water" : null
    }
    const oO = [
        [1, 0, 0],
        [-1, 0, 0],
        [0, 1, 0],
        [0, -1, 0],
        [0, 0, 1],
        [0, 0, -1]
      ],
      FO = 63;

    function VO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      const pO = KO ? function(OO, KO, pO) {
        const XO = oO.findIndex((XO => {
          let [bK, eO, lO] = XO;
          return bK === OO && eO === KO && lO === pO
        }));
        return XO < 0 ? 0 : 1 << XO
      }(KO[0], KO[1], KO[2]) : 0;
      return "maker" === OO ? {
        kind: OO,
        faces: pO
      } : "user" === OO ? {
        kind: OO,
        faces: FO & ~pO
      } : {
        kind: OO,
        faces: FO
      }
    }

    function LO(OO) {
      return "pipe" === OO || "tank" === OO || "maker" === OO
    }

    function QO(OO, KO, pO) {
      return 0 !== (OO.faces & 1 << pO) && 0 !== (KO.faces & 1 << (1 ^ pO)) && (LO(OO.kind) || LO(KO.kind))
    }
    const zK = (OO, KO, pO, XO) => ({
        input: OO,
        inputAmount: XO,
        output: KO,
        outputAmount: pO
      }),
      AO = {
        Condenser: {
          kind: "Condenser",
          opMs: 2e3,
          inputSlot: null,
          fuelSlot: null,
          outputSlots: [],
          recipes: [],
          powerPerOp: 60,
          fluidMade: 12,
          couplable: !0,
          couplerSlot: 0
        },
        Centrifuge: {
          kind: "Centrifuge",
          opMs: 12e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [zK("Uranium Grit", "Uranium Pellet", 1, 12), zK("Spent Pellet", "Plutonium Pellet", 1, 4)],
          powerPerOp: 600,
          waterPerOp: 24
        },
        Synthesizer: {
          kind: "Synthesizer",
          opMs: 6e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [1, 2, 3],
          recipes: [],
          powerPerOp: 120,
          waterPerOp: 12,
          synth: !0
        },
        "Coolant Mixer": {
          kind: "Coolant Mixer",
          opMs: 12e3,
          inputSlot: 0,
          fuelSlot: null,
          outputSlots: [],
          recipes: [zK("Biomass", "", 0, 1)],
          powerPerOp: 720,
          waterPerOp: 144,
          cryoMade: MO,
          couplable: !0,
          couplerSlot: 1
        }
      };

    function fO(OO, KO) {
      return 1e3 * (null !== KO && void 0 !== KO ? KO : 0) / OO.opMs
    }

    function dO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
      const pO = fO(AO["Coolant Mixer"], MO) * KO;
      return OO <= 0 ? 0 : Math.ceil(OO / pO - 1e-9)
    }
    const TO = "baf2Water",
      NO = "baf2waterclose",
      IO = "baf2wateropen"
  },
  36813: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => yK,
      f: () => fO,
      h: () => AO
    });
    var XO = pO(8365),
      bK = pO(8386),
      eO = pO(8458),
      lO = pO(36818),
      vK = pO(8449);
    const CO = (0, lO.J)("pipe"),
      hO = (0, lO.J)("tank"),
      DO = (0, lO.J)("port"),
      MO = "Reactor Port";

    function aK(OO, KO, pO) {
      const XO = new Set([eO.g, eO.e, MO, ...KO, ...pO, ...OO ? [lO.i] : []]);
      return {
        makers: new Set(KO),
        roots: XO
      }
    }
    const oO = {
        water: aK(!0, ["Condenser"], ["Centrifuge", "Synthesizer", lO.e]),
        cryo: aK(!1, [lO.e], [])
      },
      FO = new Set([...oO.water.roots, ...oO.cryo.roots]),
      VO = {
        nx: [-1, 0, 0],
        ny: [0, -1, 0],
        nz: [0, 0, -1],
        px: [1, 0, 0],
        py: [0, 1, 0],
        pz: [0, 0, 1]
      },
      LO = bK.f.map((OO => VO[OO])),
      QO = LO.map((OO => {
        let [KO, pO, XO] = OO;
        return lO.u.findIndex((OO => {
          let [bK, eO, lO] = OO;
          return bK === KO && eO === pO && lO === XO
        }))
      }));

    function zK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "water";
      const pO = XO.l[OO],
        bK = null === pO || void 0 === pO ? void 0 : pO.meta.rootName,
        aK = oO[KO];
      if (!bK || !aK.roots.has(bK)) return null;
      if ((0, eO.n)(bK)) return (0, lO.G)(pO.name) === KO ? CO : null;
      if (bK === lO.i) return hO;
      if (bK === MO) return pO.name.endsWith("|Water") ? DO : null;
      const [FO, VO] = vK.h[(pO.meta.rot || 1) - 1];
      return (0, lO.J)(aK.makers.has(bK) ? "maker" : "user", [-FO, 0, -VO])
    }

    function AO(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "water";
      const {
        makers: vK
      } = oO[eO];
      return LO.some(((hO, DO) => {
        var MO, aK;
        let [oO, FO, VO] = hO;
        const LO = OO(KO + oO, pO + FO, bK + VO),
          AO = zK(LO, eO);
        return null !== AO && vK.has(null !== (MO = null === (aK = XO.l[LO]) || void 0 === aK ? void 0 : aK.meta.rootName) && void 0 !== MO ? MO : "") && !(0, lO.L)(CO, AO, QO[DO])
      }))
    }

    function fO(OO) {
      const KO = XO.l[OO];
      return KO ? (0, lO.G)(KO.name) : null
    }
    let dO = null;

    function TO(OO) {
      if (!dO) {
        dO = new Map;
        for (const OO of ["water", "cryo"])
          for (let KO = 0; KO < 64; KO++)
            for (const pO of [!1, !0]) dO.set((0, eO.r)(OO, KO, pO), {
              Lp: OO,
              mask: KO,
              full: pO
            })
      }
      return dO.get(OO)
    }
    const NO = new Map(Array.from({
      length: eO.j + 1
    }, ((OO, KO) => [(0, eO.v)(KO), KO])));

    function IO(OO, KO, pO, bK, eO, lO) {
      return LO.some(((vK, CO) => {
        var hO, DO, MO;
        let [aK, oO, FO] = vK;
        if (0 === (lO >> CO & 1)) return !1;
        const VO = null !== (hO = null === (DO = XO.l[OO(KO + aK, pO + oO, bK + FO)]) || void 0 === DO ? void 0 : DO.name) && void 0 !== hO ? hO : "",
          LO = TO(VO);
        return LO ? LO.Lp === eO && LO.full : (null !== (MO = function(OO) {
          var KO;
          return null !== (KO = NO.get(OO)) && void 0 !== KO ? KO : null
        }(VO)) && void 0 !== MO ? MO : 0) > 0
      }))
    }
    class yK {
      constructor() {
        this.reshapeOffsets = LO
      }
      handles(OO) {
        return null !== fO(OO)
      }
      affects(OO) {
        var KO, pO;
        return FO.has(null !== (KO = null === (pO = XO.l[OO]) || void 0 === pO ? void 0 : pO.meta.rootName) && void 0 !== KO ? KO : "")
      }
      placedBy(OO) {
        var KO;
        return (null === (KO = XO.l[OO]) || void 0 === KO ? void 0 : KO.meta.rootName) === eO.e ? eO.g : null
      }
      shape(OO, KO, pO, bK, vK, hO) {
        var DO, MO, aK;
        const oO = null !== (DO = null === (MO = XO.l[vK]) || void 0 === MO ? void 0 : MO.name) && void 0 !== DO ? DO : "",
          FO = hO || oO !== eO.g ? null !== (aK = (0, lO.G)(oO)) && void 0 !== aK ? aK : "water" : function(OO, KO, pO, XO) {
            return LO.some(((bK, eO) => {
              let [vK, hO, DO] = bK;
              const MO = zK(OO(KO + vK, pO + hO, XO + DO), "cryo");
              return null !== MO && "port" !== MO.kind && (0, lO.L)(CO, MO, QO[eO])
            })) ? "cryo" : "water"
          }(OO, KO, pO, bK),
          VO = function(OO, KO, pO, XO) {
            let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "water",
              eO = 0;
            return LO.forEach(((vK, hO) => {
              let [DO, MO, aK] = vK;
              const oO = zK(OO(KO + DO, pO + MO, XO + aK), bK);
              oO && (0, lO.L)(CO, oO, QO[hO]) && (eO |= 1 << hO)
            })), eO
          }(OO, KO, pO, bK, FO),
          AO = hO ? function(OO) {
            var KO;
            return !0 === (null === (KO = TO(OO)) || void 0 === KO ? void 0 : KO.full)
          }(oO) : IO(OO, KO, pO, bK, FO, VO);
        return (0, XO.p)((0, eO.r)(FO, VO, AO))
      }
    }
  },
  35228: OO => {
    OO.exports = function OO(KO, pO) {
      if (KO === pO) return !0;
      if (KO && pO && "object" == typeof KO && "object" == typeof pO) {
        if (KO.constructor !== pO.constructor) return !1;
        var XO, bK, eO;
        if (Array.isArray(KO)) {
          if ((XO = KO.length) != pO.length) return !1;
          for (bK = XO; 0 !== bK--;)
            if (!OO(KO[bK], pO[bK])) return !1;
          return !0
        }
        if (KO.constructor === RegExp) return KO.source === pO.source && KO.flags === pO.flags;
        if (KO.valueOf !== Object.prototype.valueOf) return KO.valueOf() === pO.valueOf();
        if (KO.toString !== Object.prototype.toString) return KO.toString() === pO.toString();
        if ((XO = (eO = Object.keys(KO)).length) !== Object.keys(pO).length) return !1;
        for (bK = XO; 0 !== bK--;)
          if (!Object.prototype.hasOwnProperty.call(pO, eO[bK])) return !1;
        for (bK = XO; 0 !== bK--;) {
          var lO = eO[bK];
          if (!OO(KO[lO], pO[lO])) return !1
        }
        return !0
      }
      return KO !== KO && pO !== pO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);