export const id = 235;
export const ids = [235];
export const modules = {
  38136: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK,
      d: () => MO,
      h: () => CO,
      l: () => oO,
      n: () => hO,
      r: () => vK,
      u: () => DO
    });
    var XO = pO(37061),
      bK = pO(38140);

    function eO(OO, KO, pO, XO) {
      switch (KO) {
        case 5120: {
          let KO = OO.getInt8(pO);
          return XO && (KO = Math.max(KO / 127, -1)), KO
        }
        case 5121: {
          let KO = OO.getUint8(pO);
          return XO && (KO /= 255), KO
        }
        case 5122: {
          let KO = OO.getInt16(pO, !0);
          return XO && (KO = Math.max(KO / 32767, -1)), KO
        }
        case 5123: {
          let KO = OO.getUint16(pO, !0);
          return XO && (KO /= 65535), KO
        }
        case 5131:
          return (0, bK.d)(OO.getUint16(pO, !0));
        case 5124:
          return OO.getInt32(pO, !0);
        case 5125:
          return OO.getUint32(pO, !0);
        case 5126:
          return OO.getFloat32(pO, !0);
        default:
          throw new Error(`Invalid component type ${KO}`)
      }
    }

    function lO(OO, KO, pO, XO, eO) {
      switch (KO) {
        case 5120:
          XO && (eO = Math.round(127 * eO)), OO.setInt8(pO, eO);
          break;
        case 5121:
          XO && (eO = Math.round(255 * eO)), OO.setUint8(pO, eO);
          break;
        case 5122:
          XO && (eO = Math.round(32767 * eO)), OO.setInt16(pO, eO, !0);
          break;
        case 5123:
          XO && (eO = Math.round(65535 * eO)), OO.setUint16(pO, eO, !0);
          break;
        case 5131:
          OO.setUint16(pO, (0, bK.i)(eO), !0);
          break;
        case 5124:
          OO.setInt32(pO, eO, !0);
          break;
        case 5125:
          OO.setUint32(pO, eO, !0);
          break;
        case 5126:
          OO.setFloat32(pO, eO, !0);
          break;
        default:
          throw new Error(`Invalid component type ${KO}`)
      }
    }

    function vK(OO) {
      switch (OO) {
        case 5120:
        case 5121:
          return 1;
        case 5122:
        case 5123:
        case 5131:
          return 2;
        case 5124:
        case 5125:
        case 5126:
          return 4;
        default:
          throw new Error(`Invalid type '${OO}'`)
      }
    }

    function CO(OO, KO, pO, XO, bK, CO, hO, DO) {
      const MO = new Array(XO),
        aK = new Array(XO);
      if (OO instanceof Array) {
        let bK = KO / 4;
        const eO = pO / 4;
        for (let KO = 0; KO < CO; KO += XO) {
          for (let KO = 0; KO < XO; KO++) MO[KO] = aK[KO] = OO[bK + KO];
          DO(aK, KO);
          for (let KO = 0; KO < XO; KO++) MO[KO] !== aK[KO] && (OO[bK + KO] = aK[KO]);
          bK += eO
        }
      } else {
        const oO = ArrayBuffer.isView(OO) ? new DataView(OO.buffer, OO.byteOffset, OO.byteLength) : new DataView(OO),
          FO = vK(bK);
        for (let OO = 0; OO < CO; OO += XO) {
          for (let OO = 0, pO = KO; OO < XO; OO++, pO += FO) MO[OO] = aK[OO] = eO(oO, bK, pO, hO);
          DO(aK, OO);
          for (let OO = 0, pO = KO; OO < XO; OO++, pO += FO) MO[OO] !== aK[OO] && lO(oO, bK, pO, hO, aK[OO]);
          KO += pO
        }
      }
    }

    function hO(OO, KO, pO, bK, eO, lO, hO, DO) {
      const MO = KO * vK(pO),
        aK = hO * KO;
      if (5126 !== pO || eO !== MO) {
        const XO = new Float32Array(aK);
        return CO(OO, bK, eO, KO, pO, aK, lO, ((OO, pO) => {
          for (let bK = 0; bK < KO; bK++) XO[pO + bK] = OO[bK]
        })), XO
      }
      if (!(OO instanceof Array || OO instanceof Float32Array) || 0 !== bK || OO.length !== aK) {
        if (OO instanceof Array) {
          const KO = bK / 4;
          return OO.slice(KO, KO + aK)
        }
        if (ArrayBuffer.isView(OO)) {
          const KO = OO.byteOffset + bK;
          return 0 !== (3 & KO) && (XO.b.Warn("Float array must be aligned to 4-bytes border"), DO = !0), DO ? new Float32Array(OO.buffer.slice(KO, KO + aK * Float32Array.BYTES_PER_ELEMENT)) : new Float32Array(OO.buffer, KO, aK)
        }
        return new Float32Array(OO, bK, aK)
      }
      return DO ? OO.slice() : OO
    }

    function DO(OO, KO, pO, bK, eO, lO, hO) {
      const DO = vK(pO),
        MO = function(OO) {
          switch (OO) {
            case 5120:
              return Int8Array;
            case 5121:
              return Uint8Array;
            case 5122:
              return Int16Array;
            case 5123:
            case 5131:
              return Uint16Array;
            case 5124:
              return Int32Array;
            case 5125:
              return Uint32Array;
            case 5126:
              return Float32Array;
            default:
              throw new Error(`Invalid component type '${OO}'`)
          }
        }(pO),
        aK = lO * KO;
      if (Array.isArray(OO)) {
        if (0 !== (3 & bK) || 0 !== (3 & eO)) throw new Error("byteOffset and byteStride must be a multiple of 4 for number[] data.");
        const XO = bK / 4,
          vK = eO / 4;
        if (XO + (lO - 1) * vK + KO > OO.length) throw new Error("Last accessed index is out of bounds.");
        if (vK < KO) throw new Error("Data stride cannot be smaller than the component size.");
        if (vK !== KO) {
          const XO = new MO(aK);
          return CO(OO, bK, eO, KO, pO, aK, !1, ((OO, pO) => {
            for (let bK = 0; bK < KO; bK++) XO[pO + bK] = OO[bK]
          })), XO
        }
        return new MO(OO.slice(XO, XO + aK))
      }
      let oO, FO = bK;
      ArrayBuffer.isView(OO) ? (oO = OO.buffer, FO += OO.byteOffset) : oO = OO;
      if (FO + (lO - 1) * eO + KO * DO > oO.byteLength) throw new Error("Last accessed byte is out of bounds.");
      const VO = KO * DO;
      if (eO < VO) throw new Error("Byte stride cannot be smaller than the component's byte size.");
      if (eO !== VO) {
        const OO = new MO(aK),
          pO = new Uint8Array(oO, FO),
          XO = new Uint8Array(OO.buffer),
          bK = KO * DO;
        for (let KO = 0, vK = 0, CO = 0; KO < lO; KO++, vK += eO, CO += bK) XO.set(pO.subarray(vK, vK + bK), CO);
        return OO
      }
      return 1 !== DO && 0 !== (FO & DO - 1) && (XO.b.Warn("Array must be aligned to border of element size. Data will be copied."), hO = !0), hO ? new MO(oO.slice(FO, FO + aK * DO)) : new MO(oO, FO, aK)
    }

    function MO(OO, KO, pO, bK, eO, lO, hO, DO) {
      const MO = KO * vK(pO),
        aK = hO * KO;
      if (DO.length !== aK) throw new Error("Output length is not valid");
      if (5126 === pO && eO === MO)
        if (OO instanceof Array) {
          const KO = bK / 4;
          DO.set(OO, KO)
        } else if (ArrayBuffer.isView(OO)) {
        const KO = OO.byteOffset + bK;
        if (0 !== (3 & KO)) return XO.b.Warn("Float array must be aligned to 4-bytes border"), void DO.set(new Float32Array(OO.buffer.slice(KO, KO + aK * Float32Array.BYTES_PER_ELEMENT)));
        const pO = new Float32Array(OO.buffer, KO, aK);
        DO.set(pO)
      } else {
        const KO = new Float32Array(OO, bK, aK);
        DO.set(KO)
      } else CO(OO, bK, eO, KO, pO, aK, lO, ((OO, pO) => {
        for (let XO = 0; XO < KO; XO++) DO[pO + XO] = OO[XO]
      }))
    }

    function aK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
        XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
      if (Array.isArray(OO)) {
        for (let bK = 0; bK < KO; bK++)
          if (OO[pO + bK] - XO > 65535) return !0;
        return !1
      }
      return 4 === OO.BYTES_PER_ELEMENT
    }

    function oO(OO) {
      const KO = OO.buffer;
      if (KO instanceof ArrayBuffer) return OO;
      const pO = new ArrayBuffer(OO.byteLength);
      return new Uint8Array(pO).set(new Uint8Array(KO, OO.byteOffset, OO.byteLength)), pO
    }
  },
  37947: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => IO,
      f: () => TO,
      h: () => NO,
      g: () => wO,
      k: () => iK
    });
    class XO {
      constructor() {
        this.children = []
      }
      isValid(OO) {
        return !0
      }
      process(OO, KO, pO) {
        let XO = "";
        if (this.line) {
          let pO = this.line;
          const bK = KO.processor;
          if (bK) {
            bK.lineProcessor && (pO = bK.lineProcessor(pO, KO.isFragment, KO.processingContext));
            const XO = KO.processor?.attributeKeywordName ?? "attribute",
              eO = KO.isFragment && KO.processor?.varyingFragmentKeywordName ? KO.processor?.varyingFragmentKeywordName : !KO.isFragment && KO.processor?.varyingVertexKeywordName ? KO.processor?.varyingVertexKeywordName : "varying";
            if (!KO.isFragment && bK.attributeProcessor && this.line.startsWith(XO)) pO = bK.attributeProcessor(this.line, OO, KO.processingContext);
            else if (bK.varyingProcessor && (bK.varyingCheck?.(this.line, KO.isFragment) || !bK.varyingCheck && this.line.startsWith(eO))) pO = bK.varyingProcessor(this.line, KO.isFragment, OO, KO.processingContext);
            else if (bK.uniformProcessor && bK.uniformRegexp && bK.uniformRegexp.test(this.line)) KO.lookForClosingBracketForUniformBuffer || (pO = bK.uniformProcessor(this.line, KO.isFragment, OO, KO.processingContext));
            else if (bK.uniformBufferProcessor && bK.uniformBufferRegexp && bK.uniformBufferRegexp.test(this.line)) KO.lookForClosingBracketForUniformBuffer || (pO = bK.uniformBufferProcessor(this.line, KO.isFragment, KO.processingContext), KO.lookForClosingBracketForUniformBuffer = !0);
            else if (bK.textureProcessor && bK.textureRegexp && bK.textureRegexp.test(this.line)) pO = bK.textureProcessor(this.line, KO.isFragment, OO, KO.processingContext);
            else if ((bK.uniformProcessor || bK.uniformBufferProcessor) && this.line.startsWith("uniform") && !KO.lookForClosingBracketForUniformBuffer) {
              /uniform\s+(?:(?:highp)?|(?:lowp)?)\s*(\S+)\s+(\S+)\s*;/.test(this.line) ? bK.uniformProcessor && (pO = bK.uniformProcessor(this.line, KO.isFragment, OO, KO.processingContext)) : bK.uniformBufferProcessor && (pO = bK.uniformBufferProcessor(this.line, KO.isFragment, KO.processingContext), KO.lookForClosingBracketForUniformBuffer = !0)
            }
            KO.lookForClosingBracketForUniformBuffer && -1 !== this.line.indexOf("}") && (KO.lookForClosingBracketForUniformBuffer = !1, bK.endOfUniformBufferProcessor && (pO = bK.endOfUniformBufferProcessor(this.line, KO.isFragment, KO.processingContext)))
          }
          XO += pO + "\n"
        }
        for (const bK of this.children) XO += bK.process(OO, KO, pO);
        return this.additionalDefineKey && (OO[this.additionalDefineKey] = this.additionalDefineValue || "true", pO[this.additionalDefineKey] = OO[this.additionalDefineKey]), XO
      }
    }
    class bK {
      constructor() {
        this._lines = []
      }
      get currentLine() {
        return this._lines[this.lineIndex]
      }
      get canRead() {
        return this.lineIndex < this._lines.length - 1
      }
      set lines(OO) {
        this._lines.length = 0;
        for (const KO of OO) {
          if (!KO || "\r" === KO) continue;
          if ("#" === KO[0]) {
            this._lines.push(KO);
            continue
          }
          const OO = KO.trim();
          if (!OO) continue;
          if (OO.startsWith("//")) {
            this._lines.push(KO);
            continue
          }
          const pO = OO.indexOf(";");
          if (-1 === pO) this._lines.push(OO);
          else if (pO === OO.length - 1) OO.length > 1 && this._lines.push(OO);
          else {
            const OO = KO.split(";");
            for (let KO = 0; KO < OO.length; KO++) {
              let pO = OO[KO];
              pO && (pO = pO.trim(), pO && this._lines.push(pO + (KO !== OO.length - 1 ? ";" : "")))
            }
          }
        }
      }
    }
    class eO extends XO {
      process(OO, KO, pO) {
        for (let XO = 0; XO < this.children.length; XO++) {
          const bK = this.children[XO];
          if (bK.isValid(OO)) return bK.process(OO, KO, pO)
        }
        return ""
      }
    }
    class lO extends XO {
      isValid(OO) {
        return this.testExpression.isTrue(OO)
      }
    }
    class vK {
      isTrue(OO) {
        return !0
      }
      static postfixToInfix(OO) {
        const KO = [];
        for (const pO of OO)
          if (void 0 === vK._OperatorPriority[pO]) KO.push(pO);
          else {
            const OO = KO[KO.length - 1],
              XO = KO[KO.length - 2];
            KO.length -= 2, KO.push(`(${XO}${pO}${OO})`)
          } return KO[KO.length - 1]
      }
      static infixToPostfix(OO) {
        const KO = vK._InfixToPostfixCache.get(OO);
        if (KO) return KO.accessTime = Date.now(), KO.result;
        if (!OO.includes("&&") && !OO.includes("||") && !OO.includes(")") && !OO.includes("(")) return [OO];
        const pO = [];
        let XO = -1;
        const bK = () => {
            DO = DO.trim(), "" !== DO && (pO.push(DO), DO = "")
          },
          eO = OO => {
            XO < vK._Stack.length - 1 && (vK._Stack[++XO] = OO)
          },
          lO = () => vK._Stack[XO],
          CO = () => -1 === XO ? "!!INVALID EXPRESSION!!" : vK._Stack[XO--];
        let hO = 0,
          DO = "";
        for (; hO < OO.length;) {
          const KO = OO.charAt(hO),
            MO = hO < OO.length - 1 ? OO.substring(hO, 2 + hO) : "";
          if ("(" === KO) DO = "", eO(KO);
          else if (")" === KO) {
            for (bK(); - 1 !== XO && "(" !== lO();) pO.push(CO());
            CO()
          } else if (vK._OperatorPriority[MO] > 1) {
            for (bK(); - 1 !== XO && vK._OperatorPriority[lO()] >= vK._OperatorPriority[MO];) pO.push(CO());
            eO(MO), hO++
          } else DO += KO;
          hO++
        }
        for (bK(); - 1 !== XO;) "(" === lO() ? CO() : pO.push(CO());
        return vK._InfixToPostfixCache.size >= vK.InfixToPostfixCacheLimitSize && vK.ClearCache(), vK._InfixToPostfixCache.set(OO, {
          result: pO,
          accessTime: Date.now()
        }), pO
      }
      static ClearCache() {
        const OO = Array.from(vK._InfixToPostfixCache.entries()).sort(((OO, KO) => OO[1].accessTime - KO[1].accessTime));
        for (let KO = 0; KO < vK.InfixToPostfixCacheCleanupSize; KO++) vK._InfixToPostfixCache.delete(OO[KO][0])
      }
    }
    vK.InfixToPostfixCacheLimitSize = 5e4, vK.InfixToPostfixCacheCleanupSize = 25e3, vK._InfixToPostfixCache = new Map, vK._OperatorPriority = {
      ")": 0,
      "(": 1,
      "||": 2,
      "&&": 3
    }, vK._Stack = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
    class CO extends vK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        super(), this.define = OO, this.not = KO
      }
      isTrue(OO) {
        let KO = void 0 !== OO[this.define];
        return this.not && (KO = !KO), KO
      }
    }
    class hO extends vK {
      isTrue(OO) {
        return this.leftOperand.isTrue(OO) || this.rightOperand.isTrue(OO)
      }
    }
    class DO extends vK {
      isTrue(OO) {
        return this.leftOperand.isTrue(OO) && this.rightOperand.isTrue(OO)
      }
    }
    class MO extends vK {
      constructor(OO, KO, pO) {
        super(), this.define = OO, this.operand = KO, this.testValue = pO
      }
      toString() {
        return `${this.define} ${this.operand} ${this.testValue}`
      }
      isTrue(OO) {
        let KO = !1;
        const pO = parseInt(void 0 != OO[this.define] ? OO[this.define] : this.define),
          XO = parseInt(void 0 != OO[this.testValue] ? OO[this.testValue] : this.testValue);
        if (isNaN(pO) || isNaN(XO)) return !1;
        switch (this.operand) {
          case ">":
            KO = pO > XO;
            break;
          case "<":
            KO = pO < XO;
            break;
          case "<=":
            KO = pO <= XO;
            break;
          case ">=":
            KO = pO >= XO;
            break;
          case "==":
            KO = pO === XO;
            break;
          case "!=":
            KO = pO !== XO
        }
        return KO
      }
    }
    var aK = pO(37938),
      oO = pO(37930);
    const FO = /defined\s*?\((.+?)\)/g,
      VO = /defined\s*?\[(.+?)\]/g,
      LO = /#include\s?<(.+)>(\((.*)\))*(\[(.*)\])*/g,
      QO = /__decl__/,
      zK = /light\{X\}.(\w*)/g,
      AO = /\{X\}/g,
      fO = [],
      dO = /(#ifdef)|(#else)|(#elif)|(#endif)|(#ifndef)|(#if)/;

    function TO(OO) {
      OO.processor && OO.processor.initializeShaders && OO.processor.initializeShaders(OO.processingContext)
    }

    function NO(OO, KO, pO, XO) {
      KO.processor?.preProcessShaderCode && (OO = KO.processor.preProcessShaderCode(OO, KO.isFragment)), wO(OO, KO, (OO => {
        KO.processCodeAfterIncludes && (OO = KO.processCodeAfterIncludes(KO.isFragment ? "fragment" : "vertex", OO, KO.defines));
        const bK = function(OO, KO, pO) {
          let XO = function(OO, KO) {
            if (KO.processor?.noPrecision) return OO;
            const pO = KO.shouldUseHighPrecisionShader; - 1 === OO.indexOf("precision highp float") ? OO = pO ? "precision highp float;\n" + OO : "precision mediump float;\n" + OO : pO || (OO = OO.replace("precision highp float", "precision mediump float"));
            return OO
          }(OO, KO);
          if (!KO.processor) return XO;
          if (0 === KO.processor.shaderLanguage && -1 !== XO.indexOf("#version 3") && (XO = XO.replace("#version 300 es", ""), !KO.processor.parseGLES3)) return XO;
          const bK = KO.defines,
            eO = YO(KO, pO);
          KO.processor.preProcessor && (XO = KO.processor.preProcessor(XO, bK, eO, KO.isFragment, KO.processingContext));
          const lO = {};
          XO = jK(XO, eO, KO, lO), KO.processor.postProcessor && (XO = KO.processor.postProcessor(XO, bK, KO.isFragment, KO.processingContext, pO ? {
            drawBuffersExtensionDisabled: !pO.getCaps().drawBuffersExtension
          } : {}, eO, lO));
          pO?._features.needShaderCodeInlining && (XO = pO.inlineShaderCode(XO));
          return XO
        }(OO, KO, XO);
        pO(bK, OO)
      }))
    }

    function IO(OO, KO, pO) {
      return pO.processor && pO.processor.finalizeShaders ? pO.processor.finalizeShaders(OO, KO, pO.processingContext) : {
        vertexCode: OO,
        fragmentCode: KO
      }
    }

    function yK(OO) {
      const KO = /defined\((.+)\)/.exec(OO);
      if (KO && KO.length) return new CO(KO[1].trim(), "!" === OO[0]);
      const pO = ["==", "!=", ">=", "<=", "<", ">"];
      let XO = "",
        bK = 0;
      for (XO of pO)
        if (bK = OO.indexOf(XO), bK > -1) break;
      if (-1 === bK) return new CO(OO);
      const eO = OO.substring(0, bK).trim(),
        lO = OO.substring(bK + XO.length).trim();
      return new MO(eO, XO, lO)
    }

    function gK(OO, KO) {
      const pO = new lO,
        XO = OO.substring(0, KO);
      let bK = OO.substring(KO);
      return bK = bK.substring(0, (bK.indexOf("//") + 1 || bK.length + 1) - 1).trim(), pO.testExpression = "#ifdef" === XO ? new CO(bK) : "#ifndef" === XO ? new CO(bK, !0) : function(OO) {
        OO = OO.replace(FO, "defined[$1]");
        const KO = vK.infixToPostfix(OO),
          pO = [];
        for (const bK of KO)
          if ("||" !== bK && "&&" !== bK) pO.push(bK);
          else if (pO.length >= 2) {
          let OO = pO[pO.length - 1],
            KO = pO[pO.length - 2];
          pO.length -= 2;
          const XO = "&&" == bK ? new DO : new hO;
          "string" === typeof OO && (OO = OO.replace(VO, "defined($1)")), "string" === typeof KO && (KO = KO.replace(VO, "defined($1)")), XO.leftOperand = "string" === typeof KO ? yK(KO) : KO, XO.rightOperand = "string" === typeof OO ? yK(OO) : OO, pO.push(XO)
        }
        let XO = pO[pO.length - 1];
        return "string" === typeof XO && (XO = XO.replace(VO, "defined($1)")), "string" === typeof XO ? yK(XO) : XO
      }(bK), pO
    }

    function uO(OO, KO, pO, bK) {
      let eO;
      for (; EO(OO, pO, bK);) {
        eO = OO.currentLine;
        const lO = eO.substring(0, 5).toLowerCase();
        if ("#else" === lO) {
          const pO = new XO;
          return KO.children.push(pO), void EO(OO, pO, bK)
        }
        if ("#elif" === lO) {
          const OO = gK(eO, 5);
          KO.children.push(OO), pO = OO
        }
      }
    }

    function EO(OO, KO, pO) {
      for (; OO.canRead;) {
        OO.lineIndex++;
        const bK = OO.currentLine;
        if (bK.indexOf("#") >= 0) {
          const XO = dO.exec(bK);
          if (XO && XO.length) {
            switch (XO[0]) {
              case "#ifdef": {
                const XO = new eO;
                KO.children.push(XO);
                const lO = gK(bK, 6);
                XO.children.push(lO), uO(OO, XO, lO, pO);
                break
              }
              case "#else":
              case "#elif":
                return !0;
              case "#endif":
                return !1;
              case "#ifndef": {
                const XO = new eO;
                KO.children.push(XO);
                const lO = gK(bK, 7);
                XO.children.push(lO), uO(OO, XO, lO, pO);
                break
              }
              case "#if": {
                const XO = new eO,
                  lO = gK(bK, 3);
                KO.children.push(XO), XO.children.push(lO), uO(OO, XO, lO, pO);
                break
              }
            }
            continue
          }
        }
        const lO = new XO;
        if (lO.line = bK, KO.children.push(lO), "#" === bK[0] && "d" === bK[1]) {
          const OO = bK.replace(";", "").split(" ");
          lO.additionalDefineKey = OO[1], 3 === OO.length && (lO.additionalDefineValue = OO[2])
        }
      }
      return !1
    }

    function jK(OO, KO, pO, eO) {
      const lO = new XO,
        vK = new bK;
      return vK.lineIndex = -1, vK.lines = OO.split("\n"), EO(vK, lO, eO), lO.process(KO, pO, eO)
    }

    function YO(OO, KO) {
      const pO = OO.defines,
        XO = {};
      for (const bK of pO) {
        const OO = bK.replace("#define", "").replace(";", "").trim().split(" ");
        XO[OO[0]] = OO.length > 1 ? OO[1] : ""
      }
      return 0 === OO.processor?.shaderLanguage && (XO.GL_ES = "true"), XO.__VERSION__ = OO.version, XO[OO.platformName] = "true", (0, oO.j)(XO, KO?.isNDCHalfZRange, KO?.BhO, KO?.useExactSrgbConversions), XO
    }

    function wO(OO, KO, pO) {
      let XO;
      for (fO.length = 0; null !== (XO = LO.exec(OO));) fO.push(XO);
      let bK = [OO],
        eO = !1;
      for (const vK of fO) {
        let OO = vK[1];
        if (-1 !== OO.indexOf("__decl__") && (OO = OO.replace(QO, ""), KO.supportsUniformBuffers && (OO = OO.replace("Vertex", "Ubo").replace("Fragment", "Ubo")), OO += "Declaration"), !KO.includesShadersStore[OO]) {
          const XO = KO.shadersRepository + "ShadersInclude/" + OO + ".fx";
          return void iK.loadFile(XO, (XO => {
            KO.includesShadersStore[OO] = XO, wO(bK.join(""), KO, pO)
          }))
        } {
          let pO = KO.includesShadersStore[OO];
          if (vK[2]) {
            const OO = vK[3].split(",");
            for (let KO = 0; KO < OO.length; KO += 2) {
              const XO = new RegExp(OO[KO], "g"),
                bK = OO[KO + 1];
              pO = pO.replace(XO, bK)
            }
          }
          if (vK[4]) {
            const OO = vK[5];
            if (-1 !== OO.indexOf("..")) {
              const XO = OO.split(".."),
                bK = parseInt(XO[0]);
              let eO = parseInt(XO[1]),
                lO = pO.slice(0);
              pO = "", isNaN(eO) && (eO = KO.indexParameters[XO[1]]);
              for (let OO = bK; OO < eO; OO++) KO.supportsUniformBuffers || (lO = lO.replace(zK, ((OO, KO) => KO + "{X}"))), pO += lO.replace(AO, OO.toString()) + "\n"
            } else KO.supportsUniformBuffers || (pO = pO.replace(zK, ((OO, KO) => KO + "{X}"))), pO = pO.replace(AO, OO)
          }
          const XO = [];
          for (const OO of bK) {
            const KO = OO.split(vK[0]);
            for (let OO = 0; OO < KO.length - 1; OO++) XO.push(KO[OO]), XO.push(pO);
            XO.push(KO[KO.length - 1])
          }
          bK = XO, eO = eO || pO.indexOf("#include<") >= 0 || pO.indexOf("#include <") >= 0
        }
      }
      fO.length = 0;
      const lO = bK.join("");
      eO ? wO(lO.toString(), KO, pO) : pO(lO)
    }
    const iK = {
      loadFile: (OO, KO, pO, XO, bK, eO) => {
        throw (0, aK.j)("FileTools")
      }
    }
  },
  37930: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      i: () => eO,
      j: () => vK,
      l: () => lO,
      n: () => CO
    });
    var XO = pO(37938);
    const bK = {};

    function eO(OO, KO) {
      return (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "") + (KO ? KO + "\n" : "") + OO
    }

    function lO(OO, KO, pO, eO, lO, vK, CO) {
      const hO = CO || bK.loadFile;
      if (!hO) throw (0, XO.j)("FileTools");
      return hO(OO, KO, pO, eO, lO, vK)
    }

    function vK(OO, KO, pO, XO) {
      if (OO) return KO ? OO.IS_NDC_HALF_ZRANGE = "" : delete OO.IS_NDC_HALF_ZRANGE, pO ? OO.USE_REVERSE_DEPTHBUFFER = "" : delete OO.USE_REVERSE_DEPTHBUFFER, void(XO ? OO.USE_EXACT_SRGB_CONVERSIONS = "" : delete OO.USE_EXACT_SRGB_CONVERSIONS);
      {
        let OO = "";
        return KO && (OO += "#define IS_NDC_HALF_ZRANGE"), pO && (OO && (OO += "\n"), OO += "#define USE_REVERSE_DEPTHBUFFER"), XO && (OO && (OO += "\n"), OO += "#define USE_EXACT_SRGB_CONVERSIONS"), OO
      }
    }

    function CO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        XO = arguments.length > 3 ? arguments[3] : void 0;
      switch (OO) {
        case 3: {
          const OO = new Int8Array(KO);
          return XO && OO.set(new Int8Array(XO)), OO
        }
        case 0: {
          const OO = new Uint8Array(KO);
          return XO && OO.set(new Uint8Array(XO)), OO
        }
        case 4: {
          const OO = "number" !== typeof KO ? new Int16Array(KO) : new Int16Array(pO ? KO / 2 : KO);
          return XO && OO.set(new Int16Array(XO)), OO
        }
        case 5:
        case 8:
        case 9:
        case 10:
        case 2: {
          const OO = "number" !== typeof KO ? new Uint16Array(KO) : new Uint16Array(pO ? KO / 2 : KO);
          return XO && OO.set(new Uint16Array(XO)), OO
        }
        case 6: {
          const OO = "number" !== typeof KO ? new Int32Array(KO) : new Int32Array(pO ? KO / 4 : KO);
          return XO && OO.set(new Int32Array(XO)), OO
        }
        case 7:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15: {
          const OO = "number" !== typeof KO ? new Uint32Array(KO) : new Uint32Array(pO ? KO / 4 : KO);
          return XO && OO.set(new Uint32Array(XO)), OO
        }
        case 1: {
          const OO = "number" !== typeof KO ? new Float32Array(KO) : new Float32Array(pO ? KO / 4 : KO);
          return XO && OO.set(new Float32Array(XO)), OO
        }
      }
      const bK = new Uint8Array(KO);
      return XO && bK.set(new Uint8Array(XO)), bK
    }
  },
  37938: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      e: () => DO,
      h: () => CO,
      j: () => bK
    });
    const XO = {};

    function bK(OO) {
      if (!(arguments.length > 1 && void 0 !== arguments[1] && arguments[1]) || !XO[OO]) return XO[OO] = !0, `${OO} needs to be imported before as it contains a side-effect required by your code.`
    }
    const eO = {};
    let lO = !1,
      vK = 0;

    function CO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      const XO = function() {
        if ((pO || lO) && 0 === vK) {
          const pO = `${OO}.${KO}`;
          eO[pO] || (eO[pO] = !0, console.warn(`[Babylon.js] ${pO}() requires a side-effect import. See: https://doc.babylonjs.com/setup/treeshaking`))
        }
      };
      return XO.__isSideEffectStub = !0, XO
    }

    function hO(OO) {
      return !!OO && !OO.__isSideEffectStub
    }

    function DO(OO, KO) {
      return {
        get() {},
        set(OO) {
          Object.defineProperty(this, KO, {
            value: OO,
            writable: !0,
            configurable: !0,
            enumerable: !0
          })
        },
        configurable: !0,
        enumerable: !0
      }
    }
  },
  37918: (OO, KO, pO) => {
    function XO() {
      return "undefined" !== typeof window
    }

    function bK() {
      return "undefined" !== typeof navigator
    }

    function eO() {
      return "undefined" !== typeof document
    }

    function lO(OO) {
      let KO = "",
        pO = OO.firstChild;
      for (; pO;) 3 === pO.nodeType && (KO += pO.textContent), pO = pO.nextSibling;
      return KO
    }
    pO.d(KO, {
      e: () => lO,
      g: () => eO,
      k: () => bK,
      n: () => XO
    })
  },
  38120: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO,
      d: () => bK,
      g: () => eO
    });
    class XO extends Error {}
    XO._setPrototypeOf = Object.setPrototypeOf || ((OO, KO) => (OO.__proto__ = KO, OO));
    const bK = {
      MeshInvalidPositionsError: 0,
      UnsupportedTextureError: 1e3,
      GLTFLoaderUnexpectedMagicError: 2e3,
      SceneLoaderError: 3e3,
      LoadFileError: 4e3,
      RequestFileError: 4001,
      ReadFileError: 4002
    };
    class eO extends XO {
      constructor(OO, KO, pO) {
        super(OO), this.errorCode = KO, this.innerError = pO, this.name = "RuntimeError", XO._setPrototypeOf(this, eO.prototype)
      }
    }
  },
  38104: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => YO,
      f: () => AO,
      i: () => gK,
      m: () => EO,
      o: () => IO,
      s: () => TO,
      u: () => NO,
      v: () => mK,
      z: () => yK,
      B: () => fO
    });
    var XO = pO(38112),
      bK = pO(37918),
      eO = pO(35660);
    class lO {}
    lO.FilesToLoad = {};
    var vK = pO(38120),
      CO = pO(38129),
      hO = pO(35653),
      DO = pO(37930),
      MO = pO(37947),
      aK = pO(37061),
      oO = pO(37955),
      FO = pO(38136);
    const VO = new RegExp(/^data:([^,]+\/[^,]+)?;base64,/i);
    class LO extends vK.g {
      constructor(OO, KO) {
        super(OO, vK.d.LoadFileError), this.name = "LoadFileError", vK.c._setPrototypeOf(this, LO.prototype), KO instanceof XO.b ? this.request = KO : this.file = KO
      }
    }
    class QO extends vK.g {
      constructor(OO, KO) {
        super(OO, vK.d.RequestFileError), this.request = KO, this.name = "RequestFileError", vK.c._setPrototypeOf(this, QO.prototype)
      }
    }
    class zK extends vK.g {
      constructor(OO, KO) {
        super(OO, vK.d.ReadFileError), this.file = KO, this.name = "ReadFileError", vK.c._setPrototypeOf(this, zK.prototype)
      }
    }
    const AO = {
        DefaultRetryStrategy: class {
          static ExponentialBackoff() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 3,
              KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 500;
            return (pO, XO, bK) => 0 !== XO.status || bK >= OO || -1 !== pO.indexOf("file:") ? -1 : Math.pow(2, bK) * KO
          }
        }.ExponentialBackoff(),
        BaseUrl: "",
        CorsBehavior: "anonymous",
        PreprocessUrl: OO => OO,
        ScriptBaseUrl: "",
        ScriptPreprocessUrl: OO => OO,
        CleanUrl: OO => OO = OO.replace(/#/gm, "%23")
      },
      fO = (OO, KO) => {
        if ((!OO || 0 !== OO.indexOf("data:")) && AO.CorsBehavior)
          if ("string" === typeof AO.CorsBehavior || AO.CorsBehavior instanceof String) KO.crossOrigin = AO.CorsBehavior;
          else {
            const pO = AO.CorsBehavior(OO);
            pO && (KO.crossOrigin = pO)
          }
      },
      dO = {
        getRequiredSize: null
      },
      TO = function(OO, KO, pO, bK) {
        let eO, vK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "",
          DO = arguments.length > 5 ? arguments[5] : void 0,
          MO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : hO.c.LastCreatedEngine;
        if ("undefined" === typeof HTMLImageElement && !MO?._features.forceBitmapOverHTMLImageElement) return pO("LoadImage is only supported in web or BabylonNative environments."), null;
        if (MO?._features.forceBitmapOverHTMLImageElement && "string" !== typeof OO && "undefined" !== typeof Blob) {
          let XO;
          if (OO instanceof Blob) XO = OO;
          else {
            const KO = OO instanceof ArrayBuffer ? OO : (0, FO.l)(OO);
            XO = new Blob([KO], {
              type: vK
            })
          }
          return MO.createImageBitmap(XO, {
            premultiplyAlpha: "none",
            colorSpaceConversion: "none",
            ...DO
          }).then(KO).catch((KO => {
            pO && pO("Error while trying to load image: " + OO, KO)
          })), null
        }
        let aK = !1;
        if (OO instanceof ArrayBuffer || ArrayBuffer.isView(OO))
          if ("undefined" !== typeof Blob && "undefined" !== typeof URL) {
            let KO;
            KO = OO instanceof ArrayBuffer ? OO : (0, FO.l)(OO), eO = URL.createObjectURL(new Blob([KO], {
              type: vK
            })), aK = !0
          } else eO = `data:${vK};base64,` + (0, CO.k)(OO);
        else OO instanceof Blob ? (eO = URL.createObjectURL(OO), aK = !0) : (eO = AO.CleanUrl(OO), eO = AO.PreprocessUrl(eO));
        const oO = KO => {
          if (pO) {
            const XO = eO || OO.toString();
            pO(`Error while trying to load image: ${0===XO.indexOf("http")||XO.length<=128?XO:XO.slice(0,128)+"..."}`, KO)
          }
        };
        if (MO?._features.forceBitmapOverHTMLImageElement) return IO(eO, (XO => {
          MO.createImageBitmap(new Blob([XO], {
            type: vK
          }), {
            premultiplyAlpha: "none",
            colorSpaceConversion: "none",
            ...DO
          }).then((OO => {
            KO(OO), aK && URL.revokeObjectURL(eO)
          })).catch((KO => {
            pO && pO("Error while trying to load image: " + OO, KO)
          }))
        }), void 0, bK || void 0, !0, ((OO, KO) => {
          oO(KO)
        })), null;
        const VO = new Image;
        if (dO.getRequiredSize) {
          const KO = dO.getRequiredSize(OO);
          KO.width && (VO.width = KO.width), KO.height && (VO.height = KO.height)
        }
        fO(eO, VO);
        const LO = [],
          QO = () => {
            for (const OO of LO) OO.target.removeEventListener(OO.name, OO.handler);
            LO.length = 0
          };
        LO.push({
          target: VO,
          name: "load",
          handler: () => {
            QO(), KO(VO), aK && VO.src && URL.revokeObjectURL(VO.src)
          }
        }), LO.push({
          target: VO,
          name: "error",
          handler: OO => {
            QO(), oO(OO), aK && VO.src && URL.revokeObjectURL(VO.src)
          }
        }), LO.push({
          target: document,
          name: "securitypolicyviolation",
          handler: OO => {
            if (OO.blockedURI !== VO.src || "CX" === OO.disposition) return;
            QO();
            const KO = new Error(`CSP violation of policy ${OO.effectiveDirective} ${OO.blockedURI}. Current policy is ${OO.originalPolicy}`);
            hO.c.UseFallbackTexture = !1, oO(KO), aK && VO.src && URL.revokeObjectURL(VO.src), VO.src = ""
          }
        }), (() => {
          for (const OO of LO) OO.target.addEventListener(OO.name, OO.handler)
        })();
        const zK = "blob:" === eO.substring(0, 5),
          TO = "data:" === eO.substring(0, 5),
          NO = () => {
            zK || TO || !XO.b.IsCustomRequestAvailable ? VO.src = eO : IO(eO, ((OO, KO, pO) => {
              const XO = new Blob([OO], {
                  type: !vK && pO ? pO : vK
                }),
                bK = URL.createObjectURL(XO);
              aK = !0, VO.src = bK
            }), void 0, bK || void 0, !0, ((OO, KO) => {
              oO(KO)
            }))
          },
          yK = () => {
            bK && bK.loadImage(eO, VO)
          };
        if (!zK && !TO && bK && bK.enableTexturesOffline) bK.open(yK, NO);
        else {
          if (-1 !== eO.indexOf("file:")) {
            const OO = decodeURIComponent(eO.substring(5).toLowerCase());
            if (lO.FilesToLoad[OO] && "undefined" !== typeof URL) {
              try {
                let KO;
                try {
                  KO = URL.createObjectURL(lO.FilesToLoad[OO])
                } catch (gK) {
                  KO = URL.createObjectURL(lO.FilesToLoad[OO])
                }
                VO.src = KO, aK = !0
              } catch (uO) {
                VO.src = ""
              }
              return VO
            }
          }
          NO()
        }
        return VO
      },
      NO = (OO, KO, pO, XO, bK) => {
        const lO = new FileReader,
          vK = {
            onCompleteObservable: new eO.e,
            abort: () => lO.abort()
          };
        return lO.onloadend = () => vK.onCompleteObservable.notifyObservers(vK), bK && (lO.onerror = () => {
          bK(new zK(`Unable to read ${OO.name}`, OO))
        }), lO.onload = OO => {
          KO(OO.target.result)
        }, pO && (lO.onprogress = pO), XO ? lO.readAsArrayBuffer(OO) : lO.readAsText(OO), vK
      },
      IO = (OO, KO, pO, XO, bK, CO, hO) => {
        if (OO.name) return NO(OO, KO, pO, bK, CO ? OO => {
          CO(void 0, OO)
        } : void 0);
        const DO = OO;
        if (-1 !== DO.indexOf("file:")) {
          let OO = decodeURIComponent(DO.substring(5).toLowerCase());
          0 === OO.indexOf("./") && (OO = OO.substring(2));
          const XO = lO.FilesToLoad[OO];
          if (XO) return NO(XO, KO, pO, bK, CO ? OO => CO(void 0, new LO(OO.message, OO.file)) : void 0)
        }
        const {
          match: MO,
          type: FO
        } = jK(DO);
        if (MO) {
          const OO = {
            onCompleteObservable: new eO.e,
            abort: () => () => {}
          };
          try {
            const OO = bK ? YO(DO) : wO(DO);
            KO(OO, void 0, FO)
          } catch (vK) {
            CO ? CO(void 0, vK) : aK.b.Error(vK.message || "Failed to parse the Data URL")
          }
          return oO.c.SetImmediate((() => {
            OO.onCompleteObservable.notifyObservers(OO)
          })), OO
        }
        return yK(DO, ((OO, pO) => {
          KO(OO, pO?.responseURL, pO?.getResponseHeader("content-type"))
        }), pO, XO, bK, CO ? OO => {
          CO(OO.request, new LO(OO.message, OO.request))
        } : void 0, hO)
      },
      yK = (OO, KO, pO, lO, vK, CO, DO) => {
        null !== lO && (lO ?? (lO = hO.c.LastCreatedScene?.offlineProvider)), OO = AO.CleanUrl(OO), OO = AO.PreprocessUrl(OO);
        const MO = AO.BaseUrl + OO;
        let oO = !1;
        const FO = {
            onCompleteObservable: new eO.e,
            abort: () => oO = !0
          },
          VO = () => {
            let OO, eO = new XO.b,
              lO = null;
            const hO = () => {
              eO && (pO && eO.removeEventListener("progress", pO), OO && eO.removeEventListener("readystatechange", OO), eO.removeEventListener("loadend", VO))
            };
            let VO = () => {
              hO(), FO.onCompleteObservable.notifyObservers(FO), FO.onCompleteObservable.clear(), pO = void 0, OO = null, VO = null, CO = void 0, DO = void 0, KO = void 0
            };
            FO.abort = () => {
              oO = !0, VO && VO(), eO && eO.readyState !== (XMLHttpRequest.DONE || 4) && eO.abort(), null !== lO && (clearTimeout(lO), lO = null), eO = null
            };
            const LO = OO => {
                const KO = OO.message || "Unknown error";
                CO && eO ? CO(new QO(KO, eO)) : aK.b.Error(KO)
              },
              zK = aK => {
                if (eO) {
                  if (eO.open("GET", MO), DO) try {
                    DO(eO)
                  } catch (FO) {
                    return void LO(FO)
                  }
                  vK && (eO.responseType = "arraybuffer"), pO && eO.addEventListener("progress", pO), VO && eO.addEventListener("loadend", VO), OO = () => {
                    if (!oO && eO && eO.readyState === (XMLHttpRequest.DONE || 4)) {
                      if (OO && eO.removeEventListener("readystatechange", OO), eO.status >= 200 && eO.status < 300 || 0 === eO.status && (!(0, bK.n)() || uO())) {
                        const OO = vK ? eO.response : eO.responseText;
                        if (null !== OO) {
                          try {
                            KO && KO(OO, eO)
                          } catch (FO) {
                            LO(FO)
                          }
                          return
                        }
                      }
                      const pO = AO.DefaultRetryStrategy;
                      if (pO) {
                        const OO = pO(MO, eO, aK);
                        if (-1 !== OO) return hO(), eO = new XO.b, void(lO = setTimeout((() => zK(aK + 1)), OO))
                      }
                      const DO = new QO("Error status: " + eO.status + " " + eO.statusText + " - Unable to load " + MO, eO);
                      CO && CO(DO)
                    }
                  }, eO.addEventListener("readystatechange", OO), eO.send()
                }
              };
            zK(0)
          };
        if (lO && lO.enableSceneOffline && !OO.startsWith("blob:")) {
          const XO = OO => {
              OO && OO.status > 400 ? CO && CO(OO) : VO()
            },
            bK = () => {
              lO && lO.loadFile(AO.BaseUrl + OO, (OO => {
                !oO && KO && KO(OO), FO.onCompleteObservable.notifyObservers(FO)
              }), pO ? OO => {
                !oO && pO && pO(OO)
              } : void 0, XO, vK)
            };
          lO.open(bK, XO)
        } else VO();
        return FO
      },
      gK = OO => {
        const {
          match: KO,
          type: pO
        } = jK(OO);
        if (KO) return pO || void 0;
        const XO = OO.lastIndexOf(".");
        switch (OO.substring(XO + 1).toLowerCase()) {
          case "glb":
            return "model/gltf-binary";
          case "bin":
            return "application/octet-stream";
          case "UhO":
            return "model/gltf+json";
          case "jpg":
          case "jpeg":
            return "image/jpeg";
          case "png":
            return "image/png";
          case "webp":
            return "image/webp";
          case "ktx":
            return "image/ktx";
          case "ktx2":
            return "image/ktx2";
          case "avif":
            return "image/avif";
          default:
            return
        }
      },
      uO = () => "undefined" !== typeof location && "file:" === location.protocol,
      EO = OO => VO.test(OO),
      jK = OO => {
        const KO = VO.exec(OO);
        if (null === KO || 0 === KO.length) return {
          match: !1,
          type: ""
        };
        return {
          match: !0,
          type: KO[0].replace("data:", "").replace(";base64,", "")
        }
      };

    function YO(OO) {
      return (0, CO.e)(OO.split(",")[1])
    }
    const wO = OO => (0, CO.i)(OO.split(",")[1]);
    let iK;
    const rK = (OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) => {
      iK = {
        DecodeBase64UrlToBinary: OO,
        DecodeBase64UrlToString: KO,
        DefaultRetryStrategy: pO.DefaultRetryStrategy,
        BaseUrl: pO.BaseUrl,
        CorsBehavior: pO.CorsBehavior,
        PreprocessUrl: pO.PreprocessUrl,
        IsBase64DataUrl: XO,
        IsFileURL: bK,
        LoadFile: eO,
        LoadImage: lO,
        ReadFile: vK,
        RequestFile: CO,
        SetCorsBehavior: hO
      }, Object.defineProperty(iK, "DefaultRetryStrategy", {
        get: function() {
          return pO.DefaultRetryStrategy
        },
        set: function(OO) {
          pO.DefaultRetryStrategy = OO
        }
      }), Object.defineProperty(iK, "BaseUrl", {
        get: function() {
          return pO.BaseUrl
        },
        set: function(OO) {
          pO.BaseUrl = OO
        }
      }), Object.defineProperty(iK, "PreprocessUrl", {
        get: function() {
          return pO.PreprocessUrl
        },
        set: function(OO) {
          pO.PreprocessUrl = OO
        }
      }), Object.defineProperty(iK, "CorsBehavior", {
        get: function() {
          return pO.CorsBehavior
        },
        set: function(OO) {
          pO.CorsBehavior = OO
        }
      })
    };
    let PO = !1;

    function mK() {
      PO || (PO = !0, rK(YO, wO, AO, EO, uO, IO, TO, NO, yK, fO), DO.e.loadFile = IO, DO.e.loadImage = TO, MO.k.loadFile = IO)
    }
  },
  38140: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => eO,
      i: () => lO
    });
    let XO = null;

    function bK() {
      if (XO) return XO;
      const OO = new ArrayBuffer(4),
        KO = new Float32Array(OO),
        pO = new Uint32Array(OO),
        bK = new Uint32Array(512),
        eO = new Uint32Array(512);
      for (let XO = 0; XO < 256; ++XO) {
        const OO = XO - 127;
        OO < -24 ? (bK[XO] = 0, bK[256 | XO] = 32768, eO[XO] = 24, eO[256 | XO] = 24) : OO < -14 ? (bK[XO] = 1024 >> -OO - 14, bK[256 | XO] = 1024 >> -OO - 14 | 32768, eO[XO] = -OO - 1, eO[256 | XO] = -OO - 1) : OO <= 15 ? (bK[XO] = OO + 15 << 10, bK[256 | XO] = OO + 15 << 10 | 32768, eO[XO] = 13, eO[256 | XO] = 13) : OO < 128 ? (bK[XO] = 31744, bK[256 | XO] = 64512, eO[XO] = 24, eO[256 | XO] = 24) : (bK[XO] = 31744, bK[256 | XO] = 64512, eO[XO] = 13, eO[256 | XO] = 13)
      }
      const lO = new Uint32Array(2048),
        vK = new Uint32Array(64),
        CO = new Uint32Array(64);
      for (let XO = 1; XO < 1024; ++XO) {
        let OO = XO << 13,
          KO = 0;
        for (; 0 === (8388608 & OO);) OO <<= 1, KO -= 8388608;
        OO &= -8388609, KO += 947912704, lO[XO] = OO | KO
      }
      for (let XO = 1024; XO < 2048; ++XO) lO[XO] = 939524096 + (XO - 1024 << 13);
      for (let XO = 1; XO < 31; ++XO) vK[XO] = XO << 23;
      vK[31] = 1199570944, vK[32] = 2147483648;
      for (let XO = 33; XO < 63; ++XO) vK[XO] = 2147483648 + (XO - 32 << 23);
      vK[63] = 3347054592;
      for (let XO = 1; XO < 64; ++XO) 32 !== XO && (CO[XO] = 1024);
      return XO = {
        floatView: KO,
        uint32View: pO,
        baseTable: bK,
        shiftTable: eO,
        mantissaTable: lO,
        exponentTable: vK,
        offsetTable: CO
      }, XO
    }
    const eO = 65504;

    function lO(OO) {
      const KO = bK();
      KO.floatView[0] = OO;
      const pO = KO.uint32View[0],
        XO = pO >> 23 & 511;
      return KO.baseTable[XO] + ((8388607 & pO) >> KO.shiftTable[XO])
    }

    function vK(OO) {
      const KO = bK();
      return KO.uint32View[0] = KO.mantissaTable[KO.offsetTable[OO >> 10] + (1023 & OO)] + KO.exponentTable[OO >> 10], KO.floatView[0]
    }
  },
  38129: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      i: () => bK,
      k: () => XO
    });
    const XO = OO => {
        const KO = ArrayBuffer.isView(OO) ? new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength) : new Uint8Array(OO);
        return "function" === typeof KO.toBase64 ? KO.toBase64() : function(OO) {
          const KO = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
          let pO, XO, bK, eO, lO, vK, CO, hO = "",
            DO = 0;
          for (; DO < OO.length;) pO = OO[DO++], XO = DO < OO.length ? OO[DO++] : Number.NaN, bK = DO < OO.length ? OO[DO++] : Number.NaN, eO = pO >> 2, lO = (3 & pO) << 4 | XO >> 4, vK = (15 & XO) << 2 | bK >> 6, CO = 63 & bK, isNaN(XO) ? vK = CO = 64 : isNaN(bK) && (CO = 64), hO += KO.charAt(eO) + KO.charAt(lO) + KO.charAt(vK) + KO.charAt(CO);
          return hO
        }(KO)
      },
      bK = OO => atob(OO),
      eO = OO => "function" === typeof Uint8Array.fromBase64 ? Uint8Array.fromBase64(OO).buffer : function(OO) {
        const KO = bK(OO),
          pO = KO.length,
          XO = new Uint8Array(new ArrayBuffer(pO));
        for (let bK = 0; bK < pO; bK++) XO[bK] = KO.charCodeAt(bK);
        return XO.buffer
      }(OO)
  },
  37955: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => lO
    });
    let XO = [];
    class bK {
      static SetImmediate(OO) {
        0 === XO.length && setTimeout((() => {
          const OO = XO;
          XO = [];
          for (const KO of OO) KO()
        }), 1), XO.push(OO)
      }
    }

    function eO(OO, KO, pO) {
      try {
        if (OO()) return KO(), !0
      } catch (XO) {
        return pO?.(XO), !0
      }
      return !1
    }
    const lO = function(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 16,
        bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 3e4,
        lO = arguments.length > 6 ? arguments[6] : void 0;
      if ((!(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5]) && eO(OO, KO, pO)) return null;
      const vK = setInterval((() => {
        eO(OO, KO, pO) ? clearInterval(vK) : (bK -= XO, bK < 0 && (clearInterval(vK), pO?.(new Error("Operation timed out after maximum retries. " + (lO || "")), !0)))
      }), XO);
      return () => clearInterval(vK)
    }
  },
  38112: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      constructor() {
        this._xhr = "undefined" !== typeof _native && _native.XMLHttpRequest ? new _native.XMLHttpRequest : new XMLHttpRequest, this._requestURL = ""
      }
      static get IsCustomRequestAvailable() {
        return Object.keys(XO.CustomRequestHeaders).length > 0 || XO.CustomRequestModifiers.length > 0
      }
      static _CleanUrl(OO) {
        return OO = (OO = OO.replace("file:http:", "http:")).replace("file:https:", "https:")
      }
      static _ShouldSkipRequestModifications(OO) {
        return XO.SkipRequestModificationForBabylonCDN && (OO.includes("preview.babylonjs.com") || OO.includes("cdn.babylonjs.com"))
      }
      static _CollectCustomizations(OO) {
        const KO = {
          ...arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}
        };
        if (XO._ShouldSkipRequestModifications(OO)) return {
          url: OO,
          headers: KO
        };
        for (const bK in XO.CustomRequestHeaders) {
          const OO = XO.CustomRequestHeaders[bK];
          OO && (KO[bK] = OO)
        }
        const pO = {
          setRequestHeader: (OO, pO) => {
            KO[OO] = pO
          }
        };
        for (const bK of XO.CustomRequestModifiers) {
          if (XO._ShouldSkipRequestModifications(OO)) break;
          const KO = bK(pO, OO);
          "string" === typeof KO && (OO = KO)
        }
        return {
          url: OO,
          headers: KO
        }
      }
      static async FetchAsync(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        const pO = KO.method ?? "GET";
        if ("undefined" !== typeof fetch) {
          const {
            url: bK,
            headers: eO
          } = XO._CollectCustomizations(XO._CleanUrl(OO), KO.headers ?? {});
          return await fetch(bK, {
            method: pO,
            headers: eO,
            body: KO.body ?? void 0
          })
        }
        return await new Promise(((bK, eO) => {
          const lO = new XO;
          lO.responseType = "arraybuffer", lO.addEventListener("readystatechange", (() => {
            if (4 === lO.readyState)
              if (lO.status >= 200 && lO.status < 300) {
                const OO = "undefined" !== typeof Headers ? new Headers : void 0,
                  KO = lO.getResponseHeader("Content-Type");
                KO && OO && OO.set("Content-Type", KO), "undefined" !== typeof Response ? bK(new Response(lO.response, {
                  status: lO.status,
                  statusText: lO.statusText,
                  headers: OO
                })) : bK({
                  ok: !0,
                  status: lO.status,
                  statusText: lO.statusText,
                  headers: {
                    get: OO => lO.getResponseHeader(OO)
                  },
                  arrayBuffer: async () => await Promise.resolve(lO.response)
                })
              } else eO(new Error(`HTTP ${lO.status} loading '${lO.requestURL}': ${lO.statusText}`))
          })), lO.open(pO, OO, KO.headers), lO.send(KO.body ?? null)
        }))
      }
      get requestURL() {
        return this._requestURL
      }
      get onprogress() {
        return this._xhr.onprogress
      }
      set onprogress(OO) {
        this._xhr.onprogress = OO
      }
      get readyState() {
        return this._xhr.readyState
      }
      get status() {
        return this._xhr.status
      }
      get statusText() {
        return this._xhr.statusText
      }
      get response() {
        return this._xhr.response
      }
      get responseURL() {
        return this._xhr.responseURL
      }
      get responseText() {
        return this._xhr.responseText
      }
      get responseType() {
        return this._xhr.responseType
      }
      set responseType(OO) {
        this._xhr.responseType = OO
      }
      get timeout() {
        return this._xhr.timeout
      }
      set timeout(OO) {
        this._xhr.timeout = OO
      }
      addEventListener(OO, KO, pO) {
        this._xhr.addEventListener(OO, KO, pO)
      }
      removeEventListener(OO, KO, pO) {
        this._xhr.removeEventListener(OO, KO, pO)
      }
      abort() {
        this._xhr.abort()
      }
      send(OO) {
        this._xhr.send(OO)
      }
      open(OO, KO, pO) {
        const {
          url: bK,
          headers: eO
        } = XO._CollectCustomizations(KO, pO);
        this._requestURL = XO._CleanUrl(bK), this._xhr.open(OO, this._requestURL, !0);
        for (const XO in eO) this._xhr.setRequestHeader(XO, eO[XO])
      }
      setRequestHeader(OO, KO) {
        this._xhr.setRequestHeader(OO, KO)
      }
      getResponseHeader(OO) {
        return this._xhr.getResponseHeader(OO)
      }
    }
    XO.CustomRequestHeaders = {}, XO.CustomRequestModifiers = new Array, XO.SkipRequestModificationForBabylonCDN = !0
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);