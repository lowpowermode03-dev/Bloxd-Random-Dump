export const id = 312;
export const ids = [312];
export const modules = {
  40187: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(37907);
    const bK = "clipPlaneFragment",
      eO = "#if defined(CLIPPLANE) || defined(CLIPPLANE2) || defined(CLIPPLANE3) || defined(CLIPPLANE4) || defined(CLIPPLANE5) || defined(CLIPPLANE6)\nif (false) {}\n#endif\n#ifdef CLIPPLANE\nelse if (fClipDistance>0.0)\n{discard;}\n#endif\n#ifdef CLIPPLANE2\nelse if (fClipDistance2>0.0)\n{discard;}\n#endif\n#ifdef CLIPPLANE3\nelse if (fClipDistance3>0.0)\n{discard;}\n#endif\n#ifdef CLIPPLANE4\nelse if (fClipDistance4>0.0)\n{discard;}\n#endif\n#ifdef CLIPPLANE5\nelse if (fClipDistance5>0.0)\n{discard;}\n#endif\n#ifdef CLIPPLANE6\nelse if (fClipDistance6>0.0)\n{discard;}\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40178: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(37907);
    const bK = "clipPlaneFragmentDeclaration",
      eO = "#ifdef CLIPPLANE\nvarying float fClipDistance;\n#endif\n#ifdef CLIPPLANE2\nvarying float fClipDistance2;\n#endif\n#ifdef CLIPPLANE3\nvarying float fClipDistance3;\n#endif\n#ifdef CLIPPLANE4\nvarying float fClipDistance4;\n#endif\n#ifdef CLIPPLANE5\nvarying float fClipDistance5;\n#endif\n#ifdef CLIPPLANE6\nvarying float fClipDistance6;\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40218: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(37907);
    const bK = "fogFragment",
      eO = "#ifdef FOG\nfloat fog=CalcFogFactor();\n#ifdef PBR\nfog=toLinearSpace(fog);\n#endif\ncolor.rgb=mix(vFogColor,color.rgb,fog);\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40182: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(37907);
    const bK = "fogFragmentDeclaration",
      eO = "#ifdef FOG\n#define FOGMODE_NONE 0.\n#define FOGMODE_EXP 1.\n#define FOGMODE_EXP2 2.\n#define FOGMODE_LINEAR 3.\n#define E 2.71828\nuniform vec4 vFogInfos;uniform vec3 vFogColor;varying vec3 vFogDistance;float CalcFogFactor()\n{float fogCoeff=1.0;float fogStart=vFogInfos.y;float fogEnd=vFogInfos.z;float fogDensity=vFogInfos.w;float fogDistance=length(vFogDistance);if (FOGMODE_LINEAR==vFogInfos.x)\n{fogCoeff=(fogEnd-fogDistance)/(fogEnd-fogStart);}\nelse if (FOGMODE_EXP==vFogInfos.x)\n{fogCoeff=1.0/pow(E,fogDistance*fogDensity);}\nelse if (FOGMODE_EXP2==vFogInfos.x)\n{fogCoeff=1.0/pow(E,fogDistance*fogDistance*fogDensity*fogDensity);}\nreturn clamp(fogCoeff,0.0,1.0);}\n#endif\n";
    XO.b.IncludesShadersStore[bK] || (XO.b.IncludesShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  },
  40604: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      colorPixelShader: () => MO
    });
    var XO = pO(37907),
      bK = pO(40178),
      eO = pO(40182),
      lO = pO(40187),
      vK = pO(40218);
    const CO = "colorPixelShader",
      hO = "#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\n#define VERTEXCOLOR\nvarying vec4 vColor;\n#else\nuniform vec4 color;\n#endif\n#include<clipPlaneFragmentDeclaration>\n#include<fogFragmentDeclaration>\n#define CUSTOM_FRAGMENT_DEFINITIONS\nvoid main(void) {\n#define CUSTOM_FRAGMENT_MAIN_BEGIN\n#include<clipPlaneFragment>\n#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)\ngl_FragColor=vColor;\n#else\ngl_FragColor=color;\n#endif\n#include<fogFragment>(color,gl_FragColor)\n#define CUSTOM_FRAGMENT_MAIN_END\n}";
    XO.b.ShadersStore[CO] || (XO.b.ShadersStore[CO] = hO);
    const DO = [bK.b, eO.c, lO.d, vK.b];
    for (const aK of DO) XO.b.IncludesShadersStore[aK.name] || (XO.b.IncludesShadersStore[aK.name] = aK.shader);
    const MO = {
      name: CO,
      shader: hO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);