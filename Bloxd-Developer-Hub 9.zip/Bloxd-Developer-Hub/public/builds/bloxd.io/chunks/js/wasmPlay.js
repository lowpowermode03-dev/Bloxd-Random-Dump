export const id = 55;
export const ids = [55];
export const modules = {
  37843: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      g: () => bK
    });
    const XO = "The world isn't loaded, so no blocks can be seen.",
      bK = "The world isn't loaded, so nothing in it can be seen."
  },
  35340: (OO, KO, pO) => {
    function XO(OO, KO) {
      OO instanceof Promise ? OO.then(KO).catch((OO => {
        console.error("Couldn't open the preview", OO)
      })) : KO(OO)
    }
    pO.d(KO, {
      b: () => lO
    });
    class bK {
      constructor(OO) {
        this.opened = null, this.view = null, this.size = null, this.closed = !1, XO(OO, (OO => {
          this.closed ? OO.close() : (this.opened = OO, null !== this.size && OO.resize(this.size.width, this.size.height), null !== this.view && OO.show(this.view))
        }))
      }
      show(OO) {
        var KO;
        this.view = OO, null === (KO = this.opened) || void 0 === KO || KO.show(OO)
      }
      resize(OO, KO) {
        var pO;
        this.size = {
          width: OO,
          height: KO
        }, null === (pO = this.opened) || void 0 === pO || pO.resize(OO, KO)
      }
      close() {
        var OO;
        this.closed = !0, null === (OO = this.opened) || void 0 === OO || OO.close(), this.opened = null
      }
    }
    class eO {
      constructor(OO) {
        this.ready = void 0, this.opened = null, this.size = null, this.closed = !1, this.ready = Promise.resolve(OO).then((OO => OO.ready)), XO(OO, (OO => {
          this.closed ? OO.close() : (this.opened = OO, null !== this.size && OO.resize(this.size.width, this.size.height))
        }))
      }
      get dev() {
        return this.opened.dev
      }
      isReady() {
        var OO, KO;
        return null !== (OO = null === (KO = this.opened) || void 0 === KO ? void 0 : KO.isReady()) && void 0 !== OO && OO
      }
      setCosmetic(OO, KO) {
        var pO;
        null === (pO = this.opened) || void 0 === pO || pO.setCosmetic(OO, KO)
      }
      playEmote(OO) {
        var KO;
        null === (KO = this.opened) || void 0 === KO || KO.playEmote(OO)
      }
      async untilDrawn(OO) {
        var KO;
        await this.ready, await (null === (KO = this.opened) || void 0 === KO ? void 0 : KO.untilDrawn(OO))
      }
      resize(OO, KO) {
        var pO;
        this.size = {
          width: OO,
          height: KO
        }, null === (pO = this.opened) || void 0 === pO || pO.resize(OO, KO)
      }
      close() {
        var OO;
        this.closed = !0, null === (OO = this.opened) || void 0 === OO || OO.close(), this.opened = null
      }
    }
    const lO = new class {
      constructor() {
        this.host = null, this.makeDefault = null
      }
      setHost(OO) {
        this.host = OO
      }
      setDefaultHost(OO) {
        this.makeDefault = OO
      }
      current() {
        if (null === this.host) {
          if (null === this.makeDefault) throw new Error("no preview host");
          this.host = this.makeDefault()
        }
        return this.host
      }
      openMob(OO) {
        return new bK(this.current().openMob(OO))
      }
      openPet(OO) {
        return new bK(this.current().openPet(OO))
      }
      openMobLineup(OO) {
        return new bK(this.current().openMobLineup(OO))
      }
      openCharacter(OO) {
        return new eO(this.current().openCharacter(OO))
      }
    }
  },
  37596: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => MO,
      g: () => aK
    });
    var XO = pO(149),
      bK = pO(1319),
      eO = pO(1315),
      lO = pO(2516),
      vK = pO(1329),
      CO = pO(35015),
      hO = pO(959),
      DO = pO(37568);

    function MO(OO) {
      (0, lO.i)("matchmake_failed", OO, XO.f[XO.f.SHADER_PACK])
    }
    async function aK(OO, KO) {
      var pO;
      const XO = null === (pO = await DO.shaderPackPage.preload()) || void 0 === pO ? void 0 : pO.listing,
        lO = (0, CO.e)();
      XO && null !== lO && await vK.c.reportShaderPackSession(OO, {
        packId: XO.packId,
        sourceHash: XO.sourceHash,
        game: (0, eO.i)(KO, bK.o, "other"),
        playSessionId: lO,
        visitSessionId: (0, hO.b)()
      })
    }
  },
  37580: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    let XO = !1;
    async function bK(OO, KO) {
      if (!XO) {
        XO = !0;
        try {
          const [{
            reloadBloxd: XO
          }, {
            NotificationProvider: bK
          }] = await Promise.all([Promise.resolve().then((() => pO(1481))), Promise.resolve().then((() => pO(1187)))]);
          if (!OO || !0 === await bK.showPromptPopup({
              title: "Unsaved changes",
              subtitle: "Exit and lose your unsaved changes?",
              confirmText: "Exit",
              destructive: !0,
              cancelText: "Cancel",
              unlockPointerKey: "replayExitUnsavedChanges"
            }).getResult()) return void XO(KO)
        } catch (bK) {
          console.error("Leaving the replay failed", bK)
        }
        XO = !1
      }
    }
  },
  37450: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      h: () => hO
    });
    var XO = pO(171),
      bK = pO(22),
      eO = pO(1056),
      lO = pO(1507),
      vK = pO(1008);
    async function CO(OO, KO) {
      return function(OO) {
        return "object" === typeof OO && null !== OO && OO.code === XO.e.VpnIp.code
      }(KO) && function(OO) {
        return bK.d.get("reactNativeFeatureFlags").appCheck && OO.isLoggedIn() && !OO.hasTriedAppAttestation()
      }(OO) && await async function(OO) {
        try {
          const KO = await (0, lO.d)();
          if (null === KO) return console.warn("The app couldn't get an App Check token"), OO.markAppAttestationTried(), !1;
          const {
            "3PSIDMCPP": pO
          } = await (0, vK.postJsonWithMetricsCookiesAndJsonResponse)(`${eO.clientSideServerUrls.indexUrl}/index/app-attestation`, {
            appCheckToken: KO.token
          }, {
            retries: 0
          }, OO.getMetricsCookies());
          return OO.setAppAttestedAuthJwt(pO), !0
        } catch (KO) {
          return console.error("Failed to attest the app:", KO), !1
        }
      }(OO)
    }
    async function hO(OO, KO) {
      try {
        return await KO()
      } catch (pO) {
        if (!await CO(OO, pO)) throw pO
      }
      return KO()
    }
  },
  37507: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(243),
      bK = pO(142),
      eO = pO(36);

    function lO() {
      eO.e.setItem(XO.Ib, eO.e.getItem(XO.Ib) + 1), (0, bK.o)() && eO.e.setItem(XO.Hb, eO.e.getItem(XO.Hb) + 1)
    }
  },
  35015: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      i: () => DO,
      l: () => oO,
      p: () => MO
    });
    var XO = pO(256),
      bK = pO(570),
      eO = pO(967),
      lO = pO(36);
    const vK = {
        idStorageKey: "playSessionId",
        lastActivityStorageKey: "playSessionLastActivityMs",
        expiryMs: 3e5
      },
      CO = "playSessionGameNameWithVariation",
      hO = "wasMatchmakePlayer";

    function DO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h;
      (0, eO.h)(OO, vK)
    }

    function MO() {
      (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).setItem(hO, !0)
    }

    function aK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h;
      return (0, eO.c)(OO, vK)
    }

    function oO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : lO.h;
      const pO = (0, eO.c)(KO, vK),
        DO = function(OO) {
          const KO = OO.getItem(CO);
          return "string" !== typeof KO ? null : KO
        }(KO),
        MO = function() {
          return !0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).getItem(hO)
        }(KO);
      let aK;
      return aK = null !== pO && null !== DO && (0, eO.f)(KO, vK) && function(OO, KO, pO) {
          const bK = (0, XO.Qb)(OO),
            eO = (0, XO.Qb)(KO),
            lO = (0, XO.Lb)(OO),
            vK = (0, XO.Lb)(KO);
          return !(bK !== eO || !pO) || bK === eO && lO === vK
        }(DO, OO, MO) ? pO : (0, bK.c)(), (0, eO.i)(KO, vK, aK), KO.setItem(CO, OO),
        function() {
          (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).removeItem(hO)
        }(KO), aK
    }
  },
  35011: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO,
      g: () => QO
    });
    var XO = pO(886),
      bK = pO(536),
      eO = pO(256),
      lO = pO(888),
      vK = pO(554),
      CO = pO(3710),
      hO = pO(94),
      DO = pO(142),
      MO = pO(1481),
      aK = pO(107),
      oO = pO(35015),
      FO = pO(36),
      VO = pO(959);

    function LO() {
      var OO, KO;
      return [...null !== (OO = navigator.languages) && void 0 !== OO ? OO : [null !== (KO = navigator.language) && void 0 !== KO ? KO : "none"], "En-GB"]
    }

    function QO(OO, KO, pO, QO, zK) {
      const AO = (0, XO.k)(KO) ? (0, XO.o)(KO) : null,
        fO = {
          cookies: (0, MO.getAllCookiesForGameNameWithVariation)(KO),
          isMobile: (0, hO.isMobile)(),
          isUsingCustomGameTexturePack: null !== AO && zK(AO),
          generalCookies: {
            joinDiscord: !!FO.e.getItem("DiscordPressed"),
            newGo: CO.d,
            ...OO.getMetricsCookies(),
            trafficCode: QO,
            compliance: hO.compliance
          },
          browserInfo: {
            ua: window.navigator.userAgent,
            name: (0, hO.getBrowserName)(),
            version: (0, hO.getBrowserVersion)(),
            platform: navigator.platform,
            platformType: (0, hO.getPlatformType)(),
            deviceType: (0, aK.c)()
          },
          isLoggedIn: OO.isLoggedIn(),
          lobbyName: pO,
          languages: LO(),
          version: bK.e,
          siteUsed: DO.t,
          subsiteUsed: DO.A,
          playSessionId: (0, oO.l)(KO),
          visitSessionId: (0, VO.b)(),
          clientReason: vK.i.reason
        };
      return null !== AO && (0, eO.xc)(AO) ? (fO.lobbyName = (0, XO.g)(AO, (0, XO.l)(KO), pO), {
        roomName: `classic_${lO.f}`,
        joinOptions: fO
      }) : {
        roomName: KO,
        joinOptions: fO
      }
    }
  },
  38748: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK
    });
    var XO = pO(37843);

    function bK(OO) {
      return {
        current: () => OO,
        watch: () => () => {}
      }
    }

    function eO() {}
    const lO = Object.freeze([0, 0, 0]),
      vK = {
        states: {
          health: bK({
            health: null,
            maxHealth: null,
            shield: null,
            maxShield: null
          }),
          inventory: bK({
            player: [],
            chestOrCreative: [],
            chest: null,
            creative: !1,
            selectedSlot: 0,
            freeSlots: 0
          }),
          hotbar: bK({
            items: [],
            ammo: 0,
            selectedSlot: null
          }),
          stationItems: bK({
            enchantable: {},
            salvageable: {}
          }),
          itemInfo: bK({}),
          creativeVisibility: bK({
            publicLobby: !1,
            shownInGame: {}
          }),
          aura: bK(null),
          heldItemAim: bK({
            gun: !1,
            aimable: !1,
            chargeName: null
          }),
          crouching: bK(!1),
          gliderBoostFuel: bK(0),
          flight: bK({
            canFly: !1,
            flying: !1
          }),
          crafting: bK({
            focus: null,
            recipes: [],
            detail: null
          }),
          players: bK({
            ids: [],
            byId: {},
            localId: null
          }),
          lobbyLeaderboardRows: bK({}),
          fullInventory: bK(!1),
          crosshairTarget: bK({
            interactPrompt: null,
            blockText: null,
            neededTool: null
          }),
          localPlayerAlive: bK(!0),
          replay: bK(null),
          replayEdits: bK(null),
          replayRecorder: bK({
            recording: !1,
            clipping: !1,
            hasClipBuffer: !1,
            seconds: 0
          }),
          replayVideoExporting: bK(!1)
        },
        events: {
          hotbarSlotRequested: {
            watch: () => () => {}
          },
          hotbarScrolled: {
            watch: () => () => {}
          },
          hotbarDropRequested: {
            watch: () => () => {}
          },
          inventoryDropRequested: {
            watch: () => () => {}
          },
          numberKeyPressed: {
            watch: () => () => {}
          },
          chestToggled: {
            watch: () => () => {}
          },
          chestRefreshed: {
            watch: () => () => {}
          },
          inventorySynced: {
            watch: () => () => {}
          },
          enchantingTableOpened: {
            watch: () => () => {}
          },
          cosmeticsUpdated: {
            watch: () => () => {}
          },
          shotDamageToShow: {
            watch: () => () => {}
          },
          boardEditRequested: {
            watch: () => () => {}
          },
          kill: {
            watch: () => () => {}
          },
          chatReceived: {
            watch: () => () => {}
          },
          ironChestOpenRequested: {
            watch: () => () => {}
          },
          localEffectUpdated: {
            watch: () => () => {}
          },
          localPlayerAliveSet: {
            watch: () => () => {}
          },
          replayUiActionRequested: {
            watch: () => () => {}
          },
          replayViewerRequested: {
            watch: () => () => {}
          }
        },
        commands: {
          selectHotbarSlot: eO,
          removeInventoryItem: () => !1,
          swapInventorySlots: () => !1,
          moveInventoryItem: () => !1,
          quickMoveInventoryItem: () => null,
          closeChest: eO,
          setInventoryOpen: eO,
          changeIronChestPasskey: eO,
          dragReplayCamera: eO,
          applyTemporaryThirdPerson: eO,
          holdEmoteWheel: eO,
          recordFlyingMiddleText: eO,
          focusCrafting: eO,
          craftRecipe: () => ({
            kR: 0,
            uq: null,
            amountAddedToSlot: 0
          }),
          salvageItem: () => !1,
          enchantItem: eO,
          setShopOpen: eO,
          buyShopItem: eO,
          sendChatMessage: eO,
          ignorePlayer: eO,
          reportPlayer: eO,
          reportWorldCodeChat: eO,
          requestDiscordReportKey: eO,
          reportLobbyOrGame: eO,
          playEmote: eO,
          updateMyCosmetic: eO,
          writeOnBoard: eO,
          writeBook: eO,
          writeNameTag: eO,
          setCustomLobbyBlock: eO,
          openIronChest: eO,
          sendCodeCollab: eO,
          clickCodeBlock: eO,
          bindCustomButtonKeys: eO,
          pressCustomButton: eO,
          moveReplayFreecam: eO,
          holdReplayFreecamVertical: eO,
          respawn: eO,
          wakeUp: eO,
          requestLeaderboard: eO,
          completeTask: eO,
          setServerCookie: eO,
          answerUiRequest: eO,
          chooseRewardedAd: eO,
          setCameraZoom: eO,
          setCrosshairInteractPrompt: eO,
          setLookSensitivity: eO,
          replayAction: eO,
          setReplayPlaying: eO,
          seekReplay: eO,
          setReplayCameraMode: eO,
          syncReplayCameraMode: eO,
          setReplayCameraKeyframe: eO,
          moveReplayCameraKeyframe: eO,
          deleteReplayCameraKeyframes: eO,
          setReplayPlaybackMark: eO,
          cropReplay: () => !1,
          holdReplayForShaderPackFailure: eO,
          exportReplayVideo: eO,
          toggleRecording: eO,
          saveClip: eO,
          setRecorderPrefs: eO,
          setReplayViewerOpen: eO
        },
        queries: {
          enchantingOffer: () => ({
            perks: [],
            options: []
          }),
          worldCodeAiChunk: () => XO.d,
          worldCodeAiGameState: () => XO.g
        },
        lookups: {
          localPos: () => lO,
          momentumFrac: () => 0,
          screenPos: () => ({
            x: 0,
            y: 0
          }),
          cameraZoom: () => 0,
          blocksStandingOn: () => [],
          dropAhead: () => !1,
          replayCamera: () => null,
          leaveGameReloadsPage: () => !1,
          codeBlockClickable: () => !1
        }
      }
  },
  38732: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      h: () => MO,
      i: () => vK,
      l: () => eO,
      m: () => bK,
      p: () => CO,
      r: () => DO
    });
    class XO extends Error {
      constructor() {
        super(...arguments), this.name = "CoreCorruption"
      }
    }

    function bK(OO) {
      return OO instanceof RangeError && /call stack/i.test(OO.message) || OO instanceof Error && "InternalError" === OO.name && /recursion/i.test(OO.message)
    }

    function eO(OO) {
      return /out of (executable )?memory|could not allocate memory|array buffer allocation failed/i.test(String(OO))
    }
    const lO = /wasm:\/\/|wasm-function\[|\[wasm code\]/;

    function vK(OO) {
      var KO;
      return OO instanceof WebAssembly.RuntimeError || OO instanceof XO || bK(OO) && lO.test(null !== (KO = OO.stack) && void 0 !== KO ? KO : "")
    }

    function CO(OO, KO) {
      if (vK(OO)) throw OO;
      console.error(KO, OO)
    }

    function hO(OO, KO, pO, bK, eO) {
      if (KO % bK !== 0 || KO + pO > OO.byteLength) throw new XO(`${eO}: ${pO} bytes at ${KO}, ${bK}-aligned, outside ${OO.byteLength} bytes of memory`)
    }

    function DO(OO, KO, pO, XO, bK) {
      return 0 === pO ? null : (hO(KO, pO, XO * OO.BYTES_PER_ELEMENT, OO.BYTES_PER_ELEMENT, bK), new OO(KO, pO, XO))
    }

    function MO(OO, KO, pO, XO, bK) {
      return 0 === KO ? null : (hO(OO, KO, pO, XO, bK), new DataView(OO, KO, pO))
    }
  },
  38674: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO,
      e: () => QO,
      g: () => VO,
      k: () => LO,
      o: () => aK,
      r: () => oO,
      s: () => DO,
      v: () => MO,
      y: () => FO
    });
    class XO extends Error {
      constructor(OO) {
        super(`the join's code did not load: ${OO instanceof Error?OO.message:String(OO)}`, {
          cause: OO
        }), this.request = void 0, this.name = "GameCodeLoadError", this.request = null === OO || void 0 === OO ? void 0 : OO.request
      }
    }
    let bK = null,
      eO = null,
      lO = null;
    const vK = [];
    let CO = null;

    function hO(OO, KO) {
      try {
        OO(KO)
      } catch (pO) {
        console.error("[bloxd-wasm-client] the game chunk's listener failed", pO)
      }
    }

    function DO() {
      return CO
    }

    function MO(OO) {
      vK.push(OO), null !== CO && hO(OO, CO)
    }

    function aK(OO) {
      return bK ??= Promise.all([pO.e(62), pO.e(64), pO.e(83), pO.e(198), pO.e(127), pO.e(219), pO.e(199), pO.e(200), pO.e(107), pO.e(81), pO.e(126), pO.e(229), pO.e(178), pO.e(76), pO.e(130), pO.e(184), pO.e(106), pO.e(226), pO.e(48)]).then((() => pO(40610))).then((KO => {
        KO.loadAudio(OO), CO = KO;
        for (const OO of vK) hO(OO, KO);
        return KO
      })).catch((OO => {
        throw bK = null, OO
      })), bK
    }
    async function oO(OO, KO) {
      try {
        const pO = await aK(OO);
        await pO.loadClientGame(KO)
      } catch (pO) {
        throw new XO(pO)
      }
    }

    function FO(OO, KO) {
      eO = {
        running: OO,
        shell: KO
      }
    }

    function VO() {
      return lO
    }
    async function LO(OO) {
      const KO = eO;
      if ((null === KO || void 0 === KO ? void 0 : KO.running) !== OO) throw new Error("the core's session has ended");
      const pO = await aK(KO.shell.audio).catch((OO => {
        throw new XO(OO)
      }));
      if (null !== lO) return lO;
      if (eO !== KO || OO.isStopped) throw new Error("the core stopped while the game code loaded");
      if (lO = pO.startGameHost(OO, KO.shell), null === lO) throw new Error("the core's shared tables didn't read, so the game can't start");
      return lO
    }

    function QO() {
      null !== lO && (null !== CO ? CO.endGameHost(lO) : lO.closeGame()), lO = null, eO = null
    }
  },
  35075: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO,
      d: () => aK,
      e: () => lO,
      h: () => vK
    });
    var XO = pO(1964),
      bK = pO(1969),
      eO = pO(1973);

    function lO(OO, KO) {
      return (!(0, eO.b)() || 0 === OO && 0 === KO) && (0, bK.s)(XO.f.Joystick, 0, OO, KO, 0)
    }

    function vK(OO, KO) {
      return !(0, eO.b)() && (0, bK.s)(XO.f.TouchLook, 0, OO, KO, 0)
    }
    const CO = {
      Action1: 1,
      Action2: 2,
      Action3: 3,
      Attack: 4,
      Use: 5,
      Interact: 6,
      Boost: 7
    };

    function hO(OO) {
      return !(OO instanceof HTMLElement) || OO.offsetWidth <= 0 || OO.offsetHeight <= 0 ? null : {
        width: OO.offsetWidth,
        height: OO.offsetHeight
      }
    }

    function DO(OO, KO) {
      const pO = OO => Math.min(65535, Math.round(4 * OO));
      return (pO(OO) | pO(KO) << 16) >>> 0
    }

    function MO(OO) {
      return {
        x: OO.left + OO.width / 2,
        y: OO.top + OO.height / 2,
        radius: Math.min(OO.width, OO.height) / 2
      }
    }
    const aK = new class {
      constructor(OO) {
        this.write = OO, this.elements = new Map
      }
      set(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        KO ? this.elements.set(OO, {
          element: KO,
          hidden: pO
        }) : this.elements.delete(OO), this.measureOne(OO)
      }
      measure() {
        for (const OO of this.elements.keys()) this.measureOne(OO)
      }
      hitZone(OO, KO) {
        let pO = null,
          XO = 1;
        for (const bK of this.elements.keys()) {
          const eO = this.shown(bK);
          if (!eO) continue;
          const {
            rect: lO,
            element: vK
          } = eO, CO = MO(lO), DO = Math.max(0, lO.width / 2 - CO.radius), aK = Math.max(0, lO.height / 2 - CO.radius), oO = Math.max(0, Math.abs(OO - CO.x) - DO), FO = Math.max(0, Math.abs(KO - CO.y) - aK), VO = vK.firstElementChild;
          let LO = Math.hypot(oO, FO) / CO.radius;
          const QO = hO(VO);
          QO && (LO = Math.min(LO, Math.max(2 * Math.abs(OO - CO.x) / QO.width, 2 * Math.abs(KO - CO.y) / QO.height))), LO < XO && (pO = {
            code: bK,
            element: vK,
            key: VO,
            ...CO
          }, XO = LO)
        }
        return pO
      }
      measureOne(OO) {
        const KO = this.shown(OO);
        if (!KO) return void this.write(XO.f.TouchZone, OO, 0, 0, 0);
        const {
          rect: pO,
          element: bK
        } = KO, eO = MO(pO);
        this.write(XO.f.TouchZone, OO, eO.x, eO.y, DO(pO.width, pO.height));
        const lO = hO(bK.firstElementChild);
        this.write(XO.f.TouchZone, 256 | OO, 0, 0, lO ? DO(lO.width, lO.height) : 0)
      }
      shown(OO) {
        const KO = this.elements.get(OO);
        if (!KO || KO.hidden) return null;
        const pO = KO.element.getBoundingClientRect();
        return pO.width <= 0 || pO.height <= 0 ? null : {
          rect: pO,
          element: KO.element
        }
      }
    }(bK.s)
  },
  38926: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO,
      e: () => DO
    });
    var XO = pO(38943),
      bK = pO(37450),
      eO = pO(35011),
      lO = pO(38933),
      vK = pO(38873),
      CO = pO(38917);
    const hO = XO.e.timeForPlayerToConnect - 1e4;
    async function DO(OO, KO, pO) {
      const XO = await OO.getTrafficCode().then((OO => null !== OO && void 0 !== OO ? OO : null), (OO => (console.error("[bloxd-wasm-client] could not get a traffic code", OO), null)));
      if (null === XO) throw new CO.s;
      const {
        gameNameWithVariation: hO,
        lobbyName: DO
      } = KO, MO = () => {
        const KO = (0, eO.g)(OO, hO, DO, XO, (OO => {
          var KO;
          return null !== (KO = null === pO || void 0 === pO ? void 0 : pO.isUsingCustomGameTexturePack(OO)) && void 0 !== KO && KO
        }));
        KO.joinOptions.wasmClient = !0, KO.joinOptions.budgetBasis = (0, lO.i)();
        const bK = (0, vK.C)();
        return null !== bK && (KO.joinOptions.renderBackend = bK), KO
      }, {
        roomName: aK,
        joinOptions: oO
      } = MO();
      return {
        endpoint: KO.endpoint,
        roomName: aK,
        joinOptions: oO,
        session: {
          gameNameWithVariation: hO,
          lobbyName: DO,
          playerDbId: OO.whamm
        },
        optionsAfterRefusal: async KO => await (0, bK.d)(OO, KO) ? MO().joinOptions : null
      }
    }
  },
  38680: (OO, KO, pO) => {
    pO.d(KO, {
      $: () => AO,
      B: () => jK,
      C: () => fO,
      D: () => dO,
      F: () => LO,
      J: () => gK,
      K: () => wO,
      O: () => FO,
      R: () => rK,
      V: () => zK,
      Z: () => QO,
      b: () => bK,
      d: () => iK,
      db: () => TO,
      e: () => YO,
      g: () => oO,
      j: () => VO,
      l: () => EO,
      p: () => IO,
      t: () => uO,
      x: () => yK,
      y: () => NO
    });
    var XO = pO(2325);
    const bK = {
      Chat: 49,
      UiRequestResponded: 91,
      CodeCollab: 89,
      SetCustomLobbyBlock: 60,
      UpdateBook: 56,
      UpdateBoard: 33,
      UpdateMyCosmetic: 45,
      PlayEmote: 90,
      ReqDiscordReportKey: 9,
      UserReport: 11,
      LobbyReport: 12,
      CustomGameReport: 13,
      IgnoreUser: 34,
      ShopMenuChanged: 26,
      GeneralCookieSet: 72,
      CompleteTask: 69,
      OpenIronChest: 80,
      ChangeIronChestPasskey: 81,
      StopSleeping: 78,
      AnalyticsUpdate: 3,
      UiRequestResp: 15,
      QteResponse: 16,
      ItemBought: 25,
      LeaderboardRequest: 40,
      UpdateNameTag: 53
    };

    function eO(OO, KO) {
      return !ArrayBuffer.isView(OO) || OO instanceof DataView ? Array.isArray(OO) ? OO.map((OO => KO(OO))) : OO : Array.from(OO, (OO => KO(OO)))
    }

    function lO(OO) {
      if ("string" !== typeof OO) return OO;
      for (let KO = 0; KO < OO.length; KO++) {
        const pO = OO.charCodeAt(KO);
        if (pO >= 55296 && pO <= 57343) return CO.decode(vK.encode(OO))
      }
      return OO
    }
    const vK = new TextEncoder,
      CO = new TextDecoder;

    function hO(OO) {
      return OO
    }
    let DO;

    function MO(OO) {
      return null === OO || "object" !== typeof OO ? OO : [lO(OO.LX), lO(OO.Ur)]
    }

    function aK(OO) {
      return null === OO || "object" !== typeof OO ? OO : [eO(OO.hiO, hO), eO(OO.pC, hO)]
    }

    function oO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.Tl), lO(KO.QG)];
      var KO
    }

    function FO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [KO.id, KO.lV];
      var KO
    }

    function VO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [KO.Zm, lO(KO.Wm), KO.Xs, lO(KO.Fs), KO.Qs, KO.jH, KO.qH, lO(KO.xH), lO(KO.Ws)];
      var KO
    }

    function LO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [eO(KO.NJ, hO), KO.yl];
      var KO
    }

    function QO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [eO(KO.uZ, (OO => lO(OO))), lO(KO.jG), KO.wZ];
      var KO
    }

    function zK(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [eO(KO.aZ, hO), lO(KO.oB), KO.uB];
      var KO
    }

    function AO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.oV), lO(KO.VV)];
      var KO
    }

    function fO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.GV)];
      var KO
    }

    function dO(OO) {
      return lO(OO)
    }

    function TO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.WG), lO(KO.lq), lO(KO.LX), lO(KO.Ur)];
      var KO
    }

    function NO(OO) {
      return MO(OO)
    }

    function IO(OO) {
      return MO(OO)
    }

    function yK(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.sH)];
      var KO
    }

    function gK(OO) {
      return OO
    }

    function uO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.zq), lO(KO.YG)];
      var KO
    }

    function EO(OO) {
      return lO(OO)
    }

    function jK(OO) {
      return aK(OO)
    }

    function YO(OO) {
      return aK(OO)
    }

    function wO(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [lO(KO.LJ)];
      var KO
    }

    function iK(OO) {
      return (DO ??= (0, XO.e)().map((OO => OO.name)), DO).map((KO => {
        return "string" === typeof(pO = OO[KO]) ? lO(pO) : eO(pO, hO);
        var pO
      }))
    }

    function rK(OO) {
      return null === (KO = OO) || "object" !== typeof KO ? KO : [KO.lY, KO.hY, KO.FY];
      var KO
    }
  },
  38900: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      followPageUiPack: () => WO,
      packForGame: () => nO.u,
      playWasmGame: () => CK,
      prefetchWasmPreviews: () => nO.x,
      setGamePackConfirm: () => nO.E,
      startWasmPlay: () => KK,
      startWasmPreviews: () => nO.M
    });
    var XO = pO(171),
      bK = pO(1104),
      eO = pO(149),
      lO = pO(37456),
      vK = pO(1556),
      CO = pO(26),
      hO = pO(3846),
      DO = pO(1152),
      MO = pO(1163),
      aK = pO(37580),
      oO = pO(37596),
      FO = pO(37507),
      VO = pO(35015),
      LO = pO(38769),
      QO = pO(3923),
      zK = pO(38674),
      AO = pO(38748),
      fO = pO(38680);
    const dO = {
      states: {
        health: !0,
        aura: !0,
        hotbar: !0,
        heldItemAim: !0,
        crouching: !0,
        flight: !0,
        gliderBoostFuel: !0,
        crosshairTarget: !0,
        inventory: !0,
        crafting: !0,
        stationItems: !0,
        itemInfo: !0,
        creativeVisibility: !0,
        fullInventory: !0,
        replay: !0,
        replayEdits: !0,
        replayRecorder: !0,
        replayVideoExporting: !0,
        players: !0,
        lobbyLeaderboardRows: !0
      },
      events: {
        hotbarSlotRequested: !0,
        hotbarScrolled: !0,
        numberKeyPressed: !0,
        shotDamageToShow: !0,
        chatReceived: !0,
        chestToggled: !0,
        chestRefreshed: !0,
        inventorySynced: !0,
        inventoryDropRequested: !0,
        enchantingTableOpened: !0,
        localEffectUpdated: !0,
        kill: !0,
        replayUiActionRequested: !0,
        replayViewerRequested: !0,
        cosmeticsUpdated: !0,
        boardEditRequested: !0,
        ironChestOpenRequested: !0
      },
      commands: {
        clickCodeBlock: !0,
        selectHotbarSlot: !0,
        setCrosshairInteractPrompt: !0,
        sendChatMessage: !0,
        removeInventoryItem: !0,
        swapInventorySlots: !0,
        moveInventoryItem: !0,
        quickMoveInventoryItem: !0,
        setInventoryOpen: !0,
        closeChest: !0,
        focusCrafting: !0,
        craftRecipe: !0,
        salvageItem: !0,
        enchantItem: !0,
        changeIronChestPasskey: !0,
        openIronChest: !0,
        completeTask: !0,
        setServerCookie: !0,
        answerUiRequest: !0,
        requestLeaderboard: !0,
        chooseRewardedAd: !0,
        ignorePlayer: !0,
        reportPlayer: !0,
        reportWorldCodeChat: !0,
        requestDiscordReportKey: !0,
        reportLobbyOrGame: !0,
        updateMyCosmetic: !0,
        holdEmoteWheel: !0,
        writeOnBoard: !0,
        writeBook: !0,
        writeNameTag: !0,
        setCustomLobbyBlock: !0,
        sendCodeCollab: !0,
        replayAction: !0,
        setReplayPlaying: !0,
        seekReplay: !0,
        setReplayCameraMode: !0,
        syncReplayCameraMode: !0,
        setReplayCameraKeyframe: !0,
        moveReplayCameraKeyframe: !0,
        deleteReplayCameraKeyframes: !0,
        setReplayPlaybackMark: !0,
        cropReplay: !0,
        holdReplayForShaderPackFailure: !0,
        exportReplayVideo: !0,
        toggleRecording: !0,
        saveClip: !0,
        setRecorderPrefs: !0,
        setReplayViewerOpen: !0,
        recordFlyingMiddleText: !0,
        dragReplayCamera: !0,
        moveReplayFreecam: !0,
        holdReplayFreecamVertical: !0,
        setShopOpen: !0,
        buyShopItem: !0
      },
      queries: {
        enchantingOffer: !0,
        worldCodeAiChunk: !0,
        worldCodeAiGameState: !0
      },
      lookups: {
        momentumFrac: !0,
        localPos: !0,
        screenPos: !0,
        codeBlockClickable: !0,
        blocksStandingOn: !0,
        dropAhead: !0,
        replayCamera: !0,
        leaveGameReloadsPage: !0
      }
    };

    function TO(OO) {
      const KO = {
        ...AO.c[OO]
      };
      for (const pO of Object.keys(dO[OO])) delete KO[pO];
      return KO
    }

    function NO() {
      var OO, KO;
      return null === (OO = null === (KO = (0, zK.g)()) || void 0 === KO ? void 0 : KO.localPlayerAlive()) || void 0 === OO || OO
    }

    function IO() {
      var OO, KO;
      return null !== (OO = null === (KO = (0, zK.g)()) || void 0 === KO ? void 0 : KO.localDeaths()) && void 0 !== OO ? OO : null
    }
    const yK = {
        current: NO,
        watch: OO => {
          let KO = NO(),
            pO = IO();
          return (0, QO.v)((() => {
            const XO = NO(),
              bK = IO(),
              eO = null !== bK && null !== pO && bK !== pO;
            pO = bK, eO ? (KO || OO(!0), OO(!1), XO && OO(!0), KO = XO) : XO !== KO && (KO = XO, OO(XO))
          }))
        }
      },
      gK = {
        states: {
          ...TO("states"),
          localPlayerAlive: yK
        },
        events: {
          ...TO("events"),
          localPlayerAliveSet: {
            watch: yK.watch
          }
        },
        commands: {
          ...TO("commands"),
          respawn: () => {
            var OO;
            null === (OO = (0, zK.g)()) || void 0 === OO || OO.respawn()
          },
          playEmote: OO => {
            var KO;
            null === (KO = (0, zK.g)()) || void 0 === KO || KO.send(fO.b.PlayEmote, (0, fO.C)({
              GV: OO
            }))
          },
          applyTemporaryThirdPerson: OO => {
            var KO;
            let {
              durationMs: pO
            } = OO;
            null === (KO = (0, zK.g)()) || void 0 === KO || KO.thirdPersonFor(pO)
          },
          bindCustomButtonKeys: OO => {
            var KO;
            null === (KO = (0, zK.g)()) || void 0 === KO || KO.bindCustomButtonKeys(OO)
          },
          pressCustomButton: OO => {
            var KO;
            let {
              id: pO,
              down: XO
            } = OO;
            null === (KO = (0, zK.g)()) || void 0 === KO || KO.pressCustomButton(pO, XO)
          },
          setLookSensitivity: () => {},
          wakeUp: OO => {
            const KO = (0, fO.K)({
                LJ: OO
              }),
              pO = () => {
                const OO = (0, zK.g)();
                return !(null !== OO && void 0 !== OO && OO.isSessionLive) || OO.send(fO.b.StopSleeping, KO)
              };
            if (!pO()) {
              const OO = (0, QO.v)((() => {
                pO() && OO()
              }))
            }
          },
          setCameraZoom: OO => {
            var KO;
            null === (KO = (0, zK.g)()) || void 0 === KO || KO.setCameraZoom(OO)
          }
        },
        queries: TO("queries"),
        lookups: {
          ...TO("lookups"),
          cameraZoom: () => {
            var OO, KO;
            return null !== (OO = null === (KO = (0, zK.g)()) || void 0 === KO ? void 0 : KO.cameraZoom()) && void 0 !== OO ? OO : 0
          }
        }
      };
    var uO = pO(38908),
      EO = pO(38917),
      jK = pO(38926),
      YO = pO(1111),
      wO = pO(105),
      iK = pO(3710),
      rK = pO(2977),
      PO = pO(1035);
    const mK = {
      qV: () => (0, YO.d)(),
      inbuiltOverwritten: () => iK.e,
      reflectApplyHit: () => PO.b,
      definerHit: () => wO.currentUrl.c,
      emitReplaced: () => (0, CO.d)(),
      confirmMesh: () => (0, rK.b)()
    };
    var sO = pO(38950),
      HO = pO(38959);
    var RO = pO(22),
      SO = pO(1558),
      JO = pO(1591),
      cK = pO(1446),
      BO = pO(1631),
      ZO = pO(1051),
      GO = pO(1109);

    function qK() {
      return GO.f.get().getCurrentLanguageCode()
    }

    function xK(OO) {
      const KO = () => {
        OO({
          translate: (OO, KO) => (0, ZO.v)(qK(), OO, KO),
          keyBindingText: OO => {
            const KO = (0, JO.o)(OO, RO.d.get("isTouchScreen"));
            return null !== KO ? (0, ZO.z)(qK(), KO.translationKey, KO.params) : (0, JO.j)((0, JO.m)(OO))
          },
          isFriend: BO.g,
          hiddenNames: SO.c.shown
        })
      };
      let pO = !1;
      const XO = () => {
          const OO = qK();
          (0, ZO.l)(OO).then((() => {
            pO || OO !== qK() || KO()
          }))
        },
        bK = () => cK.e.getSocialState().friends.map((OO => OO.name.toLowerCase())).sort().join(" ");
      let eO = bK();
      KO(), XO();
      const lO = [(0, GO.i)((() => {
        KO(), XO()
      })), (0, CO.j)("customBindingsChanged", KO), (0, CO.j)("appManagerUpdated|isTouchScreen", KO), (0, BO.d)((() => {
        const OO = bK();
        OO !== eO && (eO = OO, KO())
      })), SO.c.subscribe(KO)];
      return () => {
        pO = !0;
        for (const OO of lO) OO()
      }
    }
    var nO = pO(38961);

    function WO(OO) {
      ! function(OO, KO) {
        OO((OO => {
          null === OO || void 0 === OO || OO.subscribe((OO => {
            let {
              pack: pO,
              gameSource: XO
            } = OO;
            KO(null === XO || null === pO ? null : {
              pack: pO,
              source: "" === XO ? null : XO
            })
          }))
        }))
      }(nO.e, OO)
    }
    let tK = !1,
      kK = null,
      UO = !1,
      OK = !1;

    function KK() {
      tK || (tK = !0, (0, nO.J)("play", mK), (0, MO.o)(new ap), vK.gameBridge.attach(gK), vp().catch((() => {})), (0, zK.v)((OO => {
        xK(OO.setTextHost)
      })), (0, nO.s)(bp), (0, nO.p)((OO => {
        XK(pK[OO])
      })))
    }
    const pK = {
      booted: eO.f.INITIALISE_NOA,
      texturesIn: eO.f.REGISTRATION,
      modelsIn: eO.f.SETUP_LIFEFORMS
    };

    function XK(OO) {
      CO.i.pl("matchmakeAndPlayStepCompleted", {
        step: OO,
        totalSubSteps: 1
      })
    }

    function bp(OO) {
      if (!UO) return;
      const {
        gameNameWithVariation: KO,
        lobbyName: pO
      } = (0, MO.b)();
      if (OO.code === XO.e.serverUpdating.code) return (new ap).leaveLive(), void lK(KO, pO);
      CO.i.pl("unwantedLeftGame", {
        reason: eK(OO),
        requiresRefresh: OO.requiresRefresh,
        canReconnect: null !== OO.reconnect,
        automaticallyReconnect: OO.reconnecting,
        canPlayAgain: OO.canPlayAgain,
        gameNameWithVariation: KO,
        lobbyName: pO
      }), (new ap).leaveLive()
    }

    function eK(OO) {
      return null !== OO.reasonKey ? {
        translationKey: OO.reasonKey
      } : "gameOrPluginKick" === OO.name ? OO.reason : `You have disconnected from the server.\n${OO.reason}`
    }

    function lK(OO, KO) {
      var XO;
      XO = (0, hO.x)(OO, KO), Promise.resolve().then((() => pO(1344))).then((OO => {
        let {
          navigatePreserveSearch: KO
        } = OO;
        KO(XO)
      })).catch((OO => {
        console.warn("[bloxd-wasm-client] the page's router didn't navigate: loading the page instead", OO), (0, HO.f)(XO)
      }))
    }

    function vp() {
      return kK ??= Promise.all([pO.e(62), pO.e(65), pO.e(63), pO.e(64), pO.e(75), pO.e(74), pO.e(229), pO.e(201), pO.e(226), pO.e(227), pO.e(42)]).then((() => pO(38766))).then((OO => {
        try {
          OO.attachPlayGameSources()
        } catch (KO) {
          throw console.error("[bloxd-wasm-client] the play sources did not attach", KO), (0, nO.N)(KO), KO
        }
      }), (OO => {
        throw kK = null, new zK.c(OO)
      })), kK
    }
    async function CK(OO, KO) {
      KK(), UO = !0;
      let pO = {
          place: OO.place,
          matchedAt: OO.matchedAt
        },
        lO = OO.place.gameNameWithVariation,
        vK = null;
      const CO = await (0, nO.h)({
        matchmake: async () => {
          let KO = pO;
          if (pO = null, null === KO) {
            const pO = await OO.rematch();
            if (pO.isError()) throw vK = pO.asError().forward(), new Error(pO.asError().message);
            KO = {
              place: pO.getValue(),
              matchedAt: performance.now()
            }
          }
          lO = KO.place.gameNameWithVariation;
          return {
            target: await (0, jK.e)(OO.userContext, KO.place, (0, nO.k)()),
            matchedAt: KO.matchedAt,
            freshMs: jK.d
          }
        },
        pageReady: vp,
        onFailure: (OO, KO) => {
          null === vK && (0, nO.o)(OO, {
            sinceJoinStartMs: KO,
            game: lO
          })
        },
        rejoin: () => () => {},
        invalidateTrafficCode: () => OO.userContext.invalidateTrafficCode(),
        signal: KO
      });
      switch (CO.kind) {
        case "joined":
          return OK || (OK = !0, (0, FO.d)()), UO ? (XK(eO.f.CONNECT_TO_GAME_SERVER), XK(eO.f.SHADER_PACK), (0, nO.I)() && (0, oO.g)(OO.userContext, lO).catch((OO => {
            console.error("Failed to report the shader pack session", OO)
          })), function() {
            const OO = (0, nO.G)();
            null !== OO && (0, oO.e)(OO)
          }(), bK.c.value(void 0)) : MK("The server ended the game as it joined");
        case "failed":
          if (!CO.reloading) {
            if (null !== vK) return vK;
            if ((CO.error instanceof EO.h || CO.error instanceof EO.b) && CO.error.code === XO.e.serverUpdating.code) {
              if (KO.aborted) return MK("Left the game while it loaded");
              const {
                gameNameWithVariation: OO,
                lobbyName: pO
              } = (0, MO.b)();
              return lK(OO, pO), MK("The server is updating")
            }
            return CO.error instanceof sO.b ? bK.c.errorWithCode(CO.error.messageKey, eO.f.SHADER_PACK, {
              severity: "medium"
            }) : bK.c.errorWithCode(function(OO) {
              if (OO instanceof EO.s) return OO.message;
              if (hK(OO)) return (0, uO.o)(OO.code, OO.serverText);
              return uO.g
            }(CO.error), eO.f.CONNECT_TO_GAME_SERVER, {
              error: (hO = CO.error, hO instanceof EO.s || hK(hO) ? void 0 : CO.error),
              severity: DK(CO.error)
            })
          }
          return MK("Reloading into the new build");
        case "stopped":
          return MK("The game client stopped, and shows why");
        case "dl":
          return MK("Left the game while it loaded")
      }
      var hO
    }

    function hK(OO) {
      return OO instanceof EO.h || OO instanceof EO.b && "attach" !== OO.stage
    }

    function DK(OO) {
      return hK(OO) ? OO instanceof EO.b && (0, uO.k)(OO.code).requiresRefresh ? "medium" : "low" : "medium"
    }

    function MK(OO) {
      return bK.c.errorWithCode(OO, eO.f.CONNECT_TO_GAME_SERVER, {
        severity: "low",
        dl: !0
      })
    }
    class ap {
      DX(OO) {
        if ((0, LO.c)()) {
          var KO, pO;
          if ((0, lO.c)()) return;
          (0, aK.b)(!0 === (null === (KO = (0, LO.h)()) || void 0 === KO || null === (pO = KO.currentViewer) || void 0 === pO ? void 0 : pO.unsavedChanges), OO)
        } else this.leaveLive()
      }
      leaveLive() {
        var OO;
        if (null === (OO = (0, nO.k)()) || void 0 === OO || OO.endGamePack(), !UO) return;
        UO = !1, (0, VO.i)();
        try {
          var KO;
          null === (KO = (0, zK.s)()) || void 0 === KO || KO.clearWasmCameraScreen()
        } catch (XO) {
          console.error("[bloxd-wasm-client] the camera screen didn't clear", XO)
        }
        const {
          gameNameWithVariation: pO
        } = (0, MO.b)();
        try {
          (0, nO.i)()
        } finally {
          (0, MO.q)({
            websocketUrl: null
          }), CO.i.pl("leaveGame", {
            gameNameWithVariation: pO
          }), (0, DO.bb)()
        }
      }
      isReplay() {
        return (0, LO.c)()
      }
    }
  },
  36122: (OO, KO, pO) => {
    function XO(OO) {
      return "string" !== typeof OO || 2 !== OO.length && ":" !== OO[2] ? null : OO[0] + OO[1]
    }

    function bK(OO) {
      const KO = XO(OO);
      return "op" === KO || "ep" === KO || "wi" === KO || "pp" === KO || "fp:call" === OO || "fp:t" === OO
    }

    function eO(OO) {
      return "fp" === XO(OO) && !bK(OO)
    }

    function lO(OO) {
      if ("string" !== typeof OO) return !1;
      return "o" === OO[0] && "p" === OO[1] && (2 === OO.length || ":" === OO[2]) || "fp:call" === OO || "2" === OO || "t" === OO || "a" === OO
    }

    function vK(OO, KO) {
      return `~${function(OO){return OO.length<2?OO:":"===OO[1]?OO[0]:OO[0]+OO[1]}(KO)}~${OO}`
    }
    pO.d(KO, {
      c: () => FO,
      e: () => lO,
      h: () => eO,
      j: () => bK,
      l: () => vK,
      m: () => oO
    });
    const CO = 200;

    function hO(OO) {
      let KO = OO.length - 1;
      for (let pO = 0; pO < 2; pO++) {
        const pO = KO;
        for (; KO >= 0 && OO[KO] >= "0" && OO[KO] <= "9";) KO--;
        if (KO < 0 || KO === pO || ":" !== OO[KO]) return -1;
        KO--
      }
      return KO + 1
    }

    function DO(OO) {
      return "unknown" === OO || hO(OO) >= 0
    }

    function MO(OO, KO) {
      return OO[KO] >= "\ud800" && OO[KO] <= "\udbff" && KO + 1 < OO.length && OO[KO + 1] >= "\udc00" && OO[KO + 1] <= "\udfff" ? 2 : 1
    }

    function aK(OO, KO, pO) {
      return 2 === pO ? 4 : OO[KO] <= "\x7f" ? 1 : OO[KO] <= "\u07ff" ? 2 : 3
    }

    function oO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1 / 0;
      if ("string" !== typeof OO || OO.length > CO || !DO(OO)) return "t";
      let pO = 2;
      for (let vK = 0; vK < OO.length;) {
        const KO = MO(OO, vK);
        pO += aK(OO, vK, KO), vK += KO
      }
      if (pO <= KO) return `t ${OO}`;
      const XO = hO(OO);
      let bK = KO - 2 - (OO.length - XO);
      if (bK < 0) return "t";
      let eO = 0;
      for (; eO < XO;) {
        const KO = MO(OO, eO),
          pO = aK(OO, eO, KO);
        if (pO > bK) break;
        bK -= pO, eO += KO
      }
      let lO = "t ";
      for (let vK = 0; vK < eO; vK++) lO += OO[vK];
      for (let vK = XO; vK < OO.length; vK++) lO += OO[vK];
      return lO
    }
    const FO = 62
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);