export const id = 345;
export const ids = [345];
export const modules = {
  59308: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      lod3DPixelShader: () => lO
    });
    var XO = pO(37907);
    const bK = "lod3DPixelShader",
      eO = "precision highp float;precision highp sampler3D;const float GammaEncodePowerApprox=1.0/2.2;varying vec2 vUV;uniform sampler3D textureSampler;uniform float lod;uniform float slice;uniform int gamma;void main(void)\n{ivec3 textureCoordinates=ivec3(vUV*vec2(textureSize(textureSampler,0).xy),int(slice));gl_FragColor=texelFetch(textureSampler,textureCoordinates,int(lod));if (gamma==0) {gl_FragColor.rgb=pow(gl_FragColor.rgb,vec3(GammaEncodePowerApprox));}}\n";
    XO.b.ShadersStore[bK] || (XO.b.ShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);