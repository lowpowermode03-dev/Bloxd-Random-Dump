export const id = 107;
export const ids = [107];
export const modules = {
  37464: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => VO,
      f: () => LO,
      i: () => FO
    });
    var XO = pO(2412);
    const bK = 0,
      eO = 2,
      lO = 3,
      vK = 4;
    class CO {
      constructor(OO, KO) {
        this.width = OO, this.YO = KO, this.data = void 0, this.next = 0, this.size = 0, this.data = new Float64Array(OO * KO)
      }
      push(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = this.data.subarray(this.next * this.width, (this.next + 1) * this.width);
        for (let XO = 0; XO < this.width; XO++) pO[XO] = OO[KO + XO];
        return this.next = (this.next + 1) % this.YO, this.size = Math.min(this.size + 1, this.YO), pO
      }
      lines() {
        const OO = [],
          KO = (this.next - this.size + this.YO) % this.YO;
        for (let pO = 0; pO < this.size; pO++) {
          const XO = (KO + pO) % this.YO * this.width;
          OO.push(Array.from(this.data.subarray(XO, XO + this.width)).join(","))
        }
        return OO
      }
    }

    function hO(OO) {
      return Number.isFinite(OO) ? String(Math.round(10 * OO) / 10) : String(OO)
    }

    function DO(OO) {
      return Number.isFinite(OO) ? OO.toFixed(1) : String(OO)
    }
    class MO {
      constructor() {
        this.frames = 0, this.looked = 0, this.idle = 0, this.TXO = 0, this.pastLimit = 0, this.lockSkips = 0, this.El = 0, this.lost = 0, this.dropped = 0, this.longFrames = 0, this.dtMin = 1 / 0, this.dtMax = 0, this.dtSum = 0, this.raw = [0, 0], this.turned = [0, 0], this.peakRate = 0, this.events = 0, this.eventMax = 0, this.bigEvents = 0, this.outliers = 0, this.eventLines = 0, this.suppressed = 0
      }
    }
    class aK {
      constructor() {
        var OO = this;
        this.tally = new MO, this.records = new CO(10, 3600), this.events = new CO(4, 12e3), this.event = new Float64Array(4), this.take = null, this.client = "js", this.started = !1, this.record = function(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          const [XO, CO, MO, aK, oO, FO, VO, LO, QO, zK] = OO.records.push(KO, pO), AO = OO.tally;
          switch (AO.frames++, VO) {
            case bK:
              return void AO.idle++;
            case vK:
              return void AO.El++;
            case lO:
              return AO.lockSkips++, void(0 === MO && 0 === aK || OO.outlier(`lock skip dropped raw (${hO(MO)}, ${hO(aK)}) at ${DO(XO)} ms`))
          }
          AO.looked++, Number.isFinite(CO) && (AO.dtMin = Math.min(AO.dtMin, CO), AO.dtMax = Math.max(AO.dtMax, CO), AO.dtSum += CO, CO > 0 && (AO.peakRate = Math.max(AO.peakRate, Math.hypot(oO, FO) / CO))), AO.raw[0] += MO, AO.raw[1] += aK, AO.turned[0] += oO, AO.turned[1] += FO;
          const fO = Math.abs(MO) > zK || Math.abs(aK) > zK,
            dO = `raw (${hO(MO)}, ${hO(aK)}) over ${DO(CO)} ms, limit ${hO(zK)}, filter v (${LO.toFixed(3)}, ${QO.toFixed(3)}) px/ms, at ${DO(XO)} ms`;
          VO === eO ? (AO.TXO++, OO.outlier(`spike put right: ${dO} -> turned (${hO(oO)}, ${hO(FO)})`)) : fO ? (AO.pastLimit++, OO.outlier(`kept past limit: ${dO}`)) : CO > 50 && (AO.longFrames++, OO.outlier(`long frame: ${dO}, turned in full`))
        }, this.onMouseMove = OO => {
          const KO = this.tally,
            {
              movementX: pO,
              movementY: XO
            } = OO;
          KO.events++;
          const bK = Math.max(Math.abs(pO), Math.abs(XO));
          KO.eventMax = Math.max(KO.eventMax, bK);
          const eO = null !== document.pointerLockElement,
            lO = this.event;
          lO[0] = OO.timeStamp, lO[1] = pO, lO[2] = XO, lO[3] = eO ? 1 : 0, this.events.push(lO), bK >= 200 && (KO.bigEvents++, this.eventOutlier(`big mousemove (${pO}, ${XO}) at ${DO(OO.timeStamp)} ms, lock ${eO?"JK":"free"}`))
        }, this.onLockChange = () => {
          const OO = document.pointerLockElement;
          (0, XO.i)("look", `pointer lock ${OO?`gained (${OO.tagName.toLowerCase()})`:"lost"} at ${DO(performance.now())} ms`)
        }, this.onLockError = () => {
          (0, XO.i)("look", `pointer lock request failed at ${DO(performance.now())} ms`)
        }, this.onVisibility = () => {
          (0, XO.i)("look", `page ${document.visibilityState} at ${DO(performance.now())} ms`)
        }, this.flush = () => {
          this.takeRecords();
          const OO = this.tally;
          if (this.tally = new MO, 0 === OO.events && 0 === OO.raw[0] && 0 === OO.raw[1] && 0 === OO.lockSkips && 0 === OO.TXO && 0 === OO.dropped) return;
          const KO = OO.looked > 0 ? OO.dtSum / OO.looked : NaN,
            pO = [`${OO.frames} frames (${OO.looked} looked, ${OO.idle} idle${"wasm"===this.client?`, ${OO.El} carried`:""})`, `dt avg ${DO(KO)} min ${DO(OO.dtMin)} max ${DO(OO.dtMax)}, ${OO.longFrames} long`, `${OO.events} mousemoves (max ${hO(OO.eventMax)} px, ${OO.bigEvents} big)`, `raw (${hO(OO.raw[0])}, ${hO(OO.raw[1])}) turned (${hO(OO.turned[0])}, ${hO(OO.turned[1])})`, `peak ${OO.peakRate.toFixed(2)} px/ms`, `put right ${OO.TXO}, past limit ${OO.pastLimit}, lock skips ${OO.lockSkips}`, "lock " + (document.pointerLockElement ? "JK" : "free")];
          OO.dropped > 0 && pO.push(`${OO.dropped} doubled spike copies dropped`), OO.lost > 0 && pO.push(`${OO.lost} records lost`), OO.suppressed > 0 && pO.push(`${OO.suppressed} outlier lines not shown`), (0, XO.i)("look", `1s: ${pO.join("; ")}`)
        }, this.dump = () => [`look records (${this.client}): nowMs,dtMs,rawX,rawY,turnedX,turnedY,outcome,vX,vY,limit`, ...this.records.lines(), "mousemove events: timeStamp,movementX,movementY,locked", ...this.events.lines()].join("\n")
      }
      start(OO, KO) {
        this.client = OO, this.take = KO;
        const {
          screen: pO
        } = window;
        (0, XO.i)("look", `start: ${OO} client, dpr ${window.devicePixelRatio}, screen ${pO.width}x${pO.height}, pointer lock ${document.pointerLockElement?"JK":"free"}`), this.started || (this.started = !0, window.addEventListener("mousemove", this.onMouseMove, {
          capture: !0,
          passive: !0
        }), document.addEventListener("pointerlockchange", this.onLockChange), document.addEventListener("pointerlockerror", this.onLockError), document.addEventListener("visibilitychange", this.onVisibility), setInterval(this.flush, 1e3), (0, XO.f)("look", this.dump))
      }
      outlier(OO) {
        const KO = this.tally;
        KO.outliers >= 20 ? KO.suppressed++ : (KO.outliers++, (0, XO.i)("look", OO))
      }
      eventOutlier(OO) {
        const KO = this.tally;
        KO.eventLines >= 10 ? KO.suppressed++ : (KO.eventLines++, (0, XO.i)("look", OO))
      }
      takeRecords() {
        var OO;
        const KO = null === (OO = this.take) || void 0 === OO ? void 0 : OO.call(this);
        if (KO && KO.length >= 2) {
          this.tally.lost += KO[0], this.tally.dropped += KO[1];
          for (let OO = 2; OO + 10 <= KO.length; OO += 10) this.record(KO, OO)
        }
      }
      droppedCopy() {
        this.tally.dropped++
      }
      endTake() {
        this.takeRecords(), this.take = null
      }
    }
    let oO = null;

    function FO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      return oO ??= new aK, oO.start(OO, KO), oO.record
    }

    function VO() {
      var OO;
      null === (OO = oO) || void 0 === OO || OO.endTake()
    }

    function LO() {
      var OO;
      null === (OO = oO) || void 0 === OO || OO.droppedCopy()
    }
  },
  37427: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK
    });
    var XO = pO(26),
      bK = pO(1136),
      eO = pO(2716);
    const lO = "Reconnecting";
    class vK {
      constructor(OO) {
        this.hooks = OO, this.graceMs = 0, this.sessionBased = !1, this.controller = void 0, this.frozen = !1, this.stopped = !1, this.listening = !1, this.ended = !1, this.retryNow = () => {
          "visible" === document.visibilityState && this.controller.retryNow()
        }, this.onPageHide = OO => {
          OO.persisted || this.DX()
        }, this.controller = new eO.d((KO => OO.reconnect(KO)), {
          isSessionLive: () => !this.ended && OO.isLive(),
          onPhaseChanged: OO => {
            this.onPhaseChanged(OO)
          },
          onReconnected: KO => {
            OO.onReconnected(KO)
          },
          onGaveUp: KO => {
            !this.ended && OO.isLive() && OO.onGaveUp(this.sessionBased, KO)
          }
        })
      }
      onInitialInfo(OO, KO) {
        this.graceMs = OO, this.sessionBased = KO
      }
      canHoldSeat() {
        return this.graceMs > 0 && !this.ended
      }
      isResuming() {
        return "connected" !== this.controller.phase
      }
      onConnectionLost(OO) {
        this.ended || this.controller.onConnectionLost(OO, this.graceMs)
      }
      onResuming() {
        this.ended || this.controller.onResuming()
      }
      onResumed() {
        this.controller.stop()
      }
      DX() {
        const OO = this.isResuming() && !this.controller.awaitingResumeOnRoom,
          KO = this.controller.heldToken;
        this.end(), OO && "" !== KO && this.hooks.releaseSeat(KO)
      }
      end() {
        this.ended = !0, this.controller.stop()
      }
      onPhaseChanged(OO) {
        const KO = "frozen" === OO || "resuming" === OO;
        KO !== this.stopped && (this.stopped = KO, this.hooks.freeze(KO));
        const pO = "frozen" === OO || "resuming" === OO && this.frozen;
        pO && !this.frozen ? (0, bK.k)(lO) : !pO && this.frozen && (0, bK.j)(lO), this.frozen = pO, this.setListening("connected" !== OO), XO.i.pl(eO.n, pO ? "frozen" : OO)
      }
      setListening(OO) {
        OO !== this.listening && (this.listening = OO, OO ? (window.addEventListener("online", this.retryNow), document.addEventListener("visibilitychange", this.retryNow), window.addEventListener("pagehide", this.onPageHide)) : (window.removeEventListener("online", this.retryNow), document.removeEventListener("visibilitychange", this.retryNow), window.removeEventListener("pagehide", this.onPageHide)))
      }
    }
  },
  37435: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO
    });
    class XO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now;
        this.onSilent = OO, this.now = KO, this.lastHeardAt = void 0, this.resumedAt = void 0, this.lastCheckAt = void 0, this.wasVisible = "visible" === document.visibilityState, this.interval = void 0, this.check = () => {
          const OO = this.now(),
            KO = OO - this.lastCheckAt <= 2e3;
          this.lastCheckAt = OO;
          const pO = "visible" === document.visibilityState;
          !pO || KO && this.wasVisible || (this.resumedAt = OO), this.wasVisible = pO, pO && OO - this.lastHeardAt > 12e3 && OO - this.resumedAt > 2e3 && this.onSilent()
        }, this.lastHeardAt = KO(), this.resumedAt = this.lastHeardAt, this.lastCheckAt = this.lastHeardAt, this.interval = setInterval(this.check, 1e3), document.addEventListener("visibilitychange", this.check), window.addEventListener("online", this.check)
      }
      heard() {
        this.lastHeardAt = this.now()
      }
      dispose() {
        clearInterval(this.interval), document.removeEventListener("visibilitychange", this.check), window.removeEventListener("online", this.check)
      }
    }
  },
  5632: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      g: () => bK,
      j: () => lO
    });
    const XO = new WeakMap;

    function bK(OO, KO) {
      OO.signal.aborted || XO.set(OO.signal, KO), OO.abort(KO)
    }

    function eO(OO) {
      var KO;
      const pO = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.reason) && void 0 !== KO ? KO : OO && XO.get(OO);
      if (void 0 !== pO && null !== pO) return pO;
      const bK = new DOMException("signal is aborted without reason", "AbortError");
      return null !== OO && void 0 !== OO && OO.aborted && XO.set(OO, bK), bK
    }

    function lO(OO) {
      if (null !== OO && void 0 !== OO && OO.aborted) throw eO(OO)
    }
  },
  37447: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(5632);

    function bK(OO, KO) {
      return new Promise(((pO, bK) => {
        if (null !== KO && void 0 !== KO && KO.aborted) return void bK((0, XO.c)(KO));
        const eO = () => {
            clearTimeout(lO), bK((0, XO.c)(KO))
          },
          lO = setTimeout((() => {
            null === KO || void 0 === KO || KO.removeEventListener("abort", eO), pO()
          }), OO);
        null === KO || void 0 === KO || KO.addEventListener("abort", eO, {
          once: !0
        })
      }))
    }
  },
  37444: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => hO
    });
    var XO = pO(171),
      bK = pO(37447),
      eO = pO(5632);
    const lO = [250, 500, 1e3, 2e3, 1250],
      vK = 406;

    function CO(OO) {
      if ("object" !== typeof OO || null === OO) return !1;
      const {
        code: KO,
        message: pO
      } = OO, bK = XO.e.duplicateLobbyNameError;
      return (KO === bK.code || KO === vK) && (pO === bK.text || pO === bK.text + XO.n)
    }
    async function hO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : bK.e;
      for (let bK = 0;; bK++) {
        let vK;
        (0, eO.j)(KO);
        try {
          return await OO()
        } catch (XO) {
          if (vK = lO[bK], void 0 === vK || !CO(XO)) throw XO
        }
        await pO(vK, KO)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);