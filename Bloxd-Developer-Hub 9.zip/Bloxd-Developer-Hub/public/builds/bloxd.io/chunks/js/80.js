export const id = 80;
export const ids = [80];
export const modules = {
  3988: (OO, KO, pO) => {
    pO.d(KO, {
      Howl: () => XO.Howl,
      b: () => XO.Howler
    });
    var XO = pO(3992);
    XO.Howler._mobileUnloaded = !0
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);