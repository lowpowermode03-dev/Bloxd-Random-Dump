export const id = 340;
export const ids = [340];
export const modules = {
  59153: (OO, KO, pO) => {
    function XO(OO) {
      return OO.features.has("timestamp-query")
    }

    function bK(OO) {
      return XO(OO) ? {
        device: OO,
        markerPipeline: OO.createComputePipeline({
          layout: "auto",
          compute: {
            module: OO.createShaderModule({
              code: "@compute @workgroup_size(1) fn main() {}"
            }),
            entryPoint: "main"
          }
        }),
        querySet: OO.createQuerySet({
          type: "timestamp",
          count: 2
        }),
        resolveBuf: OO.createBuffer({
          size: 16,
          usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC
        }),
        pool: [],
        lastMs: 0,
        inFlight: 0
      } : null
    }

    function eO(OO, KO) {
      const pO = KO.beginComputePass({
        timestampWrites: {
          querySet: OO.querySet,
          beginningOfPassWriteIndex: 0
        }
      });
      pO.setPipeline(OO.markerPipeline), pO.dispatchWorkgroups(1), pO.end()
    }

    function lO(OO, KO) {
      const pO = KO.beginComputePass({
        timestampWrites: {
          querySet: OO.querySet,
          endOfPassWriteIndex: 1
        }
      });
      pO.setPipeline(OO.markerPipeline), pO.dispatchWorkgroups(1), pO.end()
    }

    function vK(OO) {
      if (OO.inFlight > 3) return;
      const KO = OO.device,
        pO = OO.pool.pop() ?? KO.createBuffer({
          size: 16,
          usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
        }),
        XO = KO.createCommandEncoder();
      XO.resolveQuerySet(OO.querySet, 0, 2, OO.resolveBuf, 0), XO.copyBufferToBuffer(OO.resolveBuf, 0, pO, 0, 16), KO.queue.submit([XO.finish()]), OO.inFlight++, pO.mapAsync(GPUMapMode.READ).then((() => {
        const KO = new BigInt64Array(pO.getMappedRange()),
          XO = Number(KO[1] - KO[0]) / 1e6;
        XO >= 0 && XO < 5e3 && (OO.lastMs = OO.lastMs > 0 ? .8 * OO.lastMs + .2 * XO : XO), pO.unmap(), OO.pool.push(pO), OO.inFlight--
      }), (() => {
        OO.inFlight--
      }))
    }

    function CO(OO) {
      OO.querySet.destroy(), OO.resolveBuf.destroy();
      for (const KO of OO.pool) KO.destroy();
      OO.pool.length = 0
    }
    pO.r(KO), pO.d(KO, {
      createGpuFrameTimer: () => bK,
      destroyGpuFrameTimer: () => CO,
      gpuFrameTimerBegin: () => eO,
      gpuFrameTimerEnd: () => lO,
      gpuFrameTimerResolve: () => vK,
      gpuTimingSupportedFor: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);