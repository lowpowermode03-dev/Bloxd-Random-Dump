export const id = 76;
export const ids = [76];
export const modules = {
  39043: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      if ("undefined" !== typeof OffscreenCanvas) return new OffscreenCanvas(OO, KO).getContext("2d", pO);
      const XO = document.createElement("canvas");
      return XO.width = OO, XO.height = KO, XO.getContext("2d", pO)
    }

    function bK(OO, KO) {
      return OO.getContext("2d", KO)
    }
    pO.d(KO, {
      b: () => bK,
      d: () => XO
    })
  },
  39106: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => CO
    });
    var XO = pO(1492);
    const bK = 33177600,
      eO = 3e4;
    let lO = !1;

    function vK(OO, KO, pO) {
      if (!OO.drawing()) return Promise.reject(new Error("Screenshots need a game to be running"));
      if (lO) return Promise.reject(new Error("A screenshot is already being taken"));
      lO = !0;
      const XO = function(OO, KO, pO) {
        const XO = Math.max(1, OO),
          eO = Math.max(1, KO),
          lO = Math.min(1, pO / Math.max(XO, eO), Math.sqrt(bK / (XO * eO)));
        return {
          width: Math.max(1, Math.floor(XO * lO)),
          height: Math.max(1, Math.floor(eO * lO))
        }
      }(KO, pO, OO.maxTextureSize);
      return OO.resize(XO.width, XO.height), new Promise(((KO, pO) => {
        let XO, bK = 2,
          vK = null;
        const CO = () => {
          var KO;
          lO = !1, null === (KO = vK) || void 0 === KO || KO(), clearTimeout(XO), OO.restoreSize()
        };
        XO = setTimeout((() => {
          CO(), pO(new Error("No frame was drawn to capture"))
        }), eO), vK = OO.onFrameDrawn((() => {
          if (bK--, bK > 0) return;
          const {
            canvas: XO
          } = OO, eO = {
            width: XO.width,
            height: XO.height
          };
          try {
            XO.toBlob((OO => {
              OO ? KO({
                blob: OO,
                ...eO
              }) : pO(new Error("The canvas gave no image"))
            }), "image/png")
          } catch (lO) {
            pO(lO)
          } finally {
            CO()
          }
        }))
      }))
    }
    async function CO(OO, KO, pO) {
      try {
        const bK = await vK(OO, KO, pO);
        (0, XO.d)(bK.blob, `bloxd-screenshot-${bK.width}x${bK.height}-${Date.now()}.png`)
      } catch (bK) {
        console.error("Error taking screenshot:", bK)
      }
    }
  },
  37136: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      e: () => CO,
      g: () => vK,
      h: () => lO
    });
    const XO = "A valid external Instance reference no longer exists.",
      bK = [
        [1e4, "<10s"],
        [6e4, "<1m"],
        [3e5, "<5m"],
        [18e5, "<30m"]
      ];
    const eO = {
      WebGPU: "WebGPU device lost",
      WebGL2: "WebGL2 context lost"
    };

    function lO(OO, KO) {
      return OO ? "frames_refused" : arguments.length > 2 && void 0 !== arguments[2] && arguments[2] ? "browser_destroyed" : function(OO) {
        var KO;
        const pO = null !== (KO = /Device removed reason: (?!S_OK)([A-Z][A-Z0-9_]+)/.exec(OO)) && void 0 !== KO ? KO : /failed with ([A-Z][A-Z0-9_]+)/.exec(OO);
        return pO ? pO[1] : OO.includes(XO) ? "gpu_process_lost" : "other"
      }(KO)
    }

    function vK(OO) {
      return `${(null===OO||void 0===OO?void 0:OO.vendor)||"unknown vendor"} ${(null===OO||void 0===OO?void 0:OO.architecture)||"unknown architecture"}`
    }

    function CO(OO) {
      var KO;
      const pO = bK.find((KO => {
        let [pO] = KO;
        return OO < pO
      }));
      return null !== (KO = null === pO || void 0 === pO ? void 0 : pO[1]) && void 0 !== KO ? KO : "30m+"
    }
  },
  37516: (OO, KO, pO) => {
    function XO(OO, KO) {
      const pO = OO || 4;
      return pO <= 6 ? 1 : pO <= 8 || KO ? 2 : 3
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  37598: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    const XO = "Traffic checks failed! Please use Chrome, disable extensions and refresh your page. Report on Discord if this persists."
  },
  38798: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => WO,
      C: () => mK,
      D: () => jK,
      G: () => PO,
      I: () => EO,
      K: () => ZO,
      N: () => BO,
      P: () => wO,
      b: () => GO,
      c: () => HO,
      d: () => gK,
      h: () => qK,
      l: () => uO,
      n: () => yK,
      q: () => sO,
      s: () => YO,
      w: () => rK,
      x: () => iK
    });
    var XO = pO(1225),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(1964),
      vK = pO(3962),
      CO = pO(3923);
    let hO, DO = !1,
      MO = !1,
      aK = !1,
      oO = !1;
    const FO = 1300,
      VO = 3e3;
    let LO = 0,
      QO = !1,
      zK = !1,
      AO = 0;
    const fO = 2;
    let dO = !1,
      TO = !1;
    const NO = new Set,
      IO = new Set;

    function yK() {
      return DO
    }

    function gK() {
      return zK
    }

    function uO() {
      return TO
    }

    function EO() {
      return (0, eO.l)() && !TO
    }

    function jK(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      if (OO !== TO) {
        TO = OO;
        for (const OO of [...IO]) OO(TO);
        KO && BO()
      }
    }

    function YO(OO) {
      return IO.add(OO), () => {
        IO.delete(OO)
      }
    }

    function wO() {
      (0, vK.j)(lO.u.Menu, (0, eO.l)() ? 0 : lO.u.Menu)
    }

    function iK() {
      zK = !1, AO = 0, wO(), BO()
    }

    function rK(OO) {
      return NO.add(OO), () => {
        NO.delete(OO)
      }
    }

    function PO(OO) {
      MO = !1, OO !== DO && (DO = OO, oO = !1, clearTimeout(hO), aK = !DO && dO, DO ? (QO = !1, zK = !1, AO = 0) : EO() && !dO && (zK = !0), dO = !1, DO && !EO() && nO(), tK(), aK && BO())
    }

    function mK(OO) {
      OO !== QO && (QO = OO, OO || BO())
    }

    function sO() {
      MO = !1, oO || !0 !== JO() || (oO = !0, clearTimeout(hO), hO = setTimeout(RO, FO))
    }

    function HO() {
      return (!MO || performance.now() - LO > VO) && (MO = (0, CO.F)().lockPointer(), LO = performance.now()), MO
    }

    function RO() {
      SO() && cK() && HO()
    }

    function SO() {
      return EO() && !DO && !QO && !(0, XO.h)()
    }

    function JO() {
      var OO;
      return "undefined" === typeof navigator || null === (OO = navigator.userActivation) || void 0 === OO ? void 0 : OO.isActive
    }

    function cK() {
      return aK && (!navigator.userAgent.includes("Firefox/") || Boolean(document.fullscreenElement)) || !1 !== JO()
    }

    function BO() {
      EO() ? SO() && !zK && cK() && HO() : DO && !dO && nO()
    }

    function ZO() {
      zK ? navigator.vendor.startsWith("Apple") ? xK() : AO = fO : BO()
    }

    function GO() {
      AO > 0 && 0 === --AO && xK()
    }

    function qK() {
      AO = 0
    }

    function xK() {
      SO() && !0 === JO() && HO()
    }

    function nO() {
      dO = !0, (0, CO.F)().unlockPointer()
    }

    function WO() {
      MO = !1, aK = !1, oO = !1, clearTimeout(hO), QO = !1, zK = !1, AO = 0, dO = !1;
      const OO = DO;
      DO = !1, OO && tK()
    }

    function tK() {
      for (const OO of [...NO]) OO(DO);
      bK.i.pl("pointerLockUpdate", DO)
    }
  },
  38769: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => aK,
      e: () => vK,
      f: () => MO,
      h: () => hO,
      l: () => lO,
      o: () => DO,
      q: () => CO
    });
    let XO = null,
      bK = null,
      eO = null;

    function lO(OO) {
      XO = OO
    }

    function vK() {
      return XO
    }

    function CO(OO) {
      bK = OO
    }

    function hO() {
      return bK
    }

    function DO(OO) {
      eO = OO
    }

    function MO() {
      return eO
    }

    function aK() {
      var OO, KO;
      return !0 === (null === (OO = bK) || void 0 === OO || null === (KO = OO.currentViewer) || void 0 === KO ? void 0 : KO.inPlayback)
    }
  },
  38968: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    const XO = {
      stop: () => XO,
      fade: () => XO,
      rate: () => XO,
      getVolume: () => 0,
      getRelativeVolume: () => 0,
      setRelativeVolume: () => XO,
      setPannerAttr: () => XO,
      setPosition: () => XO
    }
  },
  38941: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      h: () => bK,
      k: () => eO
    });
    const XO = 1024,
      bK = 1024 * XO;

    function eO(OO) {
      return (OO / bK).toFixed(1)
    }
  },
  38805: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      h: () => eO,
      k: () => vK
    });
    let XO = null,
      bK = null;

    function eO(OO, KO) {
      return XO = OO, bK = null, vK(KO), () => {
        XO === OO && (XO = null, bK = null)
      }
    }

    function lO() {
      return null === bK ? null : {
        ...bK
      }
    }

    function vK(OO) {
      var KO;
      null !== (KO = XO) && void 0 !== KO && KO(OO) && (bK = {
        ...OO
      })
    }
  },
  38939: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => vK,
      g: () => lO,
      k: () => CO,
      o: () => hO
    });
    var XO = pO(171);
    const bK = 32 * pO(38941).h,
      eO = 6144,
      lO = 4608,
      vK = 512;

    function CO(OO) {
      return Math.floor(bK * OO / eO)
    }

    function hO(OO) {
      const KO = OO - Math.floor(OO / 6);
      let pO = XO.h.maxChunkHorizAddDistance,
        bK = XO.h.maxChunkVertAddDistance;
      if (DO(pO + 1, bK + 1) <= KO) return null;
      for (; DO(pO + 1, bK + 1) > KO && (pO > 0 || bK > 0);) pO > bK ? pO-- : bK--;
      return {
        horizontal: pO,
        vertical: bK
      }
    }

    function DO(OO, KO) {
      const pO = Math.max(OO, KO);
      let XO = 0;
      for (let bK = -pO; bK <= pO; bK++)
        for (let eO = -pO; eO <= pO; eO++)
          for (let lO = -pO; lO <= pO; lO++) MO(OO, KO, bK, eO, lO) && XO++;
      return XO
    }

    function MO(OO, KO, pO, XO, bK) {
      const eO = pO * pO + bK * bK;
      return OO === KO ? eO + XO * XO <= OO * OO : OO > KO ? Math.abs(XO) <= KO && eO + XO * XO <= OO * OO : eO <= OO * OO && eO + XO * XO <= KO * KO
    }
  },
  38908: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      e: () => eO,
      g: () => vK,
      k: () => DO,
      o: () => CO,
      s: () => lO
    });
    var XO = pO(171);
    const bK = 3e3,
      eO = 15e3;

    function lO(OO) {
      const KO = OO.endsWith(XO.n);
      return {
        text: (KO ? OO.slice(0, -XO.n.length) : OO) || null,
        dropsCache: KO
      }
    }
    const vK = "Either your internet isn't working or this is a bug.";

    function CO(OO, KO) {
      const pO = DO(OO);
      return null !== pO.name && "" === XO.e[pO.name].text && null !== KO ? KO : pO.reason
    }
    const hO = "You were removed from the game.";

    function DO(OO) {
      var KO;
      let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      const bK = null !== (KO = Object.keys(XO.e).find((KO => XO.e[KO].code === OO))) && void 0 !== KO ? KO : null;
      if (null === bK) return {
        code: OO,
        name: bK,
        reason: null !== pO && void 0 !== pO ? pO : `${vK}\nCode: ${OO}`,
        canReconnect: !1,
        automaticallyReconnect: !1,
        requiresRefresh: !1
      };
      const {
        text: eO,
        canReconnect: lO = !1
      } = XO.e[bK], CO = OO === XO.e.outdatedVersion.code || OO === XO.e.loadRecaptchaError.code;
      return {
        code: OO,
        name: bK,
        reason: "" !== eO ? eO : null !== pO && void 0 !== pO ? pO : OO === XO.e.gameOrPluginKick.code ? hO : `Code: ${OO}`,
        canReconnect: lO,
        automaticallyReconnect: OO === XO.e.customGameUpdated.code || OO === XO.e.duplicateLobbyNameError.code,
        requiresRefresh: CO
      }
    }
  },
  38976: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => AO,
      h: () => FO,
      l: () => ZO,
      n: () => uO,
      p: () => jK,
      r: () => YO,
      u: () => zK,
      v: () => LO,
      z: () => QO,
      A: () => gK,
      B: () => SO,
      F: () => TO,
      J: () => mK,
      M: () => BO,
      N: () => wO,
      Q: () => rK
    });
    var XO = pO(3934),
      bK = pO(38732),
      eO = pO(9);
    class lO {
      constructor(OO, KO) {
        this.memory = OO, this.access = KO, this.cursor = 0, this.dropped = 0, this.buffer = null, this.ptr = 0, this.YO = 0, this.u32 = new eO.h(0), this.f32 = new eO.c(0), this.u8 = new eO.b(0), this.dataView = new eO.d(new ArrayBuffer(0)), this.refresh()
      }
      refresh() {
        this.ptr = this.access.ptr(), this.YO = this.access.YO(), this.buffer = (0, eO.B)(this.memory()), this.u32 = new eO.h(this.buffer, this.ptr, this.YO >>> 2), this.f32 = new eO.c(this.buffer, this.ptr, this.YO >>> 2), this.u8 = new eO.b(this.buffer, this.ptr, this.YO), this.dataView = new eO.d(this.buffer, this.ptr, this.YO)
      }
      ensureViews() {
        (0, eO.B)(this.memory()) !== this.buffer && this.refresh()
      }
      get view() {
        return this.ensureViews(), this.dataView
      }
      room(OO) {
        return !!this.fits(OO) || (this.dropped++, !1)
      }
      fits(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.cursor;
        this.ensureViews();
        const pO = KO + OO;
        return pO <= this.YO || pO <= XO.Fc && 0 !== this.access.reserve(pO) && (this.refresh(), pO <= this.YO)
      }
      consume(OO) {
        const KO = this.cursor - OO;
        KO > 0 && OO > 0 && (this.ensureViews(), this.u8.copyWithin(0, OO, this.cursor)), this.cursor = KO > 0 ? KO : 0
      }
      writeRecord(OO, KO, pO, bK, eO) {
        if (!this.room(XO.vb)) return !1;
        const lO = this.cursor >>> 2;
        return this.u32[lO] = 65535 & OO | (65535 & KO) << 16, this.f32[lO + 1] = pO, this.f32[lO + 2] = bK, this.u32[lO + 3] = eO >>> 0, this.cursor += XO.vb, !0
      }
      writeOptions(OO, KO) {
        const pO = KO.byteLength,
          bK = XO.vb + (0, XO.ne)(pO);
        if (!this.fits(bK)) return !1;
        const eO = this.cursor,
          lO = eO >>> 2;
        this.u32[lO] = XO.zb.Options, this.u32[lO + 1] = pO, this.u32[lO + 2] = 0, this.u32[lO + 3] = OO >>> 0;
        const vK = eO + XO.vb;
        return this.u8.set(KO, vK), this.u8.fill(0, vK + pO, eO + bK), this.cursor += bK, !0
      }
      writeWorkerRecord(OO, KO, pO, bK, eO) {
        const lO = eO.byteLength,
          vK = XO.Ad + (0, XO.ne)(lO);
        if (lO > XO.yd) return this.dropped++, !1;
        if (!this.room(vK)) return !1;
        const CO = this.cursor,
          hO = CO >>> 2;
        this.u32[hO] = OO >>> 0, this.u32[hO + 1] = 65535 & KO | (65535 & pO) << 16, this.u32[hO + 2] = bK >>> 0, this.u32[hO + 3] = lO;
        const DO = CO + XO.Ad;
        return this.u8.set(eO, DO), this.u8.fill(0, DO + lO, CO + vK), this.cursor += vK, !0
      }
      written() {
        return this.ensureViews(), this.u8.subarray(0, this.cursor)
      }
      writeFrame(OO, KO) {
        return this.writeNet(XO.Sb.Frame, OO, KO)
      }
      writeOpen(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this.writeNet(XO.Sb.Open, OO, CO(KO))
      }
      writeClose(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return this.writeNet(XO.Sb.Close, OO, CO(KO))
      }
      writeNet(OO, KO, pO) {
        const bK = pO.byteLength,
          eO = XO.Qb + (0, XO.ne)(bK);
        if (bK > XO.Lb) return this.dropped++, !1;
        if (!this.room(eO)) return !1;
        const lO = this.cursor;
        this.u32[lO >>> 2] = bK, this.u32[1 + (lO >>> 2)] = (0, XO.ie)(OO, KO);
        const vK = lO + XO.Qb;
        return this.u8.set(pO, vK), this.u8.fill(0, vK + bK, lO + eO), this.cursor += eO, !0
      }
      Ip(OO, KO, pO) {
        const bK = XO.x + (0, XO.ne)(pO);
        if (!this.room(bK)) return -1;
        const eO = this.cursor;
        this.u32[eO >>> 2] = 65535 & OO | (65535 & KO) << 16, this.u32[1 + (eO >>> 2)] = pO;
        const lO = eO + XO.x;
        return this.u8.fill(0, lO, eO + bK), this.cursor += bK, lO
      }
      growForCmd(OO) {
        return this.fits(XO.x + (0, XO.ne)(OO), 0)
      }
      writeCmd(OO, KO, pO) {
        const XO = this.Ip(OO, KO, pO.byteLength);
        return !(XO < 0) && (this.u8.set(pO, XO), !0)
      }
      copyWritten(OO, KO) {
        return this.ensureViews(), this.u8.slice(OO, OO + KO)
      }
    }
    const vK = new eO.b(0);

    function CO(OO) {
      if (0 === OO) return vK;
      const KO = new eO.b(XO.Mb);
      for (let pO = 0; pO < XO.Mb; pO++) KO[pO] = OO >>> 8 * pO & 255;
      return KO
    }
    class hO {
      constructor(OO, KO) {
        this.input = void 0, this.net = void 0, this.worker = void 0, this.cmd = void 0, this.input = new lO(KO, {
          ptr: () => OO.ZO(),
          YO: () => OO.uaO(),
          reserve: KO => OO.RaO(KO)
        }), this.net = new lO(KO, {
          ptr: () => OO.moO(),
          YO: () => OO.PaO(),
          reserve: KO => OO.SaO(KO)
        }), this.worker = new lO(KO, {
          ptr: () => OO.VoO(),
          YO: () => OO.ooO(),
          reserve: KO => OO.JaO(KO)
        }), this.cmd = new lO(KO, {
          ptr: () => OO.QaO(),
          YO: () => OO.VaO(),
          reserve: KO => OO.LaO(KO)
        })
      }
      reset(OO) {
        this.input.cursor = 0, this.worker.cursor = 0, this.cmd.consume(OO)
      }
    }
    var DO = pO(38871),
      MO = pO(1969),
      aK = pO(3929),
      oO = pO(38979);
    const FO = "coreFrame",
      VO = "fatalStatus",
      LO = "otherCall",
      QO = "coreRings",
      zK = "netIn",
      AO = "abi",
      fO = "netOut",
      dO = "workerOut",
      TO = "worldgenHost",
      NO = "eventWalker",
      IO = "netEvent",
      yK = "envEvent",
      gK = "sharedTables",
      uO = "inputAction",
      EO = new Set([NO, IO, yK, uO, gK]),
      jK = "wasmMemory",
      YO = "meshHost";

    function wO(OO, KO) {
      OO.forEachWorkerOut(((pO, bK, eO) => {
        if ((0, XO.be)(pO)) try {
          var lO;
          null === (lO = KO.worldgen) || void 0 === lO || lO.take(pO, eO)
        } catch (CO) {
          OO.crash(TO, CO)
        } else try {
          var vK;
          null === (vK = KO.mesh) || void 0 === vK || vK.take(pO, bK, eO)
        } catch (CO) {
          OO.crash(YO, CO)
        }
      }))
    }
    const iK = 1048576;

    function rK(OO, KO) {
      let pO = !1;
      const XO = () => {
        pO = !1, KO()
      };
      return () => {
        !pO && OO.cursor >= iK && (pO = !0, queueMicrotask(XO))
      }
    }
    const PO = new Set([VO, LO, TO, YO]);

    function mK(OO) {
      return EO.has(OO.site) ? OO.error instanceof WebAssembly.RuntimeError || (0, bK.m)(OO.error) : !PO.has(OO.site) && OO.error instanceof Error
    }
    const sO = "events",
      HO = [],
      RO = "dXO",
      SO = "terrainTextures",
      JO = "sunShadowTextures",
      cK = new TextDecoder;

    function BO(OO, KO) {
      const {
        site: pO,
        error: bK,
        header: eO
      } = OO, lO = eO ? (0, XO.Yd)(eO.lastError) : "noFrame", vK = `CORE-${pO===VO?lO:pO}`, CO = null === bK || void 0 === bK ? "" : ` ${(0,DO.d)(bK)}`, hO = {
        site: pO,
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return eO && (hO.status = String(eO.status), hO.lastError = lO, hO.lastErrorCode = String(eO.lastError), hO.lastErrorDetail = String(eO.lastErrorDetail), hO.errorCount = String(eO.errorCount), hO.frameIndex = String(eO.frameIndex), hO.tickIndex = String(eO.tickIndex)), {
        code: vK,
        message: `core ${pO}, last error ${lO};${CO}`,
        details: hO
      }
    }
    class ZO {
      constructor(OO, KO, pO) {
        this.core = OO, this.memory = KO, this.handlers = pO, this.rings = void 0, this.lastHeader = null, this.lastFrameKind = "none", this.stopped = !1, this.netKept = 0, this.keptFrames = 0, this.headerBuffer = null, this.header = new Uint32Array(0), this.unsentUiPrefs = null, this.eventWalker = null, this.netOffsets = [], this.frameEvents = {
          ptr: 0,
          len: 0,
          net: HO,
          netOffsets: this.netOffsets,
          kind: "none"
        }, this.unsentEnvPrefs = null, this.unsentLookPrefs = null, this.envEvents = [], this.graceEvents = [], this.unsentOptions = [], this.optionsDropped = 0, this.drawsHeld = !1, this.gameHost = null, this.rings = new hO(OO, KO)
      }
      get netKeptFrames() {
        return this.keptFrames
      }
      get netWrittenSinceFrame() {
        return this.rings.net.cursor - this.netKept
      }
      hasPendingCommands() {
        return this.rings.cmd.cursor > 0
      }
      framePaces(OO) {
        if (this.stopped || this.drawsHeld) return !1;
        try {
          return this.core.IaO(OO)
        } catch (KO) {
          return this.crash(FO, KO), !1
        }
      }
      get isStopped() {
        return this.stopped
      }
      frame(OO, KO) {
        var pO;
        let eO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (this.stopped) return !1;
        if (!this.writePendingInput()) return !1;
        const {
          input: lO,
          net: vK,
          worker: CO,
          cmd: hO
        } = this.rings, DO = vK.cursor, MO = KO && !this.drawsHeld;
        let LO = XO.K.Fatal;
        const QO = hO.cursor;
        let AO = null;
        try {
          const KO = (MO ? XO.cb.Draws : 0) | (eO ? XO.cb.NetAll : 0);
          LO = (0, oO.g)((() => this.core.frame(OO, lO.cursor, vK.cursor, CO.cursor, KO, QO)))
        } catch (rK) {
          AO = {
            error: rK
          }
        }
        const fO = null === (pO = this.gameHost) || void 0 === pO ? void 0 : pO.takeFault();
        this.rings.reset(this.stopped || null !== AO || void 0 !== fO ? hO.cursor : QO);
        const dO = null === AO && void 0 === fO ? this.headerView() : null,
          TO = null === dO ? null : (0, XO.pe)(dO);
        null !== TO && (this.lastHeader = TO);
        const yK = null !== TO && LO !== XO.K.Fatal,
          gK = yK && null !== dO ? dO[XO.nb.NetInKept] : 0,
          uO = yK && gK <= DO && gK % 4 === 0 ? gK : null;
        var EO, jK;
        null !== TO && null !== uO && LO === XO.K.Errors && (null === (EO = (jK = this.handlers).onErrors) || void 0 === EO || EO.call(jK, TO));
        const YO = null === uO ? HO : this.readEvents(DO);
        if (vK.consume(DO - (null !== uO && void 0 !== uO ? uO : 0)), this.netKept = null !== uO && void 0 !== uO ? uO : 0, this.keptFrames = this.netKept > 0 ? this.keptFrames + 1 : 0, null !== AO) return this.crash(FO, void 0 === fO || fO instanceof bK.e ? AO.error : fO), !1;
        if (void 0 !== fO || null === TO) return this.crashOn(FO, fO), !1;
        if (this.lastFrameKind = (0, aK.e)(MO, this.headerView()[XO.nb.FrameDraw]), LO === XO.K.Fatal) return this.crash(VO, null), !1;
        if (null === uO) return this.crash(zK, `the core kept ${gK} of ${DO} net-in bytes`), !1;
        if (this.eventWalker) {
          if (this.stopped) return !1;
          const OO = this.frameEvents,
            KO = this.headerView();
          OO.ptr = KO[XO.nb.EventsPtr], OO.len = KO[XO.nb.EventsLen], OO.net = YO, OO.kind = this.lastFrameKind;
          try {
            this.eventWalker(OO)
          } catch (rK) {
            return this.crashOn(NO, rK), !1
          }
          return this.handEnvEvents()
        }
        for (const XO of YO) {
          if (this.stopped) return !1;
          try {
            var wO, iK;
            null === (wO = (iK = this.handlers).onNetEvent) || void 0 === wO || wO.call(iK, XO)
          } catch (rK) {
            return this.crashOn(IO, rK), !1
          }
        }
        return this.handEnvEvents()
      }
      handEnvEvents() {
        for (const eO of this.graceEvents) {
          if (this.stopped) return !1;
          try {
            var OO, KO;
            null === (OO = (KO = this.handlers).onReconnectGrace) || void 0 === OO || OO.call(KO, eO)
          } catch (bK) {
            return this.crashOn(IO, bK), !1
          }
        }
        for (const eO of this.envEvents) {
          if (this.stopped) return !1;
          try {
            var pO, XO;
            null === (pO = (XO = this.handlers).onEnvEvent) || void 0 === pO || pO.call(XO, eO)
          } catch (bK) {
            return this.crashOn(yK, bK), !1
          }
        }
        return !this.stopped
      }
      setEventWalker(OO) {
        this.eventWalker = OO
      }
      writePendingInput() {
        if (this.stopped) return !1;
        const {
          input: OO
        } = this.rings;
        try {
          const KO = this.unsentUiPrefs;
          KO && OO.writeRecord(XO.zb.UiPrefs, 0, KO.nametagCutDistance, 0, (0, XO.re)(KO)) && (this.unsentUiPrefs = null);
          const pO = this.unsentEnvPrefs;
          pO && OO.writeRecord(XO.zb.EnvPrefs, (0, XO._d)(pO), pO.fogChunks, 0, 0) && (this.unsentEnvPrefs = null);
          const bK = this.unsentLookPrefs;
          bK && OO.writeRecord(XO.zb.Sensitivity, 0, bK.mouse, bK.touch, (0, MO.i)(bK.fovPercent)) && (this.unsentLookPrefs = null);
          let eO = 0;
          for (const {
              aux: XO,
              payload: lO
            }
            of this.unsentOptions) {
            if (!OO.writeOptions(XO, lO)) {
              if (OO.cursor > 0) break;
              this.optionsDropped++
            }
            eO++
          }
          eO > 0 && this.unsentOptions.splice(0, eO)
        } catch (KO) {
          return this.crash(QO, KO), !1
        }
        return !0
      }
      setHoldDraws(OO) {
        this.drawsHeld = OO
      }
      setUiPrefs(OO) {
        this.unsentUiPrefs = {
          ...OO
        }
      }
      setEnvPrefs(OO) {
        this.unsentEnvPrefs = {
          ...OO
        }
      }
      setLookPrefs(OO) {
        this.unsentLookPrefs = {
          ...OO
        }
      }
      queueOptions(OO, KO) {
        KO.byteLength > XO.Wb.PayloadMaxBytes ? this.optionsDropped++ : this.unsentOptions.push({
          aux: OO,
          payload: KO
        })
      }
      setChunkCap(OO) {
        return this.callCore("setChunkCap", null, (KO => KO.WaO(OO)))
      }
      shedMemory(OO) {
        const KO = this.callCore("shedMemory", null, (KO => KO.eoO(OO)));
        return 0 === KO ? null : KO
      }
      addDistanceInUse() {
        const OO = this.callCore("addDistanceInUse", null, (OO => OO.haO()));
        return 0 === OO ? null : OO
      }
      setChunkAddDistance(OO, KO) {
        return this.callCore("setChunkAddDistance", !1, (pO => pO.naO(OO, KO)))
      }
      setGameHost(OO) {
        return this.callCore("setGameHost", !1, (KO => (KO.NaO(OO), this.gameHost = OO, !0)))
      }
      setAntiCheatProbes(OO) {
        return this.callCore("setAntiCheatProbes", !1, (KO => KO.ZaO(OO)))
      }
      setAmbientOcclusion(OO) {
        this.callCore("setAmbientOcclusion", void 0, (KO => {
          KO.BaO(OO)
        }))
      }
      setPoseLod(OO) {
        this.callCore("setPoseLod", void 0, (KO => {
          KO.UaO(OO)
        }))
      }
      setLookDebug(OO) {
        this.callCore(RO, void 0, (KO => {
          KO.koO(OO)
        }))
      }
      takeLookDebug() {
        return this.callCore(RO, [], (OO => OO.hoO()))
      }
      setTextureLayers(OO) {
        return this.callCore("setTextureLayers", !1, (KO => KO.bFO(OO)))
      }
      setBlockColours(OO) {
        let {
          blocks: KO,
          counts: pO,
          values: XO
        } = OO;
        return this.callCore("setBlockColours", !1, (OO => OO.qoO(KO, pO, XO)))
      }
      terrainTextureNames() {
        return this.callCore(SO, [], (OO => OO.aFO()))
      }
      setTerrainTextures(OO, KO, pO) {
        return this.callCore(SO, !1, (XO => XO.XoO(OO, pO, KO)))
      }
      setShaderPack(OO, KO, pO, XO, bK, eO) {
        return this.callCore("setShaderPack", !1, (lO => {
          var vK, CO;
          return null !== (vK = null === (CO = lO.GDO) || void 0 === CO ? void 0 : CO.call(lO, OO, KO, pO, XO, bK, eO)) && void 0 !== vK && vK
        }))
      }
      sunShadowWantedTextures() {
        return this.callCore(JO, null, (OO => {
          var KO, pO;
          return null !== (KO = null === (pO = OO.vFO) || void 0 === pO ? void 0 : pO.call(OO)) && void 0 !== KO ? KO : null
        }))
      }
      setSunShadowTexture(OO, KO, pO, XO, bK) {
        this.callCore(JO, void 0, (eO => {
          var lO;
          null === (lO = eO.poO) || void 0 === lO || lO.call(eO, OO, KO, pO, XO, bK)
        }))
      }
      takeSunShadowWarnings() {
        return this.callCore(JO, [], (OO => {
          var KO, pO;
          return null !== (KO = null === (pO = OO.DoO) || void 0 === pO ? void 0 : pO.call(OO)) && void 0 !== KO ? KO : []
        }))
      }
      callCore(OO, KO, pO) {
        if (this.stopped) return KO;
        try {
          return pO(this.core)
        } catch (XO) {
          return this.crash(OO, XO), KO
        }
      }
      readEvents(OO) {
        this.netOffsets.length = 0;
        const KO = this.headerView(),
          pO = KO[XO.nb.EventsPtr],
          bK = KO[XO.nb.EventsLen];
        if (this.envEvents.length = 0, this.graceEvents.length = 0, 0 === bK) return HO;
        const eO = [],
          lO = this.memory().buffer;
        if (pO % 4 !== 0 || pO + bK > lO.byteLength) return this.crash(sO, `events of ${bK} bytes at ${pO} outside ${lO.byteLength} bytes of memory`), HO;
        const vK = new DataView(lO, pO, bK),
          CO = this.rings.net,
          hO = (KO, pO) => KO + pO <= OO ? CO.copyWritten(KO, pO) : null;
        let DO = 0;
        for (; DO < bK;) {
          const OO = DO + XO.R,
            KO = OO <= bK ? vK.getUint32(DO, !0) : -1,
            CO = KO >>> 16;
          if (KO < 0 || CO > bK - OO) return this.crash(sO, `event record at ${DO} overruns its ${bK} bytes`), HO;
          const yK = 65535 & KO,
            gK = KO => vK.getUint32(OO + 4 * KO, !0);
          if (yK === XO.V.RawMessage) {
            const OO = CO >= XO.Gc.BYTES ? 65535 & gK(1) : -1,
              KO = OO === XO.Gc.STRING_TYPE,
              pO = CO === (KO ? XO.Gc.STRING_TYPE_BYTES : XO.Gc.BYTES) ? hO(gK(2), gK(3)) : null,
              bK = KO && pO ? hO(gK(4), gK(5)) : null;
            if (!pO || KO && !bK) return this.crash(sO, `RawMessage at ${DO} of ${CO} bytes names bytes outside net-in`), HO;
            this.netOffsets.push(DO), eO.push({
              type: "message",
              conn: gK(0),
              Tl: OO,
              payloadKind: gK(1) >>> 16,
              payload: pO,
              stringType: bK ? cK.decode(bK) : null
            })
          } else if (yK === XO.V.CoreErrors) {
            var MO, aK;
            const OO = CO >= 4 ? gK(0) : -1;
            if (OO < 0 || OO > XO.H.PAIRS_MAX || CO !== 4 * (XO.H.FIXED_WORDS + XO.H.PAIR_WORDS * OO)) return this.crash(sO, `CoreErrors at ${DO} of ${CO} bytes`), HO;
            const KO = [];
            for (let pO = 0; pO < OO; pO++) KO.push({
              code: gK(1 + 2 * pO),
              detail: gK(2 + 2 * pO)
            });
            null === (MO = (aK = this.handlers).onCoreErrors) || void 0 === MO || MO.call(aK, KO, gK(1 + 2 * OO))
          } else if (yK === XO.V.RenderReload) {
            var oO, FO;
            if (CO !== XO.Oc.BYTES) return this.crash(sO, `RenderReload at ${DO} of ${CO} bytes`), HO;
            null === (oO = (FO = this.handlers).onRenderReload) || void 0 === oO || oO.call(FO, gK(0), gK(1))
          } else if (yK === XO.V.Images) {
            var VO, LO;
            null === (VO = (LO = this.handlers).onImages) || void 0 === VO || VO.call(LO, new Uint8Array(lO.slice(pO + OO, pO + OO + CO)))
          } else if (yK === XO.V.ModelRequests)
            for (let pO = 0; pO < CO >>> 2; pO++) {
              var QO, zK;
              null === (QO = (zK = this.handlers).onModelRequest) || void 0 === QO || QO.call(zK, gK(pO))
            } else if (yK === XO.V.ModelTaken) {
              var AO, fO;
              if (CO < 4) return this.crash(sO, `ModelTaken at ${DO} of ${CO} bytes`), HO;
              const OO = new Uint32Array((CO >>> 2) - 1);
              for (let KO = 0; KO < OO.length; KO++) OO[KO] = gK(1 + KO);
              null === (AO = (fO = this.handlers).onModelTaken) || void 0 === AO || AO.call(fO, gK(0), OO)
            } else if (yK === XO.V.TerrainTexturesWanted) {
            var dO, TO;
            if (0 !== CO) return this.crash(sO, `TerrainTexturesWanted at ${DO} of ${CO} bytes`), HO;
            null === (dO = (TO = this.handlers).onTerrainTexturesWanted) || void 0 === dO || dO.call(TO)
          } else if (yK === XO.V.KeepAliveDue) {
            var NO, IO;
            if (CO > XO.Db) return this.crash(sO, `KeepAliveDue at ${DO} of ${CO} bytes`), HO;
            null === (NO = (IO = this.handlers).onKeepAlive) || void 0 === NO || NO.call(IO, new Uint8Array(lO, pO + OO, CO).slice())
          } else if (yK === XO.V.ConnectionState) {
            if (CO !== XO.z) return this.crash(sO, `ConnectionState at ${DO} of ${CO} bytes`), HO;
            this.netOffsets.push(DO), eO.push({
              type: "connection",
              conn: gK(0),
              phase: gK(1),
              code: 0 | gK(2)
            })
          } else if (yK === XO.V.EnvLighting || yK === XO.V.SkyImages) {
            if (CO !== (yK === XO.V.EnvLighting ? XO.O : XO.jd)) return this.crash(sO, `event ${yK} at ${DO} of ${CO} bytes`), HO;
            this.envEvents.push({
              kind: yK,
              payload: new Uint8Array(lO.slice(pO + OO, pO + OO + CO))
            })
          } else if (yK === XO.V.ReconnectGrace) {
            if (CO !== XO.ic) return this.crash(sO, `ReconnectGrace at ${DO} of ${CO} bytes`), HO;
            const OO = gK(2);
            this.graceEvents.push({
              conn: gK(0),
              graceMs: gK(1),
              sessionBased: 0 !== (OO & XO.Ic.SessionBased),
              replayOffer: 0 !== (OO & XO.Ic.ReplayOffer)
            })
          }
          DO = OO + (0, XO.ne)(CO)
        }
        return eO
      }
      forEachNetOut(OO) {
        this.forEachOut(fO, "net-out", XO.nb.NetOutPtr, XO.nb.NetOutLen, XO.Qb, 0, ((KO, pO, bK, eO) => {
          const lO = (0, XO.ge)(pO);
          lO === XO.Sb.Frame ? OO((0, XO.fe)(pO), bK) : this.crash(fO, `net-out record at ${eO} is kind ${lO}, not a frame`)
        }))
      }
      forEachWorkerOut(OO) {
        this.forEachOut(dO, "worker-out", XO.nb.WorkerOutPtr, XO.nb.WorkerOutLen, XO.wd, 4, ((KO, pO, bK, eO) => {
          const lO = 255 & KO,
            vK = lO === XO.Nd.Init ? this.initOf(bK, eO) : bK;
          null !== vK && OO(lO, KO >>> 8 & 16777215, vK)
        }))
      }
      initOf(OO, KO) {
        const pO = this.memory().buffer;
        if (OO.byteLength !== XO.rb) return this.crash(dO, `worker-out Init record at ${KO} is ${OO.byteLength} bytes, not a view`), null;
        const bK = new DataView(OO.buffer, OO.byteOffset, XO.rb),
          eO = bK.getUint32(0, !0),
          lO = bK.getUint32(4, !0);
        return eO + lO > pO.byteLength ? (this.crash(dO, `worker-out Init record at ${KO} names ${lO} bytes at ${eO} outside ${pO.byteLength} bytes of memory`), null) : new Uint8Array(pO, eO, lO)
      }
      forEachOut(OO, KO, pO, bK, eO, lO, vK) {
        if (this.stopped || null === this.lastHeader) return;
        const CO = this.headerView(),
          hO = CO[pO],
          DO = CO[bK];
        if (0 === DO) return;
        const MO = this.memory().buffer;
        if (hO % 4 !== 0 || hO + DO > MO.byteLength) return void this.crash(OO, `${KO} of ${DO} bytes at ${hO} outside ${MO.byteLength} bytes of memory`);
        const aK = new DataView(MO, hO, DO);
        let oO = 0;
        for (; oO < DO;) {
          const pO = oO + eO,
            bK = pO <= DO ? aK.getUint32(oO + lO, !0) : -1;
          if (bK < 0 || bK > DO - pO) return void this.crash(OO, `${KO} record at ${oO} overruns its ${DO} bytes`);
          if (vK(aK.getUint32(oO, !0), aK.getUint32(oO + 4, !0), new Uint8Array(MO, hO + pO, bK), oO), this.stopped) return;
          oO = pO + (0, XO.ne)(bK)
        }
      }
      forEachEvent(OO) {
        if (this.stopped || null === this.lastHeader) return;
        const KO = this.headerView(),
          pO = KO[XO.nb.EventsPtr],
          bK = KO[XO.nb.EventsLen];
        if (0 === bK) return;
        const eO = this.memory().buffer;
        if (pO % 4 !== 0 || pO + bK > eO.byteLength) return void this.crash(sO, `events of ${bK} bytes at ${pO} outside ${eO.byteLength} bytes of memory`);
        const lO = new DataView(eO, pO, bK);
        let vK = 0;
        for (; vK < bK;) {
          const KO = vK + XO.R,
            pO = KO <= bK ? lO.getUint32(vK, !0) : -1,
            eO = pO >>> 16;
          if (pO < 0 || eO > bK - KO) return void this.crash(sO, `event record at ${vK} overruns its ${bK} bytes`);
          OO(65535 & pO, lO, KO, eO), vK = KO + (0, XO.ne)(eO)
        }
      }
      crashOn(OO, KO) {
        KO instanceof bK.e ? this.crash(sO, KO.message) : this.crash(OO, KO)
      }
      crash(OO, KO) {
        this.stopped || (this.stopped = !0, this.handlers.onCrash({
          site: OO,
          error: KO,
          header: this.lastHeader
        }))
      }
      headerWord(OO) {
        return this.stopped || null === this.lastHeader ? 0 : this.headerView()[OO]
      }
      headerView() {
        const OO = this.memory().buffer;
        return OO !== this.headerBuffer && (this.headerBuffer = OO, this.header = new Uint32Array(OO, this.core.yX(), XO.jb)), this.header
      }
    }
  },
  39047: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    const XO = {
      destroy_stage_0: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAK0lEQVQYlWP8//8/IwMewIRPknQFjIyM/wmaYGdn9w9FE7IjYSagiFHsCwCM7A/Ccc+NjAAAAABJRU5ErkJggg==",
      destroy_stage_1: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAQklEQVQYlYWPMQ4AIAgDOeO7+v9XWScMOGinpjmgYJt4aKQB/ASqKtwASeuGZxrbAEhyRJxe1JJ1debtRIZt6PfmBqYNG36KBWHbAAAAAElFTkSuQmCC",
      destroy_stage_2: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAARUlEQVQYlYWPwQnAMAwDdaVr2ftPVfWVIBJC9DI6LMvYRpIAjzn1rMaq9wQAbwnd/SWUJNkmb1eVkx07zPK5PaLTu37xA3+wH3UI6vmHAAAAAElFTkSuQmCC",
      destroy_stage_3: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAASUlEQVQYlW2PwQ3AMAjEfFXXYv+x3A+pSNqT+IBPMlEDkEQ6awdwMaJGzYTfVJUL4GydUFW5AbM5j2o+DrMEcE+g5dKzf/FrDjw47TfQdOS/BAAAAABJRU5ErkJggg==",
      destroy_stage_4: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAATklEQVQYlYWPsRHDQAzDQF/W4u8/lZEmn5PtwuwkETwqagCSyE97B3AwpEbNNH8A1lpn2wvwN824tqpp6yN2G+dRzaPDhLgPm56peXvzC7EqSTSAXQcxAAAAAElFTkSuQmCC",
      destroy_stage_5: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAATElEQVQYlW2PwREAMQgCIX1p/1Xd3idmNBN/iotowJJkG+2q2WkARwRD2LUkKTO/m44I7mWVyxDrxIsEvCqg7ZOhAyNx0d3Vrzc7+AM+lEvjLYgPSwAAAABJRU5ErkJggg==",
      destroy_stage_6: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAT0lEQVQYlW2PyQ2AQAwDx9tXtv+qGD4ERQt+RY7lI2oAksiD5gBWH1WlGjUtTuIC2HtfHHi5qvJ0mRxt27nzqWZ1VhJnuU/Js8u77m/mFNyVEDqzHRw/iwAAAABJRU5ErkJggg==",
      destroy_stage_7: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAJklEQVQYlWNgQAK2trb/GXABXJIsuCThYsiSMDZBq7AqoEw3Pp0AAAYX+aJ4oVQAAAAASUVORK5CYII=",
      destroy_stage_8: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAUUlEQVQYlV2PwQ3AMAwCoepazvDJXr1+apWEl40BYQHWh6pCAcACDLiq6DlFtySNMZ4kt6RcOiW5LdI2eZxzXmpBurPLVqjda60/Ob84uwB+AVXlTrnZ3+XVAAAAAElFTkSuQmCC",
      destroy_stage_9: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAUElEQVQYlW2OyQ3AMAgEhyhtQfF2X9m8IKvIvBDMHkgKSQGQmcJGUtBAZsr3hm6Aqnr4zUBOt4vfJh8gIuTPtdZFK1ztXUbtcXvvz/nU3F1eyBpW2eqlL9QAAAAASUVORK5CYII="
    }
  },
  39010: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      f: () => VO,
      g: () => aK,
      j: () => MO
    });
    const XO = 2e3,
      bK = "unavailable";
    let eO = () => Promise.resolve().then((() => pO(2519))),
      lO = null,
      vK = null,
      CO = hO();

    function hO() {
      let OO = () => {};
      return {
        promise: new Promise((KO => {
          OO = () => {
            KO(null)
          }
        })),
        resolve: OO
      }
    }

    function DO() {
      if (null === lO) {
        const OO = eO();
        lO = OO, OO.then((KO => {
          lO === OO && (vK = KO)
        }), (() => {
          lO === OO && (lO = null)
        }))
      }
      return lO
    }

    function MO() {
      DO().catch((() => {}))
    }

    function aK() {
      CO.resolve()
    }

    function oO(OO, KO, pO, XO) {
      if (null === OO) return {
        errorKind: KO,
        fingerprint: bK,
        dedupe: `${KO}|${XO}`
      };
      const {
        fingerprint: eO
      } = OO.clientErrorKey(KO, pO, XO);
      return {
        errorKind: KO,
        fingerprint: eO,
        dedupe: eO
      }
    }

    function FO(OO, KO, pO, XO) {
      return null === vK ? XO ? (MO(), oO(null, OO, KO, pO)) : null : oO(vK, OO, KO, pO)
    }
    async function VO(OO, KO, pO) {
      let bK;
      const eO = new Promise((OO => {
        bK = setTimeout((() => {
          OO(null)
        }), XO)
      }));
      try {
        return oO(await Promise.race([DO(), eO, CO.promise]), OO, KO, pO)
      } catch {
        return oO(null, OO, KO, pO)
      } finally {
        clearTimeout(bK)
      }
    }
  },
  39002: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BUILT_IN_ANIMATIONS_SITE: () => OK,
      CORE_ERRORS_SITE: () => BO,
      EVENT_OVERFLOW_SITE: () => UO,
      JOIN_SITE: () => GO,
      LEAVE_SITE: () => qK,
      MODEL_FEED_SITE: () => xK,
      MODEL_POOL_SITE: () => nO,
      NON_FATAL_LOKI_REPORTS_PER_PAGE: () => XK,
      NON_FATAL_REPORTS_PER_SESSION: () => zp,
      PREVIEW_ANIMATIONS_SITE: () => kK,
      RENDER_RELOAD_SITE: () => tK,
      TEXTURE_NAMES_SITE: () => WO,
      TEXTURE_PACK_FEED_SITE: () => KK,
      TurnstilePageError: () => GK,
      WASM_LOAD_SITE: () => ZO,
      crashError: () => NK,
      crashReportsSettled: () => jp,
      flushCrashReports: () => uK,
      joinFailureCode: () => qp,
      lokiTransport: () => lK,
      modelFailureCode: () => Op,
      readTrap: () => ip,
      renderLossDetail: () => Fp,
      reportCoreErrors: () => wK,
      reportCountedLoadFallback: () => BK,
      reportCrash: () => IK,
      reportDataLoadFailure: () => zX,
      reportDisconnect: () => kp,
      reportDracoDecoderFailure: () => Xp,
      reportEventOverflow: () => lp,
      reportGpuFallback: () => cp,
      reportMemoryShed: () => hp,
      reportModelFailure: () => Kp,
      reportModelPoolFailure: () => pp,
      reportPageJoinFailure: () => nK,
      reportReconnectGaveUp: () => UK,
      reportRenderReload: () => Vp,
      reportReplayFault: () => Mp,
      reportStaleBuildReload: () => fp,
      reportStoppedCore: () => sK,
      reportTerrainTextureFailure: () => Lp,
      reportTexturePackFeedLoadFailure: () => ep,
      reportUnstreamedCoreLoad: () => ZK,
      reportUnsupportedFallback: () => SK,
      reportUnusedSeat: () => tp,
      reportWorkerLost: () => vX,
      reportWorkerStartTimeout: () => Dp,
      reportWorldgenGaveUp: () => Cp,
      reportWorldgenLoadFailure: () => bX,
      resetCrashReports: () => YK,
      setCrashBackend: () => oK,
      setCrashScreen: () => MK,
      setCrashTransport: () => hK,
      showCrash: () => mp,
      showJoinFailure: () => xp,
      showUnsupported: () => RK
    });
    var XO = pO(951),
      bK = pO(2526),
      eO = pO(39010),
      lO = pO(3934),
      vK = pO(3943);
    const CO = {
        1: "link",
        2: "draw",
        3: "draw base vertex",
        4: "draw no index buffer",
        7: "draw missing block",
        8: "draw small binding",
        9: "draw missing texture",
        10: "draw no texture storage",
        11: "draw missing sampler",
        12: "draw missing vertex buffer",
        13: "draw short constant",
        15: "draw no zero buffer"
      },
      hO = {
        1: "renderer",
        2: "sky",
        3: "meshes",
        4: "terrain"
      },
      DO = {
        0: "transform",
        1: "object",
        2: "instance batch",
        3: "material",
        4: "terrain part",
        5: "particle system",
        6: "geometry",
        7: "texture",
        9: "shader pack",
        10: "text plane",
        11: "object chunk"
      },
      MO = {
        1: "mesh undecodable",
        2: "part refused",
        3: "terrain ids full",
        4: "unknown terrain id",
        5: "buffer failed"
      };

    function aK(OO) {
      return String(OO).replace(/\d/g, (OO => String.fromCharCode(97 + Number(OO))))
    }

    function oO(OO, KO) {
      var pO;
      return null !== (pO = OO[KO]) && void 0 !== pO ? pO : aK(KO)
    }

    function FO(OO, KO) {
      switch (OO) {
        case vK.f.RenderSceneRowNotDrawn:
          return {
            words: ` ${oO(DO,KO)}`, instance: String(KO), group: String(OO)
          };
        case vK.f.RenderChunkMeshNotDrawn: {
          const pO = 0 === (128 & KO) ? "" : " shortage",
            XO = KO >>> 8;
          return {
            words: ` ${oO(MO,127&KO)}${pO}${0===XO?"":` kind ${aK(XO)}`}`,
            instance: String(KO),
            group: String(OO)
          }
        }
        case vK.f.RenderInternal: {
          const pO = oO(hO, 255 & KO),
            XO = KO >>> 8 & 255;
          if (0 === XO) return {
            words: ` ${pO}`,
            instance: String(KO),
            group: String(OO)
          };
          const bK = oO(CO, XO),
            eO = KO >>> 16;
          return {
            words: ` ${pO} ${bK} program ${aK(eO)}`,
            instance: `${pO} ${bK}`,
            group: "program",
            program: {
              programFailure: bK,
              program: String(eO)
            }
          }
        }
        default:
          return null
      }
    }
    const VO = 2,
      LO = new Map;

    function QO(OO) {
      let {
        group: KO,
        instance: pO
      } = OO, XO = LO.get(KO);
      return void 0 === XO && (XO = [], LO.set(KO, XO)), !XO.includes(pO) && (XO.length >= VO || (XO.push(pO), !1))
    }
    var zK = pO(2716),
      AO = pO(37136),
      fO = pO(2718),
      dO = pO(2373),
      TO = pO(38976),
      NO = pO(38674),
      IO = pO(38917),
      yK = pO(2085),
      gK = pO(38908),
      uO = pO(38950);
    const EO = "seat reservation expired.",
      jK = "early_leave";

    function YO(OO) {
      if (OO instanceof IO.o) return OO.networkLost ? "expected" : "unrecognised";
      if (OO instanceof IO.b) {
        if ("closed" === OO.stage && (0 === OO.code || (0, fO.g)(OO.code))) return "expected";
        if ("roomError" === OO.stage && (OO.serverText === EO || OO.serverText === jK)) return "expected"
      }
      return OO instanceof IO.b || OO instanceof IO.h ? null === (0, gK.k)(OO.code).name ? "unrecognised" : "known" : (0, yK.d)(OO) ? "expected" : OO instanceof IO.s || OO instanceof uO.b ? "known" : "unrecognised"
    }
    var wO = pO(39017),
      iK = pO(2947),
      rK = pO(2951),
      PO = pO(39020),
      mK = pO(39035),
      sO = pO(39050),
      HO = pO(2528),
      RO = pO(38973),
      SO = pO(38867),
      JO = pO(38871);
    const cK = "[bloxd-wasm-client]",
      BO = "coreErrors",
      ZO = "wasmLoad",
      GO = "join",
      qK = "DX",
      xK = "modelFeed",
      nO = "modelWorkerPool",
      WO = "textureNames",
      tK = "renderReload",
      kK = "previewAnimations",
      UO = "eventOverflow",
      OK = "builtInAnimations",
      KK = "texturePackFeed",
      pK = 300,
      XK = 8;
    let bp = 0;
    const eK = new Set,
      lK = (OO, KO) => {
        const pO = FK[OO.kind];
        if (null === pO) return void vp(OO, KO, ap, null);
        const XO = (0, eO.b)(pO, OO.message, OO.code, OO.fatal);
        if (null !== XO) return void vp(OO, KO, ap, XO);
        const bK = ap;
        gp("Loki", (async () => {
          vp(OO, KO, bK, await (0, eO.f)(pO, OO.message, OO.code))
        }))
      };

    function vp(OO, KO, pO, eO) {
      const {
        kind: lO,
        code: vK,
        site: CO,
        fatal: hO,
        details: DO
      } = OO;
      if (!hO)
        if (null === eO || (0, bK.d)(eO.errorKind) || eK.has(eO.dedupe)) {
          if (bp >= XK) return;
          bp++
        } else eK.add(eO.dedupe);
      const MO = {
        ...DO,
        kind: lO,
        code: vK,
        site: CO,
        fatal: String(hO),
        backend: pO
      };
      null !== eO && (MO.errorKind = eO.errorKind, MO.fingerprint = eO.fingerprint), KO instanceof Error && "string" === typeof KO.stack && (MO.causeStack = KO.stack.slice(0, 2e3)), (0, XO.Zb)(NK(OO, KO), MO)
    }
    let CK = lK;

    function hK(OO) {
      const KO = CK;
      return CK = OO, KO
    }
    let DK = () => {};

    function MK(OO) {
      const KO = DK;
      return DK = OO, KO
    }
    let ap = "unpicked";

    function oK(OO) {
      ap = OO
    }
    const FK = {
        crash: "wasm_load",
        unsupported: "wasm_load",
        model: "wasm_load",
        join: "matchmake_failed",
        pageJoin: null,
        unsupportedFallback: null,
        gpuFallback: null,
        coreError: null,
        meshHeap: null,
        recovered: null,
        unstreamedLoad: null,
        modelLate: null,
        worldgenLoad: null,
        texturePackLoad: null,
        terrainTexture: null,
        previewAnimations: null,
        builtInAnimations: null,
        seat: null,
        staleBuild: "wasm_load",
        disconnect: "disconnect"
      },
      VK = {
        coreError: "wasm_load",
        recovered: "wasm_load",
        unstreamedLoad: "wasm_load",
        gpuFallback: "wasm_load"
      },
      LK = new Set(["unstreamedLoad"]);
    let QK = !1;
    const zp = 20,
      AK = new Map;
    let fK = 0,
      dK = 0;
    const TK = new Set;

    function NK(OO, KO) {
      const pO = Object.assign(new Error(`${OO.code}: ${OO.message}`), {
        name: "WasmClientCrash",
        cause: null !== KO && void 0 !== KO ? KO : void 0
      });
      return KO instanceof Error && KO.stack && (pO.stack = KO.stack), pO
    }

    function IK(OO) {
      var KO, XO;
      const {
        kind: bK,
        code: eO,
        site: lO,
        fatal: vK,
        message: CO,
        error: hO
      } = OO, DO = !1 !== OO.toTransport && !LK.has(bK), MO = !vK && DO, aK = {
        kind: bK,
        code: eO,
        site: lO,
        fatal: vK,
        message: CO,
        details: null !== (KO = OO.details) && void 0 !== KO ? KO : {}
      }, oO = `${eO}@${lO}${void 0===OO.instance?"":`#${OO.instance}`}${vK?"!":""}`, FO = (null !== (XO = AK.get(oO)) && void 0 !== XO ? XO : 0) + 1;
      if (AK.set(oO, FO), FO > 1 ? 0 === (FO & FO - 1) && yp((() => {
          console.warn(`${cK} ${eO} at ${lO} reported ${FO} times`)
        })) : MO && fK >= zp ? yp((() => {
          console.warn(`${cK} ${bK} ${eO} at ${lO}: ${CO} (not sent: the session's ${zp} went)`, aK.details, null !== hO && void 0 !== hO ? hO : "")
        })) : (MO && fK++, function(OO, KO, XO) {
          var bK, eO;
          const {
            kind: lO,
            code: vK,
            site: CO,
            fatal: hO,
            message: DO,
            details: MO
          } = OO;
          yp((() => {
            (hO ? console.error : console.warn)(`${cK} ${lO} ${vK} at ${CO}: ${DO}`, MO, null !== KO && void 0 !== KO ? KO : "")
          }));
          const aK = VK[lO],
            oO = null !== (bK = null !== (eO = FK[lO]) && void 0 !== eO ? eO : aK) && void 0 !== bK ? bK : null;
          null !== oO && gp("counts", (async () => {
            const {
              peekVisitSessionId: OO
            } = await Promise.resolve().then((() => pO(959)));
            if (null !== OO()) {
              const {
                reportCappedWasmFailure: OO,
                reportWasmFailure: KO
              } = await pO.e(192).then((() => pO(34879)));
              (void 0 === aK ? KO : OO)(oO, DO, vK), QK = !0
            }
          }));
          XO && yp((() => {
            CK(OO, KO)
          }))
        }(aK, hO, DO)), vK) {
        var VO;
        const KO = null !== (VO = OO.screen) && void 0 !== VO ? VO : {
          text: (0, sO.d)(aK, !0),
          reload: !0
        };
        yp((() => {
          DK(KO)
        }))
      }
      return aK
    }

    function yp(OO) {
      try {
        OO()
      } catch (KO) {
        try {
          console.warn(`${cK} could not send a report`, KO)
        } catch {}
      }
    }

    function gp(OO, KO) {
      try {
        const pO = KO().catch((KO => {
          console.warn(`${cK} could not send the report to ${OO}`, KO)
        })).finally((() => {
          TK.delete(pO)
        }));
        TK.add(pO)
      } catch (pO) {
        console.warn(`${cK} could not send the report to ${OO}`, pO)
      }
    }
    async function uK(OO) {
      let KO;
      (0, eO.g)();
      const pO = new Promise((pO => {
        KO = setTimeout(pO, OO)
      }));
      await Promise.race([EK(), pO]), clearTimeout(KO)
    }
    async function EK() {
      if (await Promise.allSettled([...TK]), QK) try {
        const {
          flushClientAnalyticsEvents: OO
        } = await Promise.resolve().then((() => pO(1326)));
        await OO()
      } catch (OO) {
        console.warn(`${cK} could not send the counts`, OO)
      }
    }
    async function jp() {
      for (; TK.size > 0;) await Promise.allSettled([...TK])
    }

    function YK() {
      AK.clear(), fK = 0, QK = !1, bp = 0, eK.clear(), dK = 0, LO.clear()
    }

    function wK(OO, KO, pO, XO) {
      dK += KO;
      for (const {
          code: vK,
          detail: CO
        }
        of OO) {
        var bK, eO;
        const OO = (0, lO.Yd)(vK),
          KO = FO(vK, CO),
          hO = Array.from(null !== (bK = null === XO || void 0 === XO ? void 0 : XO(vK, CO)) && void 0 !== bK ? bK : "").slice(0, pK).join(""),
          DO = `core error ${OO}${null!==(eO=null===KO||void 0===KO?void 0:KO.words)&&void 0!==eO?eO:""}${hO?`: ${hO}`:""}`,
          MO = {
            errorCode: String(vK),
            detail: String(CO),
            droppedBefore: String(dK),
            wasmBuild: pO.wasm,
            clientVersion: pO.client,
            ...null === KO || void 0 === KO ? void 0 : KO.program
          };
        null !== KO && QO(KO) ? yp((() => {
          console.warn(`${cK} coreError CORE-${OO}: ${DO} (not sent: the session's render warnings of its kind went)`, MO)
        })) : IK({
          kind: vK === lO.I.JobsHeapGaveUp ? "meshHeap" : "coreError",
          code: `CORE-${OO}`,
          site: BO,
          fatal: !1,
          message: DO,
          details: MO,
          instance: null === KO || void 0 === KO ? void 0 : KO.instance
        })
      }
    }

    function ip(OO) {
      return (0, RO.n)(OO instanceof SO.b ? OO.trap : OO, iK.I, iK.ab)
    }
    const rp = "declined=js";

    function PK(OO) {
      return OO ? {
        labels: [rp],
        details: {
          declined: "js"
        }
      } : {
        labels: [],
        details: {}
      }
    }

    function mp(OO, KO, pO) {
      return HK(OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, !0)
    }

    function sK(OO, KO, pO) {
      return HK(OO, KO, pO, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, !1)
    }

    function HK(OO, KO, pO, XO, bK) {
      let {
        memoryDetails: eO = {},
        declined: lO = !1
      } = XO;
      const {
        code: vK,
        details: CO,
        message: hO
      } = (0, TO.M)(OO, KO), DO = [];
      null !== pO && (CO.trapKind = pO.kind, null !== pO.panic && (CO.panic = (0, RO.j)(pO.panic)), pO.refusedBytes > 0 && (CO.refusedAllocation = String(pO.refusedBytes)), DO.push((0, RO.q)(pO.kind, pO.refusedBytes)));
      const MO = PK(lO);
      return IK({
        kind: "crash",
        code: vK,
        site: OO.site,
        fatal: bK,
        message: [...DO, ...MO.labels, hO].join("; "),
        details: {
          ...CO,
          ...MO.details,
          ...eO
        },
        error: OO.error
      })
    }

    function RK(OO, KO, pO) {
      return IK({
        kind: "unsupported",
        code: KO,
        site: ZO,
        fatal: !0,
        message: pO,
        details: {
          ...arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
          cause: OO,
          status: KO
        },
        screen: {
          text: (0, sO.j)(OO),
          reload: "download" === OO
        }
      })
    }

    function SK(OO, KO) {
      return IK({
        kind: "unsupportedFallback",
        code: "unsupported",
        site: ZO,
        fatal: !1,
        message: KO,
        details: {
          ...arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
          cause: OO,
          status: "unsupported",
          fallback: "js"
        }
      })
    }
    const JK = "misdrawn_gpu_js_fallback";

    function cp(OO) {
      return IK({
        kind: "gpuFallback",
        code: JK,
        site: ZO,
        fatal: !1,
        message: `the renderer misdraws ${OO}`,
        details: {
          gpuFamily: OO,
          fallback: "js"
        }
      })
    }

    function BK(OO, KO, pO, XO) {
      const bK = PK(XO);
      return IK({
        kind: "unsupported",
        code: KO,
        site: ZO,
        fatal: !1,
        message: [...bK.labels, pO].join("; "),
        details: {
          cause: OO,
          status: KO,
          fallback: "js",
          ...bK.details
        }
      })
    }

    function ZK() {
      const {
        code: OO,
        message: KO
      } = HO.c;
      return IK({
        kind: "unstreamedLoad",
        code: OO,
        site: ZO,
        fatal: !1,
        message: KO
      })
    }
    class GK extends Error {
      constructor() {
        super("the shell's page can't run the Turnstile check: join from /play"), this.name = "TurnstilePageError"
      }
    }

    function qp(OO) {
      return OO instanceof IO.h ? 0 === OO.code ? "JOIN-matchmake" : `JOIN-${OO.code}` : OO instanceof IO.b ? 0 === OO.code ? `JOIN-${OO.stage}` : `JOIN-${OO.stage}-${OO.code}` : OO instanceof NO.c ? "JOIN-gameCode" : OO instanceof GK ? "JOIN-turnstilePage" : OO instanceof IO.s ? "JOIN-trafficCheck" : "JOIN-network"
    }

    function xp(OO, KO) {
      const pO = (0, JO.d)(OO),
        XO = {
          wasmBuild: KO.wasm,
          clientVersion: KO.client
        },
        bK = OO instanceof GK ? {
          text: (0, sO.f)(),
          reload: !1
        } : void 0,
        eO = YO(OO),
        lO = "expected" !== eO;
      return IK({
        kind: "join",
        code: qp(OO),
        site: GO,
        fatal: !0,
        message: pO,
        details: XO,
        error: OO,
        screen: bK,
        toTransport: lO,
        instance: eO
      })
    }

    function nK(OO, KO, pO) {
      var XO;
      const bK = YO(OO),
        eO = {
          cause: (OO instanceof IO.b || OO instanceof IO.h) && null !== (XO = OO.serverText) && void 0 !== XO ? XO : "",
          sinceJoinStart: (0, fO.e)(pO.sinceJoinStartMs),
          game: pO.game,
          ...(0, fO.m)(),
          wasmBuild: KO.wasm,
          clientVersion: KO.client
        };
      return IK({
        kind: "pageJoin",
        code: qp(OO),
        site: GO,
        fatal: !1,
        message: (0, JO.d)(OO),
        details: eO,
        error: OO,
        toTransport: "unrecognised" === bK,
        instance: bK
      })
    }
    const WK = {
      renewed: {
        code: "CORE-seatRenewed",
        message: "the early seat outlasted the room's hold, so the join reserved another"
      },
      lost: {
        code: "CORE-seatAbandoned",
        message: "the early seat's request failed before the join, so the join reserved another"
      },
      rematched: {
        code: "CORE-seatAbandoned",
        message: "the early seat was for a place matchmaking replaced"
      },
      abandoned: {
        code: "CORE-seatAbandoned",
        message: "the early seat was abandoned by a leave or a failed boot or join"
      }
    };

    function tp(OO, KO) {
      let {
        unused: pO,
        answered: XO,
        heldMs: bK
      } = OO;
      const {
        code: eO,
        message: lO
      } = WK[pO], vK = {
        unused: pO,
        answered: String(XO),
        heldMs: String(bK),
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "seat",
        code: eO,
        site: GO,
        fatal: !1,
        message: lO,
        details: vK
      })
    }

    function kp(OO, KO, pO) {
      var XO;
      let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null !== (XO = OO.name) && void 0 !== XO ? XO : String(OO.code);
      const eO = {
          closeCode: String(OO.code),
          recognised: String(null !== OO.name),
          closeReason: pO.closeReason,
          sinceJoined: (0, fO.e)(pO.sinceJoinedMs),
          game: pO.game,
          ...(0, fO.m)(),
          wasmBuild: KO.wasm,
          clientVersion: KO.client
        },
        lO = null === OO.name && !(0, fO.g)(OO.code);
      return IK({
        kind: "disconnect",
        code: bK,
        site: qK,
        fatal: !1,
        message: "Left room",
        details: eO,
        toTransport: lO
      })
    }

    function UK(OO, KO) {
      const pO = {
        ...(0, zK.j)(OO),
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "disconnect",
        code: `reconnect-${OO.reason}`,
        site: GO,
        fatal: !1,
        message: "Reconnect failed",
        details: pO
      })
    }

    function Op(OO) {
      return OO.error instanceof rK.h ? `MODEL-${OO.error.status}` : OO.error instanceof PO.i ? "MODEL-ring" : "MODEL-network"
    }

    function Kp(OO, KO) {
      const pO = Op(OO),
        XO = `model file ${OO.file} ${OO.startup?"(startup) ":""}could not load`,
        bK = {
          file: String(OO.file),
          url: OO.url,
          wasmBuild: KO.wasm,
          clientVersion: KO.client
        };
      return IK({
        kind: OO.startup ? "model" : "modelLate",
        code: pO,
        site: xK,
        fatal: OO.startup,
        message: XO,
        details: bK,
        error: OO.error
      })
    }

    function pp(OO, KO) {
      const pO = {
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "model",
        code: "CORE-modelWorkerPool",
        site: nO,
        fatal: !1,
        message: "the model workers could not start: no model can build",
        details: pO,
        error: OO
      })
    }

    function Xp(OO, KO) {
      const pO = {
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "recovered",
        code: "CORE-dracoDecoder",
        site: nO,
        fatal: !1,
        message: "the Draco decoder did not load: the Draco files waiting on it failed",
        details: pO,
        error: OO
      })
    }

    function bX(OO, KO) {
      const pO = {
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "worldgenLoad",
        code: "CORE-worldgenLoad",
        site: TO.F,
        fatal: !1,
        message: "world-gen worker code could not load",
        details: pO,
        error: OO
      })
    }

    function ep(OO, KO) {
      const pO = {
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "texturePackLoad",
        code: "CORE-texturePackLoad",
        site: KK,
        fatal: !1,
        message: "texture pack feed code could not load",
        details: pO,
        error: OO
      })
    }

    function lp(OO, KO) {
      const {
        frames: pO,
        acks: XO,
        mask: bK,
        outcome: eO
      } = OO, lO = {
        frames: String(pO),
        acks: String(XO),
        mask: String(bK),
        outcome: null !== eO && void 0 !== eO ? eO : "resynced",
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "recovered",
        code: "rejoined" === eO ? "CORE-eventOverflowRejoin" : "failed" === eO ? "CORE-eventOverflowFailed" : "CORE-eventOverflow",
        site: UO,
        fatal: !1,
        message: `the event buffer refused records in ${pO} frames`,
        details: lO
      })
    }

    function vX(OO, KO, pO) {
      return IK({
        kind: "recovered",
        code: "CORE-workerLost",
        site: OO,
        fatal: !1,
        message: `a ${OO} worker was lost`,
        details: {
          reason: KO,
          wasmBuild: pO.wasm,
          clientVersion: pO.client
        }
      })
    }

    function Cp(OO, KO) {
      const pO = {
        lastReason: OO,
        wasmBuild: KO.wasm,
        clientVersion: KO.client
      };
      return IK({
        kind: "recovered",
        code: "CORE-worldgenGaveUp",
        site: TO.F,
        fatal: !1,
        message: "no world-gen worker generated: chunks come whole",
        details: pO
      })
    }

    function hp(OO, KO, pO) {
      return IK({
        kind: "recovered",
        code: "CORE-memoryShed",
        site: TO.p,
        fatal: !1,
        message: (0, wO.j)(OO) ? "wasm memory was refused: the session shed load" : "the tab's footprint reached its budget: the session shed load",
        details: {
          cause: OO,
          ...KO,
          wasmBuild: pO.wasm,
          clientVersion: pO.client
        }
      })
    }

    function Dp(OO, KO, pO) {
      return IK({
        kind: "recovered",
        code: "CORE-workerStartTimeout",
        site: OO,
        fatal: !1,
        message: `a ${OO} worker did not start`,
        details: {
          waitedMs: String(Math.round(KO)),
          wasmBuild: pO.wasm,
          clientVersion: pO.client
        }
      })
    }

    function Mp(OO, KO, pO) {
      return IK({
        kind: "recovered",
        code: "CORE-replayFault",
        site: OO,
        fatal: !1,
        message: `the replay's ${OO} failed`,
        details: {
          wasmBuild: pO.wasm,
          clientVersion: pO.client
        },
        error: KO
      })
    }
    const aX = {
        lost: "render device was lost",
        frames_refused: "render device refused a frame",
        start_failed: "renderer couldn't start"
      },
      op = {
        adapter: null,
        boundAtMs: null
      };

    function Fp(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : performance.now();
      const bK = null === KO || void 0 === KO ? void 0 : KO.message,
        eO = KO instanceof dO.b ? "timeout" : (0, AO.h)("frames_refused" === OO, "string" === typeof bK ? bK : ""),
        lO = null === pO.boundAtMs ? "unbound" : `up${(0,AO.e)(XO-pO.boundAtMs)}`,
        vK = null === pO.adapter ? "no adapter" : (0, AO.g)(pO.adapter);
      return `${eO} ${(0,dO.c)()?"hidden":"visible"} ${lO} ${vK}`
    }

    function Vp(OO, KO, XO) {
      let {
        cause: bK = "lost",
        error: eO,
        context: lO = op
      } = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      const vK = Fp(bK, eO, lO),
        CO = {
          losses: String(KO),
          cause: bK,
          detail: vK,
          wasmBuild: XO.wasm,
          clientVersion: XO.client
        },
        hO = `the ${OO} ${aX[bK]}`,
        DO = IK({
          kind: "recovered",
          code: "CORE-renderLost",
          site: tK,
          fatal: !1,
          message: hO,
          details: CO,
          error: eO
        });
      return gp("ga", (async () => {
        const {
          logError: KO
        } = await Promise.resolve().then((() => pO(2302))), XO = `${AO.d["webgpu"===OO?"WebGPU":"WebGL2"]}\n Error: ${vK}`;
        KO("warning", XO), KO("error", XO)
      })), DO
    }

    function Lp(OO, KO) {
      var pO, XO;
      const bK = null === OO.name ? "TEXTURE-sources" : null === OO.url ? "TEXTURE-nourl" : OO.error instanceof mK.b ? `TEXTURE-${OO.error.status}` : "TEXTURE-network",
        eO = null === OO.name ? "terrain textures could not load" : `terrain texture ${OO.name} could not load`,
        lO = {
          texture: null !== (pO = OO.name) && void 0 !== pO ? pO : "",
          url: null !== (XO = OO.url) && void 0 !== XO ? XO : "",
          wasmBuild: KO.wasm,
          clientVersion: KO.client
        };
      return IK({
        kind: "terrainTexture",
        code: bK,
        site: TO.B,
        fatal: !1,
        message: eO,
        details: lO,
        error: OO.error
      })
    }
    const Qp = {
      previewAnimations: {
        site: kK,
        prefix: "ANIMS",
        name: "the previews' animations"
      },
      builtInAnimations: {
        site: OK,
        prefix: "BUILTIN",
        name: "the built-in animations"
      }
    };

    function zX(OO, KO, pO, XO) {
      const {
        site: bK,
        prefix: eO,
        name: lO
      } = Qp[OO], {
        stage: vK,
        error: CO
      } = pO;
      return IK({
        kind: OO,
        code: "decode" === vK ? null === CO ? `${eO}-decode` : `${eO}-trap` : CO instanceof rK.h ? `${eO}-${CO.status}` : `${eO}-network`,
        site: bK,
        fatal: !1,
        message: "decode" === vK ? `${lO} did not decode` : `${lO} could not load`,
        details: {
          url: KO,
          wasmBuild: XO.wasm,
          clientVersion: XO.client
        },
        error: CO
      })
    }
    const Ap = "staleBuild";

    function fp(OO, KO, pO) {
      const XO = {
          failedSite: OO.site,
          url: OO.url,
          from: OO.from,
          sameBuild: String(OO.from === KO),
          reloadMs: String(Math.max(0, Date.now() - OO.at)),
          wasmBuild: pO.wasm,
          clientVersion: pO.client
        },
        bK = `reloaded into a newer build after ${OO.site} failed to load: ${OO.error}`;
      return IK({
        kind: "staleBuild",
        code: "CORE-staleBuild",
        site: Ap,
        fatal: !1,
        message: bK,
        details: XO
      })
    }
  },
  38933: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => IO,
      i: () => NO,
      k: () => TO
    });
    var XO = pO(171),
      bK = pO(94),
      eO = pO(3623),
      lO = pO(561),
      vK = pO(38939);
    const CO = 1048576,
      hO = 1024 * CO,
      DO = 400 * CO,
      MO = 147456,
      aK = .5,
      oO = 1.5 * hO,
      FO = 768 * CO,
      VO = new Set(["428x926@3", "393x852@3", "430x932@3", "402x874@3", "440x956@3", "420x912@3"]),
      LO = 600,
      QO = 8;

    function zK(OO) {
      return DO + OO * MO
    }

    function AO(OO, KO, pO) {
      var bK, eO;
      let {
        footprintBytes: lO,
        basis: CO,
        namesLimit: AO
      } = function(OO) {
        const {
          os: KO,
          deviceMemory: pO
        } = OO;
        if ("ios" === KO) {
          const KO = Math.min(OO.screenWidth, OO.screenHeight),
            pO = Math.max(OO.screenWidth, OO.screenHeight);
          return KO >= LO ? OO.hardwareConcurrency >= QO ? {
            footprintBytes: zK(vK.b),
            basis: "ipad-m",
            namesLimit: !1
          } : {
            footprintBytes: FO,
            basis: "ipad",
            namesLimit: !0
          } : VO.has(`${KO}x${pO}@${OO.devicePixelRatio}`) ? {
            footprintBytes: oO,
            basis: "iphone-6gb",
            namesLimit: !0
          } : {
            footprintBytes: FO,
            basis: "iphone",
            namesLimit: !0
          }
        }
        return "number" === typeof pO && Number.isFinite(pO) && pO > 0 ? {
          footprintBytes: pO * hO * aK,
          basis: `memory-${pO}`,
          namesLimit: !0
        } : "android" === KO ? {
          footprintBytes: FO,
          basis: "android",
          namesLimit: !0
        } : {
          footprintBytes: zK(vK.g),
          basis: "unreported",
          namesLimit: !1
        }
      }(OO);
      if (pO) {
        const OO = Math.min(lO, zK(vK.b));
        lO = DO + Math.max(0, OO - DO) / 2, CO += "+killed", AO = !0
      }
      null !== KO && zK(KO) < lO && (lO = zK(KO), CO += "+learned", AO = !0);
      const fO = function(OO) {
          const KO = Math.floor((OO - DO) / MO);
          return Math.min(vK.b, Math.max(vK.f, KO))
        }(lO),
        dO = (0, vK.o)(fO);
      return {
        footprintBytes: lO,
        shedFootprintBytes: AO ? Math.max(lO, zK(fO)) : null,
        chunkCap: fO,
        maxHorizDistance: null !== (bK = null === dO || void 0 === dO ? void 0 : dO.horizontal) && void 0 !== bK ? bK : XO.h.maxChunkHorizAddDistance,
        maxVertDistance: null !== (eO = null === dO || void 0 === dO ? void 0 : dO.vertical) && void 0 !== eO ? eO : XO.h.maxChunkVertAddDistance,
        basis: CO
      }
    }
    let fO = null;

    function dO() {
      return AO({
        os: (0, bK.getOperatingSystem)(),
        deviceMemory: navigator.deviceMemory,
        screenWidth: window.screen.width,
        screenHeight: window.screen.height,
        devicePixelRatio: window.devicePixelRatio,
        hardwareConcurrency: navigator.hardwareConcurrency
      }, (0, eO.d)(), (0, lO.u)("wasm").length > 0)
    }

    function TO() {
      return fO ??= dO(), fO
    }

    function NO() {
      var OO;
      return (null !== (OO = fO) && void 0 !== OO ? OO : dO()).basis
    }

    function IO(OO, KO) {
      return OO.setChunkCap(KO.chunkCap)
    }
  },
  39101: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      f: () => eO
    });
    var XO = pO(2460),
      bK = pO(886);

    function eO(OO, KO) {
      return null !== OO.gameSource && (0, XO.n)(KO, OO.gameSource)
    }

    function lO(OO, KO) {
      if (null === OO.gameSource || "" === OO.gameSource || null === KO) return !0;
      const pO = (0, bK.k)(KO) ? (0, bK.o)(KO) : null;
      return null !== pO && eO(OO, pO)
    }
  },
  39075: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      d: () => VO,
      h: () => hO,
      j: () => DO,
      m: () => FO
    });
    var XO = pO(39026),
      bK = pO(39083);
    const eO = 396,
      lO = 1,
      vK = 2,
      CO = 3,
      hO = {
        Glb: 1,
        LifeformAtlas: 2,
        ArmourAtlas: 3,
        Cape: 4,
        GroupAtlas: 5,
        Particle: 6,
        AttachmentImage: 7,
        BlockImage: 8
      },
      DO = {
        File: 0,
        Item: 1
      },
      MO = 0,
      aK = 1,
      oO = 2;

    function FO(OO) {
      const KO = (0, XO.q)();
      KO.catch((() => {}));
      let bK = null;
      return {
        glbUrl: OO,
        lifeformAtlasUrl: async OO => (await KO).lifeformAtlasUrl(OO),
        armourAtlasUrl: async () => (await pO.e(187).then((() => pO(33017)))).armourAtlasUrl,
        capeUrl: async OO => (await KO).capeUrl(OO),
        attachmentImageUrl: async OO => (await KO).attachmentImageUrl(OO),
        blockImageUrl: async OO => (await KO).blockImageUrl(OO),
        groupAtlasUrl: async OO => (await KO).groupAtlasUrl(OO),
        particleTextureUrl: async OO => (await KO).particleTextureUrl(OO),
        particleItemUrl: async OO => (bK ??= pO.e(34).then((() => pO(49589))).catch((OO => {
          throw bK = null, OO
        })), (await bK).particleItemUrl(OO))
      }
    }
    class VO {
      constructor(OO, KO) {
        var pO, eO, lO;
        let vK = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        this.sources = OO, this.onFailure = KO, this.loading = new Map, this.glbImages = new Map, this.glbWrittenImages = new Map, this.glbTakenCount = new Map, this.answered = new Map, this.ready = [], this.load = void 0, this.release = void 0, this.fetchFile = void 0, this.YX = !1, this.load = null !== (pO = vK.load) && void 0 !== pO ? pO : (OO, KO) => (0, bK.m)(OO, vK.fetchImage, KO), this.release = null !== (eO = vK.release) && void 0 !== eO ? eO : bK.r, this.fetchFile = null !== (lO = vK.fetchFile) && void 0 !== lO ? lO : OO => (0, XO.k)(OO)
      }
      get waiting() {
        return this.ready.length
      }
      get inFlight() {
        return this.loading.size
      }
      glbWritten(OO, KO) {
        this.glbWrittenImages.set(OO, TO(KO))
      }
      glbTaken(OO, KO) {
        const pO = this.glbWrittenImages.get(OO);
        this.glbWrittenImages.delete(OO), KO && this.setGlbImages(OO, void 0 !== pO && pO.length > 0 ? pO : void 0)
      }
      setGlbImages(OO, KO) {
        var pO;
        this.glbTakenCount.set(OO, (null !== (pO = this.glbTakenCount.get(OO)) && void 0 !== pO ? pO : 0) + 1), void 0 === KO ? this.glbImages.delete(OO) : this.glbImages.set(OO, KO);
        const XO = [];
        for (const {
            key: bK
          }
          of this.loading.values()) bK.kind === hO.Glb && bK.word === OO && XO.push(bK);
        for (let bK = this.ready.length - 1; bK >= 0; bK--) {
          const {
            key: KO,
            id: pO
          } = this.ready[bK];
          KO.kind === hO.Glb && KO.word === OO && (this.ready.splice(bK, 1), null !== pO && (this.answered.delete(pO), this.release(pO)), XO.push(KO))
        }
        this.loadAgain(XO)
      }
      onEvent(OO) {
        if (this.YX) return;
        const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
        for (let pO = 0; pO + 8 <= OO.byteLength; pO += 8) {
          const OO = KO.getUint8(pO),
            XO = KO.getUint32(pO + 4, !0);
          if (OO === CO) {
            this.answered.delete(XO), this.release(XO);
            continue
          }
          const bK = {
            kind: KO.getUint8(pO + 1),
            index: KO.getUint8(pO + 2),
            word: XO
          };
          OO === lO ? this.want(bK) : OO === vK && this.loading.delete(LO(bK))
        }
      }
      reload(OO, KO) {
        const pO = pO => OO.includes(pO.kind) && (void 0 === KO || KO(pO)),
          XO = new Map;
        for (const bK of this.answered.values()) pO(bK) && XO.set(LO(bK), bK);
        for (const [bK, {
            key: eO
          }] of this.loading) pO(eO) && XO.set(bK, eO);
        this.loadAgain(XO.values())
      }
      loadAgain(OO) {
        for (const KO of OO) this.loading.delete(LO(KO)), this.want(KO)
      }
      drain(OO) {
        if (null !== OO)
          for (; this.ready.length > 0;) {
            if (!OO(eO, 0, this.ready[0].record)) return;
            this.ready.shift()
          }
      }
      dispose() {
        this.YX = !0, this.loading.clear(), this.ready.length = 0;
        for (const OO of this.answered.keys()) this.release(OO);
        this.answered.clear()
      }
      want(OO) {
        const KO = LO(OO);
        if (this.loading.has(KO)) return;
        const pO = {
          key: OO
        };
        this.loading.set(KO, pO), this.loadKey(OO).then((XO => {
          this.YX || this.loading.get(KO) !== pO ? this.release(XO.id) : (this.loading.delete(KO), this.answered.set(XO.id, OO), this.ready.push({
            record: zK(OO, MO, XO),
            key: OO,
            id: XO.id
          }))
        }), (XO => {
          if (this.YX || this.loading.get(KO) !== pO) return;
          this.loading.delete(KO), this.onFailure({
            key: OO,
            error: XO
          });
          const eO = XO instanceof bK.d && "decode" === XO.stage ? aK : oO;
          this.ready.push({
            record: zK(OO, eO, null),
            key: OO,
            id: null
          })
        }))
      }
      async loadKey(OO) {
        switch (OO.kind) {
          case hO.Glb:
            return this.load(await this.glbImage(OO), "none");
          case hO.LifeformAtlas:
            return this.load(QO(await this.sources.lifeformAtlasUrl(OO.word), OO), "none");
          case hO.ArmourAtlas:
            return this.load(QO(await this.sources.armourAtlasUrl(), OO), "none");
          case hO.Cape:
            return this.load(QO(await this.sources.capeUrl(OO.word), OO), "none");
          case hO.AttachmentImage:
            return this.load(QO(await this.sources.attachmentImageUrl(OO.word), OO), "none");
          case hO.GroupAtlas:
            return this.load(QO(await this.sources.groupAtlasUrl(OO.word), OO), "none");
          case hO.BlockImage:
            return this.load(QO(await this.sources.blockImageUrl(OO.word), OO), "none");
          case hO.Particle: {
            const KO = await (OO.index === DO.Item ? this.sources.particleItemUrl(OO.word) : this.sources.particleTextureUrl(OO.word));
            return this.load(QO(KO, OO), "flipY")
          }
          default:
            throw new bK.d("fetch", `image kind ${OO.kind}`, {
              cause: null
            })
        }
      }
      async glbImage(OO) {
        var KO;
        let pO = this.glbImages.get(OO.word);
        if (void 0 === pO) {
          const KO = this.glbTakenCount.get(OO.word),
            XO = QO(await this.sources.glbUrl(OO.word), OO);
          try {
            pO = TO(await this.fetchFile(XO))
          } catch (eO) {
            throw new bK.d("fetch", XO, {
              cause: eO
            })
          }
          this.glbTakenCount.get(OO.word) === KO && this.glbImages.set(OO.word, pO)
        }
        const XO = null === (KO = pO) || void 0 === KO ? void 0 : KO[OO.index];
        if (!XO) throw new bK.d("decode", `image ${OO.index} of file ${2147483647&OO.word}`, {
          cause: null
        });
        return XO
      }
    }

    function LO(OO) {
      let {
        kind: KO,
        index: pO,
        word: XO
      } = OO;
      return `${KO}:${pO}:${XO}`
    }

    function QO(OO, KO) {
      if (null === OO) throw new bK.d("fetch", `no URL for image ${LO(KO)}`, {
        cause: null
      });
      return OO
    }

    function zK(OO, KO, pO) {
      var XO, bK, eO;
      const lO = new Uint8Array(16),
        vK = new DataView(lO.buffer);
      return vK.setUint8(0, OO.kind), vK.setUint8(1, OO.index), vK.setUint8(2, KO), vK.setUint32(4, OO.word, !0), vK.setUint32(8, null !== (XO = null === pO || void 0 === pO ? void 0 : pO.id) && void 0 !== XO ? XO : 0, !0), vK.setUint16(12, Math.min(null !== (bK = null === pO || void 0 === pO ? void 0 : pO.width) && void 0 !== bK ? bK : 0, 65535), !0), vK.setUint16(14, Math.min(null !== (eO = null === pO || void 0 === pO ? void 0 : pO.height) && void 0 !== eO ? eO : 0, 65535), !0), lO
    }
    const AO = 1179937895,
      fO = 1313821514,
      dO = 5130562;

    function TO(OO) {
      var KO;
      const pO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
      if (OO.byteLength < 20 || pO.getUint32(0, !0) !== AO || pO.getUint32(16, !0) !== fO) return [];
      let XO, bK = 20 + pO.getUint32(12, !0);
      try {
        XO = JSON.parse((new TextDecoder).decode(OO.subarray(20, bK)))
      } catch {
        return []
      }
      for (; bK + 8 <= OO.byteLength && pO.getUint32(bK + 4, !0) !== dO;) bK += 8 + pO.getUint32(bK, !0);
      const eO = null !== (KO = XO.images) && void 0 !== KO ? KO : [];
      if (0 === eO.length || bK + 8 > OO.byteLength) return eO.map((() => null));
      const lO = OO.subarray(bK + 8, Math.min(OO.byteLength, bK + 8 + pO.getUint32(bK, !0)));
      return eO.map((OO => {
        var KO, pO, bK;
        const eO = void 0 === OO.bufferView || null === (KO = XO.bufferViews) || void 0 === KO ? void 0 : KO[OO.bufferView];
        if (!eO || 0 !== (null !== (pO = eO.buffer) && void 0 !== pO ? pO : 0) || void 0 === eO.byteLength) return null;
        const vK = null !== (bK = eO.byteOffset) && void 0 !== bK ? bK : 0,
          CO = vK + eO.byteLength;
        return CO <= lO.byteLength ? lO.slice(vK, CO) : null
      }))
    }
  },
  3952: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      f: () => eO,
      h: () => vK
    });
    var XO = pO(1964),
      bK = pO(3955);

    function eO(OO) {
      let {
        action: KO,
        flags: pO
      } = OO;
      return "mid-fire" === KO && 0 !== (pO & XO.b.AltLeftClick)
    }
    const lO = new Set;

    function vK(OO) {
      return lO.add(OO), () => {
        lO.delete(OO)
      }
    }

    function CO(OO) {
      const KO = bK.e[255 & OO];
      if (void 0 === KO) return;
      const pO = OO >>> 8 & 255,
        eO = {
          action: KO,
          down: 0 !== (pO & XO.b.Down),
          flags: pO,
          press: OO >>> 16
        };
      for (const XO of lO) XO(eO)
    }
  },
  38755: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      e: () => eO,
      h: () => bK
    });
    let XO = null;

    function bK(OO) {
      XO = OO
    }

    function eO(OO) {
      XO === OO && (XO = null)
    }

    function lO() {
      var OO;
      null === (OO = XO) || void 0 === OO || OO()
    }
  },
  39064: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      g: () => hO,
      j: () => CO
    });
    var XO = pO(3943),
      bK = pO(1964),
      eO = pO(3962);
    let lO = !1,
      vK = !1;

    function CO(OO) {
      lO = !0;
      try {
        OO()
      } finally {
        lO = !1
      }
    }

    function hO(OO, KO) {
      if (lO) return !1;
      switch (OO) {
        case XO.x.MouseDown:
        case XO.x.MouseUp:
        case XO.x.TouchStart:
        case XO.x.TouchEnd:
        case XO.x.TouchCancel:
        case XO.x.TouchButton:
          return !0;
        case XO.x.KeyDown:
        case XO.x.KeyUp:
          return 0 === (KO & bK.e.Repeat) && !(0, eO.f)(document.activeElement);
        default:
          return !1
      }
    }

    function DO(OO) {
      vK || (vK = !0, queueMicrotask((() => {
        vK = !1, OO()
      })))
    }
  },
  38917: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      c: () => eO,
      d: () => lO,
      g: () => bK,
      h: () => oO,
      i: () => DO,
      k: () => CO,
      o: () => aK,
      s: () => MO,
      u: () => vK
    });
    var XO = pO(37598);
    const bK = new Uint8Array([12]),
      eO = 2e3,
      lO = 257;

    function vK(OO) {
      const KO = new Uint8Array(4);
      return new DataView(KO.buffer).setUint32(0, OO, !0), KO
    }
    class CO extends Error {
      constructor() {
        super("the game was left while it reconnected"), this.name = "AbortError"
      }
    }
    class hO extends Error {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        super(OO), this.stage = KO, this.code = pO, this.serverText = XO, this.name = "JoinError"
      }
    }
    class DO extends Error {
      constructor(OO) {
        super(OO), this.final = !0, this.name = "ResumeRefusedError"
      }
    }
    class MO extends Error {
      constructor() {
        super(XO.d), this.name = "TrafficCheckError"
      }
    }
    class aK extends Error {
      constructor(OO, KO, pO) {
        super(OO, {
          cause: pO
        }), this.networkLost = KO, this.name = "SeatRequestError"
      }
    }
    class oO extends Error {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        super(OO), this.code = KO, this.serverText = pO, this.name = "MatchmakeError"
      }
    }
  },
  38800: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      c: () => eO
    });
    let XO = null;

    function bK(OO, KO) {
      XO = {
        conn: OO,
        reason: KO
      }
    }

    function eO(OO) {
      var KO;
      const pO = (null === (KO = XO) || void 0 === KO ? void 0 : KO.conn) === OO ? XO.reason : null;
      return XO = null, pO
    }
  },
  39017: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => yK,
      j: () => MO,
      n: () => dO,
      q: () => QO,
      t: () => NO
    });
    var XO = pO(38941),
      bK = pO(38939);
    const eO = 64 * XO.e,
      lO = 40 * XO.h,
      vK = 36 * XO.h,
      CO = 20 * XO.h,
      hO = 2 * XO.h,
      DO = 5 * XO.h;

    function MO(OO) {
      return "footprint" !== OO
    }
    const aK = 2 * XO.h,
      oO = 4 * XO.h,
      FO = 35 * XO.h + aK + oO,
      VO = 6.5 * XO.h,
      LO = 132.5 * XO.e;

    function QO(OO) {
      const KO = VO + (0, bK.k)(OO) + OO * LO;
      return Math.ceil((2 * FO + KO) / eO) * eO
    }
    const zK = QO(bK.b),
      AO = (XO.h, XO.h, XO.h, {
        targetBytes: lO,
        leastBytes: CO
      }),
      fO = {
        targetBytes: vK,
        leastBytes: CO
      };

    function dO(OO) {
      return OO >= bK.b ? AO : fO
    }
    const TO = 2 * eO;

    function NO(OO, KO, pO) {
      return OO + KO + TO > (null !== pO && void 0 !== pO ? pO : zK)
    }
    const IO = {
      now: () => performance.now(),
      requestIdle: "function" === typeof requestIdleCallback ? OO => {
        requestIdleCallback(OO)
      } : null
    };
    class yK {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : IO;
        this.memory = OO, this.readPeakStoredChunks = KO, this.onError = pO, this.clock = XO, this.pendingSince = null, this.stepsRefused = !1, this.stepsHeldUntil = null, this.shedding = null, this.sheds = 0, this.shedCap = null, this.stopped = !1, this.statsAt = -1 / 0, this.main = null, this.peakStoredChunks = 0, this.workers = new Map, this.replacedRefusals = {
          reserves: 0,
          allocations: 0
        }, this.joinReserveTaken = null, this.ceilingBytes = null, this.ballastCheckAt = -1 / 0, this.ballastPeakBytes = 0, this.distanceInUse = null, this.footprint = null
      }
      setShed(OO, KO, pO) {
        this.shedding = {
          shed: OO,
          CX: KO,
          readDistanceInUse: pO
        }
      }
      shedDistanceInUse() {
        return this.distanceInUse
      }
      setFootprint(OO) {
        this.footprint = OO
      }
      setCeiling(OO) {
        this.ceilingBytes = OO, this.call((() => {
          this.memory.setCeiling(OO)
        }), void 0)
      }
      ceilingMayRefuse(OO) {
        return NO(this.memory.memoryBytes(), OO, this.ceilingBytes)
      }
      reserveAtJoin(OO) {
        let {
          targetBytes: KO,
          leastBytes: pO
        } = OO;
        const XO = this.memory.memoryBytes(),
          bK = XO + pO,
          eO = Math.max(KO + (this.ballastOn() ? DO : 0), bK),
          lO = this.call((() => this.memory.reserveUpFront(eO) ? "target" : eO > bK && this.memory.reserveUpFront(bK) ? "least" : "none"), "none");
        if (this.stopped) return !1;
        if ("target" !== lO) {
          const OO = "least" === lO ? `took ${bK} bytes instead` : "frames grow it in steps";
          console.warn(`[bloxd-wasm-client] wasm memory: the join's reserve to ${eO} bytes was refused at ${XO} bytes; ${OO}`)
        }
        return this.joinReserveTaken = lO, this.takePressure(), this.takeBallast(this.clock.now()), this.refreshStats(), "target" !== lO && this.shedFor("joinReserve"), "none" !== lO
      }
      afterFrame() {
        if (this.stopped) return;
        const OO = this.clock.now(),
          KO = null !== this.stepsHeldUntil && OO >= this.stepsHeldUntil;
        if (KO && (this.stepsHeldUntil = null), this.takePressure() && null === this.stepsHeldUntil && !this.stepsRefused && this.shedFor("allocation"), this.stopped) return;
        if (null === this.stepsHeldUntil && OO >= this.ballastCheckAt && (this.takeBallast(OO), this.stopped)) return;
        const pO = this.stepsRefused || null !== this.stepsHeldUntil ? "none" : this.call((() => this.memory.lowWater()), "none"),
          XO = KO && "now" === pO ? "none" : pO,
          {
            requestIdle: bK
          } = this.clock;
        "now" === XO || null !== this.pendingSince && OO - this.pendingSince >= 500 ? this.step() : "idle" === XO && null === this.pendingSince && (null === bK ? this.step() : (this.pendingSince = OO, bK((() => {
          null !== this.pendingSince && this.step()
        })))), OO - this.statsAt >= 1e3 && (this.statsAt = OO, this.refreshStats(), this.checkFootprint())
      }
      refreshStats() {
        this.call((() => {
          var OO, KO;
          (this.main = this.memory.stats(), this.peakStoredChunks = this.readPeakStoredChunks(), this.sheds > 0 && null !== this.shedding) && (this.distanceInUse = null !== (KO = this.shedding.readDistanceInUse()) && void 0 !== KO ? KO : this.distanceInUse);
          null === (OO = this.footprint) || void 0 === OO || OO.read(this.memory.memoryBytes() + this.workersMemoryBytes())
        }), void 0)
      }
      stop() {
        this.stopped = !0, this.pendingSince = null
      }
      noteMeshWorker(OO, KO) {
        this.noteWorker(`Mesh${OO}`, KO)
      }
      meshWorkerGone(OO) {
        this.workerGone(`Mesh${OO}`)
      }
      noteWorldgen(OO) {
        this.noteWorker("Worldgen", OO)
      }
      worldgenGone() {
        this.workerGone("Worldgen")
      }
      noteWorker(OO, KO) {
        const pO = this.workers.get(OO);
        null !== pO && void 0 !== pO && pO.gone && (this.replacedRefusals.reserves += pO.stats.reservesRefused, this.replacedRefusals.allocations += pO.stats.allocationsRefused), this.workers.set(OO, {
          stats: KO,
          gone: !1
        })
      }
      workerGone(OO) {
        const KO = this.workers.get(OO);
        KO && (KO.gone = !0)
      }
      details() {
        var OO, KO;
        const pO = {
          wasmMemoryNow: `${(0,XO.k)(this.memory.memoryBytes())} MiB`
        };
        null !== this.joinReserveTaken && (pO.wasmMemoryJoinReserve = this.joinReserveTaken), this.sheds > 0 && (pO.wasmMemoryShed = `${this.sheds}, chunk cap ${this.shedCap}`);
        const bK = this.main;
        if (bK) {
          pO.wasmMemoryMain = gK(bK);
          const OO = Math.max(0, bK.peakLiveBytes - this.ballastPeakBytes),
            KO = 0 === this.peakStoredChunks ? "-" : (OO / this.peakStoredChunks / XO.e).toFixed(1);
          pO.wasmMemoryChunks = `peak stored ${this.peakStoredChunks}, peak live per stored chunk ${KO} KiB`
        }
        for (const [XO, {
            stats: lO,
            gone: vK
          }] of this.workers) pO[`wasmMemory${XO}`] = gK(lO) + (vK ? " (gone)" : "");
        const eO = null !== (OO = null === (KO = this.footprint) || void 0 === KO ? void 0 : KO.describe()) && void 0 !== OO ? OO : null;
        return null !== eO && (pO.wasmMemoryFootprint = eO), pO
      }
      pageKillSnapshot() {
        var OO, KO, pO, bK, eO;
        let lO = (null !== (OO = null === (KO = this.main) || void 0 === KO ? void 0 : KO.reservesRefused) && void 0 !== OO ? OO : 0) + this.replacedRefusals.reserves,
          vK = (null !== (pO = null === (bK = this.main) || void 0 === bK ? void 0 : bK.allocationsRefused) && void 0 !== pO ? pO : 0) + this.replacedRefusals.allocations;
        for (const {
            stats: XO
          }
          of this.workers.values()) lO += XO.reservesRefused, vK += XO.allocationsRefused;
        return {
          wasmMainMiB: Number((0, XO.k)(this.memory.memoryBytes())),
          wasmWorkersMiB: Number((0, XO.k)(this.workersMemoryBytes())),
          peakStoredChunks: this.peakStoredChunks,
          refusedReserves: lO,
          refusedAllocations: vK,
          sheds: this.sheds,
          ...null === (eO = this.footprint) || void 0 === eO ? void 0 : eO.snapshot()
        }
      }
      workersMemoryBytes() {
        let OO = 0;
        for (const {
            stats: KO,
            gone: pO
          }
          of this.workers.values()) OO += pO ? 0 : KO.memoryBytes;
        return OO
      }
      checkFootprint() {
        null === this.footprint || null === this.shedding || this.stepsRefused || null !== this.stepsHeldUntil || this.footprint.takeShed() && this.shedFor("footprint")
      }
      step() {
        this.pendingSince = null, this.call((() => this.memory.reserveAhead(hO)), !0) || (null === this.shedding ? this.stopSteps("a step ahead was refused (the ceiling, or the browser)") : this.shedFor("step"))
      }
      ballastOn() {
        return null !== this.shedding
      }
      takeBallast(OO) {
        if (!this.ballastOn() || null === this.joinReserveTaken) return;
        this.ballastCheckAt = OO + 1e3;
        const KO = this.call((() => this.memory.takeBallast()), 0);
        this.ballastPeakBytes = Math.max(this.ballastPeakBytes, KO)
      }
      takePressure() {
        return this.ballastOn() && this.call((() => this.memory.takePressure()), !1)
      }
      stopSteps(OO) {
        this.stepsRefused = !0, console.warn(`[bloxd-wasm-client] wasm memory: ${OO}: frames grow on demand from here`)
      }
      shedFor(OO) {
        const {
          shedding: KO
        } = this;
        if (null === KO) return;
        this.pendingSince = null;
        const pO = this.call((() => KO.shed(OO)), null);
        this.stopped || (null !== pO ? (this.sheds++, this.shedCap = pO, this.stepsHeldUntil = this.clock.now() + 5e3, this.refreshStats(), KO.CX(OO, this.sheds, this.details())) : MO(OO) && this.stopSteps("nothing is left to shed"))
      }
      call(OO, KO) {
        if (this.stopped) return KO;
        try {
          return OO()
        } catch (pO) {
          return this.stop(), this.onError(pO), KO
        }
      }
    }

    function gK(OO) {
      const KO = (OO, KO) => `${OO}/${(0,XO.k)(KO)}`;
      return `memory ${(0,XO.k)(OO.memoryBytes)} live ${(0,XO.k)(OO.liveBytes)} peak ${(0,XO.k)(OO.peakLiveBytes)} unused ${(0,XO.k)(OO.unusedBytes)} ceiling ${(0,XO.k)(OO.ceilingBytes)} MiB; grows upFront ${KO(OO.grows.upFront,OO.grownBytes.upFront)} ahead ${KO(OO.grows.ahead,OO.grownBytes.ahead)} inFrame ${KO(OO.grows.onDemandInFrame,OO.grownBytes.onDemandInFrame)} other ${KO(OO.grows.onDemand,OO.grownBytes.onDemand)}; refused reserves ${OO.reservesRefused} allocations ${OO.allocationsRefused}`
    }
  },
  39020: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => vK,
      h: () => MO,
      i: () => hO
    });
    var XO = pO(3934),
      bK = pO(39026),
      eO = pO(39029);
    const lO = 395,
      vK = 2147483648,
      CO = new Uint8Array(0);
    class hO extends Error {
      constructor() {
        super(...arguments), this.name = "ModelRingError"
      }
    }
    class DO extends Error {
      constructor() {
        super(...arguments), this.name = "ModelPackRefusedError"
      }
    }
    class MO {
      constructor(OO, KO, pO) {
        var XO, eO, lO, vK;
        let CO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        this.files = OO, this.build = KO, this.onFailure = pO, this.ready = [], this.pending = new Map, this.written = new Map, this.drawn = new Map, this.undrawn = new Set, this.Sp = new Map, this.keptTotal = 0, this.refusedPack = new Map, this.startupLeft = void 0, this.fetchFile = void 0, this.onWritten = void 0, this.onTaken = void 0, this.onPackFileFailed = void 0, this.refreshes = 0, this.nextSeq = 1, this.fetchFile = null !== (XO = CO.fetchFile) && void 0 !== XO ? XO : OO => (0, bK.k)(OO), this.onWritten = null !== (eO = CO.onWritten) && void 0 !== eO ? eO : null, this.onTaken = null !== (lO = CO.onTaken) && void 0 !== lO ? lO : null, this.onPackFileFailed = null !== (vK = CO.onPackFileFailed) && void 0 !== vK ? vK : null, this.startupLeft = new Set(OO.startup);
        for (const bK of OO.startup) this.request(bK)
      }
      get startupDone() {
        return 0 === this.startupLeft.size
      }
      get waiting() {
        return this.ready.length
      }
      get asking() {
        return this.pending.size
      }
      get inFlight() {
        return this.pending.size - this.ready.length
      }
      get unanswered() {
        return this.written.size
      }
      get keptBytes() {
        return this.keptTotal
      }
      drawnUrl(OO) {
        return this.drawn.get(OO)
      }
      request(OO) {
        const KO = this.pending.get(OO);
        if (!0 === (null === KO || void 0 === KO ? void 0 : KO.ask)) return;
        const pO = this.Ip(OO, !0);
        pO.recheck = void 0 !== KO;
        const XO = this.drawn.get(OO);
        if (void 0 !== XO) return pO.JK = !0, pO.recheck = !0, void this.fetch(OO, pO, XO);
        this.fetchWanted(OO, pO)
      }
      async refresh() {
        const OO = ++this.refreshes,
          KO = new Set;
        for (const lO of [this.drawn.keys(), this.written.keys(), this.pending.keys(), this.undrawn.values()])
          for (const OO of lO) 0 === (OO & bK.h) && KO.add(OO);
        const pO = [...KO];
        let XO;
        try {
          XO = await Promise.all(pO.map((OO => this.wanted(OO))))
        } catch {
          return null
        }
        if (OO !== this.refreshes) return null;
        const eO = {
          resent: 0,
          refetched: 0,
          delivered: pO.filter((OO => this.drawn.has(OO))).length
        };
        return pO.forEach(((OO, KO) => {
          const {
            url: pO,
            inPlaceOf: bK
          } = XO[KO], lO = this.pending.get(OO);
          if (void 0 !== lO) {
            if (lO.JK || void 0 === lO.url) return void(lO.recheck = !0);
            if (lO.url === pO) return;
            eO.refetched++;
            const KO = this.Ip(OO, lO.ask);
            return KO.recheck = lO.recheck, void this.fetch(OO, KO, pO, bK)
          }
          const vK = this.written.get(OO);
          void 0 === vK ? this.drawn.get(OO) !== (null !== pO && void 0 !== pO ? pO : void 0) && (eO.resent++, this.fetch(OO, this.Ip(OO, !1), pO, bK)) : vK.url !== (null !== pO && void 0 !== pO ? pO : "") && (vK.attempt.recheck = !0)
        })), eO
      }
      taken(OO, KO) {
        const pO = new Set,
          XO = new Set;
        for (const bK of Array.from(KO)) 0 === (bK & vK) ? pO.add(bK) : XO.add((bK & ~vK) >>> 0);
        for (const [bK, eO] of this.written) eO.seq > OO || (this.written.delete(bK), pO.has(eO.seq) ? this.refusedFile(bK, eO) : this.takenFile(bK, eO, !eO.empty && !XO.has(eO.seq)))
      }
      takenFile(OO, KO, pO) {
        const {
          attempt: XO
        } = KO;
        if (pO) {
          var bK;
          this.drawn.set(OO, KO.url), this.undrawn.delete(OO), void 0 !== XO.inPlaceOf ? this.refusedPack.set(OO, XO.inPlaceOf) : XO.JK || this.refusedPack.delete(OO), null === (bK = this.onTaken) || void 0 === bK || bK.call(this, OO, !0);
          const pO = this.pending.get(OO);
          if (!0 === (null === pO || void 0 === pO ? void 0 : pO.JK) && pO.url !== KO.url) {
            const pO = this.Ip(OO, !0);
            pO.JK = !0, pO.recheck = !0, this.fetch(OO, pO, KO.url)
          }
        } else {
          var eO;
          this.drawn.has(OO) || this.undrawn.add(OO), null === (eO = this.onTaken) || void 0 === eO || eO.call(this, OO, !1)
        }
        XO.recheck && this.resendIfChanged(OO)
      }
      refusedFile(OO, KO) {
        var pO, XO;
        if (null === (pO = this.onTaken) || void 0 === pO || pO.call(this, OO, !1), this.refusedPack.set(OO, KO.url), this.pending.has(OO)) return void(null === (XO = this.onPackFileFailed) || void 0 === XO || XO.call(this, OO, aK(KO.url)));
        const bK = this.Ip(OO, KO.attempt.ask);
        bK.recheck = KO.attempt.recheck, this.afterRefusal(OO, bK, KO.url)
      }
      async afterRefusal(OO, KO, pO) {
        var XO;
        let bK;
        try {
          bK = await this.wanted(OO)
        } catch (eO) {
          return void(this.pending.get(OO) === KO && this.giveUp(OO, KO, pO, eO))
        }
        this.pending.get(OO) === KO && (bK.inPlaceOf !== pO ? KO.ask || (null !== (XO = bK.url) && void 0 !== XO ? XO : void 0) !== this.drawn.get(OO) ? this.fetch(OO, KO, bK.url, bK.inPlaceOf) : this.pending.delete(OO) : this.fallBack(OO, KO, pO, aK(pO)))
      }
      Ip(OO, KO) {
        const pO = {
          url: void 0,
          ask: KO,
          JK: !1,
          recheck: !1,
          inPlaceOf: void 0
        };
        this.pending.set(OO, pO);
        for (let XO = this.ready.length - 1; XO >= 0; XO--) this.ready[XO].file === OO && this.ready.splice(XO, 1);
        return pO
      }
      async wanted(OO) {
        const KO = await this.files.url(OO);
        return null !== KO && this.refusedPack.get(OO) === KO ? {
          url: await this.files.shippedUrl(OO),
          inPlaceOf: KO
        } : {
          url: KO,
          inPlaceOf: void 0
        }
      }
      fetchWanted(OO, KO) {
        const pO = this.files.url(OO);
        pO instanceof Promise ? pO.then((pO => {
          this.fetchFound(OO, KO, pO)
        }), (pO => {
          this.pending.get(OO) === KO && this.giveUp(OO, KO, "", pO)
        })) : this.fetchFound(OO, KO, pO)
      }
      fetchFound(OO, KO, pO) {
        null !== pO && this.refusedPack.get(OO) === pO ? Promise.resolve(this.files.shippedUrl(OO)).then((XO => {
          this.fetch(OO, KO, XO, pO)
        }), (XO => {
          this.pending.get(OO) === KO && this.giveUp(OO, KO, pO, XO)
        })) : this.fetch(OO, KO, pO)
      }
      fetch(OO, KO, pO, XO) {
        this.pending.get(OO) === KO && (KO.url = pO, KO.inPlaceOf = XO, null !== pO ? this.load(OO, KO, pO) : this.buildFile(OO, KO, "", CO))
      }
      load(OO, KO, pO) {
        const XO = this.Sp.get(OO);
        (null === XO || void 0 === XO ? void 0 : XO.url) !== pO ? this.fetchFile(pO).then((XO => {
          var bK, eO;
          this.pending.get(OO) === KO && (this.keptTotal += XO.byteLength - (null !== (bK = null === (eO = this.Sp.get(OO)) || void 0 === eO ? void 0 : eO.glb.byteLength) && void 0 !== bK ? bK : 0), this.Sp.set(OO, {
            url: pO,
            glb: XO
          }), this.buildFile(OO, KO, pO, XO))
        }), (XO => {
          this.pending.get(OO) === KO && this.fallBack(OO, KO, pO, XO)
        })) : this.buildFile(OO, KO, pO, XO.glb)
      }
      buildFile(OO, KO, pO, lO) {
        let vK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const CO = lO.byteLength > 0 && (0, bK.n)(pO) ? (OO | bK.e) >>> 0 : OO;
        this.build(CO, lO).then((bK => {
          if (this.pending.get(OO) !== KO) return;
          if (XO.x + (0, XO.ne)(bK.byteLength) > XO.Fc) return void this.ringRefused(OO, KO, pO, new hO(`${oO(pO)}'s record is ${bK.byteLength-eO.d} bytes, past the cmd ring's ${XO.Fc}`), vK);
          const CO = {
            file: OO,
            url: pO,
            payload: bK,
            glb: lO,
            attempt: KO
          };
          vK ? this.ready.unshift(CO) : this.ready.push(CO)
        }))
      }
      async fallBack(OO, KO, pO, XO) {
        var bK;
        let eO = null,
          lO = XO;
        try {
          eO = await this.files.shippedUrl(OO)
        } catch (vK) {
          lO = vK
        }
        this.pending.get(OO) === KO && (null !== eO && eO !== pO ? (null === (bK = this.onPackFileFailed) || void 0 === bK || bK.call(this, OO, XO), KO.ask || this.drawn.get(OO) !== eO ? (KO.url = eO, KO.inPlaceOf = pO, this.load(OO, KO, eO)) : this.pending.delete(OO)) : this.giveUp(OO, KO, pO, lO))
      }
      ringRefused(OO, KO, pO, XO) {
        let eO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        (0, bK.n)(pO) ? this.fallBack(OO, KO, pO, XO): this.giveUp(OO, KO, pO, XO, eO)
      }
      giveUp(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        this.onFailure({
          file: OO,
          url: oO(pO),
          error: XO,
          startup: this.startupLeft.has(OO)
        }), KO.ask || !this.drawn.has(OO) ? this.buildFile(OO, KO, pO, CO, bK) : this.pending.delete(OO)
      }
      async resendIfChanged(OO) {
        var KO;
        if (0 !== (OO & bK.h)) return;
        let pO;
        try {
          pO = await this.wanted(OO)
        } catch {
          return
        }(null !== (KO = pO.url) && void 0 !== KO ? KO : void 0) === this.drawn.get(OO) || this.pending.has(OO) || this.written.has(OO) || this.fetch(OO, this.Ip(OO, !1), pO.url, pO.inPlaceOf)
      }
      drain(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (null === OO) return;
        let pO = 0,
          XO = 0;
        for (; XO < this.ready.length && pO < 262144;) {
          const DO = this.ready[XO];
          if (this.written.has(DO.file)) {
            XO++;
            continue
          }
          const MO = this.nextSeq;
          new DataView(DO.payload.buffer, DO.payload.byteOffset, DO.payload.byteLength).setUint32(eO.f, MO, !0);
          const aK = DO.attempt.JK && DO.glb.byteLength > 0 && this.drawn.get(DO.file) === DO.url;
          if (OO(lO, aK ? 1 : 0, DO.payload)) {
            if (this.nextSeq = MO >= vK - 1 ? 1 : MO + 1, this.ready.splice(XO, 1), pO += DO.payload.byteLength, this.pending.delete(DO.file), this.startupLeft.delete(DO.file), this.written.set(DO.file, {
                seq: MO,
                url: DO.url,
                empty: 0 === DO.glb.byteLength,
                attempt: DO.attempt
              }), DO.glb.byteLength > 0) try {
              var bK;
              null === (bK = this.onWritten) || void 0 === bK || bK.call(this, DO.file, DO.glb)
            } catch (CO) {
              console.warn("ModelFeed: reading the file's images failed", CO)
            }
          } else {
            if (null === KO || 0 === DO.glb.byteLength || KO(DO.payload.byteLength)) return;
            this.ready.splice(XO, 1);
            const OO = new hO(`${oO(DO.url)}'s record is ${DO.payload.byteLength-eO.d} bytes, more than the cmd ring can grow to take`);
            this.ringRefused(DO.file, DO.attempt, DO.url, OO, !0)
          }
        }
      }
    }

    function aK(OO) {
      return new DO(`presentation refused ${oO(OO)}`)
    }

    function oO(OO) {
      return OO.startsWith("data:") ? `${OO.slice(0,Math.min(Math.max(OO.indexOf(","),5),64))},...` : OO
    }
  },
  39026: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      h: () => eO,
      k: () => DO,
      n: () => vK,
      q: () => hO,
      u: () => CO
    });
    var XO = pO(2951),
      bK = pO(2494);
    const eO = 2147483648,
      lO = 1073741824;

    function vK(OO) {
      return OO.startsWith("data:")
    }

    function CO(OO) {
      let {
        onTableFailed: KO,
        packUrl: pO
      } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      const XO = hO();
      XO.catch((OO => {
        null === KO || void 0 === KO || KO(OO)
      }));
      const bK = async KO => (await XO).fileUrl((KO & ~eO) >>> 0, OO);
      return {
        startup: [],
        url: async OO => {
          if (pO && 0 === (OO & eO)) {
            const KO = await XO,
              bK = KO.filePackName(OO),
              eO = null === bK || "lifeform" === KO.fileSource(OO) ? null : pO(bK);
            if (null !== eO) return eO
          }
          return bK(OO)
        },
        shippedUrl: bK
      }
    }

    function hO() {
      return pO.e(37).then((() => pO(41396)))
    }
    async function DO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      return OO.startsWith("data:") ? (0, bK.b)(OO.slice(OO.indexOf(",") + 1), KO) : (0, XO.y)(OO, {
        spare: KO
      })
    }
  },
  39029: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      f: () => hO,
      g: () => aK,
      k: () => FO,
      l: () => MO,
      o: () => oO
    });
    const XO = 826427981,
      bK = 1,
      eO = 2,
      lO = 44,
      vK = 46,
      CO = 8,
      hO = 4;

    function DO(OO, KO, pO) {
      const bK = (new TextEncoder).encode(pO),
        eO = CO + 4 * (KO.length + 2),
        lO = new Uint8Array(eO + (bK.byteLength + 3 & -4)),
        vK = new DataView(lO.buffer);
      return vK.setUint32(0, OO, !0), vK.setUint32(CO, XO, !0), KO.forEach(((OO, KO) => {
        vK.setUint32(CO + 4 * (KO + 1), OO, !0)
      })), vK.setUint32(eO - 4, bK.byteLength, !0), lO.set(bK, eO), lO
    }

    function MO(OO, KO) {
      return DO(OO, [eO], KO)
    }

    function aK(OO, KO) {
      return DO(OO, [bK, vK], KO)
    }

    function oO(OO, KO) {
      return DO(OO, [bK, lO], KO)
    }

    function FO(OO) {
      const KO = CO;
      if (OO.byteLength < KO + 12) return !1;
      const pO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength);
      return pO.getUint32(KO, !0) === XO && pO.getUint32(KO + 4, !0) === bK && pO.getUint32(KO + 8, !0) === lO
    }
  },
  4160: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      f: () => lO
    });
    var XO = pO(2460),
      bK = pO(4169);
    let eO = null;

    function lO(OO, KO) {
      eO = {
        pack: OO.metaData.id === XO.c ? null : OO,
        prompt: KO
      }
    }

    function vK(OO, KO) {
      const pO = eO;
      null !== pO && (0, bK.b)(pO.pack, OO) && (eO = null, KO && pO.prompt())
    }
  },
  39108: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    const XO = 2e3
  },
  39089: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => DO,
      d: () => eO,
      h: () => MO,
      j: () => lO
    });
    var XO = pO(39075),
      bK = pO(39026);
    const eO = new class {
      constructor() {
        this.page = null, this.session = void 0, this.follower = null, this.isWanted = !1, this.listeners = new Set, this.pageListeners = new Set, this.wantedListeners = new Set
      }
      get current() {
        return void 0 === this.session ? this.page : this.session
      }
      setPageFiles(OO) {
        this.change((() => {
          this.page = OO
        }))
      }
      setSessionFiles(OO) {
        const KO = void 0 !== this.session && void 0 === OO;
        if (this.change((() => {
            this.session = OO
          })), KO)
          for (const pO of [...this.pageListeners]) pO()
      }
      showsPage() {
        return void 0 === this.session
      }
      onPageShown(OO) {
        return this.pageListeners.add(OO), () => {
          this.pageListeners.delete(OO)
        }
      }
      setFollower(OO) {
        this.follower = OO, this.startFollower()
      }
      wanted() {
        this.isWanted = !0;
        for (const OO of [...this.wantedListeners]) OO();
        this.startFollower()
      }
      onWanted(OO) {
        return this.wantedListeners.add(OO), () => {
          this.wantedListeners.delete(OO)
        }
      }
      onChange(OO) {
        return this.listeners.add(OO), () => {
          this.listeners.delete(OO)
        }
      }
      startFollower() {
        const OO = this.follower;
        this.isWanted && null !== OO && (this.follower = null, OO((() => {
          this.follower = OO
        })))
      }
      change(OO) {
        const KO = this.current;
        if (OO(), this.current !== KO)
          for (const pO of this.listeners) pO()
      }
    };

    function lO(OO, KO) {
      return {
        ...OO,
        armourAtlasUrl: () => {
          var pO, XO;
          return null !== (pO = null === (XO = KO()) || void 0 === XO ? void 0 : XO.armourAtlasUrl()) && void 0 !== pO ? pO : OO.armourAtlasUrl()
        },
        lifeformAtlasUrl: pO => CO(KO(), (OO => OO.LIFEFORM_ATLAS_PATHS[pO]), (() => OO.lifeformAtlasUrl(pO))),
        groupAtlasUrl: pO => CO(KO(), (OO => OO.GROUP_ATLAS_PATHS[pO]), (() => OO.groupAtlasUrl(pO))),
        particleItemUrl: XO => hO(KO(), (async () => {
          const OO = await pO.e(34).then((() => pO(49589))).catch((() => null));
          return (null === OO || void 0 === OO ? void 0 : OO.particleItemSprite(XO)) || null
        }), (() => OO.particleItemUrl(XO))),
        blockImageUrl: pO => hO(KO(), (async () => {
          var OO, KO;
          return null !== (OO = null === (KO = await vK()) || void 0 === KO ? void 0 : KO.blockImageName(pO)) && void 0 !== OO ? OO : null
        }), (() => OO.blockImageUrl(pO)))
      }
    }

    function vK() {
      return (0, bK.q)().catch((() => null))
    }

    function CO(OO, KO, pO) {
      return hO(OO, (async () => {
        var OO;
        const pO = await vK(),
          XO = null === pO ? null : KO(pO),
          bK = null !== (OO = null === XO || void 0 === XO ? void 0 : XO.slice(XO.lastIndexOf("/") + 1)) && void 0 !== OO ? OO : null;
        return "Player_Atlas" === bK ? null : bK
      }), pO)
    }
    async function hO(OO, KO, pO) {
      if (null !== OO) {
        const pO = await KO(),
          XO = null === pO ? null : OO.textureUrl(pO);
        if (null !== XO) return XO
      }
      return pO()
    }
    const DO = 0;

    function MO(OO) {
      const KO = [XO.h.ArmourAtlas, XO.h.LifeformAtlas, XO.h.GroupAtlas, XO.h.BlockImage, XO.h.Particle];
      OO.reload(KO, (OO => {
        switch (OO.kind) {
          case XO.h.Particle:
            return OO.index === XO.j.Item;
          case XO.h.LifeformAtlas:
            return OO.word !== DO;
          default:
            return !0
        }
      }))
    }
  },
  38959: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      f: () => vK,
      i: () => lO,
      m: () => bK,
      n: () => eO
    });
    const XO = 1e3;

    function bK() {
      CO((() => {
        window.location.reload()
      }))
    }

    function eO() {
      return new Promise((() => {}))
    }

    function lO(OO) {
      CO((() => {
        window.location.replace(OO(window.location.href))
      }))
    }

    function vK(OO) {
      Promise.resolve().then((() => pO(105))).then((KO => {
        let {
          currentUrl: pO
        } = KO;
        lO((() => pO.mergeSearchParamsInto(OO)))
      }), (() => {
        lO((() => OO))
      }))
    }

    function CO(OO) {
      null !== window.onbeforeunload ? Promise.resolve().then((() => pO(1481))).then((KO => {
        let {
          prepareForUnloadWithoutConfirmation: pO
        } = KO;
        try {
          pO()
        } catch (XO) {
          console.warn("[bloxd-wasm-client] prepareForUnloadWithoutConfirmation threw: leaving plainly", XO), window.onbeforeunload = null
        }
        OO()
      }), (() => {
        window.onbeforeunload = null, OO()
      })) : OO()
    }
  },
  38979: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => eO
    });
    var XO = pO(5754);
    let bK = null;

    function eO(OO) {
      bK = {
        scanned: !1
      };
      try {
        return OO()
      } finally {
        bK = null
      }
    }

    function lO() {
      const OO = bK;
      if (null === OO) return (0, XO.f)();
      const KO = (0, XO.f)(!OO.scanned);
      return OO.scanned = !0, KO
    }
  },
  38771: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => bK
    });
    let XO = {
      fire: () => {},
      close: () => {}
    };

    function bK(OO) {
      XO = OO
    }

    function eO() {
      return XO
    }
  },
  39059: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => oO,
      d: () => vK,
      e: () => MO,
      i: () => aK,
      j: () => FO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(2265),
      lO = pO(8296);

    function vK() {
      var OO;
      const KO = (pO = XO.d.get("clientEscMenuOptions"), bK = (0, eO.k)(), {
        sampleCount: pO.antiAliasing ? 4 : 1,
        n: (0, eO.y)(pO.pixelScale, bK),
        pixelated: (0, eO.u)(pO.pixelSmoothing)
      });
      var pO, bK;
      return KO.sampleCount > 1 && (0, lO.b)() && (KO.sampleCount = 1), KO.n = null !== (OO = (0, lO.n)()) && void 0 !== OO ? OO : KO.n, KO
    }
    let CO = null;
    const hO = new Set;

    function DO() {
      if (null === CO) {
        const OO = document.createElement("div");
        OO.style.cssText = "position:fixed;top:0;right:0;bottom:0;left:0;visibility:hidden;pointer-events:none", OO.setAttribute("aria-hidden", "true"), document.body.append(OO), CO = new eO.c(OO, (() => {
          for (const OO of hO) OO()
        }))
      }
      return CO
    }

    function MO(OO) {
      const KO = (0, eO.k)(),
        [pO, XO] = DO().size(KO);
      return (0, eO.i)(pO, XO, KO, OO.n)
    }

    function aK(OO) {
      const KO = (0, eO.k)(),
        [pO, XO] = DO().size(KO);
      if (pO <= 0 || XO <= 0) return null;
      const bK = (0, eO.i)(pO, XO, KO, vK().n);
      return (0, eO.e)(OO, bK), bK
    }

    function oO(OO, KO) {
      OO.style.imageRendering = (0, eO.I)(KO.pixelated)
    }

    function FO(OO, KO) {
      const pO = (0, bK.j)("appManagerUpdated|clientEscMenuOptions", (() => {
          oO(OO, vK()), KO()
        })),
        XO = (0, lO.v)(KO);
      return DO(), hO.add(KO), () => {
        pO(), XO(), hO.delete(KO)
      }
    }
  },
  4169: (OO, KO, pO) => {
    function XO(OO, KO) {
      return bK(OO, KO)
    }

    function bK(OO, KO) {
      if (OO === KO) return !0;
      if ("object" !== typeof OO || "object" !== typeof KO || null === OO || null === KO || Array.isArray(OO) !== Array.isArray(KO)) return !1;
      const pO = OO,
        XO = KO,
        eO = Object.keys(pO);
      return eO.length === Object.keys(XO).length && eO.every((OO => Object.prototype.hasOwnProperty.call(XO, OO) && bK(pO[OO], XO[OO])))
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  39e3: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => dO,
      g: () => AO,
      k: () => FO,
      n: () => oO
    });
    var XO = pO(37447),
      bK = pO(5632),
      eO = pO(37444),
      lO = pO(38908),
      vK = pO(38917);
    const CO = {
        "X-Requested-With": "XMLHtttpRequest"
      },
      hO = 3,
      DO = [500, 1500];

    function MO(OO) {
      const KO = new URL(OO);
      return {
        secure: "https:" === KO.protocol || "wss:" === KO.protocol,
        host: KO.host,
        pathname: KO.pathname.replace(/\/+$/, ""),
        search: KO.searchParams.toString()
      }
    }

    function aK(OO, KO, pO) {
      const {
        secure: XO,
        host: bK,
        pathname: eO,
        search: lO
      } = MO(OO);
      return `${XO?"https":"http"}://${bK}${eO}/matchmake/${KO}/${encodeURIComponent(pO)}${lO?`?${lO}`:""}`
    }

    function oO(OO, KO) {
      var pO;
      const XO = null !== (pO = KO.protocol) && void 0 !== pO ? pO : "ws";
      if ("ws" !== XO) throw new Error(`seat reservation asks for the ${XO} transport`);
      const {
        secure: bK,
        host: eO,
        pathname: lO,
        search: vK
      } = MO(OO), CO = new URLSearchParams(vK);
      CO.append("sessionId", KO.sessionId), KO.reconnectionToken && CO.append("reconnectionToken", KO.reconnectionToken);
      return `${bK?"wss":"ws"}://${KO.room.publicAddress||`${eO}${lO}`}/${KO.room.processId}/${KO.room.roomId}?${CO.toString()}`
    }

    function FO(OO, KO, pO) {
      var lO;
      let CO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      const MO = null !== (lO = CO.sleep) && void 0 !== lO ? lO : XO.e;
      return (0, eO.c)((() => async function(OO, KO, pO, XO) {
        var eO;
        const {
          signal: lO,
          sleep: CO
        } = XO, MO = aK(OO, "joinOrCreate", KO), oO = JSON.stringify(pO);
        let FO = null;
        for (let aK = 0; aK < hO; aK++) {
          var zK;
          if (aK > 0) await CO(null !== (zK = DO[aK - 1]) && void 0 !== zK ? zK : 1500, lO);
          let OO;
          (0, bK.j)(lO);
          try {
            OO = await LO(MO, oO, XO)
          } catch (AO) {
            (0, bK.j)(lO), FO = VO(AO);
            continue
          }
          const {
            response: KO,
            answer: pO,
            refusal: eO,
            lost: hO
          } = OO;
          if (null === hO) {
            if (null !== eO) throw QO(eO, pO);
            if (KO.ok && null !== pO && TO(pO)) return pO;
            FO = new vK.o(`seat request answered HTTP ${KO.status}${null===pO?" without JSON":" without a seat"}`, !1)
          } else FO = VO(hO.error)
        }
        throw null !== (eO = FO) && void 0 !== eO ? eO : new vK.o("seat request made no attempt", !1)
      }(OO, KO, pO, {
        ...CO,
        sleep: MO
      })), CO.signal, MO)
    }

    function VO(OO) {
      return new vK.o(OO instanceof Error ? OO.message : String(OO), !0, OO)
    }
    async function LO(OO, KO, pO) {
      var XO;
      const {
        signal: eO
      } = pO, lO = null !== (XO = pO.fetch) && void 0 !== XO ? XO : fetch, vK = await lO(OO, {
        method: "POST",
        headers: {
          ...CO,
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: KO,
        credentials: "include",
        signal: eO
      }), {
        answer: hO,
        lost: DO
      } = await async function(OO) {
        try {
          const KO = await OO.json();
          return {
            answer: "object" === typeof KO && null !== KO ? KO : null,
            lost: null
          }
        } catch (KO) {
          return {
            answer: null,
            lost: KO instanceof SyntaxError ? null : {
              error: KO
            }
          }
        }
      }(vK), MO = null !== hO && "string" === typeof hO.error ? hO.error : null;
      var aK;
      null !== MO && (null === (aK = pO.onRefusal) || void 0 === aK || aK.call(pO));
      return (0, bK.j)(eO), {
        response: vK,
        answer: hO,
        refusal: MO,
        lost: DO
      }
    }

    function QO(OO, KO) {
      return new vK.h(OO, "number" === typeof(null === KO || void 0 === KO ? void 0 : KO.code) ? KO.code : 0, (0, lO.s)(OO).text)
    }
    class zK extends Error {
      constructor(OO, KO) {
        super(OO), this.code = KO, this.name = "SeatHttpError"
      }
    }
    async function AO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
      const {
        response: bK,
        answer: eO,
        refusal: lO,
        lost: vK
      } = await LO(aK(OO, "reconnect", KO), JSON.stringify({
        reconnectionToken: pO
      }), XO);
      if (null !== vK) throw vK.error;
      if (!bK.ok) {
        const OO = null !== eO && "number" === typeof eO.code && 0 !== eO.code ? eO.code : bK.status;
        throw new zK(`the seat's reconnect was refused: ${null!==lO&&void 0!==lO?lO:`HTTP ${bK.status}`}`, OO)
      }
      if (null !== lO) throw QO(lO, eO);
      if (null === eO || !TO(eO)) throw new Error("the seat's reconnect answered " + (null === eO ? "without JSON" : "without a seat"));
      return {
        ...eO,
        reconnectionToken: pO
      }
    }
    const fO = 10;

    function dO(OO) {
      if (OO.byteLength < 2 || OO[0] !== fO) return null;
      const KO = 2 + OO[1];
      return KO > OO.byteLength ? null : (new TextDecoder).decode(OO.subarray(2, KO))
    }

    function TO(OO) {
      const KO = OO.room;
      return "string" === typeof OO.sessionId && "object" === typeof KO && null !== KO && "string" === typeof KO.roomId && "string" === typeof KO.processId && "string" === typeof KO.name
    }
  },
  39114: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      g: () => eO,
      k: () => bK
    });
    let XO = null;

    function bK(OO) {
      XO = OO
    }

    function eO(OO) {
      XO === OO && (XO = null)
    }

    function lO() {
      var OO;
      null === (OO = XO) || void 0 === OO || OO()
    }
  },
  39096: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(39101),
      bK = pO(39089);
    const eO = new class {
      constructor(OO) {
        this.pack = OO, this.game = void 0, this.settle = null, this.hold = null, this.endedWhileHeld = !1, this.gameListeners = new Set, OO.onWanted((() => {
          this.release()
        }))
      }
      setGame(OO) {
        if (void 0 === OO && null !== this.hold) return void(this.endedWhileHeld = !0);
        this.hold = null, this.endedWhileHeld = !1;
        const KO = this.inGame();
        if (this.game = OO, this.update(), this.inGame() !== KO)
          for (const pO of this.gameListeners) pO()
      }
      inGame() {
        return void 0 !== this.game
      }
      onGameChange(OO) {
        return this.gameListeners.add(OO), () => {
          this.gameListeners.delete(OO)
        }
      }
      unwantedLeave(OO) {
        OO && void 0 !== this.game ? this.hold = {
          game: this.game
        } : this.release()
      }
      rejoinHold() {
        return this.hold
      }
      releaseHold(OO) {
        null !== OO && OO === this.hold && this.release()
      }
      release() {
        if (null === this.hold) return;
        const OO = this.endedWhileHeld;
        this.hold = null, this.endedWhileHeld = !1, OO && this.setGame(void 0)
      }
      setSettled(OO) {
        this.settle = OO, this.update()
      }
      update() {
        void 0 === this.game ? this.pack.setSessionFiles(void 0) : null !== this.settle && (0, XO.d)(this.settle.state, this.game) && this.pack.setSessionFiles(this.settle.files)
      }
    }(bK.d)
  },
  38950: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => QO,
      d: () => LO,
      g: () => dO
    });
    var XO = pO(5778),
      bK = pO(26),
      eO = pO(3576),
      lO = pO(3943),
      vK = pO(5771),
      CO = pO(38954);

    function hO(OO, KO) {
      const pO = (0, vK.e)(KO.variants);
      return OO.setShaderPack(pO.variantFlags, pO.hooks, pO.moduleCodes, (0, CO.B)(KO.layers), CO.m[KO.LX], KO.keepCircleShadows)
    }
    const DO = 0,
      MO = 1,
      aK = 2,
      oO = "shaderPack:failedToCompile",
      FO = new Set(["no_webgpu_api", "no_adapter", "software_adapter", "adapter_error", "start_no_adapter"]),
      VO = new Set(["not_requested", "off_after_loss", "gpu_class_webgl"]);

    function LO(OO, KO) {
      var pO;
      const XO = null !== (pO = null === OO || void 0 === OO ? void 0 : OO.reason) && void 0 !== pO ? pO : "none";
      return FO.has(XO) ? {
        messageKey: KO ? "shaderPack:failedWebGpuDisabledUntilRestart" : "shaderPack:failedNoWebGpu",
        noAdapter: !0
      } : "not_requested" === XO && "override" === (null === OO || void 0 === OO ? void 0 : OO.source) ? {
        messageKey: "shaderPack:failedRendererOverride",
        noAdapter: !1
      } : {
        messageKey: VO.has(XO) ? "shaderPack:failedWebGpuOff" : "shaderPack:failedNoWebGpu",
        noAdapter: !1
      }
    }
    class QO extends Error {
      constructor(OO) {
        super(`the shader pack can't run in this game: ${OO}`), this.messageKey = OO, this.name = "ShaderPackJoinError"
      }
    }
    const zK = "strict";
    class AO {
      constructor(OO) {
        this.deps = OO, this.pagePack = void 0, this.loaded = null, this.LX = zK, this.failedPolicies = new Set, this.failedModelPolicies = new Set, this.refused = !1, this.joined = !1, this.playing = !1, this.game = 0, this.failedWhileJoining = !1, this.offInThisGame = !1, this.couldntRun = null, this.modelsNotified = !1, this.pagePack = OO.load().catch((KO => (OO.warn("the shader pack could not load: the game draws without it", KO), {
          status: "none"
        }))).then((OO => (this.loaded = OO, "active" === OO.status && (this.handOverToPreviews(OO), null !== OO.harnessPolicy && (this.LX = OO.harnessPolicy, this.handOver())), OO)))
      }
      async join(OO) {
        this.DX();
        const KO = this.game,
          [pO, bK] = await Promise.all([this.pagePack, this.policyOf(OO)]);
        if (KO !== this.game || "none" === pO.status) return null;
        const eO = "active" === pO.status ? pO.pack.variants : pO.variants,
          lO = (0, XO.k)(eO, bK);
        if (lO && "active" === pO.status && null === this.deps.core) return this.joined = !0, this.offInThisGame = !0, this.couldntRun = this.deps.noWebGpu.messageKey, null;
        if (lO) {
          const OO = this.cantRun(pO, bK);
          if (null !== OO) return OO
        } else if ("blocked" === pO.status || null === this.deps.core) return null;
        return this.LX = bK, this.handOver(), lO && this.refused ? oO : (this.joined = !0, this.offInThisGame = !lO, null)
      }
      async replay(OO) {
        const KO = await this.join(OO);
        null === KO ? this.playable() : this.deps.failInGame(KO)
      }
      cantRun(OO, KO) {
        const {
          core: pO,
          noWebGpu: XO
        } = this.deps;
        if ("blocked" === OO.status) {
          return "shaderPack:failedUnchecked" === OO.messageKey && null === pO && XO.noAdapter ? XO.messageKey : OO.messageKey
        }
        return this.refused || this.failedPolicies.has(KO) ? oO : null
      }
      runsInJoinedGame() {
        return this.joined && !this.offInThisGame
      }
      couldntRunInJoinedGame() {
        return this.couldntRun
      }
      playable() {
        this.joined && !this.playing && (this.playing = !0, this.failedWhileJoining ? this.fail(oO) : (null !== this.couldntRun ? this.notify(eO.c, this.couldntRun) : this.offInThisGame && this.notify("shaderPack:offInThisGame"), this.failedModelPolicies.has(this.LX) && this.notifyModelFallback()))
      }
      DX() {
        this.game++, this.joined = !1, this.playing = !1, this.failedWhileJoining = !1, this.offInThisGame = !1, this.couldntRun = null, this.modelsNotified = !1
      }
      coreErrors(OO) {
        for (const {
            code: KO,
            detail: pO
          }
          of OO)
          if (KO === lO.f.RenderShaderPackNotRun) switch (255 & pO) {
            case DO:
              this.refused = !0, this.failed();
              break;
            case MO:
              this.failedPolicies.add(this.LX), this.failed();
              break;
            case aK:
              this.failedModelPolicies.add(this.LX), this.playing && this.notifyModelFallback()
          }
      }
      failed() {
        this.joined && !this.offInThisGame && (this.playing ? this.fail(oO) : this.failedWhileJoining = !0)
      }
      fail(OO) {
        this.DX(), this.deps.failInGame(OO)
      }
      notifyModelFallback() {
        this.modelsNotified || (this.modelsNotified = !0, this.notify("shaderPack:modelsWithoutPack"))
      }
      notify(OO, KO) {
        const pO = this.game;
        this.deps.notify(OO, (() => pO === this.game && this.joined), KO)
      }
      handOver() {
        var OO;
        const {
          core: KO
        } = this.deps;
        null !== KO && "active" === (null === (OO = this.loaded) || void 0 === OO ? void 0 : OO.status) && (hO(KO, {
          ...this.loaded.pack,
          LX: this.LX
        }) || (this.refused = !0, this.deps.warn("the core refused the shader pack: the games it runs in fail", null)))
      }
      handOverToPreviews(OO) {
        let {
          pack: KO,
          harnessPolicy: pO
        } = OO;
        const {
          previews: XO
        } = this.deps;
        null !== XO && hO(XO, {
          ...KO,
          LX: null !== pO && void 0 !== pO ? pO : zK
        })
      }
      policyOf(OO) {
        return this.deps.policyOf(OO).catch((OO => (this.deps.warn("the game's shader pack policy could not load: the policy of a game without one", OO), zK)))
      }
    }
    const fO = "wasmShaderPackNotice";

    function dO(OO, KO, pO, XO) {
      return bK.i.subscribe(fO, (OO => {
        let {
          translationKey: KO,
          stillCurrent: pO,
          reasonKey: XO
        } = OO;
        pO() && bK.i.pl("chat", (0, eO.f)(KO, XO))
      })), new AO({
        load: TO,
        policyOf: NO,
        core: OO,
        previews: KO,
        noWebGpu: pO,
        notify: (OO, KO, pO) => {
          const XO = {
            translationKey: OO,
            stillCurrent: KO,
            reasonKey: pO
          };
          bK.i.pl(fO, XO, !0)
        },
        failInGame: OO => {
          bK.i.pl(eO.d, OO)
        },
        warn: XO
      })
    }
    async function TO() {
      const [{
        shaderPackPage: OO,
        harnessShaderPackMode: KO
      }, {
        shaderPackTextures: XO
      }] = await Promise.all([pO.e(122).then((() => pO(37568))), pO.e(123).then((() => pO(5763)))]), bK = await OO.load();
      return "active" !== bK.status ? bK : {
        status: "active",
        pack: {
          variants: bK.pack.variants,
          layers: XO().layers,
          keepCircleShadows: bK.pack.keepCircleShadows
        },
        harnessPolicy: KO()
      }
    }
    async function NO(OO) {
      var KO;
      const [{
        harnessShaderPackMode: XO
      }, {
        getShaderPackPolicy: bK
      }] = await Promise.all([pO.e(122).then((() => pO(37568))), pO.e(78).then((() => pO(41309)))]);
      return null !== (KO = XO()) && void 0 !== KO ? KO : bK(OO)
    }
  },
  39083: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK,
      h: () => hO,
      i: () => eO,
      m: () => MO,
      p: () => DO,
      r: () => aK
    });
    var XO = pO(2951);
    class bK extends Error {
      constructor(OO, KO, pO) {
        super(`${"fetch"===OO?"fetching":"decoding"} ${KO} failed`, pO), this.stage = OO, this.source = KO, this.name = "ShellImageError"
      }
    }
    async function eO(OO) {
      let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : XO.y,
        eO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "none";
      if ("string" === typeof OO) try {
        KO = await pO(OO)
      } catch (lO) {
        throw new bK("fetch", OO, {
          cause: lO
        })
      } else KO = OO;
      try {
        const OO = new Blob([KO.slice()], {
          type: "image/png"
        });
        return await createImageBitmap(OO, {
          premultiplyAlpha: "none",
          colorSpaceConversion: "none",
          imageOrientation: eO
        })
      } catch (lO) {
        throw new bK("decode", "string" === typeof OO ? OO : `${KO.byteLength} bytes`, {
          cause: lO
        })
      }
    }
    let lO = null;
    const vK = new Map;
    let CO = 1;

    function hO(OO) {
      if (lO = OO, null !== OO) {
        for (const [KO, pO] of vK) OO.KaO(KO, pO);
        vK.clear()
      }
    }

    function DO(OO) {
      const KO = CO++;
      return lO ? lO.KaO(KO, OO) : vK.set(KO, OO), KO
    }
    async function MO(OO, KO, pO) {
      const XO = await eO(OO, KO, pO);
      return {
        id: DO(XO),
        width: XO.width,
        height: XO.height
      }
    }

    function aK(OO) {
      var KO;
      const pO = vK.get(OO);
      if (pO) return pO.close(), void vK.delete(OO);
      null === (KO = lO) || void 0 === KO || KO.taO(OO)
    }
  },
  39035: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK,
      f: () => LO,
      g: () => CO,
      h: () => hO,
      k: () => DO,
      m: () => aK
    });
    var XO = pO(39043),
      bK = pO(39047);
    const eO = "atlas:",
      lO = 3e4;
    class vK extends Error {
      constructor(OO, KO) {
        super(`fetching ${OO} answered HTTP ${KO}`), this.url = OO, this.status = KO, this.name = "TerrainTextureFetchError"
      }
    }

    function CO(OO) {
      if (!OO.startsWith(eO)) return null;
      const KO = Number(OO.slice(eO.length));
      return Number.isInteger(KO) && KO >= 0 ? KO : null
    }
    async function hO() {
      const OO = await pO.e(187).then((() => pO(33017)));
      return {
        atlasSheets: OO.blockAtlasUrls,
        texture: KO => {
          var pO, XO, eO;
          return null !== (pO = null !== (XO = null !== (eO = OO.animatedBlockTextures[KO]) && void 0 !== eO ? eO : OO.rotatedBlockTextures[KO]) && void 0 !== XO ? XO : bK.b[KO]) && void 0 !== pO ? pO : null
        }
      }
    }
    async function DO(OO) {
      const KO = new AbortController,
        pO = setTimeout((() => {
          KO.abort(new DOMException(`${OO} took over ${lO} ms`, "TimeoutError"))
        }), lO);
      let XO;
      try {
        const pO = await fetch(OO, {
          signal: KO.signal
        });
        if (!pO.ok) throw new vK(OO, pO.status);
        XO = await pO.blob()
      } finally {
        clearTimeout(pO)
      }
      const bK = await createImageBitmap(XO, {
        premultiplyAlpha: "none",
        colorSpaceConversion: "none"
      });
      try {
        return aK(bK)
      } finally {
        bK.close()
      }
    }
    const MO = 8192;

    function aK(OO) {
      const {
        width: KO,
        height: pO
      } = OO, bK = Math.max(1, Math.min(pO, MO)), eO = (0, XO.d)(KO, bK, {
        willReadFrequently: !0
      });
      if (!eO) throw new Error("no 2D context to read the texture back");
      eO.globalCompositeOperation = "copy";
      const lO = new Uint8Array(KO * pO * 4);
      for (let XO = 0; XO < pO; XO += bK) {
        const vK = Math.min(bK, pO - XO);
        eO.drawImage(OO, 0, XO, KO, vK, 0, 0, KO, vK), lO.set(eO.getImageData(0, 0, KO, vK).data, XO * KO * 4)
      }
      return {
        width: KO,
        height: pO,
        pixels: lO
      }
    }
    async function oO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : DO;
      const XO = [],
        bK = await Promise.all(OO.map((async OO => {
          var bK, lO;
          const vK = null !== (bK = null === (lO = KO.decoded) || void 0 === lO ? void 0 : lO.call(KO, OO)) && void 0 !== bK ? bK : null,
            hO = null === vK ? function(OO, KO) {
              if (OO.startsWith(eO)) {
                var pO;
                const XO = CO(OO);
                return null === XO ? null : null !== (pO = KO.atlasSheets[XO]) && void 0 !== pO ? pO : null
              }
              return KO.texture(OO)
            }(OO, KO) : null,
            DO = null !== vK && void 0 !== vK ? vK : null === hO ? null : pO(hO);
          if (null === DO) return XO.push({
            name: OO,
            url: hO,
            error: new Error(`no URL for terrain texture ${OO}`)
          }), null;
          try {
            const KO = await DO;
            if (KO.pixels.byteLength !== KO.width * KO.height * 4) throw new Error(`decoded ${KO.pixels.byteLength} bytes for ${KO.width}x${KO.height} texels`);
            return {
              name: OO,
              texture: KO
            }
          } catch (MO) {
            return XO.push({
              name: OO,
              url: hO,
              error: MO
            }), null
          }
        }))),
        lO = bK.filter((OO => null !== OO)),
        vK = new Uint32Array(2 * lO.length);
      lO.forEach(((OO, KO) => {
        let {
          texture: pO
        } = OO;
        vK[2 * KO] = pO.width, vK[2 * KO + 1] = pO.height
      }));
      return {
        handOver: {
          names: lO.map((OO => {
            let {
              name: KO
            } = OO;
            return KO
          })),
          textures: lO.map((OO => {
            let {
              texture: KO
            } = OO;
            return KO.pixels
          })),
          sizes: vK
        },
        failures: XO
      }
    }
    const FO = [2e3, 1e4, 3e4, 6e4, 12e4];

    function VO() {}
    class LO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : FO,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1048576;
        this.core = OO, this.retryMs = KO, this.keepBelow = pO, this.started = 0, this.landed = 0, this.current = null, this.restoring = null
      }
      async swap(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : hO,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        const XO = ++this.started,
          bK = {
            decode: pO.decode,
            wholeAtlas: pO.wholeAtlas
          };
        return this.loadAndHandOver(KO, bK, OO, (() => {
          var OO;
          return XO < this.landed || !1 === (null === (OO = pO.wanted) || void 0 === OO ? void 0 : OO.call(pO))
        }), {
          onTaken: (OO, pO) => {
            this.landed = XO;
            const eO = null !== OO && function(OO) {
              return OO.textures.reduce(((OO, KO) => OO + KO.byteLength), 0)
            }(OO) < this.keepBelow ? OO : null;
            this.current = {
              mine: XO,
              sources: KO,
              load: bK,
              Sp: eO,
              failed: pO
            }
          }
        })
      }
      restore(OO) {
        var KO;
        const pO = this.current;
        if (null === pO) return Promise.resolve(null);
        if ((null === (KO = this.restoring) || void 0 === KO ? void 0 : KO.mine) === pO.mine) return this.restoring.done;
        const XO = {
          mine: pO.mine,
          done: this.restoreLanded(pO, OO).finally((() => {
            this.restoring === XO && (this.restoring = null)
          }))
        };
        return this.restoring = XO, XO.done
      }
      async restoreLanded(OO, KO) {
        const pO = () => this.landed !== OO.mine,
          {
            Sp: XO
          } = OO;
        if (null !== XO) return this.stopped() ? null : this.core.setTerrainTextures(XO.names, XO.textures, XO.sizes);
        let bK = KO;
        for (let eO = 0;; eO++) {
          const KO = this.retryMs.at(eO),
            XO = {
              allOrNothingExcept: void 0 === KO ? void 0 : OO.failed
            },
            lO = await this.loadAndHandOver(OO.sources, OO.load, bK, pO, XO);
          if (!1 !== lO || void 0 === KO || this.stopped()) return lO;
          if (bK = VO, await new Promise((OO => {
              setTimeout(OO, KO)
            })), pO()) return null
        }
      }
      stopped() {
        return !0 === this.core.isStopped
      }
      async loadAndHandOver(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
        if (this.stopped()) return null;
        const eO = this.core.terrainTextureNames();
        var lO;
        if (0 === eO.length) return null === (lO = bK.onTaken) || void 0 === lO || lO.call(bK, null, new Set), !0;
        let vK;
        try {
          vK = await oO(eO, await OO(), KO.decode)
        } catch (FO) {
          return XO() ? null : (pO({
            name: null,
            url: null,
            error: FO
          }), !1)
        }
        if (XO() || this.stopped()) return null;
        for (const CO of vK.failures) pO(CO);
        const hO = bK.allOrNothingExcept;
        if (void 0 !== hO && vK.failures.some((OO => {
            let {
              name: KO
            } = OO;
            return null === KO || !hO.has(KO)
          })) || !0 === KO.wholeAtlas && vK.failures.some((OO => {
            let {
              name: KO
            } = OO;
            return null === KO || null !== CO(KO)
          }))) return !1;
        const {
          handOver: DO
        } = vK, MO = this.core.setTerrainTextures(DO.names, DO.textures, DO.sizes);
        if (MO) {
          var aK;
          const OO = new Set(vK.failures.flatMap((OO => {
            let {
              name: KO
            } = OO;
            return null === KO ? [] : [KO]
          })));
          null === (aK = bK.onTaken) || void 0 === aK || aK.call(bK, DO, OO)
        }
        return MO
      }
    }
  },
  38961: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => Hv,
      h: () => Pl,
      i: () => xv,
      k: () => Rv,
      o: () => rv,
      p: () => Le,
      s: () => Kv,
      u: () => Bv,
      x: () => El,
      A: () => lv,
      E: () => cC,
      G: () => Sl,
      I: () => Rl,
      J: () => jv,
      M: () => ul,
      N: () => ev
    });
    var XO = pO(536),
      bK = pO(886),
      eO = pO(171),
      lO = pO(1575),
      vK = pO(243),
      CO = pO(2947),
      hO = pO(34910),
      DO = pO(2951),
      MO = pO(37102),
      aK = pO(5754),
      oO = pO(38841),
      FO = pO(554),
      VO = pO(1163),
      LO = pO(1569),
      QO = pO(2981),
      zK = pO(2557);
    let AO = null;
    var fO = pO(1056),
      dO = pO(5632),
      TO = pO(37516),
      NO = pO(2666),
      IO = pO(59),
      yK = pO(236),
      gK = pO(233),
      uO = pO(38798),
      EO = pO(3929),
      jK = pO(3923);
    class YO {
      constructor(OO, KO) {
        this.showView = OO, this.holdForAd = KO
      }
      pointerUnlockRequestsChanged() {
        (0, uO.x)()
      }
      pointerLockDebugEntries() {
        return [{
          label: "Locked to the canvas",
          value: String((0, uO.n)())
        }]
      }
      setGameViewShown(OO) {
        this.showView(OO)
      }
      videoAdHold(OO, KO) {
        this.holdForAd(OO, KO)
      }
    }
    class wO {
      DX(OO) {
        ! function(OO) {
          if (null !== (0, VO.b)().websocketUrl) try {
            (0, jK.F)().leaveGame(OO)
          } finally {
            (0, VO.q)({
              websocketUrl: null
            })
          }
        }(OO)
      }
      isReplay() {
        return !1
      }
    }
    class iK {
      watchFrameStarts(OO) {
        return (0, jK.q)(OO)
      }
      watchFrames(OO) {
        return (0, jK.n)(OO)
      }
      watchTicks(OO) {
        return (0, jK.v)(OO)
      }
    }
    var rK = pO(1146),
      PO = pO(38968);

    function mK(OO) {
      return OO >= 0 ? Math.min(1, OO) : 0
    }

    function sO(OO, KO) {
      const {
        fade: pO
      } = OO;
      return null === pO || KO - pO.at >= pO.ms ? OO.volume : pO.from + (OO.volume - pO.from) * Math.max(0, (KO - pO.at) / pO.ms)
    }
    var HO = pO(38674);

    function RO(OO) {
      const KO = Object.entries(OO),
        pO = new Uint32Array(KO.length);
      let XO = 0;
      for (const [lO, [, vK]] of KO.entries()) pO[lO] = vK.length, XO += vK.length;
      const bK = new Float64Array(3 * XO);
      let eO = 0;
      for (const [, lO] of KO)
        for (const OO of lO) bK.set(OO, eO), eO += 3;
      return {
        blocks: KO.map((OO => {
          let [KO] = OO;
          return KO
        })).join("\0"),
        counts: pO,
        values: bK
      }
    }
    class SO {
      constructor(OO, KO) {
        this.core = OO, this.warn = KO, this.latest = 0
      }
      async feed() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : JO;
        const KO = ++this.latest;
        let pO;
        try {
          pO = await OO()
        } catch (XO) {
          return void(this.core.isStopped || KO !== this.latest || this.warn("the block colours didn't load, so block particles draw grey", XO))
        }
        KO === this.latest && (this.core.setBlockColours(pO) || this.core.isStopped || this.warn("the core refused the block colours: block particles draw grey"))
      }
    }
    async function JO() {
      return RO((await pO.e(187).then((() => pO(33017)))).averageColors)
    }
    var cK = pO(3934),
      BO = pO(3943),
      ZO = pO(38732),
      GO = pO(38973),
      qK = pO(38878),
      xK = pO(524),
      nO = pO(35512),
      WO = pO(518),
      tK = pO(256),
      kK = pO(38867);
    const UO = [3e4, 12e4, 3e5];
    class OK extends Error {}
    const KK = {
      mobTypes: xK.k,
      vehicleTypes: nO.b,
      mobAiStates: xK.g,
      playerPoses: WO.n
    };
    var pK = pO(38855),
      XK = pO(38976),
      bp = pO(38987),
      eK = pO(38995),
      lK = pO(2716),
      vp = pO(37427),
      CK = pO(3962),
      hK = pO(38917),
      DK = pO(1964);
    const MK = DK.u.KeysDisabled | DK.u.LookFrozen | DK.u.ClicksSuppressed,
      ap = lK.g;
    var oK = (0, eK.b)("resumingConn");
    class FK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now;
        this.shell = OO, this.now = KO, this.session = void 0, this.attempt = null, this.landed = null, this.initialInfoConn = 0, this.initialInfoOffer = !1, this.completedEarlyConn = 0, Object.defineProperty(this, oK, {
          writable: !0,
          value: 0
        }), this.drops = 0, this.session = new vp.e({
          reconnect: OO => this.reconnect(OO),
          isLive: () => OO.isLive(),
          onReconnected: KO => {
            this.landed = KO, OO.onReconnected(KO), this.landIfResumed()
          },
          onGaveUp: (KO, pO) => {
            this.abortAttempt(), OO.onGaveUp(KO, pO)
          },
          freeze: KO => {
            OO.QKO(KO), (0, CK.j)(MK, KO ? MK : 0, "reconnectFreeze")
          },
          releaseSeat: OO => {
            this.releaseSeat(OO)
          }
        })
      }
      isResuming() {
        return this.session.isResuming()
      }
      get resumingConn() {
        return (0, bp.c)(this, oK)[oK]
      }
      canHoldSeat() {
        return this.session.canHoldSeat()
      }
      onInitialInfo(OO) {
        let {
          conn: KO,
          graceMs: pO,
          sessionBased: XO,
          replayOffer: bK
        } = OO;
        this.session.onInitialInfo(pO, XO), this.isResuming() && (this.initialInfoConn = KO, this.initialInfoOffer = bK, this.landIfResumed())
      }
      onResumeComplete(OO) {
        0 !== OO && (OO === (0, bp.c)(this, oK)[oK] ? ((0, bp.c)(this, oK)[oK] = 0, this.session.onResumed()) : this.isResuming() && (this.completedEarlyConn = OO))
      }
      onDropped(OO) {
        this.drops++, this.landed = null, this.initialInfoConn = 0, this.initialInfoOffer = !1, this.completedEarlyConn = 0, (0, bp.c)(this, oK)[oK] = 0, this.session.onConnectionLost(OO)
      }
      DX() {
        this.session.DX(), this.dispose()
      }
      dispose() {
        this.abortAttempt(), this.landed = null, this.completedEarlyConn = 0, (0, bp.c)(this, oK)[oK] = 0, this.session.end()
      }
      reconnect(OO) {
        const KO = this.attempt;
        if (null !== KO && this.awaitingJoinRoom(KO)) return KO.result;
        this.abortAttempt();
        const pO = new AbortController,
          XO = this.drops,
          bK = {
            attachedAt: null
          },
          eO = this.shell.reconnect(OO, pO.signal, (() => {
            bK.attachedAt = this.now()
          })).then((OO => {
            if (this.clearAttempt(lO), this.drops !== XO) throw new Error("the resumed room dropped before its attempt settled");
            return OO
          }), (OO => {
            throw this.clearAttempt(lO), OO
          })),
          lO = {
            abort: pO,
            socket: bK,
            result: eO
          };
        return this.attempt = lO, eO
      }
      clearAttempt(OO) {
        this.attempt === OO && (this.attempt = null)
      }
      abortAttempt() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new DOMException("the reconnect attempt was given up", "AbortError");
        const KO = this.attempt;
        this.attempt = null, null === KO || void 0 === KO || KO.abort.abort(OO)
      }
      awaitingJoinRoom(OO) {
        const KO = OO.socket.attachedAt;
        return null !== KO && this.now() - KO < ap
      }
      releaseSeat(OO) {
        const KO = this.attempt,
          pO = null !== KO && this.awaitingJoinRoom(KO);
        this.abortAttempt(new hK.k), pO || this.shell.releaseSeat(OO)
      }
      landIfResumed() {
        const OO = this.landed;
        if (null !== OO && OO.conn === this.initialInfoConn) {
          const KO = this.initialInfoOffer && this.completedEarlyConn !== OO.conn;
          if (this.landed = null, this.initialInfoConn = 0, this.initialInfoOffer = !1, this.completedEarlyConn = 0, this.abortAttempt(), !KO) return void this.session.onResumed();
          (0, bp.c)(this, oK)[oK] = OO.conn, this.session.onResuming()
        }
      }
    }
    var VK = pO(37435),
      LK = pO(39e3),
      QK = pO(38939),
      zp = pO(38933),
      AK = pO(4160),
      fK = pO(8301),
      dK = pO(2553),
      TK = pO(38805),
      NK = pO(561),
      IK = pO(3697),
      yp = pO(36),
      gp = pO(39002),
      uK = pO(3635),
      EK = pO(1969),
      jp = pO(22),
      YK = pO(26),
      wK = pO(1441),
      ip = pO(1136),
      rp = pO(107),
      PK = pO(1973),
      mp = pO(3955);
    const sK = new Set([cK.zb.KeyDown, cK.zb.MouseMove, cK.zb.MouseDown, cK.zb.Wheel, cK.zb.TouchStart, cK.zb.TouchMove]);

    function HK(OO) {
      return (OO.shiftKey ? cK.Hb.Shift : 0) | (OO.ctrlKey ? cK.Hb.Ctrl : 0) | (OO.altKey ? cK.Hb.Alt : 0) | (OO.metaKey ? cK.Hb.Meta : 0) | ("repeat" in OO && OO.repeat ? cK.Hb.Repeat : 0) | (OO.isTrusted ? 0 : cK.Hb.Untrusted)
    }

    function RK(OO) {
      return "touchOnly" !== (0, rp.c)() && "function" === typeof OO.requestPointerLock
    }

    function SK(OO) {
      return 0 === OO.button ? OO.altKey ? mp.i["Alt+Left Click"] : mp.i.Mouse1 : 1 === OO.button ? mp.i.Mouse2 : mp.i.Mouse3
    }
    const JK = new Set(["AltLeft", "AltRight", "ArrowUp", "ArrowDown"]),
      cp = new Map([
        ["AltLeft", "altKey"],
        ["AltRight", "altKey"],
        ["ControlLeft", "ctrlKey"],
        ["ControlRight", "ctrlKey"],
        ["ShiftLeft", "shiftKey"],
        ["ShiftRight", "shiftKey"],
        ["MetaLeft", "metaKey"],
        ["MetaRight", "metaKey"]
      ]),
      BK = 32768,
      ZK = 1;

    function GK(OO) {
      return Math.min(Math.max(Math.round(OO), 0), 65535)
    }

    function qp(OO, KO, pO) {
      const XO = [],
        bK = (OO, KO, pO, bK) => {
          const eO = pO;
          OO.addEventListener(KO, eO, bK), XO.push((() => {
            OO.removeEventListener(KO, eO, bK)
          }))
        },
        eO = {
          capture: !0,
          passive: !0
        },
        lO = (OO, pO, XO, bK, eO) => (!(0, PK.b)() || !sK.has(OO)) && (KO(OO, pO, XO, bK, eO), !0),
        vK = () => document.pointerLockElement === OO,
        CO = function() {
          try {
            return window.self !== window.top
          } catch {
            return !0
          }
        }(),
        hO = OO => {
          OO.ctrlKey && pO.ctrlCombosAreGames() && !(0, CK.f)(OO.target) && OO.preventDefault()
        },
        DO = (OO, XO, bK) => {
          pO.inspect(OO, XO, !1), KO(cK.zb.KeyUp, XO, 0, 0, (0, EK.o)(bK, OO.timeStamp)), pO.keyReleased(XO)
        },
        MO = new Map,
        aK = (OO, KO, pO) => OO[pO] || ("AltRight" === KO || "ControlLeft" === KO) && OO.getModifierState("AltGraph"),
        oO = new Map,
        FO = () => {
          MO.clear(), oO.clear()
        },
        VO = OO => {
          if (document.hasFocus())
            for (const [KO, pO] of oO) oO.delete(KO), aK(OO, KO, pO) || (MO.delete(KO), DO(OO, mp.i[KO], HK(OO)))
        };
      OO.tabIndex = -1;
      let LO = 0,
        QO = 0;
      const zK = () => {
        const KO = OO.getBoundingClientRect();
        LO = KO.left, QO = KO.top
      };
      let AO = "mouse";
      const fO = () => !vK() && ("mouse" === AO || !pO.touchUiShown()),
        dO = (OO, KO, pO) => {
          const XO = (GK(OO.clientX - LO) | GK(OO.clientY - QO) << 16) >>> 0;
          lO(cK.zb.MouseMove, cK.Jb.Point, KO, pO, XO)
        };
      let TO = !1,
        NO = 0;
      const IO = () => {
        TO && (TO = !1, pO.viewShown() && (0, uO.K)())
      };
      XO.push((() => {
        clearTimeout(NO)
      })), bK(window, "keydown", (OO => {
        "Escape" === OO.key ? (0, uO.C)(!0) : OO.repeat || (0, CK.f)(OO.target) || (TO = !0, clearTimeout(NO), NO = window.setTimeout(IO, 0))
      }), eO), bK(window, "keydown", (OO => {
        IO(), hO(OO), VO(OO);
        const KO = mp.i[OO.code];
        if ("number" !== typeof KO || !pO.viewShown()) return;
        const XO = (0, CK.f)(OO.target);
        XO || !pO.prevents(KO) && !JK.has(OO.code) || OO.preventDefault(), OO.repeat || pO.inspect(OO, KO, !0), lO(cK.zb.KeyDown, KO, 0, 0, (0, EK.o)(HK(OO), OO.timeStamp)) && MO.set(OO.code, KO), XO || pO.keyPressed(KO)
      }), {
        capture: !1,
        passive: !1
      }), bK(window, "keyup", (OO => {
        "Escape" === OO.key && (0, uO.C)(!1), hO(OO), MO.delete(OO.code), oO.delete(OO.code), VO(OO);
        const KO = mp.i[OO.code];
        "number" === typeof KO && DO(OO, KO, HK(OO))
      }), {
        capture: !0,
        passive: !1
      }), bK(window, "mousemove", (OO => {
        "mouse" === AO && fO() ? dO(OO, OO.movementX, OO.movementY) : vK() ? lO(cK.zb.MouseMove, cK.Jb.Stamped, OO.movementX, OO.movementY, (0, EK.o)(0, OO.timeStamp)) : lO(cK.zb.MouseMove, 0, OO.movementX, OO.movementY, 0)
      }), eO);
      let yK = 0,
        gK = 0;
      const EO = [];
      let jK = !1,
        YO = !1;
      bK(OO, "mousedown", (OO => {
        if ((0, PK.b)()) return;
        VO(OO);
        const XO = 1 << OO.button;
        if (!vK() && (0, uO.I)() && (0, uO.c)() && (YO = !0, !jK)) return void(yK |= XO);
        yK &= ~XO;
        const bK = OO.button <= 2 ? SK(OO) : void 0;
        void 0 !== bK && (EO[OO.button] = bK, pO.inspect(OO, bK, !0)), fO() && dO(OO, 0, 0), KO(cK.zb.MouseDown, OO.button, OO.clientX, OO.clientY, (0, EK.o)(HK(OO), OO.timeStamp)), gK |= XO, void 0 !== bK && pO.keyPressed(bK)
      }), eO), bK(window, "mouseup", (OO => {
        var XO;
        VO(OO);
        const bK = 1 << OO.button,
          eO = 0 !== (yK & ~gK & bK);
        if (yK &= ~bK, gK &= ~bK, eO) return;
        const lO = OO.button <= 2 ? null !== (XO = EO[OO.button]) && void 0 !== XO ? XO : SK(OO) : void 0;
        void 0 !== lO && pO.inspect(OO, lO, !1), KO(cK.zb.MouseUp, OO.button, OO.clientX, OO.clientY, (0, EK.o)(HK(OO), OO.timeStamp)), void 0 !== lO && pO.keyReleased(lO)
      }), eO), bK(OO, "contextmenu", (OO => {
        OO.preventDefault()
      }), {
        passive: !1
      });
      const wO = OO => {
        (vK() || (0, uO.l)() && (0, ip.l)()) && (OO.ctrlKey || CO && !document.fullscreenElement) && OO.preventDefault()
      };
      bK(OO, "wheel", (OO => {
        wO(OO), VO(OO), lO(cK.zb.Wheel, OO.deltaMode, OO.deltaX, OO.deltaY, 0)
      }), {
        capture: !0,
        passive: !1
      });
      const iK = {
          capture: !0,
          passive: !1
        },
        rK = OO => {
          OO ? window.addEventListener("wheel", wO, iK) : window.removeEventListener("wheel", wO, iK)
        };
      rK((0, uO.l)()), XO.push((0, uO.s)(rK)), XO.push((() => {
        rK(!1)
      }));
      const PO = new Map,
        mK = new Set,
        sO = OO => {
          const KO = "stylus" === OO.touchType;
          for (const pO of PO.values())
            if (!pO.touched && (KO || Math.abs(OO.clientX - pO.x) <= ZK && Math.abs(OO.clientY - pO.y) <= ZK)) return pO.touched = !0, !0;
          return !1
        },
        HO = OO => 32767 & OO,
        RO = new Set,
        SO = OO => pO => {
          const XO = (0, EK.o)(HK(pO), pO.timeStamp);
          OO !== cK.zb.TouchStart && OO !== cK.zb.TouchMove || ((OO, pO) => {
            const XO = OO.touches;
            if (XO)
              for (const bK of RO) {
                let OO = !1;
                for (let KO = 0; KO < XO.length && !OO; KO++) OO = HO(XO[KO].identifier) === bK;
                OO || (RO.delete(bK), KO(cK.zb.TouchCancel, bK, 0, 0, pO))
              }
          })(pO, XO);
          const bK = pO.changedTouches;
          for (let KO = 0; KO < bK.length; KO++) {
            const pO = bK[KO];
            if (OO === cK.zb.TouchStart && sO(pO) && mK.add(pO.identifier), mK.has(pO.identifier)) {
              OO !== cK.zb.TouchEnd && OO !== cK.zb.TouchCancel || mK.delete(pO.identifier);
              continue
            }
            const eO = HO(pO.identifier),
              vK = lO(OO, eO, pO.clientX, pO.clientY, XO);
            OO === cK.zb.TouchStart ? vK && RO.add(eO) : OO !== cK.zb.TouchMove && RO.delete(eO)
          }
        },
        JO = SO(cK.zb.TouchStart);
      bK(OO, "touchstart", (OO => {
        OO.preventDefault(), (0, PK.b)() || (pO.touchStarting(), JO(OO))
      }), {
        passive: !1
      }), bK(OO, "touchmove", SO(cK.zb.TouchMove), eO), bK(OO, "touchend", SO(cK.zb.TouchEnd), eO), bK(OO, "touchcancel", SO(cK.zb.TouchCancel), eO);
      const BO = OO => BK | 32767 & OO,
        ZO = (OO, KO) => {
          lO(OO, BO(KO.pointerId), KO.clientX, KO.clientY, (0, EK.o)(HK(KO), KO.timeStamp))
        };
      bK(window, "pointerdown", (KO => {
        AO = KO.pointerType, "mouse" === KO.pointerType && KO.target !== OO && pO.viewShown() && (0, uO.N)()
      }), eO), bK(OO, "pointerdown", (OO => {
        "pen" === OO.pointerType && 0 === OO.button && (0, uO.l)() && (0, ip.l)() && (OO.preventDefault(), (0, PK.b)() || (PO.set(OO.pointerId, {
          x: OO.clientX,
          y: OO.clientY,
          touched: !1
        }), pO.touchStarting(), ZO(cK.zb.TouchStart, OO)))
      }), {
        passive: !1
      }), bK(window, "pointermove", (OO => {
        AO = OO.pointerType, PO.has(OO.pointerId) && ZO(cK.zb.TouchMove, OO), "mouse" !== OO.pointerType && fO() && dO(OO, 0, 0)
      }), eO);
      const GO = OO => KO => {
        PO.delete(KO.pointerId) && ZO(OO, KO)
      };
      bK(window, "pointerup", GO(cK.zb.TouchEnd), eO), bK(window, "pointercancel", GO(cK.zb.TouchCancel), eO);
      let qK = 0;
      const xK = () => {
          qK = 0, zK(), pO.resized()
        },
        nO = () => {
          const OO = pO.sizeCanvas();
          null !== OO && KO(cK.zb.Resize, 0, OO.cssWidth, OO.cssHeight, (0, EK.i)(OO.renderScale)), zK(), pO.resized(), 0 === qK && (qK = requestAnimationFrame(xK))
        };
      bK(window, "resize", nO, eO), XO.push(pO.watchRenderScale(nO)), XO.push((() => {
        cancelAnimationFrame(qK)
      })), bK(window, "focus", (OO => {
        OO.isTrusted && (KO(cK.zb.Focus, 0, 0, 0, 0), pO.viewShown() && (0, uO.N)())
      }), {
        passive: !0
      });
      const WO = () => {
          (0, uO.C)(!1), yK = 0
        },
        tK = () => {
          RO.clear(), PO.clear(), mK.clear()
        };
      let kK = 0,
        UO = 0;
      bK(window, "blur", (XO => {
        WO(), (0, uO.h)();
        for (const OO of MO.keys()) {
          const KO = cp.get(OO);
          void 0 !== KO && oO.set(OO, KO)
        }
        XO.isTrusted && ((OO => {
          for (const [pO, XO] of PO) KO(cK.zb.TouchCancel, BO(pO), XO.x, XO.y, (0, EK.o)(0, OO));
          PO.clear()
        })(XO.timeStamp), KO(cK.zb.Blur, cK.t.KeepTouches, 0, 0, 0)), CO && XO.isTrusted && (clearTimeout(UO), UO = window.setTimeout((() => {
          if (!document.hasFocus()) {
            for (const OO of MO.values()) DO(XO, OO, 0);
            FO()
          }
        }), 0)), clearTimeout(kK), kK = window.setTimeout((() => {
          document.activeElement instanceof HTMLIFrameElement && (0, ip.l)() && pO.viewShown() && OO.focus({
            preventScroll: !0
          })
        }), 0)
      }), {
        passive: !0
      }), XO.push((() => {
        clearTimeout(kK), clearTimeout(UO)
      })), bK(window, "mousedown", (KO => {
        CO && KO.isTrusted && !document.hasFocus() && (0, ip.l)() && pO.viewShown() && (window.focus(), OO.focus({
          preventScroll: !0
        }))
      }), eO), bK(document, "visibilitychange", (() => {
        document.hidden ? (KO(cK.zb.Blur, 0, 0, 0, 0), tK()) : document.hasFocus() && KO(cK.zb.Focus, 0, 0, 0, 0)
      }), {
        passive: !0
      }), XO.push((0, PK.h)((() => {
        WO(), KO(cK.zb.Blur, cK.t.Release, 0, 0, 0), pO.keysReleased(), FO(), gK = 0, tK(), KO(cK.zb.Joystick, 0, 0, 0, 0), document.hasFocus() && KO(cK.zb.Focus, 0, 0, 0, 0)
      })));
      const OK = !pO.canLock(),
        KK = () => OK && !(0, uO.l)() ? cK.gc.Lockless : cK.gc.Released,
        pK = () => {
          vK() && (jK = !1, YO = !1), KO(cK.zb.PointerLock, vK() ? cK.gc.Locked : KK(), 0, 0, 0), (0, uO.G)(vK())
        };
      return bK(document, "pointerlockchange", pK, {
        passive: !0
      }), bK(document, "pointerlockerror", (() => {
        jK ||= YO, YO = !1, (0, uO.q)()
      }), {
        passive: !0
      }), OK && XO.push((0, uO.s)((() => {
        KO(cK.zb.PointerLock, KK(), 0, 0, 0)
      }))), nO(), KO(document.hasFocus() ? cK.zb.Focus : cK.zb.Blur, 0, 0, 0, 0), pK(), () => {
        for (const OO of XO.splice(0)) OO()
      }
    }
    var xp = pO(39059),
      nK = pO(8296),
      WK = pO(1599);
    const tp = new Map(mp.e.map(((OO, KO) => [OO, KO]))),
      kp = ["jump", "primary-fire", "alt-fire"],
      UK = ["primary-fire", "alt-fire"];

    function Op(OO) {
      return `${WK.e}${OO}`
    }
    const Kp = ["forward", "backward", "left", "right", "sprint", "jump"];

    function pp(OO) {
      const KO = [];
      for (const pO of OO) {
        const OO = "string" === typeof pO ? mp.i[pO] : void 0;
        "number" === typeof OO && KO.push(OO)
      }
      return KO
    }
    class Xp {
      constructor() {
        this.keys = new Map, this.preventKeys = new Set, this.movementKeys = new Set, this.checkedDown = new Set, this.checkedUp = new Set;
        for (const [OO, KO] of Object.entries(mp.f)) this.keys.set(OO, KO);
        this.updateKeySets()
      }
      prevents(OO) {
        return this.preventKeys.has(OO)
      }
      moves(OO) {
        return this.movementKeys.has(OO)
      }
      checks(OO, KO) {
        return (KO ? this.checkedDown : this.checkedUp).has(OO)
      }
      sync(OO, KO) {
        for (const [pO, XO] of this.keys) {
          const bK = OO(Op(pO)),
            eO = Array.isArray(bK) ? pp(bK) : mp.f[pO];
          (eO.length !== XO.length || eO.some(((OO, KO) => OO !== XO[KO]))) && this.bind(pO, eO, KO)
        }
      }
      bind(OO, KO, pO) {
        const XO = tp.get(OO);
        if (void 0 !== XO) {
          pO(cK.zb.Binding, 0, 0, 0, XO | cK.p.Clear << 8);
          for (const eO of [...KO, ...null !== (bK = mp.g[OO]) && void 0 !== bK ? bK : []]) {
            var bK;
            pO(cK.zb.Binding, eO, 0, 0, XO | cK.p.Add << 8)
          }
          this.keys.set(OO, KO), this.updateKeySets()
        }
      }
      updateKeySets() {
        this.preventKeys.clear();
        for (const XO of mp.m)
          for (const KO of null !== (OO = this.keys.get(mp.e[XO])) && void 0 !== OO ? OO : []) {
            var OO;
            this.preventKeys.add(KO)
          }
        this.movementKeys.clear();
        for (const XO of Kp)
          for (const OO of null !== (KO = this.keys.get(XO)) && void 0 !== KO ? KO : []) {
            var KO;
            this.movementKeys.add(OO)
          }
        for (const [XO, bK] of [
            [this.checkedDown, kp],
            [this.checkedUp, UK]
          ]) {
          XO.clear();
          for (const OO of bK)
            for (const KO of null !== (pO = this.keys.get(OO)) && void 0 !== pO ? pO : []) {
              var pO;
              XO.add(KO)
            }
        }
      }
    }
    var bX = pO(3952),
      ep = pO(35075);
    const lp = "[bloxd-wasm-client]";

    function vX() {
      return "inGame" === jp.d.get("gameState") && !(0, wK.l)()
    }
    let Cp = null;

    function hp(OO, KO) {
      Cp && KO.writePendingInput() && Cp.push(function(OO, KO) {
        let pO = "";
        for (const XO of KO) pO += XO.toString(16).padStart(2, "0");
        return pO ? `${OO} ${pO}` : String(OO)
      }(OO, KO.rings.input.written()))
    }
    const Dp = [];

    function Mp(OO, KO, pO, XO) {
      OO === cK.V.InputAction && XO === cK.tb && Dp.push(KO.getUint32(pO, !0))
    }
    var aX = pO(39064),
      op = pO(1054),
      Fp = pO(39050);
    const Vp = {
      general: {
        ok: "OK",
        tryAgain: "Try Again",
        back: "Back",
        reload: "Reload",
        reconnect: "Rejoin"
      },
      wasmScreens: op.wasmScreens
    };

    function Lp(OO) {
      var KO, pO;
      let XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      const [bK, eO] = OO.split(":");
      return (null !== (KO = null === (pO = Vp[bK]) || void 0 === pO ? void 0 : pO[eO]) && void 0 !== KO ? KO : OO).replace(/\{\{(\w+)\}\}/g, ((OO, KO) => {
        var pO;
        return null !== (pO = XO[KO]) && void 0 !== pO ? pO : OO
      }))
    }

    function Qp(OO, KO) {
      (0, uK.c)();
      const pO = document.createElement("div");
      pO.setAttribute("role", "alertdialog"), pO.style.cssText = "position:fixed;top:0;right:0;bottom:0;left:0;z-index:100;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.7);font:16px sans-serif;color:#fff";
      const XO = document.createElement("div");
      XO.style.cssText = "max-width:28rem;padding:1.5rem;border-radius:8px;background:#1c2333;text-align:center";
      const bK = document.createElement("h2");
      bK.textContent = Lp(OO.title);
      const eO = document.createElement("p");
      if (eO.textContent = Lp(OO.help, OO.helpValues), eO.style.whiteSpace = "pre-line", XO.append(bK, eO), OO.discordLink) {
        const OO = document.createElement("a");
        OO.href = Fp.c, OO.target = "_blank", OO.rel = "noreferrer", OO.style.color = "#8ab4ff", OO.textContent = Lp("wasmScreens:reportOnDiscord"), XO.append(OO)
      }
      const lO = document.createElement("div");
      return lO.style.cssText = "display:flex;gap:1rem;justify-content:center;margin-top:1.5rem", XO.append(lO), pO.append(XO), document.body.append(pO), new Promise((XO => {
        const bK = OO => {
            null === KO || void 0 === KO || KO.removeEventListener("abort", eO), pO.remove(), XO(OO)
          },
          eO = () => {
            bK(!1)
          };
        null === KO || void 0 === KO || KO.addEventListener("abort", eO, {
          once: !0
        });
        const vK = (OO, KO) => {
          const pO = document.createElement("button");
          pO.textContent = Lp(OO), pO.style.cssText = "padding:0.5rem 1.25rem;font:inherit", pO.addEventListener("click", (() => {
            bK(KO)
          })), lO.append(pO)
        };
        null !== OO.cancel && vK(OO.cancel, !1), vK(OO.confirm, !0)
      }))
    }
    var zX = pO(226),
      Ap = pO(94),
      fp = pO(127);
    const dp = new Set(["android", "ios"]);

    function Tp(OO, KO, pO) {
      const XO = function(OO, KO, pO) {
        const XO = "software_adapter" === OO.reason ? null : OO.adapter,
          bK = null === XO || "" === XO.vendor ? null : (0, zX.g)(XO.vendor, XO.architecture);
        if (null !== bK && "other_intel" !== bK) return bK;
        if (dp.has(KO)) return null;
        const eO = pO();
        return null === eO ? null : (0, zX.h)(eO.vendor, eO.renderer)
      }(OO, KO, pO);
      return null !== XO && FO.d.has(XO) ? XO : null
    }

    function Np() {
      let OO = null;
      try {
        var KO, pO, XO, bK;
        const eO = document.createElement("canvas"),
          lO = {
            powerPreference: fp.d
          };
        OO = null !== (KO = eO.getContext("webgl2", lO)) && void 0 !== KO ? KO : eO.getContext("webgl", lO);
        const vK = null === (pO = OO) || void 0 === pO ? void 0 : pO.getExtension("WEBGL_debug_renderer_info");
        if (!OO || !vK) return null;
        const CO = String(null !== (XO = OO.getParameter(vK.UNMASKED_RENDERER_WEBGL)) && void 0 !== XO ? XO : "");
        return "" === CO ? null : {
          vendor: String(null !== (bK = OO.getParameter(vK.UNMASKED_VENDOR_WEBGL)) && void 0 !== bK ? bK : ""),
          renderer: CO
        }
      } catch {
        return null
      } finally {
        try {
          var eO, lO;
          null === (eO = OO) || void 0 === eO || null === (lO = eO.getExtension("WEBGL_lose_context")) || void 0 === lO || lO.loseContext()
        } catch {}
      }
    }
    var Ip = pO(38908);
    const yX = 6e4,
      gX = 3e5;
    var upO = pO(2898),
      Ep = pO(38959);
    var jX = pO(38800),
      Yp = pO(570),
      wp = pO(9);

    function iX(OO, KO) {
      const pO = wp.Y.encode(KO);
      ! function(OO, KO) {
        let pO = KO >= 0 ? 2 * KO : 2 * -KO - 1;
        for (; pO >= 128;) OO.push(pO % 128 | 128), pO = Math.floor(pO / 128);
        OO.push(pO)
      }(OO, pO.length);
      for (const XO of pO) OO.push(XO)
    }
    let rX, Pp, mX;
    (() => {
      const OO = ["length", 0, 1, void 0, "b", 9, 11, "e", "a", 1023, 3, 56, 227, 65536, "d", 195, 10, 55296, 56320, 2, 69, 6, 12, 63, 128, "c", 4, 163, 72, 192, 211, "Invalid byte index", 175, 255, 224, 31, "Invalid continuation byte", 240, 15, 7, 18, !1, "p", 8, "g", 234, 40, 147, 132, 182, 222, "resolv", "then", 197, 56319, 64512, 189, 65535, 137, 57343, "Lone s", "urroga", "te U+", 16, 4294967168, 4294965248, 4294901760, 4292870144, 174, 215, 196, 2048, 248, 111, 1114111, "Invalid UTF-8 detected", 178, "3.0.0", "undefi", "ned", null, "postCo", "okies", 118, 193, 120, 123, "M2EaqF", "C", 512, "012345", 208, 89, 58, 77, 244, 32, 5, 24, 19, 64, 73, 116, 143, 125, "f", 117, 230, 166, 105];

      function KO() {}
      const XO = (0, wp[OO[42]])("aGFyZHdhcmVDb25jdXJyZW5jeQ=="),
        bK = (0, wp[OO[42]])("QkFCWUxPTg=="),
        eO = (0, wp[OO[42]])("QW5kZXNpdGU="),
        lO = (0, wp[OO[42]])("U21vb3RoIEdyYW5pdGU="),
        vK = (0, wp[OO[42]])("RGlvcml0ZQ=="),
        CO = async (XO, bK, eO, lO) => {
          "hsUy6G" in KO && function(...KO) {
            DO(KO[OO[0]] = OO[1], KO[OO[48]] = function(...KO) {
              if (DO(KO[OO[0]] = OO[2], KO[OO[8]] = KO[OO[1]].length), KO[OO[8]] < OO[19]) return OO[1];
              if (DO(KO[OO[4]] = Math.max(...KO[OO[1]]), KO[OO[25]] = Math.min(...KO[OO[1]])), KO[OO[4]] === KO[OO[25]]) return OO[1];
              for (DO(KO[OO[14]] = Array(KO[OO[8]] - OO[2]).fill(Number.MAX_SAFE_INTEGER), KO[OO[46]] = Array(KO[OO[8]] - OO[2]).fill(Number.MIN_SAFE_INTEGER), KO[-OO[45]] = Math.ceil((KO[OO[4]] - KO[OO[25]]) / (KO[OO[8]] - OO[2])), KO[OO[44]] = OO[1]), KO[OO[43]] = OO[1]; KO[OO[43]] < KO[OO[8]]; KO[OO[43]]++) KO[OO[1]][KO[OO[43]]] !== KO[OO[25]] && KO[OO[1]][KO[OO[43]]] !== KO[OO[4]] && DO(KO[OO[44]] = Math.floor((KO[OO[1]][KO[OO[43]]] - KO[OO[25]]) / KO[-OO[45]]), KO[OO[14]][KO[OO[44]]] = Math.min(KO[OO[14]][KO[OO[44]]], KO[OO[1]][KO[OO[43]]]), KO[OO[46]][KO[OO[44]]] = Math.max(KO[OO[46]][KO[OO[44]]], KO[OO[1]][KO[OO[43]]]));
              for (DO(KO[OO[5]] = Number.MIN_SAFE_INTEGER, KO[OO[47]] = KO[OO[25]]), KO[OO[6]] = OO[1]; KO[OO[6]] < KO[OO[8]] - OO[2]; KO[OO[6]]++) KO[OO[14]][KO[OO[6]]] === Number.MAX_SAFE_INTEGER && KO[OO[46]][KO[OO[6]]] === Number.MIN_SAFE_INTEGER || DO(KO[OO[5]] = Math.max(KO[OO[5]], KO[OO[14]][KO[OO[6]]] - KO[OO[47]]), KO[OO[47]] = KO[OO[46]][KO[OO[6]]]);
              return KO[OO[5]] = Math.max(KO[OO[5]], KO[OO[4]] - KO[OO[47]]), KO[OO[5]]
            }, console.log(KO[OO[48]]))
          }();
          const [{
            clientSideServerUrls: vK
          }, {
            postJsonWithMetricsCookiesAndJsonResponse: CO
          }] = await Promise.all([Promise[OO[51] + OO[7]]()[OO[52]](((...XO) => (XO[OO[0]] = OO[1], "GFtNaa" in KO && function(...KO) {
            DO(KO[OO[0]] = OO[1], KO[-OO[50]] = function(...pO) {
              return DO(pO[OO[0]] = OO[19], pO[OO[8]] = [], pO[OO[4]] = pO[OO[1]].length, pO[OO[1]].sort(((OO, KO) => OO - KO)), KO[OO[49]](pO[OO[8]], [], OO[1], pO[OO[4]], pO[OO[1]], pO[OO[2]])), pO[OO[8]]
            }, KO[OO[49]] = function(pO, XO, bK, eO, lO, vK) {
              var CO, hO = OO[80];
              if (!(vK < OO[1])) {
                if (vK === OO[1]) return pO.push(XO);
                for (CO = bK; CO < eO && !(lO[CO] > vK); CO++) CO > bK && lO[CO] === lO[CO - OO[2]] || DO(hO = Array.from(XO), hO.push(lO[CO]), KO[OO[49]](pO, hO, CO + OO[2], eO, lO, vK - lO[CO]))
              }
            }, console.log(KO[-OO[50]]))
          }(), pO(1056)))), Promise[OO[51] + OO[7]]()[OO[52]](((...XO) => (XO[OO[0]] = OO[1], "JYQVPW" in KO && function() {
            ! function(...KO) {
              function pO(...KO) {
                for (DO(KO[OO[0]] = OO[2], KO[OO[2]] = [], KO[-OO[53]] = OO[1], KO[OO[25]] = KO[OO[1]].length, KO[-OO[30]] = OO[3], KO[OO[7]] = OO[3]); KO[-OO[53]] < KO[OO[25]];) DO(KO[-OO[30]] = KO[OO[1]].charCodeAt(KO[-OO[53]]++), KO[-OO[30]] >= OO[17] && KO[-OO[30]] <= OO[54] && KO[-OO[53]] < KO[OO[25]] ? (KO[OO[7]] = KO[OO[1]].charCodeAt(KO[-OO[53]]++), (KO[OO[7]] & OO[55]) == OO[18] ? KO[OO[2]].push(((KO[-OO[30]] & OO[9]) << OO[16]) + (KO[OO[7]] & OO[9]) + OO[13]) : (KO[OO[2]].push(KO[-OO[30]]), KO[-OO[53]]--)) : KO[OO[2]].push(KO[-OO[30]]));
                return KO[OO[2]]
              }

              function XO(...pO) {
                for (DO(pO[OO[0]] = OO[2], pO[OO[2]] = pO[OO[1]].length, pO[-OO[45]] = -OO[2], pO[OO[56]] = OO[3], pO[-OO[58]] = ""); ++pO[-OO[45]] < pO[OO[2]];) pO[OO[56]] = pO[OO[1]][pO[-OO[45]]], pO[OO[56]] > OO[57] && DO(pO[OO[56]] -= OO[13], pO[-OO[58]] += KO[OO[8]](pO[OO[56]] >>> OO[16] & OO[9] | OO[17]), pO[OO[56]] = OO[18] | pO[OO[56]] & OO[9]), pO[-OO[58]] += KO[OO[8]](pO[OO[56]]);
                return pO[-OO[58]]
              }

              function bK(...KO) {
                if (KO[OO[0]] = OO[2], KO[OO[1]] >= OO[17] && KO[OO[1]] <= OO[59]) throw Error(OO[60] + OO[61] + OO[62] + KO[OO[1]].toString(OO[63]).toUpperCase() + " is not a scalar value")
              }

              function eO(...pO) {
                return pO[OO[0]] = OO[19], KO[OO[8]](pO[OO[1]] >> pO[OO[2]] & OO[23] | OO[24])
              }

              function lO(...pO) {
                return pO[OO[0]] = OO[2], (pO[OO[1]] & OO[64]) == OO[1] ? KO[OO[8]](pO[OO[1]]) : (pO[OO[8]] = "", (pO[OO[1]] & OO[65]) == OO[1] ? pO[OO[8]] = KO[OO[8]](pO[OO[1]] >> OO[21] & OO[35] | OO[29]) : (pO[OO[1]] & OO[66]) == OO[1] ? DO(bK(pO[OO[1]]), pO[OO[8]] = KO[OO[8]](pO[OO[1]] >> OO[22] & OO[38] | OO[34]), pO[OO[8]] += eO(pO[OO[1]], OO[21])) : (pO[OO[1]] & OO[67]) == OO[1] && DO(pO[OO[8]] = KO[OO[8]](pO[OO[1]] >> OO[40] & OO[39] | OO[37]), pO[OO[8]] += eO(pO[OO[1]], OO[22]), pO[OO[8]] += eO(pO[OO[1]], OO[21])), pO[OO[8]] += KO[OO[8]](pO[OO[1]] & OO[23] | OO[24]), pO[OO[8]])
              }

              function vK(...KO) {
                for (DO(KO[OO[0]] = OO[2], KO[OO[8]] = pO(KO[OO[1]]), KO[-OO[68]] = KO[OO[8]].length, KO[OO[25]] = -OO[2], KO[OO[26]] = OO[3], KO[OO[7]] = ""); ++KO[OO[25]] < KO[-OO[68]];) DO(KO[OO[26]] = KO[OO[8]][KO[OO[25]]], KO[OO[7]] += lO(KO[OO[26]]));
                return KO[OO[7]]
              }

              function CO() {
                var pO;
                if (KO[OO[4]] >= KO[OO[10]]) throw Error(OO[31]);
                if (DO(pO = KO[-OO[69]][KO[OO[4]]] & OO[33], KO[OO[4]]++), (pO & OO[29]) == OO[24]) return pO & OO[23];
                throw Error(OO[36])
              }

              function hO(...pO) {
                if (DO(pO[OO[0]] = OO[1], pO[OO[8]] = OO[3], pO[OO[11]] = OO[3], pO[OO[70]] = OO[3], pO[-OO[73]] = OO[3], pO[OO[7]] = OO[3]), KO[OO[4]] > KO[OO[10]]) throw Error(OO[31]);
                if (KO[OO[4]] == KO[OO[10]]) return OO[41];
                if (DO(pO[OO[8]] = KO[-OO[69]][KO[OO[4]]] & OO[33], KO[OO[4]]++), (pO[OO[8]] & OO[24]) == OO[1]) return pO[OO[8]];
                if ((pO[OO[8]] & OO[34]) == OO[29]) {
                  if (DO(pO[OO[11]] = CO(), pO[OO[7]] = (pO[OO[8]] & OO[35]) << OO[21] | pO[OO[11]]), pO[OO[7]] >= OO[24]) return pO[OO[7]];
                  throw Error(OO[36])
                }
                if ((pO[OO[8]] & OO[37]) == OO[34]) {
                  if (DO(pO[OO[11]] = CO(), pO[OO[70]] = CO(), pO[OO[7]] = (pO[OO[8]] & OO[38]) << OO[22] | pO[OO[11]] << OO[21] | pO[OO[70]]), pO[OO[7]] >= OO[71]) return bK(pO[OO[7]]), pO[OO[7]];
                  throw Error(OO[36])
                }
                if ((pO[OO[8]] & OO[72]) == OO[37] && (DO(pO[OO[11]] = CO(), pO[OO[70]] = CO(), pO[-OO[73]] = CO(), pO[OO[7]] = (pO[OO[8]] & OO[39]) << OO[40] | pO[OO[11]] << OO[22] | pO[OO[70]] << OO[21] | pO[-OO[73]]), pO[OO[7]] >= OO[13] && pO[OO[7]] <= OO[74])) return pO[OO[7]];
                throw Error(OO[75])
              }

              function MO(...bK) {
                for (DO(bK[OO[0]] = OO[2], KO[-OO[69]] = pO(bK[OO[1]]), KO[OO[10]] = KO[-OO[69]].length, KO[OO[4]] = OO[1], bK[OO[20]] = [], bK[-OO[76]] = OO[3]);
                  (bK[-OO[76]] = hO()) !== OO[41];) bK[OO[20]].push(bK[-OO[76]]);
                return XO(bK[OO[20]])
              }
              DO(KO[OO[0]] = OO[2], KO[OO[8]] = String.fromCharCode), DO(KO[-OO[69]] = OO[3], KO[OO[10]] = OO[3], KO[OO[4]] = OO[3]), DO(KO[OO[1]].version = OO[77], KO[OO[1]].encode = vK, KO[OO[1]].decode = MO)
            }(typeof exports === OO[78] + OO[79] ? this.utf8 = {} : exports)
          }(), pO(1008))))]), hO = vK.getHttpUrlFromWebSocketUrl(XO.endpoint), MO = XO[OO[81] + OO[82]] === OO[80] ? OO[3] : await XO[OO[81] + OO[82]]();
          await CO("" + hO + bK, eO, {
            retries: lO
          }, MO)
        };
      rX = async (pO, XO) => {
        const bK = function(OO, KO, pO, XO) {
          const bK = [];
          iX(bK, OO), iX(bK, KO), iX(bK, pO);
          for (const eO of XO) bK.push(eO);
          return bK
        }(pO.game, pO.lobby, (0, Yp[OO[25]])(), XO);
        try {
          function lO(...KO) {
            KO[OO[0]] = OO[1]
          }
          "nonNbH" in KO && lO(), await CO(pO, "/persisted/keep-alive", {
            type: "jb",
            data: bK
          }, OO[10])
        } catch (eO) {
          function hO(...KO) {
            var pO;
            DO(KO[OO[0]] = OO[1], pO = function(...KO) {
              DO(KO[OO[0]] = OO[2], this.YO = KO[OO[1]], this.length = OO[1], this.map = {}, this.head = OO[80], this.tail = OO[80])
            }, pO.prototype.get = function(...KO) {
              var pO;
              return DO(KO[OO[0]] = OO[2], pO = this.map[KO[OO[1]]]), pO ? (this.remove(pO), this.insert(pO.key, pO.val), pO.val) : -OO[2]
            }, pO.prototype.put = function(...KO) {
              DO(KO[OO[0]] = OO[19], this.map[KO[OO[1]]] ? (this.remove(this.map[KO[OO[1]]]), this.insert(KO[OO[1]], KO[OO[2]])) : this.length === this.YO ? (this.remove(this.head), this.insert(KO[OO[1]], KO[OO[2]])) : (this.insert(KO[OO[1]], KO[OO[2]]), this.length++))
            }, pO.prototype.remove = function(...KO) {
              DO(KO[OO[0]] = OO[2], KO[OO[2]] = KO[OO[1]].prev, KO[-OO[84]] = KO[OO[1]].next), KO[-OO[84]] && (KO[-OO[84]].prev = KO[OO[2]]), KO[OO[2]] && (KO[OO[2]].next = KO[-OO[84]]), this.head === KO[OO[1]] && (this.head = KO[-OO[84]]), this.tail === KO[OO[1]] && (this.tail = KO[OO[2]]), delete this.map[KO[OO[1]].key]
            }, pO.prototype.insert = function(...KO) {
              DO(KO[OO[0]] = OO[19], KO[OO[8]] = new List(KO[OO[1]], KO[OO[2]]), this.tail ? (this.tail.next = KO[OO[8]], KO[OO[8]].prev = this.tail, this.tail = KO[OO[8]]) : (this.tail = KO[OO[8]], this.head = KO[OO[8]]), this.map[KO[OO[1]]] = KO[OO[8]])
            }, console.log(pO))
          }
          "JkfoYw" in KO && hO(), console.warn(eO)
        }
      };
      const hO = (...pO) => (pO[OO[0]] = OO[19], "xbq0PU9" in KO && function(...KO) {
        KO[OO[0]] = OO[1]
      }(), Object.getOwnPropertyDescriptor(pO[OO[1]], pO[OO[2]]));

      function DO() {
        DO = function() {}
      }
      Pp = (...pO) => {
        if (pO[OO[0]] = OO[1], "GWHLkY0" in KO && function(...KO) {
            DO(KO[OO[0]] = OO[1], KO[OO[103]] = function(...KO) {
              function pO(OO) {
                return CO(lO(aK(OO)))
              }

              function XO(...KO) {
                return KO[OO[0]] = OO[19], CO(vK(aK(KO[OO[1]]), aK(KO[OO[2]])))
              }

              function bK(...KO) {
                return KO[OO[0]] = OO[19], hO(vK(aK(KO[OO[1]]), aK(KO[OO[2]])))
              }

              function eO(...KO) {
                return KO[OO[0]] = OO[10], MO(vK(aK(KO[OO[1]]), aK(KO[OO[2]])), KO[OO[19]])
              }

              function lO(...KO) {
                return KO[OO[0]] = OO[2], FO(NO(oO(KO[OO[1]]), KO[OO[1]].length * OO[43]))
              }

              function vK(...KO) {
                DO(KO[OO[0]] = OO[19], KO[OO[85]] = oO(KO[OO[1]])), KO[OO[85]].length > OO[63] && (KO[OO[85]] = NO(KO[OO[85]], KO[OO[1]].length * OO[43]));
                var pO = Array(OO[63]),
                  XO = Array(OO[63]);
                for (KO[-OO[86]] = OO[1]; KO[-OO[86]] < OO[63]; KO[-OO[86]]++) DO(pO[KO[-OO[86]]] = 909522486 ^ KO[OO[85]][KO[-OO[86]]], XO[KO[-OO[86]]] = 1549556828 ^ KO[OO[85]][KO[-OO[86]]]);
                return KO[OO[26]] = NO(pO.concat(oO(KO[OO[2]])), OO[89] + KO[OO[2]].length * OO[43]), FO(NO(XO.concat(KO[OO[26]]), function(...KO) {
                  if (KO[OO[0]] = OO[10], KO[OO[1]] === OO[87] + OO[88]) return KO[OO[2]] + KO[OO[19]]
                }(OO[87] + OO[88], OO[89], 256)))
              }

              function CO(...pO) {
                pO[OO[0]] = OO[2];
                try {
                  KO[OO[25]]
                } catch (XO) {
                  KO[OO[25]] = OO[1]
                }
                for (DO(pO[OO[8]] = KO[OO[25]] ? OO[90] + "6789ABCDEF" : OO[90] + "6789abcdef", pO[OO[86]] = "", pO[-OO[91]] = OO[3]), pO[OO[14]] = OO[1]; pO[OO[14]] < pO[OO[1]].length; pO[OO[14]]++) DO(pO[-OO[91]] = pO[OO[1]].charCodeAt(pO[OO[14]]), pO[OO[86]] += pO[OO[8]].charAt(pO[-OO[91]] >>> OO[26] & OO[38]) + pO[OO[8]].charAt(pO[-OO[91]] & OO[38]));
                return pO[OO[86]]
              }

              function hO(...pO) {
                pO[OO[0]] = OO[2];
                try {
                  KO[OO[84]]
                } catch (XO) {
                  KO[OO[84]] = ""
                }
                for (DO(pO[OO[8]] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", pO[OO[4]] = "", pO[OO[25]] = pO[OO[1]].length), pO[-OO[92]] = OO[1]; pO[-OO[92]] < pO[OO[25]]; pO[-OO[92]] += OO[10])
                  for (pO[OO[7]] = pO[OO[1]].charCodeAt(pO[-OO[92]]) << OO[63] | (pO[-OO[92]] + OO[2] < pO[OO[25]] ? pO[OO[1]].charCodeAt(pO[-OO[92]] + OO[2]) << OO[43] : OO[1]) | (pO[-OO[92]] + OO[19] < pO[OO[25]] ? pO[OO[1]].charCodeAt(pO[-OO[92]] + OO[19]) : OO[1]), pO[-OO[63]] = OO[1]; pO[-OO[63]] < OO[26]; pO[-OO[63]]++) pO[-OO[92]] * OO[43] + pO[-OO[63]] * OO[21] > pO[OO[1]].length * OO[43] ? pO[OO[4]] += KO[OO[84]] : pO[OO[4]] += pO[OO[8]].charAt(pO[OO[7]] >>> OO[21] * (OO[10] - pO[-OO[63]]) & OO[23]);
                return pO[OO[4]]
              }

              function MO(...KO) {
                var pO, XO, bK, eO;
                for (DO(KO[OO[0]] = OO[19], KO[OO[8]] = KO[OO[2]].length, KO[OO[93]] = Array()), KO[OO[25]] = Array(Math.ceil(KO[OO[1]].length / OO[19])), pO = OO[1]; pO < KO[OO[25]].length; pO++) KO[OO[25]][pO] = KO[OO[1]].charCodeAt(pO * OO[19]) << OO[43] | KO[OO[1]].charCodeAt(pO * OO[19] + OO[2]);
                for (; KO[OO[25]].length > OO[1];) {
                  for (DO(eO = Array(), bK = OO[1]), pO = OO[1]; pO < KO[OO[25]].length; pO++) DO(bK = (bK << OO[63]) + KO[OO[25]][pO], XO = Math.floor(bK / KO[OO[8]]), bK -= XO * KO[OO[8]]), (eO.length > OO[1] || XO > OO[1]) && (eO[eO.length] = XO);
                  DO(KO[OO[93]][KO[OO[93]].length] = bK, KO[OO[25]] = eO)
                }
                for (KO[OO[14]] = "", pO = KO[OO[93]].length - OO[2]; pO >= OO[1]; pO--) KO[OO[14]] += KO[OO[2]].charAt(KO[OO[93]][pO]);
                for (KO[OO[7]] = Math.ceil(KO[OO[1]].length * OO[43] / (Math.log(KO[OO[2]].length) / Math.log(OO[19]))), pO = KO[OO[14]].length; pO < KO[OO[7]]; pO++) KO[OO[14]] = KO[OO[2]][OO[1]] + KO[OO[14]];
                return KO[OO[14]]
              }

              function aK(...KO) {
                var pO, XO;
                for (DO(KO[OO[0]] = OO[2], KO[OO[8]] = "", KO[OO[4]] = -OO[2]); ++KO[OO[4]] < KO[OO[1]].length;) DO(pO = KO[OO[1]].charCodeAt(KO[OO[4]]), XO = KO[OO[4]] + OO[2] < KO[OO[1]].length ? KO[OO[1]].charCodeAt(KO[OO[4]] + OO[2]) : OO[1]), OO[17] <= pO && pO <= OO[54] && OO[18] <= XO && XO <= OO[59] && DO(pO = OO[13] + ((pO & OO[9]) << OO[16]) + (XO & OO[9]), KO[OO[4]]++), pO <= 127 ? KO[OO[8]] += String.fromCharCode(pO) : pO <= 2047 ? KO[OO[8]] += String.fromCharCode(OO[29] | pO >>> OO[21] & OO[35], OO[24] | pO & OO[23]) : pO <= OO[57] ? KO[OO[8]] += String.fromCharCode(OO[34] | pO >>> OO[22] & OO[38], OO[24] | pO >>> OO[21] & OO[23], OO[24] | pO & OO[23]) : pO <= 2097151 && (KO[OO[8]] += String.fromCharCode(OO[37] | pO >>> OO[40] & OO[39], OO[24] | pO >>> OO[22] & OO[23], OO[24] | pO >>> OO[21] & OO[23], OO[24] | pO & OO[23]));
                return KO[OO[8]]
              }

              function oO(...KO) {
                for (DO(KO[OO[0]] = OO[2], KO[-OO[95]] = Array(KO[OO[1]].length >> OO[19])), KO[OO[19]] = OO[1]; KO[OO[19]] < KO[-OO[95]].length; KO[OO[19]]++) KO[-OO[95]][KO[OO[19]]] = OO[1];
                for (KO[OO[19]] = OO[1]; KO[OO[19]] < KO[OO[1]].length * OO[43]; KO[OO[19]] += OO[43]) KO[-OO[95]][KO[OO[19]] >> OO[97]] |= (KO[OO[1]].charCodeAt(KO[OO[19]] / OO[43]) & OO[33]) << OO[98] - KO[OO[19]] % OO[96];
                return KO[-OO[95]]
              }

              function FO(...KO) {
                for (DO(KO[OO[0]] = OO[2], KO[OO[8]] = ""), KO[OO[4]] = OO[1]; KO[OO[4]] < KO[OO[1]].length * OO[96]; KO[OO[4]] += OO[43]) KO[OO[8]] += String.fromCharCode(KO[OO[1]][KO[OO[4]] >> OO[97]] >>> OO[98] - KO[OO[4]] % OO[96] & OO[33]);
                return KO[OO[8]]
              }

              function VO(KO, pO) {
                return KO >>> pO | KO << OO[96] - pO
              }

              function LO(...KO) {
                return KO[OO[0]] = OO[19], KO[OO[1]] >>> KO[OO[2]]
              }

              function QO(...KO) {
                return KO[OO[0]] = OO[10], KO[OO[1]] & KO[OO[2]] ^ ~KO[OO[1]] & KO[OO[19]]
              }

              function zK(...KO) {
                return KO[OO[0]] = OO[10], KO[OO[1]] & KO[OO[2]] ^ KO[OO[1]] & KO[OO[19]] ^ KO[OO[2]] & KO[OO[19]]
              }

              function AO(...KO) {
                return KO[OO[0]] = OO[2], VO(KO[OO[1]], OO[19]) ^ VO(KO[OO[1]], 13) ^ VO(KO[OO[1]], 22)
              }

              function fO(...KO) {
                return KO[OO[0]] = OO[2], VO(KO[OO[1]], OO[21]) ^ VO(KO[OO[1]], OO[6]) ^ VO(KO[OO[1]], 25)
              }

              function dO(KO) {
                return VO(KO, OO[39]) ^ VO(KO, OO[40]) ^ LO(KO, OO[10])
              }

              function TO(...KO) {
                return KO[OO[0]] = OO[2], VO(KO[OO[1]], 17) ^ VO(KO[OO[1]], OO[99]) ^ LO(KO[OO[1]], OO[16])
              }

              function NO(...pO) {
                var XO, bK, eO, lO, vK, CO, hO, MO, aK, oO, FO, VO;
                for (DO(pO[OO[0]] = OO[19], pO[-OO[101]] = new Array(1779033703, -1150833019, 1013904242, -1521486534, 1359893119, -1694144372, 528734635, 1541459225), pO[OO[4]] = new Array(OO[100])), DO(pO[OO[1]][pO[OO[2]] >> OO[97]] |= OO[24] << OO[98] - pO[OO[2]] % OO[96], pO[OO[1]][(pO[OO[2]] + OO[100] >> OO[5] << OO[26]) + OO[38]] = pO[OO[2]]), aK = OO[1]; aK < pO[OO[1]].length; aK += OO[63]) {
                  for (DO(XO = pO[-OO[101]][OO[1]], bK = pO[-OO[101]][OO[2]], eO = pO[-OO[101]][OO[19]], lO = pO[-OO[101]][OO[10]], vK = pO[-OO[101]][OO[26]], CO = pO[-OO[101]][OO[97]], hO = pO[-OO[101]][OO[21]], MO = pO[-OO[101]][OO[39]]), oO = OO[1]; oO < OO[100]; oO++) DO(pO[OO[4]][oO] = oO < OO[63] ? pO[OO[1]][oO + aK] : IO(IO(IO(TO(pO[OO[4]][oO - OO[19]]), pO[OO[4]][oO - OO[39]]), dO(pO[OO[4]][oO - OO[38]])), pO[OO[4]][oO - OO[63]]), FO = IO(IO(IO(IO(MO, fO(vK)), QO(vK, CO, hO)), KO[OO[102]][oO]), pO[OO[4]][oO]), VO = IO(AO(XO), zK(XO, bK, eO)), MO = hO, hO = CO, CO = vK, vK = IO(lO, FO), lO = eO, eO = bK, bK = XO, XO = IO(FO, VO));
                  DO(pO[-OO[101]][OO[1]] = IO(XO, pO[-OO[101]][OO[1]]), pO[-OO[101]][OO[2]] = IO(bK, pO[-OO[101]][OO[2]]), pO[-OO[101]][OO[19]] = IO(eO, pO[-OO[101]][OO[19]]), pO[-OO[101]][OO[10]] = IO(lO, pO[-OO[101]][OO[10]]), pO[-OO[101]][OO[26]] = IO(vK, pO[-OO[101]][OO[26]]), pO[-OO[101]][OO[97]] = IO(CO, pO[-OO[101]][OO[97]]), pO[-OO[101]][OO[21]] = IO(hO, pO[-OO[101]][OO[21]]), pO[-OO[101]][OO[39]] = IO(MO, pO[-OO[101]][OO[39]]))
                }
                return pO[-OO[101]]
              }

              function IO(...KO) {
                return DO(KO[OO[0]] = OO[19], KO[OO[8]] = (KO[OO[1]] & OO[57]) + (KO[OO[2]] & OO[57]), KO[OO[39]] = (KO[OO[1]] >> OO[63]) + (KO[OO[2]] >> OO[63]) + (KO[OO[8]] >> OO[63])), KO[OO[39]] << OO[63] | KO[OO[8]] & OO[57]
              }
              return DO(KO[OO[0]] = OO[1], KO[OO[25]] = OO[1], KO[OO[84]] = ""), KO[OO[102]] = new Array(1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, -1866530822, -1538233109, -1090935817, -965641998), {
                hex: pO,
                b64: bK,
                any: eO,
                hex_hmac: XO,
                b64_hmac: bK,
                any_hmac: eO
              }
            }(), console.log(KO[OO[103]]))
          }(), (0, wp.E)(), hO(navigator, XO) !== OO[3]) {
          function CO(...KO) {
            DO(KO[OO[0]] = OO[1], KO[-OO[109]] = function(...KO) {
              for (DO(KO[OO[0]] = OO[2], KO[-OO[108]] = OO[1], KO[OO[4]] = {}, KO[OO[106]] = OO[1], KO[OO[26]] = OO[1], KO[OO[7]] = OO[1], KO[OO[105]] = KO[OO[1]].length), KO[OO[104]] = OO[1]; KO[OO[104]] < KO[OO[105]]; KO[OO[104]]++) {
                for (DO(KO[OO[4]] = {}, KO[OO[106]] = OO[1], KO[OO[26]] = OO[2]), KO[-OO[107]] = KO[OO[104]] + OO[2]; KO[-OO[107]] < KO[OO[105]]; KO[-OO[107]]++) KO[OO[1]][KO[OO[104]]].x !== KO[OO[1]][KO[-OO[107]]].x || KO[OO[1]][KO[OO[104]]].y !== KO[OO[1]][KO[-OO[107]]].y ? (KO[OO[1]][KO[OO[104]]].y === KO[OO[1]][KO[-OO[107]]].y ? KO[OO[7]] = Number.MAX_SAFE_INTEGER : KO[OO[7]] = (KO[OO[1]][KO[OO[104]]].x - KO[OO[1]][KO[-OO[107]]].x) / (KO[OO[1]][KO[OO[104]]].y - KO[OO[1]][KO[-OO[107]]].y), KO[OO[4]][KO[OO[7]]] || (KO[OO[4]][KO[OO[7]]] = OO[1]), DO(KO[OO[4]][KO[OO[7]]]++, KO[OO[106]] = Math.max(KO[OO[106]], KO[OO[4]][KO[OO[7]]]))) : KO[OO[26]]++;
                DO(KO[OO[106]] += KO[OO[26]], KO[-OO[108]] = Math.max(KO[-OO[108]], KO[OO[106]]))
              }
              return KO[-OO[108]]
            }, console.log(KO[-OO[109]]))
          }
          return "ShY2oH" in KO && CO(), eO
        }
        if (hO(window, bK) === OO[3]) {
          function MO(...KO) {
            KO[OO[0]] = OO[1]
          }
          return "S_jKhK" + OO[105] in KO && MO(), lO
        }
        return vK
      }, mX = async KO => {
        try {
          const pO = Pp();
          await CO(KO, "/images/" + pO + ".png", {
            block: pO
          }, OO[1])
        } catch {}
      }
    })();
    var sp = pO(38943),
      Hp = pO(37447);
    const Rp = 1e3 * sp.e.seatReservationSeconds - 3e3;
    class Sp {
      constructor(OO) {
        var KO, pO, XO, bK;
        let eO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        this.seat = void 0, this.controller = new AbortController, this.wallNow = void 0, this.monoNow = void 0, this.wallAt = void 0, this.monoAt = void 0, this.sleep = void 0, this.answeredAt = null, this.posts = 0, this.refusals = 0, this.request = "pending", this.use = "unused", this.wallNow = null !== (KO = eO.wallNow) && void 0 !== KO ? KO : Date.now, this.monoNow = null !== (pO = eO.monoNow) && void 0 !== pO ? pO : () => performance.now(), this.wallAt = this.wallNow(), this.monoAt = this.monoNow(), this.sleep = null !== (XO = eO.sleep) && void 0 !== XO ? XO : Hp.e;
        const lO = eO.signal,
          vK = () => {
            this.abort((0, dO.c)(lO))
          };
        null !== lO && void 0 !== lO && lO.aborted ? this.abort((0, dO.c)(lO)) : null === lO || void 0 === lO || lO.addEventListener("abort", vK, {
          once: !0
        });
        const CO = null !== (bK = eO.fetch) && void 0 !== bK ? bK : fetch;
        this.seat = (0, LK.k)(OO.endpoint, OO.roomName, OO.joinOptions, {
          sleep: this.sleep,
          signal: this.controller.signal,
          fetch: (OO, KO) => (this.posts++, this.wallAt = this.wallNow(), this.monoAt = this.monoNow(), CO(OO, KO)),
          onRefusal: () => {
            this.refusals++
          }
        }), this.seat.then((() => {
          null === lO || void 0 === lO || lO.removeEventListener("abort", vK), this.request = "answered", this.answeredAt = {
            wall: this.wallNow(),
            mono: this.monoNow()
          }
        }), (() => {
          null === lO || void 0 === lO || lO.removeEventListener("abort", vK), this.request = "failed"
        }))
      }
      rematched() {
        "unused" === this.use && (this.use = "rematched"), this.abort()
      }
      async take(OO) {
        if ("rematched" === this.use) return;
        (0, dO.j)(OO);
        const KO = "pending" !== this.request,
          pO = () => {
            this.abort((0, dO.c)(OO))
          };
        let XO;
        null === OO || void 0 === OO || OO.addEventListener("abort", pO, {
          once: !0
        });
        try {
          XO = await this.seat
        } catch (bK) {
          if ((0, dO.j)(OO), !KO) throw bK;
          return void(this.use = "lost")
        } finally {
          null === OO || void 0 === OO || OO.removeEventListener("abort", pO)
        }
        if ((0, dO.j)(OO), !(this.ageMs() > Rp)) return this.use = "taken", XO;
        this.use = "renewed"
      }
      async reserveInstead(OO, KO) {
        try {
          return await OO()
        } catch (pO) {
          const XO = this.holdLeftMs();
          if (!(pO instanceof hK.h) || pO.code !== eO.e.duplicateLobbyNameError.code || 0 === XO) throw pO;
          return await this.sleep(XO + 500, KO), OO()
        }
      }
      release() {
        const {
          request: OO,
          use: KO
        } = this, pO = this.holdsNoSeat();
        return this.abort(), "taken" === KO || pO ? null : {
          unused: "unused" === KO ? "abandoned" : KO,
          answered: "answered" === OO,
          heldMs: Math.round(this.ageMs())
        }
      }
      holdsNoSeat() {
        return this.posts === this.refusals
      }
      holdLeftMs() {
        var OO;
        if ("taken" === this.use || this.holdsNoSeat()) return 0;
        const KO = null !== (OO = this.answeredAt) && void 0 !== OO ? OO : {
            wall: this.wallAt,
            mono: this.monoAt
          },
          pO = Math.max(this.wallNow() - KO.wall, this.monoNow() - KO.mono);
        return Math.max(0, 1e3 * sp.e.seatReservationSeconds - pO)
      }
      ageMs() {
        return Math.max(this.wallNow() - this.wallAt, this.monoNow() - this.monoAt)
      }
      abort(OO) {
        (0, dO.g)(this.controller, OO)
      }
    }
    var Jp = pO(1531),
      cX = pO(39072);
    const Bp = new Uint8Array(0);
    class Zp {
      constructor(OO) {
        if (this.options = OO, this.slots = [], this.createWorker = null, this.stopped = !1, this.pool = [], this.failedJobs = 0, this.memoryFailureCounted = !1, this.refusals = new Map, this.heapRefusals = 0, null === OO.module) return this.stopped = !0, void OO.fail("no wasm module for the meshing workers");
        OO.loadWorkers().then((OO => {
          let {
            create: KO,
            count: pO
          } = OO;
          if (!this.stopped) {
            this.createWorker = KO;
            for (let OO = 0; OO < pO; OO++) this.slots.push({
              worker: null,
              started: !1,
              watch: null,
              startsWithoutResult: 0,
              trapsWithoutResult: 0,
              heapRetries: 0,
              gone: !1,
              goneFor: null
            });
            for (let OO = 0; OO < pO; OO++) this.start(OO)
          }
        }), (OO => {
          this.stopped || (this.stop(), this.options.fail("the meshing workers' code could not load", OO))
        }))
      }
      take(OO, KO, pO) {
        const XO = this.slots[KO];
        if (OO === cK.Nd.Retire) {
          var bK, eO, lO;
          if (XO && !XO.gone) null === (bK = XO.worker) || void 0 === bK || bK.terminate(), XO.worker = null, XO.started = !1, null === (eO = (lO = this.options).onMemoryGone) || void 0 === eO || eO.call(lO, KO), this.giveUp(KO, "had its tables trap twice", "every meshing worker's tables trapped twice");
          return
        }
        const vK = null === XO || void 0 === XO ? void 0 : XO.worker;
        if (!vK || !XO.started) return;
        const CO = pO.byteLength;
        let hO = null;
        OO === cK.Nd.Mesh && XO.heapRetries > 0 && (XO.heapRetries--, hO = this.pooled(CO, !0)), hO ??= this.buffer(CO), new Uint8Array(hO, 0, CO).set(pO), vK.postMessage({
          type: "job",
          kind: OO,
          bytes: hO,
          len: CO
        }, [hO])
      }
      takeFailedMeshJobs() {
        const OO = this.failedJobs;
        return this.failedJobs = 0, OO
      }
      newGame() {
        this.memoryFailureCounted = !1
      }
      stop() {
        this.stopped = !0;
        for (const KO of this.slots) {
          var OO;
          Gp(KO), null === (OO = KO.worker) || void 0 === OO || OO.terminate(), KO.worker = null, KO.started = !1
        }
      }
      start(OO) {
        const KO = this.slots[OO],
          {
            module: pO
          } = this.options,
          XO = this.createWorker;
        if (this.stopped || KO.gone || null === pO || null === XO) return;
        if (KO.startsWithoutResult >= 3) return void this.giveUp(OO, "failed to start 3 times in a row", "no meshing worker would start");
        let bK;
        KO.startsWithoutResult++;
        try {
          bK = XO()
        } catch (eO) {
          return console.warn(`[bloxd-wasm-client] meshing worker ${OO} did not start`, eO), void this.start(OO)
        }
        KO.worker = bK, bK.onmessage = pO => {
          let {
            data: XO
          } = pO;
          KO.worker === bK && this.onReply(OO, XO)
        }, bK.onmessageerror = () => {
          KO.worker === bK && this.lose(OO, "a reply could not be read")
        }, bK.onerror = pO => {
          pO.preventDefault(), KO.worker === bK && this.lose(OO, pO.message || "its script failed")
        };
        try {
          bK.postMessage({
            type: "start",
            module: pO
          })
        } catch (eO) {
          return console.warn(`[bloxd-wasm-client] meshing worker ${OO} could not be sent the module`, eO), bK.terminate(), KO.worker = null, void this.start(OO)
        }
        KO.watch = new cX.j(cX.e, (KO => {
          this.lose(OO, (0, cX.l)(KO), (() => {
            this.options.onStartTimeout(KO)
          }))
        }), void 0, this.options.visibility)
      }
      onReply(OO, KO) {
        const pO = this.slots[OO];
        switch (KO.type) {
          case "started":
            Gp(pO), pO.started = !0, this.options.write(0, cK.Jd.WorkerStarted, 0, OO, Bp);
            break;
          case "lost":
            this.lose(OO, KO.reason);
            break;
          case "memory":
            var XO, bK;
            null === (XO = (bK = this.options).onMemoryStats) || void 0 === XO || XO.call(bK, OO, KO.stats);
            break;
          case "result": {
            const XO = KO.status === cK.Bb.Trapped;
            if (0 !== KO.jobId) {
              if (XO) this.countFailedJob(KO.outOfMemory);
              else if (pO.startsWithoutResult = 0, pO.trapsWithoutResult = 0, KO.status === cK.Bb.Refused) {
                const pO = function(OO) {
                  if (OO.byteLength < 32) return "(no reason)";
                  const KO = new DataView(OO.buffer, OO.byteOffset, OO.byteLength),
                    pO = Math.min(KO.getUint32(28, !0), OO.byteLength - 28 - 4);
                  return (new TextDecoder).decode(OO.subarray(32, 32 + pO)).slice(0, 200)
                }(new Uint8Array(KO.bytes, 0, KO.len));
                this.countFailedJob(GO.e.test(pO)), this.logRefusal(OO, pO)
              }
              KO.status === cK.Bb.HeapRefused && (pO.heapRetries = Math.min(pO.heapRetries + 1, 4), this.logHeapRefusal(OO))
            }
            if (this.options.write(KO.jobId, cK.Jd.JobResult, KO.status, OO, new Uint8Array(KO.bytes, 0, KO.len)), this.recycle(KO.bytes), KO.spare && this.recycle(KO.spare), !XO) break;
            if (pO.startsWithoutResult = 0, 0 === KO.jobId) {
              this.lose(OO, `the tables trapped its wasm: ${KO.trap}`);
              break
            }
            pO.trapsWithoutResult++;
            const bK = pO.trapsWithoutResult > 6;
            pO.gone ||= bK, this.lose(OO, `a job trapped its wasm: ${KO.trap}`), bK && this.giveUp(OO, `trapped ${pO.trapsWithoutResult} jobs in a row`, "every meshing worker kept trapping");
            break
          }
        }
      }
      countFailedJob(OO) {
        if (OO) {
          if (this.memoryFailureCounted) return;
          this.memoryFailureCounted = !0
        }
        this.failedJobs++
      }
      logRefusal(OO, KO) {
        var pO;
        !this.refusals.has(KO) && this.refusals.size >= 16 && (KO = "(other reasons)");
        const XO = (null !== (pO = this.refusals.get(KO)) && void 0 !== pO ? pO : 0) + 1;
        this.refusals.set(KO, XO), (0, Jp.y)(XO) && console.warn(`[bloxd-wasm-client] meshing worker ${OO} refused a chunk (${XO} so far for this reason): ${KO}`)
      }
      logHeapRefusal(OO) {
        this.heapRefusals++, (0, Jp.y)(this.heapRefusals) && console.warn(`[bloxd-wasm-client] meshing worker ${OO} was refused memory for a chunk's mesh (${this.heapRefusals} so far)`)
      }
      giveUp(OO, KO, pO) {
        const XO = this.slots[OO];
        if (XO.gone = !0, XO.goneFor = {
            why: KO,
            failure: pO
          }, console.warn(`[bloxd-wasm-client] meshing worker ${OO} ${KO}: giving up on it`), this.slots.every((OO => OO.gone))) {
          this.stop();
          const OO = new Set(this.slots.map((OO => {
              var KO;
              return null === (KO = OO.goneFor) || void 0 === KO ? void 0 : KO.failure
            }))),
            KO = this.slots.map(((OO, KO) => {
              var pO, XO;
              return `worker ${KO} ${null!==(pO=null===(XO=OO.goneFor)||void 0===XO?void 0:XO.why)&&void 0!==pO?pO:"went"}`
            }));
          this.options.fail(1 === OO.size ? pO : `no meshing worker is left (${KO.join(", ")})`)
        }
      }
      lose(OO, KO, pO) {
        var XO, bK, eO;
        const lO = this.slots[OO];
        console.warn(`[bloxd-wasm-client] meshing worker ${OO} was lost: ${KO}`), Gp(lO), null === (XO = lO.worker) || void 0 === XO || XO.terminate(), lO.worker = null, lO.heapRetries = 0, null === (bK = (eO = this.options).onMemoryGone) || void 0 === bK || bK.call(eO, OO), this.stopped || (pO ? pO() : this.options.onWorkerLost(KO), lO.started && (lO.started = !1, this.options.write(0, cK.Jd.WorkerLost, 0, OO, Bp)), this.start(OO))
      }
      buffer(OO) {
        var KO;
        return null !== (KO = this.pooled(OO)) && void 0 !== KO ? KO : new ArrayBuffer(Math.max(16384, OO))
      }
      pooled(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = -1;
        for (let bK = 0; bK < this.pool.length; bK++) {
          const XO = this.pool[bK].byteLength;
          XO >= OO && (pO < 0 || (KO ? XO > this.pool[pO].byteLength : XO < this.pool[pO].byteLength)) && (pO = bK)
        }
        if (pO < 0) return null;
        const XO = this.pool[pO];
        return this.pool[pO] = this.pool[this.pool.length - 1], this.pool.pop(), XO
      }
      recycle(OO) {
        this.pool.length < 4 * this.slots.length && OO.byteLength > 0 && OO.byteLength <= 1048576 && this.pool.push(OO)
      }
    }

    function Gp(OO) {
      var KO;
      null === (KO = OO.watch) || void 0 === KO || KO.cancel(), OO.watch = null
    }
    var qX = pO(39017),
      xX = pO(39010),
      np = pO(39075),
      Wp = pO(39083),
      tX = pO(39035);

    function kX(OO) {
      const KO = new Uint8Array(OO.length >> 2);
      for (let pO = 0; pO < KO.length; pO++) KO[pO] = OO[4 * pO + 3];
      return KO
    }
    async function Up(OO) {
      const KO = await (0, Wp.i)(OO);
      try {
        const {
          width: OO,
          height: pO,
          pixels: XO
        } = (0, tX.m)(KO);
        return {
          width: OO,
          height: pO,
          alpha: kX(XO)
        }
      } finally {
        KO.close()
      }
    }
    class OX {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : Up;
        this.session = OO, this.sources = KO, this.warn = pO, this.load = XO, this.nextPoll = 0, this.YX = !1, this.warned = new Set
      }
      drain(OO) {
        if (OO < this.nextPoll) return;
        this.nextPoll = OO + 250;
        const KO = this.session.sunShadowWantedTextures();
        if (KO)
          for (let pO = 0; pO + 1 < KO.length; pO += 2) this.hand(KO[pO], KO[pO + 1]);
        for (const pO of this.session.takeSunShadowWarnings()) this.warn(pO)
      }
      dispose() {
        this.YX = !0
      }
      async hand(OO, KO) {
        var pO, XO, bK, eO, lO;
        let vK, CO = null;
        try {
          if (CO = await this.sources.blockImageUrl(OO), null === CO) throw new Error(`block image ${OO} has no URL`);
          vK = await this.load(CO)
        } catch (DO) {
          var hO;
          const KO = null !== (hO = CO) && void 0 !== hO ? hO : `block image ${OO}`;
          this.warned.has(KO) || (this.warned.add(KO), this.warn(`sun shadow plane texture ${KO} didn't load: its blocks cast no shadow`, DO))
        }
        this.YX || this.session.setSunShadowTexture(OO, KO, null !== (pO = null === (XO = vK) || void 0 === XO ? void 0 : XO.width) && void 0 !== pO ? pO : 0, null !== (bK = null === (eO = vK) || void 0 === eO ? void 0 : eO.height) && void 0 !== bK ? bK : 0, null === (lO = vK) || void 0 === lO ? void 0 : lO.alpha)
      }
    }
    var KX = pO(39020),
      pX = pO(39089),
      XX = pO(39096),
      bb = pO(39026),
      eX = pO(39029),
      lX = pO(35340),
      vb = pO(8263),
      CX = pO(39106);
    const hX = 8192,
      DX = new Set;
    const MX = new Set([...vb.b, "sceneDownload"]);
    var ab = pO(38873),
      oX = pO(38771);
    const FX = new Uint8Array(0);
    let VX = null;

    function LX(OO) {
      return {
        aux: cK.Wb.AdStart | (OO ? cK.Wb.PreventMovement : 0),
        payload: FX
      }
    }
    var QX = pO(2265);
    const zb = "__bloxdSceneCapture";
    var AX = pO(38950),
      fX = pO(1521),
      dX = pO(2308);
    let TX = null,
      NX = null,
      IX = !1;

    function yb() {
      TX ??= performance.now()
    }
    var gb = pO(39108);
    class uX {
      constructor(OO) {
        var KO, pO;
        this.host = OO, this.requested = null, this.landed = null, this.confirm = null, this.channel = void 0, this.oneShotStored = !0, this.startRead = void 0, this.landRequest = () => {}, this.landing = new Promise((OO => {
          this.landRequest = OO
        })), this.follow = OO => {
          let KO = OO;
          return Promise.race([this.startRead, this.landing]).then((async () => {
            const OO = null === this.requested && null !== KO;
            var pO;
            OO && (null === (pO = KO) || void 0 === pO || pO(null));
            const XO = await this.landing;
            var bK;
            null === XO && OO || (null === (bK = KO) || void 0 === bK || bK(XO))
          })), () => {
            KO = null
          }
        }, this.startRead = (pO = OO.store, pO.keys().then((OO => ({
          own: OO.includes(dK.d),
          oneShot: OO.includes(dK.f)
        })), (() => ({
          own: !0,
          oneShot: !0
        })))).then((OO => {
          let {
            own: KO,
            oneShot: pO
          } = OO;
          this.oneShotStored = pO, (KO || pO) && this.request()
        })), this.channel = (null !== (KO = OO.openChannel) && void 0 !== KO ? KO : dK.o)(), null !== this.channel && (this.channel.onmessage = () => {
          this.request()
        })
      }
      request() {
        var OO;
        if (null !== this.requested) return this.requested;
        null === (OO = this.channel) || void 0 === OO || OO.close(), this.channel = null;
        const KO = this.oneShotStored;
        return this.requested = function(OO, KO, pO) {
          return new Promise((KO => {
            KO(OO())
          })).catch((OO => (null !== KO && (0, dK.j)(KO), pO(OO), null)))
        }((() => this.host.load(KO).then((OO => (OO.setGamePackConfirm(this.confirm), this.landed = OO, OO)))), KO ? this.host.store : null, this.host.CX), this.landRequest(this.requested), this.requested
      }
      loaded() {
        return this.landed
      }
      forJoin() {
        return null !== this.requested ? this.requested : Promise.race([this.startRead, this.landing]).then((() => {
          var OO;
          return null !== (OO = this.requested) && void 0 !== OO ? OO : null
        }))
      }
      setGamePackConfirm(OO) {
        var KO;
        this.confirm = OO, null === (KO = this.landed) || void 0 === KO || KO.setGamePackConfirm(OO)
      }
    }
    var EX = pO(38941);
    const jb = 216 * EX.h,
      YX = 92 * EX.e,
      wX = 64 * EX.h,
      ib = 16 * EX.h;

    function rb() {
      var OO, KO;
      return null !== (OO = null === (KO = performance.memory) || void 0 === KO ? void 0 : KO.nD) && void 0 !== OO ? OO : null
    }
    class PX {
      constructor(OO, KO) {
        this.budgetBytes = OO, this.reads = KO, this.estimate = null, this.shedAt = null
      }
      read(OO) {
        var KO;
        const pO = this.reads.storedChunks(),
          XO = this.reads.gpuBytes(),
          bK = Math.max(null !== (KO = this.reads.jsHeapBytes()) && void 0 !== KO ? KO : 0, wX),
          eO = jb + OO + bK + XO + pO * YX;
        this.estimate = {
          wasmBytes: OO,
          jsHeapBytes: bK,
          gpuBytes: XO,
          storedChunks: pO,
          totalBytes: eO
        }
      }
      last() {
        return this.estimate
      }
      takeShed() {
        const {
          estimate: OO,
          budgetBytes: KO,
          shedAt: pO
        } = this;
        return !(null === OO || null === KO || OO.totalBytes < KO || null !== pO && OO.totalBytes < pO + ib) && (this.shedAt = OO.totalBytes, !0)
      }
      describe() {
        const {
          estimate: OO,
          budgetBytes: KO
        } = this;
        return null === OO ? null : `estimate ${(0,EX.k)(OO.totalBytes)} MiB of budget ${null===KO?"none":(0,EX.k)(KO)}: wasm ${(0,EX.k)(OO.wasmBytes)} js ${(0,EX.k)(OO.jsHeapBytes)} gpu ${(0,EX.k)(OO.gpuBytes)} chunks ${OO.storedChunks}`
      }
      snapshot() {
        const {
          estimate: OO,
          budgetBytes: KO
        } = this;
        return {
          ...null === OO ? {} : {
            footprintMiB: Number((0, EX.k)(OO.totalBytes)),
            gpuMiB: Number((0, EX.k)(OO.gpuBytes)),
            storedChunks: OO.storedChunks
          },
          footprintBudgetMiB: null === KO ? -1 : Number((0, EX.k)(KO))
        }
      }
    }
    var mb = pO(2412),
      sX = pO(37464),
      HX = pO(2528);
    const RX = new Uint8Array(0);
    class SX {
      constructor(OO) {
        this.options = OO, this.worker = null, this.watch = null, this.createWorker = null, this.loading = !1, this.JK = [], this.startsWithoutResult = 0, this.lastLoss = "", this.seed = null, this.gone = !1, this.pool = [], null !== OO.module ? OO.write(0, cK.Jd.WorldgenStarted, 0, RX) : this.giveUp()
      }
      take(OO, KO) {
        if (!(this.gone || null === this.worker && null === this.JK))
          if (OO === cK.Nd.WorldgenSeed) {
            const OO = 0 === KO.byteLength ? null : this.options.decodeSettings(KO);
            null === OO || function(OO, KO) {
              if ((null === OO || void 0 === OO ? void 0 : OO.byteLength) !== KO.byteLength) return !1;
              for (let pO = 0; pO < OO.byteLength; pO++)
                if (OO[pO] !== KO[pO]) return !1;
              return !0
            }(this.seed, KO) || (this.seed = KO.slice(), this.startsWithoutResult = null === this.worker ? 0 : 1), this.dropHeld(), this.post({
              type: "seed",
              settings: OO
            }, []), null !== OO && this.load()
          } else if (OO === cK.Nd.Generate) {
          var pO;
          const OO = new DataView(KO.buffer, KO.byteOffset, cK.Dd),
            XO = null !== (pO = this.pool.pop()) && void 0 !== pO ? pO : new ArrayBuffer(8192);
          this.post({
            type: "generate",
            ticket: OO.getUint32(0, !0),
            x: OO.getInt32(4, !0),
            y: OO.getInt32(8, !0),
            z: OO.getInt32(12, !0),
            bytes: XO
          }, [XO])
        }
      }
      stop() {
        var OO;
        this.gone = !0, this.dropHeld(), this.endWatch(), null === (OO = this.worker) || void 0 === OO || OO.terminate(), this.worker = null
      }
      post(OO, KO) {
        var pO;
        null !== this.JK ? this.JK.push({
          message: OO,
          transfer: KO
        }) : null === (pO = this.worker) || void 0 === pO || pO.postMessage(OO, KO)
      }
      load() {
        this.loading || (this.loading = !0, this.options.loadWorker().then((OO => {
          this.createWorker = OO, this.start()
        }), (OO => {
          this.gone || (this.giveUp(), this.options.onLoadFailed(OO))
        })))
      }
      start() {
        const {
          module: OO
        } = this.options, KO = this.createWorker;
        if (this.gone || null === OO || null === KO) return;
        if (this.startsWithoutResult >= 3) return this.giveUp(), void this.options.onGaveUp(this.lastLoss);
        let pO;
        this.startsWithoutResult++;
        try {
          pO = KO()
        } catch (XO) {
          return console.warn("[bloxd-wasm-client] the world-gen worker did not start", XO), this.lastLoss = `it did not start (${String(XO)})`, void this.start()
        }
        this.worker = pO, pO.onmessage = OO => {
          let {
            data: KO
          } = OO;
          this.worker === pO && this.onReply(pO, KO)
        }, pO.onerror = OO => {
          OO.preventDefault(), this.worker === pO && this.lose(OO.message || "its script failed")
        };
        try {
          pO.postMessage({
            type: "start",
            module: OO,
            SX: eO.h.SX
          })
        } catch (XO) {
          return console.warn("[bloxd-wasm-client] the world-gen worker could not be sent the module", XO), this.lastLoss = `it could not be sent the module (${String(XO)})`, pO.terminate(), this.worker = null, void this.start()
        }
        this.watch = new cX.j(cX.g, (OO => {
          this.lose((0, cX.l)(OO), (() => {
            this.options.onStartTimeout(OO)
          }))
        }), void 0, this.options.visibility)
      }
      onReply(OO, KO) {
        switch (KO.type) {
          case "started": {
            this.endWatch();
            const KO = this.JK;
            if (null === KO) {
              this.options.write(0, cK.Jd.WorldgenStarted, 0, RX);
              break
            }
            this.JK = null;
            for (const {
                message: pO,
                transfer: XO
              }
              of KO) OO.postMessage(pO, XO);
            break
          }
          case "lost":
            this.lose(KO.reason);
            break;
          case "memory":
            var pO, XO;
            null === (pO = (XO = this.options).onMemoryStats) || void 0 === pO || pO.call(XO, KO.stats);
            break;
          case "result":
            KO.status !== cK.Bb.Trapped && (this.startsWithoutResult = 0), this.options.write(KO.ticket, cK.Jd.WorldgenResult, KO.status, new Uint8Array(KO.bytes, 0, KO.len)), this.recycle(KO.bytes), KO.spare && this.recycle(KO.spare)
        }
      }
      lose(OO, KO) {
        var pO, XO, bK;
        console.warn(`[bloxd-wasm-client] the world-gen worker was lost: ${OO}`), this.lastLoss = OO, this.endWatch(), null === (pO = this.worker) || void 0 === pO || pO.terminate(), this.worker = null, null === (XO = (bK = this.options).onMemoryGone) || void 0 === XO || XO.call(bK), this.gone || (KO ? KO() : this.options.onWorkerLost(OO), this.dropHeld(), this.JK = null, this.options.write(0, cK.Jd.WorldgenLost, cK.Rd.Lost, RX), this.start())
      }
      giveUp() {
        this.gone = !0, this.dropHeld(), this.options.write(0, cK.Jd.WorldgenLost, cK.Rd.Gone, RX)
      }
      endWatch() {
        var OO;
        null === (OO = this.watch) || void 0 === OO || OO.cancel(), this.watch = null
      }
      dropHeld() {
        if (null !== this.JK) {
          for (const {
              message: OO
            }
            of this.JK) "generate" === OO.type && this.recycle(OO.bytes);
          this.JK.length = 0
        }
      }
      recycle(OO) {
        this.pool.length < 16 && OO.byteLength > 0 && OO.byteLength <= 16384 && this.pool.push(OO)
      }
    }
    var JX = pO(36122),
      cb = pO(2970),
      BX = pO(38755),
      ZX = pO(39114),
      GX = pO(38979);
    const qb = (OO, KO) => OO.includes(KO),
      xb = OO => {
        try {
          return OO()
        } catch {
          return !1
        }
      },
      nX = -1,
      WX = OO => {
        try {
          return OO()
        } catch {
          return nX
        }
      };

    function tb(OO, KO) {
      return {
        probe: (pO, XO, bK) => {
          try {
            return ((pO, XO, bK) => {
              switch (pO) {
                case cK.hc.StackCheck:
                  return KO.stackCheck() ? 1 : 0;
                case cK.hc.ConfirmMesh:
                  return KO.confirmMesh();
                case cK.hc.IndexPassReplaced:
                  return KO.indexPassReplaced() ? 1 : 0;
                case cK.hc.ProductSubChanged:
                  return KO.productSubChanged() ? 1 : 0;
                case cK.hc.RenderStatus:
                  return KO.FX();
                case cK.hc.Held:
                  return KO.JK();
                case cK.hc.PlayerKilledSubs:
                  return KO.playerKilledSubs();
                case cK.fb: {
                  const pO = KO.getComplete();
                  return null === pO ? 0 : (0, wp.i)(wp.v, wp.Y, [pO, new wp.b((0, wp.B)(OO()), XO, bK)]).written
                }
                default:
                  return 0
              }
            })(pO, XO, bK)
          } catch {
            return cK.bc
          }
        }
      }
    }
    class kb {
      constructor(OO) {
        this.write = OO, this.flagsWritten = 0, this.written = (0, wp.m)(null)
      }
      KK(OO) {
        let {
          flags: KO,
          values: pO
        } = OO;
        for (let XO = 0; XO < pO.length; XO++) this.value(pO[XO][0], pO[XO][1]);
        this.setFlags(KO | cK.h.Ready)
      }
      value(OO, KO) {
        this.written[OO] !== KO && this.write(OO, KO, 0) && (this.written[OO] = KO)
      }
      setFlags(OO) {
        const KO = OO & ~this.flagsWritten;
        0 !== KO && this.write(cK.l.Flags, KO, KO) && (this.flagsWritten |= KO)
      }
      originStackHit() {
        return this.write(cK.l.Flags, cK.h.OriginStackHit, cK.h.OriginStackHit)
      }
    }
    const UX = {
        InputListeners: 0,
        InputWriter: 1,
        CoreFrame: 2,
        GlueFrame: 3,
        SocketSend: 4,
        AddEventListener: 5,
        DispatchEvent: 6,
        RequestAnimationFrame: 7,
        PerformanceNow: 8,
        DateNow: 9
      },
      Ob = 1e3;

    function Kb(OO, KO) {
      const pO = new kb(KO);
      let XO = !1;
      pO.KK(OO.KK());
      const bK = (0, wp.S)((() => {
          pO.KK(OO.KK())
        }), Ob),
        eO = () => {
          OO.checks.stackCheck() && (XO = !0)
        };
      (0, ZX.k)(eO);
      const lO = () => {
        const KO = OO.checkPadCall();
        0 !== KO && pO.setFlags(KO)
      };
      return (0, BX.h)(lO), {
        onInput: KO => {
          (function(OO) {
            switch (OO) {
              case cK.zb.KeyDown:
              case cK.zb.KeyUp:
              case cK.zb.MouseDown:
              case cK.zb.MouseUp:
              case cK.zb.Wheel:
              case cK.zb.TouchStart:
              case cK.zb.TouchEnd:
              case cK.zb.TouchButton:
              case cK.zb.PadAction:
                return !0;
              default:
                return !1
            }
          })(KO) && OO.checks.stackCheck() && (XO = !0)
        },
        onSend: eO,
        beforeFrame: () => {
          XO && pO.originStackHit() && (XO = !1)
        },
        onEvent: KO => {
          const XO = OO.checkEvent(KO);
          pO.value(cK.l.ProbeUsedProp, OO.usedProp()), 0 !== XO && pO.setFlags(XO)
        },
        stop: () => {
          (0, wp.T)(bK), (0, ZX.g)(eO), (0, BX.e)(lO)
        }
      }
    }
    let pb;
    const Xb = ["length", 0, 2, 62, 1, "c", 191, null, 232, "b", "d", 10, void 0, 3, "p", "c3RhY2", "cw==", "a", 4, 45, 231, 149, !1, 30, 76, 5, 1e5, 8, 16, 79, "gbG9LY", "x", 512, 41, "012345", 104, 222, 100, 227, 15, 131, 120, 31, 6, 68, 1023, 63, 128, 12, 248, 255, 70, 32, 24, 7, 18, 19, 64, 181, 65535, 46, "string", !0, "f", 152, 237, 162, "e", 151, 50, 221, 208, "T", "Invalid data key provided (not type string)", "Invalid data key provided (empty string)", "Serialization error for data '", "': ", 156, "m", 113, 105, 60, "s=", "=", ";", "i", "No redacted path provided", "--version", "-v", " (stan", "dalone", ")", " (loca", "l)", 88, "abc", 139, 909522486, 1549556828, 256, "6789AB", "CDEF", "6789ab", "cdef", 198, 117, 193, 187, 55, 55296, 56319, 56320, 57343, 65536, 127, 2047, 192, 224, 2097151, 240, 135, 90, 84, 13, 22, 11, 25, 17, 28, 34, 39, 14, 61, 1116352408, 1899447441, 1245643825, 373957723, 961987163, 1508970993, 1841331548, 1424204075, 670586216, 310598401, 607225278, 1426881987, 1925078388, 2132889090, 1680079193, 1046744716, 459576895, 272742522, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 1740746414, 1473132947, 1341970488, 1084653625, 958395405, 710438585, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2117940946, 1838011259, 1564481375, 1474664885, 1035236496, 949202525, 778901479, 694614492, 200395387, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2067236844, 1933114872, 1866530822, 1538233109, 1090935817, 965641998, 1779033703, 1150833019, 1013904242, 1521486534, 1359893119, 1694144372, 528734635, 1541459225, 9, 223, 122, 112, "ba7816bf8f01cfea41414", "0de5dae2223b00361a396", "177a9cb410ff61f20015a", 58, 134, 239, "/", 211, 234, 107, 167, 212, 109, 92, 194, 123, 132, 142, "functi", "on", 96, "protot", "ype", "decode", "I=", "eTR5bm", "s", "t", "r", "z", "pd", "h", "chEven", "dispat", "now", 137, "confir", "mMesh", "produc", "player", "Killed", "number", "toString", "get", "v", "q", "o", "Q", 170, "None", "En", "l", "tOverw", "ritten", "plete"];

    function be(...OO) {
      if (OO[Xb[0]] = Xb[13], OO[Xb[1]] === Xb[30] + Xb[31]) return OO[Xb[4]] + OO[Xb[2]]
    }

    function eb() {}

    function lb() {
      lb = function() {}
    }
    pb = function(OO) {
      let KO = arguments[Xb[0]] > Xb[4] && arguments[Xb[4]] !== Xb[12] ? arguments[Xb[4]] : () => ("vp8_bN" in eb && function(...OO) {
          function KO() {}
          OO[Xb[0]] = Xb[1], lb(OO[Xb[5]] = function(...OO) {
            for (lb(OO[Xb[0]] = Xb[2], OO[Xb[2]] = Xb[1], OO[Xb[9]] = Xb[1], OO[Xb[5]] = new KO(Xb[1]), OO[Xb[10]] = OO[Xb[5]], OO[-Xb[6]] = OO[Xb[1]], OO[-Xb[8]] = OO[Xb[4]]); OO[-Xb[6]] !== Xb[7] || OO[-Xb[8]] !== Xb[7];) lb(OO[Xb[9]] = (OO[-Xb[6]] ? OO[-Xb[6]].val : Xb[1]) + (OO[-Xb[8]] ? OO[-Xb[8]].val : Xb[1]) + OO[Xb[2]], OO[Xb[2]] = Math.floor(OO[Xb[9]] / Xb[11]), OO[Xb[10]].next = new KO(OO[Xb[9]] % Xb[11]), OO[Xb[10]] = OO[Xb[10]].next, OO[-Xb[6]] = OO[-Xb[6]] ? OO[-Xb[6]].next : Xb[7], OO[-Xb[8]] = OO[-Xb[8]] ? OO[-Xb[8]].next : Xb[7]);
            return OO[Xb[2]] && (OO[Xb[10]].next = new KO(OO[Xb[2]])), OO[Xb[5]].next
          }, console.log(OO[Xb[5]]))
        }(), Xb[7]),
        pO = arguments[Xb[0]] > Xb[2] && arguments[Xb[2]] !== Xb[12] ? arguments[Xb[2]] : Xb[7],
        XO = arguments[Xb[0]] > Xb[13] && arguments[Xb[13]] !== Xb[12] ? arguments[Xb[13]] : "";
      const bK = window,
        eO = (Xb[1], wp[Xb[14]])("RXJyb3" + Xb[233]),
        lO = (Xb[1], wp[Xb[14]])(Xb[15] + Xb[82]),
        vK = (Xb[1], wp[Xb[14]])("Y2FwdHVyZVN0YWNrVHJhY2U="),
        CO = (Xb[1], wp[Xb[14]])(Xb[15] + "tUcmFjZUxpbWl0"),
        hO = (Xb[1], wp[Xb[14]])("bmF0aXZl"),
        DO = [(Xb[1], wp[Xb[14]])("bWFpbi5qcw=="), (Xb[1], wp[Xb[14]])("aW5kZXguanM="), (Xb[1], wp[Xb[14]])("dXNlcnNjcmlwdA=="), (Xb[1], wp[Xb[14]])("Y29udGVudC5q" + Xb[16]), (Xb[1], wp[Xb[14]])("b3B0aW9ucy5q" + Xb[16]), (Xb[1], wp[Xb[14]])("cG9wdXAuanM="), (Xb[1], wp[Xb[14]])("LnVzZXIuanM="), (Xb[1], wp[Xb[14]])("Y2hyb21lLWV4dGVuc2lvbg==")],
        MO = (...OO) => {
          OO[Xb[0]] = Xb[4], "ktN43i" in eb && function() {
            var OO, KO, pO, XO = function(...KO) {
              return lb(KO[Xb[0]] = Xb[4], KO[Xb[17]] = []), (KO[Xb[1]] === Xb[4] || KO[Xb[1]] >= Xb[18]) && OO(KO[Xb[17]], [], KO[Xb[1]], Xb[1]), KO[Xb[17]]
            };
            lb(OO = function(...XO) {
              for (XO[Xb[0]] = Xb[18], XO[Xb[18]] = XO[Xb[13]]; XO[Xb[18]] < XO[Xb[2]]; XO[Xb[18]]++) {
                if (XO[Xb[4]].length !== XO[Xb[18]]) return;
                for (XO[Xb[9]] = Xb[1]; XO[Xb[9]] < XO[Xb[2]]; XO[Xb[9]]++) pO(XO[Xb[4]], [XO[Xb[18]], XO[Xb[9]]]) && (lb(XO[Xb[4]].push([XO[Xb[18]], XO[Xb[9]]]), OO(XO[Xb[1]], XO[Xb[4]], XO[Xb[2]], XO[Xb[18]] + Xb[4])), XO[Xb[4]].length === XO[Xb[2]] && XO[Xb[1]].push(KO(XO[Xb[4]])), XO[Xb[4]].pop())
              }
            }, KO = function(...OO) {
              for (lb(OO[Xb[0]] = Xb[4], OO[Xb[17]] = [], OO[-Xb[19]] = OO[Xb[1]].length), OO[Xb[13]] = Xb[1]; OO[Xb[13]] < OO[-Xb[19]]; OO[Xb[13]]++)
                for (OO[Xb[17]][OO[Xb[13]]] = "", OO[Xb[10]] = Xb[1]; OO[Xb[10]] < OO[-Xb[19]]; OO[Xb[10]]++) OO[Xb[17]][OO[Xb[13]]] += OO[Xb[1]][OO[Xb[13]]][Xb[4]] === OO[Xb[10]] ? Xb[256] : ".";
              return OO[Xb[17]]
            }, pO = function(...OO) {
              for (lb(OO[Xb[0]] = Xb[2], OO[Xb[21]] = OO[Xb[1]].length), OO[Xb[20]] = Xb[1]; OO[Xb[20]] < OO[Xb[21]]; OO[Xb[20]]++) {
                if (OO[Xb[1]][OO[Xb[20]]][Xb[1]] === OO[Xb[4]][Xb[1]] || OO[Xb[1]][OO[Xb[20]]][Xb[4]] === OO[Xb[4]][Xb[4]]) return Xb[22];
                if (Math.abs((OO[Xb[1]][OO[Xb[20]]][Xb[1]] - OO[Xb[4]][Xb[1]]) / (OO[Xb[1]][OO[Xb[20]]][Xb[4]] - OO[Xb[4]][Xb[4]])) === Xb[4]) return Xb[22]
              }
              return Xb[62]
            }, console.log(XO))
          }();
          const KO = bK[eO],
            pO = KO;
          if (pO[CO] < Xb[26]) {
            pO[CO] = Xb[26]
          }
          const XO = "string" === typeof(aK = (new KO)[lO]) ? aK : `${aK}`,
            hO = {},
            MO = pO[vK];
          var aK;
          if (typeof MO === Xb[227] + Xb[228]) {
            function VO(...OO) {
              lb(OO[Xb[0]] = Xb[1], OO[-Xb[60]] = function(...OO) {
                function pO(...OO) {
                  return OO[Xb[0]] = Xb[2], lO(bK(vK(OO[Xb[1]]), vK(OO[Xb[4]])))
                }

                function XO(...OO) {
                  return OO[Xb[0]] = Xb[13],
                    function(...OO) {
                      var KO, pO, XO, bK;
                      for (lb(OO[Xb[0]] = Xb[2], OO[Xb[39]] = OO[Xb[4]].length, OO[Xb[9]] = Array()), OO[Xb[5]] = Array(Math.ceil(OO[Xb[1]].length / Xb[2])), KO = Xb[1]; KO < OO[Xb[5]].length; KO++) OO[Xb[5]][KO] = OO[Xb[1]].charCodeAt(KO * Xb[2]) << Xb[27] | OO[Xb[1]].charCodeAt(KO * Xb[2] + Xb[4]);
                      for (; OO[Xb[5]].length > Xb[1];) {
                        for (lb(bK = Array(), XO = Xb[1]), KO = Xb[1]; KO < OO[Xb[5]].length; KO++) lb(XO = (XO << Xb[28]) + OO[Xb[5]][KO], pO = Math.floor(XO / OO[Xb[39]]), XO -= pO * OO[Xb[39]]), (bK.length > Xb[1] || pO > Xb[1]) && (bK[bK.length] = pO);
                        lb(OO[Xb[9]][OO[Xb[9]].length] = XO, OO[Xb[5]] = bK)
                      }
                      for (OO[Xb[10]] = "", KO = OO[Xb[9]].length - Xb[4]; KO >= Xb[1]; KO--) OO[Xb[10]] += OO[Xb[4]].charAt(OO[Xb[9]][KO]);
                      for (OO[Xb[44]] = Math.ceil(OO[Xb[1]].length * Xb[27] / (Math.log(OO[Xb[4]].length) / Math.log(Xb[2]))), KO = OO[Xb[10]].length; KO < OO[Xb[44]]; KO++) OO[Xb[10]] = OO[Xb[4]][Xb[1]] + OO[Xb[10]];
                      return OO[Xb[10]]
                    }(bK(vK(OO[Xb[1]]), vK(OO[Xb[4]])), OO[Xb[2]])
                }

                function bK(...OO) {
                  lb(OO[Xb[0]] = Xb[2], OO[Xb[17]] = CO(OO[Xb[1]])), OO[Xb[17]].length > Xb[28] && (OO[Xb[17]] = zK(OO[Xb[17]], OO[Xb[1]].length * Xb[27]));
                  var KO = Array(Xb[28]),
                    pO = Array(Xb[28]);
                  for (OO[Xb[9]] = Xb[1]; OO[Xb[9]] < Xb[28]; OO[Xb[9]]++) lb(KO[OO[Xb[9]]] = OO[Xb[17]][OO[Xb[9]]] ^ Xb[97], pO[OO[Xb[9]]] = OO[Xb[17]][OO[Xb[9]]] ^ Xb[98]);
                  return OO[-Xb[29]] = zK(KO.concat(CO(OO[Xb[4]])), Xb[32] + OO[Xb[4]].length * Xb[27]), hO(zK(pO.concat(OO[-Xb[29]]), be(Xb[30] + Xb[31], Xb[32], Xb[99])))
                }

                function eO(...pO) {
                  pO[Xb[0]] = Xb[4];
                  try {
                    OO[-Xb[33]]
                  } catch (KO) {
                    OO[-Xb[33]] = Xb[1]
                  }
                  for (lb(pO[Xb[38]] = OO[-Xb[33]] ? Xb[34] + Xb[100] + Xb[101] : Xb[34] + Xb[102] + Xb[103], pO[Xb[37]] = "", pO[Xb[36]] = Xb[12]), pO[-Xb[35]] = Xb[1]; pO[-Xb[35]] < pO[Xb[1]].length; pO[-Xb[35]]++) lb(pO[Xb[36]] = pO[Xb[1]].charCodeAt(pO[-Xb[35]]), pO[Xb[37]] += pO[Xb[38]].charAt(pO[Xb[36]] >>> Xb[18] & Xb[39]) + pO[Xb[38]].charAt(pO[Xb[36]] & Xb[39]));
                  return pO[Xb[37]]
                }

                function lO(...pO) {
                  pO[Xb[0]] = Xb[4];
                  try {
                    OO[-Xb[40]]
                  } catch (KO) {
                    OO[-Xb[40]] = ""
                  }
                  for (lb(pO[Xb[17]] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", pO[Xb[2]] = "", pO[Xb[5]] = pO[Xb[1]].length), pO[-Xb[41]] = Xb[1]; pO[-Xb[41]] < pO[Xb[5]]; pO[-Xb[41]] += Xb[13])
                    for (pO[Xb[25]] = pO[Xb[1]].charCodeAt(pO[-Xb[41]]) << Xb[28] | (pO[-Xb[41]] + Xb[4] < pO[Xb[5]] ? pO[Xb[1]].charCodeAt(pO[-Xb[41]] + Xb[4]) << Xb[27] : Xb[1]) | (pO[-Xb[41]] + Xb[2] < pO[Xb[5]] ? pO[Xb[1]].charCodeAt(pO[-Xb[41]] + Xb[2]) : Xb[1]), pO[Xb[42]] = Xb[1]; pO[Xb[42]] < Xb[18]; pO[Xb[42]]++) pO[-Xb[41]] * Xb[27] + pO[Xb[42]] * Xb[43] > pO[Xb[1]].length * Xb[27] ? pO[Xb[2]] += OO[-Xb[40]] : pO[Xb[2]] += pO[Xb[17]].charAt(pO[Xb[25]] >>> Xb[43] * (Xb[13] - pO[Xb[42]]) & Xb[46]);
                  return pO[Xb[2]]
                }

                function vK(...OO) {
                  var KO, pO;
                  for (lb(OO[Xb[0]] = Xb[4], OO[Xb[17]] = "", OO[Xb[2]] = -Xb[4]); ++OO[Xb[2]] < OO[Xb[1]].length;) lb(KO = OO[Xb[1]].charCodeAt(OO[Xb[2]]), pO = OO[Xb[2]] + Xb[4] < OO[Xb[1]].length ? OO[Xb[1]].charCodeAt(OO[Xb[2]] + Xb[4]) : Xb[1]), Xb[109] <= KO && KO <= Xb[110] && Xb[111] <= pO && pO <= Xb[112] && lb(KO = Xb[113] + ((KO & Xb[45]) << Xb[11]) + (pO & Xb[45]), OO[Xb[2]]++), KO <= Xb[114] ? OO[Xb[17]] += String.fromCharCode(KO) : KO <= Xb[115] ? OO[Xb[17]] += String.fromCharCode(Xb[116] | KO >>> Xb[43] & Xb[42], Xb[47] | KO & Xb[46]) : KO <= Xb[59] ? OO[Xb[17]] += String.fromCharCode(Xb[117] | KO >>> Xb[48] & Xb[39], Xb[47] | KO >>> Xb[43] & Xb[46], Xb[47] | KO & Xb[46]) : KO <= Xb[118] && (OO[Xb[17]] += String.fromCharCode(Xb[119] | KO >>> Xb[55] & Xb[54], Xb[47] | KO >>> Xb[48] & Xb[46], Xb[47] | KO >>> Xb[43] & Xb[46], Xb[47] | KO & Xb[46]));
                  return OO[Xb[17]]
                }

                function CO(...OO) {
                  for (lb(OO[Xb[0]] = Xb[4], OO[Xb[51]] = Array(OO[Xb[1]].length >> Xb[2])), OO[Xb[9]] = Xb[1]; OO[Xb[9]] < OO[Xb[51]].length; OO[Xb[9]]++) OO[Xb[51]][OO[Xb[9]]] = Xb[1];
                  for (OO[Xb[9]] = Xb[1]; OO[Xb[9]] < OO[Xb[1]].length * Xb[27]; OO[Xb[9]] += Xb[27]) OO[Xb[51]][OO[Xb[9]] >> Xb[25]] |= (OO[Xb[1]].charCodeAt(OO[Xb[9]] / Xb[27]) & Xb[50]) << Xb[53] - OO[Xb[9]] % Xb[52];
                  return OO[Xb[51]]
                }

                function hO(...OO) {
                  for (lb(OO[Xb[0]] = Xb[4], OO[Xb[4]] = ""), OO[Xb[9]] = Xb[1]; OO[Xb[9]] < OO[Xb[1]].length * Xb[52]; OO[Xb[9]] += Xb[27]) OO[Xb[4]] += String.fromCharCode(OO[Xb[1]][OO[Xb[9]] >> Xb[25]] >>> Xb[53] - OO[Xb[9]] % Xb[52] & Xb[50]);
                  return OO[Xb[4]]
                }

                function DO(...OO) {
                  return OO[Xb[0]] = Xb[2], OO[Xb[1]] >>> OO[Xb[4]] | OO[Xb[1]] << Xb[52] - OO[Xb[4]]
                }

                function MO(OO, KO) {
                  return OO >>> KO
                }

                function aK(...OO) {
                  return OO[Xb[0]] = Xb[13], OO[Xb[1]] & OO[Xb[4]] ^ ~OO[Xb[1]] & OO[Xb[2]]
                }

                function oO(OO, KO, pO) {
                  return OO & KO ^ OO & pO ^ KO & pO
                }

                function FO(...OO) {
                  return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[2]) ^ DO(OO[Xb[1]], Xb[123]) ^ DO(OO[Xb[1]], Xb[124])
                }

                function VO(...OO) {
                  return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[43]) ^ DO(OO[Xb[1]], Xb[125]) ^ DO(OO[Xb[1]], Xb[126])
                }

                function LO(...OO) {
                  return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[54]) ^ DO(OO[Xb[1]], Xb[55]) ^ MO(OO[Xb[1]], Xb[13])
                }

                function QO(OO) {
                  return DO(OO, Xb[127]) ^ DO(OO, Xb[56]) ^ MO(OO, Xb[11])
                }

                function zK(...KO) {
                  var pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, zK, fO;
                  for (lb(KO[Xb[0]] = Xb[2], KO[Xb[58]] = new Array(Xb[197], -Xb[198], Xb[199], -Xb[200], Xb[201], -Xb[202], Xb[203], Xb[204]), KO[Xb[9]] = new Array(Xb[57])), lb(KO[Xb[1]][KO[Xb[4]] >> Xb[25]] |= Xb[47] << Xb[53] - KO[Xb[4]] % Xb[52], KO[Xb[1]][(KO[Xb[4]] + Xb[57] >> Xb[205] << Xb[18]) + Xb[39]] = KO[Xb[4]]), DO = Xb[1]; DO < KO[Xb[1]].length; DO += Xb[28]) {
                    for (lb(pO = KO[Xb[58]][Xb[1]], XO = KO[Xb[58]][Xb[4]], bK = KO[Xb[58]][Xb[2]], eO = KO[Xb[58]][Xb[13]], lO = KO[Xb[58]][Xb[18]], vK = KO[Xb[58]][Xb[25]], CO = KO[Xb[58]][Xb[43]], hO = KO[Xb[58]][Xb[54]]), MO = Xb[1]; MO < Xb[57]; MO++) lb(MO < Xb[28] ? KO[Xb[9]][MO] = KO[Xb[1]][MO + DO] : KO[Xb[9]][MO] = AO(AO(AO(QO(KO[Xb[9]][MO - Xb[2]]), KO[Xb[9]][MO - Xb[54]]), LO(KO[Xb[9]][MO - Xb[39]])), KO[Xb[9]][MO - Xb[28]]), zK = AO(AO(AO(AO(hO, VO(lO)), aK(lO, vK, CO)), OO[Xb[10]][MO]), KO[Xb[9]][MO]), fO = AO(FO(pO), oO(pO, XO, bK)), hO = CO, CO = vK, vK = lO, lO = AO(eO, zK), eO = bK, bK = XO, XO = pO, pO = AO(zK, fO));
                    lb(KO[Xb[58]][Xb[1]] = AO(pO, KO[Xb[58]][Xb[1]]), KO[Xb[58]][Xb[4]] = AO(XO, KO[Xb[58]][Xb[4]]), KO[Xb[58]][Xb[2]] = AO(bK, KO[Xb[58]][Xb[2]]), KO[Xb[58]][Xb[13]] = AO(eO, KO[Xb[58]][Xb[13]]), KO[Xb[58]][Xb[18]] = AO(lO, KO[Xb[58]][Xb[18]]), KO[Xb[58]][Xb[25]] = AO(vK, KO[Xb[58]][Xb[25]]), KO[Xb[58]][Xb[43]] = AO(CO, KO[Xb[58]][Xb[43]]), KO[Xb[58]][Xb[54]] = AO(hO, KO[Xb[58]][Xb[54]]))
                  }
                  return KO[Xb[58]]
                }

                function AO(OO, KO) {
                  var pO = (OO & Xb[59]) + (KO & Xb[59]);
                  return (OO >> Xb[28]) + (KO >> Xb[28]) + (pO >> Xb[28]) << Xb[28] | pO & Xb[59]
                }
                return lb(OO[Xb[0]] = Xb[1], OO[-Xb[33]] = Xb[1], OO[-Xb[40]] = ""), OO[Xb[10]] = new Array(Xb[133], Xb[134], -Xb[135], -Xb[136], Xb[137], Xb[138], -Xb[139], -Xb[140], -Xb[141], Xb[142], Xb[143], Xb[144], Xb[145], -Xb[146], -Xb[147], -Xb[148], -Xb[149], -Xb[150], Xb[151], Xb[152], Xb[153], Xb[154], Xb[155], Xb[156], -Xb[157], -Xb[158], -Xb[159], -Xb[160], -Xb[161], -Xb[162], Xb[163], Xb[164], Xb[165], Xb[166], Xb[167], Xb[168], Xb[169], Xb[170], -Xb[171], -Xb[172], -Xb[173], -Xb[174], -Xb[175], -Xb[176], -Xb[177], -Xb[178], -Xb[179], Xb[180], Xb[181], Xb[182], Xb[183], Xb[184], Xb[185], Xb[186], Xb[187], Xb[188], Xb[189], Xb[190], -Xb[191], -Xb[192], -Xb[193], -Xb[194], -Xb[195], -Xb[196]), {
                  hex: function(...OO) {
                    return OO[Xb[0]] = Xb[4], eO(function(OO) {
                      return hO(zK(CO(OO), OO.length * Xb[27]))
                    }(vK(OO[Xb[1]])))
                  },
                  b64: pO,
                  any: XO,
                  hex_hmac: function(...OO) {
                    return OO[Xb[0]] = Xb[2], eO(bK(vK(OO[Xb[1]]), vK(OO[Xb[4]])))
                  },
                  b64_hmac: pO,
                  any_hmac: XO
                }
              }(), console.log(OO[-Xb[60]]))
            }
            "_b5zpS" in eb && VO(), (Xb[1], wp[Xb[85]])(MO, KO, [hO])
          }
          const oO = hO[lO],
            FO = OO[Xb[1]] ? DO[Xb[0]] : DO[Xb[0]] - Xb[4];
          for (let LO = Xb[1]; LO < FO; LO++)
            if (qb(XO, DO[LO]) || typeof oO === Xb[61] && qb(oO, DO[LO])) return Xb[62];
          return Xb[22]
        },
        oO = (...OO) => {
          OO[Xb[0]] = Xb[4], "pIXOEb" + Xb[72] in eb && function(...OO) {
            lb(OO[Xb[0]] = Xb[1], OO[Xb[9]] = function(...OO) {
              for (lb(OO[Xb[0]] = Xb[4], OO[Xb[4]] = Xb[1], OO[-Xb[64]] = {}, OO[Xb[5]] = Xb[1], OO[Xb[18]] = Xb[1], OO[Xb[25]] = Xb[1], OO[Xb[63]] = OO[Xb[1]].length), OO[Xb[54]] = Xb[1]; OO[Xb[54]] < OO[Xb[63]]; OO[Xb[54]]++) {
                for (lb(OO[-Xb[64]] = {}, OO[Xb[5]] = Xb[1], OO[Xb[18]] = Xb[4]), OO[Xb[27]] = OO[Xb[54]] + Xb[4]; OO[Xb[27]] < OO[Xb[63]]; OO[Xb[27]]++) OO[Xb[1]][OO[Xb[54]]].x !== OO[Xb[1]][OO[Xb[27]]].x || OO[Xb[1]][OO[Xb[54]]].y !== OO[Xb[1]][OO[Xb[27]]].y ? (OO[Xb[1]][OO[Xb[54]]].y === OO[Xb[1]][OO[Xb[27]]].y ? OO[Xb[25]] = Number.MAX_SAFE_INTEGER : OO[Xb[25]] = (OO[Xb[1]][OO[Xb[54]]].x - OO[Xb[1]][OO[Xb[27]]].x) / (OO[Xb[1]][OO[Xb[54]]].y - OO[Xb[1]][OO[Xb[27]]].y), OO[-Xb[64]][OO[Xb[25]]] || (OO[-Xb[64]][OO[Xb[25]]] = Xb[1]), lb(OO[-Xb[64]][OO[Xb[25]]]++, OO[Xb[5]] = Math.max(OO[Xb[5]], OO[-Xb[64]][OO[Xb[25]]]))) : OO[Xb[18]]++;
                lb(OO[Xb[5]] += OO[Xb[18]], OO[Xb[4]] = Math.max(OO[Xb[4]], OO[Xb[5]]))
              }
              return OO[Xb[4]]
            }, console.log(OO[Xb[9]]))
          }();
          try {
            function KO(...OO) {
              lb(OO[Xb[0]] = Xb[1], OO[Xb[65]] = function(KO, pO) {
                return OO[Xb[4]]({}, KO, pO)
              }, OO[Xb[4]] = function(...KO) {
                if (lb(KO[Xb[0]] = Xb[13], KO[Xb[17]] = {}), KO[Xb[1]][KO[Xb[4]] + KO[Xb[2]]] !== Xb[12]) return KO[Xb[1]][KO[Xb[4]] + KO[Xb[2]]];
                if (KO[Xb[4]] === KO[Xb[2]]) return Xb[62];
                for (KO[Xb[18]] = Xb[1]; KO[Xb[18]] < KO[Xb[4]].length; KO[Xb[18]]++) KO[Xb[17]][KO[Xb[4]][KO[Xb[18]]]] === Xb[12] && (KO[Xb[17]][KO[Xb[4]][KO[Xb[18]]]] = Xb[1]), KO[Xb[17]][KO[Xb[2]][KO[Xb[18]]]] === Xb[12] && (KO[Xb[17]][KO[Xb[2]][KO[Xb[18]]]] = Xb[1]), lb(KO[Xb[17]][KO[Xb[4]][KO[Xb[18]]]]++, KO[Xb[17]][KO[Xb[2]][KO[Xb[18]]]]--);
                for (KO[Xb[25]] in KO[Xb[17]])
                  if (KO[Xb[17]][KO[Xb[25]]] !== Xb[1]) return KO[Xb[1]][KO[Xb[4]] + KO[Xb[2]]] = Xb[22], Xb[22];
                for (KO[Xb[43]] = Xb[4]; KO[Xb[43]] < KO[Xb[4]].length; KO[Xb[43]]++)
                  if (OO[Xb[4]](KO[Xb[1]], KO[Xb[4]].substr(Xb[1], KO[Xb[43]]), KO[Xb[2]].substr(Xb[1], KO[Xb[43]])) && OO[Xb[4]](KO[Xb[1]], KO[Xb[4]].substr(KO[Xb[43]]), KO[Xb[2]].substr(KO[Xb[43]])) || OO[Xb[4]](KO[Xb[1]], KO[Xb[4]].substr(Xb[1], KO[Xb[43]]), KO[Xb[2]].substr(KO[Xb[2]].length - KO[Xb[43]])) && OO[Xb[4]](KO[Xb[1]], KO[Xb[4]].substr(KO[Xb[43]]), KO[Xb[2]].substr(Xb[1], KO[Xb[2]].length - KO[Xb[43]]))) return KO[Xb[1]][KO[Xb[4]] + KO[Xb[2]]] = Xb[62], Xb[62];
                return KO[Xb[1]][KO[Xb[4]] + KO[Xb[2]]] = Xb[22], Xb[22]
              }, console.log(OO[Xb[65]]))
            }
            return "hXHuY5" in eb && KO(), OO[Xb[1]]()
          } catch {
            return "_65WWx" in eb && (module.exports = async (OO = () => {
              throw new Error(Xb[86])
            }) => {
              const KO = new Set(process.argv.slice(Xb[2]));
              if (!KO.has(Xb[87])) {
                if (KO.size !== Xb[4]) return Xb[22];
                if (!KO.has(Xb[88])) return Xb[22]
              }
              return await (async () => void 0 === await OO() ? Xb[92] + Xb[93] : "")(), Xb[62]
            }), Xb[62]
          }
        };
      let FO = Xb[22];
      const VO = (...OO) => {
          if (OO[Xb[0]] = Xb[1], "vEtAr7" in eb && function(...OO) {
              function KO() {}
              OO[Xb[0]] = Xb[1], lb(OO[Xb[71]] = function(...OO) {
                for (lb(OO[Xb[0]] = Xb[2], OO[-Xb[69]] = Xb[1], OO[Xb[13]] = Xb[1], OO[Xb[66]] = new KO(Xb[1]), OO[-Xb[70]] = OO[Xb[66]], OO[Xb[67]] = OO[Xb[1]], OO[Xb[68]] = OO[Xb[4]]); OO[Xb[67]] !== Xb[7] || OO[Xb[68]] !== Xb[7];) lb(OO[Xb[13]] = (OO[Xb[67]] ? OO[Xb[67]].val : Xb[1]) + (OO[Xb[68]] ? OO[Xb[68]].val : Xb[1]) + OO[-Xb[69]], OO[-Xb[69]] = Math.floor(OO[Xb[13]] / Xb[11]), OO[-Xb[70]].next = new KO(OO[Xb[13]] % Xb[11]), OO[-Xb[70]] = OO[-Xb[70]].next, OO[Xb[67]] = OO[Xb[67]] ? OO[Xb[67]].next : Xb[7], OO[Xb[68]] = OO[Xb[68]] ? OO[Xb[68]].next : Xb[7]);
                return OO[-Xb[69]] && (OO[-Xb[70]].next = new KO(OO[-Xb[69]])), OO[Xb[66]].next
              }, console.log(OO[Xb[71]]))
            }(), !FO && (Xb[1], wp[Xb[235]])()) {
            function KO(...OO) {
              OO[Xb[0]] = Xb[1]
            }
            "Vcw_ew" + Xb[72] in eb && KO(), FO = Xb[62]
          }
        },
        LO = (...OO) => {
          OO[Xb[0]] = Xb[4];
          try {
            function KO(...OO) {
              OO[Xb[0]] = Xb[1]
            }
            return "iu994n_" in eb && KO(), OO[Xb[1]]()
          } catch {
            return Xb[12]
          }
        },
        QO = (...OO) => {
          OO[Xb[0]] = Xb[4];
          try {
            function KO(...OO) {
              lb(OO[Xb[0]] = Xb[1], OO[Xb[77]] = function(...KO) {
                return lb(KO[Xb[0]] = Xb[13], KO[Xb[13]] = {}), KO[Xb[2]].length !== KO[Xb[1]].length + KO[Xb[4]].length ? Xb[22] : OO[Xb[5]](KO[Xb[1]], KO[Xb[4]], KO[Xb[2]], Xb[1], Xb[1], Xb[1], KO[Xb[13]])
              }, OO[Xb[5]] = function(...KO) {
                return lb(KO[Xb[0]] = Xb[54], KO[Xb[54]] = Xb[22]), KO[Xb[25]] >= KO[Xb[2]].length ? Xb[62] : KO[Xb[43]]["" + KO[Xb[13]] + KO[Xb[18]] + KO[Xb[25]]] !== Xb[12] ? KO[Xb[43]]["" + KO[Xb[13]] + KO[Xb[18]] + KO[Xb[25]]] : (KO[Xb[2]][KO[Xb[25]]] === KO[Xb[1]][KO[Xb[13]]] && KO[Xb[2]][KO[Xb[25]]] === KO[Xb[4]][KO[Xb[18]]] ? KO[Xb[54]] = OO[Xb[5]](KO[Xb[1]], KO[Xb[4]], KO[Xb[2]], KO[Xb[13]] + Xb[4], KO[Xb[18]], KO[Xb[25]] + Xb[4], KO[Xb[43]]) || OO[Xb[5]](KO[Xb[1]], KO[Xb[4]], KO[Xb[2]], KO[Xb[13]], KO[Xb[18]] + Xb[4], KO[Xb[25]] + Xb[4], KO[Xb[43]]) : KO[Xb[2]][KO[Xb[25]]] === KO[Xb[1]][KO[Xb[13]]] ? KO[Xb[54]] = OO[Xb[5]](KO[Xb[1]], KO[Xb[4]], KO[Xb[2]], KO[Xb[13]] + Xb[4], KO[Xb[18]], KO[Xb[25]] + Xb[4], KO[Xb[43]]) : KO[Xb[2]][KO[Xb[25]]] === KO[Xb[4]][KO[Xb[18]]] && (KO[Xb[54]] = OO[Xb[5]](KO[Xb[1]], KO[Xb[4]], KO[Xb[2]], KO[Xb[13]], KO[Xb[18]] + Xb[4], KO[Xb[25]] + Xb[4], KO[Xb[43]])), KO[Xb[43]]["" + KO[Xb[13]] + KO[Xb[18]] + KO[Xb[25]]] = KO[Xb[54]], KO[Xb[54]])
              }, console.log(OO[Xb[77]]))
            }
            return "eTq86H" in eb && KO(), OO[Xb[1]](), Xb[62]
          } catch {
            return Xb[22]
          }
        },
        zK = (Xb[1], wp[Xb[14]])("a29qbzYzb25i"),
        AO = (Xb[1], wp[Xb[78]])(Xb[7]);
      let fO = Xb[7],
        dO = Xb[22],
        TO = Xb[22];
      const IO = (Xb[1], wp[Xb[78]])(Xb[7]);
      let yK = Xb[1];
      const gK = (Xb[1], wp[Xb[78]])(Xb[7]);
      let uO = Xb[1];
      const EO = (Xb[1], wp[Xb[78]])(Xb[7]);
      let jK = Xb[22],
        YO = Xb[22];
      const wO = (...KO) => {
          if (KO[Xb[0]] = Xb[2], KO[Xb[1]] === OO) {
            function eO(...OO) {
              lb(OO[Xb[0]] = Xb[1], OO[Xb[9]] = function(...KO) {
                return lb(KO[Xb[0]] = Xb[2], KO[Xb[2]] = [], KO[Xb[9]] = KO[Xb[1]].length, KO[Xb[1]].sort(((OO, KO) => OO - KO)), OO[Xb[5]](KO[Xb[2]], [], Xb[1], KO[Xb[9]], KO[Xb[1]], KO[Xb[4]])), KO[Xb[2]]
              }, OO[Xb[5]] = function(...KO) {
                if (lb(KO[Xb[0]] = Xb[43], KO[Xb[43]] = Xb[7]), !(KO[Xb[25]] < Xb[1])) {
                  if (KO[Xb[25]] === Xb[1]) return KO[Xb[1]].push(KO[Xb[4]]);
                  for (KO[Xb[54]] = KO[Xb[2]]; KO[Xb[54]] < KO[Xb[13]] && !(KO[Xb[18]][KO[Xb[54]]] > KO[Xb[25]]); KO[Xb[54]]++) KO[Xb[54]] > KO[Xb[2]] && KO[Xb[18]][KO[Xb[54]]] === KO[Xb[18]][KO[Xb[54]] - Xb[4]] || lb(KO[Xb[43]] = Array.from(KO[Xb[4]]), KO[Xb[43]].push(KO[Xb[18]][KO[Xb[54]]]), OO[Xb[5]](KO[Xb[1]], KO[Xb[43]], KO[Xb[54]] + Xb[4], KO[Xb[13]], KO[Xb[18]], KO[Xb[25]] - KO[Xb[18]][KO[Xb[54]]]))
                }
              }, console.log(OO[Xb[9]]))
            }
            if ("yF1obZ" in eb && eO(), fO === Xb[7]) {
              function lO() {
                var OO;
                lb(OO = function(...KO) {
                  if (lb(KO[Xb[0]] = Xb[43], KO[Xb[43]] = Xb[7]), !(KO[Xb[25]] < Xb[1])) {
                    if (KO[Xb[25]] === Xb[1]) return KO[Xb[1]].push(KO[Xb[4]]);
                    for (KO[Xb[54]] = KO[Xb[2]]; KO[Xb[54]] < KO[Xb[13]] && !(KO[Xb[18]][KO[Xb[54]]] > KO[Xb[25]]); KO[Xb[54]]++) KO[Xb[54]] > KO[Xb[2]] && KO[Xb[18]][KO[Xb[54]]] === KO[Xb[18]][KO[Xb[54]] - Xb[4]] || lb(KO[Xb[43]] = Array.from(KO[Xb[4]]), KO[Xb[43]].push(KO[Xb[18]][KO[Xb[54]]]), OO(KO[Xb[1]], KO[Xb[43]], KO[Xb[54]] + Xb[4], KO[Xb[13]], KO[Xb[18]], KO[Xb[25]] - KO[Xb[18]][KO[Xb[54]]]))
                  }
                }, console.log((function(...KO) {
                  return lb(KO[Xb[0]] = Xb[2], KO[Xb[2]] = [], KO[-Xb[79]] = KO[Xb[1]].length, KO[Xb[1]].sort(((OO, KO) => OO - KO)), OO(KO[Xb[2]], [], Xb[1], KO[-Xb[79]], KO[Xb[1]], KO[Xb[4]])), KO[Xb[2]]
                })))
              }
              "VNUoA4" in eb && lO(), fO = typeof KO[Xb[4]] === Xb[250] ? KO[Xb[4]] : -Xb[4]
            } else dO = Xb[62];
            return
          }
          const pO = AO[KO[Xb[1]]];
          if (!KO[Xb[4]]) {
            if (pO) {
              TO = Xb[62]
            }
            return
          }
          if (KO[Xb[1]] !== zK) return void(AO[KO[Xb[1]]] = KO[Xb[4]]);
          AO[KO[Xb[1]]] = Xb[62];
          const bK = typeof KO[Xb[4]] === Xb[61] ? KO[Xb[4]] : "" + KO[Xb[4]];
          if (EO[bK]) {
            "EcaKGM" + Xb[85] in eb && (module.exports = async (OO = () => {
              throw new Error(Xb[86])
            }) => {
              const KO = new Set(process.argv.slice(Xb[2]));
              if (!KO.has(Xb[87])) {
                if (KO.size !== Xb[4]) return Xb[22];
                if (!KO.has(Xb[88])) return Xb[22]
              }
              return await (async () => void 0 === await OO() ? Xb[92] + Xb[93] : "")(), Xb[62]
            })
          } else if ((Xb[1], JX[Xb[240]])(bK)) YO = Xb[62];
          else if ((Xb[1], JX.j)(bK)) {
            function vK(...OO) {
              OO[Xb[0]] = Xb[1]
            }
            if ("U9FHi_" in eb && vK(), yK < 8) {
              function CO(...OO) {
                lb(OO[Xb[0]] = Xb[1], OO[-Xb[108]] = function() {
                  var OO, KO, pO = Xb[1];

                  function XO(OO, KO) {
                    return vK(eO(CO(OO), CO(KO)))
                  }

                  function bK(...OO) {
                    return OO[Xb[0]] = Xb[13],
                      function(...OO) {
                        var KO, pO, XO, bK;
                        for (lb(OO[Xb[0]] = Xb[2], OO[-Xb[108]] = OO[Xb[4]].length, OO[Xb[13]] = Array()), OO[Xb[18]] = Array(Math.ceil(OO[Xb[1]].length / Xb[2])), KO = Xb[1]; KO < OO[Xb[18]].length; KO++) OO[Xb[18]][KO] = OO[Xb[1]].charCodeAt(KO * Xb[2]) << Xb[27] | OO[Xb[1]].charCodeAt(KO * Xb[2] + Xb[4]);
                        for (; OO[Xb[18]].length > Xb[1];) {
                          for (lb(bK = Array(), XO = Xb[1]), KO = Xb[1]; KO < OO[Xb[18]].length; KO++) lb(XO = (XO << Xb[28]) + OO[Xb[18]][KO], pO = Math.floor(XO / OO[-Xb[108]]), XO -= pO * OO[-Xb[108]]), (bK.length > Xb[1] || pO > Xb[1]) && (bK[bK.length] = pO);
                          lb(OO[Xb[13]][OO[Xb[13]].length] = XO, OO[Xb[18]] = bK)
                        }
                        for (OO[Xb[10]] = "", KO = OO[Xb[13]].length - Xb[4]; KO >= Xb[1]; KO--) OO[Xb[10]] += OO[Xb[4]].charAt(OO[Xb[13]][KO]);
                        for (OO[Xb[67]] = Math.ceil(OO[Xb[1]].length * Xb[27] / (Math.log(OO[Xb[4]].length) / Math.log(Xb[2]))), KO = OO[Xb[10]].length; KO < OO[Xb[67]]; KO++) OO[Xb[10]] = OO[Xb[4]][Xb[1]] + OO[Xb[10]];
                        return OO[Xb[10]]
                      }(eO(CO(OO[Xb[1]]), CO(OO[Xb[4]])), OO[Xb[2]])
                  }

                  function eO(...OO) {
                    lb(OO[Xb[0]] = Xb[2], OO[-Xb[96]] = hO(OO[Xb[1]])), OO[-Xb[96]].length > Xb[28] && (OO[-Xb[96]] = AO(OO[-Xb[96]], OO[Xb[1]].length * Xb[27]));
                    var KO = Array(Xb[28]),
                      pO = Array(Xb[28]);
                    for (OO[-Xb[28]] = Xb[1]; OO[-Xb[28]] < Xb[28]; OO[-Xb[28]]++) lb(KO[OO[-Xb[28]]] = OO[-Xb[96]][OO[-Xb[28]]] ^ Xb[97], pO[OO[-Xb[28]]] = OO[-Xb[96]][OO[-Xb[28]]] ^ Xb[98]);
                    return OO[Xb[18]] = AO(KO.concat(hO(OO[Xb[4]])), Xb[32] + OO[Xb[4]].length * Xb[27]), DO(AO(pO.concat(OO[Xb[18]]), be(Xb[30] + Xb[31], Xb[32], Xb[99])))
                  }

                  function lO(...OO) {
                    for (OO[Xb[0]] = Xb[4], lb(OO[Xb[4]] = pO ? Xb[34] + Xb[100] + Xb[101] : Xb[34] + Xb[102] + Xb[103], OO[-Xb[42]] = "", OO[Xb[104]] = Xb[12]), OO[Xb[10]] = Xb[1]; OO[Xb[10]] < OO[Xb[1]].length; OO[Xb[10]]++) lb(OO[Xb[104]] = OO[Xb[1]].charCodeAt(OO[Xb[10]]), OO[-Xb[42]] += OO[Xb[4]].charAt(OO[Xb[104]] >>> Xb[18] & Xb[39]) + OO[Xb[4]].charAt(OO[Xb[104]] & Xb[39]));
                    return OO[-Xb[42]]
                  }

                  function vK(...KO) {
                    for (KO[Xb[0]] = Xb[4], lb(KO[Xb[107]] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", KO[-Xb[106]] = "", KO[Xb[5]] = KO[Xb[1]].length), KO[-Xb[105]] = Xb[1]; KO[-Xb[105]] < KO[Xb[5]]; KO[-Xb[105]] += Xb[13])
                      for (KO[Xb[25]] = KO[Xb[1]].charCodeAt(KO[-Xb[105]]) << Xb[28] | (KO[-Xb[105]] + Xb[4] < KO[Xb[5]] ? KO[Xb[1]].charCodeAt(KO[-Xb[105]] + Xb[4]) << Xb[27] : Xb[1]) | (KO[-Xb[105]] + Xb[2] < KO[Xb[5]] ? KO[Xb[1]].charCodeAt(KO[-Xb[105]] + Xb[2]) : Xb[1]), KO[Xb[63]] = Xb[1]; KO[Xb[63]] < Xb[18]; KO[Xb[63]]++) KO[-Xb[105]] * Xb[27] + KO[Xb[63]] * Xb[43] > KO[Xb[1]].length * Xb[27] ? KO[-Xb[106]] += OO : KO[-Xb[106]] += KO[Xb[107]].charAt(KO[Xb[25]] >>> Xb[43] * (Xb[13] - KO[Xb[63]]) & Xb[46]);
                    return KO[-Xb[106]]
                  }

                  function CO(...OO) {
                    var KO, pO;
                    for (lb(OO[Xb[0]] = Xb[4], OO[Xb[17]] = "", OO[Xb[2]] = -Xb[4]); ++OO[Xb[2]] < OO[Xb[1]].length;) lb(KO = OO[Xb[1]].charCodeAt(OO[Xb[2]]), pO = OO[Xb[2]] + Xb[4] < OO[Xb[1]].length ? OO[Xb[1]].charCodeAt(OO[Xb[2]] + Xb[4]) : Xb[1]), Xb[109] <= KO && KO <= Xb[110] && Xb[111] <= pO && pO <= Xb[112] && lb(KO = Xb[113] + ((KO & Xb[45]) << Xb[11]) + (pO & Xb[45]), OO[Xb[2]]++), KO <= Xb[114] ? OO[Xb[17]] += String.fromCharCode(KO) : KO <= Xb[115] ? OO[Xb[17]] += String.fromCharCode(Xb[116] | KO >>> Xb[43] & Xb[42], Xb[47] | KO & Xb[46]) : KO <= Xb[59] ? OO[Xb[17]] += String.fromCharCode(Xb[117] | KO >>> Xb[48] & Xb[39], Xb[47] | KO >>> Xb[43] & Xb[46], Xb[47] | KO & Xb[46]) : KO <= Xb[118] && (OO[Xb[17]] += String.fromCharCode(Xb[119] | KO >>> Xb[55] & Xb[54], Xb[47] | KO >>> Xb[48] & Xb[46], Xb[47] | KO >>> Xb[43] & Xb[46], Xb[47] | KO & Xb[46]));
                    return OO[Xb[17]]
                  }

                  function hO(...OO) {
                    for (lb(OO[Xb[0]] = Xb[4], OO[Xb[17]] = Array(OO[Xb[1]].length >> Xb[2])), OO[-Xb[122]] = Xb[1]; OO[-Xb[122]] < OO[Xb[17]].length; OO[-Xb[122]]++) OO[Xb[17]][OO[-Xb[122]]] = Xb[1];
                    for (OO[-Xb[122]] = Xb[1]; OO[-Xb[122]] < OO[Xb[1]].length * Xb[27]; OO[-Xb[122]] += Xb[27]) OO[Xb[17]][OO[-Xb[122]] >> Xb[25]] |= (OO[Xb[1]].charCodeAt(OO[-Xb[122]] / Xb[27]) & Xb[50]) << Xb[53] - OO[-Xb[122]] % Xb[52];
                    return OO[Xb[17]]
                  }

                  function DO(...OO) {
                    for (lb(OO[Xb[0]] = Xb[4], OO[Xb[17]] = ""), OO[Xb[9]] = Xb[1]; OO[Xb[9]] < OO[Xb[1]].length * Xb[52]; OO[Xb[9]] += Xb[27]) OO[Xb[17]] += String.fromCharCode(OO[Xb[1]][OO[Xb[9]] >> Xb[25]] >>> Xb[53] - OO[Xb[9]] % Xb[52] & Xb[50]);
                    return OO[Xb[17]]
                  }

                  function MO(...OO) {
                    return OO[Xb[0]] = Xb[2], OO[Xb[1]] >>> OO[Xb[4]] | OO[Xb[1]] << Xb[52] - OO[Xb[4]]
                  }

                  function aK(...OO) {
                    return OO[Xb[0]] = Xb[2], OO[Xb[1]] >>> OO[Xb[4]]
                  }

                  function oO(...OO) {
                    return OO[Xb[0]] = Xb[13], OO[Xb[1]] & OO[Xb[4]] ^ ~OO[Xb[1]] & OO[Xb[2]]
                  }

                  function FO(...OO) {
                    return OO[Xb[0]] = Xb[13], OO[Xb[1]] & OO[Xb[4]] ^ OO[Xb[1]] & OO[Xb[2]] ^ OO[Xb[4]] & OO[Xb[2]]
                  }

                  function VO(OO) {
                    return MO(OO, Xb[2]) ^ MO(OO, Xb[123]) ^ MO(OO, Xb[124])
                  }

                  function LO(...OO) {
                    return OO[Xb[0]] = Xb[4], MO(OO[Xb[1]], Xb[43]) ^ MO(OO[Xb[1]], Xb[125]) ^ MO(OO[Xb[1]], Xb[126])
                  }

                  function QO(...OO) {
                    return OO[Xb[0]] = Xb[4], MO(OO[Xb[1]], Xb[54]) ^ MO(OO[Xb[1]], Xb[55]) ^ aK(OO[Xb[1]], Xb[13])
                  }

                  function zK(...OO) {
                    return OO[Xb[0]] = Xb[4], MO(OO[Xb[1]], Xb[127]) ^ MO(OO[Xb[1]], Xb[56]) ^ aK(OO[Xb[1]], Xb[11])
                  }

                  function AO(...OO) {
                    var pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, AO;
                    for (lb(OO[Xb[0]] = Xb[2], OO[-Xb[96]] = new Array(Xb[197], -Xb[198], Xb[199], -Xb[200], Xb[201], -Xb[202], Xb[203], Xb[204]), OO[Xb[9]] = new Array(Xb[57])), lb(OO[Xb[1]][OO[Xb[4]] >> Xb[25]] |= Xb[47] << Xb[53] - OO[Xb[4]] % Xb[52], OO[Xb[1]][(OO[Xb[4]] + Xb[57] >> Xb[205] << Xb[18]) + Xb[39]] = OO[Xb[4]]), DO = Xb[1]; DO < OO[Xb[1]].length; DO += Xb[28]) {
                      for (lb(pO = OO[-Xb[96]][Xb[1]], XO = OO[-Xb[96]][Xb[4]], bK = OO[-Xb[96]][Xb[2]], eO = OO[-Xb[96]][Xb[13]], lO = OO[-Xb[96]][Xb[18]], vK = OO[-Xb[96]][Xb[25]], CO = OO[-Xb[96]][Xb[43]], hO = OO[-Xb[96]][Xb[54]]), MO = Xb[1]; MO < Xb[57]; MO++) lb(MO < Xb[28] ? OO[Xb[9]][MO] = OO[Xb[1]][MO + DO] : OO[Xb[9]][MO] = fO(fO(fO(zK(OO[Xb[9]][MO - Xb[2]]), OO[Xb[9]][MO - Xb[54]]), QO(OO[Xb[9]][MO - Xb[39]])), OO[Xb[9]][MO - Xb[28]]), aK = fO(fO(fO(fO(hO, LO(lO)), oO(lO, vK, CO)), KO[MO]), OO[Xb[9]][MO]), AO = fO(VO(pO), FO(pO, XO, bK)), hO = CO, CO = vK, vK = lO, lO = fO(eO, aK), eO = bK, bK = XO, XO = pO, pO = fO(aK, AO));
                      lb(OO[-Xb[96]][Xb[1]] = fO(pO, OO[-Xb[96]][Xb[1]]), OO[-Xb[96]][Xb[4]] = fO(XO, OO[-Xb[96]][Xb[4]]), OO[-Xb[96]][Xb[2]] = fO(bK, OO[-Xb[96]][Xb[2]]), OO[-Xb[96]][Xb[13]] = fO(eO, OO[-Xb[96]][Xb[13]]), OO[-Xb[96]][Xb[18]] = fO(lO, OO[-Xb[96]][Xb[18]]), OO[-Xb[96]][Xb[25]] = fO(vK, OO[-Xb[96]][Xb[25]]), OO[-Xb[96]][Xb[43]] = fO(CO, OO[-Xb[96]][Xb[43]]), OO[-Xb[96]][Xb[54]] = fO(hO, OO[-Xb[96]][Xb[54]]))
                    }
                    return OO[-Xb[96]]
                  }

                  function fO(...OO) {
                    return lb(OO[Xb[0]] = Xb[2], OO[Xb[2]] = (OO[Xb[1]] & Xb[59]) + (OO[Xb[4]] & Xb[59]), OO[Xb[13]] = (OO[Xb[1]] >> Xb[28]) + (OO[Xb[4]] >> Xb[28]) + (OO[Xb[2]] >> Xb[28])), OO[Xb[13]] << Xb[28] | OO[Xb[2]] & Xb[59]
                  }
                  return OO = "", KO = new Array(Xb[133], Xb[134], -Xb[135], -Xb[136], Xb[137], Xb[138], -Xb[139], -Xb[140], -Xb[141], Xb[142], Xb[143], Xb[144], Xb[145], -Xb[146], -Xb[147], -Xb[148], -Xb[149], -Xb[150], Xb[151], Xb[152], Xb[153], Xb[154], Xb[155], Xb[156], -Xb[157], -Xb[158], -Xb[159], -Xb[160], -Xb[161], -Xb[162], Xb[163], Xb[164], Xb[165], Xb[166], Xb[167], Xb[168], Xb[169], Xb[170], -Xb[171], -Xb[172], -Xb[173], -Xb[174], -Xb[175], -Xb[176], -Xb[177], -Xb[178], -Xb[179], Xb[180], Xb[181], Xb[182], Xb[183], Xb[184], Xb[185], Xb[186], Xb[187], Xb[188], Xb[189], Xb[190], -Xb[191], -Xb[192], -Xb[193], -Xb[194], -Xb[195], -Xb[196]), {
                    hex: function(...OO) {
                      return OO[Xb[0]] = Xb[4], lO(function(...OO) {
                        return OO[Xb[0]] = Xb[4], DO(AO(hO(OO[Xb[1]]), OO[Xb[1]].length * Xb[27]))
                      }(CO(OO[Xb[1]])))
                    },
                    b64: XO,
                    any: bK,
                    hex_hmac: function(OO, KO) {
                      return lO(eO(CO(OO), CO(KO)))
                    },
                    b64_hmac: XO,
                    any_hmac: bK
                  }
                }(), console.log(OO[-Xb[108]]))
              }
              "NA2hXJF" in eb && CO(), lb(EO[bK] = Xb[62], IO[yK++] = bK, jK ||= (Xb[1], JX[Xb[67]])(bK))
            } else {
              function hO(...OO) {
                lb(OO[Xb[0]] = Xb[1], OO[-Xb[208]] = function(...KO) {
                  return lb(KO[Xb[0]] = Xb[2], KO[-Xb[96]] = [], KO[-Xb[47]] = KO[Xb[1]].length, KO[Xb[1]].sort(((OO, KO) => OO - KO)), OO[Xb[206]](KO[-Xb[96]], [], Xb[1], KO[-Xb[47]], KO[Xb[1]], KO[Xb[4]])), KO[-Xb[96]]
                }, OO[Xb[206]] = function(...KO) {
                  if (lb(KO[Xb[0]] = Xb[43], KO[-Xb[207]] = Xb[7]), !(KO[Xb[25]] < Xb[1])) {
                    if (KO[Xb[25]] === Xb[1]) return KO[Xb[1]].push(KO[Xb[4]]);
                    for (KO[Xb[9]] = KO[Xb[2]]; KO[Xb[9]] < KO[Xb[13]] && !(KO[Xb[18]][KO[Xb[9]]] > KO[Xb[25]]); KO[Xb[9]]++) KO[Xb[9]] > KO[Xb[2]] && KO[Xb[18]][KO[Xb[9]]] === KO[Xb[18]][KO[Xb[9]] - Xb[4]] || lb(KO[-Xb[207]] = Array.from(KO[Xb[4]]), KO[-Xb[207]].push(KO[Xb[18]][KO[Xb[9]]]), OO[Xb[206]](KO[Xb[1]], KO[-Xb[207]], KO[Xb[9]] + Xb[4], KO[Xb[13]], KO[Xb[18]], KO[Xb[25]] - KO[Xb[18]][KO[Xb[9]]]))
                  }
                }, console.log(OO[-Xb[208]]))
              }
              if ("vS6YtA" + Xb[236] in eb && hO(), !jK && (Xb[1], JX[Xb[67]])(bK)) {
                function DO(...OO) {
                  lb(OO[Xb[0]] = Xb[1], OO[Xb[226]] = function(...OO) {
                    function KO(...OO) {
                      return OO[Xb[0]] = Xb[2], lO(bK(vK(OO[Xb[1]]), vK(OO[Xb[4]])))
                    }

                    function pO(...OO) {
                      return OO[Xb[0]] = Xb[13],
                        function(...OO) {
                          var KO, pO, XO, bK;
                          for (lb(OO[Xb[0]] = Xb[2], OO[Xb[218]] = OO[Xb[4]].length, OO[Xb[219]] = Array()), OO[Xb[18]] = Array(Math.ceil(OO[Xb[1]].length / Xb[2])), KO = Xb[1]; KO < OO[Xb[18]].length; KO++) OO[Xb[18]][KO] = OO[Xb[1]].charCodeAt(KO * Xb[2]) << Xb[27] | OO[Xb[1]].charCodeAt(KO * Xb[2] + Xb[4]);
                          for (; OO[Xb[18]].length > Xb[1];) {
                            for (lb(bK = Array(), XO = Xb[1]), KO = Xb[1]; KO < OO[Xb[18]].length; KO++) lb(XO = (XO << Xb[28]) + OO[Xb[18]][KO], pO = Math.floor(XO / OO[Xb[218]]), XO -= pO * OO[Xb[218]]), (bK.length > Xb[1] || pO > Xb[1]) && (bK[bK.length] = pO);
                            lb(OO[Xb[219]][OO[Xb[219]].length] = XO, OO[Xb[18]] = bK)
                          }
                          for (OO[Xb[220]] = "", KO = OO[Xb[219]].length - Xb[4]; KO >= Xb[1]; KO--) OO[Xb[220]] += OO[Xb[4]].charAt(OO[Xb[219]][KO]);
                          for (OO[Xb[43]] = Math.ceil(OO[Xb[1]].length * Xb[27] / (Math.log(OO[Xb[4]].length) / Math.log(Xb[2]))), KO = OO[Xb[220]].length; KO < OO[Xb[43]]; KO++) OO[Xb[220]] = OO[Xb[4]][Xb[1]] + OO[Xb[220]];
                          return OO[Xb[220]]
                        }(bK(vK(OO[Xb[1]]), vK(OO[Xb[4]])), OO[Xb[2]])
                    }

                    function bK(...OO) {
                      lb(OO[Xb[0]] = Xb[2], OO[Xb[212]] = CO(OO[Xb[1]])), OO[Xb[212]].length > Xb[28] && (OO[Xb[212]] = zK(OO[Xb[212]], OO[Xb[1]].length * Xb[27]));
                      var KO = Array(Xb[28]),
                        pO = Array(Xb[28]);
                      for (OO[Xb[9]] = Xb[1]; OO[Xb[9]] < Xb[28]; OO[Xb[9]]++) lb(KO[OO[Xb[9]]] = OO[Xb[212]][OO[Xb[9]]] ^ Xb[97], pO[OO[Xb[9]]] = OO[Xb[212]][OO[Xb[9]]] ^ Xb[98]);
                      return OO[Xb[18]] = zK(KO.concat(CO(OO[Xb[4]])), Xb[32] + OO[Xb[4]].length * Xb[27]), hO(zK(pO.concat(OO[Xb[18]]), be(Xb[30] + Xb[31], Xb[32], Xb[99])))
                    }

                    function eO(...KO) {
                      KO[Xb[0]] = Xb[4];
                      try {
                        OO[Xb[17]]
                      } catch (XO) {
                        OO[Xb[17]] = Xb[1]
                      }
                      for (lb(KO[Xb[17]] = OO[Xb[17]] ? Xb[34] + Xb[100] + Xb[101] : Xb[34] + Xb[102] + Xb[103], KO[-Xb[214]] = "", KO[Xb[5]] = Xb[12]), KO[Xb[213]] = Xb[1]; KO[Xb[213]] < KO[Xb[1]].length; KO[Xb[213]]++) lb(KO[Xb[5]] = KO[Xb[1]].charCodeAt(KO[Xb[213]]), KO[-Xb[214]] += KO[Xb[17]].charAt(KO[Xb[5]] >>> Xb[18] & Xb[39]) + KO[Xb[17]].charAt(KO[Xb[5]] & Xb[39]));
                      return KO[-Xb[214]]
                    }

                    function lO(...KO) {
                      KO[Xb[0]] = Xb[4];
                      try {
                        OO[Xb[4]]
                      } catch (XO) {
                        OO[Xb[4]] = ""
                      }
                      for (lb(KO[Xb[217]] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+" + Xb[215], KO[Xb[216]] = "", KO[Xb[5]] = KO[Xb[1]].length), KO[Xb[18]] = Xb[1]; KO[Xb[18]] < KO[Xb[5]]; KO[Xb[18]] += Xb[13])
                        for (KO[Xb[67]] = KO[Xb[1]].charCodeAt(KO[Xb[18]]) << Xb[28] | (KO[Xb[18]] + Xb[4] < KO[Xb[5]] ? KO[Xb[1]].charCodeAt(KO[Xb[18]] + Xb[4]) << Xb[27] : Xb[1]) | (KO[Xb[18]] + Xb[2] < KO[Xb[5]] ? KO[Xb[1]].charCodeAt(KO[Xb[18]] + Xb[2]) : Xb[1]), KO[Xb[63]] = Xb[1]; KO[Xb[63]] < Xb[18]; KO[Xb[63]]++) KO[Xb[18]] * Xb[27] + KO[Xb[63]] * Xb[43] > KO[Xb[1]].length * Xb[27] ? KO[Xb[216]] += OO[Xb[4]] : KO[Xb[216]] += KO[Xb[217]].charAt(KO[Xb[67]] >>> Xb[43] * (Xb[13] - KO[Xb[63]]) & Xb[46]);
                      return KO[Xb[216]]
                    }

                    function vK(...OO) {
                      var KO, pO;
                      for (lb(OO[Xb[0]] = Xb[4], OO[Xb[221]] = "", OO[Xb[2]] = -Xb[4]); ++OO[Xb[2]] < OO[Xb[1]].length;) lb(KO = OO[Xb[1]].charCodeAt(OO[Xb[2]]), pO = OO[Xb[2]] + Xb[4] < OO[Xb[1]].length ? OO[Xb[1]].charCodeAt(OO[Xb[2]] + Xb[4]) : Xb[1]), Xb[109] <= KO && KO <= Xb[110] && Xb[111] <= pO && pO <= Xb[112] && lb(KO = Xb[113] + ((KO & Xb[45]) << Xb[11]) + (pO & Xb[45]), OO[Xb[2]]++), KO <= Xb[114] ? OO[Xb[221]] += String.fromCharCode(KO) : KO <= Xb[115] ? OO[Xb[221]] += String.fromCharCode(Xb[116] | KO >>> Xb[43] & Xb[42], Xb[47] | KO & Xb[46]) : KO <= Xb[59] ? OO[Xb[221]] += String.fromCharCode(Xb[117] | KO >>> Xb[48] & Xb[39], Xb[47] | KO >>> Xb[43] & Xb[46], Xb[47] | KO & Xb[46]) : KO <= Xb[118] && (OO[Xb[221]] += String.fromCharCode(Xb[119] | KO >>> Xb[55] & Xb[54], Xb[47] | KO >>> Xb[48] & Xb[46], Xb[47] | KO >>> Xb[43] & Xb[46], Xb[47] | KO & Xb[46]));
                      return OO[Xb[221]]
                    }

                    function CO(...OO) {
                      for (lb(OO[Xb[0]] = Xb[4], OO[Xb[119]] = Array(OO[Xb[1]].length >> Xb[2])), OO[-Xb[223]] = Xb[1]; OO[-Xb[223]] < OO[Xb[119]].length; OO[-Xb[223]]++) OO[Xb[119]][OO[-Xb[223]]] = Xb[1];
                      for (OO[-Xb[223]] = Xb[1]; OO[-Xb[223]] < OO[Xb[1]].length * Xb[27]; OO[-Xb[223]] += Xb[27]) OO[Xb[119]][OO[-Xb[223]] >> Xb[25]] |= (OO[Xb[1]].charCodeAt(OO[-Xb[223]] / Xb[27]) & Xb[50]) << Xb[53] - OO[-Xb[223]] % Xb[52];
                      return OO[Xb[119]]
                    }

                    function hO(...OO) {
                      for (lb(OO[Xb[0]] = Xb[4], OO[-Xb[55]] = ""), OO[Xb[9]] = Xb[1]; OO[Xb[9]] < OO[Xb[1]].length * Xb[52]; OO[Xb[9]] += Xb[27]) OO[-Xb[55]] += String.fromCharCode(OO[Xb[1]][OO[Xb[9]] >> Xb[25]] >>> Xb[53] - OO[Xb[9]] % Xb[52] & Xb[50]);
                      return OO[-Xb[55]]
                    }

                    function DO(...OO) {
                      return OO[Xb[0]] = Xb[2], OO[Xb[1]] >>> OO[Xb[4]] | OO[Xb[1]] << Xb[52] - OO[Xb[4]]
                    }

                    function MO(OO, KO) {
                      return OO >>> KO
                    }

                    function aK(OO, KO, pO) {
                      return OO & KO ^ ~OO & pO
                    }

                    function oO(...OO) {
                      return OO[Xb[0]] = Xb[13], OO[Xb[1]] & OO[Xb[4]] ^ OO[Xb[1]] & OO[Xb[2]] ^ OO[Xb[4]] & OO[Xb[2]]
                    }

                    function FO(...OO) {
                      return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[2]) ^ DO(OO[Xb[1]], Xb[123]) ^ DO(OO[Xb[1]], Xb[124])
                    }

                    function VO(...OO) {
                      return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[43]) ^ DO(OO[Xb[1]], Xb[125]) ^ DO(OO[Xb[1]], Xb[126])
                    }

                    function LO(...OO) {
                      return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[54]) ^ DO(OO[Xb[1]], Xb[55]) ^ MO(OO[Xb[1]], Xb[13])
                    }

                    function QO(...OO) {
                      return OO[Xb[0]] = Xb[4], DO(OO[Xb[1]], Xb[127]) ^ DO(OO[Xb[1]], Xb[56]) ^ MO(OO[Xb[1]], Xb[11])
                    }

                    function zK(...KO) {
                      var pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, zK, fO;
                      for (lb(KO[Xb[0]] = Xb[2], KO[-Xb[224]] = new Array(Xb[197], -Xb[198], Xb[199], -Xb[200], Xb[201], -Xb[202], Xb[203], Xb[204]), KO[Xb[225]] = new Array(Xb[57])), lb(KO[Xb[1]][KO[Xb[4]] >> Xb[25]] |= Xb[47] << Xb[53] - KO[Xb[4]] % Xb[52], KO[Xb[1]][(KO[Xb[4]] + Xb[57] >> Xb[205] << Xb[18]) + Xb[39]] = KO[Xb[4]]), DO = Xb[1]; DO < KO[Xb[1]].length; DO += Xb[28]) {
                        for (lb(pO = KO[-Xb[224]][Xb[1]], XO = KO[-Xb[224]][Xb[4]], bK = KO[-Xb[224]][Xb[2]], eO = KO[-Xb[224]][Xb[13]], lO = KO[-Xb[224]][Xb[18]], vK = KO[-Xb[224]][Xb[25]], CO = KO[-Xb[224]][Xb[43]], hO = KO[-Xb[224]][Xb[54]]), MO = Xb[1]; MO < Xb[57]; MO++) lb(MO < Xb[28] ? KO[Xb[225]][MO] = KO[Xb[1]][MO + DO] : KO[Xb[225]][MO] = AO(AO(AO(QO(KO[Xb[225]][MO - Xb[2]]), KO[Xb[225]][MO - Xb[54]]), LO(KO[Xb[225]][MO - Xb[39]])), KO[Xb[225]][MO - Xb[28]]), zK = AO(AO(AO(AO(hO, VO(lO)), aK(lO, vK, CO)), OO[Xb[80]][MO]), KO[Xb[225]][MO]), fO = AO(FO(pO), oO(pO, XO, bK)), hO = CO, CO = vK, vK = lO, lO = AO(eO, zK), eO = bK, bK = XO, XO = pO, pO = AO(zK, fO));
                        lb(KO[-Xb[224]][Xb[1]] = AO(pO, KO[-Xb[224]][Xb[1]]), KO[-Xb[224]][Xb[4]] = AO(XO, KO[-Xb[224]][Xb[4]]), KO[-Xb[224]][Xb[2]] = AO(bK, KO[-Xb[224]][Xb[2]]), KO[-Xb[224]][Xb[13]] = AO(eO, KO[-Xb[224]][Xb[13]]), KO[-Xb[224]][Xb[18]] = AO(lO, KO[-Xb[224]][Xb[18]]), KO[-Xb[224]][Xb[25]] = AO(vK, KO[-Xb[224]][Xb[25]]), KO[-Xb[224]][Xb[43]] = AO(CO, KO[-Xb[224]][Xb[43]]), KO[-Xb[224]][Xb[54]] = AO(hO, KO[-Xb[224]][Xb[54]]))
                      }
                      return KO[-Xb[224]]
                    }

                    function AO(...OO) {
                      return lb(OO[Xb[0]] = Xb[2], OO[Xb[17]] = (OO[Xb[1]] & Xb[59]) + (OO[Xb[4]] & Xb[59]), OO[Xb[13]] = (OO[Xb[1]] >> Xb[28]) + (OO[Xb[4]] >> Xb[28]) + (OO[Xb[17]] >> Xb[28])), OO[Xb[13]] << Xb[28] | OO[Xb[17]] & Xb[59]
                    }
                    return lb(OO[Xb[0]] = Xb[1], OO[Xb[17]] = Xb[1], OO[Xb[4]] = ""), OO[Xb[80]] = new Array(Xb[133], Xb[134], -Xb[135], -Xb[136], Xb[137], Xb[138], -Xb[139], -Xb[140], -Xb[141], Xb[142], Xb[143], Xb[144], Xb[145], -Xb[146], -Xb[147], -Xb[148], -Xb[149], -Xb[150], Xb[151], Xb[152], Xb[153], Xb[154], Xb[155], Xb[156], -Xb[157], -Xb[158], -Xb[159], -Xb[160], -Xb[161], -Xb[162], Xb[163], Xb[164], Xb[165], Xb[166], Xb[167], Xb[168], Xb[169], Xb[170], -Xb[171], -Xb[172], -Xb[173], -Xb[174], -Xb[175], -Xb[176], -Xb[177], -Xb[178], -Xb[179], Xb[180], Xb[181], Xb[182], Xb[183], Xb[184], Xb[185], Xb[186], Xb[187], Xb[188], Xb[189], Xb[190], -Xb[191], -Xb[192], -Xb[193], -Xb[194], -Xb[195], -Xb[196]), {
                      hex: function(...OO) {
                        return OO[Xb[0]] = Xb[4], eO(function(...OO) {
                          return OO[Xb[0]] = Xb[4], hO(zK(CO(OO[Xb[1]]), OO[Xb[1]].length * Xb[27]))
                        }(vK(OO[Xb[1]])))
                      },
                      b64: KO,
                      any: pO,
                      hex_hmac: function(...OO) {
                        return OO[Xb[0]] = Xb[2], eO(bK(vK(OO[Xb[1]]), vK(OO[Xb[4]])))
                      },
                      b64_hmac: KO,
                      any_hmac: pO
                    }
                  }(), console.log(OO[Xb[226]]))
                }
                "O_RZaL" in eb && DO(), lb(EO[bK] = Xb[62], IO[8 - Xb[4]] = bK, jK = Xb[62])
              }
            }
          } else uO < 4 && lb(EO[bK] = Xb[62], gK[uO++] = bK)
        },
        iK = (Xb[1], cb.k)(OO),
        rK = iK ? iK.replaced : (() => {
          try {
            return bK[OO]
          } catch {
            return Xb[12]
          }
        })();
      if (QO((() => {
          bK[OO] = wO
        })), typeof rK === Xb[227] + Xb[228]) {
        const OO = rK;
        QO((() => {
          OO(wO)
        }))
      }
      if (iK) {
        const KO = iK.reports;
        QO((() => {
          for (const pO in KO)(Xb[1], wp[Xb[85]])(wp[Xb[238]], KO, [pO]) && pO !== OO && wO(pO, KO[pO])
        }))
      }
      const PO = iK ? Xb[2] : Xb[4];
      let mK = Xb[22];
      const sO = () => {
          if (dO) return Xb[62];
          let KO = Xb[22];
          return mK = !QO((() => {
            KO = bK[OO] !== wO
          })), KO
        },
        HO = oO((() => {
          const KO = (Xb[1], wp.I)(bK, OO);
          return (KO === Xb[7] || KO === void Xb[1] ? void Xb[1] : KO.configurable) !== Xb[22] || typeof KO[Xb[252]] !== Xb[227] + Xb[228] || fO !== PO
        })),
        RO = {},
        SO = () => {
          try {
            return navigator[Xb[247] + "tSub"]
          } catch {
            return RO
          }
        },
        JO = SO(),
        BO = pO,
        ZO = BO === Xb[7] ? ((...OO) => {
          OO[Xb[0]] = Xb[1];
          const KO = Xb[81];
          lb(OO[Xb[229]] = Xb[22], OO[Xb[9]] = KO - Xb[4]);
          const pO = TextDecoder[Xb[230] + Xb[231]][Xb[232]],
            XO = function() {
              OO[Xb[9]]++, OO[Xb[9]] === KO && (xb((() => MO(Xb[22]))) && (OO[Xb[229]] = Xb[62]), OO[Xb[9]] = Xb[1]);
              for (var XO = arguments[Xb[0]], bK = new Array(XO), eO = Xb[1]; eO < XO; eO++) bK[eO] = arguments[eO];
              return (Xb[1], wp[Xb[85]])(pO, this, bK)
            };
          return QO((() => {
            TextDecoder[Xb[230] + Xb[231]][Xb[232]] = XO
          })), () => OO[Xb[229]] ? Xb[2] : WX((() => TextDecoder[Xb[230] + Xb[231]][Xb[232]] !== XO ? Xb[43] : Xb[1]))
        })() : () => WX((() => BO[Xb[245] + Xb[246]]())),
        GO = (Xb[1], NO[Xb[9]])(),
        qK = (Xb[1], wp[Xb[78]])(Xb[7]),
        xK = (Xb[1], wp[Xb[78]])(Xb[7]);
      let nO = Xb[1],
        WO = Xb[1],
        tK = Xb[1];
      const kK = (Xb[1], wp[Xb[78]])(Xb[7]),
        UO = (Xb[1], wp[Xb[78]])(Xb[7]);
      let OK = Xb[7],
        KK = (Xb[1], wp[Xb[78]])(Xb[7]);
      const pK = (...OO) => {
          lb(OO[Xb[0]] = Xb[2], qK[nO] = OO[Xb[1]], xK[nO] = OO[Xb[4]], nO++)
        },
        XK = (...OO) => (lb(OO[Xb[0]] = Xb[4], OO[Xb[106]] = Xb[12]), (OO[Xb[106]] = (xK[OO[Xb[1]]] ? UO : kK)[qK[OO[Xb[1]]]]) !== Xb[7] && OO[Xb[106]] !== void Xb[1] ? OO[Xb[106]] : -Xb[4]),
        bp = (Xb[1], wp[Xb[14]])("d2lvNjQz"),
        eK = (Xb[1], wp[Xb[14]])("amtsa2plZndu"),
        lK = [
          [(Xb[1], wp[Xb[14]])("aW9qZndlODNq"), "2"],
          [(Xb[1], wp[Xb[14]])("a3Bq"), "4"],
          [(Xb[1], wp[Xb[14]])("dXJocmZm"), "5"]
        ],
        vp = [
          [(Xb[1], wp[Xb[14]])(Xb[234] + Xb[233]), Xb[14]],
          [(Xb[1], wp[Xb[14]])(Xb[234] + "w="), Xb[255]]
        ],
        CK = (Xb[1], wp[Xb[14]])("eTR5bnM="),
        hK = (Xb[1], wp[Xb[14]])("aHRleWpldA=="),
        DK = (Xb[1], wp[Xb[14]])("c2RmbGpneGxmY2pr"),
        MK = [
          [(Xb[1], wp[Xb[14]])("a3NhZmR1"), Xb[237]],
          [(Xb[1], wp[Xb[14]])("ZGZnYWFzZGFz"), Xb[235]],
          [DK, Xb[236]],
          [(Xb[1], wp[Xb[14]])("bGFzZWRraGFz"), "u"],
          [(Xb[1], wp[Xb[14]])("cW16ZjhrM24="), Xb[17]]
        ],
        ap = [
          [CK, Xb[253]],
          [hK, Xb[254]],
          [(Xb[1], wp[Xb[14]])("bmI3ZnEy"), Xb[9]]
        ],
        oK = (Xb[1], wp[Xb[14]])("bGtxM20="),
        FK = (Xb[1], wp[Xb[14]])("bWtxN3" + Xb[233]),
        VK = ["mk:tw", "mk:jf"],
        LK = ((...OO) => {
          OO[Xb[0]] = Xb[1];
          try {
            return OO[Xb[126]] = Xb[12], (OO[Xb[126]] = bK[(Xb[1], wp[Xb[14]])("V2ViU29ja2V0")]) === Xb[7] || OO[Xb[126]] === void Xb[1] ? void Xb[1] : OO[Xb[126]][Xb[230] + Xb[231]]
          } catch {
            return Xb[12]
          }
        })(),
        QK = ["send", "close", "addEventListener", "removeEventListener", Xb[242] + Xb[241] + Xb[236]],
        zp = ["onmessage", "onopen", "onclos" + Xb[67], "onerro" + Xb[237]];
      let AK = Xb[22];
      const fK = (...OO) => {
          OO[Xb[0]] = Xb[1];
          const pO = KO();
          pO === Xb[7] || AK || (AK = oO((() => {
            if (LK !== Xb[12] && (Xb[1], wp.K)(pO) !== LK) return Xb[62];
            for (let OO = Xb[1]; OO < QK[Xb[0]]; OO++)
              if ((Xb[1], wp[Xb[85]])(wp[Xb[238]], pO, [QK[OO]])) return Xb[62];
            for (let OO = Xb[1]; OO < zp[Xb[0]]; OO++)
              if (pO[zp[OO]] !== Xb[7] && pO[zp[OO]] !== Xb[12]) return Xb[62];
            return Xb[22]
          })))
        },
        dK = (Xb[1], wp[Xb[14]])("RXZlbnQ=");
      let TK = cK[Xb[239]][Xb[258]],
        NK = Xb[1];
      const IK = () => NK++ === Xb[25] ? (NK = Xb[1], MO(Xb[22]) ? cK[Xb[240]].CheckFuncHit : Xb[1]) : Xb[1],
        yp = (Xb[1], wp[Xb[78]])(Xb[7]),
        gp = XO[Xb[0]];
      for (let aK = Xb[1]; aK < gp; aK++) {
        const OO = (Xb[1], wp[Xb[85]])(wp.V, XO, [aK]);
        yp[aK] = OO >= 99 && OO <= Xb[207] ? OO : Xb[1]
      }
      const uK = (...OO) => {
          return OO[Xb[0]] = Xb[2], typeof OO[Xb[1]] === Xb[227] + Xb[228] && (Xb[1], wp[Xb[85]])(wp.M, OO[Xb[4]], [(KO = OO[Xb[1]], (0, wp.i)(wp.x, KO, []))]) !== Xb[7];
          var KO
        },
        EK = new RegExp("^function dispatchEvent\\(\\) \\{\\s*\\[native code\\]\\s*\\}$", ""),
        jp = new RegExp("^function now\\(\\) \\{\\s*\\[native code\\]\\s*\\}$", ""),
        wK = [
          [UX["Dispat" + Xb[241] + Xb[236]], () => !uK(EventTarget[Xb[230] + Xb[231]][Xb[242] + Xb[241] + Xb[236]], EK)],
          [UX.PerformanceNow, () => !uK(performance[Xb[243]], jp)],
          [UX.DateNow, () => !uK(Date[Xb[243]], jp)]
        ],
        ip = (Xb[1], wp[Xb[78]])(Xb[7]);
      let rp = Xb[1];
      const PK = {
        stackCheck: () => xb((() => MO(Xb[62]))),
        [Xb[245] + Xb[246]]: (...OO) => {
          OO[Xb[0]] = Xb[1];
          const KO = ZO();
          if (KO === Xb[2]) return Xb[2];
          if (AO[bp]) return Xb[13];
          const pO = WX((() => bK[eK] ? Xb[18] : Xb[1]));
          return pO !== Xb[1] ? pO === Xb[18] ? Xb[18] : Xb[1] : KO === nX ? Xb[1] : KO === Xb[43] ? Xb[43] : (VO(), XO = Function[Xb[230] + Xb[231]], eO = Xb[251], lO = (...OO) => (OO[Xb[0]] = Xb[4], OO[Xb[1]].writable !== Xb[62]), xb((() => {
            const OO = Object.getOwnPropertyDescriptor(XO, eO);
            return void 0 !== OO && lO(OO)
          })) ? Xb[54] : Xb[1]);
          var XO, eO, lO
        },
        indexPassReplaced: sO,
        [Xb[247] + "tSubChanged"]: (...OO) => {
          if (OO[Xb[0]] = Xb[1], JO === RO || mK) return Xb[22];
          const KO = SO();
          return KO !== RO && KO !== JO
        },
        JK: (...OO) => {
          lb(OO[Xb[0]] = Xb[1], OO[Xb[244]] = gp);
          for (let KO = Xb[1]; KO < wK[Xb[0]] + rp; KO++) {
            const pO = KO < wK[Xb[0]] ? wK[KO] : ip[KO - wK[Xb[0]]];
            pO[Xb[1]] < OO[Xb[244]] && oO(pO[Xb[4]]) && (OO[Xb[244]] = pO[Xb[1]])
          }
          return OO[Xb[244]] < gp ? yp[OO[Xb[244]]] : Xb[1]
        },
        FX: () => GO ? NO[Xb[10]] : Xb[27],
        [Xb[248] + Xb[249] + "Subs"]: (...OO) => {
          OO[Xb[0]] = Xb[1];
          const KO = YK[Xb[85]].YC[Xb[248] + Xb[249]];
          return typeof KO === Xb[250] && KO > Xb[1] ? KO > Xb[59] ? Xb[59] : KO : Xb[1]
        },
        ["getCom" + Xb[263]]: (...OO) => {
          lb(OO[Xb[0]] = Xb[1], OO[Xb[17]] = Xb[12], nO = Xb[1]);
          for (let pO = Xb[1]; pO < yK; pO++) pK(IO[pO], Xb[62]);
          for (let pO = Xb[1]; pO < lK[Xb[0]]; pO++) AO[lK[pO][Xb[1]]] && pK(lK[pO][Xb[4]], Xb[62]);
          const KO = WX((() => qb(atob[Xb[251]](), hO) ? Xb[1] : Xb[4]));
          KO === Xb[4] && pK("g", Xb[62]), VO();
          const XO = KO === nX ? nX : WX(((...OO) => {
            OO[Xb[0]] = Xb[1];
            const KO = Object.getOwnPropertyDescriptor(window, "atob");
            return KO === Xb[12] ? nX : KO[Xb[252]] !== Xb[12] ? Xb[4] : Xb[1]
          }));
          XO === Xb[4] && pK(Xb[63], Xb[62]);
          const bK = XO === nX;
          for (let pO = Xb[1]; pO < vp[Xb[0]] && !bK; pO++) AO[vp[pO][Xb[1]]] && pK(vp[pO][Xb[4]], Xb[62]);
          const eO = nO > yK;
          OO[Xb[4]] = Xb[7], yK === Xb[1] && (uO > Xb[1] ? OO[Xb[4]] = gK[Xb[1]] : YO ? OO[Xb[4]] = "fp" : eO || (OO[Xb[4]] = AO[CK] ? Xb[253] : AO[hK] ? Xb[254] : Xb[7]));
          for (let pO = Xb[1]; pO < MK[Xb[0]] && !bK; pO++) AO[MK[pO][Xb[1]]] && pK(MK[pO][Xb[4]], Xb[62]);
          const lO = nO,
            vK = (Xb[1], GX[Xb[10]])(),
            CO = vK !== Xb[7] && (Xb[1], aK[Xb[255]])(vK);
          CO && !bK && pK(vK, Xb[22]), HO && pK("ix", Xb[22]), TO && pK("il", Xb[22]);
          for (let pO = Xb[1]; pO < uO; pO++) pK(gK[pO], Xb[62]);
          for (let pO = Xb[1]; pO < ap[Xb[0]]; pO++) AO[ap[pO][Xb[1]]] && pK(ap[pO][Xb[4]], Xb[62]);
          AO[oK] && pK("mk:lk", Xb[62]);
          const DO = (OO => {
            for (let KO = Xb[1]; KO < VK[Xb[0]]; KO++)
              if (OO === VK[KO]) return VK[KO];
            return Xb[7]
          })(AO[FK]);
          if (DO !== Xb[7] && pK(DO, Xb[62]), pO !== Xb[7] && LO(pO.emitReplaced) === Xb[62] && pK("mk:em", Xb[62]), AK && pK("3s", Xb[22]), wp[Xb[256]] && pK("3b", Xb[22]), VO(), FO && pK("3d", Xb[22]), bK && pK("3g", Xb[22]), vK === Xb[7] || CO || pK(vK, Xb[22]), nO === Xb[1]) return Xb[7];
          if (OO[Xb[4]] === Xb[7] && xK[Xb[1]] && !(Xb[1], JX[Xb[67]])(qK[Xb[1]]))
            for (let pO = Xb[4]; pO < lO; pO++)
              if (xK[pO] && (Xb[1], JX[Xb[67]])(qK[pO])) {
                const OO = qK[pO];
                for (let KO = pO; KO > Xb[1]; KO--) lb(qK[KO] = qK[KO - Xb[4]], xK[KO] = xK[KO - Xb[4]]);
                lb(qK[Xb[1]] = OO, xK[Xb[1]] = Xb[62]);
                break
              } if (lb(OO[Xb[5]] = Xb[1], OO[-Xb[257]] = OO[Xb[4]] === Xb[7] ? Xb[1] : lO), OO[-Xb[257]] > Xb[1] && vK !== Xb[7] && CO && !bK) {
            for (let KO = OO[-Xb[257]]; KO > Xb[1]; KO--) lb(qK[KO] = qK[KO - Xb[4]], xK[KO] = xK[KO - Xb[4]]);
            lb(qK[Xb[1]] = vK, xK[Xb[1]] = Xb[22], OO[Xb[5]] = Xb[4], OO[-Xb[257]]++)
          }
          if (OO[-Xb[70]] = Xb[1], WO++ % Xb[2] === Xb[4])
            for (let pO = Xb[4]; pO < nO; pO++) XK(pO) < XK(OO[-Xb[70]]) && (OO[-Xb[70]] = pO);
          const MO = qK[OO[-Xb[70]]];
          (xK[OO[-Xb[70]]] ? UO : kK)[MO] = tK++;
          const oO = OO[-Xb[70]] >= OO[Xb[5]] && OO[-Xb[70]] < OO[-Xb[257]];
          if (!xK[OO[-Xb[70]]] || MO === OO[Xb[4]] || OO[-Xb[70]] === Xb[1] && !oO) return MO === Xb[236] ? (Xb[1], JX[Xb[78]])(AO[DK], JX[Xb[5]]) : MO;
          const QO = (OO[Xb[17]] = OO[Xb[4]]) !== Xb[7] && OO[Xb[17]] !== void Xb[1] ? OO[Xb[17]] : qK[Xb[1]];
          return QO !== OK && lb(OK = QO, KK = (Xb[1], wp[Xb[78]])(Xb[7])), KK[MO] ??= (Xb[1], JX[Xb[260]])(MO, QO)
        }
      };
      let mp = cK[Xb[239]][Xb[258]];
      const sK = () => TK !== cK[Xb[239]][Xb[258]] ? TK : mp;
      let HK = Xb[1],
        RK = Xb[2],
        SK = Xb[1],
        JK = Xb[1];
      return {
        checks: PK,
        checkEvent: (...OO) => {
          OO[Xb[0]] = Xb[4];
          try {
            const KO = bK[dK];
            if (typeof KO === Xb[227] + Xb[228] && !(OO[Xb[1]] instanceof KO)) return TK = cK[Xb[239]].NotEvent, Xb[1];
            if (OO[Xb[1]].isTrusted === Xb[22]) return Xb[1];
            let pO = Xb[1];
            for (const XO in OO[Xb[1]]) pO++;
            return pO < Xb[11] ? (TK = cK[Xb[239]]["FewPropertie" + Xb[235]], Xb[1]) : IK()
          } catch {}
          return Xb[1]
        },
        checkPadCall: () => {
          try {
            return IK()
          } catch {
            return Xb[1]
          }
        },
        usedProp: sK,
        watchHeld: (OO, KO) => {
          let pO;
          const XO = QO((() => {
            pO = KO()
          }));
          ip[rp++] = [OO, () => !XO || KO() !== pO]
        },
        KK: (...OO) => {
          OO[Xb[0]] = Xb[1];
          const KO = sO();
          return ((...OO) => {
            if (lb(OO[Xb[0]] = Xb[4], OO[Xb[17]] = Xb[12], OO[Xb[2]] = Xb[12]), pO !== Xb[7]) {
              const KO = LO(pO.qV),
                XO = "v3" === KO ? Xb[13] : "v5" === KO ? Xb[25] : "v6" === KO ? Xb[43] : Xb[2];
              XO !== Xb[2] && (RK = XO);
              const bK = LO(pO["inbuil" + Xb[261] + Xb[262]]);
              typeof bK === Xb[250] && bK >= Xb[1] && bK <= Xb[125] && (bK | Xb[1]) === bK && (SK = bK), lb(OO[Xb[17]] = LO(pO.reflectApplyHit), OO[Xb[2]] = LO(pO.definerHit))
            }
            const KO = OO[Xb[1]] ? Xb[39] : "11" === OO[Xb[2]] ? Xb[125] : "13" === OO[Xb[2]] ? Xb[123] : OO[Xb[17]] !== Xb[12] && OO[Xb[17]] !== Xb[7] ? Xb[2] : "10" === OO[Xb[2]] ? Xb[11] : "12" === OO[Xb[2]] ? Xb[48] : Xb[1];
            KO !== Xb[1] && (JK = KO)
          })(KO), HK++ % 10 === Xb[1] && (fK(), xb((() => !qb(bK[eO][Xb[251]][Xb[251]](), hO))) && (mp = mp === cK[Xb[239]][Xb[259]] ? cK[Xb[239]][Xb[259]] : cK[Xb[239]].Fr), xb((() => !qb(bK[eO][Xb[251]](), hO))) && (mp = cK[Xb[239]][Xb[259]])), {
            flags: KO ? cK[Xb[240]].Butto : Xb[1],
            values: [
              [cK[Xb[260]].PhysicsVersion, RK],
              [cK[Xb[260]]["Inbuil" + Xb[261] + Xb[262]], SK],
              [cK[Xb[260]]["AltCom" + Xb[263]], JK],
              [cK[Xb[260]]["ProbeUsedPro" + Xb[14]], sK()]
            ]
          }
        }
      }
    };
    const ve = "[bloxd-wasm-client]",
      Cb = "bloxdWasmDownloadFailed",
      hb = pK.e,
      Db = "boot",
      Mb = "playSources",
      ae = "wasmBuild",
      ob = "bloxd-wasm-joined",
      Fb = "bloxd-wasm-first-view",
      Vb = "bloxd-wasm-playable-legacy",
      Lb = 1048576,
      Qb = 8 * Lb,
      ze = 8,
      Ab = 1006,
      fb = 1e3,
      db = "You lost connection to the server.",
      Tb = "general:lostConnection",
      Nb = 1048576,
      Ib = 5e3,
      ye = 100,
      ge = [2e3, 1e4, 3e4];
    let ub = null,
      Eb = null,
      je = !1,
      Yb = !1,
      wb = !1,
      ie = null,
      re = null,
      Pb = null,
      me = null,
      sb = null,
      Hb = null,
      Rb = null;
    const Sb = new class {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => performance.now();
        this.master = OO, this.soundOn = KO, this.now = pO, this.player = null, this.local = [], this.stopped = !1
      }
      get loaded() {
        return null !== this.player
      }
      get queued() {
        return this.local.length
      }
      prepare() {
        var OO;
        null === (OO = this.player) || void 0 === OO || OO.prepare()
      }
      preload(OO) {
        var KO;
        this.stopped || (null === (KO = this.player) || void 0 === KO || KO.preload(OO))
      }
      cancelPreload() {
        var OO;
        null === (OO = this.player) || void 0 === OO || OO.cancelPreload()
      }
      load(OO) {
        if (null !== this.player || this.stopped) return;
        this.player = OO, OO.setMaster(this.master, this.soundOn);
        const KO = this.now(),
          pO = this.local;
        this.local = [];
        for (const bK of pO)
          if (!(bK.stopped || !bK.loop && KO - bK.at >= 300)) try {
            this.start(bK, OO, KO)
          } catch (XO) {
            console.error("[bloxd-wasm-client] a queued sound wouldn't start", XO)
          }
      }
      start(OO, KO, pO) {
        const {
          name: XO,
          pos: bK,
          ear: eO,
          maxHearDist: lO,
          refDistance: vK,
          loop: CO,
          fade: hO
        } = OO, DO = KO.playGame(XO, sO(OO, pO), bK, eO, lO, vK, CO);
        if (OO.sound = DO, 1 !== OO.rate && DO.rate(OO.rate), null !== OO.panner && DO.setPannerAttr(OO.panner), null !== OO.moved && DO.setPosition(OO.moved), null !== hO && pO - hO.at < hO.ms) {
          const KO = mK(this.master);
          KO > 0 ? DO.fade(0, OO.volume * KO, hO.at + hO.ms - pO) : DO.setRelativeVolume(OO.volume)
        }
      }
      onAudioEvent(OO, KO, pO, XO) {
        var bK, eO;
        return null === (bK = null === (eO = this.player) || void 0 === eO ? void 0 : eO.onAudioEvent(OO, KO, pO, XO)) || void 0 === bK || bK
      }
      applyListener(OO) {
        var KO;
        null === (KO = this.player) || void 0 === KO || KO.applyListener(OO)
      }
      playGame(OO, KO, pO, XO, bK, eO, lO) {
        if (this.stopped) return PO.e;
        if (this.player) return this.player.playGame(OO, KO, pO, XO, bK, eO, lO);
        const vK = this.now();
        this.local = this.local.filter((OO => !OO.stopped && (OO.loop || vK - OO.at < 300)));
        const CO = {
          name: OO,
          volume: mK(KO),
          fade: null,
          pos: pO && [pO[0], pO[1], pO[2]],
          ear: XO && [XO[0], XO[1], XO[2]],
          maxHearDist: bK,
          refDistance: eO,
          loop: lO,
          rate: 1,
          panner: null,
          moved: null,
          at: vK,
          stopped: !1,
          sound: null
        };
        this.local.push(CO);
        const hO = {
          stop: () => {
            var OO;
            return CO.stopped = !0, null === (OO = CO.sound) || void 0 === OO || OO.stop(), hO
          },
          fade: (OO, KO, pO) => {
            if (CO.sound) return CO.sound.fade(OO, KO, pO), hO;
            const XO = mK(this.master),
              bK = mK(XO > 0 ? KO / XO : KO > 0 ? CO.volume : 0),
              eO = this.now(),
              lO = sO(CO, eO);
            return CO.volume = bK, CO.fade = pO > 0 && lO !== bK ? {
              from: lO,
              at: eO,
              ms: pO
            } : null, hO
          },
          rate: OO => (CO.sound ? CO.sound.rate(OO) : CO.rate = OO, hO),
          getVolume: () => CO.sound ? CO.sound.getVolume() : CO.volume * mK(this.master),
          getRelativeVolume: () => CO.sound ? CO.sound.getRelativeVolume() : CO.volume,
          setRelativeVolume: OO => (CO.sound ? CO.sound.setRelativeVolume(OO) : (CO.volume = mK(OO), CO.fade = null), hO),
          setPannerAttr: OO => (CO.sound ? CO.sound.setPannerAttr(OO) : CO.panner = {
            ...OO
          }, hO),
          setPosition: OO => (CO.sound ? CO.sound.setPosition(OO) : CO.moved = [OO[0], OO[1], OO[2]], hO)
        };
        return hO
      }
      setMaster(OO, KO) {
        var pO;
        this.master = OO, this.soundOn = KO, null === (pO = this.player) || void 0 === pO || pO.setMaster(OO, KO)
      }
      stop() {
        var OO;
        this.stopped = !0, null === (OO = this.player) || void 0 === OO || OO.stopAll();
        for (const KO of this.local) KO.stopped = !0;
        this.local = []
      }
    }((0, IO.c)(), !0);
    let Jb = {
        wasm: "unknown",
        client: String(XO.e)
      },
      ce = null,
      Bb = () => {};
    const Zb = new Promise((OO => {
      Bb = OO
    }));
    let Gb = () => {};
    const qe = new Promise((OO => {
      Gb = OO
    }));
    let xe = null,
      nb = null,
      Wb = null,
      te = null,
      ke = null,
      Ub = null,
      Oe = null,
      Ke = null,
      pe = null,
      Xe = null,
      bl = null,
      ee = null,
      le = null,
      vl = null,
      Ce = null,
      he = null,
      De = null,
      Me = null,
      al = !1,
      oe = null;
    const Fe = new Set,
      Ve = new Set;

    function Le(OO) {
      for (const KO of Fe) OO(KO);
      return Ve.add(OO), () => {
        Ve.delete(OO)
      }
    }

    function Qe(OO) {
      if (!Fe.has(OO)) {
        Fe.add(OO);
        for (const pO of Ve) try {
          pO(OO)
        } catch (KO) {
          console.error(`${ve} a startup listener threw`, KO)
        }
      }
    }

    function zl(OO) {
      al = !0, OO.isStopped || Qe("texturesIn")
    }
    let Ae = 1,
      fe = -1 / 0,
      de = !1,
      Te = !1,
      Ne = 0,
      Ie = null,
      yl = !1;
    const gl = {
      dropped: -1 / 0,
      pause: -1 / 0
    };
    let ue = 0,
      Ee = 0,
      jl = null,
      Ye = null,
      we = null,
      il = null;
    const rl = new WeakMap;
    let Pe = null,
      ml = null,
      se = null,
      He = null,
      Re = null,
      Se = null,
      Je = null,
      cl = 0,
      Be = null,
      Ze = null,
      Ge = null,
      ql = null,
      xl = -1 / 0,
      ne = null;
    const We = new Set;
    let tl = !1,
      kl = null;
    const Ue = new Map,
      Ol = new Set;
    let Kl = !1;
    const pl = {
      adapter: null,
      boundAtMs: null
    };
    let Xl = null,
      bv = () => [0, 0],
      el = () => {},
      ll = () => {},
      vv = null,
      Cl = null;
    const hl = new class {
      constructor(OO) {
        this.reached = OO, this.next = 1
      }
      observe(OO) {
        if (!(OO < this.next)) {
          for (; this.next <= OO;) this.next *= 2;
          this.reached(OO)
        }
      }
    }((OO => {
      console.warn(`${ve} chunk cancels from the server this session: ${OO}`)
    }));
    let Dl = null,
      Ml = null,
      av = null,
      ol = null,
      Fl = !1,
      Vl = !1,
      Ll = null,
      Ql = !1,
      zv = !1,
      Al = !0,
      fl = null,
      dl = !1,
      Tl = !1,
      Nl = !1;

    function Il() {
      return Pb ??= Promise.all([pO.e(199), pO.e(130), pO.e(51)]).then((() => pO(41314))).then((OO => (re = OO, Object.assign(globalThis, {
        bloxdPreviewPage: OO.pagePreviews()
      }), OO)), (OO => {
        throw Pb = null, OO
      })), Pb
    }

    function yv() {
      return ie ??= pO.e(49).then((() => pO(41328))).catch((OO => {
        throw ie = null, new HO.c(OO)
      })), ie
    }
    class gv {
      constructor() {
        this.host = null
      }
      open(OO) {
        return null !== this.host ? OO(this.host) : Il().then((KO => (this.host ??= new KO.WasmPreviewHost(KO.pagePreviews()), OO(this.host))))
      }
      openMob(OO) {
        return this.open((KO => KO.openMob(OO)))
      }
      openPet(OO) {
        return this.open((KO => KO.openPet(OO)))
      }
      openMobLineup(OO) {
        return this.open((KO => KO.openMobLineup(OO)))
      }
      openCharacter(OO) {
        return this.open((KO => KO.openCharacter(OO)))
      }
    }

    function ul() {
      wb || (wb = !0, lX.b.setHost(new gv), (0, dK.i)(), pX.d.setFollower(Pv), Object.assign(globalThis, {
        bloxdPreviews: lX.b
      }))
    }

    function El() {
      Il().then((OO => {
        OO.pagePreviews().prefetch()
      }), (() => {}))
    }

    function jv() {
      let OO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      if (Yb) return;
      Yb = !0, zv = "play" === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "shell"), Al = !zv, console.info(`${ve} starting`), je || (je = !0, (0, rK.C)(new YO(tv, vC)), (0, VO.o)(new wO), (0, rK.y)(new iK), (0, rK.s)()), ul(), (0, gp.setCrashScreen)((OO => {
        let {
          text: KO,
          reload: pO
        } = OO;
        ! function(OO, KO) {
          var pO, XO;
          if (dl) return;
          dl = !0, (0, NK.f)(), null === (pO = ne) || void 0 === pO || pO.abort(), ne = null, XX.e.release();
          const bK = zv ? null !== (XO = OO.cancel) && void 0 !== XO ? XO : "general:back" : null;
          Qp({
            ...OO,
            cancel: bK
          }).then((OO => {
            OO && KO && Tl ? (0, Ep.i)(FO.v) : OO && KO ? (0, Ep.m)() : zv && (0, Ep.f)("/")
          }))
        }(KO, pO)
      })), (0, xX.j)(), (0, NO.b)();
      let KO = null;
      try {
        KO = pb("94negvilyxn", (() => {
          var OO, KO;
          return null !== (OO = null === (KO = xe) || void 0 === KO ? void 0 : KO.ws) && void 0 !== OO ? OO : null
        }), OO, "ghrzcpmnyi")
      } catch (eO) {
        console.error(`${ve} probes`, eO)
      }
      const XO = function() {
        const OO = (0, upO.l)(),
          KO = (0, upO.g)();
        let pO = !1;
        return XO => {
          OO && !pO && (pO = !0, (0, gp.reportStaleBuildReload)(OO, KO, XO))
        }
      }();
      sv(), zv || function() {
        const OO = function(OO) {
          var KO;
          const pO = new URLSearchParams(OO),
            XO = pO.get("game");
          return XO ? {
            game: XO,
            lobby: null !== (KO = pO.get("lobby")) && void 0 !== KO ? KO : null
          } : null
        }(window.location.search);
        if (OO) return (0, bK.k)(OO.game) && sv().request(), void iv(OO.game, OO.lobby);
        const KO = new URLSearchParams(window.location.search).get("ws");
        if (!KO) return;
        Zb.then((OO => {
          OO && async function(OO, KO) {
            try {
              await (0, HO.k)(OO), ml = aC(new WebSocket(KO)), null !== ml && XX.e.setGame(null), Yl()
            } catch (eO) {
              console.error(`${ve} ?ws=${KO} did not attach`, eO)
            }
          }(OO, KO)
        }))
      }(), async function(OO) {
        var KO, XO, bK, lO, VO;
        if ("undefined" === typeof WebAssembly) return uv("noWebAssembly", "This browser has no WebAssembly"), null;
        const QO = await (0, ab.J)();
        if ((0, gp.setCrashBackend)((0, pK.s)(QO) ? "unsupported" : null !== (KO = null === QO || void 0 === QO ? void 0 : QO.backend) && void 0 !== KO ? KO : "none"), (0, pK.s)(QO)) return uv("browser", `No WebGPU or WebGL2, and WebGL1 lacks ${QO.missing.join(", ")}`, {
          missing: QO.missing.join(",")
        }), null;
        if ((0, mb.q)("render")) try {
          const {
            startRenderDebug: OO
          } = await pO.e(43).then((() => pO(3852)));
          OO(QO)
        } catch (sK) {
          console.warn("The render debug topic didn't load", sK)
        }
        const zK = null !== QO && Ev() ? function(OO) {
          let KO;
          try {
            KO = (0, Ap.getOperatingSystem)()
          } catch {
            return null
          }
          return Tp(OO, KO, Np)
        }(QO) : null;
        if (null !== zK) return (0, gp.reportGpuFallback)(zK), (0, FO.o)(zK), jC(`the wasm client's renderer misdraws this GPU (${zK})`, "gpu"), null;
        const dO = null !== (XO = null === QO || void 0 === QO ? void 0 : QO.backend) && void 0 !== XO ? XO : null;
        pl.adapter = null !== (bK = null === QO || void 0 === QO ? void 0 : QO.adapter) && void 0 !== bK ? bK : null, pl.boundAtMs = null;
        const NO = !(0, pK.T)();
        null !== QO && "none" !== QO.reason && console.info(`${ve} drawing with ${QO.backend}: ${QO.reason}`);
        const IO = (0, ab.z)();
        Gb(!0), (0, HO.v)((OO => {
          try {
            null !== dO && (vv = OO.startSkyFeed, wv(), function(OO) {
              var KO, pO;
              bv = OO.rasterText, He = OO.setTextLocalPlayer, OO.setTextLocalPlayer(null !== (KO = null === (pO = se) || void 0 === pO ? void 0 : pO.info.playerDbId) && void 0 !== KO ? KO : null), el = OO.drainTextRerasters, ll = OO.loadTextIcons, OO.warmText((() => Fl)), OO.textChanged(), Fl && setTimeout(ll, 0)
            }(OO), Cl = OO.startShellAnalytics, Zv())
          } finally {
            Nl || (av = OO.followMenuPrefs({
              setSoundPrefs: hv,
              setEnvPrefs: Dv,
              setUiPrefs: Cv,
              setLookPrefs: Mv
            }))
          }
        })), (0, HO.o)(Sb).catch((OO => {
          console.warn(`${ve} the game code did not load: a join asks again`, OO)
        }));
        const yK = (0, ab.l)(QO);
        let YO, wO;
        yK.catch((() => {})), "loading" === (0, CO.C)() && yb();
        try {
          YO = function(OO) {
            const KO = null !== OO && void 0 !== OO ? OO : document.createElement("canvas");
            KO.id = "wasm-game-canvas";
            const pO = (0, xp.d)(),
              XO = (0, xp.e)(pO);
            return KO.style.cssText = "position:fixed;top:0;left:0;display:block;touch-action:none;outline:none;background:#000", (0, QX.e)(KO, XO), (0, xp.b)(KO, pO), KO.width = XO.bufferWidth, KO.height = XO.bufferHeight, kv(KO, Al), fl = KO, document.body.append(KO), KO
          }(null === dO ? null : await (await Il()).pagePreviews().beginSession())
        } catch (eO) {
          return await VC({
            site: ae,
            error: eO
          }, (() => {
            (0, gp.showUnsupported)((0, Fp.h)("fetch"), HX.g.fetch, `the previews did not load: ${String(eO)}`)
          })), null
        }
        yb();
        try {
          wO = await yK
        } catch (eO) {
          return await VC({
            site: ae,
            error: eO
          }, (() => {
            (0, gp.showUnsupported)((0, Fp.h)("fetch"), HX.g.fetch, `the ${null!==dO&&void 0!==dO?dO:"client"} build did not load: ${String(eO)}`)
          })), null
        }
        const iK = (0, ab.g)(),
          rK = !iK && !0 !== yp.h.getItem(Cb),
          PO = !iK && "loading" === (0, CO.C)();
        await (0, hO.h)(wO, oO.e, {
          reloadFailedDownload: rK
        }), PO && !(0, CO.S)() && await (0, hO.h)(wO, oO.e, {
          reloadFailedDownload: rK
        });
        NX = performance.now();
        const mK = Jb;
        if (!(0, CO.S)()) {
          (0, CO.Q)() && yp.h.setItem(Cb, !0);
          const OO = (0, CO.n)();
          if ("call" === OO) hC({
            site: XK.v,
            error: (0, CO.k)(),
            header: null
          }, mK);
          else {
            const KO = null !== OO && void 0 !== OO ? OO : "instantiate",
              pO = () => {
                (0, gp.showUnsupported)((0, Fp.h)(KO), HX.g[KO], (0, CO.h)())
              };
            if ("compile" !== OO && "instantiate" !== OO || !Ev())
              if ("fetch" === KO) {
                const OO = [wO.url().href, oO.e.url().href];
                await VC({
                  site: ae,
                  error: (0, CO.h)(),
                  urls: OO
                }, pO)
              } else pO();
            else {
              const KO = (0, CO.h)(),
                pO = (0, ZO.l)((0, CO.k)());
              (0, gp.reportCountedLoadFallback)((0, Fp.h)(OO), HX.g[OO], KO, pO), jC(`the wasm client did not ${OO} here (${KO})`, pO ? "oom" : null)
            }
          }
          return null
        }(0, DO.D)(wO.url()) && (0, gp.reportUnstreamedCoreLoad)();
        const sO = (0, CO.G)();
        let BO, GO = mK;
        try {
          GO = {
            ...mK,
            wasm: sO.uO()
          };
          const {
            Gl: OO
          } = wO.MX, KO = OO.CaO();
          if (KO !== cK.C) return hC({
            site: XK.d,
            error: `core ABI ${KO}, page ABI ${cK.C}`,
            header: null
          }, GO), null;
          const [pO, XO] = (0, cK.ke)();
          BO = new OO(pO, XO)
        } catch (eO) {
          return hC({
            site: XK.d,
            error: eO,
            header: null
          }, GO), null
        }
        Jb = GO, ce = wO.MX;
        const qK = new XK.l(BO, CO.u, {
          onCrash: OO => {
            NO && function(OO, KO, pO) {
              if ("webgpu" !== KO || (0, ab.e)()) return !1;
              const XO = function(OO) {
                if (OO.site === XK.h && (0, pK.t)(OO.error)) return "frames_refused";
                return OO.site === hb && (0, pK.v)(OO.error) ? "start_failed" : null
              }(OO);
              if (null === XO || !(0, pK.Q)(XO)) return !1;
              return (0, gp.reportRenderReload)("webgpu", "start_failed" === XO ? 0 : 1, pO, {
                cause: XO,
                error: OO.error,
                context: pl
              }), Wv(), !0
            }(OO, dO, GO) || hC(OO, GO)
          },
          onNetEvent: nv,
          onReconnectGrace: Nv,
          onCoreErrors: (OO, KO) => {
            var pO;
            (0, gp.reportCoreErrors)(OO, KO, GO, ((OO, KO) => {
              var pO;
              return null === (pO = Xl) || void 0 === pO ? void 0 : pO.voO(OO, KO)
            })), null === (pO = oe) || void 0 === pO || pO.coreErrors(OO)
          },
          onRenderReload: (OO, KO) => {
            ! function(OO, KO, pO, XO) {
              if ((0, ab.e)()) return;
              const bK = KO === cK.Oc.WEBGPU,
                eO = (0, pK.S)(Xl),
                lO = bK ? (0, pK.O)("lost", XO) : null;
              if (null !== lO) {
                const KO = void 0 === eO ? "" : ` (${eO.message})`;
                return void OO.crash(gp.RENDER_RELOAD_SITE, new Error(`the WebGPU device was lost (${pO}) and ${lO}${KO}`))
              }(0, gp.reportRenderReload)(bK ? "webgpu" : "webgl", pO, Jb, {
                error: eO,
                context: pl
              }), Wv()
            }(qK, OO, KO, NO)
          },
          onEnvEvent: OO => {
            var KO;
            OO.kind === cK.V.SkyImages && (null === (KO = he) || void 0 === KO || KO.onEvent(OO.payload))
          },
          onImages: OO => {
            var KO;
            null === (KO = De) || void 0 === KO || KO.onEvent(OO)
          },
          onModelRequest: OO => {
            var KO;
            null === (KO = le) || void 0 === KO || KO.request(OO)
          },
          onModelTaken: (OO, KO) => {
            var pO;
            null === (pO = le) || void 0 === pO || pO.taken(OO, KO)
          },
          onTerrainTexturesWanted: () => {
            queueMicrotask((() => {
              ! function(OO, KO) {
                const pO = Rb;
                if (null === pO || OO.isStopped) return;
                pO.restore((OO => {
                  (0, gp.reportTerrainTextureFailure)(OO, KO)
                })).then((KO => {
                  !1 !== KO || OO.isStopped ? !0 === KO && console.info(`${ve} terrain textures handed over again after the renderer lost them`) : console.warn(`${ve} the terrain textures couldn't be handed over again: the terrain draws blank`)
                }))
              }(qK, GO)
            }))
          },
          onKeepAlive: OO => {
            const KO = null === il ? void 0 : rl.get(il);
            void 0 !== KO && rX(KO, OO)
          }
        });
        if (me = qK, null !== OO) {
          qK.setAntiCheatProbes(tb(CO.u, OO.checks)), OO.watchHeld(UX.CoreFrame, (() => qK.frame)), OO.watchHeld(UX.GlueFrame, (() => BO.frame));
          const KO = Kb(OO, ((OO, KO, pO) => {
            let XO = !1;
            return oC(qK, (() => {
              XO = qK.rings.input.writeRecord(cK.zb.AntiCheat, OO, KO, pO, 0)
            })), XO
          }));
          qK.isStopped ? KO.stop() : bl = KO
        }
        ub = (OO, KO, pO) => qK.rings.cmd.writeCmd(OO, KO, pO), Eb = OO => qK.rings.cmd.growForCmd(OO), yl = !1, wv(), (0, HO.y)(qK, {
          core: BO,
          memory: CO.u,
          staleOr: (OO, KO, pO) => VC({
            site: OO,
            error: KO
          }, pO),
          reportReplayFault: (OO, KO) => {
            (0, gp.reportReplayFault)(OO, KO, Jb)
          },
          audio: Sb,
          options: LO.c,
          onNetEvent: nv,
          sessionInfo: OO => {
            var KO;
            return (null === (KO = se) || void 0 === KO ? void 0 : KO.conn) === OO ? se.info : null
          },
          onEventOverflow: nl,
          replayShaderPack: OO => {
            var KO;
            null === (KO = oe) || void 0 === KO || KO.replay(OO)
          },
          hasPackModel: OO => {
            var KO, pO;
            return null !== (null !== (KO = null === (pO = iC()) || void 0 === pO ? void 0 : pO.modelUrl(OO)) && void 0 !== KO ? KO : null)
          },
          beforeWrite: () => (!de && qK.rings.net.cursor > 0 && Uv(qK, !1, "all"), !qK.isStopped),
          beforeOp: () => (!de && qK.netWrittenSinceFrame > 0 && Uv(qK, !1, "budget"), !qK.isStopped)
        }), (0, jK.D)({
          lockPointer: () => {
            if (!RK(YO)) return !1;
            try {
              Promise.resolve(YO.requestPointerLock()).catch((() => {}))
            } catch {
              return !1
            }
            return !0
          },
          unlockPointer: () => {
            (0, uK.c)()
          },
          leaveGame: () => {
            xv()
          },
          canvas: () => YO
        }), ee = (0, jK.v)((() => {
          var OO;
          const KO = (0, HO.g)();
          null === (OO = (0, HO.s)()) || void 0 === OO || OO.followCursorAim(!0 === (null === KO || void 0 === KO ? void 0 : KO.isSessionLive) ? KO : null)
        })), jl && qK.setUiPrefs(jl);
        Ye && qK.setEnvPrefs(Ye);
        we && qK.setLookPrefs(we);
        const xK = VX ? LX(VX.preventMovement) : null;
        xK && lv(xK);
        const nO = (0, zp.k)(),
          WO = (0, zp.e)(qK, nO);
        pe = nO.basis, (0, IK.e)(null === WO ? null : (0, QK.o)(WO)), Ke = WO;
        const tK = (0, MO.c)();
        let kK = 1 / 0,
          UO = !0,
          OK = nO.shedFootprintBytes;
        const KK = new qX.e(tK, (() => BO.Ul()), (OO => {
          qK.crash(XK.p, OO)
        }));
        Ub = KK, Oe = KK, null !== WO && KK.setCeiling(Math.min((0, qX.q)(WO), kK));
        if (UO) {
          KK.setShed((OO => {
            const KO = qK.shedMemory("joinReserve" !== OO);
            return null !== KO && (null === Ke || KO < Ke) && (Ke = KO, (0, IK.e)((0, QK.o)(KO))), KO
          }), ((OO, KO, pO) => {
            1 === KO ? (0, gp.reportMemoryShed)(OO, pO, Jb) : console.warn(`${ve} wasm memory: shed again (${OO}): shed ${KO}`, pO.wasmMemoryShed)
          }), (() => qK.addDistanceInUse()));
          const OO = (0, pK.L)(sO);
          KK.setFootprint(new PX(OK, {
            storedChunks: () => BO.loK(),
            gpuBytes: () => {
              var KO;
              return null !== (KO = null === OO || void 0 === OO ? void 0 : OO.UMO()) && void 0 !== KO ? KO : 0
            },
            jsHeapBytes: rb
          }))
        }
        window.addEventListener("pagehide", (() => {
          Ub === KK && (KK.refreshStats(), ah(KK))
        })), window.addEventListener("pagehide", tC), window.addEventListener("pagehide", kC), !1;
        const [bp, eK] = (0, fK.e)();
        ol = (0, TK.h)((OO => qK.setChunkAddDistance(OO.horizontal, OO.vertical)), {
          horizontal: bp,
          vertical: eK
        }), qK.setAmbientOcclusion(!0 !== yp.e.getItem("disableAmbientOcclusion")), qK.setPoseLod(!0 !== yp.e.getItem(vK.I)), (0, mb.q)("look") && (qK.setLookDebug(!0), (0, sX.i)("wasm", (() => qK.takeLookDebug())));
        const lK = function(OO, KO, pO, XO) {
          const bK = new Xp,
            eO = OO => yp.e.getItem(OO);
          bK.sync(eO, KO), (0, uO.P)();
          const lO = (0, YK.j)("customBindingsChanged", (() => {
            bK.sync(eO, KO)
          }));
          (0, EK.k)(KO);
          const vK = new Set,
            CO = (0, jK.v)((() => {
              var OO;
              vK.size > 0 && vX() && !0 === (null === (OO = (0, HO.g)()) || void 0 === OO ? void 0 : OO.localPlayerAlive()) && YK.i.pl("usedKeyboard")
            })),
            hO = qp(OO, KO, {
              prevents: OO => bK.prevents(OO),
              keyPressed: OO => {
                bK.moves(OO) && (vK.add(OO), vX() && YK.i.pl("usedKeyboard"))
              },
              keyReleased: OO => {
                vK.delete(OO)
              },
              keysReleased: () => {
                vK.clear()
              },
              resized: () => {
                ep.d.measure(), (0, nK.k)()
              },
              sizeCanvas: () => (0, xp.i)(OO),
              watchRenderScale: KO => (0, xp.j)(OO, KO),
              touchStarting: () => {
                ep.d.measure()
              },
              viewShown: pO,
              touchUiShown: () => jp.d.get("isTouchScreen"),
              ctrlCombosAreGames: vX,
              inspect: (OO, KO, pO) => {
                bK.checks(KO, pO) && XO(OO)
              },
              canLock: () => RK(OO)
            }),
            DO = (0, CK.c)(KO);
          return () => {
            lO(), CO(), (0, EK.k)(null), DO(), hO()
          }
        }(YO, ((OO, KO, pO, XO, bK) => {
          var eO;
          oC(qK, (() => {
            qK.rings.input.writeRecord(OO, KO, pO, XO, bK)
          })), null === (eO = bl) || void 0 === eO || eO.onInput(OO), !Te && (0, aX.g)(OO, bK) && (0, aX.d)((() => {
            me !== qK || Nl || qK.isStopped || !bh() || Uv(qK, !1, "budget", !1)
          }))
        }), (() => Al), (OO => {
          var KO;
          null === (KO = bl) || void 0 === KO || KO.onEvent(OO)
        }));
        if (qK.isStopped) return lK(), null;
        nb = lK;
        const vp = () => !qK.isStopped && !dl;
        if (qK.isStopped) return null;
        (0, CO.W)((() => {
          "call" === (0, CO.n)() && qK.crash(XK.v, (0, CO.k)())
        }));
        const hK = (0, XK.Q)(qK.rings.worker, (() => {
          Uv(qK, !1, "budget")
        }));
        Wb = function(OO, KO) {
          return FC().catch((() => {})), new SX({
            module: (0, CO.y)(),
            decodeSettings: OO => {
              const KO = (0, HO.s)();
              if (null === KO) throw new Error("no game code to decode the world-gen seed with");
              return KO.decodeMapSettings(OO)
            },
            loadWorker: FC,
            onLoadFailed: OO => {
              (0, gp.reportWorldgenLoadFailure)(OO, Jb)
            },
            onWorkerLost: OO => {
              (0, gp.reportWorkerLost)(XK.F, OO, Jb)
            },
            onStartTimeout: OO => {
              (0, gp.reportWorkerStartTimeout)(XK.F, OO, Jb)
            },
            onGaveUp: OO => {
              (0, gp.reportWorldgenGaveUp)(OO, Jb)
            },
            onMemoryStats: OO => {
              var KO;
              null === (KO = Ub) || void 0 === KO || KO.noteWorldgen(OO)
            },
            onMemoryGone: () => {
              var OO;
              null === (OO = Ub) || void 0 === OO || OO.worldgenGone()
            },
            write: (pO, XO, bK, eO) => {
              oC(OO, (() => {
                OO.rings.worker.writeWorkerRecord(pO, XO, bK, 0, eO) || OO.crash(XK.F, `a world-gen record of kind ${XO} did not fit the worker-in ring`)
              })), KO()
            }
          })
        }(qK, hK), ke = function(OO, KO) {
          return new Zp({
            module: (0, CO.y)(),
            loadWorkers: async () => {
              const [{
                createMeshWorker: OO
              }, KO] = await Promise.all([pO.e(36).then((() => pO(41380))), Promise.resolve().then((() => pO(94))).then((OO => {
                let {
                  isMobile: KO
                } = OO;
                return KO()
              }), (() => !1))]);
              return {
                create: OO,
                count: (0, TO.c)(navigator.hardwareConcurrency, KO)
              }
            },
            write: (pO, XO, bK, eO, lO) => {
              (0, nK.h)(), oC(OO, (() => {
                OO.rings.worker.writeWorkerRecord(pO, XO, bK, eO, lO) || OO.crash(XK.r, `a meshing record of kind ${XO} did not fit the worker-in ring`)
              })), KO()
            },
            onWorkerLost: OO => {
              (0, gp.reportWorkerLost)(XK.r, OO, Jb)
            },
            onStartTimeout: OO => {
              (0, gp.reportWorkerStartTimeout)(XK.r, OO, Jb)
            },
            onMemoryStats: (OO, KO) => {
              var pO;
              null === (pO = Ub) || void 0 === pO || pO.noteMeshWorker(OO, KO)
            },
            onMemoryGone: OO => {
              var KO;
              null === (KO = Ub) || void 0 === KO || KO.meshWorkerGone(OO)
            },
            fail: (KO, pO) => {
              const XO = () => {
                OO.crash(XK.r, void 0 === pO ? KO : new Error(KO, {
                  cause: pO
                }))
              };
              void 0 !== pO ? VC({
                site: XK.r,
                error: pO
              }, XO) : XO()
            }
          })
        }(qK, hK);
        const DK = (0, bb.u)(fO.clientSideServerUrls.staticUrl, {
            onTableFailed: OO => {
              VC({
                site: gp.MODEL_FEED_SITE,
                error: OO
              }, (() => {}), vp)
            },
            packUrl: OO => {
              var KO, pO;
              return null !== (KO = null === (pO = iC()) || void 0 === pO ? void 0 : pO.modelUrl(OO)) && void 0 !== KO ? KO : null
            }
          }),
          MK = function(OO, KO, pO) {
            const XO = pO => {
              var XO, bK;
              return null !== (XO = null === (bK = KO()) || void 0 === bK ? void 0 : bK.drawnUrl(pO)) && void 0 !== XO ? XO : OO.url(pO)
            };
            return (0, pX.j)((0, np.m)(XO), pO)
          }(DK, (() => le), iC),
          ap = new np.d(MK, (OO => {
            console.warn(`${ve} image ${OO.key.kind}:${OO.key.index}:${OO.key.word} failed`, OO.error)
          }));
        De = ap, Me = new OX(qK, MK, ((OO, KO) => {
          void 0 === KO ? console.warn(`${ve} ${OO}`) : mC(OO, KO)
        }));
        const oK = new KX.h(DK, function(OO, KO) {
          let XO = !1,
            bK = null,
            eO = null;
          const lO = {
              onUnavailable: (pO, XO) => {
                eO ??= VC({
                  site: gp.MODEL_POOL_SITE,
                  error: pO,
                  urls: XO
                }, (() => {
                  (0, gp.reportModelPoolFailure)(pO, OO)
                }), KO)
              },
              onDecoderFailed: (pO, XO) => {
                const bK = () => {
                  (0, gp.reportDracoDecoderFailure)(pO, OO)
                };
                void 0 !== XO ? VC({
                  site: gp.MODEL_POOL_SITE,
                  error: pO,
                  urls: XO
                }, bK, KO) : bK()
              },
              onWorkerLost: KO => {
                (0, gp.reportWorkerLost)(gp.MODEL_POOL_SITE, KO, OO)
              }
            },
            vK = pO.e(38).then((() => pO(41387))).then((OO => {
              let {
                pageModelPool: KO
              } = OO;
              if (XO) return null;
              const pO = KO(lO);
              return bK = pO.unlisten, vl = pO.pool, pO.pool
            }), (OO => (XO || lO.onUnavailable(OO, void 0), null)));
          return Ce = () => {
            var OO;
            XO = !0, null === (OO = bK) || void 0 === OO || OO(), vl = null
          }, (OO, KO) => vK.then((pO => {
            var XO;
            return null !== (XO = null === pO || void 0 === pO ? void 0 : pO.build(OO, KO)) && void 0 !== XO ? XO : (0, eX.o)(OO, "the model workers did not load")
          })).then((OO => null !== eO && (0, eX.k)(OO) ? eO.then((() => OO)) : OO))
        }(GO, vp), (OO => {
          OO.startup ? (CC(), VC({
            site: gp.MODEL_FEED_SITE,
            error: OO.error,
            urls: "" === OO.url ? void 0 : [OO.url]
          }, (() => {
            (0, gp.reportModelFailure)(OO, GO)
          }))) : (0, gp.reportModelFailure)(OO, GO)
        }), {
          onWritten: (OO, KO) => {
            ap.glbWritten(OO, KO)
          },
          onTaken: (OO, KO) => {
            ap.glbTaken(OO, KO)
          },
          onPackFileFailed: (OO, KO) => {
            console.warn(`${ve} the texture pack's model file ${OO} failed: the shipped one loads`, KO)
          }
        });
        le = oK;
        const FK = new tX.f(qK);
        Rb = FK, FK.swap((OO => {
          const KO = () => {
            (0, gp.reportTerrainTextureFailure)(OO, GO)
          };
          if (Fl) return void KO();
          const pO = () => !Fl,
            XO = null === OO.url ? void 0 : [OO.url];
          VC({
            site: XK.B,
            error: OO.error,
            urls: XO
          }, KO, pO)
        })).then((OO => {
          null !== OO && (OO || qK.isStopped || console.warn(`${ve} the core refused the terrain textures: terrain draws untextured`), zl(qK))
        }));
        const VK = new SO(qK, ((OO, KO) => {
          console.warn(`${ve} ${OO}`, ...void 0 === KO ? [] : [KO])
        }));
        VK.feed(), null !== dO && function(OO, KO, XO, bK, eO, lO) {
          let vK = null,
            CO = null,
            hO = !1;
          const DO = {
            textures: null,
            stop: () => {
              var OO, KO;
              hO = !0, null === (OO = CO) || void 0 === OO || OO(), null === (KO = vK) || void 0 === KO || KO(), XX.e.setSettled(null), null !== ce && wl.clear(ce)
            }
          };
          Hb = DO, CO = sv().follow((CO => {
            null !== CO && Promise.all([pO.e(180), pO.e(41)]).then((() => pO(41349))).then((pO => {
              let {
                PackTextures: MO
              } = pO;
              if (hO || OO.isStopped) return;
              const aK = new MO({
                feed: CO,
                terrain: KO,
                backend: XO,
                stopped: () => OO.isStopped,
                landed: () => {
                  zl(OO)
                },
                packSwapped: () => {
                  (0, pX.h)(bK), lO.feed((() => async function(OO) {
                    const KO = null === OO ? null : await OO.averageColours;
                    return null === KO ? JO() : RO(KO)
                  }(aK.assets))), rC(aK.iconOverrides()), eO.refresh().then((OO => {
                    null !== OO && console.info(`${ve} texture pack models: ${OO.resent} of ${OO.delivered} files written again, ${OO.refetched} refetched`)
                  }))
                },
                settled: (OO, KO, pO) => {
                  var XO;
                  (XX.e.setSettled({
                    state: OO,
                    files: KO
                  }), null === OO.gameSource && (0, AK.d)(OO.pack, pO), pO) || function(OO) {
                    const KO = ce;
                    null !== KO && wl.apply(KO, OO).then((KO => {
                      KO && OO && console.info(`${ve} the texture pack's animations are in (${Object.keys(OO).length} files)`)
                    }))
                  }(null === (XO = OO.pack) || void 0 === XO ? void 0 : XO.animations)
                },
                settling: () => {
                  XX.e.setSettled(null)
                },
                warn: mC,
                maxTextureSize: () => Promise.resolve((0, pK.X)(document.createElement("canvas")))
              });
              DO.textures = aK, vK = aK.start()
            }), (OO => {
              console.warn(`${ve} the texture pack's terrain didn't load: the built atlas stays`, OO)
            }))
          }))
        }(qK, FK, dO, ap, oK, VK);
        const LK = () => {
            qK.setTextureLayers("")
          },
          dK = OO => {
            (AO ??= pO.e(45).then((() => pO(41389))).then((OO => {
              let {
                TEXTURE_NAMES: KO
              } = OO;
              return KO
            }), (OO => {
              throw AO = null, OO
            })), AO).then((OO => {
              qK.setTextureLayers(OO) || qK.isStopped || (console.warn(`${ve} the core refused the texture names: textured Boxes draw textureNotFound`), LK())
            }), (KO => {
              if (qK.isStopped) return;
              const [pO, ...XO] = OO;
              void 0 === pO ? VC({
                site: gp.TEXTURE_NAMES_SITE,
                error: KO
              }, (() => {
                console.warn(`${ve} the texture names didn't load, so textured Boxes draw textureNotFound`, KO), LK()
              }), vp) : setTimeout((() => {
                dK(XO)
              }), pO)
            }))
          };
        if (dK(ge), null !== dO && !await async function(OO, KO, pO, XO, bK, lO) {
            var vK;
            const CO = (0, pK.L)(pO);
            if (null === CO) return OO.crash(hb, new Error(`this ${XO} build has no openRenderer`)), !1;
            let hO;
            Xl = CO;
            try {
              var DO, MO, aK, oO;
              const eO = null !== (DO = null === (MO = re) || void 0 === MO ? void 0 : MO.pagePreviews()) && void 0 !== DO ? DO : null,
                vK = null !== (aK = null === (oO = re) || void 0 === oO ? void 0 : oO.previewModule(pO)) && void 0 !== aK ? aK : null;
              if (null === eO || null === vK) {
                null === eO || void 0 === eO || eO.endSession(!1), hO = (0, xp.d)().sampleCount, await (0, pK.h)(KO, CO, lO, Yv, hO, await bK);
                const OO = (0, pK.q)(pO);
                null === OO && console.warn(`${ve} this ${XO} build has no image registry: sky and model images won't show`), (0, Wp.h)(OO)
              } else {
                (0, ab.e)() && await (0, Ep.n)();
                const pO = (0, ab.F)();
                if (null !== pO) {
                  const KO = (0, pK.S)(CO);
                  return OO.crash(gp.RENDER_RELOAD_SITE, new Error(`${pO}${void 0===KO?"":` (${KO.message})`}`)), !1
                }
                hO = await eO.bindSession(vK, KO, (async OO => (0, pK.w)(CO, hb, lO, OO, Yv, await bK)))
              }
            } catch (eO) {
              return OO.crash(hb, eO), !1
            }(function(OO, KO) {
              const pO = OO,
                {
                  requestCapture: XO,
                  takeCapture: bK
                } = pO;
              if ("function" !== typeof XO || "function" !== typeof bK) return;
              const eO = {
                request() {
                  XO.call(pO, KO)
                },
                take() {
                  var OO;
                  return null !== (OO = bK.call(pO)) && void 0 !== OO ? OO : null
                }
              };
              window[zb] = eO
            })(KO, hO), Kl = !0;
            const FO = performance.now();
            return pl.boundAtMs = null !== (vK = (0, ab.H)()) && void 0 !== vK ? vK : FO, console.info(`${ve} ${XO} renderer bound at ${Math.round(FO)} ms`), !OO.isStopped
          }(qK, BO, sO, dO, IO, YO)) return null;
        if (null !== dO) {
          var NK, wK, ip;
          (0, aK.C)(dO);
          const OO = () => !qK.isStopped && XC();
          pO.e(177).then((() => pO(8256))).then((KO => {
            let {
              devTools: pO
            } = KO;
            qK.isStopped || pO.setHost(function(OO) {
              return {
                tools: MX,
                async downloadScene(KO, pO) {
                  let {
                    width: XO,
                    height: bK,
                    colouring: eO
                  } = pO;
                  "screenshot" === KO && null === eO ? await (0, CX.e)(OO, XO, bK) : console.warn("The Rust client's developer tools take uncoloured screenshots only")
                },
                setAmbientLightIntensity: () => (console.warn("The Rust client's renderer has no ambient light setting"), Promise.resolve())
              }
            }(function(OO, KO) {
              return {
                canvas: OO,
                maxTextureSize: hX,
                drawing: KO,
                resize: (OO, KO) => {
                  (0, EK.s)(cK.zb.Resize, 0, OO, KO, (0, EK.i)(1))
                },
                restoreSize: () => {
                  const KO = (0, xp.i)(OO);
                  null !== KO && (0, EK.s)(cK.zb.Resize, 0, KO.cssWidth, KO.cssHeight, (0, EK.i)(KO.renderScale))
                },
                onFrameDrawn: OO => (DX.add(OO), () => {
                  DX.delete(OO)
                })
              }
            }(YO, OO)))
          }), (OO => {
            console.warn(`${ve} the developer tools didn't load: no captures this session`, OO)
          }));
          const KO = "webgpu" === dO && null !== (NK = null === QO || void 0 === QO || null === (wK = QO.adapter) || void 0 === wK ? void 0 : wK.vendor) && void 0 !== NK ? NK : null;
          Dl = {
            backend: dO,
            canvas: YO,
            fallbackReason: null !== (ip = null === QO || void 0 === QO ? void 0 : QO.reason) && void 0 !== ip ? ip : null,
            adapterVendor: KO
          }, Zv();
          try {
            (0, nK.s)(dO, YO, KO)
          } catch (eO) {
            (0, nK.u)(), console.error(`${ve} the quality steps didn't start`, eO)
          }
        }
        const rp = (0, AX.d)(QO, (0, gK.e)()),
          PK = "webgpu" === dO;
        if (oe = (0, AX.g)(PK ? qK : null, PK && null !== (lO = null === (VO = re) || void 0 === VO ? void 0 : VO.pagePreviews().hX) && void 0 !== lO ? lO : null, rp, mC), Nl) return null;
        if (KK.reserveAtJoin((0, qX.n)(null !== WO && void 0 !== WO ? WO : QK.f)), qK.isStopped) return null;
        const mp = OO => {
          if (null !== Ml) try {
            Ml.animationFrame(OO)
          } catch (eO) {
            xC(eO)
          }
          if (function(OO, KO) {
              return KO && !Nl && !Te && bh() && XC() && OO.framePaces(performance.now())
            }(qK, Al)) return qK.writePendingInput(), (0, jK.f)(OO, OC), Gv(!1, OO), void requestAnimationFrame(mp);
          Uv(qK, Al, "budget") && ((0, EO.g)(qK.lastFrameKind) && XC() && (0, jK.f)(OO, OC), Gv(Al && Ql, OO), DC(qK), KK.afterFrame(), requestAnimationFrame(mp))
        };
        requestAnimationFrame(mp);
        return function(OO) {
          if (OO.has("inputLog") && (0, bX.h)((OO => {
              let {
                action: KO,
                down: pO,
                press: XO
              } = OO;
              console.info(`${lp} input ${KO} ${pO?"down":"up"} press ${XO} at ${performance.now().toFixed(1)}`)
            })), OO.has("inputDump")) {
            const OO = [];
            Cp = OO, Object.assign(window, {
              bloxdInputDump: () => OO.join("\n")
            })
          }
        }(new URLSearchParams(window.location.search)), Xe = function(OO, KO) {
          let pO = null;
          const XO = () => {
              null !== pO && (clearInterval(pO), pO = null)
            },
            bK = () => {
              document.hidden ? pO ??= setInterval((() => {
                Uv(OO, !1, "budget") ? (DC(OO), KO.afterFrame()) : XO()
              }), ye) : XO()
            };
          return document.addEventListener("visibilitychange", bK), bK(), () => {
            XO(), document.removeEventListener("visibilitychange", bK)
          }
        }(qK, KK), qK
      }(KO).then((OO => {
        var KO;
        (XO(Jb), Gb(null !== OO), Bb(OO), null === OO) ? null === (KO = re) || void 0 === KO || KO.pagePreviews().endSession(null === (0, CO.n)()): Qe("booted")
      }), (OO => {
        XO(Jb), Gb(!1), Bb(null), hC({
          site: Db,
          error: OO,
          header: null
        }, Jb)
      }))
    }

    function Yl() {
      const OO = ce;
      null !== OO && Il().then((KO => {
        let {
          pageBuiltInAnimationPack: pO
        } = KO;
        pO().provide(OO)
      }), (OO => {
        console.warn(`${ve} the built-in animation pack's chunk did not load: lifeforms stay in their rest pose`, OO)
      }))
    }
    const wl = new class {
      constructor(OO) {
        this.deps = OO, this.latest = 0, this.JK = null
      }
      apply(OO, KO) {
        return this.load(OO, KO, 0)
      }
      async load(OO, KO, pO) {
        var XO;
        const bK = ++this.latest,
          eO = this.deps.compiler;
        if (void 0 === KO || null === KO || "object" !== typeof KO || 0 === Object.keys(KO).length || null === eO) return this.drop(OO), !1;
        if ((null === (XO = this.JK) || void 0 === XO ? void 0 : XO.module) === OO && (0, tK.Sd)(this.JK.files, KO)) return !1;
        try {
          const [pO, XO] = await Promise.all([eO(), this.deps.builtIns()]);
          if (bK !== this.latest) return !1;
          const lO = await pO(KO, KK, {
            builtIns: XO
          });
          if (bK !== this.latest) return !1;
          const vK = this.call(OO, lO);
          if (void 0 === vK) throw new OK("the compiled animations didn't read against the built-in pack");
          return this.JK = {
              module: OO,
              files: KO
            },
            function(OO) {
              for (let KO = 0; KO + 2 < OO.length; KO += 3) {
                ("error" === OO[KO] ? console.error : console.warn)(`Animation for the texture pack: ${OO[KO+1]}: ${OO[KO+2]}`)
              }
            }(vK), !0
        } catch (vK) {
          var lO;
          if (bK !== this.latest) return !1;
          this.drop(OO), 0 === pO && this.deps.warn("the texture pack's animations didn't load: lifeforms play the built-in ones", vK);
          const XO = (null !== (lO = this.deps.retryAfterMs) && void 0 !== lO ? lO : UO)[pO];
          return void 0 === XO || vK instanceof OK || (0, kK.h)(OO) || setTimeout((() => {
            bK === this.latest && this.load(OO, KO, pO + 1)
          }), XO), !1
        }
      }
      call(OO, KO) {
        try {
          return OO.eaO(KO)
        } catch (pO) {
          throw (0, kK.j)(OO, pO), pO
        }
      }
      clear(OO) {
        this.latest++, this.drop(OO)
      }
      drop(OO) {
        const KO = this.JK;
        if (this.JK = null, (null === KO || void 0 === KO ? void 0 : KO.module) === OO && !(0, kK.h)(OO)) try {
          this.call(OO, null)
        } catch {}
      }
    }({
      compiler: qK.b,
      builtIns: async () => {
        const {
          pageBuiltInAnimationPack: OO
        } = await Il();
        return OO().whenSet()
      },
      warn: mC
    });
    async function iv(OO, KO) {
      let XO = !1;
      await Pl({
        matchmake: async () => {
          const {
            guestJoinTarget: bK,
            guestJoinWithPack: eO
          } = await pO.e(98).then((() => pO(41336)));
          return XO ? bK(OO, KO, Rv()) : (XO = !0, eO(OO, KO, (KO => Sv(OO, KO)), Rv))
        },
        onFailure: OO => {
          (0, gp.showJoinFailure)(OO, Jb)
        },
        rejoin: Ul,
        invalidateTrafficCode: Ov
      })
    }

    function rv(OO, KO) {
      (0, gp.reportPageJoinFailure)(OO, Jb, KO)
    }
    async function Pl(OO) {
      let {
        matchmake: KO,
        onFailure: pO,
        rejoin: XO,
        invalidateTrafficCode: bK,
        pageReady: lO,
        signal: vK
      } = OO;
      const CO = () => !0 === (null === vK || void 0 === vK ? void 0 : vK.aborted);
      let hO;
      const DO = XX.e.rejoinHold(),
        MO = (0, NK.y)("wasm", MC);
      let aK = !1,
        oO = performance.now();
      try {
        if (!await qe) return {
          kind: "stopped"
        };
        if (CO()) return {
          kind: "dl"
        };
        yv().catch((() => {}));
        let OO = await KO();
        oO = performance.now();
        const pO = () => performance.now() - OO.matchedAt <= OO.freshMs,
          bK = sl(OO.target).catch((() => {}));
        pO() && !CO() && (hO = new Sp(OO.target, {
          signal: vK
        }));
        const eO = performance.now();
        if (null === await Zb) return {
          kind: "stopped"
        };
        var FO;
        if (function(OO) {
            var KO, pO;
            if (fX.d.markGameEngineConstructed(), IX) return;
            IX = !0;
            const XO = Math.max(OO, null !== (KO = TX) && void 0 !== KO ? KO : OO);
            (0, dX.i)("ready", Math.max(0, (null !== (pO = NX) && void 0 !== pO ? pO : XO) - XO) / 1e3)
          }(eO), await bK, !pO() && !CO()) null === (FO = hO) || void 0 === FO || FO.rematched(), OO = await KO(), oO = performance.now();
        if (CO()) return {
          kind: "dl"
        };
        const DO = await async function(OO) {
          var KO, pO, XO;
          let {
            signal: bK,
            rejoin: eO = null,
            early: lO,
            pageReady: vK
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          if (null !== bK && void 0 !== bK && bK.aborted) throw new DOMException("the join was left", "AbortError");
          const CO = (hO = Ze, DO = performance.now(), null !== hO && DO - hO < yX);
          var hO, DO;
          Ze = null;
          const MO = new AbortController;
          cv({
            controller: MO,
            game: null !== (KO = null === (pO = OO.session) || void 0 === pO ? void 0 : pO.gameNameWithVariation) && void 0 !== KO ? KO : null
          }), Ge = null, null === (XO = ne) || void 0 === XO || XO.abort(), ne = null, tl = !1, kl = null, Ue.clear();
          const aK = () => {
            (0, dO.g)(MO, (0, dO.c)(bK))
          };
          null === bK || void 0 === bK || bK.addEventListener("abort", aK, {
            once: !0
          });
          try {
            var oO, FO, VO;
            const KO = await Zb;
            if (null === KO || KO.isStopped || Nl) throw new Error("no core is running to join a game with");
            if (OO.session && null !== oe) {
              const KO = await Hl(oe.join(OO.session.gameNameWithVariation), MO.signal);
              if (null !== KO) throw new AX.b(KO)
            }
            const [, , , {
              joinRoom: pO
            }] = await Hl(Promise.all([(0, HO.k)(KO), sl(OO), null === vK || void 0 === vK ? void 0 : vK(), yv()]), MO.signal), XO = OO.session, bK = XO ? {
              ...bC,
              attachSocket: KO => {
                const pO = aC(KO, OO.endpoint);
                var bK;
                null !== pO && (se = {
                  conn: pO,
                  info: XO
                }, null === (bK = He) || void 0 === bK || bK(XO.playerDbId));
                return pO
              }
            } : bC, hO = await pO(bK, OO, {
              signal: MO.signal,
              early: lO
            }).catch((OO => {
              throw function(OO) {
                if (!(OO instanceof hK.b)) return OO;
                if ("roomError" === OO.stage && null !== kl) return mv(new hK.b(OO.message, OO.stage, OO.code, kl), OO);
                const KO = "closed" === OO.stage && null !== ql ? Ue.get(ql.conn) : void 0;
                return void 0 === KO ? OO : mv(new hK.b(OO.message, OO.stage, KO.code), OO)
              }(OO)
            }));
            if (Pe !== MO) throw hO.DX(), new DOMException("the join was left", "AbortError");
            Zl(hO), null === (oO = ke) || void 0 === oO || oO.newGame();
            const DO = function(OO) {
              var KO, pO;
              const {
                session: XO
              } = OO, bK = void 0 === XO ? OO.joinOptions.lobbyName : XO.lobbyName;
              return {
                endpoint: OO.endpoint,
                game: null !== (KO = null === XO || void 0 === XO ? void 0 : XO.gameNameWithVariation) && void 0 !== KO ? KO : OO.roomName,
                lobby: String(null !== bK && void 0 !== bK ? bK : null),
                postCookies: null !== (pO = OO.postCookies) && void 0 !== pO ? pO : null
              }
            }(OO);
            rl.set(hO, DO), mX(DO);
            const aK = performance.now(),
              LO = {
                conn: hO.conn,
                rejoin: eO,
                game: null !== (FO = null === (VO = OO.session) || void 0 === VO ? void 0 : VO.gameNameWithVariation) && void 0 !== FO ? FO : "",
                joinedAt: aK,
                rejoinedAt: CO ? aK : null,
                overflow: null
              };
            Re = LO,
              function(OO, KO) {
                fv();
                const pO = {
                  endpoint: KO,
                  roomId: OO.seat.room.roomId,
                  heldConn: 0,
                  dropCode: 0,
                  pendingHold: null,
                  resume: new FK({
                    reconnect: (OO, KO, XO) => Iv(pO, OO, KO, XO),
                    releaseSeat: OO => {
                      !async function(OO, KO) {
                        const {
                          roomId: pO,
                          roomToken: XO
                        } = Tv(OO, KO);
                        try {
                          const {
                            leaveHeldSeat: KO
                          } = await yv();
                          await KO(OO.endpoint, pO, XO)
                        } catch (bK) {
                          console.warn(`${ve} the held seat of a game left while it reconnected couldn't be released`, bK)
                        }
                      }(pO, OO)
                    },
                    isLive: () => Se === pO && null !== Re && !Nl,
                    QKO: OO => {
                      Be = OO, Av()
                    },
                    onReconnected: OO => {
                      ! function(OO) {
                        const KO = il;
                        if (null !== KO && KO !== OO) {
                          const pO = rl.get(KO);
                          void 0 !== pO && rl.set(OO, pO), Ll === KO && (Ll = OO), KO.detach()
                        }
                        Zl(OO)
                      }(OO)
                    },
                    onGaveUp: (OO, KO) => {
                      ! function(OO, KO, pO) {
                        var XO, bK;
                        console.warn(`${ve} gave up reconnecting (${pO.reason}, ${pO.attempts} attempts)`, pO.lastError), (0, gp.reportReconnectGaveUp)(pO, Jb);
                        const eO = null !== (XO = null === (bK = Re) || void 0 === bK ? void 0 : bK.rejoin) && void 0 !== XO ? XO : null;
                        dv(OO, "gaveUp"), qv();
                        const lO = {
                          code: OO.dropCode,
                          name: null,
                          reason: db,
                          canReconnect: !KO,
                          automaticallyReconnect: !1,
                          requiresRefresh: !1
                        };
                        Xv(lO, KO ? null : eO, !1, {
                          reasonKey: Tb,
                          canPlayAgain: KO
                        })
                      }(pO, OO, KO)
                    }
                  })
                };
                Se = pO, null !== Je && Je.conn === OO.conn && pO.resume.onInitialInfo(Je)
              }(hO, OO.endpoint), performance.mark(ob), setTimeout((() => {
                il === hO && (0, rK.b)()
              }), 0), Yl(), console.info(`${ve} joined ${OO.roomName} as ${hO.seat.sessionId} at ${Math.round(performance.now())} ms`);
            const QO = Ge;
            Ge = null, null !== QO && Wl(LO, QO.mask, QO.frames);
            const zK = Ue.get(hO.conn);
            return Ue.clear(), void 0 !== zK && (Zl(null), pv(hO.conn, zK.code, zK.reason)), hO
          } finally {
            var LO;
            null === bK || void 0 === bK || bK.removeEventListener("abort", aK), Pe === MO && Bl(il, null), (null === (LO = ql) || void 0 === LO ? void 0 : LO.join) === MO && (ql = null)
          }
        }(OO.target, {
          signal: vK,
          rejoin: XO(OO.target),
          early: hO,
          pageReady: lO
        });
        return aK = !0, {
          kind: "joined",
          game: DO
        }
      } catch (LO) {
        if (LO instanceof DOMException && "AbortError" === LO.name || CO()) return {
          kind: "dl"
        };
        if (Nl) return {
          kind: "stopped"
        };
        if (tl && (tl = !1, await bK().catch((OO => {
            console.warn(`${ve} the cached traffic code could not be dropped`, OO)
          }))), null === await Zb) return {
          kind: "stopped"
        };
        if (LO instanceof AX.b) return pO(LO, performance.now() - oO), {
          kind: "failed",
          error: LO,
          reloading: !1
        };
        if (LO instanceof hK.b && LO.code === eO.e.wasmClientNotAllowed.code && zv) return jC("this server refused the wasm client to this account", "refused"), {
          kind: "failed",
          error: LO,
          reloading: !0
        };
        const OO = LO instanceof hK.b && LO.code === eO.e.outdatedVersion.code,
          KO = () => null === il,
          XO = await VC({
            site: gp.JOIN_SITE,
            error: LO,
            outdated: OO
          }, (() => {
            pO(LO, performance.now() - oO)
          }), KO);
        return {
          kind: "failed",
          error: LO,
          reloading: XO
        }
      } finally {
        var VO;
        aK || MO.end(), XX.e.releaseHold(DO);
        const OO = null === (VO = hO) || void 0 === VO ? void 0 : VO.release();
        OO && (0, gp.reportUnusedSeat)(OO, Jb)
      }
    }

    function mv(OO, KO) {
      return OO.stack = KO.stack, OO
    }

    function sl(OO) {
      return OO.session ? (0, HO.r)(Sb, OO.session.gameNameWithVariation) : Promise.resolve()
    }

    function Hl(OO, KO) {
      return (0, dO.j)(KO), new Promise(((pO, XO) => {
        const bK = () => {
          XO((0, dO.c)(KO))
        };
        KO.addEventListener("abort", bK, {
          once: !0
        }), OO.then((OO => {
          KO.removeEventListener("abort", bK), pO(OO)
        }), (OO => {
          KO.removeEventListener("abort", bK), XO(OO)
        }))
      }))
    }

    function Rl() {
      var OO, KO;
      return null !== (OO = null === (KO = oe) || void 0 === KO ? void 0 : KO.runsInJoinedGame()) && void 0 !== OO && OO
    }

    function Sl() {
      var OO, KO;
      return null !== (OO = null === (KO = oe) || void 0 === KO ? void 0 : KO.couldntRunInJoinedGame()) && void 0 !== OO ? OO : null
    }

    function Jl() {
      cv(null)
    }

    function cv(OO) {
      var KO, pO, XO;
      (function() {
        const OO = Se;
        null !== OO && dv(OO, "left")
      }(), null === xe || xe.left) || (xe.left = !0, null === (XO = (0, HO.g)()) || void 0 === XO || XO.socketLeft(), (0, VO.q)({
        websocketUrl: null
      }));
      Pe && (0, dO.g)(Pe, new DOMException("the join was left", "AbortError")), qv(null !== OO), null === (KO = oe) || void 0 === KO || KO.DX();
      const bK = il;
      null !== OO && XX.e.setGame(OO.game), Bl(null, null !== (pO = null === OO || void 0 === OO ? void 0 : OO.controller) && void 0 !== pO ? pO : null), null === bK || void 0 === bK || bK.DX(), Gl(0), (0, QO.e)()
    }

    function Bl(OO, KO) {
      il = OO, Pe = KO, null === il && null === Pe && XX.e.setGame(void 0)
    }

    function Zl(OO) {
      Bl(OO, Pe)
    }

    function Gl(OO) {
      const KO = me;
      return null !== ub && !Nl && null !== KO && !KO.isStopped && (!!ub(hK.d, 0, (0, hK.u)(OO)) && (yl = !0, 0 === OO || Te || Uv(KO, !1, "all"), !0))
    }

    function qv() {
      var OO, KO;
      arguments.length > 0 && void 0 !== arguments[0] && arguments[0] || (0, NK.f)();
      const pO = null !== (OO = null === (KO = Re) || void 0 === KO ? void 0 : KO.overflow) && void 0 !== OO ? OO : null;
      Re = null, null !== pO && (0, gp.reportEventOverflow)(pO, Jb)
    }

    function xv() {
      null !== il || null !== Pe ? Jl() : ov()
    }

    function nl(OO, KO) {
      console.warn(`${ve} the event buffer refused records in ${KO} frames (categories ${OO})`), Nl || (null !== Re ? Wl(Re, OO, KO) : null !== Pe && function(OO, KO, pO) {
        var XO;
        const bK = function(OO, KO) {
          return null === OO ? "drop" : OO.activated ? "keep" : 0 !== (KO & BO.n.NetSession) ? "fail" : "drop"
        }((null === (XO = ql) || void 0 === XO ? void 0 : XO.join) === OO ? ql : null, KO);
        "keep" === bK ? Ge = {
          mask: KO,
          frames: pO
        } : "fail" === bK && (0, dO.g)(OO, new Error("the join's net session was lost to an event overflow"))
      }(Pe, OO, KO))
    }

    function Wl(OO, KO, pO) {
      const XO = OO.overflow ??= {
        frames: 0,
        acks: 0,
        mask: 0,
        outcome: null
      };
      XO.frames += pO, XO.acks++, XO.mask |= KO;
      const bK = function(OO, KO, pO) {
        if (0 === (OO & BO.n.NetSession)) return "none";
        const XO = null !== KO.rejoinedAt && pO - KO.rejoinedAt < gX;
        return null === KO.rejoin || XO ? "fail" : "rejoin"
      }(KO, OO, performance.now());
      "none" !== bK && queueMicrotask((() => {
        if (Re !== OO) return;
        const KO = "rejoin" === bK && performance.now() - xl >= Ip.e;
        XO.outcome = KO ? "rejoined" : "failed", Xv(function(OO, KO) {
          return {
            code: 0,
            name: "eventOverflow",
            reason: "Your game fell behind the server.",
            canReconnect: OO,
            automaticallyReconnect: KO,
            requiresRefresh: !1
          }
        }(null !== OO.rejoin, KO), OO.rejoin, KO), Jl(), KO && (Ze = performance.now())
      }))
    }

    function tv(OO) {
      Al = OO, fl && kv(fl, OO)
    }

    function kv(OO, KO) {
      OO.style.visibility = KO ? "visible" : "hidden"
    }

    function Ul(OO) {
      var KO;
      const pO = OO.roomName,
        XO = null !== (KO = OO.joinOptions.lobbyName) && void 0 !== KO ? KO : null;
      return () => {
        iv(pO, XO)
      }
    }

    function Ov() {
      return pO.e(98).then((() => pO(41336))).then((OO => {
        let {
          invalidateGuestTrafficCode: KO
        } = OO;
        return KO()
      })).catch((OO => {
        console.warn(`${ve} the cached traffic code could not be dropped`, OO)
      }))
    }

    function Kv(OO) {
      return We.add(OO), () => {
        We.delete(OO)
      }
    }

    function pv(OO, KO, pO) {
      var XO, bK;
      let lO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      if (Nl) return;
      if ((null === (XO = Re) || void 0 === XO ? void 0 : XO.conn) !== OO) return void(null !== Pe && Ue.set(OO, {
        code: KO,
        reason: pO
      }));
      const {
        rejoin: vK,
        game: CO,
        joinedAt: hO
      } = Re;
      qv(), fv();
      const DO = (0, Ip.k)(KO, (0, jX.c)(OO));
      if (console.info(`${ve} the game's connection closed with code ${KO} (${null!==(bK=DO.name)&&void 0!==bK?bK:"unrecognised"})`), KO === eO.e.gameOrPluginKick.code || lO || (0, gp.reportDisconnect)(DO, Jb, {
          closeReason: pO,
          sinceJoinedMs: performance.now() - hO,
          game: CO
        }), DO.requiresRefresh) {
        const OO = "outdatedVersion" === DO.name,
          pO = new Error(`the game's connection closed with code ${KO}`),
          XO = () => null === Re && null === Pe;
        return void VC({
          site: gp.JOIN_SITE,
          error: pO,
          outdated: OO
        }, (() => {
          XO() && Xv(DO, null, !1)
        }), XO)
      }
      const MO = DO.canReconnect ? vK : null,
        aK = null !== MO && DO.automaticallyReconnect && performance.now() - xl >= Ip.e;
      Xv(DO, MO, aK)
    }

    function Xv(OO, KO, pO) {
      var XO;
      let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {
        reasonKey: null,
        canPlayAgain: !1
      };
      if (dl) return;
      XX.e.unwantedLeave(pO && null !== KO && 0 === We.size), null === (XO = ne) || void 0 === XO || XO.abort();
      const eO = new AbortController;
      ne = eO;
      const lO = null === KO ? null : () => {
        eO.signal.aborted || (eO.abort(), KO())
      };
      if (pO && null !== lO) {
        xl = performance.now();
        const OO = setTimeout(lO, Ip.b);
        eO.signal.addEventListener("abort", (() => {
          clearTimeout(OO)
        }))
      }
      const vK = {
        code: OO.code,
        name: OO.name,
        reason: OO.reason,
        reasonKey: bK.reasonKey,
        reconnect: lO,
        reconnecting: pO,
        requiresRefresh: OO.requiresRefresh,
        canPlayAgain: bK.canPlayAgain
      };
      if (We.size > 0)
        for (const hO of [...We]) try {
          hO(vK)
        } catch (CO) {
          console.error(`${ve} an unwanted-leave listener threw`, CO)
        } else Qp((0, Fp.e)(OO, null !== lO, pO), eO.signal).then((KO => {
          KO && (null !== lO ? lO() : OO.requiresRefresh && (0, Ep.m)())
        }))
    }
    const bC = {
      attachSocket: OO => aC(OO),
      onConnection: OO => (Ol.add(OO), () => {
        Ol.delete(OO)
      }),
      sendRaw: (OO, KO) => {
        const pO = xe;
        return null !== pO && pO.conn === OO && vh(pO, KO)
      },
      leaveRoom: Gl,
      closeSocket: OO => {
        var KO;
        (null === (KO = xe) || void 0 === KO ? void 0 : KO.conn) === OO && ov()
      },
      flushNet: Fv
    };

    function ev(OO) {
      Zb.then((KO => {
        null === KO || KO.isStopped || Nl ? console.warn(`${ve} the play sources threw as they attached, after the client stopped`, OO) : hC({
          site: Mb,
          error: OO,
          header: null
        }, Jb)
      }))
    }

    function lv(OO) {
      let {
        aux: KO,
        payload: pO
      } = OO;
      const XO = me;
      return null !== XO && !XO.isStopped && (XO.queueOptions(KO, pO), !0)
    }

    function vC(OO, KO) {
      lv(function(OO, KO) {
        return VX = OO ? {
          preventMovement: KO
        } : null, OO ? LX(KO) : {
          aux: cK.Wb.AdEnd,
          payload: FX
        }
      }(OO, KO))
    }

    function Cv(OO) {
      var KO;
      jl = OO, null === (KO = me) || void 0 === KO || KO.setUiPrefs(OO)
    }

    function hv(OO, KO) {
      Sb.setMaster(OO, KO)
    }

    function Dv(OO) {
      var KO;
      Ye = OO, null === (KO = me) || void 0 === KO || KO.setEnvPrefs(OO)
    }

    function Mv(OO) {
      var KO;
      we = OO, null === (KO = me) || void 0 === KO || KO.setLookPrefs(OO)
    }

    function aC(OO) {
      var KO;
      let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new URL(OO.url).origin,
        XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      if (OO.readyState === WebSocket.CLOSING || OO.readyState === WebSocket.CLOSED) return console.warn(`${ve} a closing or closed socket can't be attached`), null;
      const bK = me;
      if (!bK || bK.isStopped) return console.warn(`${ve} no core is running to attach a socket to`), OO.close(), null;
      if (null === (0, HO.g)()) return console.warn(`${ve} the game has not started to attach a socket to`), OO.close(), null;
      if (Ae > cK.A) return console.warn(`${ve} this core has attached all the sockets it can; reload to play on`), OO.close(), null;
      if (yl && !Te && (Uv(bK, !1, "all"), bK.isStopped || Nl)) return OO.close(), null;
      ov();
      const eO = Ae++;
      if (!gC(bK, "open", eO, XO ? cK.Tb.Resume : 0)) return OO.close(), null;
      ql = null === Pe ? null : {
        join: Pe,
        conn: eO,
        activated: !1
      }, OO.binaryType = "arraybuffer";
      const lO = new VK.c((() => {
          ! function(OO, KO) {
            if (xe !== KO || OO.isStopped || null === Qv(KO, Ab)) return;
            KO.detach(), xe = null, Lv(OO, KO, Ab, "", !0), KO.ws.close()
          }(bK, vK)
        })),
        vK = {
          ws: OO,
          conn: eO,
          pending: [],
          pendingBytes: 0,
          left: !1,
          resume: XO,
          token: null,
          detach: () => {
            lO.dispose(), OO.removeEventListener("message", CO), OO.removeEventListener("open", hO), OO.removeEventListener("close", DO)
          }
        },
        CO = OO => {
          if (OO.data instanceof ArrayBuffer) {
            var KO;
            const pO = new Uint8Array(OO.data);
            lO.heard(), vK.token = null !== (KO = (0, LK.e)(pO)) && void 0 !== KO ? KO : vK.token,
              function(OO, KO, pO) {
                oC(OO, (() => {
                  OO.rings.net.writeFrame(KO, pO) || OO.crash(XK.u, `a socket frame of ${pO.byteLength} bytes did not fit the net-in ring`)
                }));
                const XO = OO.rings.net.cursor >= Qb;
                (XO || OO.netWrittenSinceFrame >= Lb || document.hidden && performance.now() - fe >= ye) && Uv(OO, !1, "budget")
              }(bK, eO, pO)
          }
        },
        hO = () => {
          for (const KO of vK.pending.splice(0)) OO.send(KO);
          vK.pendingBytes = 0
        },
        DO = OO => {
          if (xe === vK && bK.rings.net.cursor > 0 && Uv(bK, !1, "all"), xe === vK) {
            if (vK.detach(), xe = null, Lv(bK, vK, OO.code, OO.reason) || Vv(bK, vK)) return;
            gC(bK, "close", eO), zC(eO, vK.left), pv(eO, OO.code, OO.reason)
          }
        };
      return OO.addEventListener("message", CO), OO.addEventListener("open", hO), OO.addEventListener("close", DO), xe = vK, null === (KO = (0, HO.g)()) || void 0 === KO || KO.socketAttached(eO), (0, VO.q)({
        websocketUrl: pO
      }), eO
    }

    function ov() {
      const OO = xe;
      if (!OO) return;
      const KO = me,
        pO = OO.resume;
      pO && (Fv(), xe !== OO) || (xe = null, OO.detach(), OO.ws.close(), null !== KO && (Vv(KO, OO) || pO && Lv(KO, OO, fb)) || (null !== KO && gC(KO, "close", OO.conn), zC(OO.conn, OO.left)))
    }

    function Fv() {
      const OO = me;
      null !== OO && !OO.isStopped && !Nl && !Te && OO.rings.net.cursor > 0 && Uv(OO, !1, "all")
    }

    function Vv(OO, KO) {
      var pO;
      if (!KO.resume) return !1;
      const XO = Se;
      return null !== XO && null !== KO.token && "" !== KO.token && (XO.pendingHold = {
        conn: KO.conn,
        token: `${XO.roomId}:${KO.token}`
      }), gC(OO, "close", KO.conn), null === (pO = (0, HO.g)()) || void 0 === pO || pO.socketDetached(KO.conn), !0
    }

    function Lv(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "",
        bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
      const eO = Qv(KO, pO);
      if (null === eO) return !1;
      const {
        JK: lO,
        token: vK,
        game: CO,
        joinedAt: hO
      } = eO;
      if (!gC(OO, "close", KO.conn, cK.D.Held)) return !0;
      console.warn(`${ve} the game's connection ${bK?"went silent":`dropped with code ${pO}`}, holding it`);
      const DO = {
        closeReason: XO,
        sinceJoinedMs: performance.now() - hO,
        game: CO
      };
      return (0, gp.reportDisconnect)((0, Ip.k)(pO), Jb, DO, bK ? "silent" : void 0), lO.heldConn = KO.conn, lO.dropCode = pO, lO.pendingHold = {
        conn: KO.conn,
        token: `${lO.roomId}:${vK}`
      }, Te || Uv(OO, !1, "all"), !0
    }

    function Qv(OO, KO) {
      const pO = Se,
        XO = Re,
        bK = OO.token;
      return null === pO || null === XO || Nl || OO.left || XO.conn !== OO.conn || null === bK || "" === bK ? null : (0, eO.j)(KO) && pO.resume.canHoldSeat() ? {
        JK: pO,
        token: bK,
        game: XO.game,
        joinedAt: XO.joinedAt
      } : null
    }

    function zC(OO, KO) {
      var pO;
      null === (pO = (0, HO.g)()) || void 0 === pO || pO.closeGame(OO), (0, oX.e)().close(OO), KO || (0, VO.q)({
        websocketUrl: null
      })
    }

    function Av() {
      const OO = Be;
      if (null === OO) return;
      const KO = (0, HO.g)();
      Nl || null === KO || KO.QKO(OO) ? Be = null : performance.now() - gl.pause >= Ib && (gl.pause = performance.now(), console.warn(`${ve} the cmd ring had no room for SetPaused(${OO}): written before the next frame`))
    }

    function fv() {
      const OO = Se;
      Se = null, null === OO || void 0 === OO || OO.resume.dispose()
    }

    function dv(OO, KO) {
      var pO, XO;
      const {
        heldConn: bK
      } = OO, eO = OO.resume.resumingConn;
      OO.heldConn = 0, OO.pendingHold = null, Se === OO && (Se = null), "left" === KO ? OO.resume.DX() : OO.resume.dispose(), 0 === cl || (null === (pO = xe) || void 0 === pO ? void 0 : pO.conn) !== cl || "left" === KO && (null === (XO = il) || void 0 === XO ? void 0 : XO.conn) === cl || yC(cl), "gaveUp" === KO && 0 !== eO && yC(eO), 0 !== bK && "refused" !== KO && (console.info(`${ve} the game held through its drop ${"left"===KO?"was left":"is given up"}`), null === me || me.isStopped || gC(me, "close", bK), zC(bK, !1))
    }

    function Tv(OO, KO) {
      const pO = KO.indexOf(":");
      return {
        roomId: pO < 0 ? OO.roomId : KO.slice(0, pO),
        roomToken: KO.slice(pO + 1)
      }
    }

    function Nv(OO) {
      var KO;
      Je = OO, OO.conn === cl && (cl = 0);
      const pO = Se;
      null !== pO && (null === (KO = Re) || void 0 === KO ? void 0 : KO.conn) === OO.conn && pO.resume.onInitialInfo(OO)
    }
    async function Iv(OO, KO, pO, XO) {
      const {
        roomId: bK,
        roomToken: eO
      } = Tv(OO, KO);
      if (null === me || me.isStopped || Nl) throw new Error("no core is running to resume the game on");
      const {
        resumeRoom: lO
      } = await Hl(yv(), pO);
      return lO({
        ...bC,
        attachSocket: KO => Se !== OO || 0 === OO.heldConn ? (KO.close(), null) : aC(KO, OO.endpoint, !0)
      }, OO.endpoint, bK, eO, {
        signal: pO,
        onAttached: XO
      })
    }

    function yC(OO) {
      var KO;
      const pO = xe;
      (null === pO || void 0 === pO ? void 0 : pO.conn) === OO && (pO.left = !0, null === (KO = (0, HO.g)()) || void 0 === KO || KO.socketLeft(), (0, VO.q)({
        websocketUrl: null
      }), Gl(OO) ? setTimeout((() => {
        xe === pO && ov()
      }), hK.c) : ov())
    }

    function gC(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
        bK = !1;
      return oC(OO, (() => {
        const {
          net: eO
        } = OO.rings;
        bK = "open" === KO ? eO.writeOpen(pO, XO) : eO.writeClose(pO, XO), bK || OO.crash(XK.u, `a socket ${KO} did not fit the net-in ring`)
      })), bK
    }

    function uv(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      if (Ev()) return (0, gp.reportUnsupportedFallback)(OO, KO, pO), void jC(`the wasm client can't run here (${KO})`, "unsupported");
      (0, gp.showUnsupported)(OO, "unsupported", KO, pO)
    }

    function Ev() {
      return zv && "wasm" !== (0, FO.f)(window.location.search)
    }

    function jC(OO, KO) {
      console.warn(`${ve} ${OO}: reloading on the JS client`), null !== KO && (0, FO.m)(KO);
      const pO = () => {
        (0, Ep.i)(FO.v)
      };
      (0, gp.flushCrashReports)(Ep.e).then(pO, pO)
    }

    function Yv(OO, KO, pO, XO) {
      return bv(OO, KO, pO, XO)
    }

    function wv() {
      null === vv || null === me || me.isStopped || Nl || null !== he || null === ub || (he = vv(ub, mC, sv().follow))
    }

    function iC() {
      var OO, KO, pO;
      return null !== (OO = null === (KO = Hb) || void 0 === KO || null === (pO = KO.textures) || void 0 === pO ? void 0 : pO.files()) && void 0 !== OO ? OO : null
    }

    function rC(OO) {
      pO.e(250).then((() => pO(38812))).then((KO => {
        let {
          setIconFileOverrides: pO
        } = KO;
        pO(OO)
      }), (OO => {
        console.warn(`${ve} the item icons couldn't take the texture pack's files`, OO)
      }))
    }

    function Pv(OO) {
      sv().follow((KO => {
        null !== KO && Promise.all([Promise.all([pO.e(180), pO.e(41)]).then((() => pO(41363))), (0, ab.J)()]).then((OO => {
          let [{
            followPagePackFiles: pO
          }, XO] = OO;
          const bK = null === XO || (0, pK.s)(XO) ? "webgl" : XO.backend;
          pO(KO, pX.d, bK, (OO => {
            pX.d.setPageFiles(OO)
          }), mC)
        }), (KO => {
          console.warn(`${ve} the texture pack's files didn't load: the previews draw the shipped ones until the next opens`, KO), OO()
        }))
      }))
    }

    function mC(OO, KO) {
      console.warn(`${ve} ${OO}`, KO)
    }

    function sv() {
      return sb ??= new uX({
        load: OO => Promise.all([pO.e(180), pO.e(46)]).then((() => pO(41370))).then((KO => {
          let {
            startPageTexturePackFeed: pO
          } = KO;
          return pO(mC, OO)
        })),
        store: yp.d,
        CX: OO => {
          Zb.then((() => {
            (0, gp.reportTexturePackFeedLoadFailure)(OO, Jb)
          }))
        }
      }), sb
    }
    const Hv = OO => sv().follow(OO);

    function Rv() {
      return sv().loaded()
    }
    const Sv = function(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => performance.now(),
          bK = 0;
        return async function(eO, lO) {
          let vK = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => !0;
          const CO = ++bK,
            hO = XO() + KO,
            DO = await
          function(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => {};
            return new Promise((XO => {
              const bK = setTimeout((() => {
                XO(null), OO.then((OO => {
                  null !== OO && (OO.joinedWithout(), pO(OO))
                }))
              }), KO);
              OO.then((OO => {
                clearTimeout(bK), XO(OO)
              }))
            }))
          }(OO(eO), KO, (OO => {
            CO === bK && vK() && lO(OO, XO() + KO).catch((OO => {
              pO("the texture pack step after the join failed", OO)
            }))
          }));
          return null === DO ? null : lO(DO, hO)
        }
      }((OO => (0, bK.k)(OO) ? sv().request() : sv().forJoin()), gb.d, mC),
      Jv = function(OO, KO) {
        let pO = !1;
        return {
          setGamePackConfirm: OO => {
            pO = null !== OO, KO(OO)
          },
          packStep: (KO, XO, bK) => OO(KO, XO, (() => pO && bK()))
        }
      }(Sv, (OO => {
        sv().setGamePackConfirm(OO)
      }));

    function cC(OO) {
      Jv.setGamePackConfirm(OO)
    }
    async function Bv(OO, KO, XO) {
      const {
        gamePackSource: bK
      } = await pO.e(99).then((() => pO(41344)));
      await Jv.packStep(OO, ((pO, XO) => pO.packForGame(OO, bK(KO), XO)), XO)
    }

    function Zv() {
      if (Nl || null !== Ml || null === Cl || null === Dl) return;
      const {
        backend: OO,
        canvas: KO,
        fallbackReason: pO,
        adapterVendor: XO
      } = Dl, bK = Cl;
      Cl = null;
      try {
        Ml = bK({
          backend: OO,
          canvas: KO,
          fallbackReason: pO,
          adapterVendor: XO,
          joinedGame: () => Nl ? null : il,
          inGame: qC,
          shaderPackRuns: Rl,
          writeCmd: (OO, KO, pO) => null !== ub && ub(OO, KO, pO),
          takeFailedMeshJobs: () => {
            var OO, KO;
            return null !== (OO = null === (KO = ke) || void 0 === KO ? void 0 : KO.takeFailedMeshJobs()) && void 0 !== OO ? OO : 0
          }
        })
      } catch (eO) {
        console.error(`${ve} the frame telemetry didn't start`, eO)
      }
    }

    function Gv(OO, KO) {
      try {
        var pO, XO, bK;
        const eO = Kl && null !== (pO = null === (XO = me) || void 0 === XO || null === (bK = XO.lastHeader) || void 0 === bK ? void 0 : bK.renderPending) && void 0 !== pO ? pO : 0;
        (0, nK.d)(KO, OO, qC() && !(null !== VX), eO)
      } catch (eO) {
        (0, nK.u)(), console.error(`${ve} the quality steps stopped`, eO)
      }
    }

    function qC() {
      return null !== il && Ll === il && !Nl
    }

    function xC(OO) {
      const KO = Ml;
      Ml = null;
      try {
        null === KO || void 0 === KO || KO.stop()
      } catch {}
      console.error(`${ve} the frame telemetry threw: it stops`, OO)
    }

    function nv(OO) {
      var KO, pO, XO;
      if ((0, oX.e)().fire(OO), "message" === OO.type) {
        if (Ne++, OO.Tl === cK.Gc.ERROR && null !== Pe) {
          var bK;
          const {
            text: KO,
            dropsCache: pO
          } = (0, Ip.s)((new TextDecoder).decode(OO.payload));
          tl ||= pO, (null === (bK = ql) || void 0 === bK ? void 0 : bK.conn) === OO.conn && (kl = KO)
        } else if (OO.Tl === BO.Hb.ResumeComplete) {
          var eO;
          null === (eO = Se) || void 0 === eO || eO.resume.onResumeComplete(OO.conn)
        }
        return
      }
      if (OO.phase === cK.F.Left) Ie = OO.conn;
      else if (OO.phase === cK.F.Activated) {
        var vK;
        LO.c.reset(), (null === (vK = ql) || void 0 === vK ? void 0 : vK.conn) === OO.conn && (ql.activated = !0)
      } else OO.phase === cK.F.Resumed ? function(OO) {
        var KO, pO;
        cl = OO;
        const XO = Se;
        if (null === XO || 0 === XO.heldConn || (null === (KO = xe) || void 0 === KO ? void 0 : KO.conn) !== OO || !xe.resume || null === Re) return;
        console.info(`${ve} the game resumed on conn ${OO}, waiting for its InitialInfo`);
        const bK = XO.heldConn;
        XO.heldConn = 0, xe.resume = !1, Re.conn = OO, (null === (pO = se) || void 0 === pO ? void 0 : pO.conn) === bK && (se = {
          conn: OO,
          info: se.info
        }), LO.c.apply({
          shopInfo: null,
          _shopVersion: lO.e
        })
      }(OO.conn) : OO.phase === cK.F.Held ? function(OO) {
        var KO;
        const pO = Se,
          XO = null !== (KO = null === pO || void 0 === pO ? void 0 : pO.pendingHold) && void 0 !== KO ? KO : null;
        if (null !== pO && null !== XO && XO.conn === OO) return pO.pendingHold = null, pO.heldConn = OO, cl = 0, console.warn(`${ve} the core holds the game, reconnecting`), void pO.resume.onDropped(XO.token);
        if (OO === cl) {
          cl = 0;
          const KO = me;
          null === KO || KO.isStopped || (console.info(`${ve} the core held again a resumed game the shell ended before its InitialInfo: closing it again`), gC(KO, "close", OO))
        }
      }(OO.conn) : OO.phase === cK.F.Closed && (null === (KO = Se) || void 0 === KO || null === (pO = KO.pendingHold) || void 0 === pO ? void 0 : pO.conn) === OO.conn && (Se.heldConn === OO.conn ? function(OO) {
        const KO = OO.heldConn,
          pO = OO.dropCode;
        dv(OO, "refused"), console.info(`${ve} the core didn't hold the game through its drop: it hadn't started`), queueMicrotask((() => {
          zC(KO, !1), pv(KO, pO, "", !0)
        }))
      }(Se) : Se.pendingHold = null);
      const CO = Object.keys(cK.F).find((KO => cK.F[KO] === OO.phase)),
        hO = 0 === OO.code ? "" : ` (code ${OO.code})`;
      console.info(`${ve} conn ${OO.conn}: ${null!==CO&&void 0!==CO?CO:OO.phase}${hO}, ${Ne} raw messages so far`), (null === (XO = il) || void 0 === XO ? void 0 : XO.conn) !== OO.conn || OO.phase !== cK.F.Left && OO.phase !== cK.F.Closed || Zl(null), ml !== OO.conn || OO.phase !== cK.F.Left && OO.phase !== cK.F.Closed || (ml = null, null === il && null === Pe && XX.e.setGame(void 0));
      for (const lO of [...Ol]) try {
        lO(OO.conn, OO.phase, OO.code)
      } catch (DO) {
        (0, ZO.p)(DO, `${ve} a connection listener threw`)
      }
    }

    function Wv() {
      (0, ab.p)(), queueMicrotask((() => {
        try {
          CC()
        } catch (OO) {
          console.warn(`${ve} stopping before the reload threw`, OO)
        }(0, gp.flushCrashReports)(Ep.e).then(Ep.m, Ep.m)
      }))
    }

    function tC() {
      const OO = me;
      null === OO || OO.isStopped || null === xe || Te || !OO.hasPendingCommands() || Uv(OO, !1, "budget")
    }

    function kC(OO) {
      var KO;
      const pO = il;
      OO.persisted || null === pO || (null === (KO = xe) || void 0 === KO ? void 0 : KO.conn) !== pO.conn || xe.left || pO.DX()
    }

    function Uv(OO, KO, XO) {
      let bK = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
      const eO = Te;
      Te = !0;
      try {
        return function(OO, KO, XO, bK) {
          var eO, lO, vK;
          if (Nl) return !1;
          if (oC(OO, KC), Nl || OO.isStopped) return !1;
          eC() && Qe("modelsIn");
          Av(), fe = performance.now(), Ie = null, yl = !1, (0, jK.J)(), null === (eO = bl) || void 0 === eO || eO.beforeFrame(), hp(fe, OO), (0, jK.z)(fe, pC), de = !0;
          const CO = KO && bh();
          let hO;
          try {
            hO = OO.frame(fe, CO, XO)
          } finally {
            de = !1
          }
          if (!hO) return !1;
          hl.observe(null !== (lO = null === (vK = OO.lastHeader) || void 0 === vK ? void 0 : vK.chunksCancelled) && void 0 !== lO ? lO : 0);
          const DO = OO.lastFrameKind,
            MO = (0, EO.c)(DO);
          KO && (Ql = MO);
          MO && (0, yK.b)(fe);
          if (null !== Ml) try {
            Ml.frameRan(OO, fe, performance.now(), DO)
          } catch (oO) {
            xC(oO)
          }
          "drawn" === DO && XC() && function() {
            for (const OO of [...DX]) OO()
          }();
          OO.forEachNetOut(lC);
          const aK = xe;
          null !== Ie && (null === aK || void 0 === aK ? void 0 : aK.conn) === Ie && vh(aK, hK.g);
          KO && function(OO) {
            var KO, XO, bK;
            if (null === il || !bh()) return;
            const eO = OO.lastHeader,
              lO = !Kl || 0 === (null === eO || void 0 === eO ? void 0 : eO.renderPending);
            !Vl && lO && (Vl = !0, performance.mark(Vb));
            if (Ll === il) return;
            const vK = null !== (KO = null === eO || void 0 === eO ? void 0 : eO.firstView) && void 0 !== KO ? KO : cK.Z.NotYet;
            if (Kl && vK === cK.Z.NotYet) return;
            if (Fl && (!0 !== (null === (XO = (0, HO.g)()) || void 0 === XO ? void 0 : XO.isSessionLive) || !lO)) return;
            Ll = il;
            const CO = il;
            if (setTimeout((() => {
                il === CO && (0, rK.f)()
              }), 0), null === (bK = oe) || void 0 === bK || bK.playable(), Fl) return;
            Fl = !0, performance.mark(Fb), (0, mb.q)("render") && pO.e(43).then((() => pO(3852))).then((OO => {
              let {
                renderDebugPlayable: KO
              } = OO;
              KO()
            }), (OO => {
              console.warn("The render debug topic didn't load", OO)
            }));
            const hO = Math.round(performance.now());
            Kl && vK === cK.Z.Backstop ? console.warn(`${ve} playable at ${hO} ms on the first view's backstop: it wasn't drawn whole in time`) : console.info(`${ve} playable at ${hO} ms${Kl?"":" (no renderer)"}`);
            setTimeout(ll, 0), (0, zK.h)().catch((OO => {
              console.error(`${ve} item sprites didn't load, so item particles show the missing texture`, OO)
            }))
          }(OO);
          (0, XK.N)(OO, {
            worldgen: Wb,
            mesh: ke
          }),
          function(OO) {
            OO.forEachEvent(Mp);
            for (const KO of Dp) try {
              (0, bX.d)(KO)
            } catch (oO) {
              if ((0, ZO.i)(oO)) {
                OO.crashOn(XK.n, oO);
                break
              }
              console.error(`${lp} an input action listener threw`, oO)
            }
            Dp.length = 0
          }(OO), bK && (0, uO.b)();
          return !OO.isStopped
        }(OO, KO, "all" === XO || OO.rings.net.cursor >= Qb || OO.netKeptFrames >= ze, bK)
      } finally {
        Te = eO
      }
    }

    function OC(OO) {
      console.error(`${ve} a frame-start listener threw`, OO)
    }

    function KC() {
      var OO, KO, pO, XO;
      null === (OO = le) || void 0 === OO || OO.drain(ub, Eb), null === (KO = De) || void 0 === KO || KO.drain(ub), null === (pO = Me) || void 0 === pO || pO.drain(performance.now()), el(ub), null === (XO = he) || void 0 === XO || XO.drain()
    }

    function pC(OO) {
      console.error(`${ve} a before-frame listener threw`, OO)
    }

    function XC() {
      return Kl && bh()
    }

    function bh() {
      return al && eC()
    }

    function eC() {
      return null === le || le.startupDone
    }

    function lC(OO, KO) {
      const pO = xe;
      (null === pO || void 0 === pO ? void 0 : pO.conn) === OO ? vh(pO, KO) : Ee++
    }

    function vh(OO, KO) {
      const {
        ws: pO
      } = OO;
      return pO.readyState === WebSocket.OPEN ? (pO.send(KO), !0) : pO.readyState === WebSocket.CONNECTING && OO.pendingBytes + KO.byteLength <= Nb ? (OO.pending.push(KO.slice()), OO.pendingBytes += KO.byteLength, !0) : (Ee++, !1)
    }

    function CC() {
      var OO, KO, pO, XO, bK, eO, lO, vK, hO, DO, MO, aK, oO, FO, VO, LO, QO;
      Nl = !0, (0, sX.d)(), fv(), (0, jK.F)().unlockPointer(), (0, jK.D)(null), null === (OO = ee) || void 0 === OO || OO(), ee = null, null === (KO = (0, HO.s)()) || void 0 === KO || KO.followCursorAim(null), (0, uO.A)(), (0, HO.e)(), Sb.stop(), null === (pO = av) || void 0 === pO || pO(), av = null, null === (XO = ol) || void 0 === XO || XO(), ol = null, null === (bK = Ml) || void 0 === bK || bK.stop(), Ml = null, (0, EK.k)(null), null === (eO = nb) || void 0 === eO || eO(), nb = null, null === (lO = Wb) || void 0 === lO || lO.stop(), Wb = null, null === (vK = ke) || void 0 === vK || vK.stop(), ke = null, null !== (hO = Hb) && void 0 !== hO && null !== (DO = hO.textures) && void 0 !== DO && DO.assets && rC(null), null === (MO = Hb) || void 0 === MO || MO.stop(), Hb = null, Rb = null;
      const zK = Ub;
      Ub = null, zK && (zK.stop(), ah(zK)), null === (aK = De) || void 0 === aK || aK.dispose(), De = null, null === (oO = Me) || void 0 === oO || oO.dispose(), Me = null, le = null, null === (FO = Ce) || void 0 === FO || FO(), Ce = null, null === (VO = Xe) || void 0 === VO || VO(), Xe = null, null === (LO = bl) || void 0 === LO || LO.stop(), bl = null, Jl(), XX.e.release(), ov();
      const AO = he;
      he = null;
      try {
        null === AO || void 0 === AO || AO.dispose()
      } catch (fO) {
        console.warn(`${ve} the sky's images didn't release`, fO)
      }(0, Wp.h)(null), null === (QO = re) || void 0 === QO || QO.pagePreviews().endSession(null === (0, CO.n)())
    }

    function hC(OO, KO) {
      var pO, XO;
      const bK = null !== (pO = null === (XO = Ub) || void 0 === XO ? void 0 : XO.details()) && void 0 !== pO ? pO : {},
        eO = OO.site === hb || OO.site === Db || OO.site === gp.RENDER_RELOAD_SITE || OO.site === Mb ? OO.error instanceof WebAssembly.RuntimeError || OO.error instanceof kK.b : !(0, pK.t)(OO.error) && (0, XK.J)(OO);
      eO && OO.error instanceof Error && (0, CO.T)(OO.error);
      const lO = eO || OO.site === XK.v ? (0, gp.readTrap)(OO.error) : null,
        vK = null !== lO && (0, GO.i)(lO.kind, lO.refusedBytes) ? lO.refusedBytes : 0,
        hO = null === Oe ? (0, qX.t)(function() {
          try {
            return (0, CO.u)().buffer.byteLength
          } catch {
            return 0
          }
        }(), vK, null) : Oe.ceilingMayRefuse(vK),
        DO = vK > 0 && !hO && Ev();
      var MO;
      if (DO && ((0, FO.m)("oom"), Tl = !0), CC(), (0, ab.e)()) return console.warn(`${ve} the session stopped at ${OO.site} as the page reloads`, OO.error), void((0, pK.t)(OO.error) || (null === (MO = OO.header) || void 0 === MO ? void 0 : MO.lastError) === cK.I.CoreBusy || (0, gp.reportStoppedCore)(OO, KO, lO, {
        memoryDetails: bK,
        declined: DO
      }));
      (0, gp.showCrash)(OO, KO, lO, {
        memoryDetails: bK,
        declined: DO
      })
    }

    function DC(OO) {
      const {
        input: KO,
        net: pO,
        worker: XO
      } = OO.rings, bK = OO.optionsDropped, eO = KO.dropped + bK + pO.dropped + XO.dropped + Ee;
      eO !== ue && function(OO, KO) {
        const pO = performance.now();
        return !(pO - gl[OO] < Ib) && (gl[OO] = pO, console.warn(`${ve} ${KO}`), !0)
      }("dropped", `${eO} records dropped so far (input ${KO.dropped}, options ${bK}, net ${pO.dropped}, worker ${XO.dropped}, net-out ${Ee})`) && (ue = eO)
    }

    function MC() {
      var OO, KO, pO, XO;
      const bK = (0, TK.e)(),
        eO = null === bK ? null : (0, IK.h)(bK);
      return {
        ...null === (OO = Ub) || void 0 === OO ? void 0 : OO.pageKillSnapshot(),
        renderDistance: null === eO ? null : Math.min(eO.horizontal, null !== (KO = null === (pO = Ub) || void 0 === pO ? void 0 : pO.shedDistanceInUse()) && void 0 !== KO ? KO : 1 / 0),
        renderDistanceVertical: null !== (XO = null === eO || void 0 === eO ? void 0 : eO.vertical) && void 0 !== XO ? XO : null,
        chunkCap: Ke,
        budgetBasis: pe,
        renderBackend: (0, ab.C)()
      }
    }

    function ah(OO) {
      console.info(`${ve} wasm memory at the session's end`, OO.details())
    }

    function oC(OO, KO) {
      if (!OO.isStopped) try {
        KO()
      } catch (pO) {
        OO.crash(XK.z, pO)
      }
    }
    async function FC() {
      const {
        createWorldgenWorker: OO,
        worldgenWorkerReady: KO
      } = await (te ??= pO.e(61).then((() => pO(41376))).catch((OO => {
        throw te = null, OO
      })), te);
      return await KO(), OO
    }

    function VC(OO, KO, pO) {
      return async function(OO, KO, pO) {
        let {
          stop: XO,
          stillWanted: bK
        } = pO;
        const eO = await (0, upO.h)(OO, {
          stillWanted: bK,
          beforeReload: async () => {
            XO(), await (0, gp.flushCrashReports)(Ep.e)
          },
          reload: Ep.m
        });
        return eO || KO(), eO
      }(OO, KO, {
        stop: CC,
        stillWanted: pO
      })
    }
  },
  39050: (OO, KO, pO) => {
    function XO(OO) {
      return "fetch" === OO || "timeout" === OO || "integrity" === OO ? "download" : "browser"
    }
    pO.d(KO, {
      c: () => bK,
      d: () => lO,
      e: () => CO,
      f: () => vK,
      h: () => XO,
      j: () => eO
    });
    const bK = "https://discord.gg/playbloxd";

    function eO(OO) {
      return "download" === OO ? {
        icon: "wifi",
        title: "wasmScreens:downloadFailedTitle",
        help: "wasmScreens:downloadFailedHelp",
        helpValues: {},
        discordLink: !1,
        confirm: "general:tryAgain",
        cancel: "general:back"
      } : {
        icon: "face-dizzy",
        title: "wasmScreens:unsupportedTitle",
        help: "wasmScreens:unsupportedHelp",
        helpValues: {},
        discordLink: !1,
        confirm: "general:ok",
        cancel: null
      }
    }

    function lO(OO, KO) {
      return {
        icon: "face-dizzy",
        title: "wasmScreens:crashTitle",
        help: KO ? "wasmScreens:crashHelp" : "wasmScreens:crashHelpNoDiscord",
        helpValues: {
          code: OO.code
        },
        discordLink: KO,
        confirm: "general:reload",
        cancel: "general:back"
      }
    }

    function vK() {
      return {
        icon: "face-dizzy",
        title: "wasmScreens:turnstilePageTitle",
        help: "wasmScreens:turnstilePageHelp",
        helpValues: {},
        discordLink: !1,
        confirm: "general:ok",
        cancel: null
      }
    }

    function CO(OO, KO, pO) {
      return {
        icon: "wifi",
        title: "wasmScreens:disconnectedTitle",
        help: pO ? "wasmScreens:reconnectingHelp" : "wasmScreens:disconnectedHelp",
        helpValues: {
          reason: OO.reason
        },
        discordLink: null === OO.name,
        confirm: KO ? "general:reconnect" : OO.requiresRefresh ? "general:reload" : "general:ok",
        cancel: null
      }
    }
  },
  39072: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      g: () => XO,
      j: () => vK,
      l: () => lO
    });
    const XO = 12e4,
      bK = 3e4,
      eO = {
        hidden: () => "undefined" !== typeof document && document.hidden,
        listen: OO => "undefined" === typeof document ? () => {} : (document.addEventListener("visibilitychange", OO), () => {
          document.removeEventListener("visibilitychange", OO)
        })
      };

    function lO(OO) {
      return `it sent no start within ${Math.round(OO)} ms`
    }
    class vK {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : () => performance.now(),
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : eO;
        this.timeoutMs = OO, this.onTimeout = KO, this.now = pO, this.visibility = XO, this.timer = null, this.counted = 0, this.step = null, this.unlisten = void 0, this.unlisten = XO.listen((() => {
          this.onVisibility()
        })), XO.hidden() || this.next()
      }
      cancel() {
        this.pause(), this.unlisten()
      }
      onVisibility() {
        this.visibility.hidden() ? (this.counted += this.credit(), this.pause()) : null === this.timer && this.next()
      }
      credit() {
        const OO = this.step;
        return null === OO ? 0 : Math.min(this.now() - OO.at, OO.ms)
      }
      pause() {
        null !== this.timer && (clearTimeout(this.timer), this.timer = null), this.step = null
      }
      next() {
        const OO = this.timeoutMs - this.counted;
        if (OO <= 0) return void this.arm(1e3, (() => {
          this.cancel(), this.onTimeout(this.counted)
        }));
        const KO = Math.min(OO, 5e3);
        this.step = {
          at: this.now(),
          ms: KO
        }, this.arm(KO, (() => {
          this.counted += this.credit(), this.step = null, this.next()
        }))
      }
      arm(OO, KO) {
        this.timer = setTimeout((() => {
          this.timer = null, KO()
        }), OO)
      }
    }
  },
  38943: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    const XO = {
      roomsPerServerMax: 30,
      timeForPlayerToConnect: 3e4,
      seatReservationSeconds: 15,
      healthWindowMs: 3e5,
      minAttemptsForRoomHealthWindow: 6,
      minAttemptsForServerHealthWindow: 20,
      minAttemptsForEmptyServerHealthWindow: 6,
      playerTimeoutThreshold: .8,
      gameServerMatchmakingHeartbeatInterval: 2e3,
      gameServerMatchmakingAnalyticsHeartbeatInterval: 1e4,
      SetRoomsHeartbeatBackoffMultiplier: 1.5,
      SetRoomsHeartbeatMaxInterval: 1e4,
      AnalyticsHeartbeatBackoffMultiplier: 1.2,
      AnalyticsHeartbeatMaxInterval: 3e4,
      defaultSubtractionFromMaxPlayersForSoftCap: 2,
      saveExpectedPlayersEvery: 1e4,
      unregisterFrozenGameServersIntervalMs: 1e3,
      gameServerFrozenThresholdMs: 3e4,
      matchmakingSkipsDrainingLobbies: !0,
      minNotDrainingShareToSkipDrainingLobbies: .5,
      drainingSessionLobbyFillMs: 3e5
    }
  },
  38987: (OO, KO, pO) => {
    function XO(OO, KO) {
      if (!Object.prototype.hasOwnProperty.call(OO, KO)) throw new TypeError("attempted to use private field on non-instance");
      return OO
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  38995: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    var XO = 0;

    function bK(OO) {
      return "__private_" + XO++ + "_" + OO
    }
  },
  37102: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO
    });
    var XO = pO(2947);
    const bK = ["none", "idle", "now"];

    function eO() {
      const OO = () => (0, XO.G)();
      return {
        memoryBytes: () => (0, XO.u)().buffer.byteLength,
        reserveUpFront: KO => OO().LO(KO),
        reserveAhead: KO => OO().VO(KO),
        setCeiling: KO => {
          OO().QO(KO)
        },
        lowWater: () => bK[OO().FO()] ?? "none",
        stats: () => function(OO) {
          const KO = new Uint32Array((0, XO.u)().buffer, OO, 17),
            pO = OO => KO[OO] ?? 0,
            bK = OO => ({
              upFront: pO(OO),
              ahead: pO(OO + 1),
              onDemandInFrame: pO(OO + 2),
              onDemand: pO(OO + 3)
            });
          return {
            memoryBytes: pO(0),
            initialBytes: pO(1),
            liveBytes: pO(2),
            peakLiveBytes: pO(3),
            headroomBytes: pO(4),
            unusedBytes: pO(5),
            ceilingBytes: pO(6),
            reservesRefused: pO(7),
            grows: bK(8),
            grownBytes: bK(12),
            allocationsRefused: pO(16)
          }
        }(OO().zK()),
        takeBallast: () => OO().fO(),
        takePressure: () => OO().dO()
      }
    }
  },
  5771: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => fO,
      g: () => dO,
      i: () => zK,
      m: () => QO
    });
    var XO = pO(5778);
    const bK = 6,
      eO = 3,
      lO = 1,
      vK = 2,
      CO = 4,
      hO = 8,
      DO = 16,
      MO = 32,
      aK = 64,
      oO = 128,
      FO = ["", "bloxdTerrainVertex", "bloxdTerrainSurface", "bloxdTerrainLight", "bloxdLiquidVertex", "bloxdLiquidSurface", "bloxdLiquidLight", "bloxdModelVertex", "bloxdModelSurface", "bloxdModelLight", "bloxdDefaultSurface", "bloxdDefaultLight"];

    function VO(OO) {
      if (!OO) return 0;
      const KO = FO.indexOf(OO);
      if (KO <= 0) throw new Error(`"${OO}" is not a shader pack hook function`);
      return KO
    }

    function LO(OO) {
      if (0 === OO) return null;
      const KO = FO[OO];
      if (void 0 === KO) throw new Error(`${OO} is not a shader pack hook function id`);
      return KO
    }

    function QO(OO) {
      const KO = XO.e.length;
      return {
        strict: OO >= KO,
        program: XO.e[OO % KO]
      }
    }

    function zK(OO) {
      return Number(OO.strict) * XO.e.length + XO.e.indexOf(OO.program)
    }

    function AO(OO) {
      return "" === OO ? [] : OO.split(" ")
    }

    function fO(OO) {
      const KO = {
        variantFlags: new Uint8Array(bK),
        hooks: new Uint8Array(bK * eO),
        moduleCodes: Array(bK).fill(""),
        reads: Array(2 * bK).fill("")
      };
      for (const pO of OO) {
        const OO = zK(pO.key),
          XO = (OO, KO) => null === pO.hooks.surface || pO.reads.fragment.includes(OO) ? 0 : KO;
        KO.variantFlags[OO] = (pO.sceneDepth ? lO : 0) | (pO.movesVertices ? vK : 0) | (pO.sunShadow ? CO : 0) | (pO.airShadow ? hO : 0) | (pO.discards ? DO : 0) | XO("localPosition", MO) | XO("enchantSpeed", aK) | XO("enchantTier", oO), KO.hooks[OO * eO] = VO(pO.hooks.vertex), KO.hooks[OO * eO + 1] = VO(pO.hooks.surface), KO.hooks[OO * eO + 2] = VO(pO.hooks.light), KO.moduleCodes[OO] = pO.moduleCode, KO.reads[2 * OO] = pO.reads.vertex.join(" "), KO.reads[2 * OO + 1] = pO.reads.fragment.join(" ")
      }
      return KO
    }

    function dO(OO) {
      const {
        hooks: KO,
        moduleCodes: pO,
        reads: XO
      } = OO;
      return Array.from(OO.variantFlags, ((OO, bK) => {
        const MO = bK * eO;
        return {
          key: QO(bK),
          hooks: {
            vertex: LO(KO[MO]),
            surface: LO(KO[MO + 1]),
            light: LO(KO[MO + 2])
          },
          moduleCode: pO[bK],
          sceneDepth: 0 !== (OO & lO),
          sunShadow: 0 !== (OO & CO),
          airShadow: 0 !== (OO & hO),
          movesVertices: 0 !== (OO & vK),
          discards: 0 !== (OO & DO),
          reads: {
            vertex: AO(XO[2 * bK]),
            fragment: AO(XO[2 * bK + 1])
          }
        }
      }))
    }
  },
  38954: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => VO,
      E: () => oO,
      H: () => FO,
      b: () => bK,
      d: () => XO,
      g: () => aK,
      j: () => DO,
      m: () => LO,
      o: () => eO,
      s: () => vK,
      u: () => CO,
      x: () => lO
    });
    const XO = 3,
      bK = 0,
      eO = 1,
      lO = 2,
      vK = {
        uniform: 3,
        PK: 4,
        special: 5,
        volume: 6,
        sampler: 7,
        entities: 8,
        entityGrids: 9
      },
      CO = 10,
      hO = "BloxdPackInputs",
      DO = "bloxdPackInputs",
      MO = [{
        name: "seconds",
        type: "f32",
        offset: 0
      }, {
        name: "lit",
        type: "u32",
        offset: 4
      }, {
        name: "renderOffset",
        type: "vec3i",
        offset: 16
      }, {
        name: "sunDirection",
        type: "vec3f",
        offset: 32
      }, {
        name: "eyePosition",
        type: "vec3f",
        offset: 48
      }, {
        name: "shadowDirection",
        type: "vec3f",
        offset: 64
      }],
      aK = 80;

    function oO() {
      const OO = MO.map((OO => {
        let {
          name: KO,
          type: pO
        } = OO;
        return `    ${KO}: ${pO},\n`
      })).join("");
      return `struct ${hO} {\n${OO}}\n@group(${XO}) @binding(${bK}) var<uniform> ${DO}: ${hO};\n`
    }

    function FO(OO, KO) {
      const pO = new DataView(OO, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, aK),
        [XO, bK, eO, lO, vK, CO] = MO;
      pO.setFloat32(XO.offset, KO.seconds, !0), pO.setUint32(bK.offset, KO.lit ? 1 : 0, !0);
      for (let hO = 0; hO < 3; hO++) pO.setInt32(eO.offset + 4 * hO, KO.renderOffset[hO], !0), pO.setFloat32(lO.offset + 4 * hO, KO.xvO[hO], !0), pO.setFloat32(vK.offset + 4 * hO, KO.eyePosition[hO], !0), pO.setFloat32(CO.offset + 4 * hO, KO.shadowDirection[hO], !0)
    }

    function VO(OO) {
      const KO = new Uint32Array(Math.max(1, OO.length));
      return OO.forEach(((OO, pO) => {
        let {
          id: XO,
          rotation: bK
        } = OO;
        KO[pO] = 65535 & XO | (3 & bK) << 16
      })), KO
    }
    const LO = {
      off: 0,
      strict: 1,
      allow: 2
    }
  },
  5778: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      g: () => bK,
      k: () => eO
    });
    const XO = ["terrain", "liquid", "model"];

    function bK(OO) {
      return !OO.hooks.vertex && !OO.hooks.surface && !OO.hooks.light
    }

    function eO(OO, KO) {
      return "off" !== KO && (null === OO || OO.some((OO => OO.key.strict === ("strict" === KO) && !bK(OO))))
    }
  },
  38973: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO,
      i: () => eO,
      j: () => CO,
      n: () => lO,
      q: () => bK
    });
    const XO = /^alloc_failed (\d+) bytes$/;

    function bK(OO, KO) {
      return eO(OO, KO) ? `trap=alloc_failed ${KO} bytes` : `trap=${OO}`
    }

    function eO(OO, KO) {
      return "unreachable" === OO && KO > 0
    }

    function lO(OO, KO, pO) {
      const XO = function(OO) {
        return OO instanceof WebAssembly.RuntimeError ? /unreachable/i.test(OO.message) ? "unreachable" : /out of bounds/i.test(OO.message) ? "out_of_bounds" : "runtime_error" : (OO instanceof RangeError || OO instanceof Error && "InternalError" === OO.name) && /call stack|recursion/i.test(OO.message) ? "stack_overflow" : "js_error"
      }(OO);
      if ("unreachable" !== XO) return {
        kind: XO,
        panic: null,
        refusedBytes: 0
      };
      const bK = KO(),
        eO = pO();
      return {
        kind: XO,
        panic: eO > 0 ? null : bK,
        refusedBytes: eO
      }
    }
    const vK = 300;

    function CO(OO) {
      return OO.replace(/\s*\n\s*/g, " / ").slice(0, vK)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);