/*! For license information please see vjxd5n.246.f9fd531e.chunk.js.LICENSE.txt */
export const id = 246;
export const ids = [246];
export const modules = {
  38603: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      FirebaseError: () => XO.e,
      SDK_VERSION: () => XO.g,
      _DEFAULT_ENTRY_NAME: () => XO.h,
      cDO: () => XO.k,
      _addOrOverwriteComponent: () => XO.l,
      _apps: () => XO.m,
      _clearComponents: () => XO.o,
      _components: () => XO.s,
      _getProvider: () => XO.w,
      _registerComponent: () => XO.y,
      _removeServiceInstance: () => XO.C,
      deleteApp: () => XO.G,
      getApp: () => XO.J,
      getApps: () => XO.I,
      initializeApp: () => XO.L,
      onLog: () => XO.M,
      registerVersion: () => XO.P,
      setLogLevel: () => XO.S
    });
    var XO = pO(38610);
    (0, XO.P)("firebase", "9.23.0", "app")
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);