export const id = 344;
export const ids = [344];
export const modules = {
  59286: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      postprocessVertexShaderWGSL: () => lO
    });
    var XO = pO(37907);
    const bK = "postprocessVertexShader",
      eO = "attribute position: vec2<f32>;uniform scale: vec2<f32>;varying vUV: vec2<f32>;const madd=vec2(0.5,0.5);\n#define CUSTOM_VERTEX_DEFINITIONS\n@vertex\nfn main(input : VertexInputs)->FragmentInputs {\n#define CUSTOM_VERTEX_MAIN_BEGIN\nvertexOutputs.vUV=(vertexInputs.position*madd+madd)*uniforms.scale;vertexOutputs.position=vec4(vertexInputs.position,0.0,1.0);\n#define CUSTOM_VERTEX_MAIN_END\n}\n";
    XO.b.ShadersStoreWGSL[bK] || (XO.b.ShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);