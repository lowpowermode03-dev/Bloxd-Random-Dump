export const id = 189;
export const ids = [189];
export const modules = {
  39525: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadGlbAsset: () => QK,
      loadGlbTree: () => LK
    });
    var XO = pO(36274),
      bK = pO(39529),
      eO = pO(34866),
      lO = pO.n(eO);

    function vK() {
      return lO()('(()=>{class OO extends Error{}function KO(KO,pO){const XO=KO._malloc(pO);if(0===XO)throw new OO(`Draco: the decoder\'s heap refused ${pO} bytes`);return XO}function pO(OO){return{[OO.DT_FLOAT32]:[Float32Array,5126],[OO.DT_INT8]:[Int8Array,5120],[OO.DT_INT16]:[Int16Array,5122],[OO.DT_INT32]:[Int32Array,5124],[OO.DT_UINT8]:[Uint8Array,5121],[OO.DT_UINT16]:[Uint16Array,5123],[OO.DT_UINT32]:[Uint32Array,5125]}}function XO(KO,XO,bK,eO,lO){let vK=null,CO=null,hO=null;try{vK=new KO.Decoder,CO=new KO.DecoderBuffer,CO.Init(XO,XO.byteLength);let DO=0;const MO=vK.GetEncodedGeometryType(CO);if(MO===KO.TRIANGULAR_MESH){const pO=new KO.Mesh;hO=pO;const XO=vK.DecodeBufferToMesh(CO,pO);if(!XO.ok()||0===pO.ptr)throw new OO(XO.error_msg());DO=3*pO.num_faces()}else{if(MO!==KO.POINT_CLOUD)throw new OO(`Draco: Cannot decode invalid geometry type ${MO}`);{const pO=new KO.PointCloud;hO=pO;const XO=vK.DecodeBufferToPointCloud(CO,pO);if(!XO.ok()||!pO.ptr)throw new OO(XO.error_msg())}}const aK=hO.num_points();if(aK!==eO.vertices||DO!==eO.indices)throw new OO(`Draco: decoded ${aK} vertices and ${DO} indices, the accessors declare ${eO.vertices} and ${eO.indices}`);const oO=pO(KO),FO=[];for(const{kind:KO,id:pO,components:XO}of bK){const bK=vK.GetAttributeByUniqueId(hO,pO);if(!bK||0===bK.ptr)throw new OO(`Draco: no attribute with id ${pO} (${KO})`);const eO=bK.data_type();if(!oO[eO])throw new OO(`Draco: Cannot decode invalid data type ${eO}`);if(bK.num_components()!==XO)throw new OO(`Draco: ${KO} decodes to ${bK.num_components()} components, its accessor declares ${XO}`);FO.push([KO,bK,eO])}return lO({dracoDecoder:vK,geometry:hO,triangles:MO===KO.TRIANGULAR_MESH,numPoints:aK,numIndices:DO,attributes:FO})}finally{hO&&KO.destroy(hO),CO&&KO.destroy(CO),vK&&KO.destroy(vK)}}const bK=self;let eO=null;self.onmessage=OO=>{let{data:lO}=OO;if("init"===lO.id){try{importScripts(lO.url),eO=DracoDecoderModule({wasmBinary:lO.wasmBinary}),bK.postMessage({id:"initDone"})}catch(MO){bK.postMessage({id:"initError",message:MO instanceof Error?MO.message:String(MO)})}return}const{seq:vK,data:CO,attributeIds:hO,expected:DO}=lO;eO?eO.then((OO=>{try{const eO=function(OO,bK,eO,lO){const vK=Object.keys(eO).map((OO=>({kind:OO,id:eO[OO],components:lO.components[OO]})));return XO(OO,bK,vK,lO,(XO=>{let{dracoDecoder:bK,geometry:eO,triangles:lO,numPoints:vK,numIndices:CO,attributes:hO}=XO;const DO=pO(OO);let MO=null;if(lO){const pO=4*CO,XO=KO(OO,pO);try{bK.GetTrianglesUInt32Array(eO,pO,XO),MO=new Uint32Array(CO),MO.set(new Uint32Array(OO.HEAPF32.buffer,XO,CO))}finally{OO._free(XO)}}const aK=[];for(const[pO,oO,FO]of hO){const[XO]=DO[FO],lO=oO.num_components(),CO=vK*lO,hO=CO*XO.BYTES_PER_ELEMENT,MO=KO(OO,hO);try{bK.GetAttributeDataArrayForAllPoints(eO,oO,FO,hO,MO),aK.push({kind:pO,data:new XO(OO.HEAPF32.buffer,MO,CO).slice(),size:lO,byteOffset:oO.byte_offset(),byteStride:oO.byte_stride(),normalized:oO.normalized()})}finally{OO._free(MO)}}return{indices:MO,attributes:aK,totalVertices:vK}}))}(OO,CO,hO,DO),lO=eO.attributes.map((OO=>OO.data.buffer));eO.indices&&lO.push(eO.indices.buffer),bK.postMessage({id:"decoded",seq:vK,...eO},lO)}catch(MO){bK.postMessage({id:"decodeError",seq:vK,message:MO instanceof Error?MO.message:String(MO)})}}),(OO=>{bK.postMessage({id:"decodeError",seq:vK,message:OO instanceof Error?OO.message:String(OO)})})):bK.postMessage({id:"decodeError",seq:vK,message:"Draco: the decoder module is not loaded"})}})();', "Worker", void 0, pO.p + "dracoDecode.worker.dc41fb58.worker.js")
    }
    const CO = 1e3;
    let hO = null,
      DO = null;
    const MO = [],
      aK = [];
    let oO = 0;
    const FO = {
      decodes: 0,
      workersStarted: 0,
      mostWorkers: 0
    };

    function VO() {
      if (!hO) return Promise.reject(new Error("Draco: configureDracoPool was not called"));
      const {
        scriptUrl: OO,
        wasmBinaryUrl: KO
      } = hO;
      return DO ??= fetch(KO).then((OO => {
        if (!OO.ok) throw new Error(`Draco: fetching ${KO} failed: ${OO.status}`);
        return OO.arrayBuffer()
      })), DO.catch((() => {
        DO = null
      })), FO.workersStarted++, DO.then((KO => new Promise(((pO, XO) => {
        const bK = new vK;
        bK.onerror = OO => {
          bK.onmessage = null, bK.onerror = null, bK.terminate(), XO(new Error("Draco: the decode worker failed to start" + (OO.message ? `: ${OO.message}` : " (its script did not load)")))
        }, bK.onmessage = OO => {
          let {
            data: KO
          } = OO;
          bK.onmessage = null, bK.onerror = null, "initDone" === KO.id ? pO(bK) : (bK.terminate(), XO(new Error(`Draco: ${"initError"===KO.id?KO.message:"the worker did not start"}`)))
        };
        const eO = KO.slice(0),
          lO = {
            id: "init",
            url: OO,
            wasmBinary: eO
          };
        bK.postMessage(lO, [eO])
      }))))
    }

    function LO(OO) {
      const KO = MO.indexOf(OO); - 1 !== KO && MO.splice(KO, 1);
      const pO = aK.shift();
      pO && zK(pO)
    }

    function QO(OO, KO) {
      OO.busy = !0, OO.releaseTimer && (clearTimeout(OO.releaseTimer), OO.releaseTimer = null);
      OO.worker.then((pO => {
        const XO = oO++;
        pO.onmessage = bK => {
          let {
            data: eO
          } = bK;
          if (("decoded" === eO.id || "decodeError" === eO.id) && eO.seq === XO) {
            if (pO.onmessage = null, pO.onerror = null, "decoded" === eO.id) return FO.decodes++, KO.resolve({
              indices: eO.indices,
              attributes: eO.attributes,
              totalVertices: eO.totalVertices
            }), void(() => {
              const KO = aK.shift();
              KO ? QO(OO, KO) : (OO.busy = !1, OO.releaseTimer = setTimeout((() => {
                const KO = MO.indexOf(OO); - 1 !== KO && MO.splice(KO, 1), OO.worker.then((OO => {
                  OO.terminate()
                }))
              }), CO))
            })();
            pO.terminate(), KO.reject(new Error(eO.message)), LO(OO)
          }
        }, pO.onerror = XO => {
          pO.onmessage = null, pO.onerror = null, pO.terminate(), KO.reject(new Error(`Draco: the decode worker failed: ${XO.message}`)), LO(OO)
        };
        const bK = {
          id: "decode",
          seq: XO,
          data: KO.data,
          attributeIds: KO.attributeIds,
          expected: KO.expected
        };
        pO.postMessage(bK, [KO.data.buffer])
      }), (pO => {
        KO.reject(pO instanceof Error ? pO : new Error(String(pO))), LO(OO)
      }))
    }

    function zK(OO) {
      const KO = MO.find((OO => !OO.busy));
      if (KO) QO(KO, OO);
      else {
        if (MO.length < function() {
            const OO = "object" === typeof navigator ? navigator.hardwareConcurrency : 0;
            return OO ? Math.max(1, Math.min(Math.floor(.5 * OO), 4)) : 1
          }()) {
          const KO = {
            worker: VO(),
            busy: !0,
            releaseTimer: null
          };
          return MO.push(KO), FO.mostWorkers = Math.max(FO.mostWorkers, MO.length), void QO(KO, OO)
        }
        aK.push(OO)
      }
    }

    function AO(OO, KO, pO) {
      return new Promise(((XO, bK) => {
        zK({
          data: new Int8Array(OO.buffer, OO.byteOffset, OO.byteLength).slice(),
          attributeIds: KO,
          expected: pO,
          resolve: XO,
          reject: bK
        })
      }))
    }
    var fO = pO(35796),
      dO = pO(35807),
      TO = pO(33003),
      NO = pO(33001);
    const IO = {
      index: -1,
      magFilter: void 0,
      minFilter: void 0,
      wrapS: void 0,
      wrapT: void 0
    };

    function yK(OO) {
      const KO = (0, NO.i)(OO.byteLength);
      if (KO) throw new TO.l(KO);
      const {
        json: pO,
        bin: XO
      } = (0, TO.z)(OO), bK = (0, NO.e)(pO, XO);
      if (bK) throw new TO.l(bK);
      try {
        return function(OO, KO) {
          var pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO;
          const QO = new Map,
            zK = pO => {
              let XO = QO.get(pO);
              if (!XO) {
                var bK;
                const eO = OO.bufferViews[pO],
                  lO = null !== (bK = eO.byteOffset) && void 0 !== bK ? bK : 0;
                XO = {
                  index: pO,
                  bytes: KO.subarray(lO, lO + eO.byteLength),
                  byteStride: eO.byteStride
                }, QO.set(pO, XO)
              }
              return XO
            },
            AO = new Map,
            fO = KO => {
              let pO = AO.get(KO);
              if (!pO) {
                var XO;
                const bK = OO.accessors[KO];
                pO = {
                  index: KO,
                  count: bK.count,
                  type: bK.type,
                  numComponents: TO.n[bK.type],
                  componentType: bK.componentType,
                  normalized: null !== (XO = bK.normalized) && void 0 !== XO && XO,
                  byteOffset: bK.byteOffset,
                  bufferView: void 0 === bK.bufferView ? null : zK(bK.bufferView),
                  min: bK.min,
                  max: bK.max
                }, AO.set(KO, pO)
              }
              return pO
            },
            dO = null !== (pO = null === (XO = OO.extensionsUsed) || void 0 === XO ? void 0 : XO.includes("KHR_draco_mesh_compression")) && void 0 !== pO && pO,
            NO = (null !== (bK = OO.meshes) && void 0 !== bK ? bK : []).map(((KO, pO) => {
              const XO = KO.primitives.map(((KO, pO) => {
                var XO, bK, eO;
                const lO = dO ? null === (XO = KO.extensions) || void 0 === XO ? void 0 : XO.KHR_draco_mesh_compression : void 0;
                let vK = null;
                const CO = [];
                if (lO) {
                  const pO = {
                    vertices: OO.accessors[KO.attributes.POSITION].count,
                    indices: void 0 === KO.indices ? 0 : OO.accessors[KO.indices].count,
                    components: {}
                  };
                  vK = {
                    bufferView: zK(lO.bufferView),
                    attributeIds: {},
                    normalized: {},
                    expected: pO
                  };
                  for (const [XO, bK] of TO.g) {
                    const eO = lO.attributes[XO];
                    if (void 0 === eO) continue;
                    vK.attributeIds[bK] = eO;
                    const CO = KO.attributes[XO];
                    var hO;
                    if (void 0 !== CO) vK.normalized[bK] = null !== (hO = OO.accessors[CO].normalized) && void 0 !== hO && hO, pO.components[bK] = TO.n[OO.accessors[CO].type]
                  }
                } else
                  for (const [OO, DO] of TO.g) {
                    const pO = KO.attributes[OO];
                    void 0 !== pO && CO.push({
                      semantic: OO,
                      kind: DO,
                      accessor: fO(pO)
                    })
                  }
                return {
                  index: pO,
                  mode: null !== (bK = KO.mode) && void 0 !== bK ? bK : 4,
                  attributes: CO,
                  indices: lO || void 0 === KO.indices ? null : fO(KO.indices),
                  position: void 0 === KO.attributes.POSITION ? null : fO(KO.attributes.POSITION),
                  material: null !== (eO = KO.material) && void 0 !== eO ? eO : null,
                  draco: vK
                }
              }));
              return {
                index: pO,
                name: KO.name,
                primitives: XO,
                extras: KO.extras
              }
            })),
            yK = (null !== (eO = OO.nodes) && void 0 !== eO ? eO : []).map(((OO, KO) => {
              var pO, XO;
              return {
                index: KO,
                name: OO.name,
                children: null !== (pO = OO.children) && void 0 !== pO ? pO : [],
                mesh: null !== (XO = OO.mesh) && void 0 !== XO ? XO : null,
                translation: OO.translation,
                rotation: OO.rotation,
                scale: OO.scale,
                hasCamera: void 0 !== OO.camera,
                extras: OO.extras
              }
            })),
            gK = null !== (lO = null === (vK = OO.extensionsUsed) || void 0 === vK ? void 0 : vK.includes("KHR_materials_unlit")) && void 0 !== lO && lO,
            uO = null !== (CO = null === (hO = OO.extensionsUsed) || void 0 === hO ? void 0 : hO.includes("KHR_texture_transform")) && void 0 !== CO && CO,
            EO = (null !== (DO = OO.materials) && void 0 !== DO ? DO : []).map(((OO, KO) => {
              var pO, XO, bK, eO;
              const lO = OO.pbrMetallicRoughness,
                vK = null === lO || void 0 === lO ? void 0 : lO.baseColorTexture;
              return {
                index: KO,
                name: OO.name,
                extras: OO.extras,
                unlit: gK && void 0 !== (null === (pO = OO.extensions) || void 0 === pO ? void 0 : pO.KHR_materials_unlit),
                pbr: lO ? {
                  baseColorFactor: lO.baseColorFactor,
                  metallicFactor: lO.metallicFactor,
                  roughnessFactor: lO.roughnessFactor
                } : null,
                baseColorTexture: vK ? {
                  texture: vK.index,
                  transform: uO && (null === (XO = vK.extensions) || void 0 === XO ? void 0 : XO.KHR_texture_transform) || null
                } : null,
                emissiveFactor: OO.emissiveFactor,
                alphaMode: null !== (bK = OO.alphaMode) && void 0 !== bK ? bK : "OPAQUE",
                alphaCutoff: OO.alphaCutoff,
                doubleSided: null !== (eO = OO.doubleSided) && void 0 !== eO && eO
              }
            })),
            jK = (null !== (MO = OO.textures) && void 0 !== MO ? MO : []).map(((KO, pO) => {
              var XO, bK;
              const eO = void 0 === KO.sampler ? IO : {
                index: KO.sampler,
                ...null === (XO = OO.samplers) || void 0 === XO ? void 0 : XO[KO.sampler]
              };
              return {
                index: pO,
                sampler: {
                  index: eO.index,
                  magFilter: eO.magFilter,
                  minFilter: eO.minFilter,
                  wrapS: eO.wrapS,
                  wrapT: eO.wrapT
                },
                image: null !== (bK = KO.source) && void 0 !== bK ? bK : -1
              }
            })),
            YO = (null !== (aK = OO.images) && void 0 !== aK ? aK : []).map(((OO, KO) => ({
              index: KO,
              name: OO.name,
              mimeType: OO.mimeType,
              bufferView: zK(OO.bufferView)
            }))),
            wO = null !== (oO = (0, TO.v)(OO)) && void 0 !== oO ? oO : 0;
          return {
            json: OO,
            rootNodes: null !== (FO = null === (VO = OO.scenes) || void 0 === VO || null === (LO = VO[wO]) || void 0 === LO ? void 0 : LO.nodes) && void 0 !== FO ? FO : [],
            nodes: yK,
            meshes: NO,
            materials: EO,
            textures: jK,
            images: YO
          }
        }(pO, XO)
      } catch (eO) {
        throw eO instanceof TO.i ? eO : new TO.i(`reading the GLB failed: ${eO instanceof Error?eO.message:String(eO)}`)
      }
    }
    async function gK(OO, KO) {
      var pO, XO;
      const bK = OO.draco;
      if (!bK) throw new TO.i("not a Draco primitive");
      let eO;
      try {
        eO = await KO(bK.bufferView.bytes, bK.attributeIds, bK.expected)
      } catch (hO) {
        throw new TO.i(`Draco decoding failed: ${hO instanceof Error?hO.message:String(hO)}`)
      }
      const {
        vertices: lO,
        indices: vK,
        components: CO
      } = bK.expected;
      if (eO.totalVertices !== lO || (null !== (pO = null === (XO = eO.indices) || void 0 === XO ? void 0 : XO.length) && void 0 !== pO ? pO : 0) !== vK || eO.attributes.some((OO => OO.size !== CO[OO.kind] || OO.data.length !== lO * OO.size))) throw new TO.i("Draco decoding gave other counts than the accessors declare");
      for (const DO of eO.attributes) {
        const OO = bK.normalized[DO.kind];
        void 0 !== OO && (DO.normalized = OO)
      }
      return eO
    }
    const uO = new WeakMap;

    function EO(OO, KO) {
      var pO;
      const XO = null !== (pO = uO.get(OO)) && void 0 !== pO ? pO : KO(OO);
      return uO.set(OO, XO), XO
    }

    function jK(OO) {
      const KO = OO.bufferView,
        pO = 5125 === OO.componentType ? Uint32Array : Uint16Array,
        XO = KO.bytes.buffer,
        bK = KO.bytes.byteOffset + (OO.byteOffset || 0);
      return bK % pO.BYTES_PER_ELEMENT !== 0 ? new pO(XO.slice(bK, bK + OO.count * pO.BYTES_PER_ELEMENT), 0) : new pO(XO, bK, OO.count)
    }

    function YO(OO, KO) {
      if (OO.min && OO.max) return [new Float64Array(OO.min), new Float64Array(OO.max)];
      const pO = KO.find((OO => {
          let {
            kind: KO
          } = OO;
          return "position" === KO
        })),
        XO = pO ? (0, dO.i)(pO, OO.count) : new Float32Array(0);
      return (0, dO.p)(XO.length / 3, ((OO, KO) => XO[3 * OO + KO]))
    }

    function wO(OO) {
      const KO = OO.attributes.map((OO => {
          var KO, pO;
          let {
            kind: XO,
            accessor: bK
          } = OO;
          const {
            bufferView: eO,
            numComponents: lO
          } = bK;
          if (!eO) {
            return {
              kind: XO,
              data: EO(bK, (() => new Float32Array(lO * bK.count))),
              offset: 0,
              stride: 4 * lO,
              components: lO,
              glType: 5126,
              isNormalized: !1
            }
          }
          const vK = null !== (KO = eO.byteStride) && void 0 !== KO ? KO : lO * TO.b[bK.componentType];
          return {
            kind: XO,
            data: eO.bytes,
            offset: null !== (pO = bK.byteOffset) && void 0 !== pO ? pO : 0,
            stride: vK,
            components: lO,
            glType: bK.componentType,
            isNormalized: bK.normalized
          }
        })),
        pO = OO.indices,
        XO = pO && EO(pO, jK),
        bK = OO.position;
      return new dO.h(KO, XO, bK.count, ...YO(bK, KO))
    }
    const iK = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array];

    function rK(OO, KO) {
      const pO = KO.attributes.map((OO => {
        let {
          kind: KO,
          data: pO,
          size: XO,
          byteOffset: bK,
          byteStride: eO,
          normalized: lO
        } = OO;
        return {
          kind: KO,
          data: pO,
          offset: bK,
          stride: eO,
          components: XO,
          glType: 5120 + iK.indexOf(pO.constructor),
          isNormalized: lO
        }
      }));
      return new dO.h(pO, KO.indices, KO.totalVertices, ...YO(OO.position, pO))
    }

    function PO(OO) {
      const KO = OO.lastIndexOf("/");
      return KO < 0 ? OO : OO.substring(KO + 1)
    }

    function mK(OO) {
      const KO = OO.lastIndexOf("/");
      return KO < 0 ? "" : OO.substring(0, KO + 1)
    }

    function sO(OO) {
      return OO.name || `node${OO.index}`
    }
    const HO = {
        rotation: [0, 1, 0, 0],
        scale: [1, 1, -1]
      },
      RO = {
        9728: 12,
        9729: 2,
        9984: 9,
        9985: 11,
        9986: 10
      },
      SO = {
        9728: 1,
        9729: 7,
        9984: 4,
        9985: 5,
        9986: 8,
        9987: 6
      };

    function JO(OO) {
      var KO, pO, XO, bK;
      const eO = null !== (KO = OO.minFilter) && void 0 !== KO ? KO : 9987;
      return 9729 === (null !== (pO = OO.magFilter) && void 0 !== pO ? pO : 9729) ? null !== (XO = RO[eO]) && void 0 !== XO ? XO : 3 : null !== (bK = SO[eO]) && void 0 !== bK ? bK : 4
    }
    const cK = {
      33071: 0,
      33648: 2
    };

    function BO(OO) {
      var KO;
      return null !== (KO = cK[null !== OO && void 0 !== OO ? OO : 10497]) && void 0 !== KO ? KO : 1
    }

    function ZO(OO) {
      return 9728 === OO.minFilter || 9729 === OO.minFilter
    }

    function GO(OO) {
      var KO, pO, XO;
      const bK = Float64Array.from(null !== (KO = OO.scale) && void 0 !== KO ? KO : [1, 1, 1]);
      return OO.hasCamera && (bK[0] = -1), {
        translation: Float64Array.from(null !== (pO = OO.translation) && void 0 !== pO ? pO : [0, 0, 0]),
        rotation: Float64Array.from(null !== (XO = OO.rotation) && void 0 !== XO ? XO : [0, 0, 0, 1]),
        scale: bK
      }
    }

    function qK(OO, KO) {
      let {
        translation: pO,
        rotation: XO,
        scale: bK
      } = OO;
      const eO = new Float32Array(16);
      return (0, fO.d)(bK, 0, XO, 0, pO, 0, eO), KO && (0, fO.o)(eO, KO, 0, eO), eO
    }
    class xK {
      constructor(OO, KO, pO, XO) {
        this.model = OO, this.decode = KO, this.fileInfo = pO, this.uniqueRootUrl = XO, this.primitives = void 0, this.parents = new Map, this.uses = new Map, this.own = new Map;
        const bK = new Set,
          eO = (KO, pO) => {
            const XO = OO.nodes[KO];
            if (this.parents.has(XO)) throw new TO.i(`/nodes/${KO}: Invalid recursive node hierarchy`);
            this.parents.set(XO, pO);
            const lO = null === XO.mesh ? [] : OO.meshes[XO.mesh].primitives,
              vK = lO.map((OO => {
                const KO = lO.length > 1;
                return {
                  name: KO ? `${sO(XO)}_primitive${OO.index}` : sO(XO),
                  node: XO,
                  primitive: OO,
                  part: KO,
                  geometry: null
                }
              }));
            this.uses.set(XO, vK);
            const CO = null !== XO.mesh && bK.has(XO.mesh);
            bK.add(XO.mesh), this.own.set(XO, CO ? [] : vK);
            for (const OO of XO.children) eO(OO, XO)
          };
        for (const lO of OO.rootNodes) eO(lO, null);
        this.primitives = OO.nodes.flatMap((OO => {
          var KO;
          return null !== (KO = this.own.get(OO)) && void 0 !== KO ? KO : []
        }))
      }
      decodeGeometries() {
        const OO = new Map;
        return Promise.all(this.primitives.map((async KO => {
          const {
            primitive: pO
          } = KO, XO = pO.draco;
          let bK = XO ? OO.get(XO.bufferView.index) : Promise.resolve(wO(pO));
          bK || (bK = gK(pO, this.decode).then((OO => rK(pO, OO))), OO.set(XO.bufferView.index, bK)), KO.geometry = await bK
        })))
      }
      parentOf(OO) {
        var KO;
        return null !== (KO = this.parents.get(OO)) && void 0 !== KO ? KO : null
      }
      meshesUnder(OO) {
        const KO = this.model.nodes.filter((OO => this.uses.has(OO)));
        for (const XO of KO) {
          const KO = this.uses.get(XO),
            pO = KO.find((KO => KO.name === OO));
          if (pO) return 1 === KO.length ? this.subtree(XO) : this.own.get(XO).includes(pO) ? [pO] : []
        }
        const pO = KO.find((KO => 1 !== this.uses.get(KO).length && sO(KO) === OO));
        return pO ? this.subtree(pO) : null
      }
      subtree(OO) {
        return [...this.own.get(OO), ...OO.children.flatMap((OO => this.subtree(this.model.nodes[OO])))]
      }
      worldMatrix(OO, KO, pO) {
        let XO = qK(GO(KO ? HO : {}), null);
        const bK = [];
        for (let lO = OO.part ? OO.node : this.parentOf(OO.node); lO; lO = this.parentOf(lO)) bK.unshift(lO);
        for (const lO of bK) XO = qK(GO(lO), XO);
        const eO = GO(OO.part ? {} : OO.node);
        return void 0 !== pO && eO.scale.fill(pO), qK(eO, XO)
      }
      floats(OO) {
        const {
          vertexAttributes: KO,
          vertexCount: pO
        } = OO.geometry;
        return new Map(KO.map((OO => [OO.kind, (0, dO.i)(OO, pO)])))
      }
      imageUrl(OO) {
        return function(OO, KO, pO) {
          let {
            name: XO
          } = KO;
          return `data:${OO}${XO}#image${pO}`
        }(this.uniqueRootUrl, this.fileInfo, OO)
      }
      textureDesc(OO, KO) {
        var pO;
        let {
          texture: XO,
          transform: bK
        } = OO;
        const {
          sampler: eO,
          image: lO
        } = this.model.textures[XO], {
          bufferView: vK,
          mimeType: CO,
          name: hO
        } = this.model.images[lO], DO = bK && {
          ...bK.offset ? {
            uOffset: bK.offset[0],
            vOffset: bK.offset[1]
          } : {},
          uRotationCenter: 0,
          vRotationCenter: 0,
          ...bK.rotation ? {
            wAng: -bK.rotation
          } : {},
          ...bK.scale ? {
            uScale: bK.scale[0],
            vScale: bK.scale[1]
          } : {}
        };
        return {
          url: this.imageUrl(lO),
          noMipmap: ZO(eO),
          invertY: !1,
          samplingMode: JO(eO),
          data: {
            bytes: vK.bytes,
            mimeType: CO,
            label: hO,
            context: `/textures/${XO}`
          },
          sets: {
            wrapU: BO(eO.wrapS),
            wrapV: BO(eO.wrapT),
            ...DO,
            coordinatesIndex: null !== (pO = null === bK || void 0 === bK ? void 0 : bK.texCoord) && void 0 !== pO ? pO : 0,
            hasAlpha: KO
          }
        }
      }
    }
    async function nO(OO, KO, pO, XO, bK, eO) {
      let lO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6];
      const vK = function(OO, KO, pO) {
          return "string" !== typeof KO ? {
            url: "",
            rootUrl: OO,
            name: pO()
          } : KO ? KO.startsWith("data:") ? {
            url: KO,
            rootUrl: OO,
            name: ""
          } : OO ? {
            url: OO + KO,
            rootUrl: OO,
            name: KO
          } : {
            url: KO,
            rootUrl: mK(KO),
            name: PO(KO)
          } : {
            url: OO,
            rootUrl: mK(OO),
            name: PO(OO)
          }
        }(pO, OO, bK),
        CO = {};
      KO.addPendingData(CO);
      try {
        const pO = yK(await async function(OO, KO) {
            return "string" !== typeof KO ? KO : OO.url.startsWith("data:") ? (0, TO.p)(OO.url) : await (0, TO.t)(OO.url)
          }(vK, OO)),
          CO = new xK(pO, XO, vK, function(OO, KO) {
            let {
              rootUrl: pO,
              name: XO
            } = OO;
            return !pO.startsWith("file:") && XO ? pO : `${pO}${KO()}/`
          }(vK, bK));
        return await eO(CO), KO.importedMeshesFiles && (KO.loadingPluginName = "UhO", lO && KO.importedMeshesFiles.push(vK.url)), CO
      } finally {
        KO.removePendingData(CO)
      }
    }
    var WO = pO(35919),
      tK = pO(35776),
      kK = pO(36257);

    function UO(OO) {
      if (null === OO || void 0 === OO || !OO.min || !OO.max) return null;
      const [KO, pO, XO] = OO.min, [bK, eO, lO] = OO.max, {
        BoundingInfo: vK,
        WX: CO
      } = (0, WO.d)();
      return new vK(new CO(KO, pO, XO), new CO(bK, eO, lO))
    }

    function OK(OO) {
      (0, tK.f)(OO) || (OO.geometry && OO.geometry.useBoundingInfoFromGeometry ? OO._updateBoundingInfo() : OO.refreshBoundingInfo(!0, !0))
    }
    class KK {
      constructor(OO, KO) {
        this.Ce = OO, this.decode = KO, this.bufferData = Promise.resolve(), this.viewData = new Map, this.viewBuffers = new Map, this.vertexBuffers = new Map, this.dracoGeometry = new Map
      }
      viewBytes(OO) {
        let KO = this.viewData.get(OO.index);
        return KO || (KO = this.bufferData.then((() => OO.bytes)), this.viewData.set(OO.index, KO)), KO
      }
      viewBuffer(OO) {
        let KO = this.viewBuffers.get(OO.index);
        return KO || (KO = this.viewBytes(OO).then((OO => new((0, WO.d)().jb)(this.Ce.qb(), OO, !1))), this.viewBuffers.set(OO.index, KO)), KO
      }
      vertexBuffer(OO, KO) {
        const {
          kind: pO,
          data: XO
        } = KO, bK = `${OO.index}:${pO}`;
        let eO = this.vertexBuffers.get(bK);
        if (!eO) {
          const lO = OO.bufferView;
          eO = lO ? this.viewBuffer(lO).then((OO => this.layoutVertexBuffer(OO, KO))) : Promise.resolve(XO).then((OO => new((0, WO.d)().VertexBuffer)(this.Ce.qb(), OO, pO, !1))), this.vertexBuffers.set(bK, eO)
        }
        return eO
      }
      layoutVertexBuffer(OO, KO) {
        let {
          kind: pO,
          offset: XO,
          stride: bK,
          components: eO,
          glType: lO,
          isNormalized: vK
        } = KO;
        const CO = this.Ce.qb();
        return new((0, WO.d)().VertexBuffer)(CO, OO, pO, !1, void 0, bK, void 0, XO, eO, lO, vK, !0, void 0, !0)
      }
      load(OO, KO, pO) {
        const XO = (0, tK.f)(pO),
          bK = OO => {
            XO || (pO._delayInfo = pO._delayInfo || [], -1 === pO._delayInfo.indexOf(OO) && pO._delayInfo.push(OO))
          },
          eO = KO.draco;
        if (eO) {
          for (const OO in eO.attributeIds) bK(OO);
          let lO = this.dracoGeometry.get(eO.bufferView.index);
          return lO || (lO = this.viewBytes(eO.bufferView).then((async () => {
            let bK;
            try {
              bK = await gK(KO, this.decode)
            } catch (CO) {
              throw new TO.i(`${OO}: ${CO instanceof Error?CO.message:String(CO)}`)
            }
            const eO = rK(KO, bK);
            if (XO) return eO;
            const lO = UO(KO.position),
              vK = new((0, WO.d)().MirroredGeometry)(pO.name, this.Ce);
            lO && (vK._boundingInfo = lO, vK.useBoundingInfoFromGeometry = !0), eO.indexData && vK.setIndices(eO.indexData);
            for (const OO of eO.vertexAttributes) vK.setVerticesBuffer(this.layoutVertexBuffer(OO.data, OO), eO.vertexCount);
            return vK.link(eO), vK
          })), this.dracoGeometry.set(eO.bufferView.index, lO)), lO
        }
        const lO = [],
          vK = wO(KO);
        if (XO) return pO.isUnIndexed = !vK.indexData, pO.hasVertexAlpha = (0, kK.g)(KO), Promise.resolve(vK);
        const CO = new((0, WO.d)().MirroredGeometry)(pO.name, this.Ce),
          {
            indexData: hO
          } = vK;
        hO ? lO.push(this.viewBytes(KO.indices.bufferView).then((() => {
          CO.setIndices(hO)
        }))) : pO.isUnIndexed = !0;
        for (const [DO, {
            kind: MO,
            accessor: aK
          }] of KO.attributes.entries()) bK(MO), lO.push(this.vertexBuffer(aK, vK.vertexAttributes[DO]).then((OO => {
          if ("position" === OO.getKind()) {
            const OO = UO(aK);
            OO && (CO._boundingInfo = OO, CO.useBoundingInfoFromGeometry = !0)
          }
          CO.setVerticesBuffer(OO, vK.vertexCount)
        })));
        return (0, kK.g)(KO) && (pO.hasVertexAlpha = !0), Promise.all(lO).then((() => (CO.link(vK), CO)))
      }
    }
    var pK, XK = pO(35728),
      bp = pO(35624),
      eK = pO(36267),
      lK = pO(35678),
      vp = pO(35711),
      CK = pO(2231),
      hK = pO(35700);

    function DK(OO, KO) {
      OO.metadata = OO.metadata || {};
      const pO = OO._internalMetadata = OO._internalMetadata || {},
        XO = pO.UhO = pO.UhO || {};
      (XO.pointers = XO.pointers || []).push(KO)
    }

    function MK(OO, KO) {
      if (KO && Object.keys(KO).length > 0) {
        const pO = OO.metadata = OO.metadata || {};
        (pO.UhO = pO.UhO || {}).extras = KO
      }
    }

    function ap(OO, KO) {
      KO.position = OO.translation ? bp.WX.FromArray(OO.translation) : bp.WX.Zero(), KO.rotationQuaternion = OO.rotation ? bp.Quaternion.FromArray(OO.rotation) : bp.Quaternion.Identity(), KO.ol = OO.scale ? bp.WX.FromArray(OO.scale) : bp.WX.One()
    }
    class oK {
      constructor(OO, KO) {
        if (this.Ce = OO, this.meshes = [], this.transformNodes = [], this.geometries = [], this.materials = [], this.textures = [], this.rootNodes = [], this.release = null, KO) {
          const KO = OO.qb(),
            pO = OO.cpO.add((() => {
              this.dispose()
            })),
            XO = KO.onContextRestoredObservable.add((() => {
              for (const OO of [...this.geometries, ...this.meshes, ...this.textures]) OO._rebuild()
            }));
          this.release = () => {
            OO.cpO.remove(pO), KO.onContextRestoredObservable.remove(XO)
          }
        }
      }
      getNodes() {
        return [...this.meshes, ...this.transformNodes]
      }
      addAllToScene() {
        if (this.release) {
          this.release(), this.release = null;
          for (const OO of this.meshes) this.Ce.GhO(OO);
          for (const OO of this.materials) this.Ce.addMaterial(OO);
          for (const OO of this.geometries) this.Ce.addGeometry(OO);
          for (const OO of this.transformNodes) this.Ce.addTransformNode(OO);
          for (const OO of this.textures) this.Ce.addTexture(OO)
        }
      }
      dispose() {
        var OO;
        for (const KO of [this.meshes, this.materials, this.geometries, this.transformNodes, this.textures]) {
          for (const OO of KO.slice()) OO.dispose();
          KO.length = 0
        }
        null === (OO = this.release) || void 0 === OO || OO.call(this), this.release = null
      }
    }
    class FK {
      constructor(OO, KO, pO, XO, bK, eO, lO) {
        this.asset = OO, this.Ce = KO, this.tree = pO, this.geometryData = bK, this.materials = eO, this.lite = lO, this.container = void 0, this.root = null, this.nodeObjects = new Map, this.nodePrimitives = new Map, this.materialData = new Map, this.container = XO ? pO : null
      }
      create(OO) {
        if (this.lite) return OO();
        const KO = this.Ce;
        KO._blockEntityCollection = !!this.container;
        try {
          const KO = OO();
          return this.container && (KO._parentContainer = this.container), KO
        } finally {
          KO._blockEntityCollection = !1
        }
      }
      node(OO, KO) {
        return this.create((() => this.lite ? KO ? (0, eK.d)(this.lite, OO) : (0, eK.s)(this.lite, OO) : KO ? new((0, WO.d)().Mesh)(OO, this.Ce) : new((0, WO.d)().TransformNode)(OO, this.Ce)))
      }
      async load() {
        var OO;
        this.asset.model.json.nodes && this.createRoot();
        const KO = this.lite ? null : this.Ce,
          pO = null !== (OO = null === KO || void 0 === KO ? void 0 : KO.blockMaterialDirtyMechanism) && void 0 !== OO && OO;
        let XO;
        KO && (KO.blockMaterialDirtyMechanism = !0);
        try {
          XO = this.loadScene()
        } finally {
          null === KO || void 0 === KO || KO._forceBlockMaterialDirtyMechanism(pO)
        }
        await XO;
        const {
          root: bK,
          tree: eO
        } = this;
        bK && (bK.WE(!0), eO.meshes.push(bK), eO.rootNodes.push(bK));
        for (const vK of this.asset.model.nodes) {
          const OO = this.nodeObjects.get(vK.index);
          OO && ["TransformNode", "LiteNode"].includes(OO.getClassName()) && eO.transformNodes.push(OO);
          for (const KO of null !== (lO = this.nodePrimitives.get(vK.index)) && void 0 !== lO ? lO : []) {
            var lO;
            eO.meshes.push(KO);
            const OO = KO.geometry;
            OO && !eO.geometries.includes(OO) && eO.geometries.push(OO)
          }
        }
      }
      createRoot() {
        const OO = this.node("__root__", !0);
        this.root = OO, OO.WE(!1), this.Ce.useRightHandedSystem || ap(HO, OO)
      }
      loadScene() {
        const OO = [];
        for (const KO of this.asset.model.rootNodes) OO.push(this.loadNode(this.asset.model.nodes[KO], (OO => {
          OO.parent = this.root
        })));
        return OO.push(Promise.resolve()), Promise.all(OO).then((() => {}))
      }
      loadNode(OO, KO) {
        const pO = `/nodes/${OO.index}`,
          XO = [],
          bK = bK => {
            if (DK(bK, pO), ap(OO, bK), OO.hasCamera && !this.Ce.useRightHandedSystem) {
              const {
                ol: OO
              } = bK;
              OO.set(-1, OO.y, OO.z)
            }
            for (const KO of OO.children) XO.push(this.loadNode(this.asset.model.nodes[KO], (OO => {
              OO.parent = bK
            })));
            (pO => {
              MK(pO, OO.extras), KO(pO)
            })(bK)
          };
        if (null === OO.mesh) {
          const KO = this.node(sO(OO), !1);
          this.nodeObjects.set(OO.index, KO), bK(KO)
        } else {
          const KO = this.asset.model.meshes[OO.mesh];
          XO.push(this.loadMesh(`/meshes/${KO.index}`, OO, KO, bK))
        }
        return Promise.all(XO).then((() => {
          for (const pO of null !== (KO = this.nodePrimitives.get(OO.index)) && void 0 !== KO ? KO : []) {
            var KO;
            OK(pO)
          }
          return this.nodeObjects.get(OO.index)
        }))
      }
      loadMesh(OO, KO, pO, XO) {
        const bK = [],
          eO = sO(KO);
        if (1 === pO.primitives.length) {
          const XO = pO.primitives[0];
          bK.push(this.loadPrimitive(`${OO}/primitives/${XO.index}`, eO, XO, (OO => {
            this.nodeObjects.set(KO.index, OO), this.nodePrimitives.set(KO.index, [OO])
          })))
        } else {
          const XO = this.node(eO, !1);
          this.nodeObjects.set(KO.index, XO);
          const lO = [];
          this.nodePrimitives.set(KO.index, lO);
          for (const KO of pO.primitives) bK.push(this.loadPrimitive(`${OO}/primitives/${KO.index}`, `${eO}_primitive${KO.index}`, KO, (OO => {
            OO.parent = XO, lO.push(OO)
          })))
        }
        const lO = this.nodeObjects.get(KO.index);
        return XO(lO), Promise.all(bK).then((() => lO))
      }
      loadPrimitive(OO, KO, pO, XO) {
        const bK = [],
          eO = this.node(KO, !0);
        if (eO.sideOrientation = this.Ce.useRightHandedSystem ? lK.e.CounterClockWiseSideOrientation : lK.e.ClockWiseSideOrientation, bK.push(this.geometryData.load(OO, pO, eO).then((OO => {
            if ((0, tK.f)(eO)) {
              var KO, pO;
              const XO = OO;
              eO.replaceModel(XO, Int32Array.of(0, null !== (KO = null === (pO = XO.indexData) || void 0 === pO ? void 0 : pO.length) && void 0 !== KO ? KO : XO.vertexCount, 0, XO.vertexCount))
            } else this.create((() => (OO.applyToMesh(eO), OO)))
          }))), this.materials) {
          const OO = 0 === pO.mode ? lK.e.PointListDrawMode : lK.e.TriangleFillMode,
            KO = null === pO.material ? null : this.asset.model.materials[pO.material];
          bK.push(this.loadMaterial(KO, OO, (OO => {
            eO.material = OO
          })))
        }
        return DK(eO, OO), XO(eO), Promise.all(bK).then((() => eO))
      }
      loadMaterial(OO, KO, pO) {
        var XO;
        const bK = `${null!==(XO=null===OO||void 0===OO?void 0:OO.index)&&void 0!==XO?XO:"default"}:${KO}`;
        let eO = this.materialData.get(bK);
        return eO || (eO = this.createMaterial(OO, KO), this.materialData.set(bK, eO)), pO(eO.material), eO.promise
      }
      createMaterial(OO, KO) {
        const pO = OO ? OO.name || `material${OO.index}` : "__GLTFLoader._default",
          {
            style: XO,
            unlit: bK
          } = this.materials;
        let eO;
        const lO = this.create((() => {
          const lO = (0, hK.d)({
            name: pO,
            Ce: this.Ce,
            sets: {
              ...(0, kK.d)(this.asset, OO, XO, bK),
              fillMode: KO
            },
            unrendered: !0
          });
          return eO = lO.model, lO.mirror
        }));
        let vK = Promise.resolve();
        if (OO) {
          const KO = `/materials/${OO.index}`,
            XO = eO.diffuseTexture;
          if (XO && !XO.mirror) vK = new Promise((OO => setTimeout(OO)));
          else if (XO) {
            const bK = XO.mirror;
            bK._parentContainer = this.container, bK.name = `${pO} (Base Color)`, DK(bK, `${KO}${OO.unlit?"":"/pbrMetallicRoughness"}/baseColorTexture`), this.tree.textures.push(bK), vK = (0, vp.w)(XO)
          }
          MK(lO, OO.extras), DK(lO, KO)
        }
        return this.tree.materials.push(lO), {
          material: lO,
          promise: vK
        }
      }
    }

    function VK() {
      XK.e.dracoDecodes = FO.decodes, XK.e.dracoWorkersStarted = FO.workersStarted, XK.e.dracoMostWorkers = FO.mostWorkers
    }
    async function LK(OO, KO, pO, bK, eO) {
      try {
        return await async function(OO, KO, pO, bK, eO, lO) {
          var vK;
          let CO;
          const hO = null === (vK = (0, CK.d)()) || void 0 === vK ? void 0 : vK.Lb,
            DO = null !== hO && void 0 !== hO && hO.Qb && KO === hO.JKO() ? hO : null,
            MO = eO && !DO;
          return await nO(OO, KO, pO, bK, XO.b, (OO => (CO = new oK(KO, MO), new FK(OO, KO, CO, MO, new KK(KO, bK), lO, DO).load())), !eO), CO
        }(OO, KO, pO, AO, bK, eO)
      } finally {
        VK()
      }
    }
    async function QK(OO, KO, pO, bK) {
      try {
        return await nO(OO, KO, pO, AO, XO.b, (OO => bK(OO, new KK(KO, AO))))
      } finally {
        VK()
      }
    }
    pK = bK.c, hO || (hO = {
      scriptUrl: new URL(pK.scriptUrl, location.href).href,
      wasmBinaryUrl: new URL(pK.wasmBinaryUrl, location.href).href
    })
  },
  39529: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(142),
      bK = pO(1063);

    function eO(OO) {
      return (0, XO.e)() ? `https://${bK.e.discordDomain}/${OO.href}` : OO.href
    }
    const lO = {
      scriptUrl: eO(new pO.U(pO(39538))),
      wasmBinaryUrl: eO(new pO.U(pO(39542)))
    }
  },
  34866: OO => {
    OO.exports = function(OO, KO, pO, XO) {
      var bK = self || window;
      try {
        try {
          var eO;
          try {
            eO = new bK.Blob([OO])
          } catch (hO) {
            (eO = new(bK.BlobBuilder || bK.WebKitBlobBuilder || bK.MozBlobBuilder || bK.MSBlobBuilder)).append(OO), eO = eO.getBlob()
          }
          var lO = bK.URL || bK.webkitURL,
            vK = lO.createObjectURL(eO),
            CO = new bK[KO](vK, pO);
          return lO.revokeObjectURL(vK), CO
        } catch (hO) {
          return new bK[KO]("data:application/javascript,".concat(encodeURIComponent(OO)), pO)
        }
      } catch (hO) {
        if (!XO) throw Error("Inline worker is not supported");
        return new bK[KO](XO, pO)
      }
    }
  },
  39542: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/draco_decoder_gltf_v2_1.1207caa8c6e38dc2aa04.wasm"
  },
  39538: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/draco_wasm_wrapper_gltf_v2_1.8b33994b6159ad3fc976.js"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);