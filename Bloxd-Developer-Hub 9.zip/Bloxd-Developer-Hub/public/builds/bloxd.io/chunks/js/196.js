export const id = 196;
export const ids = [196];
export const modules = {
  34958: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => IO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(1355),
      lO = pO(909),
      vK = pO(638),
      CO = pO(1051),
      hO = pO(1271),
      DO = pO(1344),
      MO = pO(2797),
      aK = pO(933),
      oO = pO(2730),
      FO = pO(2050),
      VO = pO(976);
    const LO = 2;

    function QO(OO) {
      return "firstPartyGame" === OO.type ? {
        type: "game",
        gameNameWithVariation: OO.gameNameWithVariation
      } : {
        type: "preview",
        preview: OO.preview
      }
    }

    function zK(OO) {
      let {
        game: KO,
        disabled: pO,
        showPlaceholder: XO
      } = OO;
      return null !== KO ? (0, VO.jsx)(oO.f, {
        source: QO(KO),
        gameWidth: "100%",
        useLongRatio: !0,
        disabled: pO,
        entrySource: "customGamePlace"
      }) : XO ? (0, VO.jsx)(oO.d, {
        gameWidth: "100%",
        useLongRatio: !0
      }) : null
    }

    function AO(OO) {
      var KO;
      let {
        category: pO,
        title: XO,
        tintColour: bK,
        layout: eO,
        games: lO,
        landscape: vK = !1
      } = OO;
      const {
        followsLeader: CO
      } = (0, FO.f)(), hO = null !== (KO = null === lO || void 0 === lO ? void 0 : lO.slice(0, eO.gameCount)) && void 0 !== KO ? KO : [], MO = {
        "--custom-game-place-tint": bK
      };
      return (0, VO.jsxs)("div", {
        className: "CustomGamePlacePanel AnimFadeIn",
        style: MO,
        children: [(0, VO.jsx)("h2", {
          className: "CustomGamePlacePanelHeading",
          children: (0, VO.jsxs)(DO.LinkPreserveSearch, {
            to: `/custom-games/${encodeURIComponent(pO)}`,
            className: "CustomGamePlacePanelTitle SmallTextBold",
            children: [(0, VO.jsx)("span", {
              children: XO
            }), (0, VO.jsx)(aK.d, {
              name: "arrow-up"
            })]
          })
        }), (0, VO.jsx)("div", {
          className: "CustomGamePlacePanelGames",
          style: {
            gridTemplateColumns: `repeat(${vK?eO.columnCount:LO}, ${vK?"var(--custom-game-place-tile-width)":"minmax(0, 1fr)"})`
          },
          children: Array.from({
            length: eO.gameCount
          }, ((OO, KO) => {
            var pO;
            return (0, VO.jsx)(zK, {
              game: null !== (pO = hO[KO]) && void 0 !== pO ? pO : null,
              disabled: CO,
              showPlaceholder: !lO
            }, KO)
          }))
        })]
      })
    }

    function fO(OO) {
      let {
        categories: KO
      } = OO;

      function pO(OO) {
        const pO = KO[OO];
        return (0, VO.jsx)(AO, {
          ...pO,
          landscape: !0
        }, pO.id)
      }
      return (0, VO.jsxs)("div", {
        className: "CustomGamePlaceMosaic CustomGamePlaceMosaicLandscape AnimFadeIn",
        children: [(0, VO.jsxs)("div", {
          className: "CustomGamePlaceUpper",
          children: [(0, VO.jsxs)("div", {
            className: "CustomGamePlaceMain",
            children: [(0, VO.jsxs)("div", {
              className: "CustomGamePlaceRow",
              children: [pO(0), pO(2)]
            }), pO(1)]
          }), pO(4)]
        }), (0, VO.jsxs)("div", {
          className: "CustomGamePlaceRow",
          children: [pO(3), pO(5)]
        })]
      })
    }
    const dO = ["section1", "section2", "section3", "section4", "section5", "section6"],
      TO = {
        section1: {
          gameCount: 4,
          columnCount: 2
        },
        section2: {
          gameCount: 6,
          columnCount: 6
        },
        section3: {
          gameCount: 8,
          columnCount: 4
        },
        section4: {
          gameCount: 6,
          columnCount: 3
        },
        section5: {
          gameCount: 3,
          columnCount: 1
        },
        section6: {
          gameCount: 8,
          columnCount: 4
        }
      };
    var NO = pO(997);

    function IO() {
      var OO;
      const {
        t: KO
      } = (0, CO.D)(), pO = (0, eO.w)(), XO = (0, NO.g)(), aK = (0, MO.c)({
        refresh: !0
      }), oO = pO.customGamePlace;
      if (!(0, lO.o)(oO)) return (0, VO.jsx)(DO.NavigatePreserveSearch, {
        to: "/"
      });
      const FO = vK.e[oO],
        LO = lO.e[oO],
        QO = null !== (OO = null === aK || void 0 === aK ? void 0 : aK[oO]) && void 0 !== OO ? OO : null,
        zK = [];
      for (let bK = 0; bK < LO.length; bK++) {
        var IO;
        const OO = dO[bK];
        if (!OO) continue;
        const pO = LO[bK];
        zK.push({
          id: pO.id,
          category: pO.category,
          title: KO(pO.displayTranslationKey),
          tintColour: pO.tintColour,
          layout: TO[OO],
          games: null !== (IO = null === QO || void 0 === QO ? void 0 : QO[pO.id]) && void 0 !== IO ? IO : null
        })
      }
      return (0, VO.jsxs)("div", {
        className: "CustomGamePlaceContainer AnimFadeIn",
        children: [(0, VO.jsx)("div", {
          className: "BackgroundImage",
          style: {
            backgroundImage: `url(/textures/games/${oO}/${FO.largePicture}.png)`
          }
        }), (0, VO.jsx)("h1", {
          className: "VisuallyHidden",
          children: KO(FO.title)
        }), (0, VO.jsx)("div", {
          className: "CustomGamePlaceHeaderContainer",
          children: (0, VO.jsx)(hO.c, {
            onClick: () => (0, DO.navigatePreserveSearch)("/"),
            children: KO("homePage:backToGames")
          })
        }), !XO && (0, VO.jsx)(fO, {
          categories: zK
        }), XO && (0, VO.jsx)("div", {
          className: bK()("CustomGamePlaceMosaic", "CustomGamePlaceMosaicPortrait"),
          children: zK.map((OO => (0, VO.jsx)(AO, {
            category: OO.category,
            title: OO.title,
            tintColour: OO.tintColour,
            layout: OO.layout,
            games: OO.games
          }, OO.id)))
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);