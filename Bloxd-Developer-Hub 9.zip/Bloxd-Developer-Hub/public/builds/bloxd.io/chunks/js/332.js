export const id = 332;
export const ids = [332];
export const modules = {
  59066: (OO, KO, pO) => {
    var XO;
    pO.r(KO), pO.d(KO, {
        ShaderLanguage: () => XO
      }),
      function(OO) {
        OO[OO.GLSL = 0] = "GLSL", OO[OO.WGSL = 1] = "WGSL"
      }(XO || (XO = {}))
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);