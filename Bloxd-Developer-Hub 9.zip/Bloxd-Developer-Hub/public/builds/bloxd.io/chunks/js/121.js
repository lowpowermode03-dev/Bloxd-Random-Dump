export const id = 121;
export const ids = [120, 121, 123];
export const modules = {
  5721: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO.h,
      d: () => bK,
      h: () => XO.q
    });
    var XO = pO(5709);
    const bK = [!1, !0].flatMap((OO => ["terrain", "liquid", "model"].map((KO => ({
      strict: OO,
      program: KO
    })))))
  },
  5791: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      forgetShaderPackActiveHint: () => EO,
      isOtherApiVersion: () => IO,
      isShaderPackActive: () => fO,
      isShaderPackChangePending: () => NO,
      markShaderPackChangePending: () => TO,
      pageShaderPackValidationVersion: () => yK,
      reconcileStoredShaderPackHint: () => uO,
      removeShaderPack: () => AO,
      replaceShaderPack: () => LO,
      saveShaderPack: () => VO,
      shaderPackNeedsCheck: () => gK,
      storedPackOutcome: () => dO,
      storedShaderPackFiles: () => aK,
      toStoredShaderPack: () => MO
    });
    var XO = pO(5709),
      bK = pO(5721),
      eO = pO(36),
      lO = pO(2668),
      vK = pO(5800),
      CO = pO(5763);
    const hO = "shaderPackChangePending";
    let DO = null;

    function MO(OO, KO, pO) {
      return {
        manifest: OO.manifest,
        files: (0, XO.v)(OO.files),
        validation: KO,
        ...pO && {
          listing: pO
        }
      }
    }

    function aK(OO) {
      return Object.keys(OO.files).map((KO => ({
        path: KO,
        source: OO.files[KO]
      })))
    }
    let oO = Promise.resolve();

    function FO(OO) {
      const KO = oO.then(OO);
      return oO = KO.catch((() => {})), KO
    }

    function VO(OO, KO) {
      return FO((() => QO(OO, KO)))
    }

    function LO(OO, KO, pO) {
      return FO((async () => JSON.stringify(await (0, vK.h)()) === JSON.stringify(OO) && (null === KO ? (await zK(), !0) : QO(KO, pO))))
    }
    async function QO(OO, KO) {
      const pO = await eO.d.setItem(vK.e, OO);
      return pO && jK(OO, KO), pO
    }
    async function zK() {
      await eO.d.removeItem(vK.e), eO.e.removeItem(lO.b)
    }

    function AO() {
      return FO(zK)
    }

    function fO(OO, KO) {
      return "active" === dO(OO, KO).kind
    }

    function dO(OO, KO) {
      var pO;
      return null === OO ? {
        kind: "none",
        reason: "nothingStored"
      } : IO(OO) ? {
        kind: "none",
        reason: "otherApiVersion"
      } : !1 !== (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.ok) || OO.validation.fromRecheck ? null === KO ? {
        kind: "none",
        reason: "noCompiler"
      } : gK(OO, KO) ? {
        kind: "blocked",
        messageKey: "shaderPack:failedUnchecked"
      } : OO.validation.ok ? {
        kind: "active"
      } : {
        kind: "blocked",
        messageKey: "shaderPack:failedValidation"
      } : {
        kind: "none",
        reason: "failedWhenLoaded"
      }
    }

    function TO() {
      eO.h.setItem(hO, performance.timeOrigin)
    }

    function NO() {
      return eO.h.getItem(hO) === performance.timeOrigin
    }

    function IO(OO) {
      return !(0, bK.h)(OO.manifest.apiVersion)
    }

    function yK(OO) {
      return DO ??= OO.sKO((0, CO.shaderPackTextures)()), DO
    }

    function gK(OO, KO) {
      var pO;
      return (null === (pO = OO.validation) || void 0 === pO ? void 0 : pO.headerVersion) !== yK(KO)
    }

    function uO(OO) {
      return FO((async () => {
        jK(await (0, vK.h)(!0), OO)
      }))
    }

    function EO() {
      return FO((async () => {
        eO.e.removeItem(lO.b)
      }))
    }

    function jK(OO, KO) {
      fO(OO, KO) ? eO.e.setItem(lO.b, !0) : eO.e.removeItem(lO.b)
    }
  },
  5800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    var XO = pO(36);
    const bK = "shaderPack";
    async function eO() {
      var OO;
      let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return null !== (OO = await XO.d.getItem(bK, KO)) && void 0 !== OO ? OO : null
    }
  },
  5763: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadShaderPackTextures: () => lO,
      shaderPackTextures: () => vK
    });
    var XO = pO(5709);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= Promise.all([pO.e(62), pO.e(182)]).then((() => pO(38591))).then((OO => {
        let {
          FORMER_BLOCK_IMAGE_NAMES: KO,
          textureNameToIndex: pO,
          textureAnimationData: eO
        } = OO;
        return bK ??= (0, XO.k)(pO, eO, KO), bK
      })), eO
    }

    function vK() {
      if (null === bK) throw new Error("Shader pack textures read before loadShaderPackTextures");
      return bK
    }
  },
  5709: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      f: () => eO,
      h: () => XO,
      k: () => FO,
      m: () => DO,
      q: () => bK,
      t: () => CO,
      v: () => hO,
      w: () => MO
    });
    const XO = 5;

    function bK(OO) {
      return OO === XO
    }
    const eO = 262144,
      lO = 256,
      vK = 256;

    function CO(OO) {
      if ("object" !== typeof OO || null === OO || Array.isArray(OO)) return "The pack has no files.";
      const KO = [];
      for (const [pO, XO] of Object.entries(OO)) {
        if ("string" !== typeof XO) return `${pO} isn't text.`;
        KO.push({
          path: pO,
          source: XO
        })
      }
      return KO.sort(((OO, KO) => DO(OO.path, KO.path))),
        function(OO) {
          if (0 === OO.length) return "The pack has no .wgsl files.";
          if (OO.length > lO) return `The pack has more than ${lO} .wgsl files.`;
          const KO = new Set;
          for (const {
              path: pO
            }
            of OO) {
            const OO = aK(pO);
            if (null !== OO) return OO;
            if (KO.has(pO)) return `The pack has two files at ${pO}.`;
            KO.add(pO)
          }
          return MO(OO) > eO ? `The pack's .wgsl files are over ${eO/1024} KB in total.` : null
        }(KO) ?? KO
    }

    function hO(OO) {
      const KO = {};
      for (const pO of OO) KO[pO.path] = pO.source;
      return KO
    }

    function DO(OO, KO) {
      return OO < KO ? -1 : OO > KO ? 1 : 0
    }

    function MO(OO) {
      const KO = new TextEncoder;
      let pO = 0;
      for (const {
          source: XO
        }
        of OO) pO += KO.encode(XO).byteLength;
      return pO
    }

    function aK(OO) {
      if (!OO.toLowerCase().endsWith(".wgsl")) return `${OO} isn't a .wgsl file.`;
      if (OO.length > vK) return `A file path is over ${vK} characters.`;
      if (OO.includes("\\") || /[\u0000-\u001f]/.test(OO)) return `${OO} isn't a valid file path.`;
      return OO.split("/").some((OO => "" === OO || "." === OO || ".." === OO)) ? `${OO} isn't a valid file path.` : null
    }
    const oO = /^(.*)\[rot\[([1-4])$/;

    function FO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : new Map;
      const XO = new Map;
      KO.forEach(((OO, KO) => {
        let {
          numAnimStates: pO,
          animStartIdx: bK
        } = OO;
        for (let eO = 1; eO < pO; eO++) XO.set(bK + eO - 1, KO)
      }));
      const bK = Object.entries(OO),
        eO = new Map;
      for (const [VO, LO] of bK) {
        const OO = oO.exec(VO);
        "1" === OO?.[2] && eO.set(OO[1], LO + 1)
      }
      const lO = OO => {
          const KO = oO.exec(OO);
          return KO && eO.has(KO[1]) ? {
            root: KO[1],
            rotation: Number(KO[2]) - 1
          } : null
        },
        vK = new Set(bK.map((OO => {
          let [KO] = OO;
          return lO(KO)?.root ?? KO
        }))),
        CO = (OO, pO) => {
          const XO = OO.replace(/_?0$/, "");
          return (KO[pO]?.numAnimStates ?? 0) > 1 && !vK.has(XO) ? XO : OO
        },
        hO = new Map;
      for (const [oO, VO] of bK) hO.set(VO, CO(lO(oO)?.root ?? oO, VO));
      const DO = bK.reduce(((OO, KO) => {
          let [, pO] = KO;
          return Math.max(OO, pO + 1)
        }), 0),
        MO = Array.from({
          length: DO
        }, ((OO, KO) => ({
          id: KO + 1,
          rotation: 0
        }))),
        aK = new Map,
        FO = new Map;
      for (const [oO, VO] of bK) {
        const OO = lO(oO),
          KO = XO.get(VO);
        if (void 0 !== KO) {
          const pO = hO.get(KO);
          FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "frame"
          }), OO && !FO.has(OO.root) && FO.set(OO.root, {
            name: OO.root,
            texture: pO,
            kind: "frame"
          });
          continue
        }
        const pO = hO.get(VO),
          bK = OO?.root ?? oO;
        if (pO !== bK && FO.set(bK, {
            name: bK,
            texture: pO,
            kind: "frame"
          }), OO) {
          const KO = eO.get(OO.root);
          MO[VO] = {
            id: KO,
            rotation: OO.rotation
          }, aK.set(pO, KO), FO.set(oO, {
            name: oO,
            texture: pO,
            kind: "rotation"
          })
        } else aK.set(pO, VO + 1)
      }
      for (const oO of aK.keys()) FO.delete(oO);
      for (const [oO, VO] of pO) {
        const OO = aK.get(VO);
        void 0 === OO || aK.has(oO) || (aK.set(oO, OO), FO.delete(oO))
      }
      return {
        named: [...aK].sort(((OO, KO) => {
          let [pO] = OO, [XO] = KO;
          return pO < XO ? -1 : pO > XO ? 1 : 0
        })).map((OO => {
          let [KO, pO] = OO;
          return {
            name: KO,
            id: pO
          }
        })),
        aliases: [...FO.values()],
        layers: MO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);