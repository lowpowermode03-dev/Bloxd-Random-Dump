export const id = 214;
export const ids = [214];
export const modules = {
  35653: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(35660);
    class bK {
      static get LastCreatedEngine() {
        return 0 === this.Instances.length ? null : this.Instances[this.Instances.length - 1]
      }
      static get LastCreatedScene() {
        return this._LastCreatedScene
      }
    }
    bK.Instances = [], bK.OnEnginesDisposedObservable = new XO.e, bK._LastCreatedScene = null, bK.UseFallbackTexture = !0, bK.FallbackTexture = ""
  },
  35644: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static SetMatrixPrecision(OO) {
        if (XO.MatrixTrackPrecisionChange = !1, OO && !XO.MatrixUse64Bits && XO.MatrixTrackedMatrices)
          for (let KO = 0; KO < XO.MatrixTrackedMatrices.length; ++KO) {
            const OO = XO.MatrixTrackedMatrices[KO],
              pO = OO._m;
            OO._m = new Array(16);
            for (let KO = 0; KO < 16; ++KO) OO._m[KO] = pO[KO]
          }
        XO.MatrixUse64Bits = OO, XO.MatrixCurrentType = XO.MatrixUse64Bits ? Array : Float32Array, XO.MatrixTrackedMatrices = null
      }
    }
    XO.MatrixUse64Bits = !1, XO.MatrixTrackPrecisionChange = !0, XO.MatrixCurrentType = Float32Array, XO.MatrixTrackedMatrices = []
  },
  35668: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK,
      c: () => hO,
      d: () => CO,
      h: () => XO,
      k: () => eO,
      m: () => lO
    });
    class XO {}

    function bK(OO) {
      OO.updateFlag = XO._UpdateFlagSeed++
    }

    function eO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
      const bK = OO.WhO(),
        eO = KO.WhO(),
        lO = bK[0],
        vK = bK[1],
        CO = bK[2],
        hO = bK[3],
        DO = bK[4],
        MO = bK[5],
        aK = bK[6],
        oO = bK[7],
        FO = bK[8],
        VO = bK[9],
        LO = bK[10],
        QO = bK[11],
        zK = bK[12],
        AO = bK[13],
        fO = bK[14],
        dO = bK[15],
        TO = eO[0],
        NO = eO[1],
        IO = eO[2],
        yK = eO[3],
        gK = eO[4],
        uO = eO[5],
        EO = eO[6],
        jK = eO[7],
        YO = eO[8],
        wO = eO[9],
        iK = eO[10],
        rK = eO[11],
        PO = eO[12],
        mK = eO[13],
        sO = eO[14],
        HO = eO[15];
      pO[XO] = lO * TO + vK * gK + CO * YO + hO * PO, pO[XO + 1] = lO * NO + vK * uO + CO * wO + hO * mK, pO[XO + 2] = lO * IO + vK * EO + CO * iK + hO * sO, pO[XO + 3] = lO * yK + vK * jK + CO * rK + hO * HO, pO[XO + 4] = DO * TO + MO * gK + aK * YO + oO * PO, pO[XO + 5] = DO * NO + MO * uO + aK * wO + oO * mK, pO[XO + 6] = DO * IO + MO * EO + aK * iK + oO * sO, pO[XO + 7] = DO * yK + MO * jK + aK * rK + oO * HO, pO[XO + 8] = FO * TO + VO * gK + LO * YO + QO * PO, pO[XO + 9] = FO * NO + VO * uO + LO * wO + QO * mK, pO[XO + 10] = FO * IO + VO * EO + LO * iK + QO * sO, pO[XO + 11] = FO * yK + VO * jK + LO * rK + QO * HO, pO[XO + 12] = zK * TO + AO * gK + fO * YO + dO * PO, pO[XO + 13] = zK * NO + AO * uO + fO * wO + dO * mK, pO[XO + 14] = zK * IO + AO * EO + fO * iK + dO * sO, pO[XO + 15] = zK * yK + AO * jK + fO * rK + dO * HO
    }

    function lO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
      eO(OO, KO, pO.WhO(), XO), bK(pO)
    }

    function vK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
      const XO = OO.WhO();
      KO[pO] = XO[0], KO[pO + 1] = XO[1], KO[pO + 2] = XO[2], KO[pO + 3] = XO[3], KO[pO + 4] = XO[4], KO[pO + 5] = XO[5], KO[pO + 6] = XO[6], KO[pO + 7] = XO[7], KO[pO + 8] = XO[8], KO[pO + 9] = XO[9], KO[pO + 10] = XO[10], KO[pO + 11] = XO[11], KO[pO + 12] = XO[12], KO[pO + 13] = XO[13], KO[pO + 14] = XO[14], KO[pO + 15] = XO[15]
    }

    function CO(OO, KO) {
      const pO = hO(OO, KO.WhO());
      return pO && bK(KO), pO
    }

    function hO(OO, KO) {
      const pO = OO.WhO(),
        XO = pO[0],
        bK = pO[1],
        eO = pO[2],
        lO = pO[3],
        vK = pO[4],
        CO = pO[5],
        hO = pO[6],
        DO = pO[7],
        MO = pO[8],
        aK = pO[9],
        oO = pO[10],
        FO = pO[11],
        VO = pO[12],
        LO = pO[13],
        QO = pO[14],
        zK = pO[15],
        AO = oO * zK - QO * FO,
        fO = aK * zK - LO * FO,
        dO = aK * QO - LO * oO,
        TO = MO * zK - VO * FO,
        NO = MO * QO - oO * VO,
        IO = MO * LO - VO * aK,
        yK = +(CO * AO - hO * fO + DO * dO),
        gK = -(vK * AO - hO * TO + DO * NO),
        uO = +(vK * fO - CO * TO + DO * IO),
        EO = -(vK * dO - CO * NO + hO * IO),
        jK = XO * yK + bK * gK + eO * uO + lO * EO;
      if (0 === jK) return !1;
      const YO = 1 / jK,
        wO = hO * zK - QO * DO,
        iK = CO * zK - LO * DO,
        rK = CO * QO - LO * hO,
        PO = vK * zK - VO * DO,
        mK = vK * QO - VO * hO,
        sO = vK * LO - VO * CO,
        HO = hO * FO - oO * DO,
        RO = CO * FO - aK * DO,
        SO = CO * oO - aK * hO,
        JO = vK * FO - MO * DO,
        cK = vK * oO - MO * hO,
        BO = vK * aK - MO * CO,
        ZO = -(bK * AO - eO * fO + lO * dO),
        GO = +(XO * AO - eO * TO + lO * NO),
        qK = -(XO * fO - bK * TO + lO * IO),
        xK = +(XO * dO - bK * NO + eO * IO),
        nO = +(bK * wO - eO * iK + lO * rK),
        WO = -(XO * wO - eO * PO + lO * mK),
        tK = +(XO * iK - bK * PO + lO * sO),
        kK = -(XO * rK - bK * mK + eO * sO),
        UO = -(bK * HO - eO * RO + lO * SO),
        OK = +(XO * HO - eO * JO + lO * cK),
        KK = -(XO * RO - bK * JO + lO * BO),
        pK = +(XO * SO - bK * cK + eO * BO);
      return KO[0] = yK * YO, KO[1] = ZO * YO, KO[2] = nO * YO, KO[3] = UO * YO, KO[4] = gK * YO, KO[5] = GO * YO, KO[6] = WO * YO, KO[7] = OK * YO, KO[8] = uO * YO, KO[9] = qK * YO, KO[10] = tK * YO, KO[11] = KK * YO, KO[12] = EO * YO, KO[13] = xK * YO, KO[14] = kK * YO, KO[15] = pK * YO, !0
    }
    XO._UpdateFlagSeed = 0
  },
  35632: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => VO,
      g: () => FO,
      i: () => fO,
      j: () => QO,
      m: () => MO,
      o: () => aK,
      s: () => oO
    });
    var XO = pO(35639),
      bK = pO(35641),
      eO = pO(35644),
      lO = pO(35653),
      vK = pO(35664),
      CO = pO(35668),
      hO = pO(35676);
    const DO = OO => parseInt(OO.toString().replace(/\W/g, ""));
    class MO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        this.x = OO, this.y = KO
      }
      toString() {
        return `{X: ${this.x} Y: ${this.y}}`
      }
      getClassName() {
        return "Vector2"
      }
      getHashCode() {
        let OO = DO(this.x);
        return OO = 397 * OO ^ DO(this.y), OO
      }
      toArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return OO[KO] = this.x, OO[KO + 1] = this.y, this
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return MO.FromArrayToRef(OO, KO, this), this
      }
      WhO() {
        return [this.x, this.y]
      }
      NhO(OO) {
        return this.x = OO.x, this.y = OO.y, this
      }
      rvO(OO, KO) {
        return this.x = OO, this.y = KO, this
      }
      set(OO, KO) {
        return this.rvO(OO, KO)
      }
      plO(OO) {
        return this.rvO(OO, OO)
      }
      add(OO) {
        return new MO(this.x + OO.x, this.y + OO.y)
      }
      addToRef(OO, KO) {
        return KO.x = this.x + OO.x, KO.y = this.y + OO.y, KO
      }
      addInPlace(OO) {
        return this.x += OO.x, this.y += OO.y, this
      }
      addInPlaceFromFloats(OO, KO) {
        return this.x += OO, this.y += KO, this
      }
      addVector3(OO) {
        return new MO(this.x + OO.x, this.y + OO.y)
      }
      subtract(OO) {
        return new MO(this.x - OO.x, this.y - OO.y)
      }
      subtractToRef(OO, KO) {
        return KO.x = this.x - OO.x, KO.y = this.y - OO.y, KO
      }
      oDO(OO) {
        return this.x -= OO.x, this.y -= OO.y, this
      }
      multiplyInPlace(OO) {
        return this.x *= OO.x, this.y *= OO.y, this
      }
      multiply(OO) {
        return new MO(this.x * OO.x, this.y * OO.y)
      }
      multiplyToRef(OO, KO) {
        return KO.x = this.x * OO.x, KO.y = this.y * OO.y, KO
      }
      multiplyByFloats(OO, KO) {
        return new MO(this.x * OO, this.y * KO)
      }
      divide(OO) {
        return new MO(this.x / OO.x, this.y / OO.y)
      }
      divideToRef(OO, KO) {
        return KO.x = this.x / OO.x, KO.y = this.y / OO.y, KO
      }
      divideInPlace(OO) {
        return this.x = this.x / OO.x, this.y = this.y / OO.y, this
      }
      minimizeInPlace(OO) {
        return this.minimizeInPlaceFromFloats(OO.x, OO.y)
      }
      maximizeInPlace(OO) {
        return this.maximizeInPlaceFromFloats(OO.x, OO.y)
      }
      minimizeInPlaceFromFloats(OO, KO) {
        return this.x = Math.min(OO, this.x), this.y = Math.min(KO, this.y), this
      }
      maximizeInPlaceFromFloats(OO, KO) {
        return this.x = Math.max(OO, this.x), this.y = Math.max(KO, this.y), this
      }
      subtractFromFloats(OO, KO) {
        return new MO(this.x - OO, this.y - KO)
      }
      subtractFromFloatsToRef(OO, KO, pO) {
        return pO.x = this.x - OO, pO.y = this.y - KO, pO
      }
      hl() {
        return new MO(-this.x, -this.y)
      }
      negateInPlace() {
        return this.x *= -1, this.y *= -1, this
      }
      negateToRef(OO) {
        return OO.x = -this.x, OO.y = -this.y, OO
      }
      scaleInPlace(OO) {
        return this.x *= OO, this.y *= OO, this
      }
      scale(OO) {
        return new MO(this.x * OO, this.y * OO)
      }
      scaleToRef(OO, KO) {
        return KO.x = this.x * OO, KO.y = this.y * OO, KO
      }
      scaleAndAddToRef(OO, KO) {
        return KO.x += this.x * OO, KO.y += this.y * OO, KO
      }
      equals(OO) {
        return OO && this.x === OO.x && this.y === OO.y
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : XO.c;
        return OO && (0, vK.WithinEpsilon)(this.x, OO.x, KO) && (0, vK.WithinEpsilon)(this.y, OO.y, KO)
      }
      soO(OO, KO) {
        return this.x === OO && this.y === KO
      }
      floor() {
        return new MO(Math.floor(this.x), Math.floor(this.y))
      }
      floorToRef(OO) {
        return OO.x = Math.floor(this.x), OO.y = Math.floor(this.y), OO
      }
      fract() {
        return new MO(this.x - Math.floor(this.x), this.y - Math.floor(this.y))
      }
      fractToRef(OO) {
        return OO.x = this.x - Math.floor(this.x), OO.y = this.y - Math.floor(this.y), OO
      }
      rotate(OO) {
        return this.rotateToRef(OO, new MO)
      }
      rotateToRef(OO, KO) {
        const pO = Math.cos(OO),
          XO = Math.sin(OO);
        return KO.x = pO * this.x - XO * this.y, KO.y = XO * this.x + pO * this.y, KO
      }
      length() {
        return Math.sqrt(this.x * this.x + this.y * this.y)
      }
      lengthSquared() {
        return this.x * this.x + this.y * this.y
      }
      normalize() {
        return this.normalizeFromLength(this.length())
      }
      normalizeFromLength(OO) {
        return 0 === OO || 1 === OO ? this : this.scaleInPlace(1 / OO)
      }
      normalizeToNew() {
        const OO = new MO;
        return this.normalizeToRef(OO), OO
      }
      normalizeToRef(OO) {
        const KO = this.length();
        return 0 === KO || 1 === KO ? (OO.x = this.x, OO.y = this.y, OO) : this.scaleToRef(1 / KO, OO)
      }
      clone() {
        return new MO(this.x, this.y)
      }
      dot(OO) {
        return this.x * OO.x + this.y * OO.y
      }
      static Zero() {
        return new MO(0, 0)
      }
      static One() {
        return new MO(1, 1)
      }
      static Random() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return new MO((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static RandomToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return (arguments.length > 2 ? arguments[2] : void 0).rvO((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static get ZeroReadOnly() {
        return MO._ZeroReadOnly
      }
      static FromArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return new MO(OO[KO], OO[KO + 1])
      }
      static FromArrayToRef(OO, KO, pO) {
        return pO.x = OO[KO], pO.y = OO[KO + 1], pO
      }
      static FromFloatsToRef(OO, KO, pO) {
        return pO.rvO(OO, KO), pO
      }
      static CatmullRom(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = .5 * (2 * KO.x + (-OO.x + pO.x) * bK + (2 * OO.x - 5 * KO.x + 4 * pO.x - XO.x) * eO + (-OO.x + 3 * KO.x - 3 * pO.x + XO.x) * lO),
          CO = .5 * (2 * KO.y + (-OO.y + pO.y) * bK + (2 * OO.y - 5 * KO.y + 4 * pO.y - XO.y) * eO + (-OO.y + 3 * KO.y - 3 * pO.y + XO.y) * lO);
        return new MO(vK, CO)
      }
      static ClampToRef(OO, KO, pO, XO) {
        return XO.x = (0, vK.Clamp)(OO.x, KO.x, pO.x), XO.y = (0, vK.Clamp)(OO.y, KO.y, pO.y), XO
      }
      static Clamp(OO, KO, pO) {
        const XO = (0, vK.Clamp)(OO.x, KO.x, pO.x),
          bK = (0, vK.Clamp)(OO.y, KO.y, pO.y);
        return new MO(XO, bK)
      }
      static Hermite(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = 2 * lO - 3 * eO + 1,
          CO = -2 * lO + 3 * eO,
          hO = lO - 2 * eO + bK,
          DO = lO - eO,
          aK = OO.x * vK + pO.x * CO + KO.x * hO + XO.x * DO,
          oO = OO.y * vK + pO.y * CO + KO.y * hO + XO.y * DO;
        return new MO(aK, oO)
      }
      static Hermite1stDerivative(OO, KO, pO, XO, bK) {
        return this.Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, new MO)
      }
      static Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO) {
        const lO = bK * bK;
        return eO.x = 6 * (lO - bK) * OO.x + (3 * lO - 4 * bK + 1) * KO.x + 6 * (-lO + bK) * pO.x + (3 * lO - 2 * bK) * XO.x, eO.y = 6 * (lO - bK) * OO.y + (3 * lO - 4 * bK + 1) * KO.y + 6 * (-lO + bK) * pO.y + (3 * lO - 2 * bK) * XO.y, eO
      }
      static Lerp(OO, KO, pO) {
        return MO.LerpToRef(OO, KO, pO, new MO)
      }
      static LerpToRef(OO, KO, pO, XO) {
        return XO.x = OO.x + (KO.x - OO.x) * pO, XO.y = OO.y + (KO.y - OO.y) * pO, XO
      }
      static Dot(OO, KO) {
        return OO.x * KO.x + OO.y * KO.y
      }
      static Normalize(OO) {
        return MO.NormalizeToRef(OO, new MO)
      }
      static NormalizeToRef(OO, KO) {
        return OO.normalizeToRef(KO), KO
      }
      static Minimize(OO, KO) {
        const pO = OO.x < KO.x ? OO.x : KO.x,
          XO = OO.y < KO.y ? OO.y : KO.y;
        return new MO(pO, XO)
      }
      static Maximize(OO, KO) {
        const pO = OO.x > KO.x ? OO.x : KO.x,
          XO = OO.y > KO.y ? OO.y : KO.y;
        return new MO(pO, XO)
      }
      static Transform(OO, KO) {
        return MO.TransformToRef(OO, KO, new MO)
      }
      static TransformToRef(OO, KO, pO) {
        const XO = KO.m,
          bK = OO.x * XO[0] + OO.y * XO[4] + XO[12],
          eO = OO.x * XO[1] + OO.y * XO[5] + XO[13];
        return pO.x = bK, pO.y = eO, pO
      }
      static PointInTriangle(OO, KO, pO, XO) {
        const bK = .5 * (-pO.y * XO.x + KO.y * (-pO.x + XO.x) + KO.x * (pO.y - XO.y) + pO.x * XO.y),
          eO = bK < 0 ? -1 : 1,
          lO = (KO.y * XO.x - KO.x * XO.y + (XO.y - KO.y) * OO.x + (KO.x - XO.x) * OO.y) * eO,
          vK = (KO.x * pO.y - KO.y * pO.x + (KO.y - pO.y) * OO.x + (pO.x - KO.x) * OO.y) * eO;
        return lO > 0 && vK > 0 && lO + vK < 2 * bK * eO
      }
      static Distance(OO, KO) {
        return Math.sqrt(MO.DistanceSquared(OO, KO))
      }
      static DistanceSquared(OO, KO) {
        const pO = OO.x - KO.x,
          XO = OO.y - KO.y;
        return pO * pO + XO * XO
      }
      static Center(OO, KO) {
        return MO.CenterToRef(OO, KO, new MO)
      }
      static CenterToRef(OO, KO, pO) {
        return pO.rvO((OO.x + KO.x) / 2, (OO.y + KO.y) / 2)
      }
      static DistanceOfPointFromSegment(OO, KO, pO) {
        const XO = MO.DistanceSquared(KO, pO);
        if (0 === XO) return MO.Distance(OO, KO);
        const bK = pO.subtract(KO),
          eO = Math.max(0, Math.min(1, MO.Dot(OO.subtract(KO), bK) / XO)),
          lO = KO.add(bK.multiplyByFloats(eO, eO));
        return MO.Distance(OO, lO)
      }
    }
    MO._V8PerformanceHack = new MO(.5, .5), MO._ZeroReadOnly = MO.Zero();
    class aK {
      get x() {
        return this._x
      }
      set x(OO) {
        this._x = OO, this._isDirty = !0
      }
      get y() {
        return this._y
      }
      set y(OO) {
        this._y = OO, this._isDirty = !0
      }
      get z() {
        return this._z
      }
      set z(OO) {
        this._z = OO, this._isDirty = !0
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
        this._isDirty = !0, this._x = OO, this._y = KO, this._z = pO
      }
      toString() {
        return `{X: ${this._x} Y: ${this._y} Z: ${this._z}}`
      }
      getClassName() {
        return "WX"
      }
      getHashCode() {
        let OO = DO(this._x);
        return OO = 397 * OO ^ DO(this._y), OO = 397 * OO ^ DO(this._z), OO
      }
      WhO() {
        return [this._x, this._y, this._z]
      }
      toArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return OO[KO] = this._x, OO[KO + 1] = this._y, OO[KO + 2] = this._z, this
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return aK.FromArrayToRef(OO, KO, this), this
      }
      toQuaternion() {
        return FO.RotationYawPitchRoll(this._y, this._x, this._z)
      }
      addInPlace(OO) {
        return this._x += OO._x, this._y += OO._y, this._z += OO._z, this._isDirty = !0, this
      }
      addInPlaceFromFloats(OO, KO, pO) {
        return this._x += OO, this._y += KO, this._z += pO, this._isDirty = !0, this
      }
      add(OO) {
        return new aK(this._x + OO._x, this._y + OO._y, this._z + OO._z)
      }
      addToRef(OO, KO) {
        return KO._x = this._x + OO._x, KO._y = this._y + OO._y, KO._z = this._z + OO._z, KO._isDirty = !0, KO
      }
      oDO(OO) {
        return this._x -= OO._x, this._y -= OO._y, this._z -= OO._z, this._isDirty = !0, this
      }
      subtract(OO) {
        return new aK(this._x - OO._x, this._y - OO._y, this._z - OO._z)
      }
      subtractToRef(OO, KO) {
        return this.subtractFromFloatsToRef(OO._x, OO._y, OO._z, KO)
      }
      subtractFromFloats(OO, KO, pO) {
        return new aK(this._x - OO, this._y - KO, this._z - pO)
      }
      subtractFromFloatsToRef(OO, KO, pO, XO) {
        return XO._x = this._x - OO, XO._y = this._y - KO, XO._z = this._z - pO, XO._isDirty = !0, XO
      }
      hl() {
        return new aK(-this._x, -this._y, -this._z)
      }
      negateInPlace() {
        return this._x *= -1, this._y *= -1, this._z *= -1, this._isDirty = !0, this
      }
      negateToRef(OO) {
        return OO._x = -1 * this._x, OO._y = -1 * this._y, OO._z = -1 * this._z, OO._isDirty = !0, OO
      }
      scaleInPlace(OO) {
        return this._x *= OO, this._y *= OO, this._z *= OO, this._isDirty = !0, this
      }
      scale(OO) {
        return new aK(this._x * OO, this._y * OO, this._z * OO)
      }
      scaleToRef(OO, KO) {
        return KO._x = this._x * OO, KO._y = this._y * OO, KO._z = this._z * OO, KO._isDirty = !0, KO
      }
      getNormalToRef(OO) {
        const KO = this.length();
        let pO = Math.acos(this._y / KO);
        const XO = Math.atan2(this._z, this._x);
        pO > Math.PI / 2 ? pO -= Math.PI / 2 : pO += Math.PI / 2;
        const bK = KO * Math.sin(pO) * Math.cos(XO),
          eO = KO * Math.cos(pO),
          lO = KO * Math.sin(pO) * Math.sin(XO);
        return OO.set(bK, eO, lO), OO
      }
      applyRotationQuaternionToRef(OO, KO) {
        const pO = this._x,
          XO = this._y,
          bK = this._z,
          eO = OO._x,
          lO = OO._y,
          vK = OO._z,
          CO = OO._w,
          hO = 2 * (lO * bK - vK * XO),
          DO = 2 * (vK * pO - eO * bK),
          MO = 2 * (eO * XO - lO * pO);
        return KO._x = pO + CO * hO + lO * MO - vK * DO, KO._y = XO + CO * DO + vK * hO - eO * MO, KO._z = bK + CO * MO + eO * DO - lO * hO, KO._isDirty = !0, KO
      }
      applyRotationQuaternionInPlace(OO) {
        return this.applyRotationQuaternionToRef(OO, this)
      }
      applyRotationQuaternion(OO) {
        return this.applyRotationQuaternionToRef(OO, new aK)
      }
      scaleAndAddToRef(OO, KO) {
        return KO._x += this._x * OO, KO._y += this._y * OO, KO._z += this._z * OO, KO._isDirty = !0, KO
      }
      projectOnPlane(OO, KO) {
        return this.projectOnPlaneToRef(OO, KO, new aK)
      }
      projectOnPlaneToRef(OO, KO, pO) {
        const XO = OO.normal,
          bK = OO.d,
          eO = LO.WX[0];
        this.subtractToRef(KO, eO), eO.normalize();
        const lO = aK.Dot(eO, XO);
        if (Math.abs(lO) < 1e-10) pO.plO(1 / 0);
        else {
          const OO = -(aK.Dot(KO, XO) + bK) / lO,
            vK = eO.scaleInPlace(OO);
          KO.addToRef(vK, pO)
        }
        return pO
      }
      equals(OO) {
        return OO && this._x === OO._x && this._y === OO._y && this._z === OO._z
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : XO.c;
        return OO && (0, vK.WithinEpsilon)(this._x, OO._x, KO) && (0, vK.WithinEpsilon)(this._y, OO._y, KO) && (0, vK.WithinEpsilon)(this._z, OO._z, KO)
      }
      soO(OO, KO, pO) {
        return this._x === OO && this._y === KO && this._z === pO
      }
      multiplyInPlace(OO) {
        return this._x *= OO._x, this._y *= OO._y, this._z *= OO._z, this._isDirty = !0, this
      }
      multiply(OO) {
        return this.multiplyByFloats(OO._x, OO._y, OO._z)
      }
      multiplyToRef(OO, KO) {
        return KO._x = this._x * OO._x, KO._y = this._y * OO._y, KO._z = this._z * OO._z, KO._isDirty = !0, KO
      }
      multiplyByFloats(OO, KO, pO) {
        return new aK(this._x * OO, this._y * KO, this._z * pO)
      }
      divide(OO) {
        return new aK(this._x / OO._x, this._y / OO._y, this._z / OO._z)
      }
      divideToRef(OO, KO) {
        return KO._x = this._x / OO._x, KO._y = this._y / OO._y, KO._z = this._z / OO._z, KO._isDirty = !0, KO
      }
      divideInPlace(OO) {
        return this._x = this._x / OO._x, this._y = this._y / OO._y, this._z = this._z / OO._z, this._isDirty = !0, this
      }
      minimizeInPlace(OO) {
        return this.minimizeInPlaceFromFloats(OO._x, OO._y, OO._z)
      }
      maximizeInPlace(OO) {
        return this.maximizeInPlaceFromFloats(OO._x, OO._y, OO._z)
      }
      minimizeInPlaceFromFloats(OO, KO, pO) {
        return OO < this._x && (this.x = OO), KO < this._y && (this.y = KO), pO < this._z && (this.z = pO), this
      }
      maximizeInPlaceFromFloats(OO, KO, pO) {
        return OO > this._x && (this.x = OO), KO > this._y && (this.y = KO), pO > this._z && (this.z = pO), this
      }
      isNonUniformWithinEpsilon(OO) {
        const KO = Math.abs(this._x),
          pO = Math.abs(this._y);
        if (!(0, vK.WithinEpsilon)(KO, pO, OO)) return !0;
        const XO = Math.abs(this._z);
        return !(0, vK.WithinEpsilon)(KO, XO, OO) || !(0, vK.WithinEpsilon)(pO, XO, OO)
      }
      get isNonUniform() {
        const OO = Math.abs(this._x);
        if (OO !== Math.abs(this._y)) return !0;
        return OO !== Math.abs(this._z)
      }
      floorToRef(OO) {
        return OO._x = Math.floor(this._x), OO._y = Math.floor(this._y), OO._z = Math.floor(this._z), OO._isDirty = !0, OO
      }
      floor() {
        return new aK(Math.floor(this._x), Math.floor(this._y), Math.floor(this._z))
      }
      fractToRef(OO) {
        return OO._x = this._x - Math.floor(this._x), OO._y = this._y - Math.floor(this._y), OO._z = this._z - Math.floor(this._z), OO._isDirty = !0, OO
      }
      fract() {
        return new aK(this._x - Math.floor(this._x), this._y - Math.floor(this._y), this._z - Math.floor(this._z))
      }
      length() {
        return Math.sqrt(this.lengthSquared())
      }
      lengthSquared() {
        return this._x * this._x + this._y * this._y + this._z * this._z
      }
      get hasAZeroComponent() {
        return this._x * this._y * this._z === 0
      }
      normalize() {
        return this.normalizeFromLength(this.length())
      }
      reorderInPlace(OO) {
        if ("xyz" === (OO = OO.toLowerCase())) return this;
        const KO = LO.WX[0].NhO(this);
        return this.x = KO[OO[0]], this.y = KO[OO[1]], this.z = KO[OO[2]], this
      }
      rotateByQuaternionToRef(OO, KO) {
        return OO.toRotationMatrix(LO.Matrix[0]), aK.TransformCoordinatesToRef(this, LO.Matrix[0], KO), KO
      }
      rotateByQuaternionAroundPointToRef(OO, KO, pO) {
        return this.subtractToRef(KO, LO.WX[0]), LO.WX[0].rotateByQuaternionToRef(OO, LO.WX[0]), KO.addToRef(LO.WX[0], pO), pO
      }
      cross(OO) {
        return aK.CrossToRef(this, OO, new aK)
      }
      normalizeFromLength(OO) {
        return 0 === OO || 1 === OO ? this : this.scaleInPlace(1 / OO)
      }
      normalizeToNew() {
        return this.normalizeToRef(new aK)
      }
      normalizeToRef(OO) {
        const KO = this.length();
        return 0 === KO || 1 === KO ? (OO._x = this._x, OO._y = this._y, OO._z = this._z, OO._isDirty = !0, OO) : this.scaleToRef(1 / KO, OO)
      }
      clone() {
        return new aK(this._x, this._y, this._z)
      }
      NhO(OO) {
        return this.rvO(OO._x, OO._y, OO._z)
      }
      rvO(OO, KO, pO) {
        return this._x = OO, this._y = KO, this._z = pO, this._isDirty = !0, this
      }
      set(OO, KO, pO) {
        return this.rvO(OO, KO, pO)
      }
      plO(OO) {
        return this._x = this._y = this._z = OO, this._isDirty = !0, this
      }
      static GetClipFactor(OO, KO, pO, XO) {
        const bK = aK.Dot(OO, pO);
        return (bK - XO) / (bK - aK.Dot(KO, pO))
      }
      static GetAngleBetweenVectors(OO, KO, pO) {
        const XO = OO.normalizeToRef(LO.WX[1]),
          bK = KO.normalizeToRef(LO.WX[2]);
        let eO = aK.Dot(XO, bK);
        eO = (0, vK.Clamp)(eO, -1, 1);
        const lO = Math.acos(eO),
          CO = LO.WX[3];
        return aK.CrossToRef(XO, bK, CO), aK.Dot(CO, pO) > 0 ? isNaN(lO) ? 0 : lO : isNaN(lO) ? -Math.PI : -Math.acos(eO)
      }
      static GetAngleBetweenVectorsOnPlane(OO, KO, pO) {
        LO.WX[0].NhO(OO);
        const XO = LO.WX[0];
        LO.WX[1].NhO(KO);
        const bK = LO.WX[1];
        LO.WX[2].NhO(pO);
        const eO = LO.WX[2],
          lO = LO.WX[3],
          CO = LO.WX[4];
        XO.normalize(), bK.normalize(), eO.normalize(), aK.CrossToRef(eO, XO, lO), aK.CrossToRef(lO, eO, CO);
        const hO = Math.atan2(aK.Dot(bK, lO), aK.Dot(bK, CO));
        return (0, vK.NormalizeRadians)(hO)
      }
      static PitchYawRollToMoveBetweenPointsToRef(OO, KO, pO) {
        const XO = QO.WX[0];
        return KO.subtractToRef(OO, XO), pO._y = Math.atan2(XO.x, XO.z) || 0, pO._x = Math.atan2(Math.sqrt(XO.x ** 2 + XO.z ** 2), XO.y) || 0, pO._z = 0, pO._isDirty = !0, pO
      }
      static PitchYawRollToMoveBetweenPoints(OO, KO) {
        const pO = aK.Zero();
        return aK.PitchYawRollToMoveBetweenPointsToRef(OO, KO, pO)
      }
      static SlerpToRef(OO, KO, pO, bK) {
        pO = (0, vK.Clamp)(pO, 0, 1);
        const eO = LO.WX[0],
          lO = LO.WX[1];
        eO.NhO(OO);
        const CO = eO.length();
        eO.normalizeFromLength(CO), lO.NhO(KO);
        const hO = lO.length();
        lO.normalizeFromLength(hO);
        const DO = aK.Dot(eO, lO);
        let MO, oO;
        if (DO < 1 - XO.c) {
          const OO = Math.acos(DO),
            KO = 1 / Math.sin(OO);
          MO = Math.sin((1 - pO) * OO) * KO, oO = Math.sin(pO * OO) * KO
        } else MO = 1 - pO, oO = pO;
        return eO.scaleInPlace(MO), lO.scaleInPlace(oO), bK.NhO(eO).addInPlace(lO), bK.scaleInPlace((0, vK.Lerp)(CO, hO, pO)), bK
      }
      static SmoothToRef(OO, KO, pO, XO, bK) {
        return aK.SlerpToRef(OO, KO, 0 === XO ? 1 : pO / XO, bK), bK
      }
      static FromArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return new aK(OO[KO], OO[KO + 1], OO[KO + 2])
      }
      static FromFloatArray(OO, KO) {
        return aK.FromArray(OO, KO)
      }
      static FromArrayToRef(OO, KO, pO) {
        return pO._x = OO[KO], pO._y = OO[KO + 1], pO._z = OO[KO + 2], pO._isDirty = !0, pO
      }
      static FromFloatArrayToRef(OO, KO, pO) {
        return aK.FromArrayToRef(OO, KO, pO)
      }
      static FromFloatsToRef(OO, KO, pO, XO) {
        return XO.rvO(OO, KO, pO), XO
      }
      static Zero() {
        return new aK(0, 0, 0)
      }
      static One() {
        return new aK(1, 1, 1)
      }
      static Up() {
        return new aK(0, 1, 0)
      }
      static get UpReadOnly() {
        return aK._UpReadOnly
      }
      static get DownReadOnly() {
        return aK._DownReadOnly
      }
      static get RightReadOnly() {
        return aK._RightReadOnly
      }
      static get LeftReadOnly() {
        return aK._LeftReadOnly
      }
      static get LeftHandedForwardReadOnly() {
        return aK._LeftHandedForwardReadOnly
      }
      static get RightHandedForwardReadOnly() {
        return aK._RightHandedForwardReadOnly
      }
      static get LeftHandedBackwardReadOnly() {
        return aK._LeftHandedBackwardReadOnly
      }
      static get RightHandedBackwardReadOnly() {
        return aK._RightHandedBackwardReadOnly
      }
      static get ZeroReadOnly() {
        return aK._ZeroReadOnly
      }
      static get OneReadOnly() {
        return aK._OneReadOnly
      }
      static Down() {
        return new aK(0, -1, 0)
      }
      static Forward() {
        return new aK(0, 0, arguments.length > 0 && void 0 !== arguments[0] && arguments[0] ? -1 : 1)
      }
      static Backward() {
        return new aK(0, 0, arguments.length > 0 && void 0 !== arguments[0] && arguments[0] ? 1 : -1)
      }
      static Right() {
        return new aK(1, 0, 0)
      }
      static Left() {
        return new aK(-1, 0, 0)
      }
      static Random() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return new aK((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static RandomToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return (arguments.length > 2 ? arguments[2] : void 0).rvO((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static TransformCoordinates(OO, KO) {
        const pO = aK.Zero();
        return aK.TransformCoordinatesToRef(OO, KO, pO), pO
      }
      static TransformCoordinatesToRef(OO, KO, pO) {
        return aK.TransformCoordinatesFromFloatsToRef(OO._x, OO._y, OO._z, KO, pO), pO
      }
      static TransformCoordinatesFromFloatsToRef(OO, KO, pO, XO, bK) {
        const eO = XO.m,
          lO = OO * eO[0] + KO * eO[4] + pO * eO[8] + eO[12],
          vK = OO * eO[1] + KO * eO[5] + pO * eO[9] + eO[13],
          CO = OO * eO[2] + KO * eO[6] + pO * eO[10] + eO[14],
          hO = 1 / (OO * eO[3] + KO * eO[7] + pO * eO[11] + eO[15]);
        return bK._x = lO * hO, bK._y = vK * hO, bK._z = CO * hO, bK._isDirty = !0, bK
      }
      static TransformNormal(OO, KO) {
        const pO = aK.Zero();
        return aK.TransformNormalToRef(OO, KO, pO), pO
      }
      static TransformNormalToRef(OO, KO, pO) {
        return this.TransformNormalFromFloatsToRef(OO._x, OO._y, OO._z, KO, pO), pO
      }
      static TransformNormalFromFloatsToRef(OO, KO, pO, XO, bK) {
        const eO = XO.m;
        return bK._x = OO * eO[0] + KO * eO[4] + pO * eO[8], bK._y = OO * eO[1] + KO * eO[5] + pO * eO[9], bK._z = OO * eO[2] + KO * eO[6] + pO * eO[10], bK._isDirty = !0, bK
      }
      static CatmullRom(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = .5 * (2 * KO._x + (-OO._x + pO._x) * bK + (2 * OO._x - 5 * KO._x + 4 * pO._x - XO._x) * eO + (-OO._x + 3 * KO._x - 3 * pO._x + XO._x) * lO),
          CO = .5 * (2 * KO._y + (-OO._y + pO._y) * bK + (2 * OO._y - 5 * KO._y + 4 * pO._y - XO._y) * eO + (-OO._y + 3 * KO._y - 3 * pO._y + XO._y) * lO),
          hO = .5 * (2 * KO._z + (-OO._z + pO._z) * bK + (2 * OO._z - 5 * KO._z + 4 * pO._z - XO._z) * eO + (-OO._z + 3 * KO._z - 3 * pO._z + XO._z) * lO);
        return new aK(vK, CO, hO)
      }
      static Clamp(OO, KO, pO) {
        const XO = new aK;
        return aK.ClampToRef(OO, KO, pO, XO), XO
      }
      static ClampToRef(OO, KO, pO, XO) {
        let bK = OO._x;
        bK = bK > pO._x ? pO._x : bK, bK = bK < KO._x ? KO._x : bK;
        let eO = OO._y;
        eO = eO > pO._y ? pO._y : eO, eO = eO < KO._y ? KO._y : eO;
        let lO = OO._z;
        return lO = lO > pO._z ? pO._z : lO, lO = lO < KO._z ? KO._z : lO, XO.rvO(bK, eO, lO), XO
      }
      static CheckExtends(OO, KO, pO) {
        KO.minimizeInPlace(OO), pO.maximizeInPlace(OO)
      }
      static Hermite(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = 2 * lO - 3 * eO + 1,
          CO = -2 * lO + 3 * eO,
          hO = lO - 2 * eO + bK,
          DO = lO - eO,
          MO = OO._x * vK + pO._x * CO + KO._x * hO + XO._x * DO,
          oO = OO._y * vK + pO._y * CO + KO._y * hO + XO._y * DO,
          FO = OO._z * vK + pO._z * CO + KO._z * hO + XO._z * DO;
        return new aK(MO, oO, FO)
      }
      static Hermite1stDerivative(OO, KO, pO, XO, bK) {
        const eO = new aK;
        return this.Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO), eO
      }
      static Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO) {
        const lO = bK * bK;
        return eO._x = 6 * (lO - bK) * OO._x + (3 * lO - 4 * bK + 1) * KO._x + 6 * (-lO + bK) * pO._x + (3 * lO - 2 * bK) * XO._x, eO._y = 6 * (lO - bK) * OO._y + (3 * lO - 4 * bK + 1) * KO._y + 6 * (-lO + bK) * pO._y + (3 * lO - 2 * bK) * XO._y, eO._z = 6 * (lO - bK) * OO._z + (3 * lO - 4 * bK + 1) * KO._z + 6 * (-lO + bK) * pO._z + (3 * lO - 2 * bK) * XO._z, eO._isDirty = !0, eO
      }
      static Lerp(OO, KO, pO) {
        const XO = new aK(0, 0, 0);
        return aK.LerpToRef(OO, KO, pO, XO), XO
      }
      static LerpToRef(OO, KO, pO, XO) {
        return XO._x = OO._x + (KO._x - OO._x) * pO, XO._y = OO._y + (KO._y - OO._y) * pO, XO._z = OO._z + (KO._z - OO._z) * pO, XO._isDirty = !0, XO
      }
      static Dot(OO, KO) {
        return OO._x * KO._x + OO._y * KO._y + OO._z * KO._z
      }
      dot(OO) {
        return this._x * OO._x + this._y * OO._y + this._z * OO._z
      }
      static Cross(OO, KO) {
        const pO = new aK;
        return aK.CrossToRef(OO, KO, pO), pO
      }
      static CrossToRef(OO, KO, pO) {
        const XO = OO._y * KO._z - OO._z * KO._y,
          bK = OO._z * KO._x - OO._x * KO._z,
          eO = OO._x * KO._y - OO._y * KO._x;
        return pO.rvO(XO, bK, eO), pO
      }
      static Normalize(OO) {
        const KO = aK.Zero();
        return aK.NormalizeToRef(OO, KO), KO
      }
      static NormalizeToRef(OO, KO) {
        return OO.normalizeToRef(KO), KO
      }
      static Project(OO, KO, pO, XO) {
        const bK = new aK;
        return aK.ProjectToRef(OO, KO, pO, XO, bK), bK
      }
      static ProjectToRef(OO, KO, pO, XO, bK) {
        const eO = XO.width,
          vK = XO.height,
          CO = XO.x,
          hO = XO.y,
          DO = LO.Matrix[1],
          MO = lO.c.LastCreatedEngine?.isNDCHalfZRange,
          oO = MO ? 1 : .5,
          FO = MO ? 0 : .5;
        VO.FromValuesToRef(eO / 2, 0, 0, 0, 0, -vK / 2, 0, 0, 0, 0, oO, 0, CO + eO / 2, vK / 2 + hO, FO, 1, DO);
        const QO = LO.Matrix[0];
        return KO.multiplyToRef(pO, QO), QO.multiplyToRef(DO, QO), aK.TransformCoordinatesToRef(OO, QO, bK), bK
      }
      static Reflect(OO, KO) {
        return this.ReflectToRef(OO, KO, new aK)
      }
      static ReflectToRef(OO, KO, pO) {
        const XO = QO.WX[0];
        return XO.NhO(KO).scaleInPlace(2 * aK.Dot(OO, KO)), pO.NhO(OO).oDO(XO)
      }
      static UnprojectFromTransform(OO, KO, pO, XO, bK) {
        return this.Unproject(OO, KO, pO, XO, bK, VO.IdentityReadOnly)
      }
      static Unproject(OO, KO, pO, XO, bK, eO) {
        const lO = new aK;
        return aK.UnprojectToRef(OO, KO, pO, XO, bK, eO, lO), lO
      }
      static UnprojectToRef(OO, KO, pO, XO, bK, eO, lO) {
        return aK.UnprojectFloatsToRef(OO._x, OO._y, OO._z, KO, pO, XO, bK, eO, lO), lO
      }
      static UnprojectFloatsToRef(OO, KO, pO, XO, bK, eO, vK, CO, hO) {
        const DO = LO.Matrix[0];
        eO.multiplyToRef(vK, DO), DO.multiplyToRef(CO, DO), DO.invert();
        const MO = LO.WX[0];
        return MO.x = OO / XO * 2 - 1, MO.y = -(KO / bK * 2 - 1), lO.c.LastCreatedEngine?.isNDCHalfZRange ? MO.z = pO : MO.z = 2 * pO - 1, aK.TransformCoordinatesToRef(MO, DO, hO), hO
      }
      static Minimize(OO, KO) {
        const pO = new aK;
        return pO.NhO(OO), pO.minimizeInPlace(KO), pO
      }
      static Maximize(OO, KO) {
        const pO = new aK;
        return pO.NhO(OO), pO.maximizeInPlace(KO), pO
      }
      static Distance(OO, KO) {
        return Math.sqrt(aK.DistanceSquared(OO, KO))
      }
      static DistanceSquared(OO, KO) {
        const pO = OO._x - KO._x,
          XO = OO._y - KO._y,
          bK = OO._z - KO._z;
        return pO * pO + XO * XO + bK * bK
      }
      static ProjectOnTriangleToRef(OO, KO, pO, bK, eO) {
        const lO = LO.WX[0],
          CO = LO.WX[1],
          hO = LO.WX[2],
          DO = LO.WX[3],
          MO = LO.WX[4];
        pO.subtractToRef(KO, lO), bK.subtractToRef(KO, CO), bK.subtractToRef(pO, hO);
        const oO = lO.length(),
          FO = CO.length(),
          VO = hO.length();
        if (oO < XO.c || FO < XO.c || VO < XO.c) return eO.NhO(KO), aK.Distance(OO, KO);
        OO.subtractToRef(KO, MO), aK.CrossToRef(lO, CO, DO);
        const QO = DO.length();
        if (QO < XO.c) return eO.NhO(KO), aK.Distance(OO, KO);
        DO.normalizeFromLength(QO);
        let zK = MO.length();
        if (zK < XO.c) return eO.NhO(KO), 0;
        MO.normalizeFromLength(zK);
        const AO = aK.Dot(DO, MO),
          fO = LO.WX[5],
          dO = LO.WX[6];
        fO.NhO(DO).scaleInPlace(-zK * AO), dO.NhO(OO).addInPlace(fO);
        const TO = LO.WX[4],
          NO = LO.WX[5],
          IO = LO.WX[7],
          yK = LO.WX[8];
        TO.NhO(lO).scaleInPlace(1 / oO), yK.NhO(CO).scaleInPlace(1 / FO), TO.addInPlace(yK).scaleInPlace(-1), NO.NhO(lO).scaleInPlace(-1 / oO), yK.NhO(hO).scaleInPlace(1 / VO), NO.addInPlace(yK).scaleInPlace(-1), IO.NhO(hO).scaleInPlace(-1 / VO), yK.NhO(CO).scaleInPlace(-1 / FO), IO.addInPlace(yK).scaleInPlace(-1);
        const gK = LO.WX[9];
        let uO;
        gK.NhO(dO).oDO(KO), aK.CrossToRef(TO, gK, yK), uO = aK.Dot(yK, DO);
        const EO = uO;
        gK.NhO(dO).oDO(pO), aK.CrossToRef(NO, gK, yK), uO = aK.Dot(yK, DO);
        const jK = uO;
        gK.NhO(dO).oDO(bK), aK.CrossToRef(IO, gK, yK), uO = aK.Dot(yK, DO);
        const YO = uO,
          wO = LO.WX[10];
        let iK, rK;
        EO > 0 && jK < 0 ? (wO.NhO(lO), iK = KO, rK = pO) : jK > 0 && YO < 0 ? (wO.NhO(hO), iK = pO, rK = bK) : (wO.NhO(CO).scaleInPlace(-1), iK = bK, rK = KO);
        const PO = LO.WX[9],
          mK = LO.WX[4];
        iK.subtractToRef(dO, yK), rK.subtractToRef(dO, PO), aK.CrossToRef(yK, PO, mK);
        if (!(aK.Dot(mK, DO) < 0)) return eO.NhO(dO), Math.abs(zK * AO);
        const sO = LO.WX[5];
        aK.CrossToRef(wO, mK, sO), sO.normalize();
        const HO = LO.WX[9];
        HO.NhO(iK).oDO(dO);
        const RO = HO.length();
        if (RO < XO.c) return eO.NhO(iK), aK.Distance(OO, iK);
        HO.normalizeFromLength(RO);
        const SO = aK.Dot(sO, HO),
          JO = LO.WX[7];
        JO.NhO(dO).addInPlace(sO.scaleInPlace(RO * SO)), yK.NhO(JO).oDO(iK), zK = wO.length(), wO.normalizeFromLength(zK);
        let cK = aK.Dot(yK, wO) / Math.max(zK, XO.c);
        return cK = (0, vK.Clamp)(cK, 0, 1), JO.NhO(iK).addInPlace(wO.scaleInPlace(cK * zK)), eO.NhO(JO), aK.Distance(OO, JO)
      }
      static Center(OO, KO) {
        return aK.CenterToRef(OO, KO, aK.Zero())
      }
      static CenterToRef(OO, KO, pO) {
        return pO.rvO((OO._x + KO._x) / 2, (OO._y + KO._y) / 2, (OO._z + KO._z) / 2)
      }
      static RotationFromAxis(OO, KO, pO) {
        const XO = new aK;
        return aK.RotationFromAxisToRef(OO, KO, pO, XO), XO
      }
      static RotationFromAxisToRef(OO, KO, pO, XO) {
        const bK = LO.Quaternion[0];
        return FO.RotationQuaternionFromAxisToRef(OO, KO, pO, bK), bK.toEulerAnglesToRef(XO), XO
      }
    }
    aK._V8PerformanceHack = new aK(.5, .5, .5), aK._UpReadOnly = aK.Up(), aK._DownReadOnly = aK.Down(), aK._LeftHandedForwardReadOnly = aK.Forward(!1), aK._RightHandedForwardReadOnly = aK.Forward(!0), aK._LeftHandedBackwardReadOnly = aK.Backward(!1), aK._RightHandedBackwardReadOnly = aK.Backward(!0), aK._RightReadOnly = aK.Right(), aK._LeftReadOnly = aK.Left(), aK._ZeroReadOnly = aK.Zero(), aK._OneReadOnly = aK.One();
    class oO {
      get x() {
        return this._x
      }
      set x(OO) {
        this._x = OO, this._isDirty = !0
      }
      get y() {
        return this._y
      }
      set y(OO) {
        this._y = OO, this._isDirty = !0
      }
      get z() {
        return this._z
      }
      set z(OO) {
        this._z = OO, this._isDirty = !0
      }
      get w() {
        return this._w
      }
      set w(OO) {
        this._w = OO, this._isDirty = !0
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        this._isDirty = !0, this._x = OO, this._y = KO, this._z = pO, this._w = XO
      }
      toString() {
        return `{X: ${this._x} Y: ${this._y} Z: ${this._z} W: ${this._w}}`
      }
      getClassName() {
        return "Vector4"
      }
      getHashCode() {
        let OO = DO(this._x);
        return OO = 397 * OO ^ DO(this._y), OO = 397 * OO ^ DO(this._z), OO = 397 * OO ^ DO(this._w), OO
      }
      WhO() {
        return [this._x, this._y, this._z, this._w]
      }
      toArray(OO, KO) {
        return void 0 === KO && (KO = 0), OO[KO] = this._x, OO[KO + 1] = this._y, OO[KO + 2] = this._z, OO[KO + 3] = this._w, this
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return oO.FromArrayToRef(OO, KO, this), this
      }
      addInPlace(OO) {
        return this.x += OO._x, this.y += OO._y, this.z += OO._z, this.w += OO._w, this
      }
      addInPlaceFromFloats(OO, KO, pO, XO) {
        return this.x += OO, this.y += KO, this.z += pO, this.w += XO, this
      }
      add(OO) {
        return new oO(this._x + OO.x, this._y + OO.y, this._z + OO.z, this._w + OO.w)
      }
      addToRef(OO, KO) {
        return KO.x = this._x + OO.x, KO.y = this._y + OO.y, KO.z = this._z + OO.z, KO.w = this._w + OO.w, KO
      }
      oDO(OO) {
        return this.x -= OO.x, this.y -= OO.y, this.z -= OO.z, this.w -= OO.w, this
      }
      subtract(OO) {
        return new oO(this._x - OO.x, this._y - OO.y, this._z - OO.z, this._w - OO.w)
      }
      subtractToRef(OO, KO) {
        return KO.x = this._x - OO.x, KO.y = this._y - OO.y, KO.z = this._z - OO.z, KO.w = this._w - OO.w, KO
      }
      subtractFromFloats(OO, KO, pO, XO) {
        return new oO(this._x - OO, this._y - KO, this._z - pO, this._w - XO)
      }
      subtractFromFloatsToRef(OO, KO, pO, XO, bK) {
        return bK.x = this._x - OO, bK.y = this._y - KO, bK.z = this._z - pO, bK.w = this._w - XO, bK
      }
      hl() {
        return new oO(-this._x, -this._y, -this._z, -this._w)
      }
      negateInPlace() {
        return this.x *= -1, this.y *= -1, this.z *= -1, this.w *= -1, this
      }
      negateToRef(OO) {
        return OO.x = -this._x, OO.y = -this._y, OO.z = -this._z, OO.w = -this._w, OO
      }
      scaleInPlace(OO) {
        return this.x *= OO, this.y *= OO, this.z *= OO, this.w *= OO, this
      }
      scale(OO) {
        return new oO(this._x * OO, this._y * OO, this._z * OO, this._w * OO)
      }
      scaleToRef(OO, KO) {
        return KO.x = this._x * OO, KO.y = this._y * OO, KO.z = this._z * OO, KO.w = this._w * OO, KO
      }
      scaleAndAddToRef(OO, KO) {
        return KO.x += this._x * OO, KO.y += this._y * OO, KO.z += this._z * OO, KO.w += this._w * OO, KO
      }
      equals(OO) {
        return OO && this._x === OO.x && this._y === OO.y && this._z === OO.z && this._w === OO.w
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : XO.c;
        return OO && (0, vK.WithinEpsilon)(this._x, OO.x, KO) && (0, vK.WithinEpsilon)(this._y, OO.y, KO) && (0, vK.WithinEpsilon)(this._z, OO.z, KO) && (0, vK.WithinEpsilon)(this._w, OO.w, KO)
      }
      soO(OO, KO, pO, XO) {
        return this._x === OO && this._y === KO && this._z === pO && this._w === XO
      }
      multiplyInPlace(OO) {
        return this.x *= OO.x, this.y *= OO.y, this.z *= OO.z, this.w *= OO.w, this
      }
      multiply(OO) {
        return new oO(this._x * OO.x, this._y * OO.y, this._z * OO.z, this._w * OO.w)
      }
      multiplyToRef(OO, KO) {
        return KO.x = this._x * OO.x, KO.y = this._y * OO.y, KO.z = this._z * OO.z, KO.w = this._w * OO.w, KO
      }
      multiplyByFloats(OO, KO, pO, XO) {
        return new oO(this._x * OO, this._y * KO, this._z * pO, this._w * XO)
      }
      divide(OO) {
        return new oO(this._x / OO.x, this._y / OO.y, this._z / OO.z, this._w / OO.w)
      }
      divideToRef(OO, KO) {
        return KO.x = this._x / OO.x, KO.y = this._y / OO.y, KO.z = this._z / OO.z, KO.w = this._w / OO.w, KO
      }
      divideInPlace(OO) {
        return this.divideToRef(OO, this)
      }
      minimizeInPlace(OO) {
        return OO.x < this._x && (this.x = OO.x), OO.y < this._y && (this.y = OO.y), OO.z < this._z && (this.z = OO.z), OO.w < this._w && (this.w = OO.w), this
      }
      maximizeInPlace(OO) {
        return OO.x > this._x && (this.x = OO.x), OO.y > this._y && (this.y = OO.y), OO.z > this._z && (this.z = OO.z), OO.w > this._w && (this.w = OO.w), this
      }
      minimizeInPlaceFromFloats(OO, KO, pO, XO) {
        return this.x = Math.min(OO, this._x), this.y = Math.min(KO, this._y), this.z = Math.min(pO, this._z), this.w = Math.min(XO, this._w), this
      }
      maximizeInPlaceFromFloats(OO, KO, pO, XO) {
        return this.x = Math.max(OO, this._x), this.y = Math.max(KO, this._y), this.z = Math.max(pO, this._z), this.w = Math.max(XO, this._w), this
      }
      floorToRef(OO) {
        return OO.x = Math.floor(this._x), OO.y = Math.floor(this._y), OO.z = Math.floor(this._z), OO.w = Math.floor(this._w), OO
      }
      floor() {
        return new oO(Math.floor(this._x), Math.floor(this._y), Math.floor(this._z), Math.floor(this._w))
      }
      fractToRef(OO) {
        return OO.x = this._x - Math.floor(this._x), OO.y = this._y - Math.floor(this._y), OO.z = this._z - Math.floor(this._z), OO.w = this._w - Math.floor(this._w), OO
      }
      fract() {
        return new oO(this._x - Math.floor(this._x), this._y - Math.floor(this._y), this._z - Math.floor(this._z), this._w - Math.floor(this._w))
      }
      length() {
        return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w)
      }
      lengthSquared() {
        return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w
      }
      normalize() {
        return this.normalizeFromLength(this.length())
      }
      normalizeFromLength(OO) {
        return 0 === OO || 1 === OO ? this : this.scaleInPlace(1 / OO)
      }
      normalizeToNew() {
        return this.normalizeToRef(new oO)
      }
      normalizeToRef(OO) {
        const KO = this.length();
        return 0 === KO || 1 === KO ? (OO.x = this._x, OO.y = this._y, OO.z = this._z, OO.w = this._w, OO) : this.scaleToRef(1 / KO, OO)
      }
      toVector3() {
        return new aK(this._x, this._y, this._z)
      }
      clone() {
        return new oO(this._x, this._y, this._z, this._w)
      }
      NhO(OO) {
        return this.x = OO.x, this.y = OO.y, this.z = OO.z, this.w = OO.w, this
      }
      rvO(OO, KO, pO, XO) {
        return this.x = OO, this.y = KO, this.z = pO, this.w = XO, this
      }
      set(OO, KO, pO, XO) {
        return this.rvO(OO, KO, pO, XO)
      }
      plO(OO) {
        return this.x = this.y = this.z = this.w = OO, this
      }
      dot(OO) {
        return this._x * OO.x + this._y * OO.y + this._z * OO.z + this._w * OO.w
      }
      static FromArray(OO, KO) {
        return KO || (KO = 0), new oO(OO[KO], OO[KO + 1], OO[KO + 2], OO[KO + 3])
      }
      static FromArrayToRef(OO, KO, pO) {
        return pO.x = OO[KO], pO.y = OO[KO + 1], pO.z = OO[KO + 2], pO.w = OO[KO + 3], pO
      }
      static FromFloatArrayToRef(OO, KO, pO) {
        return oO.FromArrayToRef(OO, KO, pO), pO
      }
      static FromFloatsToRef(OO, KO, pO, XO, bK) {
        return bK.x = OO, bK.y = KO, bK.z = pO, bK.w = XO, bK
      }
      static Zero() {
        return new oO(0, 0, 0, 0)
      }
      static One() {
        return new oO(1, 1, 1, 1)
      }
      static Random() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return new oO((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static RandomToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        return pO.x = (0, vK.RandomRange)(OO, KO), pO.y = (0, vK.RandomRange)(OO, KO), pO.z = (0, vK.RandomRange)(OO, KO), pO.w = (0, vK.RandomRange)(OO, KO), pO
      }
      static Clamp(OO, KO, pO) {
        return oO.ClampToRef(OO, KO, pO, new oO)
      }
      static ClampToRef(OO, KO, pO, XO) {
        return XO.x = (0, vK.Clamp)(OO.x, KO.x, pO.x), XO.y = (0, vK.Clamp)(OO.y, KO.y, pO.y), XO.z = (0, vK.Clamp)(OO.z, KO.z, pO.z), XO.w = (0, vK.Clamp)(OO.w, KO.w, pO.w), XO
      }
      static CheckExtends(OO, KO, pO) {
        KO.minimizeInPlace(OO), pO.maximizeInPlace(OO)
      }
      static get ZeroReadOnly() {
        return oO._ZeroReadOnly
      }
      static Normalize(OO) {
        return oO.NormalizeToRef(OO, new oO)
      }
      static NormalizeToRef(OO, KO) {
        return OO.normalizeToRef(KO), KO
      }
      static Minimize(OO, KO) {
        const pO = new oO;
        return pO.NhO(OO), pO.minimizeInPlace(KO), pO
      }
      static Maximize(OO, KO) {
        const pO = new oO;
        return pO.NhO(OO), pO.maximizeInPlace(KO), pO
      }
      static Distance(OO, KO) {
        return Math.sqrt(oO.DistanceSquared(OO, KO))
      }
      static DistanceSquared(OO, KO) {
        const pO = OO.x - KO.x,
          XO = OO.y - KO.y,
          bK = OO.z - KO.z,
          eO = OO.w - KO.w;
        return pO * pO + XO * XO + bK * bK + eO * eO
      }
      static Center(OO, KO) {
        return oO.CenterToRef(OO, KO, new oO)
      }
      static CenterToRef(OO, KO, pO) {
        return pO.x = (OO.x + KO.x) / 2, pO.y = (OO.y + KO.y) / 2, pO.z = (OO.z + KO.z) / 2, pO.w = (OO.w + KO.w) / 2, pO
      }
      static TransformCoordinates(OO, KO) {
        return oO.TransformCoordinatesToRef(OO, KO, new oO)
      }
      static TransformCoordinatesToRef(OO, KO, pO) {
        return oO.TransformCoordinatesFromFloatsToRef(OO._x, OO._y, OO._z, KO, pO), pO
      }
      static TransformCoordinatesFromFloatsToRef(OO, KO, pO, XO, bK) {
        const eO = XO.m,
          lO = OO * eO[0] + KO * eO[4] + pO * eO[8] + eO[12],
          vK = OO * eO[1] + KO * eO[5] + pO * eO[9] + eO[13],
          CO = OO * eO[2] + KO * eO[6] + pO * eO[10] + eO[14],
          hO = OO * eO[3] + KO * eO[7] + pO * eO[11] + eO[15];
        return bK.x = lO, bK.y = vK, bK.z = CO, bK.w = hO, bK
      }
      static TransformNormal(OO, KO) {
        return oO.TransformNormalToRef(OO, KO, new oO)
      }
      static TransformNormalToRef(OO, KO, pO) {
        const XO = KO.m,
          bK = OO.x * XO[0] + OO.y * XO[4] + OO.z * XO[8],
          eO = OO.x * XO[1] + OO.y * XO[5] + OO.z * XO[9],
          lO = OO.x * XO[2] + OO.y * XO[6] + OO.z * XO[10];
        return pO.x = bK, pO.y = eO, pO.z = lO, pO.w = OO.w, pO
      }
      static TransformNormalFromFloatsToRef(OO, KO, pO, XO, bK, eO) {
        const lO = bK.m;
        return eO.x = OO * lO[0] + KO * lO[4] + pO * lO[8], eO.y = OO * lO[1] + KO * lO[5] + pO * lO[9], eO.z = OO * lO[2] + KO * lO[6] + pO * lO[10], eO.w = XO, eO
      }
      static FromVector3(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return new oO(OO._x, OO._y, OO._z, KO)
      }
      static Dot(OO, KO) {
        return OO.x * KO.x + OO.y * KO.y + OO.z * KO.z + OO.w * KO.w
      }
    }
    oO._V8PerformanceHack = new oO(.5, .5, .5, .5), oO._ZeroReadOnly = oO.Zero();
    class FO {
      get x() {
        return this._x
      }
      set x(OO) {
        this._x = OO, this._isDirty = !0
      }
      get y() {
        return this._y
      }
      set y(OO) {
        this._y = OO, this._isDirty = !0
      }
      get z() {
        return this._z
      }
      set z(OO) {
        this._z = OO, this._isDirty = !0
      }
      get w() {
        return this._w
      }
      set w(OO) {
        this._w = OO, this._isDirty = !0
      }
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
          XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1;
        this._isDirty = !0, this._x = OO, this._y = KO, this._z = pO, this._w = XO
      }
      toString() {
        return `{X: ${this._x} Y: ${this._y} Z: ${this._z} W: ${this._w}}`
      }
      getClassName() {
        return "Quaternion"
      }
      getHashCode() {
        let OO = DO(this._x);
        return OO = 397 * OO ^ DO(this._y), OO = 397 * OO ^ DO(this._z), OO = 397 * OO ^ DO(this._w), OO
      }
      WhO() {
        return [this._x, this._y, this._z, this._w]
      }
      toArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return OO[KO] = this._x, OO[KO + 1] = this._y, OO[KO + 2] = this._z, OO[KO + 3] = this._w, this
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return FO.FromArrayToRef(OO, KO, this)
      }
      equals(OO) {
        return OO && this._x === OO._x && this._y === OO._y && this._z === OO._z && this._w === OO._w
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : XO.c;
        return OO && (0, vK.WithinEpsilon)(this._x, OO._x, KO) && (0, vK.WithinEpsilon)(this._y, OO._y, KO) && (0, vK.WithinEpsilon)(this._z, OO._z, KO) && (0, vK.WithinEpsilon)(this._w, OO._w, KO)
      }
      isApprox(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : XO.c;
        return OO && ((0, vK.WithinEpsilon)(this._x, OO._x, KO) && (0, vK.WithinEpsilon)(this._y, OO._y, KO) && (0, vK.WithinEpsilon)(this._z, OO._z, KO) && (0, vK.WithinEpsilon)(this._w, OO._w, KO) || (0, vK.WithinEpsilon)(this._x, -OO._x, KO) && (0, vK.WithinEpsilon)(this._y, -OO._y, KO) && (0, vK.WithinEpsilon)(this._z, -OO._z, KO) && (0, vK.WithinEpsilon)(this._w, -OO._w, KO))
      }
      clone() {
        return new FO(this._x, this._y, this._z, this._w)
      }
      NhO(OO) {
        return this._x = OO._x, this._y = OO._y, this._z = OO._z, this._w = OO._w, this._isDirty = !0, this
      }
      rvO(OO, KO, pO, XO) {
        return this._x = OO, this._y = KO, this._z = pO, this._w = XO, this._isDirty = !0, this
      }
      set(OO, KO, pO, XO) {
        return this.rvO(OO, KO, pO, XO)
      }
      plO(OO) {
        return this.rvO(OO, OO, OO, OO)
      }
      add(OO) {
        return new FO(this._x + OO._x, this._y + OO._y, this._z + OO._z, this._w + OO._w)
      }
      addInPlace(OO) {
        return this._x += OO._x, this._y += OO._y, this._z += OO._z, this._w += OO._w, this._isDirty = !0, this
      }
      addToRef(OO, KO) {
        return KO._x = this._x + OO._x, KO._y = this._y + OO._y, KO._z = this._z + OO._z, KO._w = this._w + OO._w, KO._isDirty = !0, KO
      }
      addInPlaceFromFloats(OO, KO, pO, XO) {
        return this._x += OO, this._y += KO, this._z += pO, this._w += XO, this._isDirty = !0, this
      }
      subtractToRef(OO, KO) {
        return KO._x = this._x - OO._x, KO._y = this._y - OO._y, KO._z = this._z - OO._z, KO._w = this._w - OO._w, KO._isDirty = !0, KO
      }
      subtractFromFloats(OO, KO, pO, XO) {
        return this.subtractFromFloatsToRef(OO, KO, pO, XO, new FO)
      }
      subtractFromFloatsToRef(OO, KO, pO, XO, bK) {
        return bK._x = this._x - OO, bK._y = this._y - KO, bK._z = this._z - pO, bK._w = this._w - XO, bK._isDirty = !0, bK
      }
      subtract(OO) {
        return new FO(this._x - OO._x, this._y - OO._y, this._z - OO._z, this._w - OO._w)
      }
      oDO(OO) {
        return this._x -= OO._x, this._y -= OO._y, this._z -= OO._z, this._w -= OO._w, this._isDirty = !0, this
      }
      scale(OO) {
        return new FO(this._x * OO, this._y * OO, this._z * OO, this._w * OO)
      }
      scaleToRef(OO, KO) {
        return KO._x = this._x * OO, KO._y = this._y * OO, KO._z = this._z * OO, KO._w = this._w * OO, KO._isDirty = !0, KO
      }
      scaleInPlace(OO) {
        return this._x *= OO, this._y *= OO, this._z *= OO, this._w *= OO, this._isDirty = !0, this
      }
      scaleAndAddToRef(OO, KO) {
        return KO._x += this._x * OO, KO._y += this._y * OO, KO._z += this._z * OO, KO._w += this._w * OO, KO._isDirty = !0, KO
      }
      multiply(OO) {
        const KO = new FO(0, 0, 0, 1);
        return this.multiplyToRef(OO, KO), KO
      }
      multiplyToRef(OO, KO) {
        const pO = this._x * OO._w + this._y * OO._z - this._z * OO._y + this._w * OO._x,
          XO = -this._x * OO._z + this._y * OO._w + this._z * OO._x + this._w * OO._y,
          bK = this._x * OO._y - this._y * OO._x + this._z * OO._w + this._w * OO._z,
          eO = -this._x * OO._x - this._y * OO._y - this._z * OO._z + this._w * OO._w;
        return KO.rvO(pO, XO, bK, eO), KO
      }
      multiplyInPlace(OO) {
        return this.multiplyToRef(OO, this)
      }
      multiplyByFloats(OO, KO, pO, XO) {
        return this._x *= OO, this._y *= KO, this._z *= pO, this._w *= XO, this._isDirty = !0, this
      }
      divide(OO) {
        throw new ReferenceError("Can not divide a quaternion")
      }
      divideToRef(OO, KO) {
        throw new ReferenceError("Can not divide a quaternion")
      }
      divideInPlace(OO) {
        throw new ReferenceError("Can not divide a quaternion")
      }
      minimizeInPlace() {
        throw new ReferenceError("Can not minimize a quaternion")
      }
      minimizeInPlaceFromFloats() {
        throw new ReferenceError("Can not minimize a quaternion")
      }
      maximizeInPlace() {
        throw new ReferenceError("Can not maximize a quaternion")
      }
      maximizeInPlaceFromFloats() {
        throw new ReferenceError("Can not maximize a quaternion")
      }
      hl() {
        return this.negateToRef(new FO)
      }
      negateInPlace() {
        return this._x = -this._x, this._y = -this._y, this._z = -this._z, this._w = -this._w, this._isDirty = !0, this
      }
      negateToRef(OO) {
        return OO._x = -this._x, OO._y = -this._y, OO._z = -this._z, OO._w = -this._w, OO._isDirty = !0, OO
      }
      soO(OO, KO, pO, XO) {
        return this._x === OO && this._y === KO && this._z === pO && this._w === XO
      }
      floorToRef(OO) {
        throw new ReferenceError("Can not floor a quaternion")
      }
      floor() {
        throw new ReferenceError("Can not floor a quaternion")
      }
      fractToRef(OO) {
        throw new ReferenceError("Can not fract a quaternion")
      }
      fract() {
        throw new ReferenceError("Can not fract a quaternion")
      }
      conjugateToRef(OO) {
        return OO.rvO(-this._x, -this._y, -this._z, this._w), OO
      }
      conjugateInPlace() {
        return this._x *= -1, this._y *= -1, this._z *= -1, this._isDirty = !0, this
      }
      conjugate() {
        return new FO(-this._x, -this._y, -this._z, this._w)
      }
      invert() {
        const OO = this.conjugate(),
          KO = this.lengthSquared();
        return 0 == KO || 1 == KO || OO.scaleInPlace(1 / KO), OO
      }
      invertInPlace() {
        this.conjugateInPlace();
        const OO = this.lengthSquared();
        return 0 == OO || 1 == OO || this.scaleInPlace(1 / OO), this
      }
      lengthSquared() {
        return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w
      }
      length() {
        return Math.sqrt(this.lengthSquared())
      }
      normalize() {
        return this.normalizeFromLength(this.length())
      }
      normalizeFromLength(OO) {
        return 0 === OO || 1 === OO ? this : this.scaleInPlace(1 / OO)
      }
      normalizeToNew() {
        const OO = new FO(0, 0, 0, 1);
        return this.normalizeToRef(OO), OO
      }
      normalizeToRef(OO) {
        const KO = this.length();
        return 0 === KO || 1 === KO ? OO.rvO(this._x, this._y, this._z, this._w) : this.scaleToRef(1 / KO, OO)
      }
      toEulerAngles() {
        const OO = aK.Zero();
        return this.toEulerAnglesToRef(OO), OO
      }
      toEulerAnglesToRef(OO) {
        const KO = this._z,
          pO = this._x,
          XO = this._y,
          bK = this._w,
          eO = XO * KO - pO * bK,
          lO = .4999999;
        if (eO < -lO) OO._y = 2 * Math.atan2(XO, bK), OO._x = Math.PI / 2, OO._z = 0, OO._isDirty = !0;
        else if (eO > lO) OO._y = 2 * Math.atan2(XO, bK), OO._x = -Math.PI / 2, OO._z = 0, OO._isDirty = !0;
        else {
          const lO = bK * bK,
            vK = KO * KO,
            CO = pO * pO,
            hO = XO * XO;
          OO._z = Math.atan2(2 * (pO * XO + KO * bK), -vK - CO + hO + lO), OO._x = Math.asin(-2 * eO), OO._y = Math.atan2(2 * (KO * pO + XO * bK), vK - CO - hO + lO), OO._isDirty = !0
        }
        return OO
      }
      toAlphaBetaGammaToRef(OO) {
        const KO = this._z,
          pO = this._x,
          XO = this._y,
          bK = this._w,
          eO = Math.sqrt(pO * pO + XO * XO),
          lO = Math.sqrt(KO * KO + bK * bK),
          vK = 2 * Math.atan2(eO, lO),
          CO = 2 * Math.atan2(KO, bK),
          hO = 2 * Math.atan2(XO, pO),
          DO = (CO + hO) / 2,
          MO = (CO - hO) / 2;
        return OO.set(MO, vK, DO), OO
      }
      toRotationMatrix(OO) {
        return VO.FromQuaternionToRef(this, OO), OO
      }
      fromRotationMatrix(OO) {
        return FO.FromRotationMatrixToRef(OO, this), this
      }
      dot(OO) {
        return this._x * OO._x + this._y * OO._y + this._z * OO._z + this._w * OO._w
      }
      toAxisAngle() {
        const OO = aK.Zero();
        return {
          axis: OO,
          angle: this.toAxisAngleToRef(OO)
        }
      }
      toAxisAngleToRef(OO) {
        let KO;
        const pO = Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z),
          XO = this._w;
        return pO > 0 ? (KO = 2 * Math.atan2(pO, XO), OO.set(this._x / pO, this._y / pO, this._z / pO)) : (KO = 0, OO.set(1, 0, 0)), KO
      }
      static FromRotationMatrix(OO) {
        const KO = new FO;
        return FO.FromRotationMatrixToRef(OO, KO), KO
      }
      static FromRotationMatrixToRef(OO, KO) {
        const pO = OO.m,
          XO = pO[0],
          bK = pO[4],
          eO = pO[8],
          lO = pO[1],
          vK = pO[5],
          CO = pO[9],
          hO = pO[2],
          DO = pO[6],
          MO = pO[10],
          aK = XO + vK + MO;
        let oO;
        return aK > 0 ? (oO = .5 / Math.sqrt(aK + 1), KO._w = .25 / oO, KO._x = (DO - CO) * oO, KO._y = (eO - hO) * oO, KO._z = (lO - bK) * oO, KO._isDirty = !0) : XO > vK && XO > MO ? (oO = 2 * Math.sqrt(1 + XO - vK - MO), KO._w = (DO - CO) / oO, KO._x = .25 * oO, KO._y = (bK + lO) / oO, KO._z = (eO + hO) / oO, KO._isDirty = !0) : vK > MO ? (oO = 2 * Math.sqrt(1 + vK - XO - MO), KO._w = (eO - hO) / oO, KO._x = (bK + lO) / oO, KO._y = .25 * oO, KO._z = (CO + DO) / oO, KO._isDirty = !0) : (oO = 2 * Math.sqrt(1 + MO - XO - vK), KO._w = (lO - bK) / oO, KO._x = (eO + hO) / oO, KO._y = (CO + DO) / oO, KO._z = .25 * oO, KO._isDirty = !0), KO
      }
      static Dot(OO, KO) {
        return OO._x * KO._x + OO._y * KO._y + OO._z * KO._z + OO._w * KO._w
      }
      static AreClose(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : .1;
        const XO = FO.Dot(OO, KO);
        return 1 - XO * XO <= pO
      }
      static SmoothToRef(OO, KO, pO, XO, bK) {
        let eO = 0 === XO ? 1 : pO / XO;
        return eO = (0, vK.Clamp)(eO, 0, 1), FO.SlerpToRef(OO, KO, eO, bK), bK
      }
      static Zero() {
        return new FO(0, 0, 0, 0)
      }
      static Inverse(OO) {
        return new FO(-OO._x, -OO._y, -OO._z, OO._w)
      }
      static InverseToRef(OO, KO) {
        return KO.set(-OO._x, -OO._y, -OO._z, OO._w), KO
      }
      static Identity() {
        return new FO(0, 0, 0, 1)
      }
      static IsIdentity(OO) {
        return OO && 0 === OO._x && 0 === OO._y && 0 === OO._z && 1 === OO._w
      }
      static RotationAxis(OO, KO) {
        return FO.RotationAxisToRef(OO, KO, new FO)
      }
      static RotationAxisToRef(OO, KO, pO) {
        pO._w = Math.cos(KO / 2);
        const XO = Math.sin(KO / 2) / OO.length();
        return pO._x = OO._x * XO, pO._y = OO._y * XO, pO._z = OO._z * XO, pO._isDirty = !0, pO
      }
      static FromArray(OO, KO) {
        return KO || (KO = 0), new FO(OO[KO], OO[KO + 1], OO[KO + 2], OO[KO + 3])
      }
      static FromArrayToRef(OO, KO, pO) {
        return pO._x = OO[KO], pO._y = OO[KO + 1], pO._z = OO[KO + 2], pO._w = OO[KO + 3], pO._isDirty = !0, pO
      }
      static FromFloatsToRef(OO, KO, pO, XO, bK) {
        return bK.rvO(OO, KO, pO, XO), bK
      }
      static FromEulerAngles(OO, KO, pO) {
        const XO = new FO;
        return FO.RotationYawPitchRollToRef(KO, OO, pO, XO), XO
      }
      static FromEulerAnglesToRef(OO, KO, pO, XO) {
        return FO.RotationYawPitchRollToRef(KO, OO, pO, XO), XO
      }
      static FromEulerVector(OO) {
        const KO = new FO;
        return FO.RotationYawPitchRollToRef(OO._y, OO._x, OO._z, KO), KO
      }
      static FromEulerVectorToRef(OO, KO) {
        return FO.RotationYawPitchRollToRef(OO._y, OO._x, OO._z, KO), KO
      }
      static FromUnitVectorsToRef(OO, KO, pO) {
        let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : XO.c;
        const eO = aK.Dot(OO, KO) + 1;
        return eO < bK ? Math.abs(OO.x) > Math.abs(OO.z) ? pO.set(-OO.y, OO.x, 0, 0) : pO.set(0, -OO.z, OO.y, 0) : (aK.CrossToRef(OO, KO, QO.WX[0]), pO.set(QO.WX[0].x, QO.WX[0].y, QO.WX[0].z, eO)), pO.normalize()
      }
      static RotationYawPitchRoll(OO, KO, pO) {
        const XO = new FO;
        return FO.RotationYawPitchRollToRef(OO, KO, pO, XO), XO
      }
      static RotationYawPitchRollToRef(OO, KO, pO, XO) {
        const bK = .5 * pO,
          eO = .5 * KO,
          lO = .5 * OO,
          vK = Math.sin(bK),
          CO = Math.cos(bK),
          hO = Math.sin(eO),
          DO = Math.cos(eO),
          MO = Math.sin(lO),
          aK = Math.cos(lO);
        return XO._x = aK * hO * CO + MO * DO * vK, XO._y = MO * DO * CO - aK * hO * vK, XO._z = aK * DO * vK - MO * hO * CO, XO._w = aK * DO * CO + MO * hO * vK, XO._isDirty = !0, XO
      }
      static RotationAlphaBetaGamma(OO, KO, pO) {
        const XO = new FO;
        return FO.RotationAlphaBetaGammaToRef(OO, KO, pO, XO), XO
      }
      static RotationAlphaBetaGammaToRef(OO, KO, pO, XO) {
        const bK = .5 * (pO + OO),
          eO = .5 * (pO - OO),
          lO = .5 * KO;
        return XO._x = Math.cos(eO) * Math.sin(lO), XO._y = Math.sin(eO) * Math.sin(lO), XO._z = Math.sin(bK) * Math.cos(lO), XO._w = Math.cos(bK) * Math.cos(lO), XO._isDirty = !0, XO
      }
      static RotationQuaternionFromAxis(OO, KO, pO) {
        const XO = new FO(0, 0, 0, 0);
        return FO.RotationQuaternionFromAxisToRef(OO, KO, pO, XO), XO
      }
      static RotationQuaternionFromAxisToRef(OO, KO, pO, XO) {
        const bK = LO.Matrix[0];
        return OO = OO.normalizeToRef(LO.WX[0]), KO = KO.normalizeToRef(LO.WX[1]), pO = pO.normalizeToRef(LO.WX[2]), VO.FromXYZAxesToRef(OO, KO, pO, bK), FO.FromRotationMatrixToRef(bK, XO), XO
      }
      static FromLookDirectionLH(OO, KO) {
        const pO = new FO;
        return FO.FromLookDirectionLHToRef(OO, KO, pO), pO
      }
      static FromLookDirectionLHToRef(OO, KO, pO) {
        const XO = LO.Matrix[0];
        return VO.LookDirectionLHToRef(OO, KO, XO), FO.FromRotationMatrixToRef(XO, pO), pO
      }
      static FromLookDirectionRH(OO, KO) {
        const pO = new FO;
        return FO.FromLookDirectionRHToRef(OO, KO, pO), pO
      }
      static FromLookDirectionRHToRef(OO, KO, pO) {
        const XO = LO.Matrix[0];
        return VO.LookDirectionRHToRef(OO, KO, XO), FO.FromRotationMatrixToRef(XO, pO)
      }
      static Slerp(OO, KO, pO) {
        const XO = FO.Identity();
        return FO.SlerpToRef(OO, KO, pO, XO), XO
      }
      static SlerpToRef(OO, KO, pO, XO) {
        let bK, eO, lO = OO._x * KO._x + OO._y * KO._y + OO._z * KO._z + OO._w * KO._w,
          vK = !1;
        if (lO < 0 && (vK = !0, lO = -lO), lO > .999999) eO = 1 - pO, bK = vK ? -pO : pO;
        else {
          const OO = Math.acos(lO),
            KO = 1 / Math.sin(OO);
          eO = Math.sin((1 - pO) * OO) * KO, bK = vK ? -Math.sin(pO * OO) * KO : Math.sin(pO * OO) * KO
        }
        return XO._x = eO * OO._x + bK * KO._x, XO._y = eO * OO._y + bK * KO._y, XO._z = eO * OO._z + bK * KO._z, XO._w = eO * OO._w + bK * KO._w, XO._isDirty = !0, XO
      }
      static Hermite(OO, KO, pO, XO, bK) {
        const eO = bK * bK,
          lO = bK * eO,
          vK = 2 * lO - 3 * eO + 1,
          CO = -2 * lO + 3 * eO,
          hO = lO - 2 * eO + bK,
          DO = lO - eO,
          MO = OO._x * vK + pO._x * CO + KO._x * hO + XO._x * DO,
          aK = OO._y * vK + pO._y * CO + KO._y * hO + XO._y * DO,
          oO = OO._z * vK + pO._z * CO + KO._z * hO + XO._z * DO,
          VO = OO._w * vK + pO._w * CO + KO._w * hO + XO._w * DO;
        return new FO(MO, aK, oO, VO)
      }
      static Hermite1stDerivative(OO, KO, pO, XO, bK) {
        const eO = new FO;
        return this.Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO), eO
      }
      static Hermite1stDerivativeToRef(OO, KO, pO, XO, bK, eO) {
        const lO = bK * bK;
        return eO._x = 6 * (lO - bK) * OO._x + (3 * lO - 4 * bK + 1) * KO._x + 6 * (-lO + bK) * pO._x + (3 * lO - 2 * bK) * XO._x, eO._y = 6 * (lO - bK) * OO._y + (3 * lO - 4 * bK + 1) * KO._y + 6 * (-lO + bK) * pO._y + (3 * lO - 2 * bK) * XO._y, eO._z = 6 * (lO - bK) * OO._z + (3 * lO - 4 * bK + 1) * KO._z + 6 * (-lO + bK) * pO._z + (3 * lO - 2 * bK) * XO._z, eO._w = 6 * (lO - bK) * OO._w + (3 * lO - 4 * bK + 1) * KO._w + 6 * (-lO + bK) * pO._w + (3 * lO - 2 * bK) * XO._w, eO._isDirty = !0, eO
      }
      static Normalize(OO) {
        const KO = FO.Zero();
        return FO.NormalizeToRef(OO, KO), KO
      }
      static NormalizeToRef(OO, KO) {
        return OO.normalizeToRef(KO), KO
      }
      static Clamp(OO, KO, pO) {
        const XO = new FO;
        return FO.ClampToRef(OO, KO, pO, XO), XO
      }
      static ClampToRef(OO, KO, pO, XO) {
        return XO.rvO((0, vK.Clamp)(OO.x, KO.x, pO.x), (0, vK.Clamp)(OO.y, KO.y, pO.y), (0, vK.Clamp)(OO.z, KO.z, pO.z), (0, vK.Clamp)(OO.w, KO.w, pO.w))
      }
      static Random() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return new FO((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static RandomToRef() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        return (arguments.length > 2 ? arguments[2] : void 0).rvO((0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO), (0, vK.RandomRange)(OO, KO))
      }
      static Minimize() {
        throw new ReferenceError("Quaternion.Minimize does not make sense")
      }
      static Maximize() {
        throw new ReferenceError("Quaternion.Maximize does not make sense")
      }
      static Distance(OO, KO) {
        return Math.sqrt(FO.DistanceSquared(OO, KO))
      }
      static DistanceSquared(OO, KO) {
        const pO = OO.x - KO.x,
          XO = OO.y - KO.y,
          bK = OO.z - KO.z,
          eO = OO.w - KO.w;
        return pO * pO + XO * XO + bK * bK + eO * eO
      }
      static Center(OO, KO) {
        return FO.CenterToRef(OO, KO, FO.Zero())
      }
      static CenterToRef(OO, KO, pO) {
        return pO.rvO((OO.x + KO.x) / 2, (OO.y + KO.y) / 2, (OO.z + KO.z) / 2, (OO.w + KO.w) / 2)
      }
    }
    FO._V8PerformanceHack = new FO(.5, .5, .5, .5);
    class VO {
      static get Use64Bits() {
        return eO.b.MatrixUse64Bits
      }
      get m() {
        return this._m
      }
      markAsUpdated() {
        this.updateFlag = CO.h._UpdateFlagSeed++, this._isIdentity = !1, this._isIdentity3x2 = !1, this._isIdentityDirty = !0, this._isIdentity3x2Dirty = !0
      }
      _updateIdentityStatus(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          XO = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
        this._isIdentity = OO, this._isIdentity3x2 = OO || pO, this._isIdentityDirty = !this._isIdentity && KO, this._isIdentity3x2Dirty = !this._isIdentity3x2 && XO
      }
      constructor() {
        this._isIdentity = !1, this._isIdentityDirty = !0, this._isIdentity3x2 = !0, this._isIdentity3x2Dirty = !0, this.updateFlag = -1, eO.b.MatrixTrackPrecisionChange && eO.b.MatrixTrackedMatrices.push(this), this._m = new eO.b.MatrixCurrentType(16), this.markAsUpdated()
      }
      isIdentity() {
        if (this._isIdentityDirty) {
          this._isIdentityDirty = !1;
          const OO = this._m;
          this._isIdentity = 1 === OO[0] && 0 === OO[1] && 0 === OO[2] && 0 === OO[3] && 0 === OO[4] && 1 === OO[5] && 0 === OO[6] && 0 === OO[7] && 0 === OO[8] && 0 === OO[9] && 1 === OO[10] && 0 === OO[11] && 0 === OO[12] && 0 === OO[13] && 0 === OO[14] && 1 === OO[15]
        }
        return this._isIdentity
      }
      isIdentityAs3x2() {
        return this._isIdentity3x2Dirty && (this._isIdentity3x2Dirty = !1, 1 !== this._m[0] || 1 !== this._m[5] || 1 !== this._m[15] || 0 !== this._m[1] || 0 !== this._m[2] || 0 !== this._m[3] || 0 !== this._m[4] || 0 !== this._m[6] || 0 !== this._m[7] || 0 !== this._m[8] || 0 !== this._m[9] || 0 !== this._m[10] || 0 !== this._m[11] || 0 !== this._m[12] || 0 !== this._m[13] || 0 !== this._m[14] ? this._isIdentity3x2 = !1 : this._isIdentity3x2 = !0), this._isIdentity3x2
      }
      determinant() {
        if (!0 === this._isIdentity) return 1;
        const OO = this._m,
          KO = OO[0],
          pO = OO[1],
          XO = OO[2],
          bK = OO[3],
          eO = OO[4],
          lO = OO[5],
          vK = OO[6],
          CO = OO[7],
          hO = OO[8],
          DO = OO[9],
          MO = OO[10],
          aK = OO[11],
          oO = OO[12],
          FO = OO[13],
          VO = OO[14],
          LO = OO[15],
          QO = MO * LO - VO * aK,
          zK = DO * LO - FO * aK,
          AO = DO * VO - FO * MO,
          fO = hO * LO - oO * aK,
          dO = hO * VO - MO * oO,
          TO = hO * FO - oO * DO;
        return KO * +(lO * QO - vK * zK + CO * AO) + pO * -(eO * QO - vK * fO + CO * dO) + XO * +(eO * zK - lO * fO + CO * TO) + bK * -(eO * AO - lO * dO + vK * TO)
      }
      toString() {
        return `{${this.m[0]}, ${this.m[1]}, ${this.m[2]}, ${this.m[3]}\n${this.m[4]}, ${this.m[5]}, ${this.m[6]}, ${this.m[7]}\n${this.m[8]}, ${this.m[9]}, ${this.m[10]}, ${this.m[11]}\n${this.m[12]}, ${this.m[13]}, ${this.m[14]}, ${this.m[15]}}`
      }
      toArray() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
          KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        if (!OO) return this._m;
        const pO = this._m;
        for (let XO = 0; XO < 16; XO++) OO[KO + XO] = pO[XO];
        return this
      }
      WhO() {
        return this._m
      }
      BCO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return VO.FromArrayToRef(OO, KO, this)
      }
      rvO() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return VO.FromArrayToRef(KO, 0, this)
      }
      set() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++) OO[KO] = KO < 0 || arguments.length <= KO ? void 0 : arguments[KO];
        return this.markAsUpdated(), this
      }
      plO(OO) {
        const KO = this._m;
        for (let pO = 0; pO < 16; pO++) KO[pO] = OO;
        return this.markAsUpdated(), this
      }
      invert() {
        return this.invertToRef(this), this
      }
      reset() {
        return VO.FromValuesToRef(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, this), this._updateIdentityStatus(!1), this
      }
      add(OO) {
        const KO = new VO;
        return this.addToRef(OO, KO), KO
      }
      addToRef(OO, KO) {
        const pO = this._m,
          XO = KO._m,
          bK = OO.m;
        for (let eO = 0; eO < 16; eO++) XO[eO] = pO[eO] + bK[eO];
        return KO.markAsUpdated(), KO
      }
      addToSelf(OO) {
        const KO = this._m,
          pO = OO.m;
        return KO[0] += pO[0], KO[1] += pO[1], KO[2] += pO[2], KO[3] += pO[3], KO[4] += pO[4], KO[5] += pO[5], KO[6] += pO[6], KO[7] += pO[7], KO[8] += pO[8], KO[9] += pO[9], KO[10] += pO[10], KO[11] += pO[11], KO[12] += pO[12], KO[13] += pO[13], KO[14] += pO[14], KO[15] += pO[15], this.markAsUpdated(), this
      }
      addInPlace(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] += pO[XO];
        return this.markAsUpdated(), this
      }
      addInPlaceFromFloats() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++) OO[KO] += KO < 0 || arguments.length <= KO ? void 0 : arguments[KO];
        return this.markAsUpdated(), this
      }
      subtract(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] -= pO[XO];
        return this.markAsUpdated(), this
      }
      subtractToRef(OO, KO) {
        const pO = this._m,
          XO = OO.m,
          bK = KO._m;
        for (let eO = 0; eO < 16; eO++) bK[eO] = pO[eO] - XO[eO];
        return KO.markAsUpdated(), KO
      }
      oDO(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] -= pO[XO];
        return this.markAsUpdated(), this
      }
      subtractFromFloats() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return this.subtractFromFloatsToRef(...KO, new VO)
      }
      subtractFromFloatsToRef() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        const XO = KO.pop(),
          bK = this._m,
          eO = XO._m,
          lO = KO;
        for (let vK = 0; vK < 16; vK++) eO[vK] = bK[vK] - lO[vK];
        return XO.markAsUpdated(), XO
      }
      invertToRef(OO) {
        return !0 === this._isIdentity ? (VO.IdentityToRef(OO), OO) : ((0, CO.c)(this, OO.WhO()) ? OO.markAsUpdated() : OO.NhO(this), OO)
      }
      addAtIndex(OO, KO) {
        return this._m[OO] += KO, this.markAsUpdated(), this
      }
      multiplyAtIndex(OO, KO) {
        return this._m[OO] *= KO, this.markAsUpdated(), this
      }
      setTranslationFromFloats(OO, KO, pO) {
        return this._m[12] = OO, this._m[13] = KO, this._m[14] = pO, this.markAsUpdated(), this
      }
      addTranslationFromFloats(OO, KO, pO) {
        return this._m[12] += OO, this._m[13] += KO, this._m[14] += pO, this.markAsUpdated(), this
      }
      setTranslation(OO) {
        return this.setTranslationFromFloats(OO._x, OO._y, OO._z)
      }
      getTranslation() {
        return new aK(this._m[12], this._m[13], this._m[14])
      }
      getTranslationToRef(OO) {
        return OO.x = this._m[12], OO.y = this._m[13], OO.z = this._m[14], OO
      }
      removeRotationAndScaling() {
        const OO = this.m;
        return VO.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, OO[12], OO[13], OO[14], OO[15], this), this._updateIdentityStatus(0 === OO[12] && 0 === OO[13] && 0 === OO[14] && 1 === OO[15]), this
      }
      NhO(OO) {
        OO.copyToArray(this._m);
        const KO = OO;
        return this.updateFlag = KO.updateFlag, this._updateIdentityStatus(KO._isIdentity, KO._isIdentityDirty, KO._isIdentity3x2, KO._isIdentity3x2Dirty), this
      }
      copyToArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return (0, CO.b)(this, OO, KO), this
      }
      multiply(OO) {
        const KO = new VO;
        return this.multiplyToRef(OO, KO), KO
      }
      multiplyInPlace(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] *= pO[XO];
        return this.markAsUpdated(), this
      }
      multiplyByFloats() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++) OO[KO] *= KO < 0 || arguments.length <= KO ? void 0 : arguments[KO];
        return this.markAsUpdated(), this
      }
      multiplyByFloatsToRef() {
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        const XO = KO.pop(),
          bK = this._m,
          eO = XO._m,
          lO = KO;
        for (let vK = 0; vK < 16; vK++) eO[vK] = bK[vK] * lO[vK];
        return XO.markAsUpdated(), XO
      }
      multiplyToRef(OO, KO) {
        return this._isIdentity ? (KO.NhO(OO), KO) : OO._isIdentity ? (KO.NhO(this), KO) : (this.multiplyToArray(OO, KO._m, 0), KO.markAsUpdated(), KO)
      }
      multiplyToArray(OO, KO, pO) {
        return (0, CO.k)(this, OO, KO, pO), this
      }
      divide(OO) {
        return this.divideToRef(OO, new VO)
      }
      divideToRef(OO, KO) {
        const pO = this._m,
          XO = OO.m,
          bK = KO._m;
        for (let eO = 0; eO < 16; eO++) bK[eO] = pO[eO] / XO[eO];
        return KO.markAsUpdated(), KO
      }
      divideInPlace(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] /= pO[XO];
        return this.markAsUpdated(), this
      }
      minimizeInPlace(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] = Math.min(KO[XO], pO[XO]);
        return this.markAsUpdated(), this
      }
      minimizeInPlaceFromFloats() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++) OO[KO] = Math.min(OO[KO], KO < 0 || arguments.length <= KO ? void 0 : arguments[KO]);
        return this.markAsUpdated(), this
      }
      maximizeInPlace(OO) {
        const KO = this._m,
          pO = OO.m;
        for (let XO = 0; XO < 16; XO++) KO[XO] = Math.max(KO[XO], pO[XO]);
        return this.markAsUpdated(), this
      }
      maximizeInPlaceFromFloats() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++) OO[KO] = Math.max(OO[KO], KO < 0 || arguments.length <= KO ? void 0 : arguments[KO]);
        return this.markAsUpdated(), this
      }
      hl() {
        return this.negateToRef(new VO)
      }
      negateInPlace() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++) OO[KO] = -OO[KO];
        return this.markAsUpdated(), this
      }
      negateToRef(OO) {
        const KO = this._m,
          pO = OO._m;
        for (let XO = 0; XO < 16; XO++) pO[XO] = -KO[XO];
        return OO.markAsUpdated(), OO
      }
      equals(OO) {
        const KO = OO;
        if (!KO) return !1;
        if ((this._isIdentity || KO._isIdentity) && !this._isIdentityDirty && !KO._isIdentityDirty) return this._isIdentity && KO._isIdentity;
        const pO = this.m,
          XO = KO.m;
        return pO[0] === XO[0] && pO[1] === XO[1] && pO[2] === XO[2] && pO[3] === XO[3] && pO[4] === XO[4] && pO[5] === XO[5] && pO[6] === XO[6] && pO[7] === XO[7] && pO[8] === XO[8] && pO[9] === XO[9] && pO[10] === XO[10] && pO[11] === XO[11] && pO[12] === XO[12] && pO[13] === XO[13] && pO[14] === XO[14] && pO[15] === XO[15]
      }
      equalsWithEpsilon(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = this._m,
          XO = OO.m;
        for (let bK = 0; bK < 16; bK++)
          if (!(0, vK.WithinEpsilon)(pO[bK], XO[bK], KO)) return !1;
        return !0
      }
      soO() {
        const OO = this._m;
        for (let KO = 0; KO < 16; KO++)
          if (OO[KO] != (KO < 0 || arguments.length <= KO ? void 0 : arguments[KO])) return !1;
        return !0
      }
      floor() {
        return this.floorToRef(new VO)
      }
      floorToRef(OO) {
        const KO = this._m,
          pO = OO._m;
        for (let XO = 0; XO < 16; XO++) pO[XO] = Math.floor(KO[XO]);
        return OO.markAsUpdated(), OO
      }
      fract() {
        return this.fractToRef(new VO)
      }
      fractToRef(OO) {
        const KO = this._m,
          pO = OO._m;
        for (let XO = 0; XO < 16; XO++) pO[XO] = KO[XO] - Math.floor(KO[XO]);
        return OO.markAsUpdated(), OO
      }
      clone() {
        const OO = new VO;
        return OO.NhO(this), OO
      }
      getClassName() {
        return "Matrix"
      }
      getHashCode() {
        let OO = DO(this._m[0]);
        for (let KO = 1; KO < 16; KO++) OO = 397 * OO ^ DO(this._m[KO]);
        return OO
      }
      decomposeToTransformNode(OO) {
        return OO.rotationQuaternion = OO.rotationQuaternion || new FO, this.decompose(OO.ol, OO.rotationQuaternion, OO.position)
      }
      decompose(OO, KO, pO, XO) {
        let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
        if (this._isIdentity) return pO && pO.plO(0), OO && OO.plO(1), KO && KO.rvO(0, 0, 0, 1), !0;
        const eO = this._m;
        if (pO && pO.rvO(eO[12], eO[13], eO[14]), (OO = OO || LO.WX[0]).x = Math.sqrt(eO[0] * eO[0] + eO[1] * eO[1] + eO[2] * eO[2]), OO.y = Math.sqrt(eO[4] * eO[4] + eO[5] * eO[5] + eO[6] * eO[6]), OO.z = Math.sqrt(eO[8] * eO[8] + eO[9] * eO[9] + eO[10] * eO[10]), XO) {
          const KO = (bK ? XO.absoluteScaling.x : XO.ol.x) < 0 ? -1 : 1,
            pO = (bK ? XO.absoluteScaling.y : XO.ol.y) < 0 ? -1 : 1,
            eO = (bK ? XO.absoluteScaling.z : XO.ol.z) < 0 ? -1 : 1;
          OO.x *= KO, OO.y *= pO, OO.z *= eO
        } else this.determinant() <= 0 && (OO.y *= -1);
        if (0 === OO._x || 0 === OO._y || 0 === OO._z) return KO && KO.rvO(0, 0, 0, 1), !1;
        if (KO) {
          const pO = 1 / OO._x,
            XO = 1 / OO._y,
            bK = 1 / OO._z;
          VO.FromValuesToRef(eO[0] * pO, eO[1] * pO, eO[2] * pO, 0, eO[4] * XO, eO[5] * XO, eO[6] * XO, 0, eO[8] * bK, eO[9] * bK, eO[10] * bK, 0, 0, 0, 0, 1, LO.Matrix[0]), FO.FromRotationMatrixToRef(LO.Matrix[0], KO)
        }
        return !0
      }
      getRow(OO) {
        if (OO < 0 || OO > 3) return null;
        const KO = 4 * OO;
        return new oO(this._m[KO + 0], this._m[KO + 1], this._m[KO + 2], this._m[KO + 3])
      }
      getRowToRef(OO, KO) {
        if (OO >= 0 && OO <= 3) {
          const pO = 4 * OO;
          KO.x = this._m[pO + 0], KO.y = this._m[pO + 1], KO.z = this._m[pO + 2], KO.w = this._m[pO + 3]
        }
        return KO
      }
      setRow(OO, KO) {
        return this.setRowFromFloats(OO, KO.x, KO.y, KO.z, KO.w)
      }
      transpose() {
        const OO = new VO;
        return VO.TransposeToRef(this, OO), OO
      }
      transposeToRef(OO) {
        return VO.TransposeToRef(this, OO), OO
      }
      setRowFromFloats(OO, KO, pO, XO, bK) {
        if (OO < 0 || OO > 3) return this;
        const eO = 4 * OO;
        return this._m[eO + 0] = KO, this._m[eO + 1] = pO, this._m[eO + 2] = XO, this._m[eO + 3] = bK, this.markAsUpdated(), this
      }
      scale(OO) {
        const KO = new VO;
        return this.scaleToRef(OO, KO), KO
      }
      scaleToRef(OO, KO) {
        for (let pO = 0; pO < 16; pO++) KO._m[pO] = this._m[pO] * OO;
        return KO.markAsUpdated(), KO
      }
      scaleAndAddToRef(OO, KO) {
        for (let pO = 0; pO < 16; pO++) KO._m[pO] += this._m[pO] * OO;
        return KO.markAsUpdated(), KO
      }
      scaleInPlace(OO) {
        const KO = this._m;
        for (let pO = 0; pO < 16; pO++) KO[pO] *= OO;
        return this.markAsUpdated(), this
      }
      toNormalMatrix(OO) {
        const KO = LO.Matrix[0];
        this.invertToRef(KO), KO.transposeToRef(OO);
        const pO = OO._m;
        return VO.FromValuesToRef(pO[0], pO[1], pO[2], 0, pO[4], pO[5], pO[6], 0, pO[8], pO[9], pO[10], 0, 0, 0, 0, 1, OO), OO
      }
      getRotationMatrix() {
        const OO = new VO;
        return this.getRotationMatrixToRef(OO), OO
      }
      getRotationMatrixToRef(OO) {
        const KO = LO.WX[0];
        if (!this.decompose(KO)) return VO.IdentityToRef(OO), OO;
        const pO = this._m,
          XO = 1 / KO._x,
          bK = 1 / KO._y,
          eO = 1 / KO._z;
        return VO.FromValuesToRef(pO[0] * XO, pO[1] * XO, pO[2] * XO, 0, pO[4] * bK, pO[5] * bK, pO[6] * bK, 0, pO[8] * eO, pO[9] * eO, pO[10] * eO, 0, 0, 0, 0, 1, OO), OO
      }
      toggleModelMatrixHandInPlace() {
        const OO = this._m;
        return OO[2] *= -1, OO[6] *= -1, OO[8] *= -1, OO[9] *= -1, OO[14] *= -1, this.markAsUpdated(), this
      }
      toggleProjectionMatrixHandInPlace() {
        const OO = this._m;
        return OO[8] *= -1, OO[9] *= -1, OO[10] *= -1, OO[11] *= -1, this.markAsUpdated(), this
      }
      _convertProjectionToHalfZRangeInPlace() {
        return this.multiplyToRef(zK, this), this
      }
      static FromArray(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        const pO = new VO;
        return VO.FromArrayToRef(OO, KO, pO), pO
      }
      static FromArrayToRef(OO, KO, pO) {
        for (let XO = 0; XO < 16; XO++) pO._m[XO] = OO[XO + KO];
        return pO.markAsUpdated(), pO
      }
      static FromFloat32ArrayToRefScaled(OO, KO, pO, XO) {
        return XO._m[0] = OO[0 + KO] * pO, XO._m[1] = OO[1 + KO] * pO, XO._m[2] = OO[2 + KO] * pO, XO._m[3] = OO[3 + KO] * pO, XO._m[4] = OO[4 + KO] * pO, XO._m[5] = OO[5 + KO] * pO, XO._m[6] = OO[6 + KO] * pO, XO._m[7] = OO[7 + KO] * pO, XO._m[8] = OO[8 + KO] * pO, XO._m[9] = OO[9 + KO] * pO, XO._m[10] = OO[10 + KO] * pO, XO._m[11] = OO[11 + KO] * pO, XO._m[12] = OO[12 + KO] * pO, XO._m[13] = OO[13 + KO] * pO, XO._m[14] = OO[14 + KO] * pO, XO._m[15] = OO[15 + KO] * pO, XO.markAsUpdated(), XO
      }
      static get IdentityReadOnly() {
        return VO._IdentityReadOnly
      }
      static FromValuesToRef(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, VO, LO) {
        const QO = LO._m;
        QO[0] = OO, QO[1] = KO, QO[2] = pO, QO[3] = XO, QO[4] = bK, QO[5] = eO, QO[6] = lO, QO[7] = vK, QO[8] = CO, QO[9] = hO, QO[10] = DO, QO[11] = MO, QO[12] = aK, QO[13] = oO, QO[14] = FO, QO[15] = VO, LO.markAsUpdated()
      }
      static FromValues(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO, MO, aK, oO, FO, LO) {
        const QO = new VO,
          zK = QO._m;
        return zK[0] = OO, zK[1] = KO, zK[2] = pO, zK[3] = XO, zK[4] = bK, zK[5] = eO, zK[6] = lO, zK[7] = vK, zK[8] = CO, zK[9] = hO, zK[10] = DO, zK[11] = MO, zK[12] = aK, zK[13] = oO, zK[14] = FO, zK[15] = LO, QO.markAsUpdated(), QO
      }
      static Compose(OO, KO, pO) {
        const XO = new VO;
        return VO.ComposeToRef(OO, KO, pO, XO), XO
      }
      static ComposeToRef(OO, KO, pO, XO) {
        const bK = XO._m,
          eO = KO._x,
          lO = KO._y,
          vK = KO._z,
          CO = KO._w,
          hO = eO + eO,
          DO = lO + lO,
          MO = vK + vK,
          aK = eO * hO,
          oO = eO * DO,
          FO = eO * MO,
          VO = lO * DO,
          LO = lO * MO,
          QO = vK * MO,
          zK = CO * hO,
          AO = CO * DO,
          fO = CO * MO,
          dO = OO._x,
          TO = OO._y,
          NO = OO._z;
        return bK[0] = (1 - (VO + QO)) * dO, bK[1] = (oO + fO) * dO, bK[2] = (FO - AO) * dO, bK[3] = 0, bK[4] = (oO - fO) * TO, bK[5] = (1 - (aK + QO)) * TO, bK[6] = (LO + zK) * TO, bK[7] = 0, bK[8] = (FO + AO) * NO, bK[9] = (LO - zK) * NO, bK[10] = (1 - (aK + VO)) * NO, bK[11] = 0, bK[12] = pO._x, bK[13] = pO._y, bK[14] = pO._z, bK[15] = 1, XO.markAsUpdated(), XO
      }
      static Identity() {
        const OO = VO.FromValues(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
        return OO._updateIdentityStatus(!0), OO
      }
      static IdentityToRef(OO) {
        return VO.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, OO), OO._updateIdentityStatus(!0), OO
      }
      static Zero() {
        const OO = VO.FromValues(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        return OO._updateIdentityStatus(!1), OO
      }
      static RotationX(OO) {
        const KO = new VO;
        return VO.RotationXToRef(OO, KO), KO
      }
      static Invert(OO) {
        const KO = new VO;
        return OO.invertToRef(KO), KO
      }
      static RotationXToRef(OO, KO) {
        const pO = Math.sin(OO),
          XO = Math.cos(OO);
        return VO.FromValuesToRef(1, 0, 0, 0, 0, XO, pO, 0, 0, -pO, XO, 0, 0, 0, 0, 1, KO), KO._updateIdentityStatus(1 === XO && 0 === pO), KO
      }
      static RotationY(OO) {
        const KO = new VO;
        return VO.RotationYToRef(OO, KO), KO
      }
      static RotationYToRef(OO, KO) {
        const pO = Math.sin(OO),
          XO = Math.cos(OO);
        return VO.FromValuesToRef(XO, 0, -pO, 0, 0, 1, 0, 0, pO, 0, XO, 0, 0, 0, 0, 1, KO), KO._updateIdentityStatus(1 === XO && 0 === pO), KO
      }
      static RotationZ(OO) {
        const KO = new VO;
        return VO.RotationZToRef(OO, KO), KO
      }
      static RotationZToRef(OO, KO) {
        const pO = Math.sin(OO),
          XO = Math.cos(OO);
        return VO.FromValuesToRef(XO, pO, 0, 0, -pO, XO, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, KO), KO._updateIdentityStatus(1 === XO && 0 === pO), KO
      }
      static RotationAxis(OO, KO) {
        const pO = new VO;
        return VO.RotationAxisToRef(OO, KO, pO), pO
      }
      static RotationAxisToRef(OO, KO, pO) {
        const XO = Math.sin(-KO),
          bK = Math.cos(-KO),
          eO = 1 - bK;
        OO = OO.normalizeToRef(LO.WX[0]);
        const lO = pO._m;
        return lO[0] = OO._x * OO._x * eO + bK, lO[1] = OO._x * OO._y * eO - OO._z * XO, lO[2] = OO._x * OO._z * eO + OO._y * XO, lO[3] = 0, lO[4] = OO._y * OO._x * eO + OO._z * XO, lO[5] = OO._y * OO._y * eO + bK, lO[6] = OO._y * OO._z * eO - OO._x * XO, lO[7] = 0, lO[8] = OO._z * OO._x * eO - OO._y * XO, lO[9] = OO._z * OO._y * eO + OO._x * XO, lO[10] = OO._z * OO._z * eO + bK, lO[11] = 0, lO[12] = 0, lO[13] = 0, lO[14] = 0, lO[15] = 1, pO.markAsUpdated(), pO
      }
      static RotationAlignToRef(OO, KO, pO) {
        let bK = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
        const eO = aK.Dot(KO, OO),
          lO = pO._m;
        if (eO < -1 + XO.c) lO[0] = -1, lO[1] = 0, lO[2] = 0, lO[3] = 0, lO[4] = 0, lO[5] = bK ? 1 : -1, lO[6] = 0, lO[7] = 0, lO[8] = 0, lO[9] = 0, lO[10] = bK ? -1 : 1, lO[11] = 0;
        else {
          const pO = aK.Cross(KO, OO),
            XO = 1 / (1 + eO);
          lO[0] = pO._x * pO._x * XO + eO, lO[1] = pO._y * pO._x * XO - pO._z, lO[2] = pO._z * pO._x * XO + pO._y, lO[3] = 0, lO[4] = pO._x * pO._y * XO + pO._z, lO[5] = pO._y * pO._y * XO + eO, lO[6] = pO._z * pO._y * XO - pO._x, lO[7] = 0, lO[8] = pO._x * pO._z * XO - pO._y, lO[9] = pO._y * pO._z * XO + pO._x, lO[10] = pO._z * pO._z * XO + eO, lO[11] = 0
        }
        return lO[12] = 0, lO[13] = 0, lO[14] = 0, lO[15] = 1, pO.markAsUpdated(), pO
      }
      static RotationYawPitchRoll(OO, KO, pO) {
        const XO = new VO;
        return VO.RotationYawPitchRollToRef(OO, KO, pO, XO), XO
      }
      static RotationYawPitchRollToRef(OO, KO, pO, XO) {
        return FO.RotationYawPitchRollToRef(OO, KO, pO, LO.Quaternion[0]), LO.Quaternion[0].toRotationMatrix(XO), XO
      }
      static Scaling(OO, KO, pO) {
        const XO = new VO;
        return VO.ScalingToRef(OO, KO, pO, XO), XO
      }
      static ScalingToRef(OO, KO, pO, XO) {
        return VO.FromValuesToRef(OO, 0, 0, 0, 0, KO, 0, 0, 0, 0, pO, 0, 0, 0, 0, 1, XO), XO._updateIdentityStatus(1 === OO && 1 === KO && 1 === pO), XO
      }
      static Translation(OO, KO, pO) {
        const XO = new VO;
        return VO.TranslationToRef(OO, KO, pO, XO), XO
      }
      static TranslationToRef(OO, KO, pO, XO) {
        return VO.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, OO, KO, pO, 1, XO), XO._updateIdentityStatus(0 === OO && 0 === KO && 0 === pO), XO
      }
      static Lerp(OO, KO, pO) {
        const XO = new VO;
        return VO.LerpToRef(OO, KO, pO, XO), XO
      }
      static LerpToRef(OO, KO, pO, XO) {
        const bK = XO._m,
          eO = OO.m,
          lO = KO.m;
        for (let vK = 0; vK < 16; vK++) bK[vK] = eO[vK] * (1 - pO) + lO[vK] * pO;
        return XO.markAsUpdated(), XO
      }
      static DecomposeLerp(OO, KO, pO) {
        const XO = new VO;
        return VO.DecomposeLerpToRef(OO, KO, pO, XO), XO
      }
      static DecomposeLerpToRef(OO, KO, pO, XO) {
        const bK = LO.WX[0],
          eO = LO.Quaternion[0],
          lO = LO.WX[1];
        OO.decompose(bK, eO, lO);
        const vK = LO.WX[2],
          CO = LO.Quaternion[1],
          hO = LO.WX[3];
        KO.decompose(vK, CO, hO);
        const DO = LO.WX[4];
        aK.LerpToRef(bK, vK, pO, DO);
        const MO = LO.Quaternion[2];
        FO.SlerpToRef(eO, CO, pO, MO);
        const oO = LO.WX[5];
        return aK.LerpToRef(lO, hO, pO, oO), VO.ComposeToRef(DO, MO, oO, XO), XO
      }
      static LookAtLH(OO, KO, pO) {
        const XO = new VO;
        return VO.LookAtLHToRef(OO, KO, pO, XO), XO
      }
      static LookAtLHToRef(OO, KO, pO, XO) {
        const bK = LO.WX[0],
          eO = LO.WX[1],
          lO = LO.WX[2];
        KO.subtractToRef(OO, lO), lO.normalize(), aK.CrossToRef(pO, lO, bK);
        const vK = bK.lengthSquared();
        0 === vK ? bK.x = 1 : bK.normalizeFromLength(Math.sqrt(vK)), aK.CrossToRef(lO, bK, eO), eO.normalize();
        const CO = -aK.Dot(bK, OO),
          hO = -aK.Dot(eO, OO),
          DO = -aK.Dot(lO, OO);
        return VO.FromValuesToRef(bK._x, eO._x, lO._x, 0, bK._y, eO._y, lO._y, 0, bK._z, eO._z, lO._z, 0, CO, hO, DO, 1, XO), XO
      }
      static LookAtRH(OO, KO, pO) {
        const XO = new VO;
        return VO.LookAtRHToRef(OO, KO, pO, XO), XO
      }
      static LookAtRHToRef(OO, KO, pO, XO) {
        const bK = LO.WX[0],
          eO = LO.WX[1],
          lO = LO.WX[2];
        OO.subtractToRef(KO, lO), lO.normalize(), aK.CrossToRef(pO, lO, bK);
        const vK = bK.lengthSquared();
        0 === vK ? bK.x = 1 : bK.normalizeFromLength(Math.sqrt(vK)), aK.CrossToRef(lO, bK, eO), eO.normalize();
        const CO = -aK.Dot(bK, OO),
          hO = -aK.Dot(eO, OO),
          DO = -aK.Dot(lO, OO);
        return VO.FromValuesToRef(bK._x, eO._x, lO._x, 0, bK._y, eO._y, lO._y, 0, bK._z, eO._z, lO._z, 0, CO, hO, DO, 1, XO), XO
      }
      static LookDirectionLH(OO, KO) {
        const pO = new VO;
        return VO.LookDirectionLHToRef(OO, KO, pO), pO
      }
      static LookDirectionLHToRef(OO, KO, pO) {
        const XO = LO.WX[0];
        XO.NhO(OO), XO.scaleInPlace(-1);
        const bK = LO.WX[1];
        return aK.CrossToRef(KO, XO, bK), VO.FromValuesToRef(bK._x, bK._y, bK._z, 0, KO._x, KO._y, KO._z, 0, XO._x, XO._y, XO._z, 0, 0, 0, 0, 1, pO), pO
      }
      static LookDirectionRH(OO, KO) {
        const pO = new VO;
        return VO.LookDirectionRHToRef(OO, KO, pO), pO
      }
      static LookDirectionRHToRef(OO, KO, pO) {
        const XO = LO.WX[2];
        return aK.CrossToRef(KO, OO, XO), VO.FromValuesToRef(XO._x, XO._y, XO._z, 0, KO._x, KO._y, KO._z, 0, OO._x, OO._y, OO._z, 0, 0, 0, 0, 1, pO), pO
      }
      static OrthoLH(OO, KO, pO, XO, bK) {
        const eO = new VO;
        return VO.OrthoLHToRef(OO, KO, pO, XO, eO, bK), eO
      }
      static OrthoLHToRef(OO, KO, pO, XO, bK, eO) {
        const lO = 2 / OO,
          vK = 2 / KO,
          CO = 2 / (XO - pO),
          hO = -(XO + pO) / (XO - pO);
        return VO.FromValuesToRef(lO, 0, 0, 0, 0, vK, 0, 0, 0, 0, CO, 0, 0, 0, hO, 1, bK), eO && bK.multiplyToRef(zK, bK), bK._updateIdentityStatus(1 === lO && 1 === vK && 1 === CO && 0 === hO), bK
      }
      static OrthoOffCenterLH(OO, KO, pO, XO, bK, eO, lO) {
        const vK = new VO;
        return VO.OrthoOffCenterLHToRef(OO, KO, pO, XO, bK, eO, vK, lO), vK
      }
      static OrthoOffCenterLHToRef(OO, KO, pO, XO, bK, eO, lO, vK) {
        const CO = 2 / (KO - OO),
          hO = 2 / (XO - pO),
          DO = 2 / (eO - bK),
          MO = -(eO + bK) / (eO - bK),
          aK = (OO + KO) / (OO - KO),
          oO = (XO + pO) / (pO - XO);
        return VO.FromValuesToRef(CO, 0, 0, 0, 0, hO, 0, 0, 0, 0, DO, 0, aK, oO, MO, 1, lO), vK && lO.multiplyToRef(zK, lO), lO.markAsUpdated(), lO
      }
      static ObliqueOffCenterLHToRef(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
        const MO = -lO * Math.cos(vK),
          aK = -lO * Math.sin(vK);
        return VO.TranslationToRef(0, 0, -CO, LO.Matrix[1]), VO.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, MO, aK, 1, 0, 0, 0, 0, 1, LO.Matrix[0]), LO.Matrix[1].multiplyToRef(LO.Matrix[0], LO.Matrix[0]), VO.TranslationToRef(0, 0, CO, LO.Matrix[1]), LO.Matrix[0].multiplyToRef(LO.Matrix[1], LO.Matrix[0]), VO.OrthoOffCenterLHToRef(OO, KO, pO, XO, bK, eO, hO, DO), LO.Matrix[0].multiplyToRef(hO, hO), hO
      }
      static OrthoOffCenterRH(OO, KO, pO, XO, bK, eO, lO) {
        const vK = new VO;
        return VO.OrthoOffCenterRHToRef(OO, KO, pO, XO, bK, eO, vK, lO), vK
      }
      static OrthoOffCenterRHToRef(OO, KO, pO, XO, bK, eO, lO, vK) {
        return VO.OrthoOffCenterLHToRef(OO, KO, pO, XO, bK, eO, lO, vK), lO._m[10] *= -1, lO
      }
      static ObliqueOffCenterRHToRef(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
        const MO = lO * Math.cos(vK),
          aK = lO * Math.sin(vK);
        return VO.TranslationToRef(0, 0, CO, LO.Matrix[1]), VO.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, MO, aK, 1, 0, 0, 0, 0, 1, LO.Matrix[0]), LO.Matrix[1].multiplyToRef(LO.Matrix[0], LO.Matrix[0]), VO.TranslationToRef(0, 0, -CO, LO.Matrix[1]), LO.Matrix[0].multiplyToRef(LO.Matrix[1], LO.Matrix[0]), VO.OrthoOffCenterRHToRef(OO, KO, pO, XO, bK, eO, hO, DO), LO.Matrix[0].multiplyToRef(hO, hO), hO
      }
      static PerspectiveLH(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0;
        const lO = new VO,
          vK = 2 * pO / OO,
          CO = 2 * pO / KO,
          hO = (XO + pO) / (XO - pO),
          DO = -2 * XO * pO / (XO - pO),
          MO = Math.tan(eO);
        return VO.FromValuesToRef(vK, 0, 0, 0, 0, CO, 0, MO, 0, 0, hO, 1, 0, 0, DO, 0, lO), bK && lO.multiplyToRef(zK, lO), lO._updateIdentityStatus(!1), lO
      }
      static PerspectiveFovLH(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        const vK = new VO;
        return VO.PerspectiveFovLHToRef(OO, KO, pO, XO, vK, !0, bK, eO, lO), vK
      }
      static PerspectiveFovLHToRef(OO, KO, pO, XO, bK) {
        let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0,
          CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8];
        const hO = pO,
          DO = XO,
          MO = 1 / Math.tan(.5 * OO),
          aK = eO ? MO / KO : MO,
          oO = eO ? MO : MO * KO,
          FO = CO && 0 === hO ? -1 : 0 !== DO ? (DO + hO) / (DO - hO) : 1,
          LO = CO && 0 === hO ? 2 * DO : 0 !== DO ? -2 * DO * hO / (DO - hO) : -2 * hO,
          QO = Math.tan(vK);
        return VO.FromValuesToRef(aK, 0, 0, 0, 0, oO, 0, QO, 0, 0, FO, 1, 0, 0, LO, 0, bK), lO && bK.multiplyToRef(zK, bK), bK._updateIdentityStatus(!1), bK
      }
      static PerspectiveFovReverseLHToRef(OO, KO, pO, XO, bK) {
        let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0;
        const CO = 1 / Math.tan(.5 * OO),
          hO = eO ? CO / KO : CO,
          DO = eO ? CO : CO * KO,
          MO = Math.tan(vK);
        return VO.FromValuesToRef(hO, 0, 0, 0, 0, DO, 0, MO, 0, 0, -pO, 1, 0, 0, 1, 0, bK), lO && bK.multiplyToRef(zK, bK), bK._updateIdentityStatus(!1), bK
      }
      static PerspectiveFovRH(OO, KO, pO, XO, bK) {
        let eO = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
          lO = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
        const vK = new VO;
        return VO.PerspectiveFovRHToRef(OO, KO, pO, XO, vK, !0, bK, eO, lO), vK
      }
      static PerspectiveFovRHToRef(OO, KO, pO, XO, bK) {
        let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0,
          CO = arguments.length > 8 && void 0 !== arguments[8] && arguments[8];
        const hO = pO,
          DO = XO,
          MO = 1 / Math.tan(.5 * OO),
          aK = eO ? MO / KO : MO,
          oO = eO ? MO : MO * KO,
          FO = CO && 0 === hO ? 1 : 0 !== DO ? -(DO + hO) / (DO - hO) : -1,
          LO = CO && 0 === hO ? 2 * DO : 0 !== DO ? -2 * DO * hO / (DO - hO) : -2 * hO,
          QO = Math.tan(vK);
        return VO.FromValuesToRef(aK, 0, 0, 0, 0, oO, 0, QO, 0, 0, FO, -1, 0, 0, LO, 0, bK), lO && bK.multiplyToRef(zK, bK), bK._updateIdentityStatus(!1), bK
      }
      static PerspectiveFovReverseRHToRef(OO, KO, pO, XO, bK) {
        let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          lO = arguments.length > 6 ? arguments[6] : void 0,
          vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0;
        const CO = 1 / Math.tan(.5 * OO),
          hO = eO ? CO / KO : CO,
          DO = eO ? CO : CO * KO,
          MO = Math.tan(vK);
        return VO.FromValuesToRef(hO, 0, 0, 0, 0, DO, 0, MO, 0, 0, -pO, -1, 0, 0, -1, 0, bK), lO && bK.multiplyToRef(zK, bK), bK._updateIdentityStatus(!1), bK
      }
      static GetFinalMatrix(OO, KO, pO, XO, bK, eO) {
        const lO = OO.width,
          vK = OO.height,
          CO = OO.x,
          hO = OO.y,
          DO = VO.FromValues(lO / 2, 0, 0, 0, 0, -vK / 2, 0, 0, 0, 0, eO - bK, 0, CO + lO / 2, vK / 2 + hO, bK, 1),
          MO = new VO;
        return KO.multiplyToRef(pO, MO), MO.multiplyToRef(XO, MO), MO.multiplyToRef(DO, MO)
      }
      static GetAsMatrix2x2(OO) {
        const KO = OO.m,
          pO = [KO[0], KO[1], KO[4], KO[5]];
        return eO.b.MatrixUse64Bits ? pO : new Float32Array(pO)
      }
      static GetAsMatrix3x3(OO) {
        const KO = OO.m,
          pO = [KO[0], KO[1], KO[2], KO[4], KO[5], KO[6], KO[8], KO[9], KO[10]];
        return eO.b.MatrixUse64Bits ? pO : new Float32Array(pO)
      }
      static Transpose(OO) {
        const KO = new VO;
        return VO.TransposeToRef(OO, KO), KO
      }
      static TransposeToRef(OO, KO) {
        const pO = OO.m,
          XO = pO[0],
          bK = pO[4],
          eO = pO[8],
          lO = pO[12],
          vK = pO[1],
          CO = pO[5],
          hO = pO[9],
          DO = pO[13],
          MO = pO[2],
          aK = pO[6],
          oO = pO[10],
          FO = pO[14],
          VO = pO[3],
          LO = pO[7],
          QO = pO[11],
          zK = pO[15],
          AO = KO._m;
        return AO[0] = XO, AO[1] = bK, AO[2] = eO, AO[3] = lO, AO[4] = vK, AO[5] = CO, AO[6] = hO, AO[7] = DO, AO[8] = MO, AO[9] = aK, AO[10] = oO, AO[11] = FO, AO[12] = VO, AO[13] = LO, AO[14] = QO, AO[15] = zK, KO.markAsUpdated(), KO._updateIdentityStatus(OO._isIdentity, OO._isIdentityDirty), KO
      }
      static Reflection(OO) {
        const KO = new VO;
        return VO.ReflectionToRef(OO, KO), KO
      }
      static ReflectionToRef(OO, KO) {
        OO.normalize();
        const pO = OO.normal.x,
          XO = OO.normal.y,
          bK = OO.normal.z,
          eO = -2 * pO,
          lO = -2 * XO,
          vK = -2 * bK;
        return VO.FromValuesToRef(eO * pO + 1, lO * pO, vK * pO, 0, eO * XO, lO * XO + 1, vK * XO, 0, eO * bK, lO * bK, vK * bK + 1, 0, eO * OO.d, lO * OO.d, vK * OO.d, 1, KO), KO
      }
      static FromXYZAxesToRef(OO, KO, pO, XO) {
        return VO.FromValuesToRef(OO._x, OO._y, OO._z, 0, KO._x, KO._y, KO._z, 0, pO._x, pO._y, pO._z, 0, 0, 0, 0, 1, XO), XO
      }
      static FromQuaternionToRef(OO, KO) {
        const pO = OO._x * OO._x,
          XO = OO._y * OO._y,
          bK = OO._z * OO._z,
          eO = OO._x * OO._y,
          lO = OO._z * OO._w,
          vK = OO._z * OO._x,
          CO = OO._y * OO._w,
          hO = OO._y * OO._z,
          DO = OO._x * OO._w;
        return KO._m[0] = 1 - 2 * (XO + bK), KO._m[1] = 2 * (eO + lO), KO._m[2] = 2 * (vK - CO), KO._m[3] = 0, KO._m[4] = 2 * (eO - lO), KO._m[5] = 1 - 2 * (bK + pO), KO._m[6] = 2 * (hO + DO), KO._m[7] = 0, KO._m[8] = 2 * (vK + CO), KO._m[9] = 2 * (hO - DO), KO._m[10] = 1 - 2 * (XO + pO), KO._m[11] = 0, KO._m[12] = 0, KO._m[13] = 0, KO._m[14] = 0, KO._m[15] = 1, KO.markAsUpdated(), KO
      }
    }
    VO._IdentityReadOnly = VO.Identity();
    class LO {}
    LO.WX = (0, bK.f)(11, aK.Zero), LO.Matrix = (0, bK.f)(2, VO.Identity), LO.Quaternion = (0, bK.f)(3, FO.Zero);
    class QO {}
    QO.Vector2 = (0, bK.f)(3, MO.Zero), QO.WX = (0, bK.f)(13, aK.Zero), QO.Vector4 = (0, bK.f)(3, oO.Zero), QO.Quaternion = (0, bK.f)(3, FO.Zero), QO.Matrix = (0, bK.f)(8, VO.Identity);
    const zK = VO.FromValues(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, .5, 0, 0, 0, .5, 1);
    let AO = !1;

    function fO() {
      AO || (AO = !0, Object.defineProperties(MO.prototype, {
        dimension: {
          value: [2]
        },
        rank: {
          value: 1
        }
      }), Object.defineProperties(aK.prototype, {
        dimension: {
          value: [3]
        },
        rank: {
          value: 1
        }
      }), Object.defineProperties(oO.prototype, {
        dimension: {
          value: [4]
        },
        rank: {
          value: 1
        }
      }), Object.defineProperties(FO.prototype, {
        dimension: {
          value: [4]
        },
        rank: {
          value: 1
        }
      }), Object.defineProperties(VO.prototype, {
        dimension: {
          value: [4, 4]
        },
        rank: {
          value: 2
        }
      }), (0, hO.h)("BABYLON.Vector2", MO), (0, hO.h)("BABYLON.Vector3", aK), (0, hO.h)("BABYLON.Vector4", oO), (0, hO.h)("BABYLON.Matrix", VO))
    }
  },
  35660: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    const XO = "undefined" !== typeof WeakRef;
    class bK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        this.initialize(OO, KO, pO, XO)
      }
      initialize(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0;
        return this.mask = OO, this.skipNextObservers = KO, this.target = pO, this.currentTarget = XO, this
      }
    }
    class eO {
      constructor(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        this.callback = OO, this.mask = KO, this.scope = pO, this._willBeUnregistered = !1, this.unregisterOnNextCall = !1, this._remove = null
      }
      remove() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        this._remove && this._remove(OO)
      }
    }
    class lO {
      static FromPromise(OO, KO) {
        const pO = new lO;
        return OO.then((OO => {
          pO.notifyObservers(OO)
        })).catch((OO => {
          if (!KO) throw OO;
          KO.notifyObservers(OO)
        })), pO
      }
      get observers() {
        return this._observers
      }
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        this.notifyIfTriggered = KO, this._observers = new Array, this._numObserversMarkedAsDeleted = 0, this._hasNotified = !1, this._eventState = new bK(0), OO && (this._onObserverAdded = OO)
      }
      add(OO) {
        let KO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          pO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        if (!OO) return null;
        const bK = new eO(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1, arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null);
        bK.unregisterOnNextCall = pO, KO ? this._observers.unshift(bK) : this._observers.push(bK), this._onObserverAdded && this._onObserverAdded(bK), this._hasNotified && this.notifyIfTriggered && this.notifyObserver(bK, this._lastNotifiedValue);
        const lO = XO ? new WeakRef(this) : {
          deref: () => this
        };
        return bK._remove = function() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
          const KO = lO.deref();
          KO && (OO ? KO.remove(bK) : KO._remove(bK))
        }, bK
      }
      addOnce(OO) {
        return this.add(OO, void 0, void 0, void 0, !0)
      }
      remove(OO) {
        if (!OO) return !1;
        OO._remove = null;
        return -1 !== this._observers.indexOf(OO) && (this._deferUnregister(OO), !0)
      }
      removeCallback(OO, KO) {
        for (let pO = 0; pO < this._observers.length; pO++) {
          const XO = this._observers[pO];
          if (!XO._willBeUnregistered && (XO.callback === OO && (!KO || KO === XO.scope))) return this._deferUnregister(XO), !0
        }
        return !1
      }
      _deferUnregister(OO) {
        OO._willBeUnregistered || (this._numObserversMarkedAsDeleted++, OO.unregisterOnNextCall = !1, OO._willBeUnregistered = !0, setTimeout((() => {
          this._remove(OO)
        }), 0))
      }
      _remove(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        if (!OO) return !1;
        const pO = this._observers.indexOf(OO);
        return -1 !== pO && (KO && this._numObserversMarkedAsDeleted--, this._observers.splice(pO, 1), !0)
      }
      makeObserverTopPriority(OO) {
        this._remove(OO, !1), this._observers.unshift(OO)
      }
      makeObserverBottomPriority(OO) {
        this._remove(OO, !1), this._observers.push(OO)
      }
      notifyObservers(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1,
          pO = arguments.length > 2 ? arguments[2] : void 0,
          XO = arguments.length > 3 ? arguments[3] : void 0,
          bK = arguments.length > 4 ? arguments[4] : void 0;
        if (this.notifyIfTriggered && (this._hasNotified = !0, this._lastNotifiedValue = OO), !this._observers.length) return !0;
        const eO = this._eventState;
        eO.mask = KO, eO.target = pO, eO.currentTarget = XO, eO.skipNextObservers = !1, eO.lastReturnValue = OO, eO.userInfo = bK;
        for (const lO of this._observers)
          if (!lO._willBeUnregistered && (lO.mask & KO && (lO.unregisterOnNextCall && this._deferUnregister(lO), lO.scope ? eO.lastReturnValue = lO.callback.apply(lO.scope, [OO, eO]) : eO.lastReturnValue = lO.callback(OO, eO)), eO.skipNextObservers)) return !1;
        return !0
      }
      notifyObserver(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -1;
        if (this.notifyIfTriggered && (this._hasNotified = !0, this._lastNotifiedValue = KO), OO._willBeUnregistered) return;
        const XO = this._eventState;
        XO.mask = pO, XO.skipNextObservers = !1, OO.unregisterOnNextCall && this._deferUnregister(OO), OO.callback(KO, XO)
      }
      hasObservers() {
        return this._observers.length - this._numObserversMarkedAsDeleted > 0
      }
      clear() {
        for (; this._observers.length;) {
          const OO = this._observers.pop();
          OO && (OO._remove = null)
        }
        this._onObserverAdded = null, this._numObserversMarkedAsDeleted = 0, this.cleanLastNotifiedState()
      }
      cleanLastNotifiedState() {
        this._hasNotified = !1, this._lastNotifiedValue = void 0
      }
      clone() {
        const OO = new lO;
        return OO._observers = this._observers.slice(0), OO
      }
      hasSpecificMask() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1;
        for (const KO of this._observers)
          if (KO.mask & OO || KO.mask === OO) return !0;
        return !1
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);