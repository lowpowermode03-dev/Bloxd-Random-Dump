export const id = 273;
export const ids = [273];
export const modules = {
  39328: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => rp
    });
    var XO = pO(39336),
      bK = pO(39364),
      eO = pO(39372),
      lO = pO(63),
      vK = pO(77),
      CO = pO(39393),
      hO = pO(39398),
      DO = pO(3906),
      MO = pO(39403),
      aK = pO(1533),
      oO = pO(39411),
      FO = pO(39432),
      VO = pO.n(FO),
      LO = pO(39375),
      QO = pO(39384),
      zK = pO(1180),
      AO = pO(35348),
      fO = pO(1098),
      dO = pO(35356),
      TO = pO(35255),
      NO = pO(1263),
      IO = pO(533),
      yK = pO(1104),
      gK = pO(39483),
      uO = pO(39338),
      EO = pO(39341),
      jK = pO(1556),
      YO = pO(3006),
      wO = pO(26),
      iK = pO(1008);
    const rK = 1e4,
      PO = 250,
      mK = 250;
    var sO = pO(39347);
    const HO = 50,
      RO = 100;
    const SO = 2e3,
      JO = uO.C.define(),
      cK = uO.C.define(),
      BO = uO.C.define();
    class ZO extends EO.m {
      constructor(OO, KO, pO) {
        super(), this.colour = OO, this.playerName = KO, this.showName = pO
      }
      toDOM() {
        const OO = document.createElement("span");
        OO.className = "cm-remote-cursor-wrapper", OO.style.borderLeftColor = this.colour;
        const KO = document.createElement("span");
        if (KO.className = "cm-remote-cursor", KO.style.borderLeftColor = this.colour, OO.appendChild(KO), this.showName) {
          const KO = document.createElement("span");
          KO.className = "cm-remote-cursor-name", KO.style.backgroundColor = this.colour, KO.textContent = this.playerName, OO.appendChild(KO)
        }
        return OO
      }
      eq(OO) {
        return this.colour === OO.colour && this.playerName === OO.playerName && this.showName === OO.showName
      }
      get estimatedHeight() {
        return -1
      }
      ignoreEvent() {
        return !0
      }
    }

    function GO(OO, KO) {
      const pO = [],
        XO = [];
      for (const [, lO] of OO) {
        const OO = KO - lO.lastMoved < SO;
        if (pO.push({
            pos: lO.head,
            decoration: EO.c.widget({
              widget: new ZO(lO.colour, lO.playerName, OO),
              side: 1
            })
          }), lO.anchor !== lO.head) {
          const OO = Math.min(lO.anchor, lO.head),
            KO = Math.max(lO.anchor, lO.head);
          XO.push({
            from: OO,
            to: KO,
            decoration: EO.c.mark({
              class: "cm-remote-selection",
              attributes: {
                style: `background-color: ${lO.colour}33`
              }
            })
          })
        }
      }
      const bK = new uO.v,
        eO = [];
      for (const lO of pO) eO.push({
        bias: 1,
        deco: lO.decoration,
        from: lO.pos,
        to: lO.pos
      });
      for (const lO of XO) eO.push({
        bias: 0,
        deco: lO.decoration,
        from: lO.from,
        to: lO.to
      });
      eO.sort(((OO, KO) => OO.from - KO.from || OO.deco.startSide - KO.deco.startSide || OO.bias - KO.bias));
      for (const lO of eO) bK.add(lO.from, lO.to, lO.deco);
      return bK.finish()
    }
    const qK = uO.G.define({
      create: () => ({
        cursors: new Map,
        ql: EO.c.none
      }),
      update(OO, KO) {
        let pO = OO.cursors,
          XO = !1;
        if (KO.docChanged) {
          const OO = new Map;
          for (const [XO, bK] of pO) OO.set(XO, {
            ...bK,
            anchor: KO.changes.mapPos(bK.anchor, 1),
            head: KO.changes.mapPos(bK.head, 1)
          });
          pO = OO, XO = !0
        }
        for (const bK of KO.effects)
          if (bK.is(JO)) {
            if (!Number.isInteger(bK.value.anchor) || !Number.isInteger(bK.value.head)) {
              console.warn(`Code Editor: ignored player ${bK.value.playerId}'s cursor at ${bK.value.anchor}-${bK.value.head}`);
              continue
            }
            const eO = KO.state.doc.length,
              lO = {
                ...bK.value,
                anchor: Math.min(bK.value.anchor, eO),
                head: Math.min(bK.value.head, eO)
              };
            pO === OO.cursors && (pO = new Map(pO)), pO.set(lO.playerId, lO), XO = !0
          } else bK.is(cK) ? pO.has(bK.value) && (pO === OO.cursors && (pO = new Map(pO)), pO.delete(bK.value), XO = !0) : bK.is(BO) && (XO = !0);
        return XO ? {
          cursors: pO,
          ql: GO(pO, Date.now())
        } : OO
      },
      provide: OO => EO.h.ql.from(OO, (OO => OO.ql))
    });
    var xK = pO(39358);
    const nO = "#e45649",
      WO = "#383a42",
      tK = "#696c77",
      kK = "#986801",
      UO = "#e5e5e6",
      OK = "#fafafa",
      KK = "#eaeaeb",
      pK = "#526fff",
      XK = EO.h.theme({
        "&": {
          color: WO,
          backgroundColor: OK
        },
        ".cm-content": {
          caretColor: pK
        },
        ".cm-cursor, .cm-dropCursor": {
          borderLeftColor: pK
        },
        "&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": {
          backgroundColor: "#d7d8de"
        },
        ".cm-panels": {
          backgroundColor: "#f0f0f1",
          color: WO
        },
        ".cm-panels.cm-panels-top": {
          borderBottom: "2px solid #d4d4d6"
        },
        ".cm-panels.cm-panels-bottom": {
          borderTop: "2px solid #d4d4d6"
        },
        ".cm-searchMatch": {
          backgroundColor: "#72a1ff40",
          outline: "1px solid #457dff"
        },
        ".cm-searchMatch.cm-searchMatch-selected": {
          backgroundColor: "#6199ff2f"
        },
        ".cm-activeLine": {
          backgroundColor: "#383a420a"
        },
        ".cm-selectionMatch": {
          backgroundColor: "#50a14f26"
        },
        "&.cm-focused .cm-matchingBracket, &.cm-focused .cm-nonmatchingBracket": {
          backgroundColor: "#4078f233"
        },
        ".cm-gutters": {
          backgroundColor: OK,
          color: tK,
          border: "none"
        },
        ".cm-activeLineGutter": {
          backgroundColor: UO
        },
        ".cm-foldPlaceholder": {
          backgroundColor: "transparent",
          border: "none",
          color: "#555"
        },
        ".cm-tooltip": {
          border: "none",
          backgroundColor: KK
        },
        ".cm-tooltip .cm-tooltip-arrow:before": {
          borderTopColor: "transparent",
          borderBottomColor: "transparent"
        },
        ".cm-tooltip .cm-tooltip-arrow:after": {
          borderTopColor: KK,
          borderBottomColor: KK
        },
        ".cm-tooltip-autocomplete": {
          "& > ul > li[aria-selected]": {
            backgroundColor: UO,
            color: WO
          }
        }
      }, {
        dark: !1
      }),
      bp = sO.d.define([{
        tag: xK.l.keyword,
        color: "#a626a4"
      }, {
        tag: [xK.l.name, xK.l.deleted, xK.l.character, xK.l.propertyName, xK.l.macroName],
        color: nO
      }, {
        tag: [xK.l.function(xK.l.variableName), xK.l.labelName],
        color: "#4078f2"
      }, {
        tag: [xK.l.color, xK.l.constant(xK.l.name), xK.l.standard(xK.l.name)],
        color: kK
      }, {
        tag: [xK.l.definition(xK.l.name), xK.l.separator],
        color: WO
      }, {
        tag: [xK.l.typeName, xK.l.className, xK.l.number, xK.l.changed, xK.l.annotation, xK.l.modifier, xK.l.self, xK.l.namespace],
        color: "#c18401"
      }, {
        tag: [xK.l.operator, xK.l.operatorKeyword, xK.l.url, xK.l.escape, xK.l.regexp, xK.l.link, xK.l.special(xK.l.string)],
        color: "#0184bc"
      }, {
        tag: [xK.l.meta, xK.l.comment],
        color: tK
      }, {
        tag: xK.l.strong,
        fontWeight: "bold"
      }, {
        tag: xK.l.emphasis,
        fontStyle: "italic"
      }, {
        tag: xK.l.strikethrough,
        textDecoration: "line-through"
      }, {
        tag: xK.l.link,
        color: tK,
        textDecoration: "underline"
      }, {
        tag: xK.l.heading,
        fontWeight: "bold",
        color: nO
      }, {
        tag: [xK.l.atom, xK.l.bool, xK.l.special(xK.l.variableName)],
        color: kK
      }, {
        tag: [xK.l.processingInstruction, xK.l.string, xK.l.inserted],
        color: "#50a14f"
      }, {
        tag: xK.l.invalid,
        color: "#000000"
      }]),
      eK = [XK, (0, sO.eb)(bp)];
    var lK = pO(35383),
      vp = pO(39492);
    const CK = eO.j.define(),
      hK = eO.l.define({
        create: () => !1,
        update(OO, KO) {
          for (const pO of KO.effects) pO.is(CK) && (OO = pO.value);
          return OO
        }
      }),
      DK = [{
        action: "explain",
        label: "Explain this"
      }, {
        action: "fix",
        label: "Fix this"
      }, {
        action: "change",
        label: "Change this\u2026"
      }];

    function MK(OO, KO) {
      return [hK, eO.n.fromClass(class {
        constructor(OO) {
          this.view = OO, this.onDown = OO => {
            const KO = OO.target instanceof Element && null !== OO.target.closest(".cm-tooltip");
            0 !== OO.button || KO || this.view.state.field(hK) || this.view.dispatch({
              effects: CK.of(!0)
            })
          }, this.onUp = () => {
            this.view.state.field(hK) && this.view.dispatch({
              effects: CK.of(!1)
            })
          }, OO.dom.addEventListener("mousedown", this.onDown), document.addEventListener("mouseup", this.onUp), window.addEventListener("blur", this.onUp)
        }
        destroy() {
          this.view.dom.removeEventListener("mousedown", this.onDown), document.removeEventListener("mouseup", this.onUp), window.removeEventListener("blur", this.onUp)
        }
      }), eO.w.compute(["selection", hK], (pO => function(OO, KO, pO) {
        const XO = OO.selection.main;
        return XO.empty || OO.field(hK) || OO.sliceDoc(XO.from, XO.to).trim().length < 2 ? null : {
          pos: XO.from,
          above: !0,
          create: OO => {
            const XO = document.createElement("div");
            XO.className = "CodeSelectionActions", XO.setAttribute("role", "toolbar"), XO.setAttribute("aria-label", "AI Helper: picked code");
            for (const {
                action: bK,
                label: eO
              }
              of DK) {
              if (!pO && "explain" !== bK) continue;
              const lO = document.createElement("button");
              lO.type = "button", lO.textContent = eO, "change" !== bK && (lO.title = vp.d, lO.dataset.asksAi = "true"), lO.addEventListener("mousedown", (OO => {
                OO.preventDefault()
              })), lO.addEventListener("click", (() => {
                const pO = OO.state.selection.main;
                if (pO.empty) return;
                const XO = {
                  action: bK,
                  path: KO,
                  fromLine: OO.state.doc.lineAt(pO.from).number,
                  toLine: OO.state.doc.lineAt(pO.to > pO.from && OO.state.doc.lineAt(pO.to).from === pO.to ? pO.to - 1 : pO.to).number,
                  text: OO.state.sliceDoc(pO.from, pO.to)
                };
                wO.i.pl("WorldCodeAiSelection", XO), OO.dispatch({
                  selection: {
                    anchor: pO.to
                  }
                })
              })), XO.appendChild(lO)
            }
            return {
              dom: XO
            }
          }
        }
      }(pO, OO, KO)))]
    }
    var ap = pO(976);
    const oK = new Set(["(", "{", "[", "<"]),
      FK = new Set([")", "}", "]", ">"]),
      VK = {
        text: "var(--codeTooltipText, white)",
        parameterName: "var(--codeTooltipParameterName, orange)",
        parameter: "var(--codeTooltipParameter, cyan)",
        suffix: "var(--codeTooltipSuffix, pink)",
        docs: "var(--codeTooltipDocs, gray)"
      };

    function LK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;

      function pO(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        const XO = [];
        for (const bK of OO) {
          let OO;
          OO = "punctuation" === bK.kind ? VK.text : "parameterName" === bK.kind ? VK.parameterName : KO, XO.push({
            str: bK.text,
            style: {
              color: OO,
              opacity: pO ? .5 : void 0
            }
          })
        }
        return XO
      }
      const XO = [];
      if (XO.push(...pO(OO.prefixDisplayParts, VK.text)), OO.parameters.length > 0) {
        XO.push("\n");
        for (let bK = 0; bK < OO.parameters.length; bK++) {
          const eO = OO.parameters[bK];
          XO.push("\t"), XO.push(...pO(eO.displayParts, VK.parameter, null !== KO && bK !== KO)), XO.push("\n")
        }
      }
      return XO.push(...pO(OO.suffixDisplayParts, VK.suffix)), OO.documentation && (XO.push("\n\n"), XO.push(...pO(OO.documentation, VK.docs))), XO
    }
    var QK = function(OO) {
      return OO[OO.VariableDefinedElsewhere = 2304] = "VariableDefinedElsewhere", OO[OO.DuplicateIdentifier = 2300] = "DuplicateIdentifier", OO
    }(QK || {});
    const zp = new Set([QK.DuplicateIdentifier]),
      AK = new Set([QK.VariableDefinedElsewhere]),
      fK = new Set([]),
      dK = "/index.js";

    function TK(OO) {
      return "/" + OO
    }

    function NK(OO, KO, pO) {
      OO.getSourceFile(KO) && OO.deleteFile(KO), OO.createFile(KO, pO)
    }

    function IK(OO) {
      return !!OO && ((0, dO.u)(OO) || (0, dO.q)(OO))
    }

    function yp(OO, KO, pO) {
      return () => {
        let XO = [...KO.languageService.getSemanticDiagnostics(pO), ...KO.languageService.getSyntacticDiagnostics(pO)];
        return XO = XO.filter((OO => !(0, IO.I)(OO.start) && !(0, IO.I)(OO.length) && !zp.has(OO.code))), OO || (XO = XO.filter((OO => !AK.has(OO.code)))), XO.map((OO => ({
          from: OO.start,
          to: OO.start + OO.length,
          message: "string" === typeof OO.messageText ? OO.messageText : OO.messageText.messageText,
          severity: fK.has(OO.code) ? "warning" : "error"
        })))
      }
    }

    function gp(OO, KO) {
      return pO => {
        var XO, bK;
        const eO = OO.languageService.getCompletionsAtPosition(KO, pO.pos, {});
        if (!eO) return {
          from: pO.pos,
          options: []
        };
        let lO = null !== (XO = null === (bK = eO.optionalReplacementSpan) || void 0 === bK ? void 0 : bK.start) && void 0 !== XO ? XO : pO.pos;
        if (!eO.optionalReplacementSpan) {
          const OO = pO.state.doc.sliceString(0, pO.pos);
          for (; lO > 0 && /[\w$]/.test(OO[lO - 1]);) lO--
        }
        return eO.entries = eO.entries.filter((OO => OO.kind !== VO().ScriptElementKind.warning)), {
          from: lO,
          options: eO.entries.map((XO => {
            var bK, eO, vK, CO;
            const hO = OO.languageService.getCompletionEntryDetails(KO, pO.pos, XO.name, {}, XO.source, {}, XO.data),
              DO = null !== (bK = null === (eO = XO.replacementSpan) || void 0 === eO ? void 0 : eO.start) && void 0 !== bK ? bK : lO,
              MO = XO.replacementSpan ? XO.replacementSpan.start + XO.replacementSpan.length : pO.pos,
              aK = null !== (vK = XO.insertText) && void 0 !== vK ? vK : XO.name;
            return {
              label: XO.name,
              detail: null === hO || void 0 === hO ? void 0 : hO.displayParts.map((OO => OO.text)).join(""),
              info: null === hO || void 0 === hO || null === (CO = hO.documentation) || void 0 === CO ? void 0 : CO.map((OO => OO.text)).join(""),
              apply: OO => {
                OO.dispatch({
                  changes: {
                    from: DO,
                    to: MO,
                    insert: aK
                  },
                  selection: {
                    anchor: DO + aK.length
                  }
                })
              }
            }
          }))
        }
      }
    }

    function uK(OO) {
      return KO => {
        const pO = document.createElement("div");
        pO.className = "CodeEditorTooltip";
        let XO = !1;
        return queueMicrotask((() => {
          XO || (vK.render((0, ap.jsx)(aK.d, {
            text: OO
          }), pO), KO.requestMeasure())
        })), {
          dom: pO,
          destroy() {
            XO = !0, queueMicrotask((() => {
              vK.unmountComponentAtNode(pO)
            }))
          }
        }
      }
    }

    function EK(OO, KO, pO) {
      return XO => {
        var bK;
        if (!KO) return [];
        const eO = null === (bK = XO.selection.Xl[0]) || void 0 === bK ? void 0 : bK.head;
        if (void 0 === eO) return [];
        const lO = OO.languageService.getSignatureHelpItems(pO, eO, {});
        if (!lO || !lO.items.length) return [];
        const vK = lO.applicableSpan.start - lO.items[0].prefixDisplayParts.map((OO => OO.text)).join("").length,
          CO = lO.applicableSpan.start,
          hO = XO.doc.lineAt(eO),
          DO = hO.from,
          MO = Math.min(hO.to, eO);
        let aK, oO;
        return vK < DO ? (aK = DO, oO = MO) : (aK = vK, oO = CO), [{
          pos: aK,
          end: oO,
          above: !1,
          create: uK(LK(lO.items[0], lO.argumentIndex))
        }]
      }
    }

    function jp(OO, KO) {
      return (pO, XO, bK) => {
        const eO = OO.languageService.getQuickInfoAtPosition(KO, XO);
        if (!eO) return [];
        const lO = eO.textSpan.start,
          vK = eO.textSpan.start + eO.textSpan.length;
        if (XO < lO || XO >= vK) return [];
        if (eO.kind === VO().ScriptElementKind.memberFunctionElement || eO.kind === VO().ScriptElementKind.variableElement && "declare" === eO.kindModifiers) {
          const OO = eO.displayParts.findIndex((OO => "space" === OO.kind)); - 1 !== OO && (eO.displayParts = eO.displayParts.slice(OO));
          const KO = {
              prefixDisplayParts: [],
              parameters: [],
              suffixDisplayParts: [],
              documentation: []
            },
            pO = eO.displayParts.findIndex((OO => "punctuation" === OO.kind && "(" === OO.text)); - 1 !== pO && (KO.prefixDisplayParts = eO.displayParts.slice(0, pO + 1), eO.displayParts = eO.displayParts.slice(pO + 1));
          const XO = eO.displayParts.findLastIndex((OO => "punctuation" === OO.kind && ")" === OO.text)); - 1 !== XO && (KO.suffixDisplayParts = eO.displayParts.slice(XO), eO.displayParts = eO.displayParts.slice(0, XO));
          let bK = 0,
            CO = [];
          for (const lO of eO.displayParts)
            if (oK.has(lO.text) ? bK++ : FK.has(lO.text) && bK--, "lineBreak" !== lO.kind) {
              if ("space" === lO.kind) {
                if (0 === CO.length) continue;
                CO.push({
                  kind: "space",
                  text: " "
                })
              } else CO.push(lO);
              0 === bK && "," === lO.text && (KO.parameters.push({
                displayParts: CO
              }), CO = [])
            } return CO.length > 0 && KO.parameters.push({
            displayParts: CO
          }), KO.documentation = eO.documentation, [{
            pos: lO,
            end: vK,
            above: !0,
            create: uK(LK(KO))
          }]
        }
        const CO = [];
        for (const OO of eO.displayParts) CO.push({
          str: OO.text,
          style: {
            color: VK.text
          }
        });
        if (eO.documentation) {
          CO.push("\n\n");
          for (const OO of eO.documentation) CO.push({
            str: OO.text,
            style: {
              color: VK.docs
            }
          })
        }
        return [{
          pos: lO,
          end: vK,
          above: !0,
          create: uK(CO)
        }]
      }
    }
    const YK = {
      indentSize: 4,
      tabSize: 4,
      newLineCharacter: "\n",
      convertTabsToSpaces: !0,
      insertSpaceAfterCommaDelimiter: !0,
      insertSpaceAfterSemicolonInForStatements: !0,
      insertSpaceBeforeAndAfterBinaryOperators: !0,
      insertSpaceAfterKeywordsInControlFlowStatements: !0,
      insertSpaceAfterFunctionKeywordForAnonymousFunctions: !0,
      insertSpaceBeforeFunctionParenthesis: !1,
      insertSpaceAfterOpeningAndBeforeClosingNonemptyParenthesis: !1,
      insertSpaceAfterOpeningAndBeforeClosingNonemptyBrackets: !1,
      insertSpaceAfterOpeningAndBeforeClosingNonemptyBraces: !0,
      insertSpaceAfterOpeningAndBeforeClosingTemplateStringBraces: !1,
      insertSpaceAfterOpeningAndBeforeClosingJsxExpressionBraces: !1,
      insertSpaceAfterTypeAssertion: !1,
      placeOpenBraceOnNewLineForFunctions: !1,
      placeOpenBraceOnNewLineForControlBlocks: !1,
      semicolons: VO().SemicolonPreference.Insert
    };
    const wK = eO.j.define(),
      ip = {
        lineNumbers: !0,
        tabSize: 4
      };

    function rp(OO) {
      let {
        isLobbyCode: KO,
        code: pO,
        onChange: vK,
        canEditCode: aK,
        setTemporaryMessage: FO,
        close: IO,
        showTooltips: ZO,
        lightMode: GO,
        collabState: xK,
        onRemoteDocChange: nO,
        files: WO,
        activePath: tK,
        pluginName: kK,
        pluginFile: UO,
        pluginSource: OK,
        setActiveDocReplacer: KK,
        showAiHints: pK,
        canAiChangeCode: XK = aK
      } = OO;
      const [bp, vp] = (0, lO.useState)(null), CK = null === xK || void 0 === xK ? void 0 : xK.version, hK = null === xK || void 0 === xK ? void 0 : xK.clientID, DK = (0, lO.useRef)({
        isLobbyCode: KO,
        files: WO,
        code: pO,
        activePath: tK
      }), oK = (0, lO.useRef)(nO);
      oK.current = nO;
      const FK = (0, lO.useRef)(null),
        VK = (0, lO.useRef)(xK);
      VK.current = xK;
      const LK = (0, lO.useRef)(null),
        QK = (0, lO.useRef)(null),
        zp = (0, lO.useRef)(null),
        AK = (0, lO.useRef)(IO);
      AK.current = IO;
      const fK = (0, lO.useRef)(pO);
      fK.current = pO;
      const uK = (0, lO.useRef)(OK);
      uK.current = OK;
      const rp = function(OO, KO, pO, XO) {
        return pO ? `/plugin-preview/${pO}/${null!==XO&&void 0!==XO?XO:"index.ts"}` : OO ? TK(null !== KO && void 0 !== KO ? KO : fO.f) : dK
      }(KO, tK, kK, UO);
      (0, lO.useEffect)((() => {
        !async function() {
          const {
            isLobbyCode: OO,
            files: KO,
            code: pO,
            activePath: XO
          } = DK.current, bK = {
            allowJs: !0,
            checkJs: !1,
            noLib: !0,
            strict: !1,
            module: VO().ModuleKind.ESNext,
            moduleResolution: VO().ModuleResolutionKind.Bundler,
            target: VO().ScriptTarget.ES2015,
            paths: {
              "@bloxd": ["/node_modules/@bloxd/index.d.ts"],
              ...Object.fromEntries(Object.values(AO.e).map((OO => [OO.specifier, [OO.typesVfsPath]])))
            }
          }, eO = new Map, lO = [];
          if (OO) {
            const OO = null !== KO && void 0 !== KO ? KO : {
              [fO.f]: pO || "\n"
            };
            for (const [KO, pO] of Object.entries(OO)) {
              const OO = TK(KO);
              eO.set(OO, pO || "\n"), lO.push(OO)
            }
            const bK = TK(null !== XO && void 0 !== XO ? XO : fO.f);
            eO.has(bK) ? eO.set(bK, pO || "\n") : (eO.set(bK, pO || "\n"), lO.push(bK)), eO.set("/node_modules/@bloxd/index.d.ts", DO.default), lO.push("/node_modules/@bloxd/index.d.ts");
            for (const KO of Object.values(AO.e)) {
              eO.set(KO.typesVfsPath, KO.types), lO.push(KO.typesVfsPath);
              for (const [OO, pO] of Object.entries(KO.files)) {
                const XO = `/plugin-preview/${KO.name}/${OO}`;
                eO.set(XO, pO || "\n"), lO.push(XO)
              }
            }
          } else eO.set(dK, pO || "\n"), lO.push(dK);
          eO.set("/globals.d.ts", OO ? hO.b : CO.b), eO.set("/lib.d.ts", MO.e), lO.push("/globals.d.ts", "/lib.d.ts");
          const vK = oO.e(eO),
            aK = oO.g(vK, lO, VO(), bK);
          vp({
            Vl: aK,
            fsMap: eO
          })
        }()
      }), []), (0, lO.useEffect)((() => {
        var OO, XO;
        if (!bp || !KO) return;
        const {
          Vl: bK,
          fsMap: eO
        } = bp;
        if (function(OO, KO, pO) {
            const XO = new Set;
            for (const [bK, eO] of Object.entries(pO)) {
              const pO = TK(bK);
              XO.add(pO);
              const lO = eO || "\n";
              KO.get(pO) !== lO && (KO.set(pO, lO), NK(OO, pO, lO))
            }
            for (const bK of [...KO.keys()]) "/globals.d.ts" === bK || "/lib.d.ts" === bK || bK.startsWith("/node_modules/") || bK.startsWith("/plugin-preview/") || XO.has(bK) || (KO.delete(bK), OO.getSourceFile(bK) && OO.deleteFile(bK))
          }(bK, eO, null !== WO && void 0 !== WO ? WO : {
            [fO.f]: pO || "\n"
          }), kK) return void NK(bK, rp, OK || "\n");
        const lO = null !== (OO = null === (XO = FK.current) || void 0 === XO ? void 0 : XO.state.doc.toString()) && void 0 !== OO ? OO : pO;
        NK(bK, rp, lO || "\n")
      }), [WO, tK, bp, kK, OK, rp, pO, KO]), (0, lO.useEffect)((() => {
        if (!bp) return;
        const {
          Vl: OO
        } = bp;
        NK(OO, rp, (kK ? OK : pO) || "\n")
      }), [pO, kK, OK, rp, bp]), (0, lO.useEffect)((() => () => {
        QK.current && (QK.current(), QK.current = null)
      }), []), (0, lO.useEffect)((() => (KK(((OO, KO) => {
        if (kK) return !1;
        const pO = FK.current,
          XO = VK.current,
          bK = XO ? (0, dO.C)(XO.docKey) : null;
        if (!pO || !XO || LK.current !== XO.clientID || OO !== bK) return !1;
        const eO = pO.state.doc.toString();
        return eO !== KO && pO.dispatch({
          changes: {
            from: 0,
            to: eO.length,
            insert: KO
          }
        }), !0
      })), () => {
        FK.current = null, LK.current = null, KK(null)
      })), [KK, kK]);
      const PK = KO ? kK ? null : null !== tK && void 0 !== tK ? tK : fO.f : lK.b,
        mp = function(OO, KO) {
          const pO = (0, lO.useRef)(null);
          (0, lO.useEffect)((() => {
            var OO;
            (null === (OO = pO.current) || void 0 === OO ? void 0 : OO.path) !== KO && (pO.current = null)
          }), [KO]);
          const XO = OO => {
            const XO = pO.current;
            if (null === OO || void 0 === OO || !OO.dom.isConnected || !XO || XO.path !== KO) return;
            pO.current = null;
            const {
              doc: bK
            } = OO.state, {
              from: lO
            } = bK.line(Math.min(Math.max(XO.line, 1), bK.lines));
            OO.dispatch({
              selection: {
                anchor: lO
              },
              effects: eO.d.scrollIntoView(lO, {
                y: "center"
              })
            }), OO.focus()
          };
          return (0, NO.f)("CodeEditorGoToLine", (KO => {
            pO.current = KO, XO(OO.current)
          })), XO
        }(FK, PK);
      (0, NO.f)("FormatCode", (() => {
        if (!bp || !FK.current || kK) return;
        const {
          Vl: OO,
          fsMap: pO
        } = bp, XO = OO.getSourceFile(rp).getFullText();
        let bK = 0;
        if (KO && WO)
          for (const [KO, vK] of Object.entries(WO)) KO !== (null !== tK && void 0 !== tK ? tK : fO.f) && (bK += vK.length);
        const eO = function(OO, KO, pO, XO, bK) {
          const eO = OO.languageService.getFormattingEditsForDocument(XO, YK);
          if (!eO.length) return yK.c.error("Code is already formatted.");
          eO.sort(((OO, KO) => KO.span.start - OO.span.start));
          let lO = OO.getSourceFile(XO).getFullText();
          for (const vK of eO) lO = lO.slice(0, vK.span.start) + vK.oB + lO.slice(vK.span.start + vK.span.length);
          return lO !== (pO ? (0, TO.j)(lO, bK) : (0, TO.g)(lO)) ? yK.c.error("Formatting the code will go beyond the character limit.") : yK.c.value(lO)
        }(OO, 0, KO, rp, bK);
        if (eO.isError()) return void FO({
          message: eO.asError().message,
          type: "warning"
        });
        const lO = eO.getValue();
        lO && (FK.current.dispatch({
          changes: {
            from: 0,
            to: XO.length,
            insert: lO
          },
          selection: {
            anchor: lO.length
          }
        }), NK(OO, rp, lO), vK(lO))
      }));
      const sK = (0, lO.useMemo)((() => {
        if (!bp) return [];
        const {
          Vl: OO,
          fsMap: pO
        } = bp;
        ! function(OO, KO, pO, XO) {
          if (OO.getSourceFile(pO)) return;
          const bK = XO || "\n";
          KO.set(pO, bK), OO.createFile(pO, bK)
        }(OO, pO, rp, (kK ? uK.current : fK.current) || "\n");
        const lO = KO && IK(kK ? null !== UO && void 0 !== UO ? UO : "index.ts" : tK),
          vK = [(0, bK.c)({
            jsx: !1,
            typescript: lO
          }), eO.g.highest(eO.d.domEventHandlers({
            keydown: OO => "Escape" === OO.key ? (AK.current(), OO.stopPropagation(), !0) : (OO.stopPropagation(), !1)
          })), (0, XO.c)({
            override: [gp(OO, rp)]
          }), EO.l.fromClass(class {
            constructor(OO) {
              this.view = OO, this.timeout = null, this.scheduleParse()
            }
            update(OO) {
              (OO.docChanged || OO.viewportChanged) && this.scheduleParse()
            }
            destroy() {
              null !== this.timeout && (clearTimeout(this.timeout), this.timeout = null)
            }
            scheduleParse() {
              null === this.timeout && (this.timeout = setTimeout((() => {
                this.timeout = null;
                const OO = this.view.viewport.to;
                (0, sO.gb)(this.view.state, OO) || (0, sO.K)(this.view, OO, HO) || this.scheduleParse()
              }), RO))
            }
          }), eO.d.lineWrapping, eO.l.define({
            create: EK(OO, ZO, rp),
            update(KO, pO) {
              const XO = pO.effects.some((OO => OO.is(wK)));
              return pO.docChanged || pO.selection || XO ? (NK(OO, rp, pO.state.doc.toString() || " "), EK(OO, ZO, rp)(pO.state)) : KO
            },
            provide: OO => eO.w.computeN([OO], (KO => KO.field(OO)))
          }), (0, eO.s)(jp(OO, rp)), (0, QO.g)(yp(KO, OO, rp)), eO.n.fromClass(class {
            constructor(OO) {
              this.view = OO, this.searchPanel = null
            }
            update(OO) {
              const KO = OO.view.dom.querySelector(".cm-search");
              if (KO !== this.searchPanel) {
                if (this.searchPanel = KO, !this.searchPanel) return;
                this.searchPanel.addEventListener("keydown", (OO => {
                  "Escape" === OO.key && (0, LO.e)(this.view), OO.stopPropagation()
                }))
              }
            }
          })];
        pK && !kK && vK.push(MK(KO ? null !== tK && void 0 !== tK ? tK : fO.f : lK.b, XK));
        const CO = VK.current;
        if (CO && !kK) {
          vK.push(... function(OO, KO, pO, XO, bK) {
            let eO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5];
            const lO = (0, dO.C)(pO),
              vK = EO.l.fromClass(class {
                constructor(OO) {
                  this.view = OO, this.pushing = !1, this.pushTimeout = null, this.pushDelayTimeout = null, this.cursorTimeout = null, this.lastPushTime = 0, this.pulling = !1, this.pullPending = !1, this.lastCursorSent = 0, this.destroyed = !1, this.subToken = void 0, this.subToken = wO.i.subscribe("codeCollab", (OO => {
                    OO.docKey === lO && OO.type === dO.e.Updates && (OO.updates ? this.applyUpdates(OO.updates) : this.pull())
                  })), this.pull()
                }
                applyUpdates(OO) {
                  const KO = JSON.parse(OO).map((OO => ({
                    clientID: OO.clientID,
                    changes: uO.ChangeSet.fromJSON(OO.changes)
                  })));
                  KO.length > 0 && (this.view.dispatch((0, gK.h)(this.view.state, KO)), bK && bK(this.view.state.doc.toString())), this.clearPushState(), this.push()
                }
                clearPushState() {
                  this.pushing = !1, this.pushTimeout && (clearTimeout(this.pushTimeout), this.pushTimeout = null), this.pushDelayTimeout && (clearTimeout(this.pushDelayTimeout), this.pushDelayTimeout = null)
                }
                update(OO) {
                  eO && (OO.docChanged && this.push(), this.sendCursor())
                }
                push() {
                  const OO = (0, gK.j)(this.view.state);
                  if (this.pushing || !OO.length) return;
                  const KO = Date.now() - this.lastPushTime;
                  if (KO < mK) return void(this.pushDelayTimeout || (this.pushDelayTimeout = setTimeout((() => {
                    this.pushDelayTimeout = null, this.push()
                  }), mK - KO)));
                  this.pushing = !0, this.lastPushTime = Date.now(), this.pushTimeout = setTimeout((() => {
                    this.clearPushState(), this.push()
                  }), rK);
                  const pO = (0, gK.e)(this.view.state),
                    bK = OO.map((OO => ({
                      clientID: OO.clientID,
                      changes: OO.changes.toJSON()
                    }))),
                    eO = JSON.stringify(bK);
                  eO.length <= dO.i ? jK.gameBridge.send("sendCodeCollab", {
                    Zm: dO.b.Push,
                    Wm: lO,
                    Xs: pO,
                    Fs: eO
                  }) : (0, iK.postJsonWithMetricsCookiesAndJsonResponse)(`${XO.gsUrl}/code/collab-push`, YO.q["collab-push"].toBuffer({
                    gameNameWithVariation: XO.gameNameWithVariation,
                    lobbyName: XO.lobbyName,
                    docKey: lO,
                    version: pO,
                    updates: eO
                  }), {
                    retries: 0
                  }).catch((OO => {
                    console.error("[CodeCollab] HTTP push failed", OO)
                  }))
                }
                pull() {
                  if (this.destroyed) return;
                  if (this.pulling) return void(this.pullPending = !0);
                  this.pulling = !0, this.pullPending = !1;
                  const OO = (0, gK.e)(this.view.state);
                  (0, iK.postJsonWithMetricsCookiesAndJsonResponse)(`${XO.gsUrl}/code/collab-pull`, YO.q["collab-pull"].toBuffer({
                    gameNameWithVariation: XO.gameNameWithVariation,
                    lobbyName: XO.lobbyName,
                    docKey: lO,
                    fromVersion: OO
                  }), {
                    retries: 1
                  }).then((OO => {
                    this.destroyed || (OO.fullDoc ? wO.i.pl("codeCollabRejoin", {
                      docKey: lO,
                      doc: OO.fullDoc,
                      version: OO.version
                    }) : this.applyUpdates(OO.updates))
                  })).catch((OO => {
                    console.error("[CodeCollab] Pull failed", OO)
                  })).finally((() => {
                    this.pulling = !1, this.pullPending && this.pull()
                  }))
                }
                sendCursor() {
                  const OO = Date.now();
                  if (OO - this.lastCursorSent < PO) return void(this.cursorTimeout || (this.cursorTimeout = setTimeout((() => {
                    this.cursorTimeout = null, this.sendCursor()
                  }), PO)));
                  this.lastCursorSent = OO;
                  const KO = this.view.state.selection.main;
                  jK.gameBridge.send("sendCodeCollab", {
                    Zm: dO.b.Cursor,
                    Wm: lO,
                    Qs: KO.anchor,
                    jH: KO.head
                  })
                }
                destroy() {
                  this.destroyed = !0, wO.i.unsubscribe(this.subToken), this.clearPushState(), this.cursorTimeout && clearTimeout(this.cursorTimeout)
                }
              });
            return [(0, gK.b)({
              startVersion: OO,
              clientID: KO
            }), vK]
          }(CK, hK, CO.docKey, CO.httpConfig, (OO => {
            var KO;
            null === (KO = oK.current) || void 0 === KO || KO.call(oK, OO)
          }), aK));
          const OO = function(OO, KO) {
            const pO = (0, dO.C)(OO);
            return {
              extensions: [qK],
              connect(OO) {
                if (KO) {
                  const pO = KO.map((OO => JO.of({
                    playerId: OO.playerId,
                    playerName: OO.playerName,
                    colour: OO.colour,
                    anchor: OO.anchor,
                    head: OO.head,
                    lastMoved: Date.now()
                  })));
                  pO.length > 0 && OO.dispatch({
                    effects: pO
                  })
                }
                const XO = wO.i.subscribe("codeCollab", (KO => {
                    if (KO.docKey === pO)
                      if (KO.type === dO.e.RemoteCursor) OO.dispatch({
                        effects: JO.of({
                          playerId: KO.playerId,
                          playerName: KO.playerName,
                          colour: KO.colour,
                          anchor: KO.anchor,
                          head: KO.head,
                          lastMoved: Date.now()
                        })
                      });
                      else if (KO.type === dO.e.Presence) {
                      const pO = JSON.parse(KO.peers),
                        XO = new Set(pO.map((OO => OO.playerId))),
                        bK = OO.state.field(qK),
                        eO = [];
                      for (const [OO] of bK.cursors) XO.has(OO) || eO.push(cK.of(OO));
                      eO.length > 0 && OO.dispatch({
                        effects: eO
                      })
                    }
                  })),
                  bK = setInterval((() => {
                    OO.dom.isConnected ? OO.dispatch({
                      effects: BO.of(Date.now())
                    }) : clearInterval(bK)
                  }), SO);
                return () => {
                  wO.i.unsubscribe(XO), clearInterval(bK)
                }
              }
            }
          }(CO.docKey, CO.existingCursors);
          vK.push(...OO.extensions), zp.current = OO.connect
        } else zp.current = null;
        return vK
      }), [KO, bp, ZO, CK, hK, rp, tK, kK, UO, aK, pK, XK]);
      if (!bp || !xK && !kK) return (0, ap.jsx)("div", {
        className: "CodeEditorContent",
        children: (0, ap.jsx)(zK.e, {})
      });
      const HK = kK ? `plugin-${kK}-${null!==UO&&void 0!==UO?UO:"index.ts"}` : xK ? `collab-${xK.clientID}` : `local-${KO}`;
      return (0, ap.jsx)(eO.r, {
        value: kK ? null !== OK && void 0 !== OK ? OK : "" : pO,
        onChange: vK,
        extensions: sK,
        className: "CodeEditorContent",
        theme: GO ? eK : "dark",
        editable: aK && !kK,
        basicSetup: ip,
        onCreateEditor: OO => {
          var KO;
          FK.current = OO, LK.current = null !== (KO = null === xK || void 0 === xK ? void 0 : xK.clientID) && void 0 !== KO ? KO : null, FK.current.focus(), mp(OO), QK.current && QK.current(), zp.current && (QK.current = zp.current(OO))
        }
      }, HK)
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);