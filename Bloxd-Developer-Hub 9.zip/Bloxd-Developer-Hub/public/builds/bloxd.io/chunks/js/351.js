export const id = 351;
export const ids = [351];
export const modules = {
  59329: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      passPixelShaderWGSL: () => lO
    });
    var XO = pO(37907);
    const bK = "passPixelShader",
      eO = "varying vUV: vec2f;var textureSamplerSampler: sampler;var textureSampler: texture_2d<f32>;\n#define CUSTOM_FRAGMENT_DEFINITIONS\n@fragment\nfn main(input: FragmentInputs)->FragmentOutputs {fragmentOutputs.color=textureSample(textureSampler,textureSamplerSampler,input.vUV);}";
    XO.b.ShadersStoreWGSL[bK] || (XO.b.ShadersStoreWGSL[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);