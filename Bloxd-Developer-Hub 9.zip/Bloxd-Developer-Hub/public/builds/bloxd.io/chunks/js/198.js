export const id = 198;
export const ids = [198];
export const modules = {
  35181: OO => {
    OO.exports = {
      aliceblue: [240, 248, 255],
      antiquewhite: [250, 235, 215],
      aqua: [0, 255, 255],
      aquamarine: [127, 255, 212],
      azure: [240, 255, 255],
      beige: [245, 245, 220],
      bisque: [255, 228, 196],
      black: [0, 0, 0],
      blanchedalmond: [255, 235, 205],
      blue: [0, 0, 255],
      blueviolet: [138, 43, 226],
      brown: [165, 42, 42],
      burlywood: [222, 184, 135],
      cadetblue: [95, 158, 160],
      chartreuse: [127, 255, 0],
      chocolate: [210, 105, 30],
      coral: [255, 127, 80],
      cornflowerblue: [100, 149, 237],
      cornsilk: [255, 248, 220],
      crimson: [220, 20, 60],
      cyan: [0, 255, 255],
      darkblue: [0, 0, 139],
      darkcyan: [0, 139, 139],
      darkgoldenrod: [184, 134, 11],
      darkgray: [169, 169, 169],
      darkgreen: [0, 100, 0],
      darkgrey: [169, 169, 169],
      darkkhaki: [189, 183, 107],
      darkmagenta: [139, 0, 139],
      darkolivegreen: [85, 107, 47],
      darkorange: [255, 140, 0],
      darkorchid: [153, 50, 204],
      darkred: [139, 0, 0],
      darksalmon: [233, 150, 122],
      darkseagreen: [143, 188, 143],
      darkslateblue: [72, 61, 139],
      darkslategray: [47, 79, 79],
      darkslategrey: [47, 79, 79],
      darkturquoise: [0, 206, 209],
      darkviolet: [148, 0, 211],
      deeppink: [255, 20, 147],
      deepskyblue: [0, 191, 255],
      dimgray: [105, 105, 105],
      dimgrey: [105, 105, 105],
      dodgerblue: [30, 144, 255],
      firebrick: [178, 34, 34],
      floralwhite: [255, 250, 240],
      forestgreen: [34, 139, 34],
      fuchsia: [255, 0, 255],
      gainsboro: [220, 220, 220],
      ghostwhite: [248, 248, 255],
      gold: [255, 215, 0],
      goldenrod: [218, 165, 32],
      gray: [128, 128, 128],
      green: [0, 128, 0],
      greenyellow: [173, 255, 47],
      grey: [128, 128, 128],
      honeydew: [240, 255, 240],
      hotpink: [255, 105, 180],
      indianred: [205, 92, 92],
      indigo: [75, 0, 130],
      ivory: [255, 255, 240],
      khaki: [240, 230, 140],
      lavender: [230, 230, 250],
      lavenderblush: [255, 240, 245],
      lawngreen: [124, 252, 0],
      lemonchiffon: [255, 250, 205],
      lightblue: [173, 216, 230],
      lightcoral: [240, 128, 128],
      lightcyan: [224, 255, 255],
      lightgoldenrodyellow: [250, 250, 210],
      lightgray: [211, 211, 211],
      lightgreen: [144, 238, 144],
      lightgrey: [211, 211, 211],
      lightpink: [255, 182, 193],
      lightsalmon: [255, 160, 122],
      lightseagreen: [32, 178, 170],
      lightskyblue: [135, 206, 250],
      lightslategray: [119, 136, 153],
      lightslategrey: [119, 136, 153],
      lightsteelblue: [176, 196, 222],
      lightyellow: [255, 255, 224],
      lime: [0, 255, 0],
      limegreen: [50, 205, 50],
      linen: [250, 240, 230],
      magenta: [255, 0, 255],
      maroon: [128, 0, 0],
      mediumaquamarine: [102, 205, 170],
      mediumblue: [0, 0, 205],
      mediumorchid: [186, 85, 211],
      mediumpurple: [147, 112, 219],
      mediumseagreen: [60, 179, 113],
      mediumslateblue: [123, 104, 238],
      mediumspringgreen: [0, 250, 154],
      mediumturquoise: [72, 209, 204],
      mediumvioletred: [199, 21, 133],
      midnightblue: [25, 25, 112],
      mintcream: [245, 255, 250],
      mistyrose: [255, 228, 225],
      moccasin: [255, 228, 181],
      navajowhite: [255, 222, 173],
      navy: [0, 0, 128],
      oldlace: [253, 245, 230],
      olive: [128, 128, 0],
      olivedrab: [107, 142, 35],
      orange: [255, 165, 0],
      orangered: [255, 69, 0],
      orchid: [218, 112, 214],
      palegoldenrod: [238, 232, 170],
      palegreen: [152, 251, 152],
      paleturquoise: [175, 238, 238],
      palevioletred: [219, 112, 147],
      papayawhip: [255, 239, 213],
      peachpuff: [255, 218, 185],
      peru: [205, 133, 63],
      pink: [255, 192, 203],
      plum: [221, 160, 221],
      powderblue: [176, 224, 230],
      purple: [128, 0, 128],
      rebeccapurple: [102, 51, 153],
      red: [255, 0, 0],
      rosybrown: [188, 143, 143],
      royalblue: [65, 105, 225],
      saddlebrown: [139, 69, 19],
      salmon: [250, 128, 114],
      sandybrown: [244, 164, 96],
      seagreen: [46, 139, 87],
      seashell: [255, 245, 238],
      sienna: [160, 82, 45],
      silver: [192, 192, 192],
      skyblue: [135, 206, 235],
      slateblue: [106, 90, 205],
      slategray: [112, 128, 144],
      slategrey: [112, 128, 144],
      snow: [255, 250, 250],
      springgreen: [0, 255, 127],
      steelblue: [70, 130, 180],
      tan: [210, 180, 140],
      teal: [0, 128, 128],
      thistle: [216, 191, 216],
      tomato: [255, 99, 71],
      turquoise: [64, 224, 208],
      violet: [238, 130, 238],
      wheat: [245, 222, 179],
      white: [255, 255, 255],
      whitesmoke: [245, 245, 245],
      yellow: [255, 255, 0],
      yellowgreen: [154, 205, 50]
    }
  },
  35174: (OO, KO, pO) => {
    var XO = pO(35181),
      bK = pO(35186),
      eO = Object.hasOwnProperty,
      lO = Object.create(null);
    for (var vK in XO) eO.call(XO, vK) && (lO[XO[vK]] = vK);
    var CO = OO.exports = {
      to: {},
      get: {}
    };

    function hO(OO, KO, pO) {
      return Math.min(Math.max(KO, OO), pO)
    }

    function DO(OO) {
      var KO = Math.round(OO).toString(16).toUpperCase();
      return KO.length < 2 ? "0" + KO : KO
    }
    CO.get = function(OO) {
      var KO, pO;
      switch (OO.substring(0, 3).toLowerCase()) {
        case "hsl":
          KO = CO.get.hsl(OO), pO = "hsl";
          break;
        case "hwb":
          KO = CO.get.hwb(OO), pO = "hwb";
          break;
        default:
          KO = CO.get.rgb(OO), pO = "rgb"
      }
      return KO ? {
        model: pO,
        value: KO
      } : null
    }, CO.get.rgb = function(OO) {
      if (!OO) return null;
      var KO, pO, bK, lO = [0, 0, 0, 1];
      if (KO = OO.match(/^#([a-f0-9]{6})([a-f0-9]{2})?$/i)) {
        for (bK = KO[2], KO = KO[1], pO = 0; pO < 3; pO++) {
          var vK = 2 * pO;
          lO[pO] = parseInt(KO.slice(vK, vK + 2), 16)
        }
        bK && (lO[3] = parseInt(bK, 16) / 255)
      } else if (KO = OO.match(/^#([a-f0-9]{3,4})$/i)) {
        for (bK = (KO = KO[1])[3], pO = 0; pO < 3; pO++) lO[pO] = parseInt(KO[pO] + KO[pO], 16);
        bK && (lO[3] = parseInt(bK + bK, 16) / 255)
      } else if (KO = OO.match(/^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/)) {
        for (pO = 0; pO < 3; pO++) lO[pO] = parseInt(KO[pO + 1], 0);
        KO[4] && (KO[5] ? lO[3] = .01 * parseFloat(KO[4]) : lO[3] = parseFloat(KO[4]))
      } else {
        if (!(KO = OO.match(/^rgba?\(\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/))) return (KO = OO.match(/^(\w+)$/)) ? "transparent" === KO[1] ? [0, 0, 0, 0] : eO.call(XO, KO[1]) ? ((lO = XO[KO[1]])[3] = 1, lO) : null : null;
        for (pO = 0; pO < 3; pO++) lO[pO] = Math.round(2.55 * parseFloat(KO[pO + 1]));
        KO[4] && (KO[5] ? lO[3] = .01 * parseFloat(KO[4]) : lO[3] = parseFloat(KO[4]))
      }
      for (pO = 0; pO < 3; pO++) lO[pO] = hO(lO[pO], 0, 255);
      return lO[3] = hO(lO[3], 0, 1), lO
    }, CO.get.hsl = function(OO) {
      if (!OO) return null;
      var KO = OO.match(/^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d\.]+)%\s*,?\s*([+-]?[\d\.]+)%\s*(?:[,|\/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/);
      if (KO) {
        var pO = parseFloat(KO[4]);
        return [(parseFloat(KO[1]) % 360 + 360) % 360, hO(parseFloat(KO[2]), 0, 100), hO(parseFloat(KO[3]), 0, 100), hO(isNaN(pO) ? 1 : pO, 0, 1)]
      }
      return null
    }, CO.get.hwb = function(OO) {
      if (!OO) return null;
      var KO = OO.match(/^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/);
      if (KO) {
        var pO = parseFloat(KO[4]);
        return [(parseFloat(KO[1]) % 360 + 360) % 360, hO(parseFloat(KO[2]), 0, 100), hO(parseFloat(KO[3]), 0, 100), hO(isNaN(pO) ? 1 : pO, 0, 1)]
      }
      return null
    }, CO.to.hex = function() {
      var OO = bK(arguments);
      return "#" + DO(OO[0]) + DO(OO[1]) + DO(OO[2]) + (OO[3] < 1 ? DO(Math.round(255 * OO[3])) : "")
    }, CO.to.rgb = function() {
      var OO = bK(arguments);
      return OO.length < 4 || 1 === OO[3] ? "rgb(" + Math.round(OO[0]) + ", " + Math.round(OO[1]) + ", " + Math.round(OO[2]) + ")" : "rgba(" + Math.round(OO[0]) + ", " + Math.round(OO[1]) + ", " + Math.round(OO[2]) + ", " + OO[3] + ")"
    }, CO.to.rgb.percent = function() {
      var OO = bK(arguments),
        KO = Math.round(OO[0] / 255 * 100),
        pO = Math.round(OO[1] / 255 * 100),
        XO = Math.round(OO[2] / 255 * 100);
      return OO.length < 4 || 1 === OO[3] ? "rgb(" + KO + "%, " + pO + "%, " + XO + "%)" : "rgba(" + KO + "%, " + pO + "%, " + XO + "%, " + OO[3] + ")"
    }, CO.to.hsl = function() {
      var OO = bK(arguments);
      return OO.length < 4 || 1 === OO[3] ? "hsl(" + OO[0] + ", " + OO[1] + "%, " + OO[2] + "%)" : "hsla(" + OO[0] + ", " + OO[1] + "%, " + OO[2] + "%, " + OO[3] + ")"
    }, CO.to.hwb = function() {
      var OO = bK(arguments),
        KO = "";
      return OO.length >= 4 && 1 !== OO[3] && (KO = ", " + OO[3]), "hwb(" + OO[0] + ", " + OO[1] + "%, " + OO[2] + "%" + KO + ")"
    }, CO.to.keyword = function(OO) {
      return lO[OO.slice(0, 3)]
    }
  },
  35167: (OO, KO, pO) => {
    const XO = pO(35174),
      bK = pO(35197),
      eO = ["keyword", "gray", "hex"],
      lO = {};
    for (const oO of Object.keys(bK)) lO[[...bK[oO].labels].sort().join("")] = oO;
    const vK = {};

    function CO(OO, KO) {
      if (!(this instanceof CO)) return new CO(OO, KO);
      if (KO && KO in eO && (KO = null), KO && !(KO in bK)) throw new Error("Unknown model: " + KO);
      let pO, hO;
      if (null == OO) this.model = "rgb", this.color = [0, 0, 0], this.valpha = 1;
      else if (OO instanceof CO) this.model = OO.model, this.color = [...OO.color], this.valpha = OO.valpha;
      else if ("string" === typeof OO) {
        const KO = XO.get(OO);
        if (null === KO) throw new Error("Unable to parse color from string: " + OO);
        this.model = KO.model, hO = bK[this.model].channels, this.color = KO.value.slice(0, hO), this.valpha = "number" === typeof KO.value[hO] ? KO.value[hO] : 1
      } else if (OO.length > 0) {
        this.model = KO || "rgb", hO = bK[this.model].channels;
        const pO = Array.prototype.slice.call(OO, 0, hO);
        this.color = aK(pO, hO), this.valpha = "number" === typeof OO[hO] ? OO[hO] : 1
      } else if ("number" === typeof OO) this.model = "rgb", this.color = [OO >> 16 & 255, OO >> 8 & 255, 255 & OO], this.valpha = 1;
      else {
        this.valpha = 1;
        const KO = Object.keys(OO);
        "alpha" in OO && (KO.splice(KO.indexOf("alpha"), 1), this.valpha = "number" === typeof OO.alpha ? OO.alpha : 0);
        const XO = KO.sort().join("");
        if (!(XO in lO)) throw new Error("Unable to parse color from object: " + JSON.stringify(OO));
        this.model = lO[XO];
        const {
          labels: eO
        } = bK[this.model], vK = [];
        for (pO = 0; pO < eO.length; pO++) vK.push(OO[eO[pO]]);
        this.color = aK(vK)
      }
      if (vK[this.model])
        for (hO = bK[this.model].channels, pO = 0; pO < hO; pO++) {
          const OO = vK[this.model][pO];
          OO && (this.color[pO] = OO(this.color[pO]))
        }
      this.valpha = Math.max(0, Math.min(1, this.valpha)), Object.freeze && Object.freeze(this)
    }
    CO.prototype = {
      toString() {
        return this.string()
      },
      toJSON() {
        return this[this.model]()
      },
      string(OO) {
        let KO = this.model in XO.to ? this : this.rgb();
        KO = KO.round("number" === typeof OO ? OO : 1);
        const pO = 1 === KO.valpha ? KO.color : [...KO.color, this.valpha];
        return XO.to[KO.model](pO)
      },
      percentString(OO) {
        const KO = this.rgb().round("number" === typeof OO ? OO : 1),
          pO = 1 === KO.valpha ? KO.color : [...KO.color, this.valpha];
        return XO.to.rgb.percent(pO)
      },
      array() {
        return 1 === this.valpha ? [...this.color] : [...this.color, this.valpha]
      },
      object() {
        const OO = {},
          {
            channels: KO
          } = bK[this.model],
          {
            labels: pO
          } = bK[this.model];
        for (let XO = 0; XO < KO; XO++) OO[pO[XO]] = this.color[XO];
        return 1 !== this.valpha && (OO.alpha = this.valpha), OO
      },
      unitArray() {
        const OO = this.rgb().color;
        return OO[0] /= 255, OO[1] /= 255, OO[2] /= 255, 1 !== this.valpha && OO.push(this.valpha), OO
      },
      unitObject() {
        const OO = this.rgb().object();
        return OO.r /= 255, OO.g /= 255, OO.b /= 255, 1 !== this.valpha && (OO.alpha = this.valpha), OO
      },
      round(OO) {
        return OO = Math.max(OO || 0, 0), new CO([...this.color.map(hO(OO)), this.valpha], this.model)
      },
      alpha(OO) {
        return void 0 !== OO ? new CO([...this.color, Math.max(0, Math.min(1, OO))], this.model) : this.valpha
      },
      red: DO("rgb", 0, MO(255)),
      green: DO("rgb", 1, MO(255)),
      blue: DO("rgb", 2, MO(255)),
      hue: DO(["hsl", "hsv", "hsl", "hwb", "hcg"], 0, (OO => (OO % 360 + 360) % 360)),
      saturationl: DO("hsl", 1, MO(100)),
      lightness: DO("hsl", 2, MO(100)),
      saturationv: DO("hsv", 1, MO(100)),
      value: DO("hsv", 2, MO(100)),
      chroma: DO("hcg", 1, MO(100)),
      gray: DO("hcg", 2, MO(100)),
      white: DO("hwb", 1, MO(100)),
      wblack: DO("hwb", 2, MO(100)),
      cyan: DO("cmyk", 0, MO(100)),
      magenta: DO("cmyk", 1, MO(100)),
      yellow: DO("cmyk", 2, MO(100)),
      black: DO("cmyk", 3, MO(100)),
      x: DO("xyz", 0, MO(95.047)),
      y: DO("xyz", 1, MO(100)),
      z: DO("xyz", 2, MO(108.833)),
      l: DO("lab", 0, MO(100)),
      a: DO("lab", 1),
      b: DO("lab", 2),
      keyword(OO) {
        return void 0 !== OO ? new CO(OO) : bK[this.model].keyword(this.color)
      },
      hex(OO) {
        return void 0 !== OO ? new CO(OO) : XO.to.hex(this.rgb().round().color)
      },
      hexa(OO) {
        if (void 0 !== OO) return new CO(OO);
        const KO = this.rgb().round().color;
        let pO = Math.round(255 * this.valpha).toString(16).toUpperCase();
        return 1 === pO.length && (pO = "0" + pO), XO.to.hex(KO) + pO
      },
      rgbNumber() {
        const OO = this.rgb().color;
        return (255 & OO[0]) << 16 | (255 & OO[1]) << 8 | 255 & OO[2]
      },
      luminosity() {
        const OO = this.rgb().color,
          KO = [];
        for (const [pO, XO] of OO.entries()) {
          const OO = XO / 255;
          KO[pO] = OO <= .04045 ? OO / 12.92 : ((OO + .055) / 1.055) ** 2.4
        }
        return .2126 * KO[0] + .7152 * KO[1] + .0722 * KO[2]
      },
      contrast(OO) {
        const KO = this.luminosity(),
          pO = OO.luminosity();
        return KO > pO ? (KO + .05) / (pO + .05) : (pO + .05) / (KO + .05)
      },
      level(OO) {
        const KO = this.contrast(OO);
        return KO >= 7 ? "AAA" : KO >= 4.5 ? "AA" : ""
      },
      isDark() {
        const OO = this.rgb().color;
        return (2126 * OO[0] + 7152 * OO[1] + 722 * OO[2]) / 1e4 < 128
      },
      isLight() {
        return !this.isDark()
      },
      hl() {
        const OO = this.rgb();
        for (let KO = 0; KO < 3; KO++) OO.color[KO] = 255 - OO.color[KO];
        return OO
      },
      lighten(OO) {
        const KO = this.hsl();
        return KO.color[2] += KO.color[2] * OO, KO
      },
      darken(OO) {
        const KO = this.hsl();
        return KO.color[2] -= KO.color[2] * OO, KO
      },
      saturate(OO) {
        const KO = this.hsl();
        return KO.color[1] += KO.color[1] * OO, KO
      },
      desaturate(OO) {
        const KO = this.hsl();
        return KO.color[1] -= KO.color[1] * OO, KO
      },
      whiten(OO) {
        const KO = this.hwb();
        return KO.color[1] += KO.color[1] * OO, KO
      },
      blacken(OO) {
        const KO = this.hwb();
        return KO.color[2] += KO.color[2] * OO, KO
      },
      grayscale() {
        const OO = this.rgb().color,
          KO = .3 * OO[0] + .59 * OO[1] + .11 * OO[2];
        return CO.rgb(KO, KO, KO)
      },
      fade(OO) {
        return this.alpha(this.valpha - this.valpha * OO)
      },
      opaquer(OO) {
        return this.alpha(this.valpha + this.valpha * OO)
      },
      rotate(OO) {
        const KO = this.hsl();
        let pO = KO.color[0];
        return pO = (pO + OO) % 360, pO = pO < 0 ? 360 + pO : pO, KO.color[0] = pO, KO
      },
      mix(OO, KO) {
        if (!OO || !OO.rgb) throw new Error('Argument to "mix" was not a Color instance, but rather an instance of ' + typeof OO);
        const pO = OO.rgb(),
          XO = this.rgb(),
          bK = void 0 === KO ? .5 : KO,
          eO = 2 * bK - 1,
          lO = pO.alpha() - XO.alpha(),
          vK = ((eO * lO === -1 ? eO : (eO + lO) / (1 + eO * lO)) + 1) / 2,
          hO = 1 - vK;
        return CO.rgb(vK * pO.red() + hO * XO.red(), vK * pO.green() + hO * XO.green(), vK * pO.blue() + hO * XO.blue(), pO.alpha() * bK + XO.alpha() * (1 - bK))
      }
    };
    for (const oO of Object.keys(bK)) {
      if (eO.includes(oO)) continue;
      const {
        channels: OO
      } = bK[oO];
      CO.prototype[oO] = function() {
        if (this.model === oO) return new CO(this);
        for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
        return KO.length > 0 ? new CO(KO, oO) : new CO([...(XO = bK[this.model][oO].raw(this.color), Array.isArray(XO) ? XO : [XO]), this.valpha], oO);
        var XO
      }, CO[oO] = function() {
        for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
        let bK = pO[0];
        return "number" === typeof bK && (bK = aK(pO, OO)), new CO(bK, oO)
      }
    }

    function hO(OO) {
      return function(KO) {
        return function(OO, KO) {
          return Number(OO.toFixed(KO))
        }(KO, OO)
      }
    }

    function DO(OO, KO, pO) {
      OO = Array.isArray(OO) ? OO : [OO];
      for (const XO of OO)(vK[XO] || (vK[XO] = []))[KO] = pO;
      return OO = OO[0],
        function(XO) {
          let bK;
          return void 0 !== XO ? (pO && (XO = pO(XO)), bK = this[OO](), bK.color[KO] = XO, bK) : (bK = this[OO]().color[KO], pO && (bK = pO(bK)), bK)
        }
    }

    function MO(OO) {
      return function(KO) {
        return Math.max(0, Math.min(OO, KO))
      }
    }

    function aK(OO, KO) {
      for (let pO = 0; pO < KO; pO++) "number" !== typeof OO[pO] && (OO[pO] = 0);
      return OO
    }
    OO.exports = CO
  },
  35203: (OO, KO, pO) => {
    const XO = pO(35206),
      bK = {};
    for (const lO of Object.keys(XO)) bK[XO[lO]] = lO;
    const eO = {
      rgb: {
        channels: 3,
        labels: "rgb"
      },
      hsl: {
        channels: 3,
        labels: "hsl"
      },
      hsv: {
        channels: 3,
        labels: "hsv"
      },
      hwb: {
        channels: 3,
        labels: "hwb"
      },
      cmyk: {
        channels: 4,
        labels: "cmyk"
      },
      xyz: {
        channels: 3,
        labels: "xyz"
      },
      lab: {
        channels: 3,
        labels: "lab"
      },
      lch: {
        channels: 3,
        labels: "lch"
      },
      hex: {
        channels: 1,
        labels: ["hex"]
      },
      keyword: {
        channels: 1,
        labels: ["keyword"]
      },
      ansi16: {
        channels: 1,
        labels: ["ansi16"]
      },
      ansi256: {
        channels: 1,
        labels: ["ansi256"]
      },
      hcg: {
        channels: 3,
        labels: ["h", "c", "g"]
      },
      apple: {
        channels: 3,
        labels: ["r16", "g16", "b16"]
      },
      gray: {
        channels: 1,
        labels: ["gray"]
      }
    };
    OO.exports = eO;
    for (const lO of Object.keys(eO)) {
      if (!("channels" in eO[lO])) throw new Error("missing channels property: " + lO);
      if (!("labels" in eO[lO])) throw new Error("missing channel labels property: " + lO);
      if (eO[lO].labels.length !== eO[lO].channels) throw new Error("channel and label counts mismatch: " + lO);
      const {
        channels: OO,
        labels: KO
      } = eO[lO];
      delete eO[lO].channels, delete eO[lO].labels, Object.defineProperty(eO[lO], "channels", {
        value: OO
      }), Object.defineProperty(eO[lO], "labels", {
        value: KO
      })
    }
    eO.rgb.hsl = function(OO) {
      const KO = OO[0] / 255,
        pO = OO[1] / 255,
        XO = OO[2] / 255,
        bK = Math.min(KO, pO, XO),
        eO = Math.max(KO, pO, XO),
        lO = eO - bK;
      let vK, CO;
      eO === bK ? vK = 0 : KO === eO ? vK = (pO - XO) / lO : pO === eO ? vK = 2 + (XO - KO) / lO : XO === eO && (vK = 4 + (KO - pO) / lO), vK = Math.min(60 * vK, 360), vK < 0 && (vK += 360);
      const hO = (bK + eO) / 2;
      return CO = eO === bK ? 0 : hO <= .5 ? lO / (eO + bK) : lO / (2 - eO - bK), [vK, 100 * CO, 100 * hO]
    }, eO.rgb.hsv = function(OO) {
      let KO, pO, XO, bK, eO;
      const lO = OO[0] / 255,
        vK = OO[1] / 255,
        CO = OO[2] / 255,
        hO = Math.max(lO, vK, CO),
        DO = hO - Math.min(lO, vK, CO),
        MO = function(OO) {
          return (hO - OO) / 6 / DO + .5
        };
      return 0 === DO ? (bK = 0, eO = 0) : (eO = DO / hO, KO = MO(lO), pO = MO(vK), XO = MO(CO), lO === hO ? bK = XO - pO : vK === hO ? bK = 1 / 3 + KO - XO : CO === hO && (bK = 2 / 3 + pO - KO), bK < 0 ? bK += 1 : bK > 1 && (bK -= 1)), [360 * bK, 100 * eO, 100 * hO]
    }, eO.rgb.hwb = function(OO) {
      const KO = OO[0],
        pO = OO[1];
      let XO = OO[2];
      const bK = eO.rgb.hsl(OO)[0],
        lO = 1 / 255 * Math.min(KO, Math.min(pO, XO));
      return XO = 1 - 1 / 255 * Math.max(KO, Math.max(pO, XO)), [bK, 100 * lO, 100 * XO]
    }, eO.rgb.cmyk = function(OO) {
      const KO = OO[0] / 255,
        pO = OO[1] / 255,
        XO = OO[2] / 255,
        bK = Math.min(1 - KO, 1 - pO, 1 - XO);
      return [100 * ((1 - KO - bK) / (1 - bK) || 0), 100 * ((1 - pO - bK) / (1 - bK) || 0), 100 * ((1 - XO - bK) / (1 - bK) || 0), 100 * bK]
    }, eO.rgb.keyword = function(OO) {
      const KO = bK[OO];
      if (KO) return KO;
      let pO, eO = 1 / 0;
      for (const bK of Object.keys(XO)) {
        const KO = XO[bK],
          CO = (vK = KO, ((lO = OO)[0] - vK[0]) ** 2 + (lO[1] - vK[1]) ** 2 + (lO[2] - vK[2]) ** 2);
        CO < eO && (eO = CO, pO = bK)
      }
      var lO, vK;
      return pO
    }, eO.keyword.rgb = function(OO) {
      return XO[OO]
    }, eO.rgb.xyz = function(OO) {
      let KO = OO[0] / 255,
        pO = OO[1] / 255,
        XO = OO[2] / 255;
      KO = KO > .04045 ? ((KO + .055) / 1.055) ** 2.4 : KO / 12.92, pO = pO > .04045 ? ((pO + .055) / 1.055) ** 2.4 : pO / 12.92, XO = XO > .04045 ? ((XO + .055) / 1.055) ** 2.4 : XO / 12.92;
      return [100 * (.4124 * KO + .3576 * pO + .1805 * XO), 100 * (.2126 * KO + .7152 * pO + .0722 * XO), 100 * (.0193 * KO + .1192 * pO + .9505 * XO)]
    }, eO.rgb.lab = function(OO) {
      const KO = eO.rgb.xyz(OO);
      let pO = KO[0],
        XO = KO[1],
        bK = KO[2];
      pO /= 95.047, XO /= 100, bK /= 108.883, pO = pO > .008856 ? pO ** (1 / 3) : 7.787 * pO + 16 / 116, XO = XO > .008856 ? XO ** (1 / 3) : 7.787 * XO + 16 / 116, bK = bK > .008856 ? bK ** (1 / 3) : 7.787 * bK + 16 / 116;
      return [116 * XO - 16, 500 * (pO - XO), 200 * (XO - bK)]
    }, eO.hsl.rgb = function(OO) {
      const KO = OO[0] / 360,
        pO = OO[1] / 100,
        XO = OO[2] / 100;
      let bK, eO, lO;
      if (0 === pO) return lO = 255 * XO, [lO, lO, lO];
      bK = XO < .5 ? XO * (1 + pO) : XO + pO - XO * pO;
      const vK = 2 * XO - bK,
        CO = [0, 0, 0];
      for (let hO = 0; hO < 3; hO++) eO = KO + 1 / 3 * -(hO - 1), eO < 0 && eO++, eO > 1 && eO--, lO = 6 * eO < 1 ? vK + 6 * (bK - vK) * eO : 2 * eO < 1 ? bK : 3 * eO < 2 ? vK + (bK - vK) * (2 / 3 - eO) * 6 : vK, CO[hO] = 255 * lO;
      return CO
    }, eO.hsl.hsv = function(OO) {
      const KO = OO[0];
      let pO = OO[1] / 100,
        XO = OO[2] / 100,
        bK = pO;
      const eO = Math.max(XO, .01);
      XO *= 2, pO *= XO <= 1 ? XO : 2 - XO, bK *= eO <= 1 ? eO : 2 - eO;
      return [KO, 100 * (0 === XO ? 2 * bK / (eO + bK) : 2 * pO / (XO + pO)), 100 * ((XO + pO) / 2)]
    }, eO.hsv.rgb = function(OO) {
      const KO = OO[0] / 60,
        pO = OO[1] / 100;
      let XO = OO[2] / 100;
      const bK = Math.floor(KO) % 6,
        eO = KO - Math.floor(KO),
        lO = 255 * XO * (1 - pO),
        vK = 255 * XO * (1 - pO * eO),
        CO = 255 * XO * (1 - pO * (1 - eO));
      switch (XO *= 255, bK) {
        case 0:
          return [XO, CO, lO];
        case 1:
          return [vK, XO, lO];
        case 2:
          return [lO, XO, CO];
        case 3:
          return [lO, vK, XO];
        case 4:
          return [CO, lO, XO];
        case 5:
          return [XO, lO, vK]
      }
    }, eO.hsv.hsl = function(OO) {
      const KO = OO[0],
        pO = OO[1] / 100,
        XO = OO[2] / 100,
        bK = Math.max(XO, .01);
      let eO, lO;
      lO = (2 - pO) * XO;
      const vK = (2 - pO) * bK;
      return eO = pO * bK, eO /= vK <= 1 ? vK : 2 - vK, eO = eO || 0, lO /= 2, [KO, 100 * eO, 100 * lO]
    }, eO.hwb.rgb = function(OO) {
      const KO = OO[0] / 360;
      let pO = OO[1] / 100,
        XO = OO[2] / 100;
      const bK = pO + XO;
      let eO;
      bK > 1 && (pO /= bK, XO /= bK);
      const lO = Math.floor(6 * KO),
        vK = 1 - XO;
      eO = 6 * KO - lO, 0 !== (1 & lO) && (eO = 1 - eO);
      const CO = pO + eO * (vK - pO);
      let hO, DO, MO;
      switch (lO) {
        default:
        case 6:
        case 0:
          hO = vK, DO = CO, MO = pO;
          break;
        case 1:
          hO = CO, DO = vK, MO = pO;
          break;
        case 2:
          hO = pO, DO = vK, MO = CO;
          break;
        case 3:
          hO = pO, DO = CO, MO = vK;
          break;
        case 4:
          hO = CO, DO = pO, MO = vK;
          break;
        case 5:
          hO = vK, DO = pO, MO = CO
      }
      return [255 * hO, 255 * DO, 255 * MO]
    }, eO.cmyk.rgb = function(OO) {
      const KO = OO[0] / 100,
        pO = OO[1] / 100,
        XO = OO[2] / 100,
        bK = OO[3] / 100;
      return [255 * (1 - Math.min(1, KO * (1 - bK) + bK)), 255 * (1 - Math.min(1, pO * (1 - bK) + bK)), 255 * (1 - Math.min(1, XO * (1 - bK) + bK))]
    }, eO.xyz.rgb = function(OO) {
      const KO = OO[0] / 100,
        pO = OO[1] / 100,
        XO = OO[2] / 100;
      let bK, eO, lO;
      return bK = 3.2406 * KO + -1.5372 * pO + -.4986 * XO, eO = -.9689 * KO + 1.8758 * pO + .0415 * XO, lO = .0557 * KO + -.204 * pO + 1.057 * XO, bK = bK > .0031308 ? 1.055 * bK ** (1 / 2.4) - .055 : 12.92 * bK, eO = eO > .0031308 ? 1.055 * eO ** (1 / 2.4) - .055 : 12.92 * eO, lO = lO > .0031308 ? 1.055 * lO ** (1 / 2.4) - .055 : 12.92 * lO, bK = Math.min(Math.max(0, bK), 1), eO = Math.min(Math.max(0, eO), 1), lO = Math.min(Math.max(0, lO), 1), [255 * bK, 255 * eO, 255 * lO]
    }, eO.xyz.lab = function(OO) {
      let KO = OO[0],
        pO = OO[1],
        XO = OO[2];
      KO /= 95.047, pO /= 100, XO /= 108.883, KO = KO > .008856 ? KO ** (1 / 3) : 7.787 * KO + 16 / 116, pO = pO > .008856 ? pO ** (1 / 3) : 7.787 * pO + 16 / 116, XO = XO > .008856 ? XO ** (1 / 3) : 7.787 * XO + 16 / 116;
      return [116 * pO - 16, 500 * (KO - pO), 200 * (pO - XO)]
    }, eO.lab.xyz = function(OO) {
      let KO, pO, XO;
      pO = (OO[0] + 16) / 116, KO = OO[1] / 500 + pO, XO = pO - OO[2] / 200;
      const bK = pO ** 3,
        eO = KO ** 3,
        lO = XO ** 3;
      return pO = bK > .008856 ? bK : (pO - 16 / 116) / 7.787, KO = eO > .008856 ? eO : (KO - 16 / 116) / 7.787, XO = lO > .008856 ? lO : (XO - 16 / 116) / 7.787, KO *= 95.047, pO *= 100, XO *= 108.883, [KO, pO, XO]
    }, eO.lab.lch = function(OO) {
      const KO = OO[0],
        pO = OO[1],
        XO = OO[2];
      let bK;
      bK = 360 * Math.atan2(XO, pO) / 2 / Math.PI, bK < 0 && (bK += 360);
      return [KO, Math.sqrt(pO * pO + XO * XO), bK]
    }, eO.lch.lab = function(OO) {
      const KO = OO[0],
        pO = OO[1],
        XO = OO[2] / 360 * 2 * Math.PI;
      return [KO, pO * Math.cos(XO), pO * Math.sin(XO)]
    }, eO.rgb.ansi16 = function(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      const [pO, XO, bK] = OO;
      let lO = null === KO ? eO.rgb.hsv(OO)[2] : KO;
      if (lO = Math.round(lO / 50), 0 === lO) return 30;
      let vK = 30 + (Math.round(bK / 255) << 2 | Math.round(XO / 255) << 1 | Math.round(pO / 255));
      return 2 === lO && (vK += 60), vK
    }, eO.hsv.ansi16 = function(OO) {
      return eO.rgb.ansi16(eO.hsv.rgb(OO), OO[2])
    }, eO.rgb.ansi256 = function(OO) {
      const KO = OO[0],
        pO = OO[1],
        XO = OO[2];
      if (KO === pO && pO === XO) return KO < 8 ? 16 : KO > 248 ? 231 : Math.round((KO - 8) / 247 * 24) + 232;
      return 16 + 36 * Math.round(KO / 255 * 5) + 6 * Math.round(pO / 255 * 5) + Math.round(XO / 255 * 5)
    }, eO.ansi16.rgb = function(OO) {
      let KO = OO % 10;
      if (0 === KO || 7 === KO) return OO > 50 && (KO += 3.5), KO = KO / 10.5 * 255, [KO, KO, KO];
      const pO = .5 * (1 + ~~(OO > 50));
      return [(1 & KO) * pO * 255, (KO >> 1 & 1) * pO * 255, (KO >> 2 & 1) * pO * 255]
    }, eO.ansi256.rgb = function(OO) {
      if (OO >= 232) {
        const KO = 10 * (OO - 232) + 8;
        return [KO, KO, KO]
      }
      let KO;
      OO -= 16;
      return [Math.floor(OO / 36) / 5 * 255, Math.floor((KO = OO % 36) / 6) / 5 * 255, KO % 6 / 5 * 255]
    }, eO.rgb.hex = function(OO) {
      const KO = (((255 & Math.round(OO[0])) << 16) + ((255 & Math.round(OO[1])) << 8) + (255 & Math.round(OO[2]))).toString(16).toUpperCase();
      return "000000".substring(KO.length) + KO
    }, eO.hex.rgb = function(OO) {
      const KO = OO.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
      if (!KO) return [0, 0, 0];
      let pO = KO[0];
      3 === KO[0].length && (pO = pO.split("").map((OO => OO + OO)).join(""));
      const XO = parseInt(pO, 16);
      return [XO >> 16 & 255, XO >> 8 & 255, 255 & XO]
    }, eO.rgb.hcg = function(OO) {
      const KO = OO[0] / 255,
        pO = OO[1] / 255,
        XO = OO[2] / 255,
        bK = Math.max(Math.max(KO, pO), XO),
        eO = Math.min(Math.min(KO, pO), XO),
        lO = bK - eO;
      let vK, CO;
      return vK = lO < 1 ? eO / (1 - lO) : 0, CO = lO <= 0 ? 0 : bK === KO ? (pO - XO) / lO % 6 : bK === pO ? 2 + (XO - KO) / lO : 4 + (KO - pO) / lO, CO /= 6, CO %= 1, [360 * CO, 100 * lO, 100 * vK]
    }, eO.hsl.hcg = function(OO) {
      const KO = OO[1] / 100,
        pO = OO[2] / 100,
        XO = pO < .5 ? 2 * KO * pO : 2 * KO * (1 - pO);
      let bK = 0;
      return XO < 1 && (bK = (pO - .5 * XO) / (1 - XO)), [OO[0], 100 * XO, 100 * bK]
    }, eO.hsv.hcg = function(OO) {
      const KO = OO[1] / 100,
        pO = OO[2] / 100,
        XO = KO * pO;
      let bK = 0;
      return XO < 1 && (bK = (pO - XO) / (1 - XO)), [OO[0], 100 * XO, 100 * bK]
    }, eO.hcg.rgb = function(OO) {
      const KO = OO[0] / 360,
        pO = OO[1] / 100,
        XO = OO[2] / 100;
      if (0 === pO) return [255 * XO, 255 * XO, 255 * XO];
      const bK = [0, 0, 0],
        eO = KO % 1 * 6,
        lO = eO % 1,
        vK = 1 - lO;
      let CO = 0;
      switch (Math.floor(eO)) {
        case 0:
          bK[0] = 1, bK[1] = lO, bK[2] = 0;
          break;
        case 1:
          bK[0] = vK, bK[1] = 1, bK[2] = 0;
          break;
        case 2:
          bK[0] = 0, bK[1] = 1, bK[2] = lO;
          break;
        case 3:
          bK[0] = 0, bK[1] = vK, bK[2] = 1;
          break;
        case 4:
          bK[0] = lO, bK[1] = 0, bK[2] = 1;
          break;
        default:
          bK[0] = 1, bK[1] = 0, bK[2] = vK
      }
      return CO = (1 - pO) * XO, [255 * (pO * bK[0] + CO), 255 * (pO * bK[1] + CO), 255 * (pO * bK[2] + CO)]
    }, eO.hcg.hsv = function(OO) {
      const KO = OO[1] / 100,
        pO = KO + OO[2] / 100 * (1 - KO);
      let XO = 0;
      return pO > 0 && (XO = KO / pO), [OO[0], 100 * XO, 100 * pO]
    }, eO.hcg.hsl = function(OO) {
      const KO = OO[1] / 100,
        pO = OO[2] / 100 * (1 - KO) + .5 * KO;
      let XO = 0;
      return pO > 0 && pO < .5 ? XO = KO / (2 * pO) : pO >= .5 && pO < 1 && (XO = KO / (2 * (1 - pO))), [OO[0], 100 * XO, 100 * pO]
    }, eO.hcg.hwb = function(OO) {
      const KO = OO[1] / 100,
        pO = KO + OO[2] / 100 * (1 - KO);
      return [OO[0], 100 * (pO - KO), 100 * (1 - pO)]
    }, eO.hwb.hcg = function(OO) {
      const KO = OO[1] / 100,
        pO = 1 - OO[2] / 100,
        XO = pO - KO;
      let bK = 0;
      return XO < 1 && (bK = (pO - XO) / (1 - XO)), [OO[0], 100 * XO, 100 * bK]
    }, eO.apple.rgb = function(OO) {
      return [OO[0] / 65535 * 255, OO[1] / 65535 * 255, OO[2] / 65535 * 255]
    }, eO.rgb.apple = function(OO) {
      return [OO[0] / 255 * 65535, OO[1] / 255 * 65535, OO[2] / 255 * 65535]
    }, eO.gray.rgb = function(OO) {
      return [OO[0] / 100 * 255, OO[0] / 100 * 255, OO[0] / 100 * 255]
    }, eO.gray.hsl = function(OO) {
      return [0, 0, OO[0]]
    }, eO.gray.hsv = eO.gray.hsl, eO.gray.hwb = function(OO) {
      return [0, 100, OO[0]]
    }, eO.gray.cmyk = function(OO) {
      return [0, 0, 0, OO[0]]
    }, eO.gray.lab = function(OO) {
      return [OO[0], 0, 0]
    }, eO.gray.hex = function(OO) {
      const KO = 255 & Math.round(OO[0] / 100 * 255),
        pO = ((KO << 16) + (KO << 8) + KO).toString(16).toUpperCase();
      return "000000".substring(pO.length) + pO
    }, eO.rgb.gray = function(OO) {
      return [(OO[0] + OO[1] + OO[2]) / 3 / 255 * 100]
    }
  },
  35197: (OO, KO, pO) => {
    const XO = pO(35203),
      bK = pO(35209),
      eO = {};
    Object.keys(XO).forEach((OO => {
      eO[OO] = {}, Object.defineProperty(eO[OO], "channels", {
        value: XO[OO].channels
      }), Object.defineProperty(eO[OO], "labels", {
        value: XO[OO].labels
      });
      const KO = bK(OO);
      Object.keys(KO).forEach((pO => {
        const XO = KO[pO];
        eO[OO][pO] = function(OO) {
          const KO = function() {
            for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
            const bK = pO[0];
            if (void 0 === bK || null === bK) return bK;
            bK.length > 1 && (pO = bK);
            const eO = OO(pO);
            if ("object" === typeof eO)
              for (let OO = eO.length, lO = 0; lO < OO; lO++) eO[lO] = Math.round(eO[lO]);
            return eO
          };
          return "conversion" in OO && (KO.conversion = OO.conversion), KO
        }(XO), eO[OO][pO].raw = function(OO) {
          const KO = function() {
            for (var KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
            const bK = pO[0];
            return void 0 === bK || null === bK ? bK : (bK.length > 1 && (pO = bK), OO(pO))
          };
          return "conversion" in OO && (KO.conversion = OO.conversion), KO
        }(XO)
      }))
    })), OO.exports = eO
  },
  35209: (OO, KO, pO) => {
    const XO = pO(35203);

    function bK(OO) {
      const KO = function() {
          const OO = {},
            KO = Object.keys(XO);
          for (let pO = KO.length, XO = 0; XO < pO; XO++) OO[KO[XO]] = {
            distance: -1,
            parent: null
          };
          return OO
        }(),
        pO = [OO];
      for (KO[OO].distance = 0; pO.length;) {
        const OO = pO.pop(),
          bK = Object.keys(XO[OO]);
        for (let XO = bK.length, eO = 0; eO < XO; eO++) {
          const XO = bK[eO],
            lO = KO[XO]; - 1 === lO.distance && (lO.distance = KO[OO].distance + 1, lO.parent = OO, pO.unshift(XO))
        }
      }
      return KO
    }

    function eO(OO, KO) {
      return function(pO) {
        return KO(OO(pO))
      }
    }

    function lO(OO, KO) {
      const pO = [KO[OO].parent, OO];
      let bK = XO[KO[OO].parent][OO],
        lO = KO[OO].parent;
      for (; KO[lO].parent;) pO.unshift(KO[lO].parent), bK = eO(XO[KO[lO].parent][lO], bK), lO = KO[lO].parent;
      return bK.conversion = pO, bK
    }
    OO.exports = function(OO) {
      const KO = bK(OO),
        pO = {},
        XO = Object.keys(KO);
      for (let bK = XO.length, eO = 0; eO < bK; eO++) {
        const OO = XO[eO];
        null !== KO[OO].parent && (pO[OO] = lO(OO, KO))
      }
      return pO
    }
  },
  35206: OO => {
    OO.exports = {
      aliceblue: [240, 248, 255],
      antiquewhite: [250, 235, 215],
      aqua: [0, 255, 255],
      aquamarine: [127, 255, 212],
      azure: [240, 255, 255],
      beige: [245, 245, 220],
      bisque: [255, 228, 196],
      black: [0, 0, 0],
      blanchedalmond: [255, 235, 205],
      blue: [0, 0, 255],
      blueviolet: [138, 43, 226],
      brown: [165, 42, 42],
      burlywood: [222, 184, 135],
      cadetblue: [95, 158, 160],
      chartreuse: [127, 255, 0],
      chocolate: [210, 105, 30],
      coral: [255, 127, 80],
      cornflowerblue: [100, 149, 237],
      cornsilk: [255, 248, 220],
      crimson: [220, 20, 60],
      cyan: [0, 255, 255],
      darkblue: [0, 0, 139],
      darkcyan: [0, 139, 139],
      darkgoldenrod: [184, 134, 11],
      darkgray: [169, 169, 169],
      darkgreen: [0, 100, 0],
      darkgrey: [169, 169, 169],
      darkkhaki: [189, 183, 107],
      darkmagenta: [139, 0, 139],
      darkolivegreen: [85, 107, 47],
      darkorange: [255, 140, 0],
      darkorchid: [153, 50, 204],
      darkred: [139, 0, 0],
      darksalmon: [233, 150, 122],
      darkseagreen: [143, 188, 143],
      darkslateblue: [72, 61, 139],
      darkslategray: [47, 79, 79],
      darkslategrey: [47, 79, 79],
      darkturquoise: [0, 206, 209],
      darkviolet: [148, 0, 211],
      deeppink: [255, 20, 147],
      deepskyblue: [0, 191, 255],
      dimgray: [105, 105, 105],
      dimgrey: [105, 105, 105],
      dodgerblue: [30, 144, 255],
      firebrick: [178, 34, 34],
      floralwhite: [255, 250, 240],
      forestgreen: [34, 139, 34],
      fuchsia: [255, 0, 255],
      gainsboro: [220, 220, 220],
      ghostwhite: [248, 248, 255],
      gold: [255, 215, 0],
      goldenrod: [218, 165, 32],
      gray: [128, 128, 128],
      green: [0, 128, 0],
      greenyellow: [173, 255, 47],
      grey: [128, 128, 128],
      honeydew: [240, 255, 240],
      hotpink: [255, 105, 180],
      indianred: [205, 92, 92],
      indigo: [75, 0, 130],
      ivory: [255, 255, 240],
      khaki: [240, 230, 140],
      lavender: [230, 230, 250],
      lavenderblush: [255, 240, 245],
      lawngreen: [124, 252, 0],
      lemonchiffon: [255, 250, 205],
      lightblue: [173, 216, 230],
      lightcoral: [240, 128, 128],
      lightcyan: [224, 255, 255],
      lightgoldenrodyellow: [250, 250, 210],
      lightgray: [211, 211, 211],
      lightgreen: [144, 238, 144],
      lightgrey: [211, 211, 211],
      lightpink: [255, 182, 193],
      lightsalmon: [255, 160, 122],
      lightseagreen: [32, 178, 170],
      lightskyblue: [135, 206, 250],
      lightslategray: [119, 136, 153],
      lightslategrey: [119, 136, 153],
      lightsteelblue: [176, 196, 222],
      lightyellow: [255, 255, 224],
      lime: [0, 255, 0],
      limegreen: [50, 205, 50],
      linen: [250, 240, 230],
      magenta: [255, 0, 255],
      maroon: [128, 0, 0],
      mediumaquamarine: [102, 205, 170],
      mediumblue: [0, 0, 205],
      mediumorchid: [186, 85, 211],
      mediumpurple: [147, 112, 219],
      mediumseagreen: [60, 179, 113],
      mediumslateblue: [123, 104, 238],
      mediumspringgreen: [0, 250, 154],
      mediumturquoise: [72, 209, 204],
      mediumvioletred: [199, 21, 133],
      midnightblue: [25, 25, 112],
      mintcream: [245, 255, 250],
      mistyrose: [255, 228, 225],
      moccasin: [255, 228, 181],
      navajowhite: [255, 222, 173],
      navy: [0, 0, 128],
      oldlace: [253, 245, 230],
      olive: [128, 128, 0],
      olivedrab: [107, 142, 35],
      orange: [255, 165, 0],
      orangered: [255, 69, 0],
      orchid: [218, 112, 214],
      palegoldenrod: [238, 232, 170],
      palegreen: [152, 251, 152],
      paleturquoise: [175, 238, 238],
      palevioletred: [219, 112, 147],
      papayawhip: [255, 239, 213],
      peachpuff: [255, 218, 185],
      peru: [205, 133, 63],
      pink: [255, 192, 203],
      plum: [221, 160, 221],
      powderblue: [176, 224, 230],
      purple: [128, 0, 128],
      rebeccapurple: [102, 51, 153],
      red: [255, 0, 0],
      rosybrown: [188, 143, 143],
      royalblue: [65, 105, 225],
      saddlebrown: [139, 69, 19],
      salmon: [250, 128, 114],
      sandybrown: [244, 164, 96],
      seagreen: [46, 139, 87],
      seashell: [255, 245, 238],
      sienna: [160, 82, 45],
      silver: [192, 192, 192],
      skyblue: [135, 206, 235],
      slateblue: [106, 90, 205],
      slategray: [112, 128, 144],
      slategrey: [112, 128, 144],
      snow: [255, 250, 250],
      springgreen: [0, 255, 127],
      steelblue: [70, 130, 180],
      tan: [210, 180, 140],
      teal: [0, 128, 128],
      thistle: [216, 191, 216],
      tomato: [255, 99, 71],
      turquoise: [64, 224, 208],
      violet: [238, 130, 238],
      wheat: [245, 222, 179],
      white: [255, 255, 255],
      whitesmoke: [245, 245, 245],
      yellow: [255, 255, 0],
      yellowgreen: [154, 205, 50]
    }
  },
  35186: (OO, KO, pO) => {
    var XO = pO(35190),
      bK = Array.prototype.concat,
      eO = Array.prototype.slice,
      lO = OO.exports = function(OO) {
        for (var KO = [], pO = 0, lO = OO.length; pO < lO; pO++) {
          var vK = OO[pO];
          XO(vK) ? KO = bK.call(KO, eO.call(vK)) : KO.push(vK)
        }
        return KO
      };
    lO.wrap = function(OO) {
      return function() {
        return OO(lO(arguments))
      }
    }
  },
  35190: OO => {
    OO.exports = function(OO) {
      return !(!OO || "string" === typeof OO) && (OO instanceof Array || Array.isArray(OO) || OO.length >= 0 && (OO.splice instanceof Function || Object.getOwnPropertyDescriptor(OO, OO.length - 1) && "String" !== OO.constructor.name))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);