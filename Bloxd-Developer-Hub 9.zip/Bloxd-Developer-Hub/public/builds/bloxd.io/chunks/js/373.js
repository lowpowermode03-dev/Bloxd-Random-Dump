export const id = 373;
export const ids = [373];
export const modules = {
  59784: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      rebuildScenePbrPipelines: () => vK,
      rebuildSceneRenderables: () => CO
    });
    var XO = pO(39742),
      bK = (OO, KO) => OO.order - KO.order,
      eO = 8,
      lO = OO => CO(OO);
    async function vK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      await hO(OO, "pbr", KO)
    }
    async function CO(OO) {
      await hO(OO, void 0, !1)
    }
    async function hO(OO, KO, vK) {
      const CO = OO;
      if (!CO._built && !vK) return;
      const hO = CO._lightListVersion ?? 0,
        DO = CO.surface.engine,
        MO = OO => {
          CO._z ? OO.forEach((OO => OO())) : (0, XO.d)(DO, (() => OO.forEach((OO => OO()))))
        };
      let aK = !1,
        oO = !1,
        FO = !1,
        VO = !1;
      try {
        for (let OO = 1;; OO++) {
          if (void 0 !== KO) {
            await LO();
            break
          }
          if (zK(CO), await LO(), !QO(CO)) break;
          if (OO >= eO) {
            CO._rebuildHook = lO, VO = !0, oO = !0;
            break
          }
        }
        FO = !0
      } finally {
        if (aK && (CO._renderables.sort(bK), CO._renderableVersion++, CO._materialEpoch++, CO._built && CO._frameGraph.build()), void 0 === KO && FO && !oO && (CO._lightListVersion ?? 0) === hO) {
          const OO = CO._pendingTopologyRetirements?.splice(0);
          OO?.length && MO(OO), VO || (CO._rebuildHook = void 0)
        }
      }
      async function LO() {
        for (const [OO, XO] of CO._groups) {
          if (void 0 !== KO && OO._materialFamily !== KO) continue;
          if (0 === XO.length) {
            (XO.o || XO.r) && (AO(OO, XO), aK = !0);
            continue
          }
          const bK = CO._runtimeBuilds;
          await (bK?.wait(XO));
          let eO = !1;
          const vK = async () => {
            const KO = CO._runtimeBuilds,
              pO = [...XO].filter((KO => CO.meshes.includes(KO) && KO.material?._buildGroup === OO));
            if (0 === pO.length) return void AO(OO, XO);
            const lO = !!XO.r,
              vK = CO._disposables.length,
              hO = new Map,
              DO = new Map(pO.map((OO => [OO, OO.material])));
            for (const OO of pO) {
              const pO = CO._meshDisposables.get(OO);
              pO && (hO.set(OO, pO), CO._meshDisposables.delete(OO), KO?.holdPendingDisposers(OO, pO))
            }
            let aK, oO;
            CO._p = OO => (oO = OO, !0);
            try {
              aK = await OO(CO, pO)
            } catch (TO) {
              oO?.[1]();
              for (const bK of pO) {
                const pO = hO.get(bK),
                  eO = CO._meshDisposables.get(bK);
                if (eO && eO !== pO)
                  for (const OO of eO) OO();
                const lO = CO.meshes.includes(bK) && bK.material === DO.get(bK) && bK.material?._buildGroup === OO && XO.includes(bK);
                pO && lO ? CO._meshDisposables.set(bK, pO) : (CO._meshDisposables.delete(bK), pO && MO(pO)), pO && KO?.releasePendingDisposers(bK, pO)
              }
              throw TO
            } finally {
              delete CO._p
            }
            if (CO._z || bK?._d()) {
              oO?.[1]();
              for (const KO of pO) {
                const OO = CO._meshDisposables.get(KO),
                  pO = hO.get(KO);
                if (OO && OO !== pO)
                  for (const KO of OO) KO();
                CO._meshDisposables.delete(KO)
              }
              for (const KO of CO._disposables.splice(0)) KO();
              const OO = [...hO.values()].flat();
              MO(OO);
              for (const [pO, XO] of hO) KO?.releasePendingDisposers(pO, XO);
              return
            }
            oO?.[0](), OO._rebuildSingle = aK.rebuildSingle, XO.r = CO._runtimeBuilds?.base(OO, aK.rebuildSingle) ?? aK.rebuildSingle, "pbr" === OO._materialFamily && aK._G && (XO._w = null), lO && fO(CO, vK);
            const FO = new Set(pO.filter((KO => CO.meshes.includes(KO) && KO.material === DO.get(KO) && KO.material?._buildGroup === OO && XO.includes(KO))));
            if (FO.size !== pO.length && aK.renderables.some((OO => !OO.mesh))) {
              for (const OO of pO) {
                const pO = CO._meshDisposables.get(OO),
                  XO = hO.get(OO);
                if (pO && pO !== XO)
                  for (const OO of pO) OO();
                XO && CO.meshes.includes(OO) ? CO._meshDisposables.set(OO, XO) : (CO._meshDisposables.delete(OO), XO && MO(XO)), XO && KO?.releasePendingDisposers(OO, XO)
              }
              return void(eO = !0)
            }
            const VO = new Set;
            for (const OO of pO)
              if (FO.has(OO)) VO.add(OO.material), CO._runtimeBuilds?.reset(OO);
              else {
                const pO = hO.get(OO),
                  XO = CO._meshDisposables.get(OO);
                if (XO && XO !== pO)
                  for (const OO of XO) OO();
                pO && CO.meshes.includes(OO) ? (CO._meshDisposables.set(OO, pO), hO.delete(OO), KO?.releasePendingDisposers(OO, pO)) : CO._meshDisposables.delete(OO)
              } for (const OO of VO) OO._csmGen = (OO._csmGen ?? 0) + 1;
            const LO = XO.o,
              QO = LO?.length ? new Set(LO) : null;
            for (let OO = CO._renderables.length - 1; OO >= 0; OO--) {
              const KO = CO._renderables[OO];
              (FO.has(KO.mesh) || QO?.has(KO)) && CO._renderables.splice(OO, 1)
            }
            const zK = aK.renderables.filter((OO => !OO.mesh || FO.has(OO.mesh)));
            CO._renderables.push(...zK), XO.o = zK;
            const dO = [...hO.values()].flat();
            MO(dO);
            for (const [OO, XO] of hO) KO?.releasePendingDisposers(OO, XO)
          }, {
            X: hO
          } = await Promise.resolve().then((() => pO(59165))), DO = 3;
          for (let KO = 1;; KO++) {
            if (eO = !1, await hO(CO, OO, vK), CO._z || bK?._d()) return void(oO = !0);
            if (!eO) break;
            if (KO >= DO) {
              AO(OO, XO), CO._rebuildHook = lO, VO = !0, oO = !0;
              break
            }
          }
          eO ? aK = !0 : aK = !0
        }
      }

      function QO(OO) {
        for (const KO of OO.meshes) {
          const pO = KO.material?._buildGroup;
          if (pO && !OO._groups.get(pO)?.includes(KO)) return !0
        }
        return !1
      }

      function zK(OO) {
        const KO = new Map;
        for (const pO of OO.meshes) {
          const OO = pO.material?._buildGroup;
          if (!OO) continue;
          const XO = KO.get(OO);
          XO ? XO.push(pO) : KO.set(OO, [pO])
        }
        for (const [pO, XO] of OO._groups) {
          const OO = KO.get(pO) ?? [];
          (XO.length !== OO.length || OO.some(((OO, KO) => XO[KO] !== OO))) && (XO.length = 0, XO.push(...OO)), KO.delete(pO)
        }
        for (const [pO, XO] of KO) {
          const KO = XO;
          OO._groups.set(pO, KO)
        }
      }

      function AO(OO, KO) {
        const pO = KO.o;
        if (pO?.length) {
          const OO = new Set(pO);
          for (let KO = CO._renderables.length - 1; KO >= 0; KO--) OO.has(CO._renderables[KO]) && CO._renderables.splice(KO, 1)
        }
        KO.o = void 0, KO.r = void 0, CO._runtimeBuilds?.dropBase(OO), CO._rebuildHook = lO, VO = !0
      }

      function fO(OO, KO) {
        const pO = new Set(OO._disposables.slice(0, KO));
        for (let XO = OO._disposables.length - 1; XO >= KO; XO--) pO.has(OO._disposables[XO]) && OO._disposables.splice(XO, 1)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);