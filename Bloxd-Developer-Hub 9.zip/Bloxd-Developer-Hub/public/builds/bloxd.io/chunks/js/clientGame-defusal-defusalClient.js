export const id = 15;
export const ids = [15];
export const modules = {
  37647: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => XO
    });
    const XO = function(OO, KO, pO) {
      let XO;
      return {
        onCreate: OO => {
          XO = OO
        },
        onPlayerAltAction: (OO, KO, pO, bK, eO, lO) => {
          lO && "Mesh" === XO.getEntityType(lO) && XO.openShop(OO, !0)
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);