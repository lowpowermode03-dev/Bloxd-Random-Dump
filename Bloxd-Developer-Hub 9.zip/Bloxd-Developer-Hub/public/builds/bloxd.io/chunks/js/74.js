export const id = 74;
export const ids = [74];
export const modules = {
  35020: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    let XO = !1;

    function bK() {
      return XO
    }

    function eO(OO) {
      return XO !== OO && (XO = OO, !0)
    }
  },
  3916: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => fO,
      g: () => QO
    });
    var XO = pO(1148),
      bK = pO(26);
    var eO = pO(256);
    var lO = pO(533);
    var vK = pO(1964),
      CO = pO(3923),
      hO = pO(3952),
      DO = pO(3962);
    class MO {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.id = OO, this.type = KO, this.parameters = pO, this.tearDownNotification = XO, this.onDonePromise = bK, this.resolveRequest = eO
      }
    }
    const aK = new Set(["primary-fire", "alt-fire", "TouchDig", "TouchInteract", "TouchBoost"]);
    class oO {
      constructor(OO, KO, pO, XO, bK, eO) {
        this.id = OO, this.type = KO, this.parameters = pO, this.resolveRequest = XO, this.onDonePromise = bK, this.tearDownNotification = eO, this.mouseSub = null, this.stopInputActions = null, this.stopShellTicks = null, this.tickSub = null, this.implementation = void 0, this.isCompleted = !1;
        const lO = QO[KO];
        if (!lO) throw console.error(`No QTE implementation registered for type: ${KO}`), new Error(`No QTE implementation registered for type: ${KO}`);
        this.implementation = new lO(pO, (OO => {
          this.isCompleted = !0, this.resolveRequest(OO)
        }), this.tearDownNotification), this.setupInputHandlers()
      }
      setupInputHandlers() {
        this.mouseSub = bK.i.subscribe("QTEMouseState", (OO => {
          let {
            isDown: KO
          } = OO;
          this.isCompleted || this.implementation.handleMouseInput(KO)
        })), this.stopInputActions = (0, hO.h)((OO => {
          this.isCompleted || !aK.has(OO.action) && !(0, hO.f)(OO) || this.implementation.handleMouseInput(OO.down)
        })), this.tickSub = bK.i.subscribe("noaTick", (OO => {
          if (this.isCompleted) return;
          const KO = OO / 1e3;
          this.implementation.handleTick(KO)
        })), this.stopShellTicks = (0, CO.v)((() => {
          this.isCompleted || this.implementation.handleTick(vK.p / 1e3)
        }))
      }
      cleanup() {
        var OO, KO;
        this.mouseSub && (bK.i.unsubscribe(this.mouseSub), this.mouseSub = null), null === (OO = this.stopInputActions) || void 0 === OO || OO.call(this), this.stopInputActions = null, null === (KO = this.stopShellTicks) || void 0 === KO || KO.call(this), this.stopShellTicks = null, this.tickSub && (bK.i.unsubscribe(this.tickSub), this.tickSub = null)
      }
      async waitUntilDone() {
        await this.onDonePromise
      }
      getState() {
        return this.implementation.getState()
      }
      tearDown() {
        this.isCompleted = !0, this.cleanup(), this.implementation.tearDown()
      }
    }
    const FO = new XO.b,
      VO = new Map;
    let LO = null;
    const QO = {
      progressBar: class {
        constructor(OO, KO, pO) {
          var XO, bK, eO, lO;
          this.resolveRequest = KO, this.tearDownNotification = pO, this.progress = 0, this.k_ = void 0, this.p_ = void 0, this.qm = void 0, this.isCompleted = !1, this.clickCount = 0, this.parameters = void 0, this.type = "progressBar";
          const vK = OO;
          this.k_ = null !== (XO = vK.k_) && void 0 !== XO ? XO : .075, this.p_ = null !== (bK = vK.p_) && void 0 !== bK ? bK : 1, this.progress = null !== (eO = vK.RP) && void 0 !== eO ? eO : 30, this.qm = null !== (lO = vK.qm) && void 0 !== lO && lO, this.parameters = vK
        }
        handleMouseInput(OO) {
          OO && !this.isCompleted && (this.clickCount++, this.progress += this.p_, this.progress >= 100 && this.complete(!0))
        }
        handleTick() {
          if (!this.isCompleted)
            if (this.progress -= this.k_, this.qm && this.progress <= 0) this.complete(!1);
            else if (this.progress <= 0) this.progress = 0;
          else if (this.progress >= 100) return void this.complete(!0)
        }
        complete(OO) {
          this.isCompleted = !0, this.resolveRequest(OO)
        }
        getState() {
          return {
            type: this.type,
            parameters: this.parameters,
            state: {
              progress: this.progress,
              clickCount: this.clickCount
            },
            isActive: !0
          }
        }
        tearDown() {
          this.tearDownNotification()
        }
      },
      timedClick: class {
        constructor(OO, KO, pO) {
          var XO;
          this.resolveRequest = KO, this.tearDownNotification = pO, this.startTime = void 0, this.timeWindowMs = void 0, this.isCompleted = !1, this.parameters = void 0, this.type = "timedClick", this.parameters = OO, this.timeWindowMs = null !== (XO = this.parameters.h_) && void 0 !== XO ? XO : 3e3, this.startTime = Date.now()
        }
        handleMouseInput(OO) {
          if (!OO || this.isCompleted) return;
          Date.now() - this.startTime <= this.timeWindowMs && this.complete(!0)
        }
        handleTick() {
          if (this.isCompleted) return;
          Date.now() - this.startTime > this.timeWindowMs && this.complete(!1)
        }
        complete(OO) {
          this.isCompleted = !0, this.resolveRequest(OO)
        }
        getState() {
          const OO = Date.now() - this.startTime,
            KO = Math.max(0, this.timeWindowMs - OO);
          return {
            type: this.type,
            parameters: this.parameters,
            state: {
              timeRemaining: KO,
              h_: this.timeWindowMs
            },
            isActive: !0
          }
        }
        tearDown() {
          this.tearDownNotification()
        }
      },
      gravityBar: class {
        constructor(OO, KO, pO) {
          var XO;
          this.resolveRequest = KO, this.tearDownNotification = pO, this.parameters = void 0, this.type = "gravityBar", this.catchZonePosition = .5, this.catchZoneVelocity = 0, this.isMouseDown = !1, this.moverPosition = .5, this.moverTarget = Math.random(), this.ticksUntilDirectionChange = void 0, this.progress = void 0, this.isCompleted = !1;
          const bK = OO;
          this.parameters = {
            ...bK,
            L_: eO.e.clamp(bK.L_, .05, 1)
          }, this.progress = null !== (XO = bK.RP) && void 0 !== XO ? XO : 30, this.ticksUntilDirectionChange = this.randomNumTicksUntilDirectionChange()
        }
        handleMouseInput(OO) {
          this.isMouseDown = OO
        }
        handleTick(OO) {
          this.isCompleted || (this.updateMover(), this.updateCatchZone(), this.updateProgress(OO))
        }
        updateMover() {
          this.ticksUntilDirectionChange--, (this.ticksUntilDirectionChange <= 0 || Math.abs(this.moverPosition - this.moverTarget) < .02) && this.pickNewMoverTarget();
          const OO = Math.sign(this.moverTarget - this.moverPosition);
          this.moverPosition += OO * this.parameters.Q_ * .004, this.moverPosition = Math.max(0, Math.min(1, this.moverPosition))
        }
        pickNewMoverTarget() {
          this.moverTarget = Math.random(), this.ticksUntilDirectionChange = this.randomNumTicksUntilDirectionChange()
        }
        randomNumTicksUntilDirectionChange() {
          const OO = eO.e.clamp(1 - .7 * this.parameters.A_, 0, 1.4);
          return Math.floor(60 * OO + 40 * Math.random())
        }
        updateCatchZone() {
          this.isMouseDown ? this.catchZoneVelocity += .001 * this.parameters.f_ : this.catchZoneVelocity -= .001 * this.parameters.gravity, this.catchZoneVelocity *= .92, this.catchZoneVelocity = eO.e.clampAbs(this.catchZoneVelocity, .03), this.catchZonePosition += this.catchZoneVelocity;
          const OO = this.parameters.L_ / 2,
            KO = OO,
            pO = 1 - OO;
          this.catchZonePosition <= KO ? (this.catchZonePosition = KO, this.catchZoneVelocity = 0) : this.catchZonePosition >= pO && (this.catchZonePosition = pO, this.catchZoneVelocity = 0)
        }
        isMoverInCatchZone() {
          const OO = this.parameters.L_ / 2;
          return this.moverPosition >= this.catchZonePosition - OO && this.moverPosition <= this.catchZonePosition + OO
        }
        updateProgress(OO) {
          this.isMoverInCatchZone() ? this.progress += this.parameters.T_ * OO : this.progress -= this.parameters.N_ * OO, this.progress >= 100 ? (this.progress = 100, this.complete(!0)) : this.parameters.qm && this.progress <= 0 ? (this.progress = 0, this.complete(!1)) : this.progress < 0 && (this.progress = 0)
        }
        complete(OO) {
          this.isCompleted = !0, this.resolveRequest(OO)
        }
        getState() {
          return {
            type: this.type,
            parameters: this.parameters,
            state: {
              catchZonePosition: this.catchZonePosition,
              L_: this.parameters.L_,
              moverPosition: this.moverPosition,
              progress: this.progress,
              isCatching: this.isMoverInCatchZone()
            },
            isActive: !0
          }
        }
        tearDown() {
          this.tearDownNotification()
        }
      },
      precisionBar: class {
        constructor(OO, KO, pO) {
          var XO, bK, lO, vK, CO;
          this.resolveRequest = KO, this.tearDownNotification = pO, this.startTime = void 0, this.speed = void 0, this.Y_ = void 0, this.isCompleted = !1, this.markerPosition = 0, this.parameters = void 0, this.type = "precisionBar";
          const hO = OO;
          this.parameters = {
            ...hO,
            speed: null !== (XO = hO.speed) && void 0 !== XO ? XO : .5,
            Y_: eO.e.clamp(hO.Y_, .05, 1),
            label: null !== (bK = hO.label) && void 0 !== bK ? bK : [{
              str: "Click when the marker is within the green zone."
            }],
            icon: null !== (lO = hO.icon) && void 0 !== lO ? lO : null,
            scale: null !== (vK = hO.scale) && void 0 !== vK ? vK : 1,
            rotation: null !== (CO = hO.rotation) && void 0 !== CO ? CO : 0
          }, this.speed = this.parameters.speed, this.Y_ = this.parameters.Y_, this.startTime = Date.now()
        }
        handleMouseInput(OO) {
          if (OO) {
            this.updateMarkerPosition();
            const OO = Math.abs(this.markerPosition - .5) <= this.Y_ / 2;
            this.complete(OO)
          }
        }
        handleTick() {
          this.isCompleted || this.updateMarkerPosition()
        }
        updateMarkerPosition() {
          const OO = (Date.now() - this.startTime) / 1e3 * this.speed % 1;
          this.markerPosition = OO <= .5 ? 2 * OO : 2 - 2 * OO
        }
        complete(OO) {
          this.isCompleted = !0, this.resolveRequest(OO)
        }
        getState() {
          return this.updateMarkerPosition(), {
            type: this.type,
            parameters: this.parameters,
            state: {
              markerPosition: this.markerPosition
            },
            isActive: !0
          }
        }
        tearDown() {
          this.tearDownNotification()
        }
      },
      rhythmClick: class {
        constructor(OO, KO, pO) {
          this.resolveRequest = KO, this.tearDownNotification = pO, this.parameters = void 0, this.type = "rhythmClick", this.shrinkStartTime = void 0, this.isCompleted = !1, this.successes = 0, this.misses = 0, this.lastClickResult = null, this.parameters = OO, this.shrinkStartTime = Date.now()
        }
        handleMouseInput(OO) {
          if (!OO || this.isCompleted) return;
          const KO = this.getOuterCircleProgress();
          if (KO <= this.parameters.J_ && KO >= -this.parameters.J_) {
            if (this.successes++, this.lastClickResult = !0, this.successes >= this.parameters.R_) return void this.complete(!0)
          } else this.handleMiss();
          this.shrinkStartTime = Date.now()
        }
        handleMiss() {
          this.misses++, this.lastClickResult = !1, !(0, lO.I)(this.parameters.B_) && this.misses > this.parameters.B_ ? this.complete(!1) : this.shrinkStartTime = Date.now()
        }
        handleTick() {
          if (this.isCompleted) return;
          this.getOuterCircleProgress() < -this.parameters.J_ && this.handleMiss()
        }
        getOuterCircleProgress() {
          return 1 - (Date.now() - this.shrinkStartTime) / this.parameters.S_
        }
        complete(OO) {
          this.isCompleted = !0, this.resolveRequest(OO)
        }
        getState() {
          return {
            type: this.type,
            parameters: this.parameters,
            state: {
              outerCircleProgress: this.getOuterCircleProgress(),
              successes: this.successes,
              R_: this.parameters.R_,
              misses: this.misses,
              lastClickResult: this.lastClickResult
            },
            isActive: !0
          }
        }
        tearDown() {
          this.tearDownNotification()
        }
      }
    };

    function zK() {
      (0, DO.j)(vK.u.Qte, LO ? vK.u.Qte : 0), LO ? bK.i.pl("qteStateUpdated", LO.getState()) : bK.i.pl("qteStateUpdated", {
        type: null,
        typeSpecificParameters: null,
        isActive: !1
      })
    }
    class AO {
      constructor(OO, KO) {
        this.resultPromise = OO, this.tearDownQTE = KO
      }
      static create(OO, KO, pO) {
        const XO = Promise.race([OO, KO]);
        return new AO(XO, pO)
      }
      async getResult() {
        return await this.resultPromise
      }
    }
    class fO {
      static queueQTE(OO, KO, pO) {
        let XO, bK;
        const eO = new Promise((OO => {
            XO = OO
          })),
          lO = new Promise((OO => {
            bK = () => {
              OO("qteTornDown")
            }
          })),
          vK = Promise.race([eO, lO]).then((() => {})),
          CO = new MO(OO, KO, pO, bK, vK, XO);
        return VO.set(OO, CO), FO.enqueue(CO), LO || this.processNextQTE(), AO.create(eO, lO, bK)
      }
      static async processNextQTE() {
        if (LO || FO.fX()) return void(FO.fX() && LO && (LO = null, zK()));
        const OO = await FO.dequeue();
        if (!VO.has(OO.id)) return void await this.processNextQTE();
        VO.delete(OO.id);
        const KO = new oO(OO.id, OO.type, OO.parameters, OO.resolveRequest, OO.onDonePromise, OO.tearDownNotification);
        LO = KO, zK();
        try {
          await KO.waitUntilDone()
        } catch (pO) {
          console.error("Error while waiting for QTE to resolve:", pO.stack)
        }
        LO === KO && (LO.cleanup(), LO = null, zK()), await this.processNextQTE()
      }
      static cancelQTE(OO) {
        if (LO && LO.id === OO) return LO.tearDown(), LO = null, zK(), void this.processNextQTE();
        const KO = VO.get(OO);
        KO && (VO.delete(OO), KO.tearDownNotification())
      }
      static getCurrentState() {
        return LO ? LO.getState() : {
          type: null,
          parameters: null,
          state: null,
          isActive: !1
        }
      }
      static reset() {
        LO && (LO.tearDown(), LO = null), VO.forEach(((OO, KO) => {
          this.cancelQTE(KO)
        })), FO.emptyQueue(), VO.clear(), zK()
      }
    }
  },
  35015: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      i: () => DO,
      l: () => oO,
      p: () => MO
    });
    var XO = pO(256),
      bK = pO(570),
      eO = pO(967),
      lO = pO(36);
    const vK = {
        idStorageKey: "playSessionId",
        lastActivityStorageKey: "playSessionLastActivityMs",
        expiryMs: 3e5
      },
      CO = "playSessionGameNameWithVariation",
      hO = "wasMatchmakePlayer";

    function DO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h;
      (0, eO.h)(OO, vK)
    }

    function MO() {
      (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).setItem(hO, !0)
    }

    function aK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h;
      return (0, eO.c)(OO, vK)
    }

    function oO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : lO.h;
      const pO = (0, eO.c)(KO, vK),
        DO = function(OO) {
          const KO = OO.getItem(CO);
          return "string" !== typeof KO ? null : KO
        }(KO),
        MO = function() {
          return !0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).getItem(hO)
        }(KO);
      let aK;
      return aK = null !== pO && null !== DO && (0, eO.f)(KO, vK) && function(OO, KO, pO) {
          const bK = (0, XO.Qb)(OO),
            eO = (0, XO.Qb)(KO),
            lO = (0, XO.Lb)(OO),
            vK = (0, XO.Lb)(KO);
          return !(bK !== eO || !pO) || bK === eO && lO === vK
        }(DO, OO, MO) ? pO : (0, bK.c)(), (0, eO.i)(KO, vK, aK), KO.setItem(CO, OO),
        function() {
          (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).removeItem(hO)
        }(KO), aK
    }
  },
  3952: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      f: () => eO,
      h: () => vK
    });
    var XO = pO(1964),
      bK = pO(3955);

    function eO(OO) {
      let {
        action: KO,
        flags: pO
      } = OO;
      return "mid-fire" === KO && 0 !== (pO & XO.b.AltLeftClick)
    }
    const lO = new Set;

    function vK(OO) {
      return lO.add(OO), () => {
        lO.delete(OO)
      }
    }

    function CO(OO) {
      const KO = bK.e[255 & OO];
      if (void 0 === KO) return;
      const pO = OO >>> 8 & 255,
        eO = {
          action: KO,
          down: 0 !== (pO & XO.b.Down),
          flags: pO,
          press: OO >>> 16
        };
      for (const XO of lO) XO(eO)
    }
  },
  8461: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => eO
    });
    var XO = pO(8411);
    const bK = "Air",
      eO = Object.freeze(new XO.f(bK, 0, "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null))
  },
  35356: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => DO,
      C: () => lO,
      b: () => bK,
      e: () => eO,
      i: () => aK,
      m: () => vK,
      q: () => CO,
      u: () => hO,
      x: () => MO
    });
    var XO = pO(1098);
    let bK = function(OO) {
        return OO[OO.Join = 0] = "Join", OO[OO.Leave = 1] = "Leave", OO[OO.Push = 2] = "Push", OO[OO.Cursor = 3] = "Cursor", OO[OO.Submit = 4] = "Submit", OO[OO.ReloadAsVariation = 5] = "ReloadAsVariation", OO[OO.CreateFile = 6] = "CreateFile", OO[OO.RenameFile = 7] = "RenameFile", OO[OO.DeleteFile = 8] = "DeleteFile", OO[OO.SetEngine = 9] = "SetEngine", OO[OO.RenameFolder = 10] = "RenameFolder", OO
      }({}),
      eO = function(OO) {
        return OO[OO.Joined = 0] = "Joined", OO[OO.Updates = 1] = "Updates", OO[OO.Presence = 2] = "Presence", OO[OO.RemoteCursor = 3] = "RemoteCursor", OO[OO.ForceClose = 4] = "ForceClose", OO[OO.LobbyFilesChanged = 5] = "LobbyFilesChanged", OO[OO.EngineSettings = 6] = "EngineSettings", OO
      }({});

    function lO(OO) {
      return "lobby" === OO.kind ? `lobby:${OO.path}` : `codeBlock:${OO.pos[0]},${OO.pos[1]},${OO.pos[2]}`
    }

    function vK(OO) {
      if ("lobby" === OO) return {
        kind: "lobby",
        path: XO.f
      };
      if (OO.startsWith("lobby:")) {
        const KO = OO.slice(6);
        return MO(KO) ? {
          kind: "lobby",
          path: KO
        } : null
      }
      const KO = OO.match(/^codeBlock:(-?\d+),(-?\d+),(-?\d+)$/);
      return KO ? {
        kind: "codeBlock",
        pos: [parseInt(KO[1]), parseInt(KO[2]), parseInt(KO[3])]
      } : null
    }

    function CO(OO) {
      return OO.endsWith(".d.ts")
    }

    function hO(OO) {
      return OO.endsWith(".ts") && !CO(OO)
    }
    const DO = 64;

    function MO(OO) {
      if (!OO || OO !== OO.trim()) return !1;
      if (OO.length > DO) return !1;
      if (OO.startsWith("/") || OO.includes("\\") || OO.includes("\0")) return !1;
      if (!CO(OO) && !hO(OO) && ! function(OO) {
          return OO.endsWith(".js") && !OO.endsWith(".min.js") && !OO.endsWith(".bundle.js")
        }(OO)) return !1;
      const KO = OO.split("/");
      for (const pO of KO)
        if ("" === pO || "." === pO || ".." === pO) return !1;
      return !0
    }
    const aK = 14e3
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);