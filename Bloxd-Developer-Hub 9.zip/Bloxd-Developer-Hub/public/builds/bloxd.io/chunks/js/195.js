export const id = 195;
export const ids = [195];
export const modules = {
  34934: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => DO,
      d: () => aK
    });
    var XO = pO(63),
      bK = pO(1187),
      eO = pO(1051),
      lO = pO(1180),
      vK = pO(2730),
      CO = pO(4054),
      hO = pO(976);

    function DO(OO) {
      let {
        loading: KO,
        schematics: pO,
        onSchematicPicked: XO,
        selectedSchematicIdList: bK = [],
        disableAutoExport: CO
      } = OO;
      const {
        t: DO
      } = (0, eO.D)();
      return (0, hO.jsxs)("div", {
        className: "SchematicList",
        children: [KO && (0, hO.jsx)(lO.e, {}), !KO && 0 === pO.length && (0, hO.jsx)("div", {
          className: "NoSchematicsText",
          children: DO("worldBuilder:noSavedSchematic")
        }), !KO && pO.map((OO => (0, hO.jsx)(vK.f, {
          source: {
            type: "schematic",
            schematic: OO
          },
          gameWidth: "25%",
          useLongRatio: !0,
          onClick: () => {
            XO(OO)
          },
          isSelected: bK.includes(OO.schematicId),
          hideCcu: !0,
          hideFavourites: !0,
          showPublishedChip: !0,
          hideUnpublishedChip: !0,
          disabled: OO.isAutoExported && CO,
          disabledReason: "worldBuilder:autoExportDisabled"
        }, OO.schematicId)))]
      })
    }

    function MO(OO) {
      let {
        ownedSchematics: KO,
        currentWorldSchematicId: pO,
        onClose: bK
      } = OO;
      const {
        t: lO
      } = (0, eO.D)(), [vK, MO] = (0, XO.useState)(null);
      return (0, hO.jsxs)("div", {
        className: "SchematicListWindow",
        children: [null === vK && (0, hO.jsxs)(hO.Fragment, {
          children: [(0, hO.jsx)("h1", {
            className: "SchematicPopupTitle",
            children: lO("worldBuilder:schematicList")
          }), (0, hO.jsx)("h2", {
            className: "SchematicPopupSubtitle",
            children: lO("worldBuilder:clickSchematicForOptions")
          }), (0, hO.jsx)("div", {
            className: "SchematicPopupSchematicListContainer",
            children: (0, hO.jsx)(DO, {
              loading: !1,
              schematics: KO,
              onSchematicPicked: OO => {
                MO(OO)
              },
              disableAutoExport: !1
            })
          })]
        }), null !== vK && (0, hO.jsx)(CO.f, {
          schematic: vK,
          inSourceWorld: vK.schematicId === pO,
          onSchematicUpdate: OO => {
            MO(OO)
          },
          onClose: () => {
            MO(null), bK()
          }
        })]
      })
    }

    function aK(OO) {
      let {
        ownedSchematics: KO,
        currentWorldSchematicId: pO,
        onClose: XO
      } = OO;
      bK.NotificationProvider.showCustomPopup({
        body: OO => (0, hO.jsx)(MO, {
          ownedSchematics: KO,
          currentWorldSchematicId: pO,
          onClose: OO
        }),
        middleScreenPopupClassName: "SchematicPopup",
        onClose: XO,
        unlockPointerKey: "schematicListPopup"
      })
    }
  },
  39755: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      runClientGameMessage: () => EO
    });
    var XO = pO(2988),
      bK = pO(3006),
      eO = pO(1163),
      lO = pO(34934),
      vK = pO(4080),
      CO = pO(918),
      hO = pO.n(CO),
      DO = pO(63),
      MO = pO(1187),
      aK = pO(1271),
      oO = pO(256),
      FO = pO(1051),
      VO = pO(933),
      LO = pO(976);

    function QO(OO) {
      let {
        onFilePicked: KO
      } = OO;
      const {
        t: pO
      } = (0, FO.D)(), [XO, bK] = (0, DO.useState)(null), {
        getRootProps: eO,
        getInputProps: lO,
        isDragActive: CO
      } = (0, vK.d)({
        onDrop: OO => {
          OO.length > 0 && bK(OO[0])
        },
        useFsAccessApi: !1
      }), MO = XO && XO.size > 1024 * oO.Sc;
      return (0, LO.jsxs)("div", {
        className: "SchematicUploadContainer",
        children: [(0, LO.jsxs)("div", {
          ...eO({
            className: hO()("SchematicUpload", {
              ActiveDrag: CO
            })
          }),
          children: [(0, LO.jsx)("input", {
            ...lO({
              accept: ".bloxdschem"
            })
          }), !CO && XO ? (0, LO.jsxs)(LO.Fragment, {
            children: [(0, LO.jsx)("div", {
              className: hO()("SchematicUploadIcon", "Active", {
                TooBig: MO
              }),
              children: (0, LO.jsx)(VO.d, {
                name: "file-lines"
              })
            }), (0, LO.jsx)("div", {
              className: "SchematicUploadInstructions Active",
              children: XO.name
            })]
          }) : (0, LO.jsxs)(LO.Fragment, {
            children: [(0, LO.jsx)("div", {
              className: "SchematicUploadIcon",
              children: (0, LO.jsx)(VO.d, {
                name: "up-from-bracket"
              })
            }), (0, LO.jsx)("div", {
              className: "SchematicUploadInstructions",
              children: pO("worldBuilder:dragAFileHere")
            })]
          })]
        }), (0, LO.jsx)(aK.m, {
          disabled: MO || !XO,
          className: "SchematicUploadButton",
          onClick: () => {
            !MO && XO && KO(XO)
          },
          children: MO ? pO("worldBuilder:fileTooBig", {
            maxSizeKb: oO.Sc
          }) : pO("worldBuilder:upload")
        })]
      })
    }

    function zK(OO) {
      let {
        ownedSchematics: KO,
        onClose: pO,
        onChosenPreset: XO,
        onChosenFile: bK
      } = OO;
      const {
        t: eO
      } = (0, FO.D)();
      return (0, LO.jsxs)(LO.Fragment, {
        children: [(0, LO.jsx)("h1", {
          className: "SchematicPopupTitle",
          children: eO("worldBuilder:loadSchematic")
        }), (0, LO.jsx)("h2", {
          className: "SchematicPopupSubtitle",
          children: eO("worldBuilder:chooseOneOfYourSchematics")
        }), (0, LO.jsx)("div", {
          className: "SchematicPopupSchematicListContainer",
          children: (0, LO.jsx)(lO.c, {
            schematics: KO,
            onSchematicPicked: OO => {
              XO(OO.schematicId), pO()
            },
            loading: !1,
            disableAutoExport: !0
          })
        }), (0, LO.jsx)("h2", {
          className: "SchematicPopupSubtitle",
          children: eO("worldBuilder:uploadNewSchematic")
        }), (0, LO.jsx)(QO, {
          onFilePicked: async OO => {
            try {
              await bK(OO)
            } catch (KO) {
              console.warn("Schematic upload failed", KO)
            } finally {
              pO()
            }
          }
        })]
      })
    }
    var AO = pO(4054),
      fO = pO(1475),
      dO = pO(3618),
      TO = pO(1077);

    function NO(OO) {
      var KO;
      let {
        ownedSchematics: pO,
        onClose: XO,
        onChosenEdit: bK,
        onChosenNew: eO,
        onChosenDownload: vK
      } = OO;
      const {
        t: CO
      } = (0, FO.D)(), [hO, MO] = (0, DO.useState)("choose"), [oO, VO] = (0, DO.useState)(null), [QO, zK] = (0, DO.useState)(null);
      return (0, LO.jsxs)(LO.Fragment, {
        children: [(0, LO.jsx)("h1", {
          className: "SchematicPopupTitle",
          children: CO("worldBuilder:saveSchematic")
        }), "choose" === hO && (0, LO.jsxs)(LO.Fragment, {
          children: [(0, LO.jsx)("h2", {
            className: "SchematicPopupSubtitle",
            children: CO("worldBuilder:overwriteOneOfYourSchematics")
          }), (0, LO.jsx)("div", {
            className: "SchematicPopupSchematicListContainer",
            children: (0, LO.jsx)(lO.c, {
              schematics: pO,
              onSchematicPicked: OO => {
                VO(OO.schematicId), zK("existing"), MO("save")
              },
              loading: !1,
              disableAutoExport: !1
            })
          }), (0, LO.jsx)("h2", {
            className: "SchematicPopupSubtitle",
            children: CO("general:otherOptions")
          }), (0, LO.jsxs)("div", {
            className: "OtherOptions",
            children: [(0, LO.jsx)(aK.m, {
              className: "ChooseUploadSchematicButton",
              onClick: () => {
                zK("new"), MO("save")
              },
              children: CO("worldBuilder:saveAsNewSchematic")
            }), (0, LO.jsx)(aK.d, {
              className: "ChooseUploadSchematicButton",
              onClick: () => {
                zK("file"), MO("save")
              },
              children: CO("worldBuilder:downloadSchematic")
            })]
          })]
        }), "choose" !== hO && (0, LO.jsx)(IO, {
          type: QO,
          ownedSchematics: pO,
          onSubmit: (OO, KO, pO) => {
            "file" === QO ? vK(KO, OO) : "new" === QO ? eO(KO, pO, OO) : bK(oO, KO, pO, OO), XO()
          },
          onBack: () => {
            MO("choose")
          },
          prepopName: "existing" === QO ? null === (KO = pO.find((OO => OO.schematicId === oO))) || void 0 === KO ? void 0 : KO.name : null
        })]
      })
    }

    function IO(OO) {
      let {
        type: KO,
        prepopName: pO,
        ownedSchematics: XO,
        onSubmit: bK,
        onBack: eO
      } = OO;
      const {
        t: lO
      } = (0, FO.D)(), [vK, CO] = (0, DO.useState)(""), [MO, oO] = (0, DO.useState)(""), [VO, QO] = (0, DO.useState)(null), [zK, AO] = (0, DO.useState)(!0), NO = OO => {
        var pO;
        OO = null !== (pO = OO) && void 0 !== pO ? pO : vK;
        const bK = "new" === KO ? (0, TO.w)(OO) : null,
          eO = [...(0, TO.qb)(OO), ...bK ? [bK] : []];
        return eO.length > 0 ? (QO(eO.join(", ")), !1) : "new" === KO && XO.find((KO => KO.name === OO)) ? (QO(lO("worldBuilder:schematicAlreadyExists")), !1) : (QO(null), !0)
      };
      return (0, LO.jsxs)("div", {
        className: "SaveSchematicWindow",
        children: [(0, LO.jsx)("h2", {
          className: "SchematicPopupSubtitle",
          children: lO("general:name")
        }), (0, LO.jsx)(fO.e, {
          className: hO()("SaveSchematicName", {
            Error: VO
          }),
          forcedText: pO,
          onValueChange: OO => {
            CO(OO), NO(OO)
          },
          placeholderText: lO("worldBuilder:schematicNamePlaceholder"),
          maxLength: TO.jb
        }), (0, LO.jsx)("h2", {
          className: hO()("SaveSchematicError", {
            Hidden: !VO
          }),
          children: VO
        }), (0, LO.jsx)("h2", {
          className: hO()("SchematicPopupSubtitle", {
            Hidden: "file" === KO
          }),
          children: lO("general:description")
        }), (0, LO.jsx)(fO.e, {
          className: hO()("SaveSchematicDescription", {
            Hidden: "file" === KO
          }),
          onValueChange: oO,
          placeholderText: lO("worldBuilder:schematicDescriptionPlaceholder"),
          maxLength: TO.ib,
          useTextarea: !0
        }), (0, LO.jsxs)("div", {
          className: hO()("SaveSchematicCheckboxContainer", {
            WarningBorder: "existing" === KO
          }),
          children: [(0, LO.jsx)(dO.c, {
            checked: zK,
            onChange: OO => {
              AO(OO.target.checked)
            },
            disabled: !1,
            className: "SaveSchematicCheckbox"
          }), (0, LO.jsx)("h1", {
            className: "SchematicPopupSubtitle",
            children: lO("existing" === KO ? "worldBuilder:overwriteLobbyCode" : "worldBuilder:includeLobbyCode")
          })]
        }), "existing" === KO && (0, LO.jsx)("div", {
          className: "SaveSchematicLobbyCodeWarning",
          children: lO("worldBuilder:lobbyCodeWarning")
        }), (0, LO.jsxs)("div", {
          className: "SaveSchematicButtons",
          children: [(0, LO.jsx)(aK.m, {
            className: "SaveSchematicButton",
            onClick: () => {
              NO() && bK(zK, vK, MO)
            },
            children: lO("file" === KO ? "general:download" : "general:save")
          }), (0, LO.jsx)(aK.I, {
            className: "SaveSchematicButton",
            onClick: eO,
            children: lO("general:cancel")
          })]
        })]
      })
    }
    var yK = pO(1056),
      gK = pO(1481),
      uO = pO(1008);

    function EO(OO, KO) {
      if ("devDownloadJson" !== OO) ! function(OO, KO) {
        const pO = yK.clientSideServerUrls.getHttpUrlFromWebSocketUrl((0, eO.b)().websocketUrl);
        let vK = !1;
        const CO = async (OO, KO) => {
          if (vK) return;
          vK = !0;
          const {
            gameNameWithVariation: XO,
            lobbyName: lO
          } = (0, eO.b)(), CO = {
            gameNameWithVariation: XO,
            lobbyName: lO
          };
          return await (0, uO.postJsonWithMetricsCookiesAndJsonResponse)(`${pO}/schematic/${OO}`, bK.C[OO].toBuffer({
            ...CO,
            ...KO
          }), {
            retries: 1
          })
        };
        if ("Plugin|WorldBuilder|SaveSchematic" === OO) ! function(OO) {
          let {
            ownedSchematics: KO,
            onChosenDownload: pO,
            onChosenEdit: XO,
            onChosenNew: bK,
            onClose: eO
          } = OO;
          MO.NotificationProvider.showCustomPopup({
            body: OO => (0, LO.jsx)(NO, {
              ownedSchematics: KO,
              onChosenDownload: pO,
              onChosenEdit: XO,
              onChosenNew: bK,
              onClose: OO
            }),
            middleScreenPopupClassName: "SchematicPopup",
            onClose: eO,
            unlockPointerKey: "schematicSaverPopup"
          })
        }({
          ownedSchematics: KO,
          onChosenDownload: (OO, KO) => {
            CO("download-schematic", {
              name: OO,
              includeLobbyCode: KO
            }).then((KO => {
              let {
                buffer: {
                  data: pO
                }
              } = KO;
              const bK = XO.jb.from(pO);
              (0, gK.downloadBlob)(new Blob([bK], {
                type: "application/octet-stream"
              }), `${OO}.bloxdschem`)
            }))
          },
          onClose: () => {
            CO("cancel", {})
          },
          onChosenEdit: (OO, KO, pO, XO) => {
            CO("save-to-profile", {
              schematicId: OO,
              name: KO,
              description: pO,
              includeLobbyCode: XO
            })
          },
          onChosenNew: (OO, KO, pO) => {
            CO("save-to-profile", {
              schematicId: null,
              name: OO,
              description: KO,
              includeLobbyCode: pO
            })
          }
        });
        else if ("Plugin|WorldBuilder|LoadSchematic" === OO) ! function(OO) {
          let {
            ownedSchematics: KO,
            onChosenFile: pO,
            onChosenPreset: XO,
            onClose: bK
          } = OO;
          MO.NotificationProvider.showCustomPopup({
            body: OO => (0, LO.jsx)(zK, {
              ownedSchematics: KO,
              onChosenFile: pO,
              onChosenPreset: XO,
              onClose: OO
            }),
            middleScreenPopupClassName: "SchematicPopup",
            onClose: bK,
            unlockPointerKey: "schematicLoaderPopup"
          })
        }({
          ownedSchematics: KO,
          onChosenFile: async OO => {
            const KO = XO.jb.from(await OO.arrayBuffer()),
              {
                gameNameWithVariation: lO,
                lobbyName: vK
              } = (0, eO.b)();
            await (0, uO.postBinaryWithMetricsCookiesAndCustomResponse)(`${pO}/schematic/upload-schematic`, bK.C["upload-schematic"].toBuffer({
              gameNameWithVariation: lO,
              lobbyName: vK,
              schematic: KO
            }), {
              retries: 1
            }, uO.HttpPayloadType.json)
          },
          onChosenPreset: OO => {
            CO("load-from-profile", {
              schematicId: OO
            })
          },
          onClose: () => {
            CO("cancel", {})
          }
        });
        else if ("Plugin|WorldBuilder|ListSchematics" === OO)(0, lO.d)({
          ownedSchematics: Array.isArray(KO) ? KO : KO.schematics,
          currentWorldSchematicId: Array.isArray(KO) ? null : KO.currentWorldSchematicId,
          onClose: () => {
            CO("cancel", {})
          }
        });
        else if ("Plugin|WorldBuilder|ExportWorld" === OO) {
          var hO;
          const OO = null !== (hO = KO.schematic) && void 0 !== hO ? hO : KO;
          (0, AO.h)({
            schematic: OO,
            inSourceWorld: OO.schematicId === KO.currentWorldSchematicId,
            onClose: () => {
              CO("cancel", {})
            }
          })
        } else console.error(`Unknown plugin message type ${OO}`)
      }(OO, KO);
      else {
        const OO = JSON.stringify(KO.data, null, 2);
        (0, gK.downloadBlob)(new Blob([OO], {
          type: "application/json"
        }), KO.filename)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);