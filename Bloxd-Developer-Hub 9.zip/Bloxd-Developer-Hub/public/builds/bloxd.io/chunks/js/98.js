export const id = 98;
export const ids = [98, 99];
export const modules = {
  4111: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(1056);
    async function bK(OO) {
      const KO = await fetch(`${XO.clientSideServerUrls.s3Url}/${OO}`, {
        headers: {
          Accept: "application/json"
        }
      });
      if (404 === KO.status || 403 === KO.status) return null;
      if (!KO.ok) throw new Error(`Failed to download the texture pack (${KO.status})`);
      return await KO.json()
    }
  },
  37450: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      h: () => hO
    });
    var XO = pO(171),
      bK = pO(22),
      eO = pO(1056),
      lO = pO(1507),
      vK = pO(1008);
    async function CO(OO, KO) {
      return function(OO) {
        return "object" === typeof OO && null !== OO && OO.code === XO.e.VpnIp.code
      }(KO) && function(OO) {
        return bK.d.get("reactNativeFeatureFlags").appCheck && OO.isLoggedIn() && !OO.hasTriedAppAttestation()
      }(OO) && await async function(OO) {
        try {
          const KO = await (0, lO.d)();
          if (null === KO) return console.warn("The app couldn't get an App Check token"), OO.markAppAttestationTried(), !1;
          const {
            "3PSIDMCPP": pO
          } = await (0, vK.postJsonWithMetricsCookiesAndJsonResponse)(`${eO.clientSideServerUrls.indexUrl}/index/app-attestation`, {
            appCheckToken: KO.token
          }, {
            retries: 0
          }, OO.getMetricsCookies());
          return OO.setAppAttestedAuthJwt(pO), !0
        } catch (KO) {
          return console.error("Failed to attest the app:", KO), !1
        }
      }(OO)
    }
    async function hO(OO, KO) {
      try {
        return await KO()
      } catch (pO) {
        if (!await CO(OO, pO)) throw pO
      }
      return KO()
    }
  },
  35015: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => aK,
      i: () => DO,
      l: () => oO,
      p: () => MO
    });
    var XO = pO(256),
      bK = pO(570),
      eO = pO(967),
      lO = pO(36);
    const vK = {
        idStorageKey: "playSessionId",
        lastActivityStorageKey: "playSessionLastActivityMs",
        expiryMs: 3e5
      },
      CO = "playSessionGameNameWithVariation",
      hO = "wasMatchmakePlayer";

    function DO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h;
      (0, eO.h)(OO, vK)
    }

    function MO() {
      (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).setItem(hO, !0)
    }

    function aK() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h;
      return (0, eO.c)(OO, vK)
    }

    function oO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : lO.h;
      const pO = (0, eO.c)(KO, vK),
        DO = function(OO) {
          const KO = OO.getItem(CO);
          return "string" !== typeof KO ? null : KO
        }(KO),
        MO = function() {
          return !0 === (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).getItem(hO)
        }(KO);
      let aK;
      return aK = null !== pO && null !== DO && (0, eO.f)(KO, vK) && function(OO, KO, pO) {
          const bK = (0, XO.Qb)(OO),
            eO = (0, XO.Qb)(KO),
            lO = (0, XO.Lb)(OO),
            vK = (0, XO.Lb)(KO);
          return !(bK !== eO || !pO) || bK === eO && lO === vK
        }(DO, OO, MO) ? pO : (0, bK.c)(), (0, eO.i)(KO, vK, aK), KO.setItem(CO, OO),
        function() {
          (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : lO.h).removeItem(hO)
        }(KO), aK
    }
  },
  35011: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO,
      g: () => QO
    });
    var XO = pO(886),
      bK = pO(536),
      eO = pO(256),
      lO = pO(888),
      vK = pO(554),
      CO = pO(3710),
      hO = pO(94),
      DO = pO(142),
      MO = pO(1481),
      aK = pO(107),
      oO = pO(35015),
      FO = pO(36),
      VO = pO(959);

    function LO() {
      var OO, KO;
      return [...null !== (OO = navigator.languages) && void 0 !== OO ? OO : [null !== (KO = navigator.language) && void 0 !== KO ? KO : "none"], "En-GB"]
    }

    function QO(OO, KO, pO, QO, zK) {
      const AO = (0, XO.k)(KO) ? (0, XO.o)(KO) : null,
        fO = {
          cookies: (0, MO.getAllCookiesForGameNameWithVariation)(KO),
          isMobile: (0, hO.isMobile)(),
          isUsingCustomGameTexturePack: null !== AO && zK(AO),
          generalCookies: {
            joinDiscord: !!FO.e.getItem("DiscordPressed"),
            newGo: CO.d,
            ...OO.getMetricsCookies(),
            trafficCode: QO,
            compliance: hO.compliance
          },
          browserInfo: {
            ua: window.navigator.userAgent,
            name: (0, hO.getBrowserName)(),
            version: (0, hO.getBrowserVersion)(),
            platform: navigator.platform,
            platformType: (0, hO.getPlatformType)(),
            deviceType: (0, aK.c)()
          },
          isLoggedIn: OO.isLoggedIn(),
          lobbyName: pO,
          languages: LO(),
          version: bK.e,
          siteUsed: DO.t,
          subsiteUsed: DO.A,
          playSessionId: (0, oO.l)(KO),
          visitSessionId: (0, VO.b)(),
          clientReason: vK.i.reason
        };
      return null !== AO && (0, eO.xc)(AO) ? (fO.lobbyName = (0, XO.g)(AO, (0, XO.l)(KO), pO), {
        roomName: `classic_${lO.f}`,
        joinOptions: fO
      }) : {
        roomName: KO,
        joinOptions: fO
      }
    }
  },
  41344: (OO, KO, pO) => {
    pO.d(KO, {
      gamePackSource: () => eO
    });
    var XO = pO(4111),
      bK = pO(1329);

    function eO(OO) {
      return {
        packKey: async KO => (await bK.c.getGame(OO, KO, !0)).customTexturePackKey,
        fetchPack: XO.c
      }
    }
  },
  41336: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      fetchGuestContext: () => aK,
      guestJoinTarget: () => AO,
      guestJoinWithPack: () => FO,
      guestPackForGame: () => oO,
      invalidateGuestTrafficCode: () => zK
    });
    var XO = pO(1056),
      bK = pO(1329),
      eO = pO(94),
      lO = pO(35011),
      vK = pO(1008),
      CO = pO(39002),
      hO = pO(41344),
      DO = pO(38926);

    function MO() {
      if (eO.featureFlags.useTurnstile) throw new CO.TurnstilePageError
    }

    function aK() {
      return (0, vK.fetchAnonymousUserContext)().catch((OO => (console.warn("the guest context didn't load", OO), null)))
    }
    async function oO(OO, KO, pO, XO) {
      try {
        const bK = await pO;
        if (null === bK) return void console.warn(`the texture pack step for ${OO} has no guest context: the pack in play stays`);
        await KO.packForGame(OO, (0, hO.gamePackSource)(bK), XO)
      } catch (bK) {
        console.warn(`the texture pack step for ${OO} failed: the pack in play stays`, bK)
      }
    }
    async function FO(OO, KO, pO, XO) {
      MO();
      const bK = aK();
      return await pO(((KO, pO) => oO(OO, KO, bK, pO))), AO(OO, KO, XO(), await bK)
    }
    let VO = null,
      LO = null;
    async function QO() {
      if ((null === VO || VO.hasExpired()) && (LO ??= (0, vK.fetchAnonymousUserContext)().then((OO => {
          VO = OO
        })).finally((() => {
          LO = null
        })), await LO), null === VO) throw new Error("no guest context to post as");
      return VO.getMetricsCookies()
    }
    async function zK() {
      var OO;
      await (null === (OO = VO) || void 0 === OO ? void 0 : OO.invalidateTrafficCode())
    }
    async function AO(OO, KO, pO) {
      let eO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
      MO();
      const CO = null !== eO && void 0 !== eO ? eO : await (0, vK.fetchAnonymousUserContext)();
      if (VO = CO, CO.isLoggedIn()) throw new Error("the shell's page joins as a guest only");
      const hO = await bK.c.matchmakePlayer(CO, KO, OO, (0, lO.c)()),
        aK = performance.now();
      if (!("gameServerHost" in hO)) throw new Error(`matchmaking refused: ${hO.failReason}`);
      const oO = XO.clientSideServerUrls.getServerWebSocketUrlFromServerUrl(hO.gameServerHost);
      if (oO.isError()) throw new Error(`no socket URL for ${hO.gameServerHost}: ${oO.asError().message}`);
      const FO = {
        endpoint: oO.getValue(),
        gameNameWithVariation: hO.gameNameWithVariation,
        lobbyName: hO.lobbyName
      };
      return {
        target: {
          ...await (0, DO.e)(CO, FO, pO),
          postCookies: QO
        },
        matchedAt: aK,
        freshMs: DO.d
      }
    }
  },
  38926: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO,
      e: () => DO
    });
    var XO = pO(38943),
      bK = pO(37450),
      eO = pO(35011),
      lO = pO(38933),
      vK = pO(38873),
      CO = pO(38917);
    const hO = XO.e.timeForPlayerToConnect - 1e4;
    async function DO(OO, KO, pO) {
      const XO = await OO.getTrafficCode().then((OO => null !== OO && void 0 !== OO ? OO : null), (OO => (console.error("[bloxd-wasm-client] could not get a traffic code", OO), null)));
      if (null === XO) throw new CO.s;
      const {
        gameNameWithVariation: hO,
        lobbyName: DO
      } = KO, MO = () => {
        const KO = (0, eO.g)(OO, hO, DO, XO, (OO => {
          var KO;
          return null !== (KO = null === pO || void 0 === pO ? void 0 : pO.isUsingCustomGameTexturePack(OO)) && void 0 !== KO && KO
        }));
        KO.joinOptions.wasmClient = !0, KO.joinOptions.budgetBasis = (0, lO.i)();
        const bK = (0, vK.C)();
        return null !== bK && (KO.joinOptions.renderBackend = bK), KO
      }, {
        roomName: aK,
        joinOptions: oO
      } = MO();
      return {
        endpoint: KO.endpoint,
        roomName: aK,
        joinOptions: oO,
        session: {
          gameNameWithVariation: hO,
          lobbyName: DO,
          playerDbId: OO.whamm
        },
        optionsAfterRefusal: async KO => await (0, bK.d)(OO, KO) ? MO().joinOptions : null
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);