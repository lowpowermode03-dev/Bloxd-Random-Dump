export const id = 58;
export const ids = [52, 58, 80];
export const modules = {
  35454: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO,
      f: () => vK
    });
    var XO = pO(26);
    const bK = 1500,
      eO = 1e3,
      lO = {
        recordingStarted: {
          text: "Started recording",
          type: "Success"
        },
        recordingStopped: {
          text: "Stopped recording",
          type: "Success"
        },
        recordingSaved: {
          text: "Recording saved",
          type: "Success"
        },
        clipSaved: {
          text: "Clip saved",
          type: "Success"
        },
        limitReached: {
          text: "Your recording reached its size limit, so it was saved.",
          type: "Warning"
        },
        recordingDiscarded: {
          text: "Your recording stopped and couldn't be saved.",
          type: "Error"
        },
        recordingTurnedOff: {
          text: "This game turned off recording, so your recording was discarded",
          type: "Error",
          timeoutMs: 3e3
        },
        recordingFailed: {
          text: "Your recording couldn't be saved, so try again.",
          type: "Error"
        },
        clipFailed: {
          text: "Your clip couldn't be saved, so try again.",
          type: "Error"
        },
        clipEmpty: {
          text: "Clip buffer is empty",
          type: "Error"
        },
        clippingNotOn: {
          text: "Clipping is not enabled",
          type: "Error"
        },
        disallowed: {
          text: "Recording is turned off in this game",
          type: "Error"
        },
        closeViewerFirst: {
          text: "Close Replay Mode to start recording",
          type: "Error"
        },
        saveBusy: {
          text: "Wait for the last save to finish, then try again.",
          type: "Error"
        },
        saveClosed: {
          text: "The replay closed or changed before it was saved, so save it again.",
          type: "Error"
        },
        cantOpen: {
          text: "This replay can't be opened, so try a different file.",
          type: "Error"
        },
        cropFailed: {
          text: "The crop didn't work, so try again.",
          type: "Error"
        },
        cropBusy: {
          text: "Wait for the crop to finish, then try again.",
          type: "Error"
        },
        viewerLoadFailed: {
          text: "The replay viewer didn't load, so try again.",
          type: "Error"
        },
        coreStopped: {
          text: "Reload the page to watch another replay.",
          type: "Error"
        }
      };

    function vK(OO) {
      var KO;
      const pO = null !== (KO = OO.timeoutMs) && void 0 !== KO ? KO : "Error" === OO.type ? bK : eO;
      XO.i.pl("showBottomMessage", {
        message: OO.text,
        timeoutLength: pO,
        type: OO.type
      })
    }
  },
  35463: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      h: () => bK
    });
    const XO = "data-replay-ui-active",
      bK = [{
        group: "middleTextTop",
        dataAttr: "data-replay-hide-middle-text-top",
        label: "Middle text top"
      }, {
        group: "middleTextUpper",
        dataAttr: "data-replay-hide-middle-text-upper",
        label: "Middle text upper"
      }, {
        group: "middleTextLower",
        dataAttr: "data-replay-hide-middle-text-lower",
        label: "Middle text lower"
      }, {
        group: "rightInfoText",
        dataAttr: "data-replay-hide-right-info-text",
        label: "Right info text"
      }, {
        group: "crosshair",
        dataAttr: "data-replay-hide-crosshair",
        label: "Crosshair"
      }, {
        group: "flyingMiddleText",
        dataAttr: "data-replay-hide-flying-middle-text",
        label: "Flying middle text"
      }, {
        group: "hotbar",
        dataAttr: "data-replay-hide-hotbar",
        label: "Hotbar (shop, inventory, item name)"
      }, {
        group: "auraBar",
        dataAttr: "data-replay-hide-aura-bar",
        label: "Aura XP bar"
      }, {
        group: "healthAndShield",
        dataAttr: "data-replay-hide-health-and-shield",
        label: "Health bar and shield bar"
      }, {
        group: "effectInfo",
        dataAttr: "data-replay-hide-effect-info",
        label: "Effect info"
      }, {
        group: "nametag",
        dataAttr: null,
        label: "Nametags"
      }, {
        group: "everythingElse",
        dataAttr: "data-replay-hide-everything-else",
        label: "Everything else"
      }]
  },
  35470: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => hO,
      g: () => MO,
      k: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(35463);

    function lO() {
      const OO = {};
      for (const {
          group: KO
        }
        of eO.h) OO[KO] = !0;
      return OO
    }
    let vK = lO();

    function CO() {
      bK.i.pl("replayViewer|uiVisibilityChanged")
    }

    function hO() {
      return vK
    }

    function DO(OO, KO) {
      vK[OO] !== KO && (vK = {
        ...vK,
        [OO]: KO
      }, "nametag" === OO && XO.d.set({
        areNametagsHidden: !KO
      }), CO())
    }

    function MO() {
      vK = lO(), XO.d.set({
        areNametagsHidden: !1
      }), CO()
    }
  },
  37587: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => jK
    });
    var XO = pO(1492),
      bK = pO(1187),
      eO = pO(63),
      lO = pO(918),
      vK = pO.n(lO),
      CO = pO(1271),
      hO = pO(94);
    const DO = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"],
      MO = ["video/mp4;codecs=avc1,mp4a.40.2", "video/mp4;codecs=avc1.42E01E,mp4a.40.2", "video/mp4;codecs=avc1", "video/mp4"];

    function aK(OO) {
      return "webm" === OO ? DO : MO
    }

    function oO(OO) {
      for (const KO of OO)
        if ("undefined" !== typeof MediaRecorder && MediaRecorder.isTypeSupported(KO)) return KO;
      return null
    }

    function FO(OO) {
      return null !== oO(aK(OO))
    }
    var VO = pO(976);
    const LO = [{
      id: "webm",
      label: "WebM",
      description: "Usually less screen tearing, but may not play in all media players."
    }, {
      id: "mp4",
      label: "MP4",
      description: "Works in more players, but may show graphical glitches on some devices."
    }];

    function QO() {
      return FO("webm") ? "webm" : FO("mp4") ? "mp4" : "webm"
    }

    function zK(OO) {
      let {
        cards: KO
      } = OO;
      return (0, VO.jsx)("div", {
        className: "ReplayVideoExportOptionCards",
        children: KO.map((OO => (0, VO.jsxs)("div", {
          className: "ReplayVideoExportOptionColumn",
          children: [(0, VO.jsx)("div", {
            className: vK()("ReplayVideoExportOptionCard", {
              Selected: OO.selected,
              Disabled: OO.disabled
            }),
            onClick: () => {
              OO.disabled || OO.onSelect()
            },
            children: (0, VO.jsxs)("div", {
              className: "ReplayVideoExportOptionCardBody",
              children: [(0, VO.jsx)("div", {
                className: "ReplayVideoExportOptionCardLabel",
                children: OO.label
              }), (0, VO.jsx)("div", {
                className: "ReplayVideoExportOptionCardDescription",
                children: OO.description
              })]
            })
          }), OO.disabled && OO.disabledReason && (0, VO.jsx)("div", {
            className: "ReplayVideoExportOptionError SmallTextLight",
            children: OO.disabledReason
          })]
        }, OO.id)))
      })
    }
    const AO = (0, eO.memo)((function(OO) {
      let {
        hasPlaybackMark: KO,
        canIncludeUi: pO,
        includeUiDisabledReason: XO,
        selectionRef: bK,
        closePopup: lO
      } = OO;
      const vK = FO("webm") || FO("mp4"),
        [DO, MO] = (0, eO.useState)(QO),
        [aK, oO] = (0, eO.useState)(pO),
        AO = vK && FO(DO);
      if (!vK) {
        const OO = (0, hO.isMobile)() ? "screen recording" : "OBS";
        return (0, VO.jsxs)("div", {
          className: "PromptPopupNotification ReplayVideoExportOptionsPopup",
          children: [(0, VO.jsx)("div", {
            className: "PromptPopupNotificationTitle SmallTextBold",
            children: "Can't export video"
          }), (0, VO.jsx)("div", {
            className: "PromptPopupNotificationSubtitle SmallTextLight",
            children: `Your device does not support exporting. Try recording with an external software like ${OO}.`
          }), (0, VO.jsx)("div", {
            className: "PromptPopupNotificationBody",
            children: (0, VO.jsx)(CO.I, {
              className: "PromptPopupNotificationBodyButton",
              onClick: () => {
                bK.options = null, lO()
              },
              children: "Close"
            })
          })]
        })
      }
      const fO = KO ? "This will only play the range you've set.\nYou won't be able to cancel once it begins.\n\nDon't touch the mouse or keyboard until it finishes." : "This will play the whole recording from the start.\nYou won't be able to cancel once it begins.\n\nDon't touch the mouse or keyboard until it finishes.",
        dO = [{
          id: "withoutUi",
          label: "Without UI",
          description: "Usually cleaner and sharper.",
          selected: !aK,
          disabled: !1,
          disabledReason: null,
          onSelect: () => {
            oO(!1)
          }
        }, {
          id: "withUi",
          label: "With UI",
          description: "Includes HUD elements. May look worse on some devices.",
          selected: aK,
          disabled: !pO,
          disabledReason: XO,
          onSelect: () => {
            oO(!0)
          }
        }],
        TO = LO.map((OO => {
          const KO = FO(OO.id);
          return {
            id: OO.id,
            label: OO.label,
            description: OO.description,
            selected: DO === OO.id,
            disabled: !KO,
            disabledReason: "Your device doesn't support this format",
            onSelect: () => {
              MO(OO.id)
            }
          }
        }));
      return (0, VO.jsxs)("div", {
        className: "PromptPopupNotification ReplayVideoExportOptionsPopup",
        children: [(0, VO.jsx)("div", {
          className: "PromptPopupNotificationTitle SmallTextBold",
          children: "Export video?"
        }), (0, VO.jsx)("div", {
          className: "PromptPopupNotificationSubtitle SmallTextLight",
          children: fO
        }), (0, VO.jsxs)("div", {
          className: "ReplayVideoExportOptionsSection",
          children: [(0, VO.jsx)("div", {
            className: "ReplayVideoExportOptionsSectionLabel SmallTextBold",
            children: "UI"
          }), (0, VO.jsx)(zK, {
            cards: dO
          })]
        }), (0, VO.jsxs)("div", {
          className: "ReplayVideoExportOptionsSection",
          children: [(0, VO.jsx)("div", {
            className: "ReplayVideoExportOptionsSectionLabel SmallTextBold",
            children: "Format"
          }), (0, VO.jsx)(zK, {
            cards: TO
          })]
        }), (0, VO.jsxs)("div", {
          className: "PromptPopupNotificationBody",
          children: [(0, VO.jsx)(CO.m, {
            className: "PromptPopupNotificationBodyButton PromptPopupNotificationBodyPrimaryButton",
            disabled: !AO,
            onClick: () => {
              bK.options = {
                format: DO,
                includeUi: pO && aK
              }, lO()
            },
            children: "Export"
          }), (0, VO.jsx)(CO.I, {
            className: "PromptPopupNotificationBodyButton",
            onClick: () => {
              bK.options = null, lO()
            },
            children: "Cancel"
          })]
        })]
      })
    }));
    var fO = pO(3988),
      dO = pO(35463),
      TO = pO(35470);
    let NO = null;

    function IO() {
      return function() {
        const OO = (0, TO.e)();
        for (const {
            group: KO,
            dataAttr: pO
          }
          of dO.h)
          if (pO && OO[KO]) return !0;
        return !1
      }() ? function() {
        var OO;
        return "function" === typeof(null === (OO = navigator.mediaDevices) || void 0 === OO ? void 0 : OO.getDisplayMedia)
      }() ? {
        canIncludeUi: !0,
        includeUiDisabledReason: null
      } : {
        canIncludeUi: !1,
        includeUiDisabledReason: "Not supported on this device"
      } : {
        canIncludeUi: !1,
        includeUiDisabledReason: "No UI to include"
      }
    }
    async function yK(OO, KO, pO) {
      return OO ? async function() {
        const OO = await navigator.mediaDevices.getDisplayMedia({
          video: !0,
          audio: !1,
          preferCurrentTab: !0,
          selfBrowserSurface: "include"
        });
        for (const KO of OO.getAudioTracks()) KO.stop(), OO.removeTrack(KO);
        return OO
      }(): KO().captureStream(Math.max(1, Math.round(pO)))
    }
    var gK = pO(37456);
    let uO = !1;

    function EO(OO) {
      OO.holdInput(!1), (0, gK.f)(!1)
    }
    async function jK(OO) {
      var KO, pO;
      if ((0, gK.c)() || uO) return;
      const eO = OO();
      if (!eO) return;
      uO = !0;
      let lO = null;
      const vK = eO.playbackMarkInTick,
        {
          canIncludeUi: CO,
          includeUiDisabledReason: hO
        } = IO();
      try {
        lO = await async function(OO) {
          let {
            hasPlaybackMark: KO,
            canIncludeUi: pO,
            includeUiDisabledReason: XO
          } = OO;
          const eO = {
              options: null
            },
            lO = bK.NotificationProvider.showCustomPopup({
              body: OO => (0, VO.jsx)(AO, {
                hasPlaybackMark: KO,
                canIncludeUi: pO,
                includeUiDisabledReason: XO,
                selectionRef: eO,
                closePopup: OO
              }),
              disableExitButton: !0,
              disablePressBackgroundToClose: !0,
              unlockPointerKey: "replayVideoExportOptions"
            });
          return "notificationTornDown" === await lO.getResult() ? null : eO.options
        }({
          hasPlaybackMark: null !== vK,
          canIncludeUi: CO,
          includeUiDisabledReason: hO
        })
      } finally {
        uO = !1
      }
      if (!lO) return;
      const DO = null !== (KO = null === (pO = eO.startFailure) || void 0 === pO ? void 0 : pO.call(eO)) && void 0 !== KO ? KO : null;
      if (null !== DO) return void bK.NotificationProvider.showAlertPopup({
        title: "Video export failed",
        subtitle: DO
      });
      if (! function(OO) {
          return !(0, gK.c)() && ((0, gK.f)(!0), OO.holdInput(!0), !0)
        }(eO)) return;
      let MO = null;
      try {
        MO = await yK(lO.includeUi, (() => eO.canvas()), eO.RKO)
      } catch (YO) {
        return console.error("Failed to create video stream for export", YO), EO(eO), void bK.NotificationProvider.showAlertPopup({
          title: "Video export failed",
          subtitle: YO instanceof Error ? YO.message : "Could not start capture."
        })
      }
      let FO = null;
      const LO = [];
      let QO = null,
        zK = null;
      try {
        var dO, TO, jK;
        FO = eO.playbackSpeed(), eO.closeViewer(), eO.setPlaybackSpeed(1), eO.pause(), eO.seekToTick(null !== vK && void 0 !== vK ? vK : 0);
        const OO = await async function() {
          const OO = fO.b.masterGain;
          if (!fO.b.ctx || !OO) return null;
          await fO.b.ctx.resume();
          const KO = fO.b.ctx.createMediaStreamDestination();
          OO.connect(KO), NO = KO;
          const [pO] = KO.stream.getAudioTracks();
          return null !== pO && void 0 !== pO ? pO : null
        }();
        zK = new MediaStream;
        for (const XO of MO.getVideoTracks()) zK.addTrack(XO);
        OO && zK.addTrack(OO);
        const KO = function(OO) {
          const KO = oO(aK(OO));
          if (!KO) throw new Error(`No MediaRecorder mime type available for ${OO}`);
          return KO
        }(lO.format);
        QO = new MediaRecorder(zK, {
          mimeType: KO,
          videoBitsPerSecond: 8e6
        }), QO.ondataavailable = OO => {
          OO.data.size > 0 && LO.push(OO.data)
        };
        const pO = new Promise((OO => {
          QO.onstop = () => {
            OO()
          }
        }));
        await (null === (dO = eO.seekSettled) || void 0 === dO ? void 0 : dO.call(eO));
        const [CO] = MO.getVideoTracks();
        QO.start(250), eO.play();
        const hO = await
        function(OO, KO, pO) {
          return new Promise((XO => {
            let bK = !1;
            const eO = OO => {
                bK || (bK = !0, vK(), KO.removeEventListener("ended", lO), XO(OO))
              },
              lO = () => {
                eO("captureLost")
              },
              vK = OO.watchPlayback((() => {
                OO.isPlaying() || eO("completed")
              }));
            KO.addEventListener("ended", lO), pO.onerror = () => {
              eO("recorderError")
            }, "ended" !== KO.readyState ? OO.isPlaying() || eO("completed") : eO("captureLost")
          }))
        }(eO, CO, QO);
        if (eO.pause(), "inactive" !== QO.state && QO.stop(), await pO, "captureLost" === hO) return void bK.NotificationProvider.showAlertPopup({
          title: "Video export stopped",
          subtitle: "Screen sharing ended before the replay finished. Nothing was saved."
        });
        if ("recorderError" === hO) return void bK.NotificationProvider.showAlertPopup({
          title: "Video export failed",
          subtitle: "The recorder encountered an error. Nothing was saved."
        });
        const DO = null !== (TO = null === (jK = eO.playbackFailure) || void 0 === jK ? void 0 : jK.call(eO)) && void 0 !== TO ? TO : null;
        if (null !== DO) return void bK.NotificationProvider.showAlertPopup({
          title: "Video export failed",
          subtitle: `${DO} Nothing was saved.`
        });
        const VO = new Blob(LO, {
          type: KO
        });
        VO.size > 0 ? (0, XO.d)(VO, function(OO, KO) {
          const pO = function(OO) {
            return "mp4" === OO ? "mp4" : "webm"
          }(KO);
          if (OO) return `${OO.replace(/\.bloxdreplay$/i,"")}.${pO}`;
          return `bloxd-replay-${Date.now()}.${pO}`
        }(eO.fileName(), lO.format)) : bK.NotificationProvider.showAlertPopup({
          title: "Video export failed",
          subtitle: "No video data was captured. Try again."
        })
      } catch (YO) {
        console.error("Replay video export failed", YO), bK.NotificationProvider.showAlertPopup({
          title: "Video export failed",
          subtitle: YO instanceof Error ? YO.message : "Something went wrong while exporting."
        })
      } finally {
        if (QO && "inactive" !== QO.state) try {
          QO.stop()
        } catch (YO) {
          console.error("Failed to stop MediaRecorder", YO)
        }! function() {
          const OO = fO.b.masterGain;
          if (NO && OO) {
            try {
              OO.disconnect(NO)
            } catch (YO) {
              console.error("Failed to disconnect Howler export tee", YO)
            }
            NO = null
          } else NO = null
        }();
        for (const OO of MO.getTracks()) OO.stop();
        if (zK)
          for (const OO of zK.getTracks()) OO.stop();
        null !== FO && eO.setPlaybackSpeed(FO), eO.pause(), EO(eO), eO.reopenViewer()
      }
    }
  },
  3988: (OO, KO, pO) => {
    pO.d(KO, {
      Howl: () => XO.Howl,
      b: () => XO.Howler
    });
    var XO = pO(3992);
    XO.Howler._mobileUnloaded = !0
  },
  40618: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO,
      g: () => bK
    });
    const XO = ["recording", "freecam", "keyframe"];

    function bK() {
      const OO = crypto.getRandomValues(new Uint32Array(2));
      return BigInt(OO[1]) << 32n | BigInt(OO[0])
    }
  },
  40653: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      HOLD_TIMEOUT_MS: () => vK,
      ReplayViewer: () => hO
    });
    var XO = pO(35454),
      bK = pO(35470),
      eO = pO(3934),
      lO = pO(40618);
    const vK = 1e4,
      CO = new Set(["hX"]);
    class hO {
      constructor(OO) {
        var KO;
        this.deps = OO, this.id = 0, this.fileName = null, this.fileHandle = null, this.unsavedChanges = !1, this.suggestSaveAs = !1, this.playback = !1, this.opening = !1, this.loadingOpens = 0, this.epoch = 0, this.holds = new Map, this.seekAsked = !1, this.cropAsked = !1, this.cropRunning = !1, this.settleFrames = 0, this.pendingSave = null, this.pendingOpen = null, this.saveRefused = !1, this.edits = 0, this.editsAtSave = null, this.lastView = null, this.now = void 0, this.now = null !== (KO = OO.now) && void 0 !== KO ? KO : () => performance.now()
      }
      get inPlayback() {
        return this.playback
      }
      get view() {
        return this.lastView
      }
      get isOpen() {
        return null !== this.lastView && this.lastView.state !== eO.cd.None
      }
      get keyframes() {
        return this.deps.client.keyframes()
      }
      get JK() {
        return [...this.holds.keys()]
      }
      get savePending() {
        return null !== this.pendingSave
      }
      get saveRefusal() {
        return this.cropping ? XO.b.cropBusy.text : null
      }
      get cropping() {
        return this.cropAsked || this.cropRunning
      }
      async open(OO, KO) {
        var pO, bK, lO, vK;
        const {
          client: CO
        } = this.deps;
        if (!this.playback) {
          if (!CO.setPlayback(!0)) throw new Error(XO.b.cantOpen.text);
          this.playback = !0
        }
        this.hold("opening"), this.loadingOpens++;
        const hO = this.epoch;
        let DO;
        try {
          DO = await CO.open(OO)
        } finally {
          this.loadingOpens--
        }
        if (hO !== this.epoch) throw new Error(XO.b.coreStopped.text);
        if ("opening" !== DO) {
          this.opening || 0 !== this.loadingOpens || this.release("opening");
          const OO = function(OO) {
            switch (OO) {
              case "reloading":
                return null;
              case "stopped":
              case eO.Sc.ModuleTrap:
                return XO.b.coreStopped;
              case eO.Sc.ModuleLoad:
                return XO.b.viewerLoadFailed;
              case eO.Sc.TooLarge:
                return XO.b.cantOpen
            }
          }(DO);
          if (null === OO) return;
          throw new Error(OO.text)
        }
        return this.rejectSave(new Error(XO.b.saveClosed.text)), this.fileName = null !== (pO = null !== (bK = KO.fileName) && void 0 !== bK ? bK : null === (lO = KO.fileHandle) || void 0 === lO ? void 0 : lO.name) && void 0 !== pO ? pO : null, this.fileHandle = null !== (vK = KO.fileHandle) && void 0 !== vK ? vK : null, this.unsavedChanges = !1, this.suggestSaveAs = !1, this.opening = !0, this.cropAsked = !1, this.cropRunning = !1, this.seekAsked = !1, this.hold("opening"), this.id++, this.deps.onChange(), this.settleOpen(null), new Promise(((OO, KO) => {
          this.pendingOpen = {
            resolve: OO,
            reject: KO
          }
        }))
      }
      play() {
        this.holds.has("hX") || this.deps.client.play()
      }
      pause() {
        this.deps.client.pause()
      }
      holdForShaderPackFailure() {
        this.isOpen && this.pause(), this.hold("hX")
      }
      seek(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const pO = this.lastView;
        null !== pO && (KO || OO < pO.KK) && (this.seekAsked = !0, this.hold("seek")), this.deps.client.seek(OO, KO)
      }
      setSpeed(OO) {
        this.deps.client.setSpeed(OO)
      }
      setCameraMode(OO) {
        this.deps.client.setCameraMode(OO)
      }
      cycleCameraMode() {
        const OO = this.lastView;
        null !== OO && OO.state !== eO.cd.None && this.setCameraMode(lO.d[(lO.d.indexOf(OO.cameraMode) + 1) % lO.d.length])
      }
      addKeyframe() {
        this.edited(this.deps.client.addKeyframe())
      }
      setKeyframe(OO) {
        this.edited(this.deps.client.setKeyframe(OO))
      }
      moveKeyframe(OO, KO) {
        this.edited(this.deps.client.moveKeyframe(OO, KO))
      }
      deleteKeyframes(OO, KO) {
        this.edited(this.deps.client.deleteKeyframes(OO, KO))
      }
      setMark(OO) {
        this.edited(this.deps.client.setMark(OO))
      }
      crop(OO, KO) {
        return !(KO <= OO) && (null !== this.pendingSave ? (this.deps.notify(XO.b.saveBusy), !1) : !!this.deps.client.crop(OO, KO) && (this.cropAsked = !0, this.hold("crop"), !0))
      }
      save() {
        return null !== this.pendingSave ? Promise.reject(new Error(XO.b.saveBusy.text)) : new Promise(((OO, KO) => {
          const pO = {
            resolve: OO,
            reject: KO
          };
          this.pendingSave = pO, this.editsAtSave = this.edits, this.deps.client.save((0, lO.g)()).then((OO => {
            this.pendingSave === pO && this.saveStarted(OO)
          }), (OO => {
            this.pendingSave === pO && this.rejectSave(OO instanceof Error ? OO : new Error(String(OO)))
          }))
        }))
      }
      saveStarted(OO) {
        switch (OO) {
          case "sealing":
            return;
          case "busy":
            return void this.saveFailed(!0);
          case "refused":
            return void(this.saveRefused = !0);
          case "tooLarge":
            return void this.saveFailed(!1)
        }
      }
      markSaved(OO, KO) {
        var pO, XO;
        this.fileHandle = OO, this.fileName = null !== (pO = null !== (XO = null === OO || void 0 === OO ? void 0 : OO.name) && void 0 !== XO ? XO : KO) && void 0 !== pO ? pO : this.fileName, this.unsavedChanges = null !== this.editsAtSave && this.edits !== this.editsAtSave, this.editsAtSave = null, this.suggestSaveAs = !1, this.deps.onChange()
      }
      end() {
        this.epoch++, this.resetInFlight(), this.releaseAll(), this.settleOpen(new Error(XO.b.coreStopped.text)), this.rejectSave(new Error(XO.b.saveClosed.text)), this.lastView = null, this.deps.onChange()
      }
      afterFrame() {
        var OO, KO, pO;
        const XO = this.deps.client.view(),
          lO = XO !== this.lastView;
        this.lastView = XO, this.opening && null !== XO && XO.state !== eO.cd.None && XO.totalTicks > 0 && (this.opening = !1, this.settleFrames = 2, this.settleOpen(null), (0, bK.g)()), this.cropAsked ? (this.cropAsked = !1, null !== XO && XO.state === eO.cd.Cropping ? this.cropRunning = !0 : this.cropped()) : this.cropRunning && null !== XO && XO.state !== eO.cd.Cropping && (this.cropRunning = !1, this.cropped()), this.seekAsked && (this.seekAsked = !1, this.settleFrames = 2), this.settleFrames > 0 && this.settleFrames--;
        const hO = 0 === this.settleFrames && 0 === (null !== (OO = null === (KO = (pO = this.deps).meshPending) || void 0 === KO ? void 0 : KO.call(pO)) && void 0 !== OO ? OO : 0);
        this.holds.has("opening") && !this.opening && 0 === this.loadingOpens && hO && this.release("opening"), this.holds.has("seek") && hO && this.release("seek"), this.holds.has("crop") && !this.cropRunning && hO && this.release("crop");
        const DO = this.now();
        for (const [bK, eO] of this.holds) !CO.has(bK) && DO - eO >= vK && (this.release(bK), "opening" === bK && (this.opening = !1, this.settleOpen(null)));
        this.saveRefused && !this.cropping && this.saveFailed(!1), lO && this.deps.onChange()
      }
      cropped() {
        (0, bK.g)(), this.id++, this.unsavedChanges = !0, this.suggestSaveAs = null !== this.fileHandle || null !== this.fileName, this.settleFrames = 2
      }
      onFailed(OO) {
        switch (OO.reason) {
          case eO.Sc.TooLarge:
            break;
          case eO.Sc.Open:
          case eO.Sc.NothingStaged:
            this.opening = !1, this.release("opening"), null === this.pendingOpen && this.deps.notify(XO.b.cantOpen), this.settleOpen(new Error(XO.b.cantOpen.text));
            break;
          case eO.Sc.Crop:
            if (OO.code === eO.Qc.Busy) {
              this.cropBusy();
              break
            }
            if (!this.cropping && this.saveRefused) {
              this.saveFailed(!1);
              break
            }
            this.cropAsked = !1, this.cropRunning = !1, this.release("crop"), this.deps.notify(XO.b.cropFailed);
            break;
          case eO.Sc.ModuleTrap:
          case eO.Sc.ModuleLoad:
          case eO.Sc.Port:
            this.moduleEnded(OO.reason === eO.Sc.ModuleTrap ? XO.b.coreStopped : XO.b.cantOpen);
            break;
          case eO.Sc.NotLive:
            console.warn("[bloxd-wasm-client] the core refused a recorder command in playback");
            break;
          default:
            console.warn(`[bloxd-wasm-client] the replay module refused a command (ReplayFailed ${OO.reason})`), this.seekAsked = !1, this.release("seek")
        }
        this.deps.onChange()
      }
      moduleEnded(OO) {
        this.resetInFlight(), this.release("opening"), this.release("seek"), this.release("crop"), null === this.pendingOpen && this.deps.notify(OO), this.settleOpen(new Error(OO.text))
      }
      saveDone(OO) {
        const KO = this.pendingSave;
        this.pendingSave = null, this.saveRefused = !1, null === KO || void 0 === KO || KO.resolve(OO)
      }
      saveFailed(OO) {
        this.rejectSave(new Error(OO ? XO.b.saveBusy.text : "The replay couldn't be saved"))
      }
      edited(OO) {
        OO && !this.cropping && (this.edits++, this.unsavedChanges = !0, this.deps.onChange())
      }
      cropBusy() {
        null !== this.pendingSave && this.saveRefused ? this.rejectSave(new Error(XO.b.cropBusy.text)) : this.deps.notify(XO.b.cropBusy)
      }
      resetInFlight() {
        this.opening = !1, this.seekAsked = !1, this.cropAsked = !1, this.cropRunning = !1, this.settleFrames = 0
      }
      settleOpen(OO) {
        const KO = this.pendingOpen;
        this.pendingOpen = null, null === OO ? null === KO || void 0 === KO || KO.resolve() : null === KO || void 0 === KO || KO.reject(OO)
      }
      rejectSave(OO) {
        const KO = this.pendingSave;
        this.pendingSave = null, this.saveRefused = !1, null === KO || void 0 === KO || KO.reject(OO)
      }
      hold(OO) {
        const KO = 0 === this.holds.size;
        this.holds.set(OO, this.now()), KO && this.deps.setHoldDraws(!0)
      }
      release(OO) {
        this.holds.delete(OO) && 0 === this.holds.size && this.deps.setHoldDraws(!1)
      }
      releaseAll() {
        this.holds.size > 0 && (this.holds.clear(), this.deps.setHoldDraws(!1))
      }
    }
  },
  40648: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      MESH_TAIL_MS: () => hO,
      PLAY_START_TIMEOUT_MS: () => vK,
      startWasmReplayVideoExport: () => MO
    });
    var XO = pO(37587),
      bK = pO(40653),
      eO = pO(3934),
      lO = pO(1973);
    const vK = bK.HOLD_TIMEOUT_MS + 5e3,
      CO = 50,
      hO = 200;

    function DO(OO) {
      var KO;
      return (null === (KO = OO.view) || void 0 === KO ? void 0 : KO.state) === eO.cd.Cropping || OO.JK.includes("crop")
    }

    function MO(OO) {
      return (0, XO.e)((() => function(OO) {
        var KO, pO, XO, bK, MO, aK;
        const oO = OO.viewer(),
          FO = null !== (KO = null === oO || void 0 === oO ? void 0 : oO.view) && void 0 !== KO ? KO : null,
          VO = OO.canvas();
        if (!oO || !FO || FO.state === eO.cd.None || 0 === FO.totalTicks || !VO || DO(oO)) return null;
        const LO = null !== (pO = OO.now) && void 0 !== pO ? pO : () => performance.now(),
          QO = oO.id,
          zK = () => {
            const KO = OO.viewer();
            return KO === oO && KO.id === QO && KO.isOpen ? KO : null
          },
          AO = Math.min(null !== (XO = null === (bK = FO.mark) || void 0 === bK ? void 0 : bK.outTick) && void 0 !== XO ? XO : 1 / 0, FO.totalTicks - 1);
        let fO = null,
          dO = !1;
        const TO = () => {
          var OO, KO;
          return (null === (OO = zK()) || void 0 === OO || null === (KO = OO.view) || void 0 === KO ? void 0 : KO.state) === eO.cd.Playing
        };
        return {
          RKO: eO.md,
          playbackMarkInTick: null !== (MO = null === (aK = FO.mark) || void 0 === aK ? void 0 : aK.inTick) && void 0 !== MO ? MO : null,
          startFailure: () => {
            const OO = zK();
            return null === OO ? "Another replay opened. Export it again from there." : DO(OO) ? "Wait for the crop to finish, then export again." : null
          },
          fileName: () => {
            var OO, KO;
            return null !== (OO = null === (KO = zK()) || void 0 === KO ? void 0 : KO.fileName) && void 0 !== OO ? OO : null
          },
          playbackSpeed: () => {
            var OO, KO, pO;
            return null !== (OO = null === (KO = zK()) || void 0 === KO || null === (pO = KO.view) || void 0 === pO ? void 0 : pO.speed) && void 0 !== OO ? OO : 1
          },
          setPlaybackSpeed: OO => {
            var KO;
            null === (KO = zK()) || void 0 === KO || KO.setSpeed(OO)
          },
          play: () => {
            var OO;
            dO = !1, fO = LO(), null === (OO = zK()) || void 0 === OO || OO.play()
          },
          pause: () => {
            var OO;
            null === (OO = zK()) || void 0 === OO || OO.pause()
          },
          seekToTick: OO => {
            var KO;
            null === (KO = zK()) || void 0 === KO || KO.seek(OO, !0)
          },
          seekSettled: () => new Promise((OO => {
            const KO = setInterval((() => {
              const pO = zK();
              null === pO ? (clearInterval(KO), OO()) : pO.JK.includes("seek") || (clearInterval(KO), setTimeout(OO, hO))
            }), CO)
          })),
          isPlaying: () => {
            var OO, KO, pO;
            return null !== fO && null !== zK() && (!!TO() || !dO && (null !== (OO = null === (KO = zK()) || void 0 === KO || null === (pO = KO.view) || void 0 === pO ? void 0 : pO.KK) && void 0 !== OO ? OO : 0) < AO && LO() - fO < vK)
          },
          watchPlayback: KO => {
            const pO = OO.watchViewer((() => {
                dO ||= null !== fO && TO(), KO()
              })),
              XO = setTimeout(KO, vK + 1);
            return () => {
              clearTimeout(XO), pO()
            }
          },
          playbackFailure: () => {
            var OO, KO;
            const pO = zK();
            return null === pO ? "The replay closed before the video finished." : (null !== (OO = null === (KO = pO.view) || void 0 === KO ? void 0 : KO.KK) && void 0 !== OO ? OO : 0) >= AO ? null : dO ? "The replay stopped before the video finished." : "The replay didn't start playing."
          },
          canvas: () => VO,
          closeViewer: () => {
            OO.requestViewer("close")
          },
          reopenViewer: () => {
            OO.requestViewer("open")
          },
          holdInput: lO.e
        }
      }(OO)))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);