export const id = 12;
export const ids = [12];
export const modules = {
  36892: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => lO
    });
    var XO = pO(36895);
    const bK = [0, 0, 0];
    class eO {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK;
        this.pool = OO, this.origin = KO, this.count = 0, this.free = []
      }
      take() {
        var OO;
        const KO = null !== (OO = this.free.pop()) && void 0 !== OO ? OO : this.count++;
        return KO >= this.pool.YO && this.pool.grow(Math.max(2 * this.pool.YO, KO + 1)), this.hide(KO), KO
      }
      release(OO) {
        this.hide(OO), this.free.push(OO)
      }
      write(OO, KO, pO, bK) {
        const {
          records: eO
        } = this.pool, {
          origin: lO
        } = this, vK = OO * XO.d;
        eO[vK] = KO - lO[0], eO[vK + 1] = pO - lO[1], eO[vK + 2] = bK - lO[2], eO[vK + XO.h] = 0, this.pool.markDirty(OO)
      }
      hide(OO) {
        this.pool.records[OO * XO.d + XO.h] = 1, this.pool.markDirty(OO)
      }
      commit() {
        this.pool.commit(this.count)
      }
      dispose() {
        this.pool.dispose()
      }
    }
    class lO {
      constructor(OO, KO, pO) {
        this.api = OO, this.model = KO, this.initialCapacity = pO, this.kinds = new Map, this.origin = [0, 0, 0]
      }
      kindOf(OO) {
        let KO = this.kinds.get(OO);
        if (void 0 === KO) {
          const pO = this.api.createInstancePool({
            ...this.model,
            item: OO
          }, this.initialCapacity);
          null === pO || void 0 === pO || pO.setOrigin(this.origin[0], this.origin[1], this.origin[2]), KO = pO && new eO(pO, this.origin), this.kinds.set(OO, KO)
        }
        return KO
      }
      follow(OO) {
        const {
          origin: KO
        } = this;
        if (Math.abs(OO[0] - KO[0]) <= 512 && Math.abs(OO[1] - KO[1]) <= 512 && Math.abs(OO[2] - KO[2]) <= 512) return !1;
        KO[0] = Math.floor(OO[0]), KO[1] = Math.floor(OO[1]), KO[2] = Math.floor(OO[2]);
        for (const pO of this.kinds.values()) null === pO || void 0 === pO || pO.pool.setOrigin(KO[0], KO[1], KO[2]);
        return !0
      }
      commit() {
        for (const OO of this.kinds.values()) null === OO || void 0 === OO || OO.commit()
      }
      dispose() {
        for (const OO of this.kinds.values()) null === OO || void 0 === OO || OO.dispose();
        this.kinds.clear()
      }
    }
  },
  37622: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => MO
    });
    const XO = "Pipe",
      bK = "Extractor Pipe",
      eO = (new Set([XO, bK]), new Set([XO, bK, "Splitter Pipe", "Filter Pipe", "Merger Pipe", "Wire"]));
    var lO = pO(36892);
    class vK {
      constructor(OO) {
        this.api = OO, this.items = new Map, this.unshown = new Set, this.kinds = void 0, this.kinds = new lO.b(OO, {
          scale: .3,
          yaw: 0
        }, 16)
      }
      onSpawn(OO) {
        if (OO.waypoints.length < 2) return void console.warn(`[PipeItemVisualizer] Ignoring pipe item ${OO.id} with < 2 waypoints`);
        const KO = this.kinds.kindOf(OO.itemName);
        if (!KO) return void(this.unshown.has(OO.itemName) || (this.unshown.add(OO.itemName), console.warn(`[PipeItemVisualizer] No model for pipe item "${OO.itemName}"`)));
        this.remove(OO.id);
        const pO = function(OO) {
          return (OO.waypoints.length - 1) / 2 * 1e3
        }(OO);
        if (Date.now() - OO.startTimeMs > pO + 2e3) return;
        const XO = KO.take();
        this.items.set(OO.id, {
          kind: KO,
          slot: XO,
          waypoints: OO.waypoints,
          startTimeMs: OO.startTimeMs,
          durationMs: pO
        })
      }
      onEnd(OO) {
        this.remove(OO.id)
      }
      xV() {
        if (0 === this.items.size) return void this.kinds.commit();
        const OO = Date.now();
        this.kinds.follow(this.api.getCameraPosition());
        for (const [KO, pO] of this.items) OO - pO.startTimeMs > pO.durationMs + 2e3 ? this.remove(KO) : this.write(pO, OO);
        this.kinds.commit()
      }
      dispose() {
        this.kinds.dispose(), this.items.clear()
      }
      remove(OO) {
        const KO = this.items.get(OO);
        KO && (KO.kind.release(KO.slot), this.items.delete(OO))
      }
      write(OO, KO) {
        const pO = OO.waypoints.length - 1;
        let XO = (KO - OO.startTimeMs) / OO.durationMs;
        XO < 0 ? XO = 0 : XO > 1 && (XO = 1);
        const bK = XO * pO;
        let eO = Math.floor(bK);
        eO >= pO && (eO = pO - 1);
        const lO = bK - eO,
          [vK, CO, hO] = OO.waypoints[eO],
          [DO, MO, aK] = OO.waypoints[eO + 1];
        OO.kind.write(OO.slot, vK + (DO - vK) * lO + .5, CO + (MO - CO) * lO + .5, hO + (aK - hO) * lO + .5)
      }
    }
    const CO = ["Auto Crafter", "Lunite Auto Crafter", "Auto Harvester", "Lunite Auto Harvester", "Filter Pipe", "Merger Pipe", "Auto Miner", "_Auto Miner Body", "_Auto Miner Drill Front", "_Auto Miner Drill Back", "_Auto Miner Foot Front", "Lunite Auto Miner", "_Lunite Auto Miner Body", "_Lunite Auto Miner Drill Front", "_Lunite Auto Miner Drill Back", "_Lunite Auto Miner Foot Front"],
      hO = new Set(CO);
    class DO {
      constructor() {
        this.pipeVisualizer = null, this.api = void 0
      }
      onCreate(OO) {
        this.api = OO, this.pipeVisualizer = new vK(OO)
      }
      onClose() {
        var OO;
        null === (OO = this.pipeVisualizer) || void 0 === OO || OO.dispose(), this.pipeVisualizer = null
      }
      onReceivedMessageFromServer(OO, KO) {
        const {
          pipeVisualizer: pO
        } = this;
        if (pO)
          if ("pipeItemSpawnBatch" === OO)
            for (const XO of KO.items) pO.onSpawn(XO);
          else if ("pipeItemEndBatch" === OO)
          for (const XO of KO.items) pO.onEnd(XO)
      }
      xV() {
        var OO;
        null === (OO = this.pipeVisualizer) || void 0 === OO || OO.xV()
      }
      onPlayerAttemptAltAction(OO, KO, pO, XO, bK, lO) {
        var vK;
        if (!hO.has(this.api.getMetaInfo(bK).rootName)) return;
        const CO = null === (vK = this.api.mhO(OO)) || void 0 === vK ? void 0 : vK.name;
        return void 0 !== CO && eO.has(CO) ? "preventAction" : void 0
      }
    }
    const MO = function(OO, KO, pO) {
      if ("survivalFactory" !== pO && "survivalFactoryPersistent" !== pO) {
        return {}
      }
      const XO = new DO;
      return {
        onCreate: OO => {
          XO.onCreate(OO)
        },
        onClose: () => {
          XO.onClose()
        },
        onReceivedMessageFromServer: (OO, KO) => {
          XO.onReceivedMessageFromServer(OO, KO)
        },
        KK: () => {
          XO.xV()
        },
        altVetoBlocks: CO,
        onPlayerAttemptAltAction: (OO, KO, pO, bK, eO, lO) => XO.onPlayerAttemptAltAction(OO, KO, pO, bK, eO, lO)
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);