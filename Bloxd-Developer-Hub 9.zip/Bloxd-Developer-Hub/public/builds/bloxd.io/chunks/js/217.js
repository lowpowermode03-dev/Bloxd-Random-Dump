export const id = 217;
export const ids = [217];
export const modules = {
  35680: (OO, KO, pO) => {
    pO.d(KO, {
      Color3: () => XO.e,
      c: () => XO.g
    });
    var XO = pO(35688);
    (0, XO.h)()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);