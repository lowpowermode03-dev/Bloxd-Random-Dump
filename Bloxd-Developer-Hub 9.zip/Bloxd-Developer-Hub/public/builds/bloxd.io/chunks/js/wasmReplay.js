export const id = 57;
export const ids = [57];
export const modules = {
  59378: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/bloxd_wasm_replay_bg.0ce188a7d14652016e63.wasm"
  },
  59372: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      BloxdReplayWasmError: () => rK,
      loadReplayModule: () => JO,
      markReplayTrapped: () => ZO,
      replayMemoryBytes: () => BO,
      unloadReplayModule: () => cK
    });
    var XO = {};
    pO.r(XO), pO.d(XO, {
      raO: () => bK,
      RoO: () => YO,
      aK: () => eO,
      default: () => jK,
      initSync: () => EO,
      oO: () => lO,
      jaO: () => vK,
      PMO: () => CO
    });
    class bK {
      __destroy_into_raw() {
        const OO = this.__wbg_ptr;
        return this.__wbg_ptr = 0, DO.unregister(this), OO
      }
      free() {
        const OO = this.__destroy_into_raw();
        yK.ij81(OO, 0)
      }
      RMO(OO, KO, pO, XO, bK, eO) {
        yK.yYE0(this.__wbg_ptr, OO, KO, pO, XO, bK, eO)
      }
      close() {
        yK.pbrO(this.__wbg_ptr)
      }
      crop(OO, KO) {
        yK.Iloa(this.__wbg_ptr, OO, KO)
      }
      caO(OO, KO) {
        yK.Y8Ad(this.__wbg_ptr, OO, KO)
      }
      ZMO() {
        return yK.nr5m(this.__wbg_ptr) >>> 0
      }
      BMO() {
        return yK.kEZ1(this.__wbg_ptr) >>> 0
      }
      GMO() {
        return yK.QZUI(this.__wbg_ptr) >>> 0
      }
      qaO() {
        return yK.ytHj(this.__wbg_ptr) >>> 0
      }
      JMO(OO, KO) {
        yK.RRqg(this.__wbg_ptr, OO, KO)
      }
      constructor() {
        const OO = yK.OWDb();
        return this.__wbg_ptr = OO, DO.register(this, this.__wbg_ptr, this), this
      }
      open() {
        yK.VbXp(this.__wbg_ptr)
      }
      yaO() {
        return yK.gJnN(this.__wbg_ptr) >>> 0
      }
      pause() {
        yK.LLyc(this.__wbg_ptr)
      }
      play() {
        yK.SdVh(this.__wbg_ptr)
      }
      save() {
        return yK.P55w(this.__wbg_ptr) >>> 0
      }
      xaO() {
        yK.NImR(this.__wbg_ptr)
      }
      seek(OO, KO) {
        yK.KBHo(this.__wbg_ptr, OO, KO)
      }
      WMO(OO) {
        yK.au8Z(this.__wbg_ptr, OO)
      }
      SMO(OO, KO) {
        const pO = function(OO, KO) {
            const pO = KO(8 * OO.length, 8) >>> 0;
            return function() {
              null !== aK && 0 !== aK.byteLength || (aK = new Float64Array(yK.memory.buffer));
              return aK
            }().set(OO, pO / 8), gK = OO.length, pO
          }(KO, yK.D4bF),
          XO = gK;
        yK.pSo6(this.__wbg_ptr, OO, pO, XO)
      }
      HMO(OO, KO) {
        yK.cThA(this.__wbg_ptr, OO, KO)
      }
      nMO(OO) {
        yK.YbtM(this.__wbg_ptr, OO)
      }
      stage(OO) {
        return yK.IdS1(this.__wbg_ptr, OO) >>> 0
      }
      step(OO, KO) {
        return yK.vSP5(this.__wbg_ptr, OO, KO) >>> 0
      }
    }

    function eO(OO, KO) {
      const pO = function(OO, KO, pO) {
          if (void 0 === pO) {
            const pO = TO.encode(OO),
              XO = KO(pO.length, 1) >>> 0;
            return VO().subarray(XO, XO + pO.length).set(pO), gK = pO.length, XO
          }
          let XO = OO.length,
            bK = KO(XO, 1) >>> 0;
          const eO = VO();
          let lO = 0;
          for (; lO < XO; lO++) {
            const KO = OO.charCodeAt(lO);
            if (KO > 127) break;
            eO[bK + lO] = KO
          }
          if (lO !== XO) {
            0 !== lO && (OO = OO.slice(lO)), bK = pO(bK, XO, XO = lO + 3 * OO.length, 1) >>> 0;
            const KO = VO().subarray(bK + lO, bK + XO);
            lO += TO.encodeInto(OO, KO).written, bK = pO(bK, XO, lO, 1) >>> 0
          }
          return gK = lO, bK
        }(OO, yK.D4bF, yK.AoTn),
        XO = gK,
        bK = yK.PFpB(pO, XO, KO);
      if (bK[1]) throw zK(bK[0])
    }

    function lO() {
      yK.UADh()
    }

    function vK() {
      return yK.g2Ye() >>> 0
    }

    function CO() {
      return zK(yK.SwrT())
    }

    function hO() {
      return {
        __proto__: null,
        SjHu: {
          __proto__: null,
          ARZQ: function(OO, KO) {
            return MO(Error(oO(OO, KO)))
          },
          qPmR: function() {
            return MO(yK.memory)
          },
          cWPN: function(OO, KO) {
            throw new Error(oO(OO, KO))
          },
          blTl: function(OO, KO) {
            console.error(oO(OO, KO))
          },
          zJSN: function() {
            return performance.now()
          }
        }
      }
    }
    Symbol.dispose && (bK.prototype[Symbol.dispose] = bK.prototype.free);
    const DO = "undefined" === typeof FinalizationRegistry ? {
      register: () => {},
      unregister: () => {}
    } : new FinalizationRegistry((OO => yK?.__wbg_replaymodule_free(OO, 1)));

    function MO(OO) {
      QO === LO.length && LO.push(LO.length + 1);
      const KO = QO;
      return QO = LO[KO], LO[KO] = OO, KO
    }
    let aK = null;

    function oO(OO, KO) {
      return function(OO, KO) {
        dO += KO, dO >= fO && (AO = new TextDecoder("utf-8", {
          ignoreBOM: !0,
          fatal: !0
        }), AO.decode(), dO = KO);
        return AO.decode(VO().subarray(OO, OO + KO))
      }(OO >>> 0, KO)
    }
    let FO = null;

    function VO() {
      return null !== FO && 0 !== FO.byteLength || (FO = new Uint8Array(yK.memory.buffer)), FO
    }
    let LO = new Array(1024).fill(void 0);
    LO.push(void 0, null, !0, !1);
    let QO = LO.length;

    function zK(OO) {
      const KO = function(OO) {
        return LO[OO]
      }(OO);
      return function(OO) {
        OO < 1028 || (LO[OO] = QO, QO = OO)
      }(OO), KO
    }
    let AO = new TextDecoder("utf-8", {
      ignoreBOM: !0,
      fatal: !0
    });
    AO.decode();
    const fO = 2146435072;
    let dO = 0;
    const TO = new TextEncoder;
    "encodeInto" in TO || (TO.encodeInto = function(OO, KO) {
      const pO = TO.encode(OO);
      return KO.set(pO), {
        read: OO.length,
        written: pO.length
      }
    });
    let NO, IO, yK, gK = 0;

    function uO(OO, KO) {
      return IO = OO, yK = OO.exports, NO = KO, aK = null, FO = null, yK.eGv5(), yK
    }

    function EO(OO) {
      if (void 0 !== yK) return yK;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module: OO
      } = OO) : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
      const KO = hO();
      OO instanceof WebAssembly.Module || (OO = new WebAssembly.Module(OO));
      return uO(new WebAssembly.Instance(OO, KO), OO)
    }
    async function jK(OO) {
      if (void 0 !== yK) return yK;
      void 0 !== OO && (Object.getPrototypeOf(OO) === Object.prototype ? ({
        module_or_path: OO
      } = OO) : console.warn("using deprecated parameters for the initialization function; pass a single object instead"));
      const KO = hO();
      ("string" === typeof OO || "function" === typeof Request && OO instanceof Request || "function" === typeof URL && OO instanceof URL) && (OO = fetch(OO));
      const {
        instance: pO,
        module: XO
      } = await async function(OO, KO) {
        if ("function" === typeof Response && OO instanceof Response) {
          if (!OO.ok) throw new Error(`failed to fetch Wasm: ${OO.status} ${OO.statusText} fetching '${OO.url}'`);
          if ("function" === typeof WebAssembly.instantiateStreaming) try {
            return await WebAssembly.instantiateStreaming(OO, KO)
          } catch (pO) {
            if (! function(OO) {
                switch (OO) {
                  case "basic":
                  case "cors":
                  case "default":
                    return !0
                }
                return !1
              }(OO.type) || "application/wasm" === OO.headers.get("Content-Type")) throw pO;
            console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", pO)
          }
          const XO = await OO.arrayBuffer();
          return await WebAssembly.instantiate(XO, KO)
        } {
          const pO = await WebAssembly.instantiate(OO, KO);
          return pO instanceof WebAssembly.Instance ? {
            instance: pO,
            module: OO
          } : pO
        }
      }(await OO, KO);
      return uO(pO, XO)
    }

    function YO() {
      yK = void 0, IO = void 0, aK = null, FO = null, LO = new Array(1024).fill(void 0), LO.push(void 0, null, !0, !1), QO = LO.length
    }
    var wO = pO(2951),
      iK = pO(5747);
    class rK extends Error {
      stage;
      constructor(OO, KO) {
        super((0, wO.v)(OO, KO), {
          cause: KO
        }), this.name = "BloxdReplayWasmError", this.stage = OO
      }
    }
    let PO = null,
      mK = null,
      sO = Promise.resolve(),
      HO = 0,
      RO = null,
      SO = null;

    function JO() {
      if (SO) return Promise.reject(SO);
      if (mK) return mK;
      const OO = HO,
        KO = sO,
        bK = (async () => {
          let bK;
          await KO, PO ??= (0, wO.x)(new pO.U(pO(59378)), (0, iK.e)("bloxd_wasm_replay"));
          try {
            bK = await PO
          } catch (eO) {
            throw PO = null, new rK((0, wO.z)(eO), eO)
          }
          if (OO !== HO) throw new rK("instantiate", new Error("unloaded while loading"));
          try {
            await jK({
              module_or_path: bK
            })
          } catch (eO) {
            throw YO(), new rK("instantiate", eO)
          }
          if (OO !== HO) throw YO(), new rK("instantiate", new Error("unloaded while loading"));
          return RO = CO(), XO
        })();
      return mK = bK, sO = bK.catch((() => {})), bK.catch((() => {
        mK === bK && (mK = null)
      })), bK
    }

    function cK() {
      SO || GO()
    }

    function BO() {
      return RO?.buffer.byteLength ?? 0
    }

    function ZO(OO) {
      return SO || (SO = new rK("call", OO), GO()), SO
    }

    function GO() {
      HO++, YO(), mK = null, RO = null
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);