export const id = 0;
export const ids = [0];
export const modules = {
  39577: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      addBabylonLights: () => QK,
      default: () => fK
    });
    var XO = pO(39580),
      bK = (pO(38038), pO(39254), pO(38587), pO(39592)),
      eO = pO(37880),
      lO = pO(35680),
      vK = pO(35624),
      CO = pO(39604),
      hO = pO(39611),
      DO = pO(35587),
      MO = (pO(39268), pO(39620)),
      aK = pO(39616),
      oO = pO(37097),
      FO = pO(39624),
      VO = pO(37907),
      LO = pO(37080);
    const QO = "gpuParticles",
      zK = LO.s,
      AO = OO => OO / 4,
      fO = OO => `gpuParticleSystem[${OO>>2}].${"xyzw"[3&OO]}`,
      dO = `\nprecision highp float;\nprecision highp int;\nprecision highp usampler2D;\n\n#define MAX_STOPS ${LO.b}\n#define COLOR_POSITIONS ${AO(zK.colorPositions)}\n#define COLOR1 ${AO(zK.color1)}\n#define COLOR2 ${AO(zK.color2)}\n#define VELOCITY ${AO(zK.ul)}\n#define REMAP ${AO(zK.remap)}\n\nuniform mat4 gpuParticleView;\nuniform mat4 gpuParticleProjection;\nuniform vec4 gpuParticleSystem[${LO.o/4}];\n// The records' frame offset and the system's clock; the slot drawn first (the oldest) and the slots in use.\nuniform vec4 gpuParticleFrame;\nuniform vec2 gpuParticleRange;\nuniform usampler2D gpuParticleRecords;\n\nvarying vec2 vUV;\nvarying vec4 vColor;\nvarying vec4 vRemap;\n\nvec3 gravity() { return vec3(${fO(zK.gravity)}, ${fO(zK.gravity+1)}, ${fO(zK.gravity+2)}); }\nint colorCount() { return int(${fO(zK.colorCount)}); }\nvec4 colorDead() { return gpuParticleSystem[${AO(zK.colorDead)}]; }\nint velocityCount() { return int(${fO(zK.velocityCount)}); }\nint remapCount() { return int(${fO(zK.remapCount)}); }\n\nuint hash(uint v) {\n\tuint state = v * 747796405u + 2891336453u;\n\tuint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;\n\treturn (word >> 22u) ^ word;\n}\n\n// The particle's own random pick for a gradient stop, as Babylon picks one when the particle reaches it.\nfloat random(uint seed, int stop) {\n\treturn float(hash(seed ^ (uint(stop) * 0x9e3779b9u)) >> 8u) / 16777216.0;\n}\n\nfloat colourPosition(int i) {\n\treturn gpuParticleSystem[COLOR_POSITIONS + i / 4][i % 4];\n}\n\nvec4 stopColour(int i, uint seed) {\n\treturn mix(gpuParticleSystem[COLOR1 + i], gpuParticleSystem[COLOR2 + i], random(seed, i));\n}\n\nfloat velocityFactor(int i, uint seed) {\n\tvec4 stop = gpuParticleSystem[VELOCITY + i];\n\treturn mix(stop.y, stop.z, random(seed, MAX_STOPS + i));\n}\n\nvec4 colourAt(vec4 colour0, float age, float ratio, uint seed) {\n\tint n = colorCount();\n\tvec4 colour;\n\tif (n == 0) {\n\t\tcolour = mix(colour0, colorDead(), ratio);\n\t} else if (age == 0.0) {\n\t\treturn stopColour(0, seed);\n\t} else if (ratio < colourPosition(0)) {\n\t\tcolour = stopColour(min(1, n - 1), seed);\n\t} else {\n\t\tcolour = stopColour(n - 1, seed);\n\t\tfor (int i = 0; i + 1 < n; i++) {\n\t\t\tfloat a = colourPosition(i);\n\t\t\tfloat b = colourPosition(i + 1);\n\t\t\tif (ratio >= a && ratio <= b) {\n\t\t\t\tfloat scale = b > a ? (ratio - a) / (b - a) : 0.0;\n\t\t\t\tcolour = mix(stopColour(i, seed), stopColour(i + 1, seed), scale);\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t}\n\tcolour.a = max(colour.a, 0.0);\n\treturn colour;\n}\n\nvec3 travel(float alpha, float beta, vec3 d, vec3 g, float s0, float s1) {\n\tfloat ds = s1 - s0;\n\tfloat ds2 = (s1 * s1 - s0 * s0) * 0.5;\n\tfloat ds3 = (s1 * s1 * s1 - s0 * s0 * s0) / 3.0;\n\treturn d * (alpha * ds) + (g * alpha + d * beta) * ds2 + g * (beta * ds3);\n}\n\nvec3 displacement(vec3 d, float age, float life, uint seed) {\n\tvec3 g = gravity();\n\tint n = velocityCount();\n\tif (n == 0) {\n\t\treturn d * age + g * (0.5 * age * age);\n\t}\n\tvec3 total = vec3(0.0);\n\tfloat beforeFirst = min(age, gpuParticleSystem[VELOCITY].x * life);\n\tif (beforeFirst > 0.0) {\n\t\ttotal += travel(velocityFactor(min(1, n - 1), seed), 0.0, d, g, 0.0, beforeFirst);\n\t}\n\tfor (int i = 0; i + 1 < n; i++) {\n\t\tfloat a = gpuParticleSystem[VELOCITY + i].x * life;\n\t\tfloat b = gpuParticleSystem[VELOCITY + i + 1].x * life;\n\t\tfloat lo = max(a, 0.0);\n\t\tfloat hi = min(b, age);\n\t\tif (hi > lo) {\n\t\t\tfloat fa = velocityFactor(i, seed);\n\t\t\tfloat beta = (velocityFactor(i + 1, seed) - fa) / (b - a);\n\t\t\ttotal += travel(fa - beta * a, beta, d, g, lo, hi);\n\t\t}\n\t}\n\tfloat afterLast = max(gpuParticleSystem[VELOCITY + n - 1].x * life, 0.0);\n\tif (age > afterLast) {\n\t\ttotal += travel(velocityFactor(n - 1, seed), 0.0, d, g, afterLast, age);\n\t}\n\treturn total;\n}\n\nvec4 remapAt(float age, float ratio) {\n\tint n = remapCount();\n\tif (n == 0 || age == 0.0) {\n\t\treturn vec4(0.0, 1.0, 0.0, 1.0);\n\t}\n\tvec2 stop = gpuParticleSystem[REMAP + n - 1].yz;\n\tif (ratio < gpuParticleSystem[REMAP].x) {\n\t\tstop = gpuParticleSystem[REMAP].yz;\n\t} else {\n\t\tfor (int i = 0; i + 1 < n; i++) {\n\t\t\tvec4 a = gpuParticleSystem[REMAP + i];\n\t\t\tvec4 b = gpuParticleSystem[REMAP + i + 1];\n\t\t\tif (ratio >= a.x && ratio <= b.x) {\n\t\t\t\tstop = mix(a.yz, b.yz, b.x > a.x ? (ratio - a.x) / (b.x - a.x) : 0.0);\n\t\t\t\tbreak;\n\t\t\t}\n\t\t}\n\t}\n\treturn vec4(stop.x, stop.y - stop.x, 0.0, 1.0);\n}\n\nvoid main(void) {\n\tint slot = (int(gpuParticleRange.x) + gl_InstanceID) % int(gpuParticleRange.y);\n\tint perRow = textureSize(gpuParticleRecords, 0).x / 4;\n\tivec2 at = ivec2((slot % perRow) * 4, slot / perRow);\n\tvec4 spawn = uintBitsToFloat(texelFetch(gpuParticleRecords, at, 0));\n\tvec4 velocity = uintBitsToFloat(texelFetch(gpuParticleRecords, at + ivec2(1, 0), 0));\n\tuvec4 sizeSeed = texelFetch(gpuParticleRecords, at + ivec2(2, 0), 0);\n\tvec4 colour0 = uintBitsToFloat(texelFetch(gpuParticleRecords, at + ivec2(3, 0), 0));\n\tfloat age = gpuParticleFrame.w - spawn.w;\n\tfloat life = velocity.w;\n\t// The strip's corners: (0, 0), (1, 0), (0, 1), (1, 1).\n\tvec2 corner = vec2(float(gl_VertexID & 1), float(gl_VertexID >> 1));\n\tvUV = corner;\n\tif (!(age >= 0.0 && age < life)) {\n\t\t// Dead, or not yet written: outside the clip volume.\n\t\tgl_Position = vec4(0.0, 0.0, 2.0, 1.0);\n\t\tvColor = vec4(0.0);\n\t\tvRemap = vec4(0.0, 1.0, 0.0, 1.0);\n\t\treturn;\n\t}\n\tfloat ratio = age / life;\n\tuint seed = sizeSeed.y;\n\tvec3 centre = gpuParticleFrame.xyz + spawn.xyz + displacement(velocity.xyz, age, life, seed);\n\t// particles.vertex's billboard: the corner offset in view space.\n\tvec3 viewPos = (gpuParticleView * vec4(centre, 1.0)).xyz + vec3((corner - 0.5) * uintBitsToFloat(sizeSeed.x), 0.0);\n\tgl_Position = gpuParticleProjection * vec4(viewPos, 1.0);\n\tvColor = colourAt(colour0, age, ratio, seed);\n\tvRemap = remapAt(age, ratio);\n}\n`;
    VO.b.ShadersStore[`${QO}VertexShader`] = dO, VO.b.ShadersStore[`${QO}PixelShader`] = "\nprecision highp float;\n\nuniform sampler2D gpuParticleTexture;\nuniform sampler2D gpuParticleRampTexture;\nuniform float gpuParticleRamp;\n\nvarying vec2 vUV;\nvarying vec4 vColor;\nvarying vec4 vRemap;\n\nvoid main(void) {\n\tvec4 textureColour = texture2D(gpuParticleTexture, vUV);\n\tvec4 colour = textureColour * vColor;\n\tif (gpuParticleRamp != 0.0) {\n\t\tfloat alpha = colour.a;\n\t\tfloat index = clamp((alpha - vRemap.x) / vRemap.y, 0.0, 1.0);\n\t\tvec4 rampColour = texture2D(gpuParticleRampTexture, vec2(1.0 - index, 0.0));\n\t\tcolour = vec4(colour.rgb * rampColour.rgb, clamp((alpha * rampColour.a - vRemap.z) / vRemap.w, 0.0, 1.0));\n\t}\n#ifdef MULTIPLY_PASS\n\t// The MULTIPLY pass of BLENDMULTIPLYMODE, which MULTIPLYADD draws before its ADD pass.\n\tfloat sourceAlpha = vColor.a * textureColour.a;\n\tcolour.rgb = colour.rgb * sourceAlpha + vec3(1.0 - sourceAlpha);\n#endif\n\tgl_FragColor = colour;\n}\n";
    const TO = ["gpuParticleView", "gpuParticleProjection", "gpuParticleSystem", "gpuParticleFrame", "gpuParticleRange", "gpuParticleRamp"],
      NO = ["gpuParticleTexture", "gpuParticleRampTexture", "gpuParticleRecords"];
    var IO = pO(37077),
      yK = pO(39631);
    class gK extends IO.d {
      constructor(OO, KO, pO, XO) {
        super(OO, KO, pO), this.renderer = pO, this.Ce = XO, this.id = void 0, this.renderingGroupId = 0, this.layerMask = 268435455, this.records = void 0, this.perRow = void 0, this.uniforms = new Float32Array(LO.o), this.uniformBits = new Uint32Array(this.uniforms.buffer), this.ramp = null, this.rampTexels = (0, yK.e)(), this.engine = void 0, this.animatedFrame = -1, this.uploadSlots = (OO, KO) => {
          const {
            engine: pO,
            perRow: XO
          } = this, bK = pO._gl;
          pO._bindTextureDirectly(bK.TEXTURE_2D, this.records, !0), pO._unpackFlipY(!1);
          const eO = this.ring.recordBits;
          for (let lO = OO; lO < KO;) {
            const OO = Math.floor(lO / XO),
              pO = Math.min(KO, (OO + 1) * XO);
            bK.texSubImage2D(bK.TEXTURE_2D, 0, lO % XO * 4, OO, 4 * (pO - lO), 1, bK.RGBA_INTEGER, bK.UNSIGNED_INT, eO, lO * LO.e), lO = pO
          }
          pO._bindTextureDirectly(bK.TEXTURE_2D, null)
        }, this.id = OO;
        const bK = XO.qb();
        this.engine = bK;
        const eO = Math.max(1, KO);
        this.perRow = Math.min(eO, 256), this.records = bK.createRawTexture(null, 4 * this.perRow, Math.ceil(eO / this.perRow), MO.b.TEXTUREFORMAT_RGBA_INTEGER, !1, !1, MO.b.TEXTURE_NEAREST_SAMPLINGMODE, null, MO.b.TEXTURETYPE_UNSIGNED_INTEGER)
      }
      animate() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.Ce.getAnimationRatio() || 1;
        const KO = this.Ce.getFrameId();
        if (KO === this.animatedFrame) return !1;
        const pO = super.animate(OO);
        return pO && (this.animatedFrame = KO, this.ring.takeUploads(this.uploadSlots)), pO
      }
      render() {
        return this.renderer.render(this)
      }
      rebuild() {}
      clone() {
        return null
      }
      prepareDraw(OO) {
        (0, yK.f)(this, this.uniforms, this.uniformBits, OO);
        for (const pO of LO.r) this.uniforms[pO] = this.uniformBits[pO];
        var KO;
        (0, yK.j)(this, this.rampTexels) && (0 === this.rampTexels.key.length ? (null === (KO = this.ramp) || void 0 === KO || KO.dispose(), this.ramp = null) : this.ramp ? this.ramp.update(this.rampTexels.texels) : this.ramp = aK.e.CreateRGBATexture(this.rampTexels.texels, LO.l, 1, this.Ce, !1, !1, MO.b.TEXTURE_NEAREST_SAMPLINGMODE))
      }
      releaseGl() {
        var OO;
        this.records.dispose(), null === (OO = this.ramp) || void 0 === OO || OO.dispose(), this.ramp = null
      }
    }
    class uO {
      constructor(OO) {
        this.Ce = OO, this.failed = !1, this.engine = void 0, this.effect = void 0, this.multiplyEffect = void 0, this.whiteRamp = void 0, this.vertexBuffers = {}, this.frame = new Float32Array(4), this.warnOnce = (0, FO.d)(), this.engine = OO.qb(), this.effect = this.createEffect(""), this.multiplyEffect = this.createEffect("#define MULTIPLY_PASS"), this.whiteRamp = aK.e.CreateRGBATexture(new Uint8Array([255, 255, 255, 255]), 1, 1, OO, !1, !1, MO.b.TEXTURE_NEAREST_SAMPLINGMODE), this.awaitLink(this.effect), this.awaitLink(this.multiplyEffect)
      }
      XpO(OO, KO) {
        const pO = 256 * this.engine.getCaps().maxTextureSize;
        KO > pO && this.warnOnce(`capacity:${OO}`, `particle system ${OO} holds ${pO} particles, not ${KO}: its records texture's limit`);
        const XO = new gK(OO, Math.min(KO, pO), this, this.Ce);
        return this.Ce.addParticleSystem(XO), XO
      }
      canDraw(OO) {
        var KO, pO;
        if (this.failed || null === (KO = OO.texture) || void 0 === KO || null === (pO = KO.mirror) || void 0 === pO || !pO.isReady()) return !1;
        for (const XO of (0, oO.k)(OO.blendMode))
          if (!this.effectFor(XO).isReady()) return !1;
        return !0
      }
      disposeStopped(OO) {
        this.Ce._toBeDisposed.push(OO)
      }
      remove(OO) {
        this.Ce.removeParticleSystem(OO), OO.releaseGl()
      }
      render(OO) {
        var KO;
        if (!OO.isReady() || !OO.hasLiveParticles()) return 0;
        const {
          engine: pO,
          Ce: XO,
          frame: bK
        } = this;
        OO.prepareDraw(this.warnOnce), OO.drawOffset(bK, 0), bK[3] = OO.drawTime();
        const eO = OO.ring.drawStart(),
          lO = OO.ring.drawCount(),
          vK = null !== (KO = OO.ramp) && void 0 !== KO ? KO : this.whiteRamp;
        pO.setState(!1);
        for (const CO of (0, oO.k)(OO.blendMode)) {
          const KO = this.effectFor(CO);
          pO.enableEffect(KO), KO.setTexture("gpuParticleTexture", OO.texture.mirror), KO.setTexture("gpuParticleRampTexture", vK), KO._bindTexture("gpuParticleRecords", OO.records), KO.setMatrix("gpuParticleView", XO.getViewMatrix()), KO.setMatrix("gpuParticleProjection", XO.getProjectionMatrix()), KO.setFloatArray4("gpuParticleSystem", OO.uniforms), KO.setFloat4("gpuParticleFrame", bK[0], bK[1], bK[2], bK[3]), KO.setFloat2("gpuParticleRange", eO, lO), KO.setFloat("gpuParticleRamp", OO.uniforms[LO.s.ramp]), pO.bindBuffers(this.vertexBuffers, null, KO), pO.setAlphaMode((0, oO.j)(CO)), pO.drawArraysType(MO.b.MATERIAL_TriangleStripDrawMode, 0, 4, lO), KO._bindTexture("gpuParticleRecords", null)
        }
        return pO.setAlphaMode(MO.b.ALPHA_DISABLE), lO
      }
      awaitLink(OO) {
        const KO = OO.getPipelineContext(),
          pO = this.engine._gl;
        !this.failed && pO && (!KO || KO.isParallelCompiled && !KO.program ? this.warnOnce("asyncProgram", "GPU particles: Babylon made a particle program asynchronously, so a failed link shows only after the first systems are made") : KO.isParallelCompiled && KO.program && (pO.getProgramParameter(KO.program, pO.LINK_STATUS) || this.fail(pO.getProgramInfoLog(KO.program) || "a program did not link")))
      }
      effectFor(OO) {
        return OO === oO.d ? this.multiplyEffect : this.effect
      }
      createEffect(OO) {
        return this.engine.createEffect(QO, [], TO, NO, OO, void 0, void 0, ((OO, KO) => {
          this.fail(KO)
        }))
      }
      fail(OO) {
        if (!this.failed) {
          this.failed = !0, console.warn(`GPU particles cannot compile here, so new particle systems are Babylon's: ${OO}`);
          for (const OO of this.Ce.ku.slice()) OO instanceof gK && OO.disposeOnStop && OO.dispose()
        }
      }
    }
    var EO = pO(38284),
      jK = pO(39251),
      YO = pO(38011),
      wO = pO(38243),
      iK = pO(38235),
      rK = pO(38162),
      PO = pO(39314),
      mK = pO(35936),
      sO = pO(39640),
      HO = pO(39643),
      RO = pO(39651),
      SO = pO(38186),
      JO = pO(35819),
      cK = pO(35816),
      BO = pO(38404),
      ZO = pO(35895),
      GO = pO(35836);

    function qK(OO) {
      if (OO.visibility < 1 || !OO.isVisible || !OO.isEnabled() || OO.metadata[GO.g] || !OO.isReady()) return !0;
      const KO = OO.au;
      if (!KO || 0 === KO.length) return !0;
      for (let pO = 0; pO < KO.length; pO++) {
        const XO = KO[pO],
          bK = XO.UX();
        if (!bK || !bK.isReadyForSubMesh(OO, XO, !1)) return !0
      }
      return !1
    }
    class xK {
      constructor(OO, KO) {
        this.ap = OO, this.culled = 0, this.armed = !1, this.vis = null, this.eye = [0, 0, 0], this.passable = new Set, this.meshes = [], this.cellSlots = new Int32Array(256), this.count = 0, KO.onBeforeActiveMeshesEvaluationObservable.add((() => {
          this.armed = !0
        }))
      }
      Ip(OO) {
        var KO;
        const pO = this.armed;
        if (this.armed = !1, this.vis = null, !pO) return !1;
        this.culled = 0;
        const {
          ap: XO
        } = this, bK = null === (KO = XO.EQ) || void 0 === KO ? void 0 : KO.visibility;
        if (!bK || !OO || XO.Lb.Qb) return !1;
        if (!(XO.lK.KDO[0] >= ZO.f)) return !1;
        const eO = OO.getProjectionMatrix().m;
        if (0 !== eO[15]) return !1;
        const lO = XO.jp,
          vK = OO.globalPosition,
          CO = this.eye;
        return CO[0] = vK.x + lO[0], CO[1] = vK.y + lO[1], CO[2] = vK.z + lO[2], !!bK.eyeClear(CO[0], CO[1], CO[2], OO.minZ, eO, XO.lK) && (this.vis = bK, this.passable.clear(), this.count = 0, !0)
      }
      see(OO, KO) {
        const pO = this.count++;
        if (pO === this.cellSlots.length) {
          const OO = new Int32Array(2 * pO);
          OO.set(this.cellSlots), this.cellSlots = OO
        }
        this.cellSlots[pO] = KO, this.meshes[pO] = OO
      }
      seeThrough(OO) {
        this.passable.add(OO)
      }
      finish(OO, KO) {
        const {
          vis: pO,
          eye: XO,
          meshes: bK,
          count: eO,
          cellSlots: lO
        } = this, {
          lK: vK
        } = this.ap, [CO, hO] = vK.KDO, DO = null !== pO && pO.update(XO[0], XO[1], XO[2], vK.ovO, CO, hO, this.passable);
        let MO = 0;
        for (let aK = 0; aK < eO; aK++) {
          const XO = bK[aK];
          if (DO) {
            const OO = 3 * lO[aK];
            if (OO >= 0 && !pO.isDrawn(KO[OO], KO[OO + 1], KO[OO + 2])) {
              MO++;
              continue
            }
          }
          SO.e.prototype.push.call(OO, XO)
        }
        bK.fill(null, 0, eO), this.count = 0, this.vis = null, this.culled = MO
      }
    }
    var nO = pO(35875),
      WO = pO(35826),
      tK = pO(38382),
      kK = pO(39660),
      UO = pO(38388),
      OK = pO(38301);
    let KK = 1;
    const pK = new WeakSet;

    function XK() {
      return KK
    }

    function bp() {
      KK = KK >= 1073741823 ? 1 : KK + 1
    }

    function eK(OO) {
      const KO = OO.metadata;
      if (!KO || !0 !== KO[cK.n]) return;
      const pO = KO[cK.r],
        XO = null === pO || void 0 === pO ? void 0 : pO._noaStamps;
      if (!pO || !XO) return;
      const bK = pO.entries.indexOf(OO);
      bK >= 0 && (XO[bK] = 0)
    }

    function lK(OO) {
      const KO = OO.au;
      for (let pO = 0; pO < KO.length; pO++) {
        const OO = KO[pO].UX();
        if (OO && !OO.isFrozen) return !1
      }
      for (let pO = 0; pO < KO.length; pO++) {
        const OO = KO[pO].UX();
        OO && pK.add(OO)
      }
      return !0
    }
    let vp = !1;
    const CK = new WeakSet;

    function hK(OO, KO) {
      const pO = OO[KO];
      if ("function" !== typeof pO) throw new Error(`terrainDrawState: Babylon has no ${KO} to hook`);
      return pO
    }

    function DK(OO, KO, pO, XO, bK) {
      const eO = pO.lK.ovO,
        lO = new Map;
      let vK = 0;
      const CO = new xK(pO, OO),
        hO = new nO.e(eO, OO.qb());
      ! function(OO) {
        if (CK.has(OO) || (CK.add(OO), OO.onContextLostObservable.add(bp), OO.onContextRestoredObservable.add(bp)), vp) return;
        vp = !0;
        const KO = kK.c.prototype,
          pO = hK(KO, "_markSubMeshesAsDirty");
        Object.assign(KO, {
          _markSubMeshesAsDirty(OO) {
            pO.call(this, OO), eK(this)
          }
        });
        const XO = hK(OK.c.prototype, "_syncParentEnabledState");
        Object.assign(OK.c.prototype, {
          _syncParentEnabledState() {
            XO.call(this), eK(this)
          }
        });
        const bK = hK(UO.b.prototype, "resetDrawCache");
        UO.b.prototype.resetDrawCache = function(OO, KO) {
          bK.call(this, OO, KO), eK(this.getMesh())
        };
        const eO = tK.b.prototype,
          lO = hK(eO, "markDirty");
        eO.markDirty = function(OO) {
          lO.call(this, OO), pK.has(this) && bp()
        };
        const vK = hK(eO, "_markAllSubMeshesAsDirty");
        Object.assign(eO, {
          _markAllSubMeshesAsDirty(OO) {
            vK.call(this, OO), pK.has(this) && bp()
          }
        })
      }(OO.qb());
      let DO = new Float64Array(384),
        MO = new Int32Array(64),
        aK = new Uint8Array(64),
        oO = new Float64Array(64),
        FO = new Int32Array(192),
        VO = 0;
      const LO = [],
        QO = new Float64Array(24),
        zK = () => {
          const OO = LO.pop();
          return void 0 !== OO ? (MO[OO] = 0, OO) : (VO === MO.length && (DO = MK(DO, new Float64Array(2 * DO.length)), MO = MK(MO, new Int32Array(2 * MO.length)), aK = MK(aK, new Uint8Array(2 * aK.length)), oO = MK(oO, new Float64Array(2 * oO.length)), FO = MK(FO, new Int32Array(2 * FO.length))), VO++)
        },
        AO = OO => {
          const KO = 6 * OO._noaSlot,
            pO = OO.CDO[0],
            XO = OO.CDO[1];
          DO[KO] = pO.x, DO[KO + 1] = pO.y, DO[KO + 2] = pO.z, DO[KO + 3] = XO.x, DO[KO + 4] = XO.y, DO[KO + 5] = XO.z
        },
        fO = (OO, KO, pO) => {
          if (!pO) return CO.see(OO, -1), !1;
          const XO = qK(OO);
          return XO && CO.seeThrough(oO[KO]), CO.see(OO, KO), !XO
        };
      let dO = -1;
      return OO.getActiveMeshCandidates = () => {
        const pO = OO.frustumPlanes,
          XO = KO._selectionContent;
        XO.reset(), (pO => {
          const XO = OO.frustumPlanes;
          vK = vK + 1 | 0 || 1;
          const bK = KO.blocks,
            eO = CO.Ip(OO.activeCamera),
            lO = eO && !0;
          if (lO) {
            const KO = OO.qb().currentRenderPassId;
            KO !== dO && (dO = KO, bp())
          }
          const hO = XK(),
            oO = lO && !1;
          bK.length > 0 && function(OO, KO) {
            for (let pO = 0; pO < 6; pO++) {
              const XO = OO[pO],
                bK = XO.normal;
              KO[4 * pO] = bK.x, KO[4 * pO + 1] = bK.y, KO[4 * pO + 2] = bK.z, KO[4 * pO + 3] = XO.d
            }
          }(XO, QO);
          const VO = DO,
            LO = MO,
            zK = aK;
          for (let OO = 0; OO < bK.length; OO++) {
            const KO = bK[OO];
            if (!BO.c.IsInFrustum(KO.CDO, XO)) continue;
            const DO = KO.entries;
            {
              const OO = KO._noaSlots,
                XO = KO._noaStamps,
                bK = KO._noaTerrain;
              for (let KO = 0; KO < DO.length; KO++) {
                const MO = OO[KO];
                if (LO[MO] !== vK && (LO[MO] = vK, zK[MO] = ap(VO, 6 * MO, QO) ? 1 : 0), 0 === zK[MO]) continue;
                const aK = DO[KO];
                if (lO && XO[KO] === hO) oO && 1 === bK[KO] && qK(aK) && 0, CO.see(aK, 1 === bK[KO] ? MO : -1);
                else if (lO) {
                  XO[KO] = hO;
                  const OO = !0 === aK.metadata[WO.j];
                  bK[KO] = OO ? 1 : 0;
                  const pO = fO(aK, MO, OO);
                  !OO || pO && lK(aK) || (XO[KO] = 0)
                } else eO ? fO(aK, MO, !0 === aK.metadata[WO.j]) : SO.e.prototype.push.call(pO, aK)
              }
              continue
            }
          }
          eO && CO.finish(pO, FO)
        })(XO), hO.apply(XO, OO.activeCamera);
        const eO = KO.vMO;
        for (let OO = 0; OO < eO.length; OO++) {
          const KO = eO[OO];
          KO.isEnabled() && SO.e.prototype.push.call(XO, KO)
        }
        return bK(XO, pO), XO
      }, {
        hDO: () => CO.culled,
        GhO: (OO, KO) => {
          const bK = Math.floor(KO[0] / eO),
            vK = Math.floor(KO[1] / eO),
            CO = Math.floor(KO[2] / eO),
            hO = `${bK}|${vK}|${CO}`;
          let DO = lO.get(hO);
          if (!DO) {
            const OO = [0, 0, 0];
            pO.bhO([bK * eO - 1, vK * eO - 1, CO * eO - 1], null, OO), DO = Object.assign(XO(OO, eO + 2), {
              DDO: hO,
              MDO: 0,
              _selectionId: 0,
              _inFrustum: !1,
              _noaSlot: zK()
            }), AO(DO), oO[DO._noaSlot] = (0, JO.g)(bK, vK, CO), FO[3 * DO._noaSlot] = bK, FO[3 * DO._noaSlot + 1] = vK, FO[3 * DO._noaSlot + 2] = CO, lO.set(hO, DO)
          }
          DO.MDO++, OO.metadata[cK.u] = DO
        },
        nKO: OO => {
          const KO = OO.metadata[cK.u];
          KO && (KO.MDO--, KO.MDO <= 0 && (lO.delete(KO.DDO), LO.push(KO._noaSlot)), OO.metadata[cK.u] = null)
        },
        lDO: (OO, KO) => {
          const pO = OO,
            XO = KO.metadata[cK.u];
          (pO._noaSlots ??= []).push(XO._noaSlot), (pO._noaStamps ??= []).push(0), (pO._noaTerrain ??= []).push(0), pO.entries.push(KO)
        },
        removeEntry: (OO, KO) => {
          const pO = OO,
            XO = pO.entries,
            bK = XO.indexOf(KO);
          if (bK < 0) return;
          const eO = pO._noaSlots,
            lO = pO._noaStamps,
            vK = pO._noaTerrain,
            CO = XO.length - 1;
          XO[bK] = XO[CO], eO[bK] = eO[CO], lO[bK] = lO[CO], vK[bK] = vK[CO], XO.pop(), eO.pop(), lO.pop(), vK.pop()
        },
        ivO: OO => {
          for (const KO of lO.values()) {
            KO.kDO.oDO(OO), KO.tDO.oDO(OO);
            for (const pO of KO.CDO) pO.oDO(OO);
            AO(KO)
          }
        }
      }
    }

    function MK(OO, KO) {
      return KO.set(OO), KO
    }

    function ap(OO, KO, pO) {
      const XO = OO[KO],
        bK = OO[KO + 1],
        eO = OO[KO + 2],
        lO = OO[KO + 3],
        vK = OO[KO + 4],
        CO = OO[KO + 5];
      for (let hO = 0; hO < 24; hO += 4) {
        const OO = pO[hO],
          KO = pO[hO + 1],
          DO = pO[hO + 2];
        if (!(OO * (OO >= 0 ? lO : XO) + KO * (KO >= 0 ? vK : bK) + DO * (DO >= 0 ? CO : eO) + pO[hO + 3] >= 0)) return !1
      }
      return !0
    }
    var oK = pO(36153);
    class FK {
      constructor(OO, KO) {
        var pO = OO.Ce;
        pO.cDO(new RO.e(pO));
        var XO = new sO.e(CO);
        pO.VDO = XO, XO.blocks = [];
        var bK, eO = {},
          lO = [];
        this.textPlanes = lO, this.hDO = () => bK.hDO(), this.ivO = OO => {
          DO(XO, OO), bK.ivO(OO)
        }, this.GhO = (KO, pO, vK) => {
          if (!KO.metadata) throw new Error("Mesh should have mesh.metadata property");
          if (!KO.metadata[cK.r] && !KO.metadata[cK.j]) {
            if (!pO) {
              var CO = XO.vMO;
              if (KO.metadata[cK.B] && !KO.parent) {
                CO = lO;
                var DO = KO.hpO().QDO;
                KO.metadata[cK.E] = DO.center.length() + DO.radius, KO.xb = !0
              }
              return CO.push(KO), KO.metadata[cK.f] = CO, void(KO.metadata[cK.j] = !0)
            }
            var aK = Math.floor(vK[0] / hO),
              oO = Math.floor(vK[1] / hO),
              FO = Math.floor(vK[2] / hO),
              VO = aK + "|" + oO + "|" + FO,
              LO = eO[VO];
            if (!LO) {
              var QO = [aK * hO, oO * hO, FO * hO],
                zK = [0, 0, 0];
              OO.ap.bhO(QO, null, zK), LO = MO(zK, hO), XO.blocks.push(LO), eO[VO] = LO, LO.DDO = VO
            }
            bK.GhO(KO, vK), bK.lDO(LO, KO), LO.MDO = (LO.MDO || 0) + 1, KO.metadata[cK.r] = LO, KO.metadata[cK.n] = !0, KO.xb = !0
          }
        }, this.nKO = OO => {
          if (OO.metadata) {
            OO.metadata[cK.j] && ((0, JO.m)(OO.metadata[cK.f], OO), OO.metadata[cK.j] = !1), OO.metadata[cK.f] === lO && (OO.xb = !1), OO.metadata[cK.f] = void 0, OO.metadata[cK.E] = void 0;
            var KO = OO.metadata[cK.r];
            KO && KO.entries && (OO.metadata[cK.n] && bK.removeEntry(KO, OO), KO.MDO--, KO.MDO <= 0 && (delete eO[KO.DDO], (0, JO.m)(XO.blocks, KO))), bK.nKO(OO), OO.metadata[cK.r] = null, OO.metadata[cK.n] = !1
          }
        }, this.MlO = function(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (OO.metadata[cK.r]) {
            if (OO.metadata[cK.n] === KO) return;
            var pO = OO.metadata[cK.r];
            pO && pO.entries && (KO ? bK.lDO(pO, OO) : bK.removeEntry(pO, OO)), OO.metadata[cK.n] = KO
          } else {
            if (OO.metadata[cK.j] === KO) return;
            var eO = OO.metadata[cK.f] || XO.vMO;
            KO ? eO.push(OO) : (0, JO.m)(eO, OO), OO.metadata[cK.j] = KO
          }
        };
        var CO = () => {},
          hO = KO * OO.ap.lK.ovO,
          DO = (OO, KO) => {
            OO.blocks.forEach((OO => {
              OO.kDO.oDO(KO), OO.tDO.oDO(KO), OO.CDO.forEach((OO => OO.oDO(KO))), OO.blocks && DO(OO, KO)
            }))
          },
          MO = (OO, KO) => {
            var pO = new vK.WX(OO[0], OO[1], OO[2]),
              XO = new vK.WX(OO[0] + KO, OO[1] + KO, OO[2] + KO);
            return new HO.c(pO, XO, void 0, void 0, void 0, CO)
          };
        bK = DK(pO, XO, OO.ap, MO, ((OO, KO) => {
          for (var pO = 0; pO < lO.length; pO++) {
            var XO = lO[pO];
            XO.isEnabled(!1) && ((0, oK.e)(XO, KO) && SO.e.prototype.push.call(OO, XO))
          }
        }))
      }
    }

    function VK(OO) {
      const {
        holderPosition: KO,
        holderRotation: pO,
        BbO: XO,
        fov: bK,
        near: eO,
        far: lO
      } = OO.model.ceO, vK = OO.IDO;
      vK.position.rvO(KO[0], KO[1], KO[2]), vK.rotation.rvO(pO[0], pO[1], pO[2]);
      const CO = OO.camera;
      CO.position.rvO(XO[0], XO[1], XO[2]), CO.fov = bK, CO.minZ = eO, CO.maxZ = lO
    }

    function LK(OO) {
      const KO = OO.qb(),
        pO = KO,
        XO = pO._gl;
      if (!XO || pO.ye < 2 || KO.BhO || XO.getParameter(XO.DEPTH_BITS) < 24) return !1;
      const bK = OO._renderingManager,
        eO = bK.getRenderingGroup(-1),
        lO = bK.getRenderingGroup(0),
        vK = wO.d.prototype.render;
      return eO.render = function(OO, KO, pO, XO, bK, eO, CO, hO, DO) {
        (OO || lO._empty) && vK.call(this, OO, KO, pO, XO, bK, eO, CO, hO, DO)
      }, lO.render = function(OO, pO, bK, lO) {
        let CO = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
          hO = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5],
          DO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
          aK = !(arguments.length > 7 && void 0 !== arguments[7]) || arguments[7],
          oO = arguments.length > 8 ? arguments[8] : void 0;
        OO ? vK.call(this, OO, pO, bK, lO, CO, hO, DO, aK, oO) : (KO.setAlphaMode(MO.b.ALPHA_DISABLE), vK.call(this, null, !1, !1, lO, CO, hO, DO, !1), eO._empty || (XO.depthRange(1, 1), vK.call(eO, null, pO, bK, lO, CO, hO, DO, aK, oO), XO.depthRange(0, 1)), vK.call(this, null, pO, bK, lO, !1, !1, !1, aK, oO))
      }, !0
    }

    function QK(OO, KO) {
      return [KO, mK.h].map(((KO, pO) => {
        const XO = new bK.d("light", vK.WX.FromArray(KO), OO);
        return XO.diffuse = lO.Color3.FromArray([1, 1, 1]), XO.specular = lO.Color3.FromArray([1, 1, 1]), XO.intensity = mK.e[pO], XO
      }))
    }
    class zp extends hO.c {
      constructor() {
        super(...arguments), this.heldTexture = null
      }
      get texture() {
        return this.heldTexture
      }
      set texture(OO) {
        var KO;
        this.heldTexture = OO, this.particleTexture = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.mirror) && void 0 !== KO ? KO : null
      }
      isEmitting() {
        return this.isStarted() && !this._stopped
      }
      dispose() {
        let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
          KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        OO && (this.particleTexture = null, (0, DO.C)(this.heldTexture), this.heldTexture = null), super.dispose(OO, KO, pO)
      }
    }
    const AK = XO.b.Zero();
    const fK = {
      jMO: function(OO, KO) {
        return new eO.d(OO, KO.ohO, {
          preserveDrawingBuffer: KO.preserveDrawingBuffer,
          powerPreference: "high-performance",
          alpha: !1,
          stencil: !1
        })
      },
      uDO: function(OO, KO) {
        ! function(OO, KO, pO) {
          const XO = new rK.d(OO.engine);
          OO.Ce = XO, XO.detachControl(), XO.autoClear = !1, iK.b.MIN_RENDERINGGROUPS = -1;
          for (let eO = iK.b.MIN_RENDERINGGROUPS; eO <= 1; eO++) XO.setRenderingOrder(eO, wO.d.PainterSortCompare, wO.d.PainterSortCompare, wO.d.PainterSortCompare);
          XO.setRenderingAutoClearDepthStencil(0, !1), YO.c.Enabled = !1, OO.dDO = new FK(OO, Math.round(KO.TDO)), OO.IDO = new jK.c("camHolder", XO), OO.camera = new EO.b("camera", new vK.WX(0, 0, 0), XO), OO.camera.parent = OO.IDO, VK(OO), (0, mK.j)(OO, ((OO, KO, pO) => (0, PO.g)(KO, pO, OO.Ce))), XO.clearColor = lO.c.FromArray(KO.clearColor), XO.ambientColor = lO.Color3.FromArray(KO.ambientColor);
          const bK = pO(XO, KO.gMO);
          XO.onNewLightAddedObservable.add((OO => {
            bK.some((KO => KO === OO)) || console.error(`Light "${OO.name}" was added to the scene after startup; terrain, block models and Lite will ignore it. Add it in addNoaLights (renderingCamera.ts) and addBabylonLights (babylonBackend.ts).`)
          })), XO.skipPointerMovePicking = !0
        }(OO, KO, QK), LK(OO.Ce)
      },
      NDO: VK,
      setBabylonFog: function(OO, KO, pO, XO) {
        const bK = OO.Ce;
        bK.fogMode = 3, bK.fogStart = KO, bK.fogEnd = pO, bK.fogColor.set(XO[0], XO[1], XO[2])
      },
      YDO: function(OO, KO, pO) {
        return OO.engine.ye >= 2 && (OO.wDO || (OO.wDO = new uO(OO.Ce)), !OO.wDO.failed) ? OO.wDO.XpO(KO, pO) : new zp(KO, pO, OO.Ce)
      },
      rMO: function(OO, KO) {
        OO.Ce.ku.forEach((pO => {
          if (pO instanceof gK) return void pO.ivO(KO, OO.ap.jp);
          const XO = pO;
          if (XO.emitter.getConnectedParticleSystems)
            for (const OO of XO._particles) OO.position.set(OO.position.x - KO[0], OO.position.y - KO[1], OO.position.z - KO[2]);
          else {
            if (!XO.worldOffset) throw new Error("Particle system has no world offset");
            XO.worldOffset.x = -OO.ap.jp[0], XO.worldOffset.y = -OO.ap.jp[1], XO.worldOffset.z = -OO.ap.jp[2]
          }
        }))
      },
      linesFromArrays: function(OO, KO, pO) {
        const XO = new CO.e(KO, OO.Ce, null, void 0, void 0, !1);
        return (0, PO.e)(KO, pO, OO.Ce, XO), XO
      },
      he: eK,
      iMO: function(OO, KO) {
        return AK.origin.NhO(KO.origin), AK.direction.NhO(KO.direction), AK.length = KO.length, AK.epsilon = KO.epsilon, AK.iMO(OO, !1, void 0, !1, void 0, !0).pickedPoint
      }
    }
  },
  39631: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => LO,
      e: () => vK,
      f: () => lO,
      j: () => hO
    });
    var XO = pO(35680),
      bK = pO(37085),
      eO = pO(37080);

    function lO(OO, KO, pO, XO) {
      const bK = eO.s;
      KO.fill(0), OO.gravity.toArray(KO, bK.gravity), OO.colorDead.toArray(KO, bK.colorDead), pO[bK.ramp] = OO.useRampGradients ? 1 : 0;
      const lO = OO.getColorGradients(),
        vK = aK(OO, lO, "colour", XO);
      pO[bK.colorCount] = vK;
      for (let eO = 0; eO < vK; eO++) {
        var CO;
        const OO = lO[oO(lO, eO)];
        KO[bK.colorPositions + eO] = OO.gradient, OO.color1.toArray(KO, bK.color1 + 4 * eO), (null !== (CO = OO.color2) && void 0 !== CO ? CO : OO.color1).toArray(KO, bK.color2 + 4 * eO)
      }
      const hO = OO.getVelocityGradients(),
        DO = aK(OO, hO, "ul", XO);
      pO[bK.velocityCount] = DO;
      for (let eO = 0; eO < DO; eO++) zK(KO, bK.ul + 4 * eO, hO[oO(hO, eO)]);
      const MO = OO.useRampGradients ? OO.getColorRemapGradients() : null,
        FO = aK(OO, MO, "colour remap", XO);
      pO[bK.remapCount] = FO;
      for (let eO = 0; eO < FO; eO++) zK(KO, bK.remap + 4 * eO, MO[oO(MO, eO)])
    }

    function vK() {
      return {
        key: [],
        texels: new Uint8Array(4 * eO.l)
      }
    }
    const CO = [];

    function hO(OO, KO) {
      return DO(OO, CO), !QO(CO, KO.key) && (KO.key.length = 0, KO.key.push(...CO), KO.key.length > 0 && function(OO, KO) {
        for (let pO = 0; pO < eO.l; pO++) bK.k.GetCurrentGradient(pO / eO.l, OO, ((OO, KO, pO) => {
          XO.Color3.LerpToRef(OO.color, KO.color, pO, MO)
        })), KO[4 * pO] = 255 * MO.r, KO[4 * pO + 1] = 255 * MO.g, KO[4 * pO + 2] = 255 * MO.b, KO[4 * pO + 3] = 255
      }(OO.getRampGradients(), KO.texels), !0)
    }

    function DO(OO, KO) {
      KO.length = 0;
      const pO = OO.useRampGradients ? OO.getRampGradients() : null;
      if (null !== pO && void 0 !== pO && pO.length) {
        KO.push(pO.length);
        for (const OO of pO) KO.push(OO.gradient, OO.color.r, OO.color.g, OO.color.b)
      }
    }
    const MO = new XO.Color3;

    function aK(OO, KO, pO, XO) {
      return KO ? KO.length > eO.b ? (XO(`particleStops:${pO}`, `GPU particles use the first 2 and last ${eO.b-2} of more than ${eO.b} ${pO} gradient stops (${OO.name})`), eO.b) : KO.length : 0
    }

    function oO(OO, KO) {
      return KO < 2 || OO.length <= eO.b ? KO : OO.length - eO.b + KO
    }
    const FO = new Float32Array(eO.o),
      VO = new Uint32Array(FO.buffer);

    function LO(OO, KO, pO) {
      return lO(OO, FO, VO, pO), KO && QO(VO, KO) ? null : VO.slice()
    }

    function QO(OO, KO) {
      if (OO.length !== KO.length) return !1;
      for (let pO = 0; pO < OO.length; pO++)
        if (OO[pO] !== KO[pO]) return !1;
      return !0
    }

    function zK(OO, KO, pO) {
      var XO;
      OO[KO] = pO.gradient, OO[KO + 1] = pO.factor1, OO[KO + 2] = null !== (XO = pO.factor2) && void 0 !== XO ? XO : pO.factor1
    }
  },
  39624: (OO, KO, pO) => {
    function XO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
      const KO = new Set;
      return (pO, XO) => {
        KO.has(pO) || (KO.add(pO), console.warn(OO + XO))
      }
    }
    pO.d(KO, {
      d: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);