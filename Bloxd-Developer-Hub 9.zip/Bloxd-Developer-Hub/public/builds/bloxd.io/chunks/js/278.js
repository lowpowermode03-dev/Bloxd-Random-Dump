export const id = 278;
export const ids = [278];
export const modules = {
  39411: (OO, KO, pO) => {
    function XO() {
      return XO = Object.assign ? Object.assign.bind() : function(OO) {
        for (var KO = 1; KO < arguments.length; KO++) {
          var pO = arguments[KO];
          for (var XO in pO)({}).hasOwnProperty.call(pO, XO) && (OO[XO] = pO[XO])
        }
        return OO
      }, XO.apply(null, arguments)
    }
    pO.d(KO, {
      e: () => aK,
      g: () => vK
    });
    var bK = !1;
    try {
      bK = "undefined" !== typeof localStorage
    } catch (FO) {}
    var eO = "undefined" !== typeof process,
      lO = bK && "function" === typeof localStorage.getItem && localStorage.getItem("DEBUG") || eO && {
        NODE_ENV: "production",
        PUBLIC_URL: "",
        WDS_SOCKET_HOST: void 0,
        WDS_SOCKET_PATH: void 0,
        WDS_SOCKET_PORT: void 0,
        FAST_REFRESH: !0,
        REACT_APP_DEV_URLS: "false"
      }.DEBUG ? console.log : function(OO) {
        return ""
      };

    function vK(OO, KO, pO, bK, eO) {
      void 0 === bK && (bK = {});
      var lO = XO({}, DO(pO), bK),
        vK = function(OO, KO, pO, bK, eO) {
          var lO = [].concat(KO),
            vK = oO(OO, pO, bK),
            CO = vK.compilerHost,
            hO = vK.updateFile,
            DO = vK.deleteFile,
            MO = new Map,
            aK = 0,
            FO = XO({}, CO, {
              getProjectVersion: function() {
                return aK.toString()
              },
              getCompilationSettings: function() {
                return pO
              },
              getCustomTransformers: function() {
                return eO
              },
              getScriptFileNames: function() {
                return lO.slice()
              },
              getScriptSnapshot: function(KO) {
                var pO = OO.readFile(KO);
                if (pO && "string" === typeof pO) return bK.ScriptSnapshot.fromString(pO)
              },
              getScriptVersion: function(OO) {
                return MO.get(OO) || "0"
              },
              writeFile: OO.writeFile
            }),
            VO = {
              languageServiceHost: FO,
              updateFile: function(OO) {
                aK++, MO.set(OO.fileName, aK.toString()), lO.includes(OO.fileName) || lO.push(OO.fileName), hO(OO)
              },
              deleteFile: function(OO) {
                aK++, MO.set(OO.fileName, aK.toString());
                var KO = lO.indexOf(OO.fileName); - 1 !== KO && lO.splice(KO, 1), DO(OO)
              }
            };
          return VO
        }(OO, KO, lO, pO, eO),
        CO = vK.languageServiceHost,
        hO = vK.updateFile,
        MO = vK.deleteFile,
        aK = pO.createLanguageService(CO),
        FO = aK.getCompilerOptionsDiagnostics();
      if (FO.length) {
        var VO = oO(OO, bK, pO);
        throw new Error(pO.formatDiagnostics(FO, VO.compilerHost))
      }
      return {
        name: "vfs",
        sys: OO,
        languageService: aK,
        getSourceFile: function(OO) {
          var KO;
          return null == (KO = aK.getProgram()) ? void 0 : KO.getSourceFile(OO)
        },
        createFile: function(OO, KO) {
          hO(pO.createSourceFile(OO, KO, lO.target, !1))
        },
        updateFile: function(OO, KO, XO) {
          var bK = aK.getProgram().getSourceFile(OO);
          if (!bK) throw new Error("Did not find a source file for " + OO);
          var eO = bK.text,
            lO = null != XO ? XO : pO.createTextSpan(0, eO.length),
            vK = eO.slice(0, lO.start) + KO + eO.slice(lO.start + lO.length),
            CO = pO.updateSourceFile(bK, vK, {
              span: lO,
              newLength: KO.length
            });
          hO(CO)
        },
        deleteFile: function(OO) {
          var KO = aK.getProgram().getSourceFile(OO);
          KO && MO(KO)
        }
      }
    }

    function CO(OO) {
      throw new Error("Method '" + OO + "' is not implemented.")
    }

    function hO(OO, KO) {
      return function() {
        for (var pO = arguments.length, XO = new Array(pO), bK = 0; bK < pO; bK++) XO[bK] = arguments[bK];
        var eO = KO.apply(void 0, XO),
          vK = "string" === typeof eO ? eO.slice(0, 80) + "..." : eO;
        return lO.apply(void 0, ["> " + OO].concat(XO)), lO("< " + vK), eO
      }
    }
    var DO = function(OO) {
        return XO({}, OO.getDefaultCompilerOptions(), {
          jsx: OO.JsxEmit.React,
          strict: !0,
          esModuleInterop: !0,
          module: OO.ModuleKind.ESNext,
          suppressOutputPathCheck: !0,
          skipLibCheck: !0,
          skipDefaultLibCheck: !0
        }, OO.versionMajorMinor && Number(OO.versionMajorMinor.split(".")[0]) >= 6 ? {
          ignoreDeprecations: "6.0"
        } : {
          moduleResolution: OO.ModuleResolutionKind.NodeJs
        })
      },
      MO = function(OO) {
        return OO.replace("/", "/lib.").toLowerCase()
      };

    function aK(OO) {
      return {
        args: [],
        createDirectory: function() {
          return CO("createDirectory")
        },
        directoryExists: hO("directoryExists", (function(KO) {
          return Array.from(OO.keys()).some((function(OO) {
            return OO.startsWith(KO)
          }))
        })),
        exit: function() {
          return CO("exit")
        },
        fileExists: hO("fileExists", (function(KO) {
          return OO.has(KO) || OO.has(MO(KO))
        })),
        getCurrentDirectory: function() {
          return "/"
        },
        getDirectories: function() {
          return []
        },
        getExecutingFilePath: function() {
          return CO("getExecutingFilePath")
        },
        readDirectory: hO("readDirectory", (function(KO) {
          return "/" === KO ? Array.from(OO.keys()) : []
        })),
        readFile: hO("readFile", (function(KO) {
          var pO;
          return null != (pO = OO.get(KO)) ? pO : OO.get(MO(KO))
        })),
        resolvePath: function(OO) {
          return OO
        },
        newLine: "\n",
        useCaseSensitiveFileNames: !0,
        write: function() {
          return CO("write")
        },
        writeFile: function(KO, pO) {
          OO.set(KO, pO)
        },
        deleteFile: function(KO) {
          OO.delete(KO)
        }
      }
    }

    function oO(OO, KO, pO) {
      var bK = new Map;
      return {
        compilerHost: XO({}, OO, {
          getCanonicalFileName: function(OO) {
            return OO
          },
          getDefaultLibFileName: function() {
            return "/" + pO.getDefaultLibFileName(KO)
          },
          getNewLine: function() {
            return OO.newLine
          },
          getSourceFile: function(XO, eO) {
            var lO, vK;
            return bK.get(XO) || (vK = pO.createSourceFile(XO, OO.readFile(XO), null != (lO = null != eO ? eO : KO.target) ? lO : DO(pO).target, !1), bK.set(vK.fileName, vK), vK)
          },
          useCaseSensitiveFileNames: function() {
            return OO.useCaseSensitiveFileNames
          }
        }),
        updateFile: function(KO) {
          var pO = bK.has(KO.fileName);
          return OO.writeFile(KO.fileName, KO.text), bK.set(KO.fileName, KO), pO
        },
        deleteFile: function(KO) {
          var pO = bK.has(KO.fileName);
          return bK.delete(KO.fileName), OO.deleteFile(KO.fileName), pO
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);