export const id = 86;
export const ids = [86, 177];
export const modules = {
  8247: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      EverythingMenu: () => ze
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1051),
      vK = pO(933),
      CO = pO(1650),
      hO = pO(997),
      DO = pO(976);

    function MO(OO) {
      let {
        items: KO,
        onClick: pO,
        selectedItemId: XO,
        className: bK,
        padStartsOnTab: MO = !0
      } = OO;
      const {
        t: aK
      } = (0, lO.D)(), oO = (0, hO.g)(), FO = [];
      for (const eO of KO) {
        var VO;
        const OO = FO[FO.length - 1];
        var LO;
        if (OO && OO.title === (null !== (VO = eO.section) && void 0 !== VO ? VO : null)) OO.items.push(eO);
        else FO.push({
          title: null !== (LO = eO.section) && void 0 !== LO ? LO : null,
          items: [eO]
        })
      }
      return (0, DO.jsx)("div", {
        className: eO()("MenuSideBarBody", bK),
        "data-pad-tabs": "2",
        children: FO.map(((OO, KO) => {
          var bK;
          return (0, DO.jsxs)("div", {
            className: "MenuSideBarSection",
            children: [OO.title && (0, DO.jsx)("div", {
              className: "MenuSideBarSectionTitle",
              children: aK(OO.title)
            }), OO.items.map((OO => {
              var KO;
              const bK = !!OO.iconElement || !!OO.faIcon;
              return (0, DO.jsxs)("div", {
                "data-pad-tab": !0,
                "data-pad-selected": XO === OO.id ? "true" : void 0,
                "data-pad-default-focus": MO && XO === OO.id || void 0,
                className: eO()("MenuSideBarBodyTab", {
                  ActiveMenuSideBarBodyTab: XO === OO.id
                }),
                onClick: () => {
                  pO(OO.id)
                },
                children: [bK && (0, DO.jsx)("div", {
                  className: "MenuSideBarBodyTabIcon",
                  children: null !== (KO = OO.iconElement) && void 0 !== KO ? KO : (0, DO.jsx)(vK.d, {
                    name: OO.faIcon
                  })
                }), (!oO || !bK) && (0, DO.jsx)("div", {
                  children: aK(OO.title)
                }), OO.redDot && (0, DO.jsx)(CO.e, {
                  top: "-0.2rem",
                  right: "-1rem"
                })]
              }, OO.id)
            }))]
          }, null !== (bK = OO.title) && void 0 !== bK ? bK : KO)
        }))
      })
    }
    var aK = pO(2332),
      oO = pO(1004),
      FO = pO(1991),
      VO = pO(1e3),
      LO = pO(1271),
      QO = pO(94),
      zK = pO(1556),
      AO = pO(1836),
      fO = pO(1840),
      dO = pO(1475),
      TO = pO(1180),
      NO = pO(4120),
      IO = pO(22),
      yK = pO(8256);

    function gK(OO) {
      let {
        setApplySettingsCallback: KO
      } = OO;
      const {
        clientEscMenuOptions: pO
      } = (0, IO.l)(["clientEscMenuOptions"]), [bK, eO] = (0, XO.useState)(!1), [lO, vK] = (0, XO.useState)(!1), [CO, hO] = (0, XO.useState)(6400), [MO, aK] = (0, XO.useState)(3600), [oO, FO] = (0, XO.useState)(!1), [VO, QO] = (0, XO.useState)(!1);

      function zK(OO) {
        const KO = "screenshot" === OO ? vK : eO;
        KO(!0);
        const pO = oO ? "normals" : VO ? "depth" : null;
        yK.devTools.downloadScene(OO, {
          width: CO,
          height: MO,
          colouring: pO
        }).catch((OO => {
          console.error("Couldn't download the scene", OO)
        })).finally((() => {
          KO(!1)
        }))
      }
      return (0, DO.jsxs)("div", {
        className: "DeveloperToolsCategory",
        children: [(0, DO.jsx)(NO.b, {
          label: "Disable Ambient Occlusion",
          checked: pO.disableAmbientOcclusion,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              disableAmbientOcclusion: OO
            }), KO((() => NO.j))
          },
          circleInfoText: "Disables ambient occlusion which is the shadow effect that makes corners and crevices darker."
        }), yK.devTools.supports("ambientLight") && (0, DO.jsx)(NO.h, {
          name: "Ambient Lighting Intensity",
          min: 0,
          max: 1,
          step: .01,
          initValue: pO.ambientLightIntensity,
          onChange: OO => {
            yK.devTools.setAmbientLightIntensity(OO).then((() => {
              IO.d.setClientEscMenuOptions({
                ambientLightIntensity: OO
              })
            })).catch((OO => {
              console.error("Couldn't set the ambient light", OO)
            }))
          },
          circleInfoText: "Sets the intensity of the white ambient light in the scene. The default is 0.5."
        }), yK.devTools.supports("weaponRaycasts") && (0, DO.jsx)(NO.b, {
          label: "Show Weapon Raycasts",
          checked: pO.showWeaponRaycasts,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              showWeaponRaycasts: OO
            })
          },
          circleInfoText: "Draws debug lines for the raw raycasts used by locally fired weapons."
        }), yK.devTools.supports("sceneDownload") && (0, DO.jsxs)("div", {
          className: "SettingBoxGroup",
          children: [(0, DO.jsxs)("div", {
            className: "SettingBox WarningBorder",
            children: [(0, DO.jsx)(NO.b, {
              label: "Apply normal-based coloring",
              checked: oO,
              onClick: OO => {
                FO(OO), OO && QO(!1)
              },
              circleInfoText: "Colors faces based on their normal direction (red=X, green=Y, blue=Z)."
            }), (0, DO.jsx)(NO.b, {
              label: "Apply depth-based coloring",
              checked: VO,
              onClick: OO => {
                QO(OO), OO && FO(!1)
              },
              circleInfoText: "Colors from white (near) to black (far) based on distance from camera. Only works for screenshot export."
            }), (0, DO.jsxs)("div", {
              className: "SettingBox DeveloperToolsCategoryScreenshotSettings",
              children: [(0, DO.jsx)("div", {
                className: "SettingLabel",
                children: "Screenshot size in pixels (width x height)"
              }), (0, DO.jsx)(dO.e, {
                className: "SettingsTextInput SmallTextLight",
                onValueChange: (OO, KO) => {
                  const pO = parseInt(OO) || 6400;
                  hO(pO)
                },
                placeholderText: "width",
                maxLength: 10,
                defaultValue: CO.toString()
              }), (0, DO.jsx)("span", {
                children: "X"
              }), (0, DO.jsx)(dO.e, {
                className: "SettingsTextInput SmallTextLight",
                onValueChange: (OO, KO) => {
                  const pO = parseInt(OO) || 3600;
                  aK(pO)
                },
                placeholderText: "height",
                maxLength: 10,
                defaultValue: MO.toString()
              })]
            }), (0, DO.jsxs)("div", {
              className: "DeveloperToolsCategoryExportButtons",
              children: [(0, DO.jsxs)(LO.d, {
                onClick: () => {
                  zK("screenshot")
                },
                disabled: lO,
                children: [lO && (0, DO.jsx)(TO.e, {}), "Download Screenshot"]
              }), (0, DO.jsxs)(LO.d, {
                onClick: () => {
                  zK("glb")
                },
                disabled: bK,
                children: [bK && (0, DO.jsx)(TO.e, {}), "Download GLB"]
              })]
            })]
          }), (0, DO.jsx)("div", {
            className: "SettingBox SettingsBoxWarning",
            children: 'To download GLB of scene with textures you need to "Disable Block Texture Atlas" in graphic settings first (you will need to reload the page to apply the setting).'
          })]
        })]
      })
    }
    var uO = pO(1104),
      EO = pO(1187),
      jK = pO(142),
      YO = pO(1008),
      wO = pO(1056),
      iK = pO(1152),
      rK = pO(2340),
      PO = pO(1344),
      mK = pO(1123),
      sO = pO(1095),
      HO = pO(2394),
      RO = pO(1635),
      SO = pO(1329),
      JO = pO(256),
      cK = pO(1849),
      BO = pO(1871),
      ZO = pO(1195),
      GO = pO(1067),
      qK = pO(4012),
      xK = pO(1302),
      nO = pO(2914),
      WO = pO(2153),
      tK = pO(1820);

    function kK(OO) {
      let {
        showing: KO
      } = OO;
      const {
        t: pO
      } = (0, lO.D)(), {
        data: XO,
        failed: bK
      } = (0, WO.e)(nO.g, KO);
      return 0 === (null === XO || void 0 === XO ? void 0 : XO.length) || null === XO && !bK ? null : (0, DO.jsxs)("div", {
        className: "SettingBox AccountSettingsPaymentHistory",
        children: [(0, DO.jsx)("div", {
          className: "AccountSettingsLabel",
          children: pO("paymentHistory:title")
        }), null === XO && bK && (0, DO.jsx)("div", {
          className: "AccountSettingsPaymentHistoryError",
          children: pO("paymentHistory:loadFailed")
        }), null !== XO && (0, DO.jsx)("ul", {
          className: "PaymentHistoryList",
          children: XO.map((OO => (0, DO.jsxs)("li", {
            className: "PaymentHistoryEntry",
            children: [(0, DO.jsx)(tK.c, {
              entry: OO
            }), (0, DO.jsxs)("div", {
              className: "PaymentHistoryEntryText",
              children: [(0, DO.jsx)("div", {
                children: (0, tK.j)(pO, OO)
              }), (0, DO.jsxs)("div", {
                className: "PaymentHistoryEntryDate",
                children: [new Date(OO.at).toLocaleDateString(), "number" === typeof OO.orderId && ` \xb7 ${pO("paymentHistory:order",{orderId:OO.orderId})}`]
              })]
            })]
          }, (0, nO.c)(OO))))
        })]
      })
    }
    var UO = pO(2838),
      OK = pO(2855),
      KK = pO(2848);

    function pK(OO) {
      let {
        showing: KO
      } = OO;
      const {
        t: pO
      } = (0, lO.D)(), {
        data: XO,
        failed: bK
      } = (0, WO.e)(UO.c, KO), eO = null === XO ? null : (0, UO.e)(XO);
      return (0, DO.jsxs)("div", {
        className: "SettingBox BlockedAndIgnoredPlayers",
        children: [(0, DO.jsx)("div", {
          className: "AccountSettingsLabel",
          children: pO("settingsMenu:blockedAndIgnoredPlayers")
        }), null === eO && !bK && (0, DO.jsx)(TO.e, {}), null === eO && bK && (0, DO.jsxs)("div", {
          className: "BlockedAndIgnoredPlayersError",
          children: [pO("settingsMenu:blockedAndIgnoredPlayersLoadFailed"), (0, DO.jsx)(LO.d, {
            className: "SmallTextLight",
            onClick: () => {
              UO.c.refresh()
            },
            children: pO("general:tryAgain")
          })]
        }), 0 === (null === eO || void 0 === eO ? void 0 : eO.length) && (0, DO.jsx)("div", {
          className: "BlockedAndIgnoredPlayersEmpty",
          children: pO("settingsMenu:noBlockedOrIgnoredPlayers")
        }), null !== eO && eO.length > 0 && (0, DO.jsx)("ul", {
          className: "BlockedAndIgnoredPlayersList",
          children: eO.map((OO => {
            let {
              name: KO,
              exclusion: XO
            } = OO;
            const bK = KK.f[XO];
            return (0, DO.jsxs)("li", {
              className: "BlockedAndIgnoredPlayer",
              children: [(0, DO.jsx)("div", {
                className: "BlockedAndIgnoredPlayerName",
                children: KO
              }), (0, DO.jsx)(LO.e, {
                className: "SmallTextLight",
                onClick: () => {
                  (0, OK.e)(bK, KO)
                },
                children: pO(KK.j[bK].text)
              })]
            }, KO)
          }))
        })]
      })
    }
    const XK = (0, XO.memo)((function(OO) {
      var KO;
      let {
        showing: pO,
        inGame: bK
      } = OO;
      const {
        t: CO,
        selectedLanguage: hO
      } = (0, lO.D)(), {
        reactNativeFeatureFlags: MO,
        hideSocialLocationFrom: FO
      } = (0, IO.l)(["reactNativeFeatureFlags", "hideSocialLocationFrom"]), VO = (0, aK.b)(), {
        userContext: zK,
        isUserContextUpdating: AO
      } = (0, oO.d)(), [fO, yK] = (0, XO.useState)(null !== (KO = zK.getPlayerName()) && void 0 !== KO ? KO : ""), [gK, uO] = (0, XO.useState)(null), {
        purchasing: EO,
        outcome: iK,
        purchase: nO
      } = (0, rK.c)("/super-rank-welcome"), [WO, tK] = (0, XO.useState)(!1), [UO, OK] = (0, XO.useState)(!1), KK = (0, XO.useRef)(null), XK = (0, XO.useRef)(null), eK = (0, RO.g)({
        showProgressUpdateMessage: !0,
        enabled: !0
      }), lK = null === eK, vp = null !== eK && void 0 !== eK ? eK : [], [CK, hK] = (0, XO.useState)([]), [DK, MK] = (0, XO.useState)(!1), ap = zK.playerHasRank("youtuber"), oK = (0, XO.useCallback)((() => SO.c.getPlayerProfile(zK, {
        lowerCaseName: zK.getPlayerName().toLowerCase()
      }).then((OO => {
        hK(OO.socialLinks)
      })).catch((OO => {
        console.error("Failed to refresh social links", OO)
      }))), [zK]);

      function FK(OO) {
        OO !== fO && ((0, mK.j)(OO) ? (OO = (0, mK.n)(OO), uO("Only letters, numbers, and _")) : uO(null), KK.current && (KK.current.value = OO), yK(OO))
      }
      return (0, XO.useEffect)((() => (!0 === pO ? (clearInterval(XK.current), XK.current = setInterval(VO, 1e3)) : clearInterval(XK.current), () => {
        clearInterval(XK.current)
      })), [pO, VO]), (0, XO.useEffect)((() => {
        var OO;
        yK(null !== (OO = zK.getPlayerName()) && void 0 !== OO ? OO : "")
      }), [zK]), (0, XO.useEffect)((() => {
        if (!pO || !ap || AO) return;
        let OO = !1;
        return MK(!0), hK([]), SO.c.getPlayerProfile(zK, {
          lowerCaseName: zK.getPlayerName().toLowerCase()
        }).then((KO => {
          OO || hK(KO.socialLinks)
        })).catch((OO => {
          console.error("Failed to load social links", OO)
        })).finally((() => {
          OO || MK(!1)
        })), () => {
          OO = !0
        }
      }), [pO, ap, AO, zK]), (0, DO.jsxs)("div", {
        className: eO()("SettingsMenuRightInner AccountSettings", {
          AccountSettingsLocked: bK
        }),
        children: [bK && (0, DO.jsx)("div", {
          className: "AccountSettingsInGameWarning",
          children: CO("settingsMenu:accountSettingsInGameWarning")
        }), (0, DO.jsxs)("div", {
          className: "SettingBox SetAccountNameDiv SmallTextLight",
          children: [(0, DO.jsxs)("div", {
            className: "AccountSettingsLabel AccountSettingsNameLabel",
            children: [CO("homePage:discordNamePopupTitle"), (0, DO.jsxs)(PO.LinkPreserveSearch, {
              className: "AccountSettingsViewProfile",
              to: (0, sO.l)({
                name: zK.getPlayerName()
              }),
              onClick: () => {
                IO.d.set({
                  openEverythingMenuName: null
                })
              },
              children: [(0, DO.jsx)(vK.d, {
                name: "arrow-up-right-from-square"
              }), " ", CO("profileCard:viewProfile")]
            })]
          }), (0, DO.jsxs)("div", {
            className: "EnterAccNameDivWrapper",
            "data-pad-initial-area": !0,
            children: [(0, DO.jsxs)("div", {
              className: "EnterAccNameInputRow",
              children: [QO.featureFlags.canChangeName && (0, DO.jsx)(dO.e, {
                className: "EnterName",
                placeholderText: CO("homePage:enterName"),
                maxLength: mK.f,
                defaultValue: fO,
                onValueChange: OO => {
                  FK(OO)
                },
                forcedText: WO || !QO.featureFlags.canChangeName ? fO : null,
                blurOnEnter: !0,
                domRef: KK
              }), (0, DO.jsx)(LO.d, {
                className: "ChooseRandomNameButton",
                onClick: () => {
                  FK((0, mK.e)())
                },
                children: (0, DO.jsx)(vK.d, {
                  name: "dice",
                  className: "ChooseRandomNameIcon"
                })
              }), !QO.featureFlags.canChangeName && (0, DO.jsx)("div", {
                className: "EnterName NoInput",
                children: (0, mK.c)(fO, !QO.featureFlags.canSeeRealPlayerNames)
              })]
            }), (0, DO.jsx)(LO.d, {
              className: "ChooseNameButton",
              disabled: WO || fO === zK.getPlayerName(),
              onClick: () => {
                fO.length < mK.i ? uO(CO("homePage:changeNameMinLengthError", {
                  length: mK.i
                })) : fO.length > mK.f ? uO(CO("homePage:changeNameMaxLengthError", {
                  length: mK.f
                })) : (tK(!0), uO(null), async function(OO, KO, pO, XO) {
                  const bK = await (0, YO.postJsonWithMetricsCookiesAndJsonResponse)(`${wO.clientSideServerUrls.indexUrl}/index/name/update`, {
                    name: OO
                  }, {
                    retries: 3
                  }, KO.getMetricsCookies()).catch((OO => (console.error("Bad response from the server when trying to update name:", OO), {
                    err: "An error occurred trying to change your name! Please report on discord what steps you took to get this error message."
                  })));
                  bK.err ? (console.error("Error when trying to get with new name from DB", bK.err), XO(bK.err)) : !0 === bK.nameExists ? XO("Name is already taken") : pO(OO)
                }(fO, zK, (OO => {
                  zK.setPlayerName(OO), tK(!1)
                }), (OO => {
                  uO(OO), tK(!1)
                })))
              },
              children: CO("general:choose")
            })]
          }), gK && (0, DO.jsx)("div", {
            className: "ChooseAccNameError",
            children: gK
          })]
        }), (0, DO.jsx)(NO.b, {
          label: (() => {
            if ((0, GO.k)(FO)) {
              const OO = (0, lO.o)(hO.code, "general:timeLeft"),
                KO = (0, JO.Z)(OO, Date.now(), FO + GO.h);
              return `${CO("settingsMenu:hideSocialLocation")} (${CO("general:timeLeft",{time:KO})})`
            }
            return CO("settingsMenu:hideSocialLocation")
          })(),
          onClick: () => {
            const OO = !(0, GO.k)(FO);
            (0, xK.e)({
              id: "social.hide_location",
              value: OO ? "on" : "off"
            }), OK(!0), SO.c.setHideSocialLocation(zK, OO).then((() => {
              IO.d.set({
                hideSocialLocationFrom: OO ? Date.now() : null
              })
            })).finally((() => {
              OK(!1)
            }))
          },
          checked: (0, GO.k)(FO),
          disabled: UO
        }), ap && (0, DO.jsxs)("div", {
          className: "SettingBox AccountSettingsSocialLinks",
          children: [(0, DO.jsx)("div", {
            className: "AccountSettingsLabel",
            children: CO("settingsMenu:socialLinks")
          }), DK && (0, DO.jsx)(TO.e, {}), !DK && (0, DO.jsx)(qK.c, {
            socialLinks: CK,
            editable: !0,
            userContext: zK,
            onLinksUpdated: oK
          })]
        }), (0, DO.jsxs)("div", {
          className: "SettingBox",
          children: [(0, DO.jsx)("div", {
            className: "AccountSettingsLabel",
            children: CO("auth:login")
          }), lK && (0, DO.jsx)(TO.e, {}), !lK && 0 === vp.length && (0, DO.jsx)("div", {
            className: "NoLoginOptions",
            children: CO("auth:noLoginOptions")
          }), !lK && vp.length > 0 && "crazygames" !== jK.t && (0, DO.jsx)("div", {
            className: "AccountSettingsLoginButtons",
            children: vp
          }), !lK && vp.length > 0 && "crazygames" === jK.t && (0, DO.jsxs)("div", {
            className: "AccountSettingsLoginButtons",
            children: [vp[0], vp.length > 1 && (0, DO.jsxs)(DO.Fragment, {
              children: [(0, DO.jsxs)("div", {
                className: "LegacyLoginOptionsHeader",
                children: [(0, DO.jsx)("span", {
                  className: "LegacyLoginOptionsTitle",
                  children: CO("auth:legacyLoginOptions")
                }), (0, DO.jsx)(ZO.c, {
                  className: "LegacyLoginOptionsInfoIcon",
                  hoverInfo: CO("auth:legacyLoginOptionsInfo")
                })]
              }), (0, DO.jsx)("div", {
                className: "LegacyAccountSettingsLoginButtons",
                children: vp.slice(1)
              })]
            })]
          }), QO.featureFlags.useLogin && MO.useLogin && (null !== zK.loggedInInfo || zK.isLoggedIn()) && (0, DO.jsxs)(DO.Fragment, {
            children: [(0, DO.jsx)("div", {
              className: "AccountSettingsLoginDivider"
            }), (0, DO.jsx)(LO.I, {
              onClick: () => {
                (0, YO.forceGlobalSignOut)()
              },
              className: "AccountSettingsSignedInButton",
              children: CO("auth:signOut")
            })]
          })]
        }), !zK.playerHasRank("super") && (0, BO.siteSupportsPurchases)() && (0, DO.jsxs)("div", {
          className: "SettingBox AccountSettingsSuperRank",
          children: [(0, DO.jsxs)("div", {
            className: "AccountSettingsLabel AccountSettingsLabelSuperRank",
            children: [(0, DO.jsx)(vK.d, {
              name: "bolt"
            }), CO("homePage:superRank")]
          }), (0, DO.jsxs)("div", {
            className: "AccountSettingsSuperRankProlongContainer",
            children: [(0, DO.jsxs)(LO.m, {
              className: "AccountSettingsSuperRankProlong",
              onClick: () => {
                (0, cK.k)({
                  mode: "self",
                  source: "accountSettings",
                  openItem: "superRank"
                })
              },
              children: [(0, DO.jsx)(vK.d, {
                name: "bolt"
              }), CO("homePage:getSuperRank")]
            }), (0, DO.jsxs)(LO.m, {
              className: "AccountSettingsSuperRankProlong",
              onClick: () => {
                (0, cK.k)({
                  mode: "gift",
                  source: "accountSettings",
                  openItem: "superRank"
                })
              },
              children: [(0, DO.jsx)(vK.d, {
                name: "bolt"
              }), CO("homePage:giftSuperRank")]
            })]
          })]
        }), zK.playerHasRank("super") && (0, DO.jsxs)("div", {
          className: "SettingBox AccountSettingsSuperRank",
          children: [(0, DO.jsxs)("div", {
            className: "AccountSettingsLabel AccountSettingsLabelSuperRank",
            children: [(0, DO.jsx)(vK.d, {
              name: "bolt"
            }), CO("homePage:superRank"), (0, DO.jsxs)("div", {
              className: "AccountSettingsSuperRankTimeLeft",
              children: ["(", CO("general:timeLeft", {
                time: (0, JO.ec)((0, lO.o)(hO.code, "general:timeLeft"), zK.superRankInfo)
              }), ")"]
            })]
          }), (0, BO.siteSupportsPurchases)() && (0, DO.jsxs)("div", {
            className: "AccountSettingsSuperRankProlongContainer",
            children: [(0, DO.jsxs)(LO.m, {
              className: "AccountSettingsSuperRankProlong",
              loading: EO,
              onClick: () => {
                nO(HO.h.id, null)
              },
              children: [(0, DO.jsx)(vK.d, {
                name: "bolt"
              }), CO("settingsMenu:getSuperRankAdditionalDaysPremiumCurrency", {
                days: HO.h.product.days,
                price: HO.h.price
              })]
            }), (0, DO.jsxs)(LO.m, {
              className: "AccountSettingsSuperRankProlong",
              onClick: () => {
                (0, cK.k)({
                  mode: "gift",
                  source: "accountSettings",
                  openItem: "superRank"
                })
              },
              children: [(0, DO.jsx)(vK.d, {
                name: "bolt"
              }), CO("homePage:giftSuperRank")]
            })]
          }), iK && (0, DO.jsx)("div", {
            className: "AccountSettingsSuperRankProlongError SmallTextBold",
            children: CO(iK.translationKey)
          })]
        }), (0, DO.jsx)(kK, {
          showing: pO
        }), QO.featureFlags.useSocialFeatures && (0, DO.jsx)(pK, {
          showing: pO
        }), (0, DO.jsxs)("div", {
          className: "SettingBoxGroup AccountSettingsDeleteAccountGroup",
          children: [(0, DO.jsxs)("div", {
            className: "SettingBox AccountSettingsDeleteAccount SettingBoxWarning",
            children: [(0, DO.jsx)("div", {
              className: "AccountSettingsDeleteAccountButtonTitle",
              children: CO("auth:deleteAccountButtonTitle")
            }), (0, jK.e)() && (0, DO.jsx)("div", {
              className: "AccountSettingsDeleteAccountButtonTitle",
              children: CO("auth:discordActivityKickWarning")
            }), (0, DO.jsx)(bp, {})]
          }), (0, DO.jsx)("div", {
            className: "SettingBox SettingsBoxWarning",
            children: CO("auth:deleteAccountWarning")
          })]
        })]
      })
    }));

    function bp() {
      const {
        userContext: OO,
        isUserContextUpdating: KO
      } = (0, oO.d)(), {
        t: pO
      } = (0, lO.D)(), [bK, eO] = (0, XO.useState)(!1), [vK, CO] = (0, XO.useState)(null), hO = KO || bK;
      return (0, DO.jsxs)("div", {
        className: "AccountSettingsDeleteAccountButtonContainer",
        children: [(0, DO.jsxs)(LO.I, {
          onClick: async function() {
            if (!bK) {
              eO(!0);
              try {
                const KO = await async function() {
                  if (!await EO.NotificationProvider.showPromptPopup({
                      title: "auth:deleteAccountPopupTitleNamed",
                      textOpts: {
                        title: {
                          playerName: (0, mK.c)(OO.getPlayerName(), !QO.featureFlags.canSeeRealPlayerNames)
                        }
                      },
                      subtitle: (0, jK.e)() ? "auth:discordActivityDeleteAccountWarning" : "auth:deleteAccountWarning",
                      confirmText: "auth:deleteAccount",
                      destructive: !0,
                      confirmTooltip: "auth:deleteAccountPopupConfirmTooltip",
                      cancelText: "general:cancel",
                      cancelTooltip: "auth:deleteAccountPopupCancelTooltip"
                    }).getResult()) return uO.c.ok();
                  const KO = await (0, YO.postJsonWithMetricsCookiesAndJsonResponse)(`${wO.clientSideServerUrls.indexUrl}/index/metrics/revoke-cookies`, {}, {
                    retries: 3
                  }, OO.getMetricsCookies());
                  if (KO.error) return uO.c.error(KO.error);
                  (0, jK.e)() && (await iK.q.discordActivity()).exit("User deleted their account");
                  return (0, YO.forgetStoredGuestAccount)(OO.whamm), (0, YO.forceGlobalSignOut)(!0), uO.c.ok()
                }(), pO = KO.isError() ? KO.asError().message : null;
                CO(pO)
              } catch (KO) {
                console.error("Failed to delete account:", KO), CO(pO("auth:genericDeleteAccountError"))
              }
              eO(!1)
            }
          },
          className: "AccountSettingsDeleteAccountButton",
          disabled: hO,
          children: [hO && (0, DO.jsx)("div", {
            className: "DeletingAccountLoader",
            children: (0, DO.jsx)(TO.e, {})
          }), pO("auth:deleteAccount")]
        }), vK && (0, DO.jsx)("div", {
          className: "DeleteAccountError",
          children: vK
        })]
      })
    }
    var eK = pO(8268),
      lK = pO(2430),
      vp = pO(1109),
      CK = pO(1253);
    const hK = (0, XO.memo)((function(OO) {
        let {
          inGame: KO
        } = OO;
        const {
          t: pO,
          selectedLanguage: XO
        } = (0, lO.D)(), {
          clientEscMenuOptions: bK,
          showDebugOverlay: eO
        } = (0, IO.l)(["clientEscMenuOptions", "showDebugOverlay"]), vK = (0, FO.i)("hideCoordinates");
        let CO = "settingsMenu:showCoordinates",
          hO = "settingsMenu:showChunkCoordinates";

        function MO(OO) {
          const KO = new Intl.DisplayNames([OO], {
            type: "language"
          }).of(OO);
          return KO.charAt(0).toUpperCase() + KO.slice(1)
        }
        return vK && (CO = "settingsMenu:showCoordinatesHidden", hO = "settingsMenu:showChunkCoordinatesHidden"), (0, DO.jsxs)("div", {
          className: "SettingsMenuRightInner",
          children: [KO && QO.featureFlags.canUseInviteLinks && (0, DO.jsxs)("div", {
            className: "SettingBox",
            children: [(0, DO.jsx)("div", {
              className: "SettingsMenuInviteHeader",
              children: pO("settingsMenu:inviteLink")
            }), (0, DO.jsx)(eK.e, {})]
          }), (0, DO.jsxs)("div", {
            className: "SettingBox",
            children: [(0, DO.jsx)("div", {
              className: "SliderText",
              style: {
                marginBottom: "10px"
              },
              children: pO("settingsMenu:language")
            }), (0, DO.jsx)(lK.b, {
              options: Object.entries(lO.j).map((OO => {
                let [KO, pO] = OO;
                return {
                  label: (0, DO.jsxs)("div", {
                    className: "SettingsMenuLanguageOption",
                    children: [(0, DO.jsx)("img", {
                      src: pO.flagImg,
                      alt: "flag"
                    }), (0, DO.jsxs)("span", {
                      children: [MO(KO), " ", (0, DO.jsxs)("span", {
                        className: "SettingsMenuLanguageOptionCode",
                        children: ["(", KO, ")"]
                      })]
                    })]
                  }),
                  value: KO
                }
              })),
              value: XO.code,
              onChange: OO => {
                vp.f.get().setCurrentLanguage(OO.value)
              }
            })]
          }), !(0, QO.isMobileApp)() && (0, CK.c)() && QO.featureFlags.useForceRotateForceFullscreenOverlay && (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:disableFullscreenMode"),
            checked: bK.disableFullscreen,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                disableFullscreen: OO
              })
            }
          }), (0, DO.jsx)(NO.b, {
            label: pO(CO),
            checked: bK.showCoordinates,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                showCoordinates: OO
              })
            },
            disabled: vK
          }), (0, DO.jsx)(NO.b, {
            label: pO(hO),
            checked: bK.showChunkCoordinates,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                showChunkCoordinates: OO
              })
            },
            disabled: vK
          }), (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:showFps"),
            checked: bK.showFPS,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                showFPS: OO
              })
            }
          }), (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:disableBunnyHopping"),
            checked: bK.disableBunnyHopping,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                disableBunnyHopping: OO
              })
            }
          }), (0, iK.F)() && (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:showChat"),
            checked: bK.showChat,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                showChat: OO
              })
            }
          }), (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:showDebugOverlay"),
            checked: eO,
            onClick: OO => {
              IO.d.set({
                showDebugOverlay: OO
              })
            }
          }), QO.featureFlags.useSocialFeatures && (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:showFriendOnlineToasts"),
            checked: bK.showFriendOnlineToasts,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                showFriendOnlineToasts: OO
              })
            }
          }), (0, DO.jsx)(NO.b, {
            label: pO("settingsMenu:showNewItemIndicator"),
            checked: bK.showNewItemIndicator,
            onClick: OO => {
              IO.d.setClientEscMenuOptions({
                showNewItemIndicator: OO
              })
            }
          })]
        })
      })),
      DK = (0, XO.memo)((function() {
        const {
          t: OO
        } = (0, lO.D)(), {
          soundVolume: KO,
          musicVolume: pO
        } = (0, IO.l)(["soundVolume", "musicVolume"]);
        return (0, DO.jsxs)("div", {
          className: "SettingsMenuRightInner",
          children: [(0, DO.jsx)(NO.h, {
            name: OO("settingsMenu:musicVolume"),
            min: 0,
            max: 1,
            step: .01,
            initValue: pO,
            onChange: OO => {
              IO.d.set({
                musicVolume: Math.round(100 * OO) / 100
              })
            },
            format: OO => OO.toFixed(2)
          }), (0, DO.jsx)(NO.h, {
            name: OO("settingsMenu:soundEffectsVolume"),
            min: 0,
            max: 1,
            step: .01,
            initValue: KO,
            onChange: OO => {
              IO.d.set({
                soundVolume: Math.round(100 * OO) / 100
              })
            },
            format: OO => OO.toFixed(2)
          })]
        })
      }));
    var MK = pO(575),
      ap = pO(1263),
      oK = pO(1513),
      FK = pO(8273),
      VK = pO(2737);
    const LK = {
      app: "notificationSettings:pushTargetsApp",
      browser: "notificationSettings:pushTargetsBrowser",
      msnPlay: "notificationSettings:pushTargetsMsnPlay"
    };

    function QK() {
      const {
        t: OO
      } = (0, lO.D)(), KO = (0, VK.b)(), {
        mobilePushNotificationsCanAsk: pO
      } = (0, IO.l)(["mobilePushNotificationsCanAsk"]), [bK, eO] = (0, XO.useState)(null), [vK, CO] = (0, XO.useState)(!1), [hO, MO] = (0, XO.useState)(null), [aK, oO] = (0, XO.useState)(!1), FO = (0, XO.useCallback)((() => {
        (0, oK.d)().then((OO => {
          KO.current && (eO(OO), CO(!1))
        })).catch((OO => {
          console.error("Failed to load push notification targets:", OO), KO.current && CO(!0)
        }))
      }), [KO]), VO = (0, XO.useCallback)((() => {
        (0, FK.e)().then((OO => {
          KO.current && MO((() => OO))
        }))
      }), [KO]);
      (0, XO.useEffect)((() => {
        FO()
      }), [FO]), (0, XO.useEffect)((() => {
        VO()
      }), [VO, pO]), (0, ap.f)(oK.j, FO);
      const QO = null === bK ? [] : Object.keys(LK).filter((OO => bK[OO] > 0));
      return (0, DO.jsxs)("div", {
        className: "SettingBox PushNotificationSettings",
        children: [(0, DO.jsx)("div", {
          className: "SliderText",
          children: OO("notificationSettings:pushNotifications")
        }), null === bK && vK && (0, DO.jsx)("div", {
          className: "PushNotificationSettingsText",
          children: OO("notificationSettings:pushTargetsLoadFailed")
        }), null !== bK && 0 === QO.length && (0, DO.jsx)("div", {
          className: "PushNotificationSettingsText",
          children: OO("notificationSettings:pushTargetsNone")
        }), QO.length > 0 && (0, DO.jsx)("ul", {
          className: "PushNotificationSettingsTargets",
          children: QO.map((KO => {
            var pO;
            return (0, DO.jsx)("li", {
              children: OO(LK[KO], {
                count: null !== (pO = null === bK || void 0 === bK ? void 0 : bK[KO]) && void 0 !== pO ? pO : 0
              })
            }, KO)
          }))
        }), null !== hO && (0, DO.jsx)(LO.d, {
          className: "PushNotificationSettingsButton",
          loading: aK,
          onClick: () => {
            oO(!0), hO().catch((OO => {
              console.error("Failed to turn on push notifications:", OO)
            })).finally((() => {
              KO.current && (oO(!1), VO())
            }))
          },
          children: OO("notificationSettings:pushTurnOn")
        })]
      })
    }
    const zp = {
        toastAndTray: {
          label: "notificationSettings:friendRequestsAll",
          info: "notificationSettings:friendRequestsAllInfo"
        },
        trayOnly: {
          label: "notificationSettings:friendRequestsQuiet",
          info: "notificationSettings:friendRequestsQuietInfo"
        },
        off: {
          label: "notificationSettings:friendRequestsOff",
          info: "notificationSettings:friendRequestsOffInfo"
        }
      },
      AK = (0, XO.memo)((function() {
        const {
          t: OO
        } = (0, lO.D)(), {
          clientEscMenuOptions: KO
        } = (0, IO.l)(["clientEscMenuOptions"]);
        return (0, DO.jsxs)("div", {
          className: "SettingsMenuRightInner",
          children: [(0, DO.jsx)(NO.e, {
            label: OO("notificationSettings:friendRequests"),
            options: MK.b.map((KO => ({
              value: KO,
              label: OO(zp[KO].label)
            }))),
            value: KO.friendRequestNotifications,
            onChange: OO => {
              IO.d.setClientEscMenuOptions({
                friendRequestNotifications: OO
              })
            },
            circleInfoText: (0, DO.jsx)("div", {
              className: "NotificationSettingLevelsInfo",
              children: MK.b.map((KO => (0, DO.jsxs)("div", {
                children: [(0, DO.jsx)("b", {
                  children: OO(zp[KO].label)
                }), ": ", OO(zp[KO].info)]
              }, KO)))
            })
          }), (0, DO.jsx)(QK, {})]
        })
      }));
    var fK = pO(3701),
      dK = pO(171),
      TK = pO(233),
      NK = pO(5800),
      IK = pO(2668),
      yp = pO(8275),
      gp = pO(533),
      uK = pO(26);
    var EK = pO(554),
      jp = pO(36);
    const YK = new Map([
      ["chunkHorizAddDist", "horizontal"],
      ["chunkVertAddDist", "vertical"]
    ]);

    function wK(OO) {
      return YK.has(OO) ? zK.gameBridge.lookup("RV", null) : null
    }

    function ip(OO) {
      if (!(0, gp.I)(IO.d.get("clientEscMenuOptions")[OO])) return IO.d.get("clientEscMenuOptions")[OO];
      const KO = wK(OO);
      return null !== KO ? KO[YK.get(OO)] : jp.e.getItem(OO)
    }

    function rp(OO, KO) {
      if ("useTouchControls" === OO) return void IO.d.set({
        isTouchScreen: KO
      });
      OO in IO.d.get("clientEscMenuOptions") && IO.d.setClientEscMenuOptions({
        [OO]: KO
      });
      const pO = wK(OO);
      null !== pO && zK.gameBridge.send("setChunkAddDistance", {
        ...pO,
        [YK.get(OO)]: KO
      }), jp.e.setItem(OO, KO)
    }
    var PK = pO(8284),
      mp = pO(8290),
      sK = pO(8296),
      HK = pO(3697);

    function RK(OO) {
      var KO, bK, vK, CO;
      let {
        minChunkAddDist: hO,
        getValue: MO,
        onChange: aK,
        setApplySettingsCallback: oO
      } = OO;
      const {
        t: VO
      } = (0, lO.D)(), {
        clientEscMenuOptions: LO
      } = (0, IO.l)(["clientEscMenuOptions", "showDistantNametags"]), zK = (0, XO.useRef)(MO("showFog")), AO = (0, XO.useRef)(LO.antiAliasing), fO = (0, XO.useRef)(LO.useWebGpu), [dO, TO] = (0, XO.useState)(null), [gK, uO] = (0, XO.useState)((() => (0, IK.c)(QO.featureFlags.settings.canUseShaderPacks))), [EO] = (0, XO.useState)((() => IO.d.isWebGpuDefaultOff())), [jK] = (0, XO.useState)(TK.e);
      (0, XO.useEffect)((() => {
        let OO = !1;
        return (0, QO.hasUsableWebGpuAdapter)().then((KO => {
          OO || TO(KO)
        })), (0, IK.k)(QO.featureFlags.settings.canUseShaderPacks) && (0, NK.h)().then((async KO => {
          const XO = null !== KO && await async function(OO) {
            const [{
              isShaderPackActive: KO
            }, {
              loadPageShaderPackCompiler: XO
            }] = await Promise.all([pO.e(120).then((() => pO(5791))), Promise.all([pO.e(127), pO.e(124), pO.e(123)]).then((() => pO(5739)))]);
            return KO(OO, await XO())
          }(KO);
          OO || uO(XO)
        })), () => {
          OO = !0
        }
      }), []);
      const YO = function(OO, KO, pO, XO, bK) {
          return (0, yp.b)(pO, XO) && !0 === KO ? {
            translationKey: "settingsMenu:newWebGpuForcedOnByShaderPack",
            checked: !0,
            disabled: !0
          } : {
            translationKey: !1 !== KO ? "settingsMenu:newWebGpu" : bK ? "settingsMenu:newWebGpuDisabledUntilRestart" : "settingsMenu:newWebGpuUnsupported",
            checked: OO && !1 !== KO,
            disabled: !0 !== KO
          }
        }(LO.useWebGpu, dO, gK, EO, jK),
        wO = (LO.useWebGpu || (0, yp.b)(gK, EO)) && gK && !0 === dO,
        iK = (0, FO.i)("lightingOverride"),
        rK = !(0, gp.I)(iK);
      let PO = "settingsMenu:enableLighting";
      rK && (PO = iK ? "settingsMenu:enableLightingForcedOn" : "settingsMenu:enableLightingForcedOff");
      const mK = OO => {
          var KO, pO, XO;
          const bK = null !== (KO = OO.showFog) && void 0 !== KO ? KO : MO("showFog"),
            eO = null !== (pO = OO.antiAliasing) && void 0 !== pO ? pO : LO.antiAliasing,
            lO = null !== (XO = OO.useWebGpu) && void 0 !== XO ? XO : LO.useWebGpu,
            vK = !EK.s && bK !== zK.current || eO !== AO.current || lO !== fO.current;
          oO(vK ? () => NO.j : null)
        },
        sO = (0, FO.i)("fogChunkDistanceOverride"),
        HO = (0, FO.i)("fogBlockDistanceOverride"),
        RO = !(0, gp.I)(sO) || !(0, gp.I)(HO),
        SO = RO ? "settingsMenu:showFogForcedOn" : "settingsMenu:showFog",
        [JO, cK] = (0, fK.e)(hO),
        [BO, ZO] = (0, HK.b)(hO),
        GO = VO("settingsMenu:chunkLoadDistanceDeviceLimit"),
        qK = BO < JO,
        xK = Math.min(null !== (KO = MO("chunkHorizAddDist")) && void 0 !== KO ? KO : hO[0], BO),
        nO = !RO && function(OO, KO) {
          return !0 === OO.showFog && OO.fogChunkDistance > KO
        }(LO, xK);
      return (0, DO.jsxs)("div", {
        className: "SettingsMenuRightInner",
        children: [(0, DO.jsx)(NO.h, {
          name: VO("settingsMenu:horizontalChunkLoadDistance"),
          min: hO[0],
          max: JO,
          selectableMax: BO,
          cappedNote: GO,
          step: 1,
          initValue: xK,
          onChange: OO => {
            !0 === MO("showFog") && OO < MO("fogChunkDistance") && aK("fogChunkDistance", OO), aK("chunkHorizAddDist", OO), uK.i.pl("updatedChunkLoadDist")
          },
          circleInfoText: VO("settingsMenu:chunkLoadDistanceInfo")
        }), (0, DO.jsx)(NO.h, {
          name: VO("settingsMenu:verticalChunkLoadDistance"),
          min: hO[1],
          max: cK,
          selectableMax: ZO,
          cappedNote: qK ? void 0 : GO,
          step: 1,
          initValue: Math.min(null !== (bK = MO("chunkVertAddDist")) && void 0 !== bK ? bK : hO[1], ZO),
          onChange: OO => {
            aK("chunkVertAddDist", OO), uK.i.pl("updatedChunkLoadDist")
          },
          circleInfoText: VO("settingsMenu:chunkLoadDistanceInfo"),
          className: "VerticalChunkLoadSlider"
        }), (0, DO.jsx)(NO.b, {
          label: VO("settingsMenu:chunkFadeIn"),
          checked: LO.chunkFadeIn,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              chunkFadeIn: OO
            })
          },
          circleInfoText: VO("settingsMenu:chunkFadeInInfo")
        }), yK.devTools.supports("chunkBorders") && (0, DO.jsx)(NO.b, {
          label: VO("settingsMenu:showChunkBorders"),
          checked: LO.showChunkBorders,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              showChunkBorders: OO
            })
          },
          circleInfoText: VO("settingsMenu:showChunkBordersInfo")
        }), (0, DO.jsx)(NO.b, {
          label: VO(PO),
          checked: LO.enableLighting,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              enableLighting: OO
            })
          },
          disabled: rK
        }), (0, DO.jsxs)("div", {
          className: "SettingBoxGroup",
          children: [(0, DO.jsx)(NO.b, {
            label: VO(SO),
            checked: LO.showFog,
            onClick: OO => {
              mK({
                showFog: OO
              }), IO.d.setClientEscMenuOptions({
                showFog: OO
              })
            },
            disabled: RO,
            className: eO()({
              SettingBoxWarning: nO
            })
          }), (0, DO.jsx)(NO.h, {
            name: VO("settingsMenu:fogChunkDistance"),
            min: hO[0],
            max: dK.h.maxChunkHorizAddDistance,
            step: 1,
            initValue: null !== (vK = LO.fogChunkDistance) && void 0 !== vK ? vK : hO[0],
            onChange: OO => {
              IO.d.setClientEscMenuOptions({
                fogChunkDistance: OO
              }), uK.i.pl("fogChunkDistanceChanged", OO)
            },
            circleInfoText: VO("settingsMenu:fogChunkDistanceInfo"),
            disabled: RO || !1 === MO("showFog"),
            className: eO()({
              SettingBoxWarning: nO
            })
          }), nO && (0, DO.jsx)("div", {
            className: "SettingBox SettingsBoxWarning",
            children: VO("settingsMenu:fogChunkDistanceInfo")
          })]
        }), !EK.s && (0, DO.jsx)(NO.b, {
          label: VO(wO ? "settingsMenu:disableBlockTextureAtlasUnavailableWithShaderPack" : "settingsMenu:disableBlockTextureAtlas"),
          checked: !wO && LO.disableTexAtlas,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              disableTexAtlas: OO
            })
          },
          circleInfoText: VO("settingsMenu:disableBlockTextureAtlasInfo"),
          disabled: wO
        }), (0, DO.jsx)(NO.h, {
          name: VO("settingsMenu:fieldOfView"),
          min: 50,
          max: 160,
          step: 1,
          initValue: LO.cameraFOV,
          onChange: OO => {
            IO.d.setClientEscMenuOptions({
              cameraFOV: OO
            })
          }
        }), (0, DO.jsx)(NO.b, {
          label: VO("settingsMenu:disableViewBobbing"),
          checked: LO.disableBobbing,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              disableBobbing: OO
            })
          },
          circleInfoText: VO("settingsMenu:disableViewBobbingInfo")
        }), (0, DO.jsx)(NO.b, {
          label: VO("settingsMenu:antiAliasing"),
          checked: LO.antiAliasing,
          onClick: OO => {
            mK({
              antiAliasing: OO
            }), (0, PK.g)("antiAliasing"), IO.d.setClientEscMenuOptions({
              antiAliasing: OO
            })
          },
          circleInfoText: VO("settingsMenu:antiAliasingInfo")
        }), (0, DO.jsx)(NO.h, {
          name: VO("settingsMenu:pixelScale"),
          min: 1,
          max: 8,
          step: 1,
          initValue: null !== (CO = LO.pixelScale) && void 0 !== CO ? CO : 1,
          onChange: OO => {
            (OO !== IO.d.get("clientEscMenuOptions").pixelScale || (0, sK.r)()) && (0, PK.g)("pixelScale"), IO.d.setClientEscMenuOptions({
              pixelScale: OO
            })
          },
          circleInfoText: VO("settingsMenu:pixelScaleInfo"),
          format: OO => `${OO}x`
        }), (0, DO.jsx)(NO.b, {
          label: VO("settingsMenu:pixelSmoothing"),
          checked: LO.pixelSmoothing,
          onClick: OO => {
            IO.d.setClientEscMenuOptions({
              pixelSmoothing: OO
            })
          },
          circleInfoText: VO("settingsMenu:pixelSmoothingInfo")
        }), EK.s && (0, DO.jsx)(NO.b, {
          label: VO("settingsMenu:distantNametags"),
          checked: (0, mp.e)(),
          onClick: OO => {
            IO.d.set({
              showDistantNametags: OO
            })
          },
          circleInfoText: VO("settingsMenu:distantNametagsInfo")
        }), (0, DO.jsx)(NO.b, {
          label: VO(YO.translationKey),
          checked: YO.checked,
          onClick: OO => {
            mK({
              useWebGpu: OO
            }), IO.d.setClientEscMenuOptions({
              useWebGpu: OO
            })
          },
          circleInfoText: VO("settingsMenu:newWebGpuInfo"),
          disabled: YO.disabled
        })]
      })
    }
    var SK = pO(8301),
      JK = pO(7942),
      cp = pO(7947),
      BK = pO(1227),
      ZK = pO(4118),
      GK = pO(8303),
      qp = pO(1583),
      xp = pO(3546),
      nK = pO(1588),
      WK = pO(581);
    const tp = (0, XO.memo)((function() {
      const {
        clientEscMenuOptions: OO
      } = (0, IO.l)(["clientEscMenuOptions"]), {
        recording: KO,
        clipping: pO,
        hasClipBuffer: bK
      } = (0, qp.i)("replayRecorder"), lO = (0, qp.e)("connectedGame", (OO => OO.replay)), vK = (0, xp.l)(), CO = !1 === (0, FO.i)("canRecordReplays");
      (0, XO.useEffect)((() => {
        zK.gameBridge.send("setRecorderPrefs", {
          clipping: OO.enableClipping,
          clipSeconds: OO.clipDurationSeconds
        })
      }), [OO.enableClipping, OO.clipDurationSeconds]);
      const hO = vK || lO,
        MO = !hO && !CO,
        aK = KO || MO,
        oO = MO,
        VO = oO && pO && !KO;

      function QO() {
        aK && zK.gameBridge.send("toggleRecording", null)
      }
      return (0, DO.jsxs)("div", {
        className: "SettingsMenuRightInner ReplayViewerCategory",
        children: [(0, DO.jsxs)("div", {
          className: "SettingBox",
          children: [(0, DO.jsx)("div", {
            className: "ReplayViewerCategoryRecordingRow",
            children: KO ? (0, DO.jsxs)(DO.Fragment, {
              children: [(0, DO.jsxs)(LO.I, {
                className: "ReplayViewerCategoryButton",
                onClick: QO,
                disabled: !aK,
                children: [(0, DO.jsx)("span", {
                  children: "Stop Recording"
                }), (0, DO.jsx)(nK.d, {
                  noaAction: "recordGame"
                })]
              }), (0, DO.jsx)(GK.d, {
                className: "ReplayViewerCategoryRecordingIndicator"
              })]
            }) : (0, DO.jsxs)(LO.d, {
              className: "ReplayViewerCategoryButton",
              onClick: QO,
              disabled: !aK,
              children: [(0, DO.jsx)("span", {
                children: "Start Recording"
              }), (0, DO.jsx)(nK.d, {
                noaAction: "recordGame"
              })]
            })
          }), CO && (0, DO.jsx)("div", {
            className: "ReplayViewerCategoryHint",
            children: "Recording is turned off in this game."
          }), hO && !KO && (0, DO.jsx)("div", {
            className: "ReplayViewerCategoryHint",
            children: "Close Replay Mode to start recording."
          })]
        }), (0, DO.jsxs)("div", {
          className: "SettingBoxGroup",
          children: [(0, DO.jsx)(NO.b, {
            label: "Enable clipping",
            checked: OO.enableClipping,
            disabled: !oO,
            onClick: function(OO) {
              oO && IO.d.setClientEscMenuOptions({
                enableClipping: OO
              })
            },
            className: eO()({
              SettingBoxDisabled: !oO
            })
          }), (0, DO.jsx)(NO.h, {
            name: "Clip duration (seconds)",
            min: WK.g,
            max: WK.d,
            step: WK.b,
            initValue: OO.clipDurationSeconds,
            onChange: function(OO) {
              IO.d.setClientEscMenuOptions({
                clipDurationSeconds: OO
              })
            },
            circleInfoText: "Longer clip durations use more memory and may affect performance.",
            disabled: !oO || !OO.enableClipping
          })]
        }), (0, DO.jsxs)("div", {
          className: "SettingBox",
          children: [(0, DO.jsxs)(LO.d, {
            className: "ReplayViewerCategoryButton",
            onClick: function() {
              VO && zK.gameBridge.send("saveClip", null)
            },
            disabled: !VO,
            children: [(0, DO.jsx)("span", {
              children: "Record clip"
            }), (0, DO.jsx)(nK.d, {
              noaAction: "recordClip"
            })]
          }), OO.enableClipping && !bK && oO && !KO && (0, DO.jsx)("div", {
            className: "ReplayViewerCategoryHint",
            children: "Clip buffer is filling \u2014 play for a moment, then save."
          }), KO && (0, DO.jsx)("div", {
            className: "ReplayViewerCategoryHint",
            children: "Clipping pauses while a full recording is active."
          })]
        }), (0, DO.jsxs)("div", {
          className: "SettingBox",
          children: [(0, DO.jsxs)(LO.d, {
            className: "ReplayViewerCategoryButton",
            onClick: function() {
              (0, xp.i)(!0), IO.d.set({
                openEverythingMenuName: null
              })
            },
            disabled: vK,
            children: [(0, DO.jsx)("span", {
              children: "Open Replay Mode"
            }), (0, DO.jsx)(nK.d, {
              noaAction: "replayViewerOpen"
            })]
          }), vK && (0, DO.jsx)("div", {
            className: "ReplayViewerCategoryHint",
            children: "Replay Mode is already open."
          })]
        }), (0, DO.jsxs)("div", {
          className: "SettingBox",
          children: [(0, DO.jsx)("div", {
            className: "ReplayViewerCategoryTutorialTitle",
            children: "How to use Replay Mode"
          }), (0, DO.jsx)("iframe", {
            className: "ReplayViewerCategoryTutorial",
            src: "https://www.youtube.com/embed/-FsT0rNSuYA?playsinline=1&rel=0",
            title: "How to use Replay Mode",
            allow: "accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
            allowFullScreen: !0,
            loading: "lazy"
          })]
        })]
      })
    }));
    var kp = pO(243),
      UK = pO(1531);
    const Op = {
      account: {
        icon: "fa-solid fa-user",
        displayName: "homePage:account"
      },
      general: {
        icon: "fa-solid fa-gear",
        displayName: "settingsMenu:general"
      },
      audio: {
        icon: "fa-solid fa-volume",
        displayName: "settingsMenu:audio"
      },
      notifications: {
        icon: "fa-solid fa-bell",
        displayName: "notificationSettings:notifications"
      },
      graphics: {
        icon: "fa-solid fa-cube",
        displayName: "settingsMenu:graphics"
      },
      controls: {
        icon: () => (0, DO.jsx)("svg", {
          className: "svg-inline--fa",
          viewBox: "0 0 640 512",
          "aria-hidden": "true",
          children: (0, DO.jsx)("path", {
            fill: "currentColor",
            d: "M256 20H384A36 36 0 0 1 420 56V208A36 36 0 0 1 384 244H256A36 36 0 0 1 220 208V56A36 36 0 0 1 256 20ZM262 166L378 166L320 90ZM36 268H164A36 36 0 0 1 200 304V456A36 36 0 0 1 164 492H36A36 36 0 0 1 0 456V304A36 36 0 0 1 36 268ZM134 438L134 322L58 380ZM256 268H384A36 36 0 0 1 420 304V456A36 36 0 0 1 384 492H256A36 36 0 0 1 220 456V304A36 36 0 0 1 256 268ZM378 346L262 346L320 422ZM476 268H604A36 36 0 0 1 640 304V456A36 36 0 0 1 604 492H476A36 36 0 0 1 440 456V304A36 36 0 0 1 476 268ZM506 322L506 438L582 380Z"
          })
        }),
        displayName: "settingsMenu:controls"
      },
      controller: {
        icon: "fa-solid fa-gamepad",
        displayName: "gamepadSettings:tab"
      },
      texturePack: {
        icon: "fa-solid fa-folder-image",
        displayName: "settingsMenu:texturePack"
      },
      hX: {
        icon: "fa-solid fa-sparkle",
        displayName: "settingsMenu:shaderPack"
      },
      updateLog: {
        icon: "fa-solid fa-clock-rotate-left",
        displayName: "homePage:updateLog"
      },
      information: {
        icon: "fa-solid fa-circle-info",
        displayName: "homePage:info"
      },
      alternativeDomains: {
        icon: "fa-solid fa-globe",
        displayName: "settingsMenu:unblockedDomains"
      },
      replayViewer: {
        icon: "fa-solid fa-video",
        displayName: "Replay Mode"
      },
      developerTools: {
        icon: "fa-solid fa-terminal",
        displayName: "Developer Tools"
      }
    };

    function Kp() {
      return Promise.all([pO.e(127), pO.e(124), pO.e(118), pO.e(115)]).then((() => pO(39133))).then((OO => ({
        default: OO.ShaderPackCategory
      })), (OO => (console.error("Failed to load the shader pack settings", OO), {
        default: pp
      })))
    }

    function pp() {
      const {
        t: OO
      } = (0, lO.D)();
      return (0, DO.jsx)("div", {
        className: "SettingsMenuRightInner",
        children: OO("shaderPack:tabLoadFailed")
      })
    }
    var Xp = pO(1225);
    const bX = (0, XO.lazy)((() => pO.e(252).then((() => pO(39116))).then((OO => ({
        default: OO.BloxdInformation
      }))))),
      ep = (0, XO.lazy)(Kp);

    function lp(OO) {
      return OO ? "general" : "account"
    }
    const vX = new Map,
      Cp = (0, XO.memo)((function(OO) {
        let {
          show: KO,
          setBeforeResumeCallback: pO
        } = OO;
        (0, VO.c)();
        const {
          gameState: bK,
          openSettingsCategory: eO
        } = (0, IO.l)(["gameState", "openSettingsCategory"]), {
          userContext: CO
        } = (0, oO.d)(), {
          t: hO
        } = (0, lO.D)(), dO = (0, aK.b)(), TO = (0, FO.i)("minChunkAddDist"), NO = "inGame" === bK, [yK, uO] = (0, XO.useState)(lp(NO)), [EO, YO] = (0, XO.useState)(null), [wO, iK] = (0, XO.useState)([]), rK = (0, XO.useRef)(function() {
          const OO = new Date,
            KO = 6 * (OO.getMonth() + OO.getDate()) % kp.u.length;
          return [...kp.u, ...kp.u].slice(KO, KO + 6)
        }()), PO = (0, XO.useRef)(null), mK = (0, ap.h)(BK.h, (0, BK.e)()), sO = Object.keys(Op).filter((OO => {
          switch (OO) {
            case "replayViewer":
              return NO;
            case "developerTools":
              return CO.playerHasRank("developer") || !1;
            case "texturePack":
              return QO.featureFlags.settings.canChangeTexturePack;
            case "hX":
              return QO.featureFlags.settings.canUseShaderPacks;
            case "notifications":
              return QO.featureFlags.useSocialFeatures;
            case "alternativeDomains":
              return "crazygames" !== jK.t;
            case "controller":
              return QO.featureFlags.useControllerSupport && (mK || "controller" === yK);
            default:
              return !0
          }
        }));
        (0, ap.f)("toggleFullCoordinateOverlay", (() => {
          const OO = ip("showCoordinates") && ip("showChunkCoordinates") && ip("showFPS");
          rp("showCoordinates", !OO), rp("showChunkCoordinates", !OO), rp("showFPS", !OO), dO()
        })), (0, ap.f)("updatedChunkLoadDist", (() => {
          dO()
        })), (0, XO.useEffect)((() => {
          if (YO(null), null === IO.d.get("openSettingsCategory")) {
            const OO = (0, Xp.h)() ? vX.get(NO) : void 0;
            uO(OO && sO.includes(OO) ? OO : lp(NO))
          }
        }), [KO]), (0, XO.useEffect)((() => {
          null !== eO && (uO(eO), vX.set(NO, eO), IO.d.set({
            openSettingsCategory: null
          }))
        }), [eO, NO]), (0, XO.useLayoutEffect)((() => {
          PO.current && (PO.current.scrollTop = 0)
        }), [yK, KO]), (0, XO.useEffect)((() => {
          "updateLog" === yK && (0, fO.e)().then(iK)
        }), [yK]), (0, XO.useEffect)((() => {
          if ((0, gp.I)(TO)) return;
          const [OO, KO] = (0, SK.e)(), [pO, XO] = (0, fK.e)(TO), bK = (0, UK.g)(TO[0], OO, pO), eO = (0, UK.g)(TO[1], KO, XO);
          zK.gameBridge.send("setChunkAddDistance", {
            horizontal: bK,
            vertical: eO
          })
        }), [TO]);
        const HO = (0, XO.useCallback)((async () => {
          EO && (await EO(), YO(null))
        }), [EO]);

        function RO() {
          IO.d.set({
            openEverythingMenuName: null
          })
        }
        return (0, XO.useEffect)((() => {
          pO((() => HO))
        }), [HO, pO]), (0, DO.jsxs)("div", {
          className: "SettingsMenu Menu",
          style: KO ? {} : {
            display: "none"
          },
          children: [(0, DO.jsx)("div", {
            className: "MenuSideBar",
            children: (0, DO.jsx)("div", {
              className: "MenuSideBarBody",
              children: (0, DO.jsx)(MO, {
                items: sO.map((OO => {
                  const KO = Op[OO].icon;
                  return {
                    id: OO,
                    faIcon: "string" === typeof KO ? KO : void 0,
                    iconElement: "string" === typeof KO ? void 0 : (0, DO.jsx)(KO, {}),
                    title: hO(Op[OO].displayName),
                    redDot: !1
                  }
                })),
                selectedItemId: yK,
                onClick: OO => {
                  !async function(OO) {
                    await HO(), uO(OO), vX.set(NO, OO)
                  }(OO)
                }
              })
            })
          }), (0, DO.jsxs)("div", {
            ref: PO,
            className: "MenuBody SettingsMenuRight",
            children: ["account" === yK && (0, DO.jsx)(XK, {
              showing: KO,
              inGame: NO
            }), "general" === yK && (0, DO.jsx)(hK, {
              inGame: NO
            }), "audio" === yK && (0, DO.jsx)(DK, {}), "notifications" === yK && (0, DO.jsx)(AK, {}), "graphics" === yK && (0, DO.jsx)(RK, {
              minChunkAddDist: null !== TO && void 0 !== TO ? TO : [2, 2],
              getValue: ip,
              onChange: rp,
              setApplySettingsCallback: YO
            }), "controls" === yK && (0, DO.jsx)(JK.h, {}), "controller" === yK && QO.featureFlags.useControllerSupport && (0, DO.jsx)(cp.b, {}), QO.featureFlags.settings.canChangeTexturePack && "texturePack" === yK && (0, DO.jsx)(ZK.c, {
              setApplySettingsCallback: YO
            }), QO.featureFlags.settings.canUseShaderPacks && "hX" === yK && (0, DO.jsx)(XO.Suspense, {
              fallback: null,
              children: (0, DO.jsx)(ep, {
                setApplySettingsCallback: YO
              })
            }), "updateLog" === yK && (0, DO.jsx)("div", {
              className: "SettingsMenuRightInner",
              children: (0, DO.jsx)("div", {
                className: "UpdateLogsContainer",
                children: wO.map(((OO, KO) => (0, DO.jsx)(AO.d, {
                  updateLog: OO,
                  index: KO,
                  close: RO
                }, KO)))
              })
            }), "information" === yK && (0, DO.jsx)("div", {
              className: "SettingsMenuRightInner",
              children: (0, DO.jsx)(XO.Suspense, {
                fallback: null,
                children: (0, DO.jsx)(bX, {})
              })
            }), "alternativeDomains" === yK && (0, DO.jsxs)("div", {
              className: "SettingsMenuRightInner",
              children: [(0, DO.jsx)("div", {
                className: "AlternativeDomainsTitle",
                children: hO("settingsMenu:unblockedDomainsDescription")
              }), (0, DO.jsx)("div", {
                className: "AlternativeDomainsList",
                children: rK.current.map((OO => (0, DO.jsxs)(LO.d, {
                  onClick: () => {
                    window.open(`https://${OO}`)
                  },
                  children: [(0, DO.jsx)(vK.d, {
                    name: "arrow-up-right-from-square"
                  }), " ", OO]
                }, OO)))
              })]
            }), "replayViewer" === yK && (0, DO.jsx)(tp, {}), "developerTools" === yK && (0, DO.jsx)("div", {
              className: "SettingsMenuRightInner",
              children: (0, DO.jsx)(gK, {
                setApplySettingsCallback: YO
              })
            }), null !== EO && (0, DO.jsx)("div", {
              className: "SettingsMenuRightFooter",
              children: (0, DO.jsx)(LO.d, {
                className: "SettingsMenuRightFooterButton",
                onClick: HO,
                children: hO("general:apply")
              })
            })]
          })]
        })
      }));
    var hp = pO(2085);
    const Dp = ["characters", "emote", "skin", "hat", "head", "eyebrows", "eyes", "back", "body", "legs", "shoes", "profileEffect", "cape", "nameColour"],
      Mp = (0, XO.lazy)((() => Promise.resolve().then((() => pO(3821))).then((OO => {
        OO.needGameClientAfterPaint();
        const KO = OO.matchmakingLibrariesPromise.then((OO => (0, hp.b)(OO.loadCharacterCustomisationUI(), (OO => OO.CharacterCustomisationUI))));
        return Promise.all([OO.ensureGameSetup(), KO]).then((OO => {
          let [, KO] = OO;
          return KO
        }))
      }))));

    function aX(OO) {
      let {
        show: KO
      } = OO;
      const {
        userContext: pO
      } = (0, oO.d)(), [bK, eO] = (0, XO.useState)("characters");
      if (!KO) return null;
      const lO = Dp.filter((OO => "cape" !== OO && "nameColour" !== OO || pO.getPlayerRanks().includes("super") || (0, BO.siteSupportsPurchases)())).map((OO => ({
        id: OO,
        faIcon: kp.y[OO],
        title: kp.C[OO],
        redDot: !1
      })));
      return (0, DO.jsxs)("div", {
        className: "Menu CharCustomisation",
        children: [(0, DO.jsx)("div", {
          className: "MenuSideBar",
          children: (0, DO.jsx)(MO, {
            items: lO,
            selectedItemId: bK,
            onClick: OO => {
              eO(OO)
            }
          })
        }), (0, DO.jsx)("div", {
          className: "MenuBody",
          children: (0, DO.jsx)(XO.Suspense, {
            fallback: (0, DO.jsx)("div", {
              className: "CharacterCustomisationLoading",
              children: (0, DO.jsx)(TO.e, {})
            }),
            children: (0, DO.jsx)(Mp, {
              selectedTab: bK
            })
          })
        })]
      })
    }
    var op = pO(1289),
      Fp = pO(8311),
      Vp = pO(3719),
      Lp = pO(2686),
      Qp = pO(2711),
      zX = pO(8333),
      Ap = pO(7833),
      fp = pO(8319),
      dp = pO(8330),
      Tp = pO(1546),
      Np = pO(1533),
      Ip = pO(4035),
      yX = pO(1119),
      gX = pO(1077),
      upO = pO(1473),
      Ep = pO(7927);
    class jX {
      constructor(OO) {
        this.info = OO
      }
      static fromShopInfo(OO) {
        const KO = {};
        for (const pO in OO) {
          const XO = !0 === OO[pO].redDot && !0 !== OO[pO].forceRemoveRedDot;
          KO[pO] = {
            redDot: XO,
            items: {}
          };
          for (const bK in OO[pO].items) {
            const XO = OO[pO].items[bK],
              eO = !0 === XO.redDot && !0 !== XO.forceRemoveRedDot;
            KO[pO].items[bK] = {
              redDot: eO
            }
          }
        }
        return new jX(KO)
      }
      anyCategoryHasRedDots() {
        for (const OO in this.info)
          if (this.categoryHasRedDot(OO)) return !0;
        return !1
      }
      doesCategoryExist(OO) {
        return !(0, gp.I)(this.info[OO])
      }
      categoryHasRedDot(OO) {
        return !0 === this.info[OO].redDot
      }
      updateCategoryRedDot(OO, KO) {
        this.info[OO].redDot = KO
      }
      doesItemExist(OO, KO) {
        return this.doesCategoryExist(OO) && !(0, gp.I)(this.info[OO].items[KO])
      }
      itemHasRedDot(OO, KO) {
        return !0 === this.info[OO].items[KO].redDot
      }
      updateItemRedDot(OO, KO, pO) {
        this.info[OO].items[KO].redDot = pO
      }
      shallowCopy() {
        return new jX(this.info)
      }
    }

    function Yp(OO, KO) {
      return `${OO}\x1f${KO}`
    }

    function wp(OO) {
      return OO ? Object.keys(OO).sort(((KO, pO) => {
        var XO, bK, eO, lO;
        const vK = (null !== (XO = null === (bK = OO[pO]) || void 0 === bK ? void 0 : bK.sortPriority) && void 0 !== XO ? XO : 0) - (null !== (eO = null === (lO = OO[KO]) || void 0 === lO ? void 0 : lO.sortPriority) && void 0 !== eO ? eO : 0);
        return 0 !== vK ? vK : KO.localeCompare(pO)
      })) : []
    }

    function iX(OO, KO) {
      return !(0, gp.I)(KO) && !(0, gp.I)(OO) && KO in OO
    }
    const rX = (0, XO.memo)((function(OO) {
      var KO, pO;
      let {
        show: bK
      } = OO;
      const lO = (0, qp.e)("players", Sp),
        vK = (0, qp.e)("players", Jp),
        [hO, aK] = (0, XO.useState)({
          shopInfo: {},
          userInputsPerItem: {},
          redDotInfo: jX.fromShopInfo({}),
          currencyAmounts: {},
          selectedCategoryKey: null,
          onBoughtInfo: null,
          awaitingPurchase: !1
        }),
        oO = (0, XO.useRef)(""),
        VO = (0, XO.useRef)(null),
        QO = (0, XO.useRef)(0),
        AO = (0, XO.useRef)(void 0),
        fO = (0, XO.useRef)(null),
        dO = (0, XO.useRef)(hO),
        TO = hO.redDotInfo.anyCategoryHasRedDots(),
        [NO, yK] = (0, XO.useState)(null),
        gK = (0, XO.useRef)(!1);
      let uO = !1,
        EO = 0,
        YO = 0;
      if (hO.currencyAmounts) {
        for (const OO in hO.currencyAmounts) {
          var wO;
          const KO = hO.currencyAmounts[OO];
          KO.hidden || (EO++, (null === (wO = KO.subtext) || void 0 === wO ? void 0 : wO.length) > 0 && YO++)
        }
        uO = EO + YO > 4
      }(0, XO.useEffect)((() => {
        uK.i.pl("showShopIconRedDot", TO, !0)
      }), [TO]), (0, XO.useEffect)((() => {
        zK.gameBridge.send("setShopOpen", bK), bK || (clearTimeout(AO.current), aK((OO => OO.awaitingPurchase ? {
          ...OO,
          awaitingPurchase: !1
        } : OO)))
      }), [bK]), (0, XO.useEffect)((() => () => {
        zK.gameBridge.send("setShopOpen", !1), clearTimeout(AO.current)
      }), []), (0, XO.useEffect)((() => {
        dO.current = hO
      }), [hO]), (0, XO.useEffect)((() => {
        if (null === NO) return;
        return (0, upO.b)("pointerdown", (OO => {
          const KO = OO.target;
          null !== KO && void 0 !== KO && KO.closest(".ShopItem") || yK(null)
        }))
      }), [NO]);
      const rK = OO => {
          aK((KO => ({
            ...KO,
            ...OO
          })))
        },
        PO = OO => {
          var KO;
          clearTimeout(null === (KO = hO.onBoughtInfo) || void 0 === KO ? void 0 : KO.timeout);
          const pO = setTimeout((() => {
            rK({
              onBoughtInfo: null
            })
          }), 3e3);
          oO.current = OO, rK({
            onBoughtInfo: {
              text: OO,
              timeout: pO
            }
          })
        },
        mK = OO => {
          const {
            shopInfo: KO,
            userInputsPerItem: pO,
            redDotInfo: XO,
            autoSelectCategory: eO
          } = function(OO, KO, pO, XO, bK, eO) {
            if ((0, gp.I)(OO) || 0 === Object.keys(OO).length) return {
              shopInfo: {},
              userInputsPerItem: {},
              redDotInfo: jX.fromShopInfo({}),
              autoSelectCategory: null
            };
            const lO = jK.p[jK.t].adConfig.showRewardedAds,
              vK = {};
            let CO = null;
            for (const LO in OO) {
              const KO = OO[LO],
                pO = {};
              let XO = !1;
              for (const OO in KO.items) {
                const bK = KO.items[OO];
                (0, Ap.i)(bK, lO) && (pO[OO] = bK, XO = !0)
              }
              XO && (vK[LO] = {
                ...KO,
                items: pO
              }, !0 === KO.autoSelectCategory && (CO = LO))
            }
            const hO = {},
              DO = (OO, KO, XO, lO) => {
                var vK, CO;
                const DO = Yp(OO, KO),
                  MO = null !== (vK = pO[DO]) && void 0 !== vK ? vK : pO[KO];
                if (null !== (CO = lO.userInput) && void 0 !== CO && CO.type) switch (lO.userInput.type) {
                  case "dropdown": {
                    var aK;
                    const OO = !MO || !lO.userInput.dropdownOptions.some((OO => (0, Ap.f)(OO) === MO)),
                      KO = lO.userInput.shouldResetSelectionOnOptionsChange && ("dropdown" !== (null === XO || void 0 === XO || null === (aK = XO.userInput) || void 0 === aK ? void 0 : aK.type) || JSON.stringify(XO.userInput.dropdownOptions) !== JSON.stringify(lO.userInput.dropdownOptions)),
                      pO = lO.userInput,
                      bK = !(0, gp.I)(pO.initialValue) && pO.dropdownOptions.some((OO => (0, Ap.f)(OO) === pO.initialValue));
                    var oO;
                    return void(OO || KO ? bK ? hO[DO] = null !== (oO = lO.userInput.initialValue) && void 0 !== oO ? oO : null : lO.userInput.dropdownOptions.length > 0 ? hO[DO] = (0, Ap.f)(lO.userInput.dropdownOptions[0]) : hO[DO] = null : hO[DO] = MO)
                  }
                  case "text":
                  case "number":
                    var FO, VO, LO;
                    return void((null === XO || void 0 === XO ? void 0 : XO.userInput) !== lO.userInput ? hO[DO] = null !== (FO = null !== (VO = lO.userInput.initialValue) && void 0 !== VO ? VO : MO) && void 0 !== FO ? FO : "" : hO[DO] = null !== (LO = null !== MO && void 0 !== MO ? MO : lO.userInput.initialValue) && void 0 !== LO ? LO : "");
                  case "color":
                    var QO, zK, AO;
                    return void((null === XO || void 0 === XO ? void 0 : XO.userInput) !== lO.userInput ? hO[DO] = null !== (QO = null !== (zK = lO.userInput.initialValue) && void 0 !== zK ? zK : MO) && void 0 !== QO ? QO : "#000000" : hO[DO] = null !== (AO = null !== MO && void 0 !== MO ? MO : lO.userInput.initialValue) && void 0 !== AO ? AO : "#000000");
                  case "player": {
                    const OO = (0, Ap.g)(bK, eO, lO.userInput);
                    return void(MO && OO.includes(MO) ? hO[DO] = MO : hO[DO] = OO.length > 0 ? OO[0] : null)
                  }
                }
              };
            for (const LO in vK)
              for (const OO in vK[LO].items) {
                var MO;
                const pO = vK[LO].items[OO];
                DO(LO, OO, null === (MO = KO[LO]) || void 0 === MO ? void 0 : MO.items[OO], pO)
              }
            const aK = jX.fromShopInfo(vK);
            for (const LO in vK) {
              var oO;
              if (XO.doesCategoryExist(LO)) {
                (null === (oO = KO[LO]) || void 0 === oO ? void 0 : oO.redDot) === vK[LO].redDot && aK.updateCategoryRedDot(LO, XO.categoryHasRedDot(LO));
                for (const OO in vK[LO].items) {
                  var FO, VO;
                  XO.doesItemExist(LO, OO) && (null === (FO = KO[LO]) || void 0 === FO || null === (VO = FO.items[OO]) || void 0 === VO ? void 0 : VO.redDot) === vK[LO].items[OO].redDot && aK.updateItemRedDot(LO, OO, XO.itemHasRedDot(LO, OO))
                }
              }
            }
            return {
              shopInfo: vK,
              userInputsPerItem: hO,
              redDotInfo: aK,
              autoSelectCategory: CO
            }
          }(OO, hO.shopInfo, hO.userInputsPerItem, hO.redDotInfo, lO, vK), CO = {
            shopInfo: KO,
            userInputsPerItem: pO,
            redDotInfo: XO
          };
          if (null === eO || bK)
            if (KO[hO.selectedCategoryKey]) CO.selectedCategoryKey = hO.selectedCategoryKey;
            else {
              const OO = wp(KO);
              CO.selectedCategoryKey = OO.length > 0 ? OO[0] : null
            }
          else CO.selectedCategoryKey = eO;
          return 0 === Object.keys(KO).length && bK && IO.d.set({
            openEverythingMenuName: null
          }), CO
        },
        sO = (OO, KO) => {
          if (null === KO || !OO.shopInfo[KO]) return OO;
          let pO = OO.redDotInfo;
          return pO.categoryHasRedDot(KO) && (pO.updateCategoryRedDot(KO, !1), pO = pO.shallowCopy()), {
            ...OO,
            selectedCategoryKey: KO,
            redDotInfo: pO
          }
        },
        HO = OO => {
          aK((KO => sO(KO, OO)))
        };
      (0, ap.f)(Ep.f, (() => {
        aK((OO => {
          const KO = (0, Ep.j)(wp(OO.shopInfo), OO.selectedCategoryKey, (KO => (0, Ep.e)(OO.shopInfo[KO].items)));
          return KO === OO.selectedCategoryKey ? OO : sO(OO, KO)
        }))
      })), (0, ap.f)("showShopFromServer", (OO => {
        let {
          toggle: KO,
          DW: pO
        } = OO;
        pO && HO(pO), 0 === Object.keys(hO.shopInfo).length || KO && bK ? IO.d.set({
          openEverythingMenuName: null
        }) : IO.d.set({
          openEverythingMenuName: kp.o.SHOP
        })
      })), (0, ap.f)("closeShopOnDamaged", (() => {
        bK && IO.d.set({
          openEverythingMenuName: null
        })
      })), (0, ap.f)("overShopInfo", (OO => {
        PO(OO)
      })), (0, FO.f)("currencyAmounts", (OO => {
        var KO;
        const pO = fO.current;
        pO && (null === OO || void 0 === OO || null === (KO = OO[pO.currency]) || void 0 === KO ? void 0 : KO.amount) === pO.amountBefore ? rK({
          currencyAmounts: OO
        }) : (fO.current = null, rK({
          currencyAmounts: OO,
          awaitingPurchase: !1
        }))
      })), (0, FO.f)("shopInfo", (OO => {
        rK({
          ...mK(OO),
          awaitingPurchase: !1
        })
      }));
      const RO = (0, XO.useRef)({
        playerIds: lO,
        localPlayerId: vK
      });
      (0, XO.useEffect)((() => {
        RO.current.playerIds === lO && RO.current.localPlayerId === vK || (RO.current = {
          playerIds: lO,
          localPlayerId: vK
        }, aK((OO => {
          const KO = mK(OO.shopInfo);
          return {
            ...OO,
            ...KO
          }
        })))
      }), [lO, vK]);
      const SO = hO.selectedCategoryKey,
        cK = (OO, KO) => {
          var pO, XO;
          return (isNaN(KO) || (0, gp.I)(OO.currency) || iX(hO.currencyAmounts, OO.currency) && KO <= hO.currencyAmounts[OO.currency].amount) && (null === (pO = OO.canBuy) || void 0 === pO || pO) && !(null !== (XO = OO.hidden) && void 0 !== XO && XO)
        },
        BO = (OO, KO) => {
          var pO, XO, bK;
          const lO = Yp(SO, OO),
            vK = hO.shopInfo[SO].items[OO],
            MO = hO.userInputsPerItem[lO],
            aK = (0, Ap.e)(vK, MO),
            oO = cK(vK, aK),
            FO = vK.enchant,
            VO = FO ? (0, JO.ob)(null !== (pO = vK.customTitle) && void 0 !== pO ? pO : OO, {
              colour: JO.hb[FO.tier]
            }) : null !== (XO = vK.customTitle) && void 0 !== XO ? XO : OO,
            TO = KO => {
              const pO = null !== KO && void 0 !== KO ? KO : MO,
                XO = void 0 !== KO ? (0, Ap.e)(vK, KO) : aK;
              cK(vK, XO) && null !== pO && ((OO, KO, pO) => {
                const XO = hO.selectedCategoryKey,
                  bK = Yp(XO, OO),
                  eO = null !== pO && void 0 !== pO ? pO : hO.userInputsPerItem[bK],
                  lO = {
                    categoryKey: XO,
                    itemKey: OO,
                    userInput: eO
                  };
                if (KO.isRewardedAd) {
                  if (Date.now() - QO.current < 5e3) return;
                  (0, iK.mb)((() => {
                    var pO, XO, eO;
                    console.log("bought rewarded ad");
                    const vK = lO.categoryKey ? null === (pO = dO.current.shopInfo[lO.categoryKey]) || void 0 === pO ? void 0 : pO.items[OO] : null;
                    vK && vK.isRewardedAd ? (null === (XO = KO.userInput) || void 0 === XO ? void 0 : XO.type) === (null === vK || void 0 === vK || null === (eO = vK.userInput) || void 0 === eO ? void 0 : eO.type) ? (lO.userInput = dO.current.userInputsPerItem[bK], zK.gameBridge.send("buyShopItem", lO), KO.onBoughtMessage && PO(KO.onBoughtMessage)) : console.warn("Shop item input type changed, early out") : console.warn("Shop item no longer valid or a rewarded ad, early out")
                  })), QO.current = Date.now()
                } else {
                  zK.gameBridge.send("buyShopItem", lO), rK({
                    awaitingPurchase: !0
                  }), clearTimeout(AO.current), AO.current = setTimeout((() => {
                    fO.current = null, rK({
                      awaitingPurchase: !1
                    })
                  }), 1e3);
                  const OO = (0, Ap.e)(KO, eO);
                  if (fO.current = null, !isNaN(OO) && iX(hO.currencyAmounts, KO.currency)) {
                    0 !== OO && (fO.current = {
                      currency: KO.currency,
                      amountBefore: hO.currencyAmounts[KO.currency].amount
                    });
                    const pO = {
                      ...hO.currencyAmounts
                    };
                    pO[KO.currency].amount -= OO, rK({
                      currencyAmounts: pO
                    })
                  }
                  KO.onBoughtMessage && PO(KO.onBoughtMessage)
                }
              })(OO, vK, KO);
              let bK = hO.redDotInfo;
              bK.itemHasRedDot(SO, OO) && (bK.updateItemRedDot(SO, OO, !1), bK = bK.shallowCopy()), rK({
                redDotInfo: bK
              })
            };
          return (0, DO.jsxs)("div", {
            className: eO()("ShopItem", {
              ShopItemNoInput: !vK.userInput,
              ShopItemNoInputCanBuy: !vK.userInput && oO,
              ShopItemNoInputSelected: vK.isSelected,
              ShopItemEnchant: !!FO
            }),
            "data-pad-focusable": !vK.userInput || void 0,
            "data-pad-unavailable": !vK.userInput && !oO || void 0,
            "data-pad-repeat": null !== (bK = (0, Ep.b)(vK)) && void 0 !== bK ? bK : void 0,
            "data-pad-repeat-wait": hO.awaitingPurchase || void 0,
            onClick: () => {
              if (FO && gK.current) {
                if (NO !== lO) return void yK(lO);
                yK(null)
              }
              vK.userInput || TO()
            },
            onPointerDown: OO => {
              FO && (gK.current = (0, dp.t)(OO))
            },
            onPointerEnter: OO => {
              FO && !(0, dp.t)(OO) && yK(lO)
            },
            onPointerLeave: OO => {
              FO && !(0, dp.t)(OO) && yK((OO => OO === lO ? null : OO))
            },
            style: {
              zIndex: Object.keys(hO.shopInfo[SO].items).length - KO
            },
            children: [hO.redDotInfo.itemHasRedDot(SO, OO) && (0, DO.jsx)(CO.e, {
              top: "-6px",
              right: "-6px"
            }), vK.badge && (0, DO.jsx)("div", {
              className: "ShopBadgeContainer",
              children: (0, DO.jsx)("div", {
                className: eO()("ShopBadgeMain", vK.badge.type),
                children: (0, DO.jsx)(Np.d, {
                  text: vK.badge.text
                })
              })
            }), (0, DO.jsx)("div", {
              className: "ShopItemLeft",
              children: vK.image && (0, DO.jsx)(Pp, {
                item: vK,
                minWidth: 5,
                minHeight: 4.8
              })
            }), (0, DO.jsxs)("div", {
              className: "ShopItemRight",
              children: [(0, DO.jsxs)("div", {
                className: "ShopItemHeader",
                children: [(0, DO.jsx)("div", {
                  className: "ShopItemHeaderTitle",
                  children: (0, DO.jsx)(Np.d, {
                    text: VO
                  })
                }), (0, DO.jsx)("div", {
                  className: "ShopItemHeaderDescription",
                  children: (0, DO.jsx)(Np.d, {
                    text: vK.description
                  })
                })]
              }), vK.userInput && (0, DO.jsxs)("div", {
                className: "ShopItemInputsContainer",
                onClick: OO => {
                  OO.stopPropagation()
                },
                children: [(0, DO.jsx)(Hp, {
                  item: vK,
                  currInput: MO,
                  updateInput: KO => {
                    ((OO, KO, pO) => {
                      const XO = Yp(OO, KO),
                        bK = {
                          ...hO.userInputsPerItem
                        };
                      bK[XO] = pO, rK({
                        userInputsPerItem: bK
                      })
                    })(SO, OO, KO)
                  },
                  onSubmit: OO => {
                    TO(OO)
                  }
                }), ("dropdown" !== vK.userInput.type || !vK.userInput.autoSubmit) && (0, DO.jsx)(LO.d, {
                  className: "ItemCostButton",
                  disabled: !oO && null !== MO,
                  onClick: () => {
                    TO()
                  },
                  children: (0, DO.jsx)(sp, {
                    item: vK,
                    cost: aK,
                    currencyAmounts: hO.currencyAmounts
                  })
                })]
              })]
            }), !vK.userInput && (0, DO.jsx)("div", {
              className: "ShopItemNoInputCost",
              children: (0, DO.jsx)(sp, {
                item: vK,
                cost: aK,
                currencyAmounts: hO.currencyAmounts
              })
            }), FO && NO === lO && (0, DO.jsxs)("div", {
              className: "ShopItemEnchantInfo SmallTextBold",
              children: [(0, DO.jsx)(Np.d, {
                text: VO
              }), (0, DO.jsx)("div", {
                className: "ShopItemEnchantInfoDescription",
                children: (0, DO.jsx)(Np.d, {
                  text: (0, fp.b)("", FO.enchantments, FO.enchantmentData)
                })
              })]
            })]
          }, lO)
        };
      return (0, DO.jsx)(Lp.b, {
        className: "Menu ShopBody",
        show: bK,
        children: 0 !== Object.keys(hO.shopInfo).length && (0, DO.jsxs)(DO.Fragment, {
          children: [(0, DO.jsxs)("div", {
            className: "MenuSideBar",
            children: [(0, DO.jsx)(MO, {
              items: wp(hO.shopInfo).map((OO => {
                var KO;
                return {
                  id: OO,
                  title: null !== (KO = hO.shopInfo[OO].customTitle) && void 0 !== KO ? KO : OO,
                  redDot: hO.redDotInfo.categoryHasRedDot(OO)
                }
              })),
              selectedItemId: SO,
              onClick: HO,
              padStartsOnTab: (0, Ep.c)(SO)
            }), (0, DO.jsx)("div", {
              className: "MenuSideBarFooter",
              children: hO.currencyAmounts && Object.keys(hO.currencyAmounts).map((OO => {
                var KO;
                const pO = hO.currencyAmounts[OO];
                return pO.hidden ? null : (0, DO.jsxs)("div", {
                  className: "ShopCurrencyDiv " + (uO ? "SmallText" : ""),
                  children: [(0, DO.jsxs)("div", {
                    className: "ShopCurrencyDetails",
                    children: [(0, DO.jsx)("div", {
                      className: "ShopCurrencyAmtIcon",
                      style: {
                        color: pO.iconColour
                      },
                      children: (0, DO.jsx)(cX, {
                        iconName: pO.icon
                      })
                    }), "\xa0", (0, zX.c)(pO.amount, 6)]
                  }), (null === (KO = pO.subtext) || void 0 === KO ? void 0 : KO.length) > 0 && (0, DO.jsx)("div", {
                    className: "ShopCurrencySubtext",
                    children: (0, DO.jsx)(Np.d, {
                      text: pO.subtext
                    })
                  })]
                }, OO)
              }))
            })]
          }), (0, DO.jsxs)("div", {
            className: "MenuBody ShopMenuBody",
            children: [(0, DO.jsx)("div", {
              className: eO()("ShopOnBoughtInfo", {
                ShopOnBoughtInfoShow: null !== hO.onBoughtInfo
              }),
              children: (0, DO.jsx)(Np.d, {
                text: oO.current
              })
            }), (0, DO.jsx)("div", {
              className: "ShopItemsWrapper",
              children: (0, DO.jsxs)("div", {
                className: "ShopItemsInner",
                children: [(null === (KO = hO.shopInfo[SO]) || void 0 === KO ? void 0 : KO.description) && (0, DO.jsx)("div", {
                  className: "ShopCategoryDescription",
                  children: (0, DO.jsx)(Np.d, {
                    text: hO.shopInfo[SO].description
                  })
                }), bK && (0, DO.jsx)("div", {
                  className: "ShopItems",
                  ref: VO,
                  "data-pad-initial-area": !0,
                  children: wp(null === (pO = hO.shopInfo[SO]) || void 0 === pO ? void 0 : pO.items).map(((OO, KO) => BO(OO, KO)))
                })]
              })
            })]
          })]
        })
      })
    }));

    function Pp(OO) {
      let {
        item: KO,
        minWidth: pO,
        minHeight: XO
      } = OO;
      const {
        image: bK,
        schematicId: eO,
        imageColour: lO
      } = KO;
      if (eO) return (0, DO.jsx)("div", {
        className: "ShopSchematic",
        style: {
          width: `${pO}rem`,
          height: `${XO}rem`
        },
        children: (0, DO.jsx)(Ip.b, {
          game: {
            schematicId: eO
          }
        })
      });
      var CO, hO;
      if ((0, Tp.d)(bK)) return (0, DO.jsx)("div", {
        className: "ShopBlock",
        style: {
          minWidth: `${pO}rem`,
          height: "0",
          minHeight: `${XO}rem`
        },
        children: (0, DO.jsx)(Tp.b, {
          itemName: bK,
          amount: null !== (CO = KO.amount) && void 0 !== CO ? CO : 0,
          amountFontSize: XO / 4 + "rem",
          enchantmentTier: null === (hO = KO.enchant) || void 0 === hO ? void 0 : hO.tier
        })
      });
      const MO = bK.slice(-4);
      return ".jpg" === MO || ".png" === MO ? (0, DO.jsx)(mX, {
        image: bK,
        minWidth: pO
      }) : (0, DO.jsx)(vK.d, {
        name: bK,
        className: "SelectedItemImage",
        style: {
          color: lO
        }
      })
    }

    function mX(OO) {
      let {
        image: KO,
        minWidth: pO
      } = OO;
      const {
        gameNameWithVariation: XO
      } = (0, qp.i)("connectedGame"), bK = KO.endsWith(".jpg");
      return (0, DO.jsx)("img", {
        className: eO()({
          ShopPixelImage: !bK
        }),
        style: {
          width: `${bK?1.6*pO:pO}rem`,
          height: "auto",
          fontSize: "1.25rem"
        },
        src: `/textures/games/${(0,JO.Qb)(XO)}/${KO}`,
        alt: KO,
        draggable: !1
      })
    }

    function sp(OO) {
      let {
        item: KO,
        cost: pO,
        currencyAmounts: XO
      } = OO;
      const bK = !isNaN(pO) && 0 !== pO && iX(XO, KO.currency);
      let eO = null;
      return KO.buyButtonText ? eO = KO.buyButtonText : bK ? (eO = pO, KO.sell && (eO = -1 * pO), eO = eO.toString()) : 0 === pO ? eO = "Free" : KO.isRewardedAd && (eO = "Watch ad"), (0, gp.I)(eO) || " " === eO ? null : (0, DO.jsxs)("div", {
        className: "BuyItemCostAndIcon",
        children: [bK && (0, DO.jsx)("div", {
          style: {
            color: XO[KO.currency].iconColour
          },
          className: "BuyItemIcon",
          children: (0, DO.jsx)(cX, {
            iconName: XO[KO.currency].icon
          })
        }), (0, DO.jsx)("div", {
          className: "BuyItemCost",
          children: (0, DO.jsx)(Np.d, {
            text: eO
          })
        })]
      })
    }

    function Hp(OO) {
      let {
        item: KO,
        currInput: pO,
        updateInput: bK,
        onSubmit: eO
      } = OO;
      const {
        t: vK
      } = (0, lO.D)(), CO = (0, XO.useRef)(null);
      if ((0, XO.useEffect)((() => {
          const OO = CO.current;
          OO && OO.value !== pO && document.activeElement !== OO && (OO.value = null !== pO && void 0 !== pO ? pO : "")
        }), [pO]), !KO.userInput) return null;
      let hO = KO.userInput;
      if (QO.featureFlags.sanitizeShopInput && "text" === KO.userInput.type && (hO = {
          type: "number",
          placeholderText: "Numbers Only"
        }), "text" === hO.type || "number" === hO.type) {
        var MO, aK;
        console.assert(void 0 !== pO, `Rendered ItemUserInput but currInput is undefined. Item: ${JSON.stringify(KO)}`);
        const OO = "text" === hO.type && hO.wordCharsOnly;
        return (0, DO.jsx)("div", {
          className: "ShopItemUserInput ShopItemUserInputTextWrapper",
          children: (0, DO.jsx)(dO.e, {
            className: "ShopItemUserInputText",
            placeholderText: vK(hO.placeholderText),
            defaultValue: pO,
            domRef: CO,
            onValueChange: (KO, pO) => {
              !0 === OO && (KO = (0, gX.eb)(KO)), CO.current.value = KO, bK(KO)
            },
            onEnter: eO,
            type: hO.type
          }, (null !== (MO = hO.initialValue) && void 0 !== MO ? MO : "") + (null !== (aK = hO.placeholderText) && void 0 !== aK ? aK : ""))
        })
      }
      if ("dropdown" === hO.type) {
        console.assert(void 0 !== pO, `Rendered ItemUserInput but currInput is undefined. Item: ${JSON.stringify(KO)}`);
        const OO = hO.autoSubmit;
        return (0, DO.jsx)("div", {
          className: "ShopItemUserInput ShopItemUserInputDropdown",
          children: (0, DO.jsx)(lK.b, {
            options: hO.dropdownOptions.map((OO => (0, Ap.f)(OO))),
            value: pO,
            onChange: KO => {
              let {
                value: pO
              } = KO;
              bK(pO), OO && eO(pO)
            }
          })
        })
      }
      return "player" === hO.type ? (0, DO.jsx)(Rp, {
        userInput: hO,
        currInput: pO,
        updateInput: bK
      }) : "color" === hO.type ? (0, DO.jsx)("div", {
        className: "ShopItemUserInput ShopItemUserInputColor",
        children: (0, DO.jsx)("input", {
          type: "color",
          value: pO,
          onChange: OO => {
            bK(OO.target.value)
          }
        })
      }) : null
    }

    function Rp(OO) {
      let {
        userInput: KO,
        currInput: pO,
        updateInput: XO
      } = OO;
      const bK = (0, qp.i)("players"),
        eO = (0, qp.i)("hiddenPlayerNames"),
        lO = (0, Ap.g)(bK.ids, bK.localId, KO);
      return (0, DO.jsx)("div", {
        className: "ShopItemUserInput ShopItemUserInputDropdown",
        children: (0, DO.jsx)(lK.b, {
          options: lO.map((OO => {
            const {
              name: KO
            } = bK.byId[OO];
            return {
              value: OO,
              label: null === KO ? "" : (0, yX.f)(KO, eO)
            }
          })),
          value: pO,
          onChange: OO => {
            let {
              value: KO
            } = OO;
            XO(KO)
          }
        })
      })
    }

    function Sp(OO) {
      let {
        ids: KO
      } = OO;
      return KO
    }

    function Jp(OO) {
      let {
        localId: KO
      } = OO;
      return KO
    }

    function cX(OO) {
      let {
        iconName: KO
      } = OO;
      return zK.gameBridge.lookup("isItemName", KO) ? (0, DO.jsx)(Tp.b, {
        itemName: KO,
        amount: 1
      }) : (0, DO.jsx)(vK.d, {
        name: KO,
        className: "2x"
      })
    }
    var Bp = pO(1441);
    const Zp = (0, pO(1232).j)((OO => OO.PadLobbyShortcuts)),
      Gp = (0, XO.lazy)((() => Promise.resolve().then((() => pO(3821))).then((OO => ({
        default: OO.Lobbyleaderboard
      })))));

    function qX(OO) {
      let {
        show: KO
      } = OO;
      return KO ? (0, DO.jsxs)(DO.Fragment, {
        children: [(0, DO.jsx)(Zp, {}), (0, DO.jsx)(XO.Suspense, {
          fallback: (0, DO.jsx)("div", {
            className: "CharacterCustomisationLoading",
            children: (0, DO.jsx)(TO.e, {})
          }),
          children: (0, DO.jsx)(Gp, {})
        })]
      }) : null
    }
    var xX = pO(1388),
      np = pO(2358),
      Wp = pO(1481),
      tX = pO(2151),
      kX = pO(1326),
      Up = pO(1273),
      OX = pO(2329),
      KX = pO(1723),
      pX = pO(2349),
      XX = pO(1896);
    const bb = "storeRecentGiftRecipients",
      eX = new Map;

    function lX() {
      try {
        const OO = jp.e.getItem(bb);
        return Array.isArray(OO) ? OO.filter((OO => "string" === typeof(null === OO || void 0 === OO ? void 0 : OO.name) && OO.name.length > 0)).map((OO => ({
          name: OO.name,
          cosmetics: OO.cosmetics && "object" === typeof OO.cosmetics ? OO.cosmetics : null
        }))) : []
      } catch {
        return []
      }
    }

    function vb(OO) {
      var KO;
      const [pO, bK] = (0, XO.useState)(""), [eO, lO] = (0, XO.useState)("search"), [vK, CO] = (0, XO.useState)(null), [hO, DO] = (0, XO.useState)(null), MO = (0, XO.useRef)(null), aK = (0, XO.useRef)(null);
      (0, XO.useEffect)((() => () => {
        MO.current && clearTimeout(MO.current)
      }), []);
      const oO = null !== (KO = null === vK || void 0 === vK ? void 0 : vK.name) && void 0 !== KO ? KO : null;

      function FO() {
        MO.current && (clearTimeout(MO.current), MO.current = null)
      }(0, XO.useEffect)((() => {
        if (null === oO || OO === YO.NULL_USER_CONTEXT) return;
        const KO = oO.toLowerCase();
        if (KO === OO.getPlayerName().toLowerCase()) return void DO({
          name: oO,
          result: {
            giftRecipientFound: !1,
            giftRecipientError: "store:giftRecipientIsYou"
          }
        });
        const pO = eX.get(KO);
        if (pO) return void DO({
          name: oO,
          result: pO
        });
        let XO = !1;
        return async function(OO, KO) {
          try {
            const pO = await (0, YO.postJsonWithMetricsCookiesAndJsonResponse)(`${wO.clientSideServerUrls.indexUrl}/index/xsolla/gift-recipient`, {
              giftRecipientName: KO
            }, {
              retries: 1
            }, OO.getMetricsCookies());
            if ("boolean" !== typeof(null === pO || void 0 === pO ? void 0 : pO.giftRecipientFound)) throw new Error(`Unexpected gift recipient lookup response: ${JSON.stringify(pO)}`);
            return pO
          } catch (pO) {
            return console.error("Failed to look up gift recipient:", pO), {
              giftRecipientFound: !1,
              giftRecipientError: "store:giftRecipientLookupFailed"
            }
          }
        }(OO, oO).catch((OO => (console.error("Gift recipient lookup failed:", OO), {
          giftRecipientFound: !1,
          giftRecipientError: "store:giftRecipientLookupFailed"
        }))).then((OO => {
          !0 !== OO.giftRecipientFound && "store:giftRecipientLookupFailed" === OO.giftRecipientError || eX.set(KO, OO), XO || DO({
            name: oO,
            result: OO
          })
        })), () => {
          XO = !0
        }
      }), [oO, OO]);
      const VO = (0, XO.useMemo)((() => {
        const OO = pO.trim();
        if (!OO) return {
          status: "none"
        };
        if (!vK || vK.name !== OO || (null === hO || void 0 === hO ? void 0 : hO.name) !== vK.name) return {
          status: "pending",
          name: OO
        };
        const KO = hO.result;
        return !1 === KO.giftRecipientFound ? {
          status: "error",
          name: vK.name,
          error: KO.giftRecipientError
        } : {
          status: "found",
          name: KO.giftRecipientName,
          ownedPacks: KO.giftRecipientOwnedPacks,
          superRankDaysLeft: KO.giftRecipientSuperRankDaysLeft
        }
      }), [pO, vK, hO]);
      (0, XO.useEffect)((() => {
        "found" === VO.status && "typed" === (null === vK || void 0 === vK ? void 0 : vK.source) && aK.current !== VO.name && (aK.current = VO.name, (0, xK.e)({
          id: "store.gift_recipient",
          value: "typed"
        }))
      }), [VO, vK]);
      const LO = (null === hO || void 0 === hO ? void 0 : hO.name) === (null === vK || void 0 === vK ? void 0 : vK.name) ? null === hO || void 0 === hO ? void 0 : hO.result : null,
        QO = !0 === (null === LO || void 0 === LO ? void 0 : LO.giftRecipientFound) ? LO.giftRecipientCosmetics : null;
      return {
        query: pO,
        via: eO,
        recipient: VO,
        recipientCosmetics: QO,
        type: function(OO) {
          bK(OO), lO("search"), FO();
          const KO = OO.trim();
          KO ? MO.current = setTimeout((() => {
            CO({
              name: KO,
              source: "typed"
            })
          }), 400) : CO(null)
        },
        choose: function(OO, KO) {
          FO(), bK(OO), lO("typed" === KO ? "search" : "prefilled" === KO ? "prefilled" : "suggestion"), CO({
            name: OO,
            source: KO
          }), "typed" !== KO && "prefilled" !== KO && (0, xK.e)({
            id: "store.gift_recipient",
            value: KO
          })
        },
        clear: function() {
          FO(), bK(""), lO("search"), CO(null)
        },
        recordGift: function(OO, KO) {
          ! function(OO) {
            eX.delete(OO.toLowerCase())
          }(OO), DO((pO => {
            if (!pO || pO.name.toLowerCase() !== OO.toLowerCase() || !0 !== pO.result.giftRecipientFound || "superRank" === KO) return pO;
            const XO = pO.result.giftRecipientOwnedPacks;
            return {
              ...pO,
              result: {
                ...pO.result,
                giftRecipientOwnedPacks: XO.includes(KO) ? XO : [...XO, KO]
              }
            }
          }))
        }
      }
    }
    var CX = pO(1894),
      hX = pO(3825),
      DX = pO(8336),
      MX = pO(2407);
    const ab = ["pointerdown", "pointermove", "keydown", "wheel", "touchstart", "scroll", "blur", "focus"];
    var oX = pO(1854),
      FX = pO(512),
      VX = pO(1446),
      LX = pO(1925),
      QX = pO(2061);

    function zb(OO) {
      let {
        cosmetics: KO
      } = OO;
      return (0, DO.jsx)("span", {
        className: "StoreRecipientAvatar",
        children: (0, DO.jsx)(LX.c, {
          cosmetics: KO
        })
      })
    }

    function AX(OO, KO) {
      var pO, XO;
      const bK = null !== (pO = OO.friend) && void 0 !== pO ? pO : {
        isError: !1,
        name: OO.name,
        ranks: [],
        cosmetics: null !== (XO = OO.cosmetics) && void 0 !== XO ? XO : {},
        nameColour: FX.b,
        location: {
          status: "noGamePlayed"
        }
      };
      return KO ? {
        ...bK,
        cosmetics: KO
      } : bK
    }

    function fX(OO) {
      let {
        recipient: KO
      } = OO;
      return "pending" === KO.status ? (0, DO.jsx)("span", {
        className: "StoreRecipientStatus",
        children: (0, DO.jsx)(TO.e, {})
      }) : "found" === KO.status ? (0, DO.jsx)(vK.d, {
        name: "check",
        className: "StoreRecipientStatus StoreRecipientStatusFound"
      }) : null
    }

    function dX(OO) {
      var KO;
      let {
        selfName: pO,
        giftRecipient: bK,
        suggestionsVersion: CO,
        pulseSignal: hO,
        disabled: MO
      } = OO;
      const {
        t: aK
      } = (0, lO.D)(), oO = (0, VX.m)(), FO = (0, XO.useRef)(null), VO = (0, XO.useRef)(null), {
        query: zK,
        via: AO,
        recipient: fO,
        recipientCosmetics: TO
      } = bK, NO = (0, XX.n)(zK), IO = (0, XO.useMemo)((() => {
        const OO = QO.featureFlags.useSocialFeatures ? oO.friends.filter((OO => !OO.isError)) : [];
        return (0, XX.k)({
          onlineFriends: (0, VX.i)(OO),
          recentRecipients: lX(),
          friends: OO,
          selfName: pO,
          max: 8
        })
      }), [oO.friends, pO, CO]), yK = zK.trim().toLowerCase(), gK = "search" !== AO && yK ? IO.find((OO => OO.name.toLowerCase() === yK)) : void 0, uO = gK && "prefilled" === AO ? [gK, ...IO.filter((OO => OO !== gK))] : IO, EO = "" !== yK && !gK, jK = EO ? zK : "", YO = uO.length > 0;
      (0, XO.useEffect)((() => {
        FO.current && FO.current.value !== jK && (FO.current.value = jK)
      }), [jK]), (0, XO.useEffect)((() => {
        FO.current && (FO.current.disabled = MO)
      }), [MO, hO]);
      const wO = (0, XO.useRef)(0);

      function iK() {
        "self" !== NO && (0, xK.e)({
          id: "store.mode",
          value: "self"
        }), bK.clear()
      }

      function rK(OO) {
        var KO, pO;
        if (MO) return;
        if (" " === OO.key || "Enter" === OO.key) return OO.preventDefault(), void OO.currentTarget.click();
        const XO = Array.from(null !== (KO = null === (pO = VO.current) || void 0 === pO ? void 0 : pO.querySelectorAll("[role=radio]")) && void 0 !== KO ? KO : []),
          bK = XO.indexOf(OO.currentTarget);
        let eO;
        "ArrowRight" === OO.key || "ArrowDown" === OO.key ? eO = XO[(bK + 1) % XO.length] : "ArrowLeft" === OO.key || "ArrowUp" === OO.key ? eO = XO[(bK - 1 + XO.length) % XO.length] : "Home" === OO.key ? eO = XO[0] : "End" === OO.key && (eO = XO[XO.length - 1]), eO && (OO.preventDefault(), eO.focus(), eO.click())
      }(0, XO.useEffect)((() => {
        var OO;
        hO > wO.current && !MO && (wO.current = hO, null === (OO = FO.current) || void 0 === OO || OO.focus())
      }), [hO, MO]);
      const PO = "self" === NO,
        sO = null !== (KO = null === gK || void 0 === gK ? void 0 : gK.name) && void 0 !== KO ? KO : null,
        HO = "error" === fO.status ? fO.error : null,
        RO = "store:giftRecipientLookupFailed" === HO;
      return (0, DO.jsxs)("div", {
        className: eO()("StoreRecipientStrip", {
          StoreRecipientStripDisabled: MO,
          StoreRecipientStripNoChips: !YO
        }),
        children: [(0, DO.jsx)("span", {
          className: "StoreRecipientLabel",
          "aria-hidden": !0,
          children: aK("store:buyingFor")
        }), (0, DO.jsxs)("div", {
          ref: VO,
          className: "StoreRecipientRadios",
          role: "radiogroup",
          "aria-label": aK("store:whoIsItFor"),
          children: [(0, DO.jsxs)("div", {
            role: "radio",
            "data-pad-focusable": !0,
            "aria-checked": PO,
            tabIndex: MO || !PO && null !== sO ? -1 : 0,
            className: eO()("StoreRecipientMe", {
              StoreRecipientChecked: PO
            }),
            onClick: () => {
              MO || iK()
            },
            onKeyDown: rK,
            children: [(0, DO.jsx)(vK.d, {
              name: "user"
            }), " ", aK("store:me")]
          }), YO && (0, DO.jsx)("div", {
            className: "StoreRecipientChips",
            children: uO.map((OO => {
              const KO = OO === gK;
              return (0, DO.jsx)("div", {
                role: "radio",
                "data-pad-focusable": !0,
                "aria-checked": KO,
                tabIndex: !MO && KO ? 0 : -1,
                title: OO.name,
                className: eO()("StoreRecipientChip", {
                  StoreRecipientChecked: KO
                }),
                onClick: () => {
                  MO || function(OO) {
                    "gift" !== NO && (0, xK.e)({
                      id: "store.mode",
                      value: "gift"
                    }), bK.choose(OO.name, OO.kind)
                  }(OO)
                },
                onKeyDown: rK,
                children: (0, DO.jsx)(QX.h, {
                  playerSocialPreview: AX(OO, KO ? TO : null),
                  opensProfileCard: !1,
                  isFriend: null !== OO.friend,
                  hideFriendBadge: !0,
                  showLocation: null !== OO.friend,
                  status: null === OO.friend ? null : void 0,
                  trailing: KO ? (0, DO.jsx)(fX, {
                    recipient: fO
                  }) : void 0
                })
              }, OO.name)
            }))
          })]
        }), (0, DO.jsxs)("div", {
          className: eO()("StoreRecipientSearch", {
            StoreRecipientChecked: EO,
            StoreRecipientSearchPulse: hO > 0 && !EO,
            StoreRecipientSearchError: null !== HO && !RO
          }),
          onClick: () => {
            var OO;
            null === (OO = FO.current) || void 0 === OO || OO.focus()
          },
          children: [EO && "found" === fO.status && TO && (0, DO.jsx)(zb, {
            cosmetics: TO
          }), !(EO && "found" === fO.status && TO) && (0, DO.jsx)(vK.d, {
            name: "magnifying-glass",
            className: "StoreRecipientSearchIcon"
          }), (0, DO.jsx)(dO.e, {
            className: "StoreRecipientSearchInput",
            domRef: FO,
            placeholderText: aK("store:searchName"),
            defaultValue: jK,
            maxLength: mK.f,
            onValueChange: function(OO) {
              "gift" !== NO && OO.trim() && (0, xK.e)({
                id: "store.mode",
                value: "gift"
              }), bK.type(OO)
            },
            onEnter: () => {
              var OO;
              const KO = null === (OO = FO.current) || void 0 === OO ? void 0 : OO.value.trim();
              KO && bK.choose(KO, "typed")
            },
            blurOnEnter: !0
          }), EO && (0, DO.jsx)(fX, {
            recipient: fO
          }), EO && (0, DO.jsx)("div", {
            ...(0, LO.X)({
              disabled: MO
            }),
            "aria-label": aK("store:clearRecipient"),
            title: aK("store:clearRecipient"),
            className: "StoreRecipientClear",
            onClick: OO => {
              OO.stopPropagation(), MO || iK()
            },
            children: (0, DO.jsx)(vK.d, {
              name: "xmark"
            })
          })]
        }, hO), HO && (0, DO.jsx)("div", {
          className: eO()("StoreRecipientPopover", {
            StoreRecipientPopoverSoft: RO
          }),
          role: "status",
          children: aK(HO)
        })]
      })
    }
    var TX = pO(1803),
      NX = pO(1829),
      IX = pO(2835),
      yb = pO(2414),
      gb = pO(1876);
    const uX = pO.p + "static/media/superRankPreviewPoster.e64783181b692cc31e08.webp";

    function EX() {
      (0, gb.e)(uX).catch((OO => {
        console.warn(OO)
      }))
    }

    function jb(OO) {
      let {
        onBack: KO,
        cta: pO,
        recipient: bK,
        afterCta: eO
      } = OO;
      const {
        t: CO
      } = (0, lO.D)(), [hO, MO] = (0, XO.useState)("starting"), aK = (0, XO.useRef)(null), oO = (0, VK.b)(), FO = (0, XO.useRef)(null), VO = (0, XO.useCallback)((() => {
        const OO = aK.current;
        null !== OO.error && OO.load();
        const KO = OO.play();
        FO.current = KO, KO.catch((OO => {
          (0, IX.b)("Failed to play Super Rank video", OO), oO.current && FO.current === KO && MO("failed")
        }))
      }), [oO]);
      return (0, XO.useEffect)((() => {
        const OO = aK.current;
        let KO;

        function pO() {
          clearTimeout(KO), KO = setTimeout(VO, 3e3)
        }
        return VO(), OO.addEventListener("ended", pO), () => {
          clearTimeout(KO), OO.removeEventListener("ended", pO)
        }
      }), [VO]), (0, DO.jsxs)("div", {
        className: "StoreSuperRankDetail",
        children: [(0, DO.jsxs)("div", {
          className: "StoreDetailHeader",
          children: [(0, DO.jsx)(LO.c, {
            className: "StoreDetailBackButton",
            onClick: KO,
            padBack: !0,
            children: CO("general:back")
          }), (0, DO.jsxs)("div", {
            className: "StoreTileTitle StoreSuperRankTitle",
            children: [(0, DO.jsx)(vK.d, {
              name: "bolt"
            }), " ", CO("homePage:superRank")]
          }), bK]
        }), (0, DO.jsxs)("div", {
          className: "StoreSuperRankDetailBody",
          children: [(0, DO.jsxs)("div", {
            className: "StoreSuperRankVideo",
            children: [(0, DO.jsx)("video", {
              ref: aK,
              src: `${wO.clientSideServerUrls.staticUrl}/videos/SuperRankPreview.mp4`,
              poster: uX,
              muted: !0,
              playsInline: !0,
              controls: "playing" === hO,
              onPlaying: () => {
                MO("playing")
              },
              onError: () => {
                MO("failed")
              }
            }), ("failed" === hO || "loading" === hO) && (0, DO.jsx)("div", {
              className: "StoreSuperRankPlay",
              children: (0, DO.jsx)(LO.d, {
                ariaLabel: CO("general:play"),
                loading: "loading" === hO,
                onClick: () => {
                  MO("loading"), VO()
                },
                touchPressOn: "pointerup",
                children: (0, DO.jsx)(vK.d, {
                  name: "play"
                })
              })
            })]
          }), (0, DO.jsxs)("div", {
            className: "StoreSuperRankDetailSide",
            children: [(0, DO.jsx)("div", {
              className: "StoreSuperRankDetailTable",
              children: (0, DO.jsx)(yb.e, {})
            }), (0, DO.jsxs)("div", {
              className: "StoreTileActions",
              children: [pO, eO]
            })]
          })]
        })]
      })
    }
    var YX = pO(2079),
      wX = pO(2771);
    const ib = [FX.s.yellow, FX.s.green, FX.s.aqua, FX.s.blue, FX.s.purple, FX.s.red];

    function rb(OO) {
      return "needsRecipient" === OO || "lookingUp" === OO || "gift" === OO || "recipientOwns" === OO
    }

    function PX(OO) {
      const {
        onKeyDown: KO,
        ...pO
      } = (0, LO.X)();
      return {
        ...pO,
        "aria-label": OO,
        onKeyDown: OO => {
          OO.target === OO.currentTarget && (null === KO || void 0 === KO || KO(OO))
        }
      }
    }

    function mb(OO) {
      let {
        text: KO
      } = OO;
      return (0, DO.jsx)("span", {
        className: "StoreRainbowText",
        children: Array.from(KO).map(((OO, KO) => (0, DO.jsx)("span", {
          style: {
            color: ib[KO % ib.length]
          },
          children: OO
        }, KO)))
      })
    }

    function sX(OO) {
      let {
        state: KO,
        item: pO,
        price: XO,
        busy: bK,
        highlight: CO = !1,
        onAct: hO,
        onNeedRecipient: MO,
        onLogin: aK = KX.c
      } = OO;
      const {
        t: oO
      } = (0, lO.D)(), FO = "superRank" === pO ? HO.h.product.days : null, VO = OO => null === FO ? oO(OO ? "general:gift" : "general:buy") : oO(OO ? "store:giftDays" : "store:buyDays", {
        days: FO
      }), QO = (OO, KO) => (0, DO.jsxs)(DO.Fragment, {
        children: [KO && (0, DO.jsx)("span", {
          className: "StoreCtaIcon",
          children: KO
        }), null === OO && (0, DO.jsx)("span", {
          className: "StoreCtaLabel StoreCtaLabelPending"
        }), null !== OO && (0, DO.jsx)("span", {
          className: "StoreCtaLabel",
          title: OO,
          children: OO
        }), (0, DO.jsxs)("span", {
          className: "StoreCtaPrice",
          children: ["\xb7", (0, DO.jsx)(NX.b, {
            amount: XO
          })]
        })]
      });
      let zK;
      switch (KO) {
        case "pending":
          zK = (0, DO.jsx)(LO.m, {
            className: "StoreCtaButton",
            disabled: !0,
            children: QO(null)
          });
          break;
        case "login":
          zK = (0, DO.jsx)(LO.m, {
            className: "StoreCtaButton",
            onClick: aK,
            children: QO(oO("store:logIn"))
          });
          break;
        case "owned":
          zK = (0, DO.jsx)(LO.e, {
            className: "StoreCtaButton",
            onClick: () => {
              IO.d.set({
                openEverythingMenuName: kp.o.CUSTOMISATION
              })
            },
            children: (0, DO.jsxs)("span", {
              className: "StoreCtaLabel",
              children: [(0, DO.jsx)(vK.d, {
                name: "shirt"
              }), " ", oO("store:equip")]
            })
          });
          break;
        case "recipientOwns":
          zK = (0, DO.jsx)(LO.m, {
            className: "StoreCtaButton",
            disabled: !0,
            children: (0, DO.jsx)("span", {
              className: "StoreCtaLabel",
              children: oO("store:alreadyOwns")
            })
          });
          break;
        case "needsRecipient":
        case "lookingUp":
        case "gift":
          zK = (0, DO.jsx)(LO.m, {
            className: "StoreCtaButton",
            disabled: "needsRecipient" === KO || null === XO,
            loading: "lookingUp" === KO || bK,
            onClick: hO,
            analyticsClick: {
              id: "store.gift",
              value: pO
            },
            children: QO(VO(!0), XX.e)
          });
          break;
        case "buy":
        case "recharge":
          zK = (0, DO.jsx)(LO.m, {
            className: "StoreCtaButton",
            loading: bK,
            disabled: null === XO,
            onClick: hO,
            analyticsClick: {
              id: "store.buy",
              value: pO
            },
            children: QO(VO(!1))
          })
      }
      return (0, DO.jsx)("div", {
        className: eO()("StoreCta", {
          StoreCtaHighlight: CO
        }),
        onClick: OO => {
          OO.stopPropagation(), "needsRecipient" === KO && MO()
        },
        children: zK
      })
    }

    function HX() {
      const {
        t: OO
      } = (0, lO.D)();
      return (0, DO.jsxs)("ul", {
        className: "StorePerks",
        children: [(0, DO.jsxs)("li", {
          children: [(0, DO.jsx)(vK.d, {
            name: "check"
          }), (0, DO.jsx)(mb, {
            text: OO("store:colourfulNames")
          })]
        }), (0, DO.jsxs)("li", {
          children: [(0, DO.jsx)(vK.d, {
            name: "check"
          }), OO("store:perkCapes")]
        }), (0, DO.jsxs)("li", {
          children: [(0, DO.jsx)(vK.d, {
            name: "check"
          }), OO("store:perkNoAdverts")]
        }), (0, DO.jsxs)("li", {
          children: [(0, DO.jsx)(vK.d, {
            name: "check"
          }), OO("store:perkFriends", {
            count: (0, GO.c)(["super"])
          })]
        })]
      })
    }

    function RX(OO) {
      let {
        daysLeft: KO,
        totalDays: pO,
        urgent: XO
      } = OO;
      const {
        t: bK
      } = (0, lO.D)(), vK = pO > 0 ? Math.min(1, Math.max(.03, KO / pO)) : 1;
      return (0, DO.jsxs)("div", {
        className: eO()("StoreSuperRankMeterArea", {
          StoreSuperRankMeterUrgent: XO
        }),
        children: [(0, DO.jsx)("span", {
          className: "StoreSuperRankDaysLeft",
          children: 1 === KO ? bK("store:oneDayLeft") : bK("store:daysLeft", {
            days: KO
          })
        }), (0, DO.jsx)("div", {
          className: "StoreSuperRankMeter",
          children: (0, DO.jsx)("i", {
            style: {
              width: 100 * vK + "%"
            }
          })
        })]
      })
    }

    function SX(OO) {
      let {
        state: KO,
        urgent: pO,
        daysLeft: XO,
        totalDays: bK,
        recipientSuperRankDaysLeft: CO,
        busy: hO,
        highlight: MO,
        onOpen: aK,
        onAct: oO,
        onNeedRecipient: FO,
        onLogin: VO
      } = OO;
      const {
        t: LO
      } = (0, lO.D)(), QO = rb(KO), {
        days: zK
      } = HO.h.product, AO = LO("store:recipientHasSuperRank", {
        days: CO,
        giftDays: zK
      });
      return (0, DO.jsxs)("div", {
        className: eO()("StoreTile StoreSuperRankTile", {
          StoreTileGift: QO,
          StoreSuperRankTileUrgent: "recharge" === KO && pO,
          StoreSuperRankTileWithChip: QO && "gift" === KO && null !== CO,
          StoreSuperRankTileGiftReady: "gift" === KO
        }),
        ...PX(LO("homePage:superRank")),
        "data-store-item": "superRank",
        onPointerEnter: EX,
        onFocus: EX,
        onClick: aK,
        children: [(0, DO.jsx)("div", {
          className: "StoreSuperRankArt",
          style: {
            backgroundImage: `url(${oX.d})`
          }
        }), QO && (0, DO.jsx)("div", {
          className: "StoreGiftRibbon"
        }), (0, DO.jsxs)("div", {
          className: "StoreTileContent",
          children: [QO && "gift" === KO && null !== CO && (0, DO.jsx)("span", {
            className: "StoreChip StoreChipGift",
            title: AO,
            children: AO
          }), (0, DO.jsxs)("div", {
            className: "StoreTileTitle StoreSuperRankTitle",
            children: [(0, DO.jsx)(vK.d, {
              name: "bolt"
            }), " ", LO("homePage:superRank")]
          }), QO && (0, DO.jsx)("div", {
            className: "StoreTilePitch",
            children: LO("store:giftPitch", {
              days: zK
            })
          }), "recharge" === KO && (0, DO.jsx)(RX, {
            daysLeft: XO,
            totalDays: bK,
            urgent: pO
          }), (0, DO.jsx)(HX, {}), (0, DO.jsxs)("div", {
            className: "StoreTileActions",
            children: [(0, DO.jsx)(sX, {
              state: KO,
              item: "superRank",
              price: HO.h.price,
              busy: hO,
              highlight: MO,
              onAct: oO,
              onNeedRecipient: FO,
              onLogin: VO
            }), "needsRecipient" === KO && (0, DO.jsx)("span", {
              className: "StoreTileNote StoreTileNoteGift",
              children: LO("store:pickRecipientFirst")
            }), "recharge" === KO && pO && (0, DO.jsx)("span", {
              className: "StoreTileNote StoreSuperRankEnding",
              children: 1 === XO ? LO("store:endsInOneDay") : LO("store:endsInDays", {
                days: XO
              })
            })]
          })]
        })]
      })
    }
    const JX = {
      standard: "StorePackTileStandard",
      enhanced: "StorePackTileEnhanced",
      premium: "StorePackTilePremium"
    };

    function cb(OO) {
      var KO;
      let {
        pack: pO,
        state: bK,
        busy: CO,
        onOpen: hO,
        onAct: MO,
        onNeedRecipient: aK,
        onLogin: oO
      } = OO;
      const {
        t: FO
      } = (0, lO.D)(), VO = xX.e[pO], LO = OX.j[pO], QO = (0, oX.j)(pO), zK = rb(bK), AO = null !== (KO = VO.displayName) && void 0 !== KO ? KO : pO, fO = (0, wX.b)(YX.e), [dO] = (0, XO.useState)(MX.d);
      return (0, DO.jsxs)("div", {
        className: eO()("StoreTile StorePackTile", VO.tier && JX[VO.tier], {
          StorePackTileOwned: "owned" === bK,
          StorePackTileRecipientOwns: "recipientOwns" === bK,
          StoreTileGift: zK
        }),
        ...PX(AO),
        "data-store-item": pO,
        onClick: hO,
        onPointerMove: OO => {
          "mouse" !== OO.pointerType || 0 === OO.movementX && 0 === OO.movementY || dO || fO.start()
        },
        onPointerLeave: fO.cancel,
        children: [LO && (0, DO.jsx)(LO, {}), (0, DO.jsx)("div", {
          className: "StorePackCharacters",
          children: QO.map((OO => (0, DO.jsx)("div", {
            className: "StorePackCharacter",
            style: {
              backgroundImage: `url(${(0,oX.g)(OO)})`
            }
          }, OO)))
        }), (0, DO.jsx)("div", {
          className: "StoreTileScrim"
        }), zK && (0, DO.jsx)("div", {
          className: "StoreGiftRibbon"
        }), (0, DO.jsxs)("div", {
          className: "StoreTileContent",
          children: [(0, DO.jsx)("div", {
            className: "StoreTileTitle",
            children: AO
          }), (0, DO.jsxs)("div", {
            className: "StoreTileMeta",
            children: [FO("store:itemCount", {
              count: (0, TX.m)(pO)
            }), "owned" === bK && (0, DO.jsxs)("span", {
              className: "StoreTileOwned",
              children: [" \xb7 ", (0, DO.jsx)(vK.d, {
                name: "check"
              }), " ", FO("general:owned")]
            })]
          }), (0, DO.jsx)(sX, {
            state: bK,
            item: pO,
            price: (0, HO.e)(pO),
            busy: CO,
            onAct: MO,
            onNeedRecipient: aK,
            onLogin: oO
          })]
        })]
      })
    }
    var BX = pO(2388);

    function ZX(OO) {
      let {
        layout: KO,
        bundleGift: pO,
        superRankDaysLeft: XO,
        superRankTotalDays: bK,
        busy: eO,
        highlightItem: lO,
        onOpen: vK,
        onAct: CO,
        onNeedRecipient: hO,
        onLogin: MO
      } = OO;
      return (0, DO.jsxs)(DO.Fragment, {
        children: [(0, DO.jsx)(BX.d, {
          className: "StoreSuperGems",
          gift: pO
        }), (0, DO.jsx)(SX, {
          state: KO.superRank.state,
          urgent: KO.superRank.urgent,
          daysLeft: XO,
          totalDays: bK,
          recipientSuperRankDaysLeft: KO.recipientSuperRankDaysLeft,
          busy: eO,
          highlight: "superRank" === lO,
          onOpen: () => {
            vK("superRank")
          },
          onAct: () => {
            CO("superRank")
          },
          onNeedRecipient: hO,
          onLogin: () => {
            MO("superRank")
          }
        }), (0, DO.jsx)("div", {
          className: "StorePackGrid",
          children: KO.packs.map((OO => (0, DO.jsx)(cb, {
            pack: OO.pack,
            state: OO.state,
            busy: eO,
            onOpen: () => {
              vK(OO.pack)
            },
            onAct: () => {
              CO(OO.pack)
            },
            onNeedRecipient: hO,
            onLogin: () => {
              MO(OO.pack)
            }
          }, OO.pack)))
        })]
      })
    }

    function GX(OO) {
      let {
        state: KO,
        mode: pO,
        giftName: XO,
        busy: bK,
        highlight: eO,
        purchaseError: vK,
        onBack: CO,
        onChooseRecipient: hO,
        onAct: MO,
        onLogin: aK
      } = OO;
      const {
        t: oO
      } = (0, lO.D)();
      return (0, DO.jsx)(jb, {
        onBack: CO,
        recipient: "gift" === pO && (0, DO.jsxs)(DO.Fragment, {
          children: [XO && (0, DO.jsxs)("span", {
            className: "StoreDetailRecipient",
            title: oO("store:giftFor", {
              name: XO
            }),
            children: [XX.e, " ", oO("store:giftFor", {
              name: XO
            })]
          }), !XO && (0, DO.jsxs)("div", {
            ...(0, LO.X)(),
            className: "StoreDetailRecipient StoreDetailRecipientChoose",
            onClick: hO,
            children: [XX.e, " ", oO("store:chooseRecipient")]
          })]
        }),
        cta: (0, DO.jsx)(sX, {
          state: KO,
          item: "superRank",
          price: HO.h.price,
          busy: bK,
          highlight: eO,
          onAct: MO,
          onNeedRecipient: hO,
          onLogin: aK
        }),
        afterCta: (0, DO.jsx)(DO.Fragment, {
          children: vK && (0, DO.jsx)("span", {
            className: "StoreTileNote StoreTileNoteError",
            children: oO(vK)
          })
        })
      })
    }
    const qb = {
      kind: "board"
    };
    let xb = !1;

    function nX(OO) {
      return "superRank" === OO.kind ? "superRank" : "pack" === OO.kind ? OO.pack : null
    }

    function WX(OO) {
      return "found" === OO.status || "error" === OO.status && "store:giftRecipientLookupFailed" === OO.error ? OO.name : null
    }(0, cK.t)(np.prefetchPremiumCurrencyBundles);
    const tb = (0, XO.memo)((function(OO) {
      var KO, bK;
      let {
        show: vK
      } = OO;
      const {
        t: CO
      } = (0, lO.D)(), {
        userContext: hO
      } = (0, oO.d)(), MO = hO !== YO.NULL_USER_CONTEXT, aK = vb(hO), [FO, LO] = (0, VO.c)(), {
        page: QO,
        urlMode: zK,
        goTo: AO
      } = (0, CX.e)(), fO = nX(QO), {
        openEverythingMenuName: dO,
        gameState: TO
      } = (0, IO.l)(["openEverythingMenuName", "gameState"]), NO = null !== dO;
      ! function(OO, KO) {
        const [bK] = (0, XO.useState)(MX.d), [eO, lO] = (0, XO.useState)(!1);
        bK && KO && !eO && lO(!0);
        const vK = (0, Xp.p)(),
          CO = bK && eO && OO && !vK;
        (0, XO.useEffect)((() => {
          if (!CO) return;
          let OO = null,
            KO = null,
            XO = null;
          const bK = () => !document.hasFocus() || document.activeElement instanceof HTMLIFrameElement || (0, np.isXsollaCheckoutInControl)(),
            eO = () => {
              var pO;
              null === (pO = XO) || void 0 === pO || pO(), XO = null, null !== OO && (clearTimeout(OO), OO = null), null !== KO && (clearTimeout(KO), KO = null)
            },
            lO = () => {
              (0, hX.t)(!1), (0, hX.q)(!1), eO(), OO = setTimeout((() => {
                OO = null, XO = (0, DX.b)((() => {
                  XO = null, bK() ? lO() : ((0, hX.t)(!0), KO = setTimeout((() => {
                    KO = null, XO = (0, DX.b)((() => {
                      XO = null, bK() ? lO() : (0, hX.q)(!0)
                    }))
                  }), 3e3), Promise.resolve().then((() => pO(3821))).then((OO => {
                    OO.startBackgroundGameSetup()
                  }), (OO => {
                    console.warn("Background game setup: its chunk failed to load", OO)
                  })))
                }))
              }), 2e3)
            };
          for (const pO of ab) window.addEventListener(pO, lO, {
            capture: !0,
            passive: !0
          });
          return lO(), () => {
            for (const OO of ab) window.removeEventListener(OO, lO, {
              capture: !0
            });
            eO(), (0, hX.t)(!1), (0, hX.q)(!1)
          }
        }), [CO])
      }(vK && NO, "pack" === QO.kind);
      const yK = "landingPage" === TO;
      (0, XO.useEffect)((() => {
        NO && (0, np.prefetchPremiumCurrencyBundles)()
      }), [NO]), (0, XO.useEffect)((() => {
        NO && !vK && yK && (0, oX.l)()
      }), [NO, vK, yK]);
      const [gK, uO] = (0, XO.useState)(0), [EO, jK] = (0, XO.useState)(null), [wO, iK] = (0, XO.useState)(null), [rK, PO] = (0, XO.useState)(null), [mK, sO] = (0, XO.useState)(null), RO = (0, XO.useRef)(null), SO = (0, XO.useRef)(null), ZO = (0, XO.useRef)(!1), GO = (0, cK.A)(), qK = (0, XO.useRef)(0), nO = (0, XO.useRef)(!1);

      function WO() {
        uO((OO => OO + 1))
      }(0, XO.useEffect)((() => {
        if (vK) {
          if (xb = !0, GO && GO.seq !== qK.current) {
            qK.current = GO.seq;
            const OO = (0, cK.e)(GO);
            zK || AO(OO), sO(GO.highlight ? nX(OO) : null), iK(null), "gift" === GO.mode && GO.giftRecipientName ? aK.choose(GO.giftRecipientName, "prefilled") : "current" !== GO.mode && aK.clear(), "gift" !== GO.mode || GO.giftRecipientName || WO(), (0, xK.e)({
              id: "store.open",
              value: GO.source
            })
          } else nO.current || (0, xK.e)({
            id: "store.open",
            value: "menuTab"
          });
          nO.current = !0
        } else nO.current = !1
      }), [vK, GO]), (0, XO.useEffect)((() => {
        if (!mK) return;
        const OO = setTimeout((() => {
          sO(null)
        }), 4e3);
        return () => {
          clearTimeout(OO)
        }
      }), [mK]), (0, XO.useEffect)((() => {
        const OO = RO.current;
        var KO;
        if (vK && OO)
          if (fO) SO.current = fO, null === (KO = OO.querySelector(".StoreDetailBackButton, .CosmeticShopDetailBackButton")) || void 0 === KO || KO.focus();
          else if (SO.current) {
          var pO;
          null === (pO = OO.querySelector(`[data-store-item="${SO.current}"]`)) || void 0 === pO || pO.focus(), SO.current = null
        }
      }), [fO, vK]), (0, XO.useEffect)((() => {
        iK(null)
      }), [aK.query]), (0, XO.useEffect)((() => {
        if (!rK) return;
        const OO = setTimeout((() => {
          PO(null)
        }), 8e3);
        return () => {
          clearTimeout(OO)
        }
      }), [rK]);
      const tK = hO.superRankInfo,
        kK = tK ? (0, JO.gc)(tK) : 0,
        UO = (0, XX.i)(kK),
        OK = kK > 0,
        KK = hO.isLoggedIn(),
        pK = hO.getOwnedCosmeticPacks(),
        XK = (0, XX.n)(aK.query),
        bp = (0, XX.g)({
          mode: XK,
          loggedIn: MO ? KK : null,
          hasSuperRank: OK,
          superRankDaysLeft: UO,
          ownedPacks: pK,
          packs: xX.j,
          recipient: aK.recipient
        });
      (0, XO.useEffect)((() => {
        if (!KK || !vK) return;
        const OO = (0, cK.y)();
        var KO;
        OO && ("superRank" === (KO = OO.item) || xX.j.includes(KO)) && ((0, xK.e)({
          id: "store.login_resume",
          value: OO.item
        }), (0, cK.k)({
          mode: OO.mode,
          source: "loginResume",
          giftRecipientName: "gift" === OO.mode && OO.recipient ? OO.recipient : void 0,
          openItem: OO.item,
          highlight: !0
        }))
      }), [KK, vK]);
      const eK = (0, XX.r)({
        hasSuperRank: KK && OK,
        superRankDaysLeft: UO,
        openedThisSession: xb || vK
      });
      if ((0, XO.useEffect)((() => {
          (0, cK.u)(eK)
        }), [eK]), !vK || !(0, BO.siteSupportsPurchases)()) return null;
      const lK = LO > FO && FO <= 700,
        vp = !lK && LO <= 420,
        CK = "gift" === XK ? WX(aK.recipient) : null,
        hK = null !== EO;

      function DK(OO) {
        (0, cK.p)({
          item: OO,
          mode: XK,
          recipient: "gift" === XK ? aK.query.trim() : ""
        }), (0, KX.c)()
      }

      function MK(OO, KO) {
        (0, xK.e)({
          id: "store.purchase_done",
          value: `${KO?"gift":"self"}:${OO}`
        }), KO && (aK.recordGift(KO.name, OO), ap(KO))
      }

      function ap(OO) {
        ! function(OO) {
          try {
            jp.e.setItem(bb, (0, XX.x)(lX(), OO))
          } catch {}
        }({
          name: OO.name,
          cosmetics: OO.cosmetics
        }), AO(qb), PO((KO => {
          var pO;
          return {
            name: OO.name,
            seq: (null !== (pO = null === KO || void 0 === KO ? void 0 : KO.seq) && void 0 !== pO ? pO : 0) + 1
          }
        }))
      }
      async function oK(OO) {
        var KO, pO;
        if (ZO.current) return;
        if (!KK) return void DK(OO);
        iK(null), sO(null);
        const XO = "gift" === XK ? {
          name: WX(aK.recipient),
          cosmetics: aK.recipientCosmetics
        } : null;
        if (XO && !XO.name) return void WO();
        const bK = "superRank" === OO ? HO.h.id : (0, HO.c)(OO);
        ZO.current = !0;
        const eO = await (0, pX.b)(bK, null !== (KO = null === XO || void 0 === XO ? void 0 : XO.name) && void 0 !== KO ? KO : null);
        if (ZO.current = !1, !eO) return;
        jK(OO);
        const lO = await tX.e.purchase(bK, null !== (pO = null === XO || void 0 === XO ? void 0 : XO.name) && void 0 !== pO ? pO : null);
        jK(null), lO ? iK(lO) : (MK(OO, XO), XO || (await (0, kX.flushClientAnalyticsEvents)(), (0, Wp.refreshWithoutConfirmation)("superRank" === OO ? "/super-rank-welcome" : `/pack-welcome/${OO}`)))
      }
      const FK = eO()("Store", {
        StoreGift: "gift" === XK,
        StorePortrait: lK,
        StoreCompact: vp
      });
      if ("pack" === QO.kind) {
        const OO = QO.pack,
          KO = bp.packs.find((KO => KO.pack === OO));
        return (0, DO.jsx)("div", {
          ref: RO,
          className: "CosmeticShopContainer",
          children: (0, DO.jsx)(OX.c, {
            pack: OO,
            onBack: () => {
              AO(qb)
            },
            onPurchased: KO => {
              MK(OO, KO ? {
                name: KO,
                cosmetics: null
              } : null)
            },
            giftCta: "gift" === XK && CK && KO && (0, DO.jsxs)(DO.Fragment, {
              children: [(0, DO.jsx)(sX, {
                state: KO.state,
                item: OO,
                price: (VK = OO, "superRank" === VK ? HO.h.price : (0, HO.e)(VK)),
                busy: hK,
                onAct: () => {
                  oK(OO)
                },
                onNeedRecipient: () => {
                  AO(qb), WO()
                }
              }), wO && (0, DO.jsx)("span", {
                className: "CosmeticShopGiftError SmallTextBold",
                children: CO(wO)
              })]
            }),
            ownedPacks: pK,
            startAsGift: "gift" === XK,
            initialGiftRecipient: "gift" === XK ? null !== CK && void 0 !== CK ? CK : aK.query.trim() : "",
            highlightCta: mK === OO
          }, OO)
        })
      }
      var VK;
      return "superRank" === QO.kind ? (0, DO.jsx)("div", {
        ref: RO,
        className: eO()(FK, "StoreDetailView"),
        children: (0, DO.jsx)(GX, {
          state: bp.superRank.state,
          mode: XK,
          giftName: CK,
          busy: hK,
          highlight: "superRank" === mK,
          purchaseError: wO,
          onBack: () => {
            AO(qb)
          },
          onChooseRecipient: () => {
            AO(qb), WO()
          },
          onAct: () => {
            oK("superRank")
          },
          onLogin: () => {
            DK("superRank")
          }
        })
      }) : (0, DO.jsxs)("div", {
        ref: RO,
        className: FK,
        children: [(0, DO.jsx)("div", {
          className: "StoreTopRow",
          children: (0, DO.jsx)(dX, {
            selfName: MO ? hO.getPlayerName() : "",
            giftRecipient: aK,
            suggestionsVersion: null !== (KO = null === rK || void 0 === rK ? void 0 : rK.seq) && void 0 !== KO ? KO : 0,
            pulseSignal: gK,
            disabled: hK || !MO
          })
        }), rK && (0, DO.jsxs)("div", {
          className: "StoreNotice StoreNoticeGiftSent",
          onClick: () => {
            PO(null)
          },
          children: [(0, DO.jsx)(Up.b, {
            showSignal: rK.seq
          }), XX.e, " ", CO("store:giftSent", {
            name: rK.name
          })]
        }, rK.seq), !rK && wO && (0, DO.jsx)("div", {
          className: "StoreNotice StoreNoticeError",
          children: CO(wO)
        }), (0, DO.jsx)(ZX, {
          layout: bp,
          bundleGift: "gift" === XK ? {
            recipientName: CK,
            lookingUp: "pending" === aK.recipient.status,
            busy: hK,
            onNeedRecipient: WO,
            onSent: OO => {
              (0, xK.e)({
                id: "store.purchase_done",
                value: "gift:superGems"
              }), ap({
                name: OO,
                cosmetics: aK.recipientCosmetics
              })
            }
          } : null,
          superRankDaysLeft: UO,
          superRankTotalDays: null !== (bK = null === tK || void 0 === tK ? void 0 : tK.superRankForDays) && void 0 !== bK ? bK : 0,
          busy: hK,
          highlightItem: mK,
          onOpen: function(OO) {
            (0, xK.e)({
              id: "store.item_open",
              value: OO
            }), AO((0, cK.h)(OO))
          },
          onAct: oK,
          onNeedRecipient: WO,
          onLogin: DK
        })]
      })
    }));
    var kb = pO(2144),
      UX = pO(7922),
      Ob = pO(2204),
      Kb = pO(2050),
      pb = pO(2102),
      Xb = pO(2111),
      be = pO(2115),
      eb = pO(2189),
      lb = pO(2174),
      ve = pO(2164),
      Cb = pO(1910),
      hb = pO(1950),
      Db = pO(1933),
      Mb = pO(1633),
      ae = pO(2124),
      ob = pO(1955);

    function Fb(OO) {
      let {
        show: KO
      } = OO;
      return KO ? (0, DO.jsx)(Vb, {}) : null
    }

    function Vb() {
      const {
        t: OO
      } = (0, lO.D)(), {
        followsLeader: KO
      } = (0, Kb.f)(), {
        loading: pO,
        friends: bK,
        requests: CO,
        invites: hO
      } = (0, VX.m)(), {
        userContext: MO
      } = (0, oO.d)(), [aK, FO] = (0, XO.useState)(ob.g);
      (0, XO.useEffect)((() => {
        (0, ob.b)()
      }), []);
      const VO = CO.map((OO => OO.name)),
        {
          state: QO,
          recentRequesters: zK
        } = (0, lb.l)(),
        AO = new Map([...("loaded" === QO.status ? QO.recentPlayers : []).map((OO => [OO.preview.name, OO])), ...zK.map((OO => [OO.name, OO]))]),
        fO = (0, XO.useRef)(null),
        [NO, IO] = (0, XO.useState)(""),
        [yK, gK] = (0, XO.useState)("Enter"),
        [uO, EO] = (0, XO.useState)(null);

      function jK() {
        NO && (gK("Loading"), (0, Db.f)(NO, "social_menu").then((OO => {
          if (fO.current) switch (OO.kind) {
            case "sent":
              gK("Success");
              break;
            case "becameFriends":
              gK("BecameFriends");
              break;
            case "failed":
              EO(OO.message), gK("Error")
          }
        })))
      }
      return (0, XO.useEffect)((() => {
        if ("Enter" === yK || "Loading" === yK) return;
        const OO = setTimeout((() => {
          fO.current.value = "", IO(""), gK("Enter")
        }), "Success" === yK ? 1e3 : 4e3);
        return () => {
          clearTimeout(OO)
        }
      }), [yK]), (0, DO.jsx)("div", {
        className: "SocialMenu",
        children: (0, DO.jsxs)("div", {
          className: "SocialMenuInner",
          children: [(0, DO.jsxs)("div", {
            className: "SocialMenuColumn",
            children: [(0, DO.jsxs)("div", {
              className: "SocialMenuBox SocialMenuAddFriend",
              children: [(0, DO.jsx)(be.b, {
                label: OO("socialBar:addFriend")
              }), (0, DO.jsxs)("div", {
                className: "AddFriendBody",
                children: [(0, DO.jsxs)("div", {
                  className: eO()("AddFriendBodyOverlay", {
                    [`AddFriendBodyOverlay${yK}`]: !0
                  }),
                  children: ["Loading" === yK && (0, DO.jsx)(TO.e, {}), "Success" === yK && (0, DO.jsx)(vK.d, {
                    name: "check"
                  }), "BecameFriends" === yK && (0, DO.jsx)(DO.Fragment, {
                    children: OO("socialBar:nowFriends", {
                      playerName: NO
                    })
                  }), "Error" === yK && uO && (0, DO.jsx)(DO.Fragment, {
                    children: OO(uO.translationKey, uO.params)
                  })]
                }), (0, DO.jsxs)("div", {
                  className: "PlayerSearch",
                  children: [(0, DO.jsx)(dO.e, {
                    className: "PlayerSearchInput",
                    placeholderText: OO("socialBar:enterPlayerName"),
                    domRef: fO,
                    onValueChange: OO => {
                      IO((0, mK.n)(OO)), fO.current.value = (0, mK.n)(OO)
                    },
                    onEnter: () => {
                      NO && (0, xK.e)({
                        id: "social.add_friend",
                        value: "social_menu"
                      }), jK()
                    }
                  }), (0, DO.jsxs)(LO.d, {
                    className: "PlayerSearchInputButton SmallTextLight",
                    onClick: () => {
                      jK()
                    },
                    analyticsClick: {
                      id: "social.add_friend",
                      value: "social_menu"
                    },
                    children: [(0, DO.jsx)(vK.d, {
                      name: "user-plus"
                    }), " ", OO("socialBar:sendRequest")]
                  })]
                })]
              }), (0, DO.jsx)(ae.d, {
                surface: "social_menu",
                prefetchOnMount: !0
              })]
            }), hO.length > 0 && (0, DO.jsxs)("div", {
              className: "SocialMenuBox SocialMenuInvites",
              children: [(0, DO.jsx)(be.b, {
                label: OO("socialBar:invites"),
                meta: hO.length
              }), hO.map((KO => (0, DO.jsxs)("div", {
                className: "SocialMenuInvite",
                children: [(0, DO.jsx)("div", {
                  className: "SocialMenuInviteIcon",
                  children: (0, DO.jsx)(Cb.c, {
                    invite: KO
                  })
                }), (0, DO.jsx)("div", {
                  className: "SocialMenuInviteText",
                  children: (0, DO.jsx)(Cb.d, {
                    invite: KO
                  })
                }), (0, DO.jsx)(LO.m, {
                  className: "SocialMenuInviteJoin SmallTextLight",
                  onClick: () => {
                    (0, hb.g)(KO)
                  },
                  analyticsClick: {
                    id: "social.accept_invite",
                    value: `social_menu:${KO.destination.kind}`
                  },
                  children: OO("general:join")
                }), (0, DO.jsx)(ZO.g, {
                  tooltipInner: (0, DO.jsx)(DO.Fragment, {
                    children: OO("general:decline")
                  }),
                  delayShow: 0,
                  children: (0, DO.jsx)(LO.e, {
                    className: "SocialMenuInviteDecline",
                    padDefaultFocus: "invite" === (null === aK || void 0 === aK ? void 0 : aK.kind) && aK.inviteId === KO.id,
                    onClick: () => {
                      VX.e.declineInvite(KO.id)
                    },
                    analyticsClick: {
                      id: "social.decline_invite",
                      value: `social_menu:${KO.destination.kind}`
                    },
                    children: (0, DO.jsx)(vK.d, {
                      name: "xmark"
                    })
                  })
                })]
              }, KO.id)))]
            }), (0, DO.jsxs)("div", {
              className: eO()("SocialMenuBox SocialMenuRequests", {
                SocialMenuBoxEmpty: !pO && 0 === CO.length
              }),
              children: [(0, DO.jsx)(be.b, {
                label: (0, DO.jsxs)(DO.Fragment, {
                  children: [(0, DO.jsx)(vK.d, {
                    name: Mb.h
                  }), " ", OO("socialBar:requests")]
                }),
                meta: (0, DO.jsxs)(DO.Fragment, {
                  children: [CO.length, CO.length === GO.m && (0, DO.jsx)("span", {
                    className: "SocialSectionTitleLimit",
                    children: OO("socialBar:limitReached")
                  })]
                })
              }), pO && (0, DO.jsx)("div", {
                className: "SocialMenuLoading",
                children: (0, DO.jsx)(TO.e, {})
              }), !pO && 0 === CO.length && (0, DO.jsx)("div", {
                className: "SocialMenuEmpty",
                children: OO("socialBar:noFriendRequests")
              }), !pO && CO.length > 0 && (0, DO.jsx)("div", {
                className: "PlayerRows",
                children: (0, DO.jsx)(ve.b, {
                  lazyLoadedClassName: "SocialMenuRequestsLazy",
                  observerUpdateDeps: [CO],
                  children: CO.map(((KO, pO) => {
                    const XO = AO.get(KO.name);
                    return (0, DO.jsxs)(Xb.d, {
                      playerSocialPreview: KO,
                      zIndex: CO.length - pO,
                      padDefaultFocus: (0, ob.f)(aK, KO.name, pO),
                      status: XO && (0, DO.jsx)(eb.b, {
                        gameNameWithVariation: XO.gameNameWithVariation,
                        isPrivateLobby: XO.isPrivateLobby
                      }),
                      children: [(0, DO.jsx)(ZO.g, {
                        tooltipInner: (0, DO.jsx)(DO.Fragment, {
                          children: OO("general:accept")
                        }),
                        delayShow: 0,
                        children: (0, DO.jsx)(LO.d, {
                          className: "FriendRequestButton",
                          onClick: () => {
                            FO((0, ob.d)(VO, pO)), (0, Db.e)(KO.name, !0, {
                              source: "social_menu",
                              announceFriend: !1
                            })
                          },
                          analyticsClick: {
                            id: "social.accept_friend_request",
                            value: "social_menu"
                          },
                          children: (0, DO.jsx)(vK.d, {
                            name: "check"
                          })
                        })
                      }), (0, DO.jsx)(ZO.g, {
                        tooltipInner: (0, DO.jsx)(DO.Fragment, {
                          children: OO("general:decline")
                        }),
                        delayShow: 0,
                        children: (0, DO.jsx)(LO.e, {
                          className: "FriendRequestButton",
                          onClick: () => {
                            FO((0, ob.d)(VO, pO)), (0, Db.e)(KO.name, !1, {
                              source: "social_menu"
                            })
                          },
                          analyticsClick: {
                            id: "social.decline_friend_request",
                            value: "social_menu"
                          },
                          children: (0, DO.jsx)(vK.d, {
                            name: "xmark"
                          })
                        })
                      })]
                    }, `${KO.name}_${KO.isError}`)
                  }))
                })
              })]
            }), (0, DO.jsx)(eb.d, {})]
          }), (0, DO.jsxs)("div", {
            className: "SocialMenuColumn",
            children: [(0, DO.jsxs)("div", {
              className: "SocialMenuBox SocialMenuParty",
              children: [(0, DO.jsx)(be.b, {
                label: OO("socialBar:party")
              }), (0, DO.jsx)(pb.d, {})]
            }), (0, DO.jsxs)("div", {
              className: "SocialMenuBox SocialMenuFriends",
              children: [(0, DO.jsx)(be.b, {
                label: (0, DO.jsxs)(DO.Fragment, {
                  children: [(0, DO.jsx)(vK.d, {
                    name: Mb.e
                  }), " ", OO("socialBar:friends")]
                }),
                meta: (0, DO.jsxs)(DO.Fragment, {
                  children: [bK.length, bK.length >= (0, GO.c)(MO.getPlayerRanks()) && (0, DO.jsx)("span", {
                    className: "SocialSectionTitleLimit",
                    children: OO("socialBar:limitReached")
                  })]
                })
              }), pO && (0, DO.jsx)("div", {
                className: "SocialMenuLoading",
                children: (0, DO.jsx)(TO.e, {})
              }), !pO && 0 === bK.length && (0, DO.jsx)("div", {
                className: "SocialMenuEmpty",
                children: OO("socialBar:noFriends")
              }), !pO && bK.length > 0 && (0, DO.jsx)("div", {
                className: "PlayerRows",
                children: (0, DO.jsx)(ve.b, {
                  lazyLoadedClassName: "SocialMenuFriendsLazy",
                  observerUpdateDeps: [bK],
                  children: bK.map(((OO, pO) => (0, DO.jsx)(Xb.d, {
                    playerSocialPreview: OO,
                    isFriend: !0,
                    hideFriendBadge: !0,
                    onFriendRemoved: OO => {
                      VX.e.removeFriendFromState(OO)
                    },
                    zIndex: bK.length - pO,
                    children: (0, DO.jsx)(Xb.b, {
                      friend: OO,
                      followsLeader: KO,
                      analyticsSurface: "social_menu"
                    })
                  }, `${OO.name}_${OO.isError}`)))
                })
              })]
            })]
          })]
        })
      })
    }
    var Lb = pO(2037);
    const Qb = OO => {
        let {
          action: KO,
          padAction: pO
        } = OO;
        const {
          isTouchScreen: XO
        } = (0, IO.l)(["isTouchScreen"]), bK = (0, Xp.p)();
        return XO && !bK ? null : (0, DO.jsx)(nK.d, {
          className: "EverythingMenuTabKey",
          noaAction: KO,
          padHidesKey: !0,
          padMenuShortcut: pO
        })
      },
      ze = (0, XO.memo)((function() {
        const {
          t: OO
        } = (0, lO.D)(), {
          gameState: KO,
          openEverythingMenuName: pO,
          initSdkSelectorFinished: bK
        } = (0, IO.l)(["gameState", "openEverythingMenuName", "initSdkSelectorFinished"]), {
          userContext: vK
        } = (0, oO.d)(), CO = (0, BO.siteSupportsPurchases)(), hO = (0, cK.D)(), MO = (OO, KO) => (0, DO.jsx)(Qb, {
          action: OO,
          padAction: KO
        }), [aK, FO] = (0, XO.useState)(null), VO = (0, XO.useRef)(null), zK = {
          ..."inGame" === KO ? {} : (0, LO.X)({
            focusOnClick: !1
          }),
          ...op.b
        }, AO = null !== pO, fO = pO !== kp.o.COSMETIC_SHOP;
        async function dO() {
          await async function() {
            if (!aK) return;
            await aK(), FO(null)
          }(), IO.d.set({
            openEverythingMenuName: null
          })
        }
        const TO = (0, XO.useMemo)((() => "inGame" === KO ? {
          text: OO("settingsMenu:exitGame"),
          onClick: () => {
            (0, UX.b)()
          }
        } : (0, jK.e)() ? {
          text: OO("settingsMenu:exitGame"),
          onClick: () => {
            iK.q.discordActivity().then((OO => {
              OO.exit("User exited the game")
            }))
          }
        } : null), [KO, OO]);
        const NO = (0, DO.jsx)("div", {
          className: "EverythingMenuCloseButtonClickZone",
          onClick: () => {
            dO()
          },
          children: (0, DO.jsx)(LO.i, {
            className: "EverythingMenuCloseButton"
          })
        });
        return (0, DO.jsx)(Fp.e, {
          showing: AO,
          globallyUniqueKey: "EverythingMenu",
          alwaysMountChildren: !0,
          keepsMovement: pO === kp.o.SHOP,
          doGameplayStartStopOnShow: "inGame" === KO,
          children: (0, DO.jsx)(Lp.b, {
            className: "EverythingMenuContainer",
            show: AO,
            children: (0, DO.jsx)(Vp.d, {
              close: () => {
                dO()
              },
              togglePointerLock: !1,
              children: (0, DO.jsxs)("div", {
                className: "EverythingMenu",
                children: [!(0, Bp.h)(pO) && (0, DO.jsxs)("div", {
                  className: "EverythingMenuTabList",
                  children: [(0, DO.jsxs)("div", {
                    className: "EverythingMenuTabListButtonContainer EverythingMenuTabListButtonContainerStart",
                    children: [TO && (0, DO.jsx)(LO.c, {
                      className: "EverythingMenuBackButton",
                      padDestructive: !0,
                      onClick: () => {
                        TO.onClick()
                      },
                      children: TO.text
                    }), AO && CO && (0, DO.jsx)("div", {
                      ...zK,
                      className: "EverythingMenuWallet",
                      title: OO("homePage:getPremiumCurrency"),
                      onClick: () => {
                        (0, cK.k)({
                          mode: "current",
                          source: "menuWallet"
                        })
                      },
                      children: (0, DO.jsx)(kb.d, {})
                    })]
                  }), (0, DO.jsxs)("div", {
                    className: "EverythingMenuTabListInner",
                    "data-pad-tabs": "1",
                    children: [(0, DO.jsxs)("div", {
                      ...zK,
                      "data-pad-tab": !0,
                      "data-pad-selected": pO === kp.o.SETTINGS ? "true" : void 0,
                      className: eO()("EverythingMenuTab", {
                        EverythingMenuTabActive: pO === kp.o.SETTINGS
                      }),
                      onClick: () => {
                        IO.d.set({
                          openEverythingMenuName: kp.o.SETTINGS
                        })
                      },
                      children: [OO("general:settings"), MO("OpenSettings", "pause")]
                    }), (0, DO.jsxs)("div", {
                      ...zK,
                      "data-pad-tab": !0,
                      "data-pad-selected": pO === kp.o.CUSTOMISATION ? "true" : void 0,
                      className: eO()("EverythingMenuTab", {
                        EverythingMenuTabActive: pO === kp.o.CUSTOMISATION
                      }),
                      onClick: () => {
                        IO.d.set({
                          openEverythingMenuName: kp.o.CUSTOMISATION
                        })
                      },
                      children: [OO("general:player"), MO("OpenCharacterCustomization")]
                    }), QO.featureFlags.useSocialFeatures && (0, DO.jsxs)("div", {
                      ...zK,
                      "data-pad-tab": !0,
                      "data-pad-selected": pO === kp.o.SOCIAL ? "true" : void 0,
                      className: eO()("EverythingMenuTab", {
                        EverythingMenuTabActive: pO === kp.o.SOCIAL
                      }),
                      ...(0, xK.b)({
                        id: "social.open_menu",
                        value: "menu_tab"
                      }, pO === kp.o.SOCIAL),
                      onClick: () => {
                        IO.d.set({
                          openEverythingMenuName: kp.o.SOCIAL
                        })
                      },
                      children: [OO("socialBar:social"), (0, DO.jsx)(Lb.c, {})]
                    }), CO && (0, DO.jsxs)("div", {
                      ...zK,
                      "data-pad-tab": !0,
                      "data-pad-selected": pO === kp.o.COSMETIC_SHOP ? "true" : void 0,
                      className: eO()("EverythingMenuTab EverythingMenuTabCosmeticShop", {
                        EverythingMenuTabActive: pO === kp.o.COSMETIC_SHOP
                      }),
                      onClick: () => {
                        IO.d.set({
                          openEverythingMenuName: kp.o.COSMETIC_SHOP
                        })
                      },
                      children: [(0, DO.jsx)("span", {
                        className: "EverythingMenuTabCosmeticShopText",
                        children: OO("store:title")
                      }), "dot" === hO && (0, DO.jsx)("span", {
                        className: "EverythingMenuTabStoreBadge EverythingMenuTabStoreDot"
                      })]
                    }), "inGame" === KO && (0, DO.jsxs)("div", {
                      ...zK,
                      "data-pad-tab": !0,
                      "data-pad-selected": pO === kp.o.LOBBY_LEADERBOARD ? "true" : void 0,
                      className: eO()("EverythingMenuTab", {
                        EverythingMenuTabActive: pO === kp.o.LOBBY_LEADERBOARD
                      }),
                      onClick: () => {
                        IO.d.set({
                          openEverythingMenuName: kp.o.LOBBY_LEADERBOARD
                        })
                      },
                      children: [OO("general:lobby"), MO("OpenLobbyLeaderboard", "leaderboard")]
                    })]
                  }), (0, DO.jsx)("div", {
                    className: "EverythingMenuTabListButtonContainer EverythingMenuTabListButtonContainerEnd",
                    children: NO
                  })]
                }), (0, Bp.h)(pO) && NO, (0, DO.jsxs)("div", {
                  className: "EverythingMenuBody",
                  "data-pad-initial-area": !0,
                  style: {
                    "--everythingMenuBodyBackgroundOpacity": "inGame" === KO ? "0.85" : "1"
                  },
                  children: [(0, DO.jsx)(Cp, {
                    show: pO === kp.o.SETTINGS,
                    setBeforeResumeCallback: FO
                  }), (0, DO.jsx)(aX, {
                    show: pO === kp.o.CUSTOMISATION
                  }), (0, DO.jsx)(XO.Suspense, {
                    fallback: null,
                    children: (0, DO.jsx)(rX, {
                      show: pO === kp.o.SHOP
                    })
                  }), (0, DO.jsx)(qX, {
                    show: pO === kp.o.LOBBY_LEADERBOARD
                  }), (0, DO.jsx)(tb, {
                    show: pO === kp.o.COSMETIC_SHOP
                  }), (0, DO.jsx)(Fb, {
                    show: pO === kp.o.SOCIAL
                  })]
                }), !(0, QO.isMobileApp)() && (0, Qp.e)(vK.getPlayerRanks()) && (0, DO.jsx)(Lp.b, {
                  ref: VO,
                  className: "EverythingMenuBannerDiv",
                  show: fO,
                  "data-pad-hint-bar-avoid": !0,
                  "data-pad-no-step-in": !0,
                  children: (0, DO.jsx)(Ob.b, {
                    info: {
                      adId: 2,
                      adType: "leaderboard",
                      adAlias: "banner_shop"
                    },
                    sizeInfo: {
                      parentRef: VO
                    },
                    showing: AO && fO,
                    verticalAlign: "center",
                    horizontalAlign: "center",
                    noFillShowBloxdAdProbability: 1
                  })
                })]
              })
            })
          })
        })
      }))
  },
  8319: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO
    });
    var XO = pO(256),
      bK = pO(8321);

    function eO(OO, KO, pO) {
      const eO = Object.entries(KO).sort(((OO, KO) => KO[1] - OO[1])),
        lO = (0, XO.ob)(OO);
      lO.push(OO ? "\n\n" : "\n");
      for (const [bK, FO] of eO) {
        var vK, CO, hO;
        const OO = null !== (vK = null === pO || void 0 === pO || null === (CO = pO[bK]) || void 0 === CO ? void 0 : CO.icon) && void 0 !== vK ? vK : `${bK} Enchantment`;
        lO.push({
          icon: OO,
          style: {
            fontSize: "1.5rem"
          }
        }), lO.push({
          str: `${bK} ${null!==(hO=(0,XO.O)(FO))&&void 0!==hO?hO:FO}\n`
        })
      }
      lO.push({
        str: "\n"
      });
      for (const [XO, FO] of eO) {
        var DO, MO, aK, oO;
        const OO = null !== (DO = null === pO || void 0 === pO || null === (MO = pO[XO]) || void 0 === MO ? void 0 : MO.icon) && void 0 !== DO ? DO : `${XO} Enchantment`,
          KO = null !== (aK = null === pO || void 0 === pO || null === (oO = pO[XO]) || void 0 === oO ? void 0 : oO.description) && void 0 !== aK ? aK : (0, bK.n)(XO);
        lO.push({
          icon: OO,
          style: {
            fontSize: "1.25rem",
            opacity: .75
          }
        }), lO.push({
          str: KO,
          style: {
            fontSize: "0.8em",
            fontWeight: "normal",
            opacity: .75
          }
        }), lO.push({
          str: "\n"
        })
      }
      return lO
    }
  },
  8330: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => MO,
      e: () => hO,
      g: () => zK,
      k: () => LO,
      l: () => CO,
      n: () => QO,
      r: () => DO,
      t: () => aK,
      w: () => VO
    });
    var XO = pO(243),
      bK = pO(533),
      eO = pO(256),
      lO = pO(3509),
      vK = pO(8319);

    function CO(OO, KO) {
      var pO;
      let {
        player: XO,
        chestOrCreative: bK
      } = OO;
      var eO;
      return KO < XO.length ? null !== (eO = XO[KO]) && void 0 !== eO ? eO : null : null !== (pO = bK[KO - XO.length]) && void 0 !== pO ? pO : null
    }

    function hO(OO) {
      var KO;
      return null !== (KO = OO.amount) && void 0 !== KO ? KO : 0
    }

    function DO(OO) {
      return 0 === OO.button || void 0 === OO.button
    }

    function MO(OO) {
      return !!OO.shiftKey
    }

    function aK(OO) {
      return "touches" in OO || "touch" === OO.pointerType || "pen" === OO.pointerType
    }
    const oO = new Set,
      FO = 50;

    function VO(OO, KO) {
      var pO;
      const XO = null === (pO = OO[KO]) || void 0 === pO ? void 0 : pO.displayName;
      return (0, bK.I)(XO) ? "string" !== typeof KO ? "" : (!oO.has(KO) && oO.size < FO && (oO.add(KO), console.warn(`No item called "${KO}", so its hover shows the name as given`)), KO) : XO
    }

    function LO(OO, KO, pO) {
      var CO, hO, DO, MO, aK, oO, FO, LO, QO, zK, AO, fO, dO, TO;
      const NO = OO.attributes,
        IO = null !== (CO = null === (hO = KO[OO.name]) || void 0 === hO ? void 0 : hO.rootName) && void 0 !== CO ? CO : OO.name,
        yK = null !== (DO = null !== (MO = NO.customDisplayName) && void 0 !== MO ? MO : null === (aK = KO[OO.name]) || void 0 === aK ? void 0 : aK.displayName) && void 0 !== DO ? DO : VO(KO, IO);
      let gK = yK;
      const uO = null === (oO = NO.customAttributes) || void 0 === oO ? void 0 : oO.enchantmentTier;
      uO && (gK = (0, eO.ob)(yK, {
        colour: eO.hb[uO]
      }));
      const EO = null !== (FO = null !== (LO = null !== (QO = function(OO, KO) {
        var pO;
        if (void 0 === OO || null !== (pO = KO.customAttributes) && void 0 !== pO && pO.author) return OO;
        const bK = (0, XO.cc)(OO);
        return bK.every((OO => "string" === typeof OO)) ? OO : bK.map((OO => "string" === typeof OO ? OO : {
          icon: OO.icon,
          style: {
            fontSize: "1.5em"
          }
        }))
      }(NO.customDescription, NO)) && void 0 !== QO ? QO : null === (zK = KO[OO.name]) || void 0 === zK ? void 0 : zK.description) && void 0 !== LO ? LO : null === (AO = KO[IO]) || void 0 === AO ? void 0 : AO.description) && void 0 !== FO ? FO : "";
      let jK = EO;
      if (null !== (fO = NO.customAttributes) && void 0 !== fO && fO.enchantments) jK = (0, vK.b)(EO, NO.customAttributes.enchantments, NO.customAttributes.enchantmentData);
      else if (pO[IO]) jK = (0, eO.ob)(EO), jK.push({
        str: "\n"
      }), jK.push({
        str: "Enchantable",
        style: {
          fontSize: "0.8em",
          fontWeight: "normal",
          opacity: .4
        }
      });
      else if (null !== (dO = NO.customAttributes) && void 0 !== dO && dO.mobSettings) {
        var YO, wO;
        const OO = NO.customAttributes.mobSettings;
        var iK, rK;
        if (jK = [], (0, bK.I)(NO.customAttributes.health) || (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Health",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: NO.customAttributes.health.toString()
          }), (0, bK.I)(OO.maxHealth) || (jK.push({
            str: "/"
          }), jK.push({
            str: OO.maxHealth.toString()
          }))), !(0, bK.I)(OO.attackDamage) && OO.attackDamage > 0 && (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Iron Sword",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: OO.attackDamage.toString()
          })), !(0, bK.I)(OO.secondaryAttackDamage) && OO.secondaryAttackDamage > 0 && (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Stone Crossbow",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: OO.secondaryAttackDamage.toString()
          })), (0, bK.I)(OO.baseRunningSpeed) || (jK.push({
            str: "\n"
          }), jK.push({
            icon: "Speed",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: " "
          }), jK.push({
            str: OO.baseRunningSpeed.toFixed(2)
          })), "Saddled" === OO.metaInfo) jK.push({
          str: "\n"
        }), jK.push({
          str: {
            translationKey: "general:has"
          }
        }), jK.push({
          str: " "
        }), jK.push({
          icon: null !== (iK = null === (rK = OO.tameInfo) || void 0 === rK ? void 0 : rK.saddleItemName) && void 0 !== iK ? iK : "Saddle",
          style: {
            fontSize: "1.5em"
          }
        });
        if (jK.push({
            str: "\n"
          }), jK.push({
            str: "\n"
          }), OO.petInfo && null !== (YO = OO.tameInfo) && void 0 !== YO && YO.supportsFriendship) {
          const KO = lO.b.getIconsFromFriendshipPoints(OO.petInfo.friendshipPoints);
          for (const OO of KO) jK.push({
            icon: OO,
            style: {
              fontSize: "1.5em"
            }
          });
          jK.push({
            str: "\n"
          });
          const pO = lO.b.getMobHungerLevel(OO.petInfo.lastFedAt);
          for (const OO of lO.b.hungerLevelIcons[pO]) jK.push({
            icon: OO,
            style: {
              fontSize: "1.5em"
            }
          });
          jK.push({
            str: " "
          }), jK.push({
            str: lO.b.hungerLevelTranslations[pO],
            style: {
              fontWeight: "bolder"
            }
          })
        }
        if (OO.tameInfo && null !== (wO = OO.tameInfo) && void 0 !== wO && wO.supportsFriendship) {
          var PO, mK;
          let KO = null !== (PO = OO.tameInfo.likedFoods) && void 0 !== PO ? PO : [];
          jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Superliked]
            }
          }), jK.push({
            str: " "
          }), null !== (mK = OO.petInfo) && void 0 !== mK && mK.superlikedFoodKnown ? (jK.push({
            icon: OO.petInfo.superlikedFood,
            style: {
              fontSize: "1.5em"
            }
          }), KO = KO.filter((KO => KO !== OO.petInfo.superlikedFood))) : jK.push({
            icon: "Question Mark",
            style: {
              fontSize: "1.5em"
            }
          }), jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Liked]
            }
          }), jK.push({
            str: " "
          });
          for (const OO of KO) jK.push({
            icon: OO,
            style: {
              fontSize: "1.5em"
            }
          });
          jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Neutral]
            }
          }), jK.push({
            str: " "
          });
          for (const pO of null !== (sO = OO.tameInfo.neutralFoods) && void 0 !== sO ? sO : []) {
            var sO;
            jK.push({
              icon: pO,
              style: {
                fontSize: "1.5em"
              }
            })
          }
          jK.push({
            str: "\n"
          }), jK.push({
            icon: "Pixelated Heart",
            style: {
              fontSize: "1.5em",
              color: lO.b.feedTextColours[lO.b.MobFoodType.Disliked]
            }
          }), jK.push({
            str: " "
          });
          for (const pO of null !== (HO = OO.tameInfo.dislikedFoods) && void 0 !== HO ? HO : []) {
            var HO;
            jK.push({
              icon: pO,
              style: {
                fontSize: "1.5em"
              }
            })
          }
        }
        jK.length > 0 ? (jK.shift(), jK.unshift(...(0, eO.ob)(EO))) : jK = (0, eO.ob)(EO)
      }
      return {
        name: gK,
        desc: jK,
        fontStyle: null !== (TO = NO.customAttributes) && void 0 !== TO && TO.author ? "italic" : "normal"
      }
    }

    function QO(OO, KO, pO, XO) {
      const bK = CO(OO, pO),
        eO = CO(OO, XO);
      if (!bK) return !1;
      const lO = KO[bK.name].armourReduction,
        vK = KO[eO.name].armourReduction;
      if (vK === lO) {
        var hO, DO, MO, aK;
        const OO = null !== (hO = null === (DO = bK.attributes.customAttributes) || void 0 === DO ? void 0 : DO.enchantmentTier) && void 0 !== hO ? hO : "Tier 0",
          KO = null !== (MO = null === (aK = eO.attributes.customAttributes) || void 0 === aK ? void 0 : aK.enchantmentTier) && void 0 !== MO ? MO : "Tier 0";
        return parseInt(OO.replace("Tier ", "")) >= parseInt(KO.replace("Tier ", ""))
      }
      return lO > vK
    }

    function zK(OO) {
      let KO;
      if ("number" === typeof OO) {
        const pO = document.querySelector(`[data-inven-idx="${OO}"]`);
        if (!pO) return null;
        KO = pO.getBoundingClientRect()
      } else KO = OO.getBoundingClientRect();
      return {
        x: KO.left + KO.width / 2,
        y: KO.top + KO.height / 2
      }
    }
  },
  8268: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => oO,
      e: () => FO,
      i: () => VO
    });
    var XO = pO(1271),
      bK = pO(63),
      eO = pO(1152),
      lO = pO(3719),
      vK = pO(1912),
      CO = pO(1051),
      hO = pO(94),
      DO = pO(1583),
      MO = pO(1180),
      aK = pO(976);

    function oO(OO) {
      let {
        show: KO,
        onClose: pO
      } = OO;
      const {
        requestedGameNameWithVariation: XO,
        lobbyName: bK,
        shownLobbyName: eO
      } = (0, DO.i)("connectedGame"), CO = (0, vK.b)(XO, bK, !1);
      return hO.featureFlags.canUseInviteLinks && (0, aK.jsx)(lO.d, {
        show: KO,
        close: pO,
        padShowsHud: !0,
        togglePointerLock: !1,
        globallyUniqueKey: "InviteLinkBox",
        doGameplayStartStopOnShow: !0,
        children: (0, aK.jsxs)("div", {
          className: "InviteLinkBox AnimFadeInScaleUp",
          children: [(0, aK.jsx)("div", {
            className: "InviteLinkBoxHeader SmallTextBold",
            children: "Invite Friends"
          }), (0, aK.jsxs)("div", {
            className: "InviteLinkBoxDescription SmallTextLight",
            children: [(0, aK.jsx)("div", {
              className: "InviteLinkBoxSubheader SmallTextBold",
              children: '"Join Lobby Name" Button Info'
            }), "Game: ", null === CO ? (0, aK.jsx)(MO.e, {}) : CO, (0, aK.jsx)("br", {}), "Lobby Name: ", eO, (0, aK.jsx)("br", {}), (0, aK.jsx)("br", {}), (0, aK.jsx)("br", {}), (0, aK.jsx)("div", {
              className: "InviteLinkBoxSubheader SmallTextBold",
              children: "Link"
            })]
          }), (0, aK.jsx)(FO, {})]
        })
      })
    }

    function FO() {
      var OO;
      const {
        t: KO
      } = (0, CO.D)(), pO = null !== (OO = VO(hO.featureFlags.canUseInviteLinks)) && void 0 !== OO ? OO : "Loading Link...", [eO, lO] = (0, bK.useState)(0), [vK, DO] = (0, bK.useReducer)((OO => OO + 1), 0);
      return (0, bK.useEffect)((() => {
        const OO = setTimeout((() => {
          DO()
        }), 1100);
        return () => {
          clearTimeout(OO)
        }
      }), [eO]), hO.featureFlags.canUseInviteLinks && (0, aK.jsxs)("div", {
        className: "InviteLinkInnerWrapper",
        children: [(0, aK.jsx)("div", {
          className: "InviteLinkInner",
          children: pO
        }), (0, aK.jsx)(XO.d, {
          className: "InviteLinkCopyButton",
          onClick: () => {
            navigator.clipboard.writeText(pO).catch((OO => {
              console.error("Failed to copy invite link:", OO)
            })), lO(Date.now())
          },
          disabled: Date.now() - eO < 1e3,
          children: Date.now() - eO < 1e3 ? KO("general:copied") : KO("general:copy")
        })]
      })
    }

    function VO(OO) {
      const [KO, pO] = (0, bK.useState)(null);
      return (0, bK.useEffect)((() => {
        if (!OO) return;
        let KO = !0;
        return (0, eO.I)().then((OO => {
          KO && pO(OO)
        })).catch((OO => {
          console.error("Failed to get invite link:", OO)
        })), () => {
          KO = !1
        }
      }), [OO]), KO
    }
  },
  8303: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(1583),
      vK = pO(976);

    function CO(OO) {
      const KO = Math.floor(OO / 3600),
        pO = Math.floor(OO % 3600 / 60),
        XO = Math.floor(OO % 60),
        bK = `${pO.toString().padStart(2,"0")}:${XO.toString().padStart(2,"0")}`;
      return KO > 0 ? `${KO}:${bK}` : bK
    }
    const hO = (0, XO.memo)((function(OO) {
      let {
        className: KO
      } = OO;
      const {
        recording: pO,
        seconds: XO
      } = (0, lO.i)("replayRecorder");
      return pO ? (0, vK.jsxs)("div", {
        className: eO()("RecordingIndicator", KO),
        children: [(0, vK.jsx)("span", {
          className: "RecordingIndicatorDot"
        }), (0, vK.jsx)("span", {
          className: "RecordingIndicatorLabel",
          children: "REC"
        }), (0, vK.jsx)("span", {
          className: "RecordingIndicatorTime",
          children: CO(XO)
        })]
      }) : null
    }))
  },
  4012: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => LO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(3819),
      lO = pO(1051),
      vK = pO(933),
      CO = pO(1271),
      hO = pO(1329),
      DO = pO(1187),
      MO = pO(2007),
      aK = pO(976);
    const oO = {
      youtube: {
        icon: "youtube",
        color: "#FF0033",
        name: "YouTube"
      },
      tiktok: {
        icon: "tiktok",
        color: "#0F0F0F",
        name: "TikTok"
      },
      instagram: {
        icon: "instagram",
        color: "#E1306C",
        name: "Instagram"
      },
      twitter: {
        icon: "x-twitter",
        color: "#0F0F0F",
        name: "X"
      },
      twitch: {
        icon: "twitch",
        color: "#9146FF",
        name: "Twitch"
      }
    };

    function FO(OO) {
      let {
        platform: KO
      } = OO;
      const pO = "youtube" === KO;
      return (0, aK.jsxs)("span", {
        className: bK()("PlayerProfileSocialLinkIcon", {
          PlayerProfileSocialLinkIconYoutube: pO
        }),
        children: [pO && (0, aK.jsx)(MO.b, {
          variant: "white"
        }), !pO && (0, aK.jsx)(vK.d, {
          name: oO[KO].icon,
          kit: "brands"
        })]
      })
    }

    function VO(OO) {
      let {
        platform: KO,
        link: pO,
        editable: XO,
        userContext: bK,
        onLinksUpdated: MO
      } = OO;
      const {
        t: VO
      } = (0, lO.D)(), LO = oO[KO];
      if (!pO && !XO) return null;

      function QO() {
        var OO;
        if (!bK || !MO) return;
        DO.NotificationProvider.showInputPopup({
          title: "homePage:profileSocialLinkEditTitle",
          textOpts: {
            title: {
              platform: LO.name
            }
          },
          prefixText: eO.A[KO],
          placeholderText: "playBloxd",
          initialValue: null !== (OO = null === pO || void 0 === pO ? void 0 : pO.handle) && void 0 !== OO ? OO : "",
          maxLength: 30,
          submitText: "general:save",
          secondaryButtonText: pO ? "general:remove" : void 0
        }).getResult().then((async OO => {
          if ("notificationTornDown" !== OO && null !== OO) try {
            "submit" === OO.type ? await hO.c.setSocialLink(bK, KO, OO.value) : await hO.c.clearSocialLink(bK, KO), MO()
          } catch (pO) {
            console.error("Failed to update social link", pO), DO.NotificationProvider.showAlertPopup({
              title: pO.errorMessageForUser,
              confirmText: "general:ok"
            })
          }
        }))
      }
      if (pO) {
        const OO = `@${pO.handle}`;
        return (0, aK.jsxs)("a", {
          className: "PlayerProfileSocialLink",
          style: {
            background: LO.color
          },
          href: pO.profileUrl,
          target: "_blank",
          rel: "noopener noreferrer",
          children: [(0, aK.jsxs)("div", {
            className: "PlayerProfileSocialLinkMain",
            children: [(0, aK.jsx)(FO, {
              platform: KO
            }), (0, aK.jsx)("span", {
              className: "PlayerProfileSocialLinkText",
              children: (0, aK.jsx)("span", {
                className: "PlayerProfileSocialLinkName SmallTextBold",
                children: OO
              })
            })]
          }), XO && (0, aK.jsx)("button", {
            type: "button",
            className: "PlayerProfileSocialLinkEditButton",
            ...(0, CO.X)({
              stopPropagation: !0
            }),
            onClick: OO => {
              OO.stopPropagation(), OO.preventDefault(), QO()
            },
            children: (0, aK.jsx)(vK.d, {
              name: "pen-to-square"
            })
          }), !XO && (0, aK.jsx)("span", {
            className: "PlayerProfileSocialLinkArrow",
            children: (0, aK.jsx)(vK.d, {
              name: "arrow-up-right-from-square"
            })
          })]
        })
      }
      return (0, aK.jsxs)("button", {
        type: "button",
        className: "PlayerProfileSocialLink PlayerProfileSocialLinkUnlinked",
        style: {
          background: LO.color
        },
        ...(0, CO.X)(),
        onClick: () => {
          QO()
        },
        children: [(0, aK.jsx)(FO, {
          platform: KO
        }), (0, aK.jsxs)("span", {
          className: "PlayerProfileSocialLinkText",
          children: [(0, aK.jsx)("span", {
            className: "PlayerProfileSocialLinkName SmallTextBold",
            children: LO.name
          }), (0, aK.jsx)("span", {
            className: "PlayerProfileSocialLinkCount SmallTextLight",
            children: VO("homePage:profileSocialLinkAdd")
          })]
        }), (0, aK.jsx)("span", {
          className: "PlayerProfileSocialLinkEditButton",
          children: (0, aK.jsx)(vK.d, {
            name: "pen-to-square"
          })
        })]
      })
    }

    function LO(OO) {
      let {
        socialLinks: KO,
        editable: pO = !1,
        userContext: XO,
        onLinksUpdated: bK
      } = OO;
      if (!pO && 0 === KO.length) return null;
      const lO = new Map(KO.map((OO => [OO.platform, OO]))),
        vK = pO ? eO.w : KO.map((OO => OO.platform));
      return (0, aK.jsx)("div", {
        className: "PlayerProfileSocialLinks",
        children: (0, aK.jsx)("div", {
          className: "PlayerProfileSocialLinksList",
          children: vK.map((OO => (0, aK.jsx)(VO, {
            platform: OO,
            link: lO.get(OO),
            editable: pO,
            userContext: XO,
            onLinksUpdated: bK
          }, OO)))
        })
      })
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  8256: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      ALL_DEV_TOOLS: () => lO,
      coreDevTools: () => hO,
      devTools: () => CO
    });
    var XO = pO(554),
      bK = pO(1146),
      eO = pO(8263);
    const lO = new Set(["sceneDownload", "ambientLight", "weaponRaycasts", "chunkBorders"]);
    async function vK() {
      const {
        noaDevTools: OO
      } = await pO.e(218).then((() => pO(39125)));
      return OO
    }
    const CO = new class {
        constructor() {
          this.loadHost = vK, this.tools = lO
        }
        setHost(OO) {
          this.tools = null === OO ? lO : OO.tools, this.loadHost = null === OO ? vK : async () => OO
        }
        supports(OO) {
          return this.tools.has(OO)
        }
        async downloadScene(OO, KO) {
          const pO = await this.loadHost();
          await pO.downloadScene(OO, KO)
        }
        async setAmbientLightIntensity(OO) {
          const KO = await this.loadHost();
          await KO.setAmbientLightIntensity(OO)
        }
      },
      hO = {
        tools: eO.b,
        downloadScene: async () => {
          throw new Error("This client can't download the scene")
        },
        setAmbientLightIntensity: async () => {
          throw new Error("This client can't set the ambient light")
        }
      };
    XO.s && CO.setHost(hO), (0, bK.m)((() => {
      CO.setHost(hO)
    }))
  },
  5800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    var XO = pO(36);
    const bK = "shaderPack";
    async function eO() {
      var OO;
      let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return null !== (OO = await XO.d.getItem(bK, KO)) && void 0 !== OO ? OO : null
    }
  },
  8275: (OO, KO, pO) => {
    function XO(OO, KO) {
      return OO && !KO
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  8273: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      f: () => aK
    });
    var XO = pO(22),
      bK = pO(1507),
      eO = pO(36),
      lO = pO(1187),
      vK = pO(2919),
      CO = pO(1302),
      hO = pO(1225);
    const DO = 2592e5,
      MO = "notificationOptInLastPromptedAt";
    async function aK() {
      var OO;
      const KO = await oO();
      if (null === KO) return;
      const pO = null !== (OO = eO.e.getItem(MO)) && void 0 !== OO ? OO : 0;
      if (Date.now() - pO < DO) return;
      if ((0, hO.h)()) return;
      const XO = await lO.NotificationProvider.showPromptPopup({
        icon: "bell",
        title: "mobilePushNotifications:optInTitle",
        subtitle: (0, bK.h)() ? "mobilePushNotifications:optInSubtitle" : "mobilePushNotifications:optInSubtitleBrowser",
        confirmText: "mobilePushNotifications:optInConfirm",
        cancelText: "mobilePushNotifications:optInCancel",
        padStartsOnCancel: !0
      }).getResult();
      "notificationTornDown" !== XO && (eO.e.setItem(MO, Date.now()), (0, CO.e)({
        id: !0 === XO ? "push.allow" : "push.deny",
        value: (0, bK.h)() ? "app" : "browser"
      }), !0 === XO && KO())
    }
    async function oO() {
      return (0, bK.h)() ? XO.d.get("mobilePushNotificationsCanAsk") ? async () => {
        (0, bK.o)("requestNotificationPermission", {})
      }: null: await vK.d.canAsk() ? () => vK.d.requestPermission() : null
    }
  },
  8336: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    const XO = {
        timeRemaining: () => 1 / 0
      },
      bK = OO => {
        var KO;
        const pO = globalThis,
          bK = null !== (KO = pO.nativeRequestIdleCallback) && void 0 !== KO ? KO : pO.requestIdleCallback,
          eO = pO.cancelIdleCallback;
        if ("function" === typeof bK && "function" === typeof eO) {
          const KO = bK.call(globalThis, OO);
          return () => {
            eO.call(globalThis, KO)
          }
        }
        const lO = setTimeout((() => {
          OO(XO)
        }), 100);
        return () => {
          clearTimeout(lO)
        }
      }
  },
  8290: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      g: () => CO
    });
    var XO = pO(22);
    const bK = 24,
      eO = "farNametags",
      lO = 1e5;

    function vK() {
      var OO;
      return null === (OO = XO.d.get("showDistantNametags")) || void 0 === OO || OO
    }

    function CO() {
      var OO;
      return null !== (OO = function() {
        const OO = new URLSearchParams(window.location.search).get(eO),
          KO = null === OO || "" === OO ? NaN : Number(OO);
        return Number.isFinite(KO) && KO >= 0 ? Math.min(KO, lO) : null
      }()) && void 0 !== OO ? OO : vK() ? 0 : bK
    }
  },
  8333: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      e: () => lO
    });
    const XO = [{
      threshold: 10n ** 180n,
      suffix: "NoQig"
    }, {
      threshold: 10n ** 177n,
      suffix: "OcQig"
    }, {
      threshold: 10n ** 174n,
      suffix: "SpQig"
    }, {
      threshold: 10n ** 171n,
      suffix: "SQig"
    }, {
      threshold: 10n ** 168n,
      suffix: "QiQig"
    }, {
      threshold: 10n ** 165n,
      suffix: "QaQig"
    }, {
      threshold: 10n ** 162n,
      suffix: "TQig"
    }, {
      threshold: 10n ** 159n,
      suffix: "DQig"
    }, {
      threshold: 10n ** 156n,
      suffix: "UQig"
    }, {
      threshold: 10n ** 153n,
      suffix: "Qig"
    }, {
      threshold: 10n ** 150n,
      suffix: "NoQag"
    }, {
      threshold: 10n ** 147n,
      suffix: "OcQag"
    }, {
      threshold: 10n ** 144n,
      suffix: "SpQag"
    }, {
      threshold: 10n ** 141n,
      suffix: "SQag"
    }, {
      threshold: 10n ** 138n,
      suffix: "QiQag"
    }, {
      threshold: 10n ** 135n,
      suffix: "QaQag"
    }, {
      threshold: 10n ** 132n,
      suffix: "TQag"
    }, {
      threshold: 10n ** 129n,
      suffix: "DQag"
    }, {
      threshold: 10n ** 126n,
      suffix: "UQag"
    }, {
      threshold: 10n ** 123n,
      suffix: "Qag"
    }, {
      threshold: 10n ** 120n,
      suffix: "NoTg"
    }, {
      threshold: 10n ** 117n,
      suffix: "OcTg"
    }, {
      threshold: 10n ** 114n,
      suffix: "SpTg"
    }, {
      threshold: 10n ** 111n,
      suffix: "STg"
    }, {
      threshold: 10n ** 108n,
      suffix: "QiTg"
    }, {
      threshold: 10n ** 105n,
      suffix: "QaTg"
    }, {
      threshold: 10n ** 102n,
      suffix: "TTg"
    }, {
      threshold: 10n ** 99n,
      suffix: "DTg"
    }, {
      threshold: 10n ** 96n,
      suffix: "UTg"
    }, {
      threshold: 10n ** 93n,
      suffix: "Tg"
    }, {
      threshold: 10n ** 90n,
      suffix: "NoVg"
    }, {
      threshold: 10n ** 87n,
      suffix: "OcVg"
    }, {
      threshold: 10n ** 84n,
      suffix: "SpVg"
    }, {
      threshold: 10n ** 81n,
      suffix: "SVg"
    }, {
      threshold: 10n ** 78n,
      suffix: "QiVg"
    }, {
      threshold: 10n ** 75n,
      suffix: "QaVg"
    }, {
      threshold: 10n ** 72n,
      suffix: "TVg"
    }, {
      threshold: 10n ** 69n,
      suffix: "DVg"
    }, {
      threshold: 10n ** 66n,
      suffix: "UVg"
    }, {
      threshold: 10n ** 63n,
      suffix: "Vg"
    }, {
      threshold: 10n ** 60n,
      suffix: "NoD"
    }, {
      threshold: 10n ** 57n,
      suffix: "OcD"
    }, {
      threshold: 10n ** 54n,
      suffix: "SpD"
    }, {
      threshold: 10n ** 51n,
      suffix: "SD"
    }, {
      threshold: 10n ** 48n,
      suffix: "QiD"
    }, {
      threshold: 10n ** 45n,
      suffix: "QaD"
    }, {
      threshold: 10n ** 42n,
      suffix: "TD"
    }, {
      threshold: 10n ** 39n,
      suffix: "DD"
    }, {
      threshold: 10n ** 36n,
      suffix: "UD"
    }, {
      threshold: 10n ** 33n,
      suffix: "D"
    }, {
      threshold: 10n ** 30n,
      suffix: "No"
    }, {
      threshold: 10n ** 27n,
      suffix: "Oc"
    }, {
      threshold: 10n ** 24n,
      suffix: "Sep"
    }, {
      threshold: 10n ** 21n,
      suffix: "S"
    }, {
      threshold: 10n ** 18n,
      suffix: "Qi"
    }, {
      threshold: 10n ** 15n,
      suffix: "Qa"
    }, {
      threshold: 10n ** 12n,
      suffix: "T"
    }, {
      threshold: 10n ** 9n,
      suffix: "B"
    }, {
      threshold: 10n ** 6n,
      suffix: "M"
    }, {
      threshold: 1000n,
      suffix: "K"
    }];

    function bK(OO) {
      let KO, pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3;
      if ("number" === typeof OO) {
        if (!Number.isFinite(OO)) return "0";
        if (Math.abs(OO) < 100) {
          const KO = OO < 0 ? "-" : "",
            pO = Math.abs(OO);
          return pO >= 10 ? `${KO}${pO.toFixed(1).replace(/\.0$/,"")}` : `${KO}${pO.toFixed(2).replace(/\.?0+$/,"")}`
        }
        KO = BigInt(Math.floor(OO))
      } else KO = OO;
      const bK = KO < 0n ? -KO : KO,
        eO = KO < 0n ? "-" : "",
        lO = bK.toString();
      if (lO.length <= pO) return `${eO}${lO}`;
      const vK = 3 * Math.floor((lO.length - 1) / 3);
      if (vK < 3) return `${eO}${lO}`;
      if (vK > 3 * XO.length) {
        const OO = lO[0],
          KO = lO.slice(1, 3).replace(/0+$/, "");
        return `${eO}${KO?`${OO}.${KO}`:OO}e${lO.length-1}`
      }
      const {
        threshold: CO,
        suffix: hO
      } = XO[XO.length - vK / 3], DO = bK / CO, MO = Number(1000n * (bK % CO) / CO), aK = Number(DO) + MO / 1e3;
      let oO;
      return oO = aK >= 100 ? Math.floor(aK).toString() : aK >= 10 ? aK.toFixed(1).replace(/\.0$/, "") : aK.toFixed(2).replace(/\.?0+$/, ""), `${eO}${oO}${hO}`
    }
    const eO = XO.map((OO => {
      let {
        threshold: KO,
        suffix: pO
      } = OO;
      return {
        threshold: Number(KO),
        suffix: pO
      }
    })).filter((OO => {
      let {
        threshold: KO
      } = OO;
      return Number.isFinite(KO)
    }));

    function lO(OO) {
      const KO = Math.abs(OO),
        pO = OO < 0 ? "-" : "";
      for (const {
          threshold: XO,
          suffix: bK
        }
        of eO)
        if (KO >= XO) {
          const OO = KO / XO;
          if (OO >= 1e3) return `${pO}${KO.toExponential(2).replace("e+","e")}`;
          let eO;
          return eO = OO >= 100 ? Math.floor(OO).toString() : OO >= 10 ? OO.toFixed(1).replace(/\.0$/, "") : OO.toFixed(2).replace(/\.?0+$/, ""), `${pO}${eO}${bK}`
        } return `${pO}${KO}`
    }
  },
  8321: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => DO,
      i: () => aK,
      m: () => MO,
      n: () => lO,
      r: () => hO,
      u: () => CO
    });
    var XO = pO(256);
    const bK = ["Wood Enchanting Table", "Stone Enchanting Table", "Iron Enchanting Table", "Gold Enchanting Table", "Diamond Enchanting Table"],
      eO = {
        Damage: {
          translationKey: "enchantments:damageDescription"
        },
        "Attack Speed": {
          translationKey: "enchantments:attackSpeedDescription"
        },
        "Critical Damage": {
          translationKey: "enchantments:criticalDamageDescription"
        },
        Protection: {
          translationKey: "enchantments:protectionDescription"
        },
        Health: {
          translationKey: "enchantments:healthDescription"
        },
        "Health Regen": {
          translationKey: "enchantments:healthRegenDescription"
        },
        "Stomp Damage": {
          translationKey: "enchantments:stompDamageDescription"
        },
        "Knockback Resist": {
          translationKey: "enchantments:knockbackResistDescription"
        },
        "Arrow Speed": {
          translationKey: "enchantments:arrowSpeedDescription"
        },
        "Arrow Damage": {
          translationKey: "enchantments:arrowDamageDescription"
        },
        "Quick Charge": {
          translationKey: "enchantments:quickChargeDescription"
        },
        "Break Speed": {
          translationKey: "enchantments:breakSpeedDescription"
        },
        Momentum: {
          translationKey: "enchantments:momentumDescription"
        },
        "Mining Yield": {
          translationKey: "enchantments:miningYieldDescription"
        },
        "Farming Yield": {
          translationKey: "enchantments:farmingYieldDescription"
        },
        "Mining Aura": {
          translationKey: "enchantments:miningAuraDescription"
        },
        "Digging Aura": {
          translationKey: "enchantments:diggingAuraDescription"
        },
        "Lumber Aura": {
          translationKey: "enchantments:lumberAuraDescription"
        },
        "Farming Aura": {
          translationKey: "enchantments:farmingAuraDescription"
        },
        "Horizontal Knockback": {
          translationKey: "enchantments:horizontalKnockbackDescription"
        },
        "Vertical Knockback": {
          translationKey: "enchantments:verticalKnockbackDescription"
        },
        "Firecracker Cooldown": {
          translationKey: "enchantments:firecrackerCooldownDescription"
        },
        "Firecracker Boost": {
          translationKey: "enchantments:firecrackerBoostDescription"
        },
        "Gliding Speed": {
          translationKey: "enchantments:glidingSpeedDescription"
        }
      };

    function lO(OO) {
      var KO;
      return null !== (KO = eO[OO]) && void 0 !== KO ? KO : {
        translationKey: ""
      }
    }
    const vK = {
      "Wood Enchanting Table": [{
        min: 1,
        max: 2
      }, {
        min: 3,
        max: 4
      }, {
        min: 5,
        max: 6
      }],
      "Stone Enchanting Table": [{
        min: 2,
        max: 4
      }, {
        min: 5,
        max: 10
      }, {
        min: 11,
        max: 15
      }],
      "Iron Enchanting Table": [{
        min: 5,
        max: 10
      }, {
        min: 11,
        max: 20
      }, {
        min: 21,
        max: 30
      }],
      "Gold Enchanting Table": [{
        min: 20,
        max: 30
      }, {
        min: 31,
        max: 40
      }, {
        min: 41,
        max: 50
      }],
      "Diamond Enchanting Table": [{
        min: 40,
        max: 50
      }, {
        min: 50,
        max: 70
      }, {
        min: 71,
        max: 80
      }]
    };

    function CO(OO) {
      return bK.includes(OO)
    }

    function hO(OO) {
      var KO;
      return !0 === (null === OO || void 0 === OO || null === (KO = OO.customAttributes) || void 0 === KO ? void 0 : KO.cannotEnchant)
    }

    function DO(OO, KO) {
      const {
        max: pO
      } = vK[OO].at(-1);
      return KO <= pO
    }

    function MO(OO) {
      const KO = Math.sin(OO / 80),
        pO = OO => {
          if (OO <= 0) return 0;
          if (OO > 1) return 1;
          let KO = 0;
          const pO = [1, 7, 21, 35, 35, 21, 7, 1];
          for (let XO = 0; XO < pO.length; XO++) {
            KO += (XO % 2 === 0 ? 1 : -1) * pO[XO] * Math.pow(OO, 2 + XO) / (2 + XO)
          }
          return 72 * KO
        },
        XO = .3 - .78 * KO,
        bK = .5 - .78 * KO,
        eO = .6 - .7 * KO,
        lO = .8 - .6 * KO;
      let vK = pO(XO),
        CO = pO(bK) - vK,
        hO = pO(eO) - CO - vK,
        DO = pO(lO) - hO - CO - vK;
      XO < .041 && (CO /= 1 - vK, hO /= 1 - vK, DO /= 1 - vK, vK = 0), bK < .041 && (vK /= 1 - CO, hO /= 1 - CO, DO /= 1 - CO, CO = 0), eO < .041 && (vK /= 1 - hO, CO /= 1 - hO, DO /= 1 - hO, hO = 0), lO < .041 && (vK /= 1 - DO, CO /= 1 - DO, hO /= 1 - DO, DO = 0);
      return {
        commonProb: vK,
        uncommonProb: CO,
        rareProb: hO,
        epicProb: DO,
        legendaryProb: 1 - (DO + hO + CO + vK)
      }
    }

    function aK(OO, KO) {
      const {
        min: pO,
        max: bK
      } = vK[OO][KO], eO = XO.e.sampleUniformIntDistribution(pO, bK, "includeMax");
      return {
        ...MO(eO),
        level: eO
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);