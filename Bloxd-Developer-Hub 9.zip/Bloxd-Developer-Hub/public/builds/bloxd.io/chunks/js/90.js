export const id = 90;
export const ids = [90];
export const modules = {
  4035: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(933),
      lO = pO(1180),
      vK = pO(2748),
      CO = pO(142),
      hO = pO(2780),
      DO = pO(2769),
      MO = pO(976);

    function aK(OO) {
      let {
        game: KO
      } = OO;
      const pO = (0, CO.o)() ? "large" : "small",
        XO = (0, hO.f)(KO, pO),
        aK = (0, vK.c)(XO),
        oO = void 0 !== aK.blurhash;
      return (0, MO.jsxs)("div", {
        className: "SchematicImageContainer",
        children: [aK.isLoading && !oO && (0, MO.jsx)(lO.e, {
          loaderType: "Secondary"
        }), !aK.failed && (null !== aK.src || oO) && (0, MO.jsx)("div", {
          className: bK()("SchematicImage", DO.m, {
            SchematicImageFadeIn: aK.fadeIn && !oO
          }),
          style: (0, DO.i)(aK),
          children: (0, MO.jsx)(DO.e, {
            image: aK
          })
        }), aK.failed && (0, MO.jsx)("div", {
          className: "SchematicImageError",
          children: (0, MO.jsx)(eO.d, {
            name: "face-dizzy"
          })
        })]
      })
    }
  },
  4158: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => oO
    });
    var XO = pO(63),
      bK = pO(918),
      eO = pO.n(bK),
      lO = pO(4080),
      vK = pO(1180),
      CO = pO(1051),
      hO = pO(2454),
      DO = pO(2571),
      MO = pO(933),
      aK = pO(976);

    function oO(OO) {
      let {
        folderName: KO,
        onTexturePackUpdated: bK,
        disabled: oO = !1,
        maxFileSizeMb: FO,
        packOwner: VO
      } = OO;
      const {
        t: LO
      } = (0, CO.D)(), [QO, zK] = (0, XO.useState)(!1), [AO, fO] = (0, XO.useState)(null), [dO, TO] = (0, XO.useState)(null), NO = (0, XO.useRef)(null);
      const {
        getRootProps: IO,
        getInputProps: yK,
        isDragActive: gK
      } = (0, lO.d)({
        onDrop: async function(OO) {
          zK(!0);
          try {
            const KO = await (0, hO.k)(OO);
            if ("customGame" === VO && (0, DO.j)(KO)) return void fO(LO(DO.b));
            if (void 0 !== FO) {
              const OO = JSON.stringify(KO).length / 1048576;
              if (OO > FO) return void fO(`File size is too large. Max size is ${FO}MB. Current size is ${OO}MB.`)
            }
            fO(null), TO(null), bK(KO), NO.current = KO,
              function(OO, KO) {
                const XO = OO.modelOverrides;
                XO && Promise.all([pO.e(186), pO.e(185)]).then((() => pO(32997))).then((pO => {
                  let {
                    packDisplayName: bK,
                    refusedPackModels: eO,
                    packModelSummary: lO
                  } = pO;
                  const vK = bK(OO.metaData);
                  KO(lO(vK, eO(vK, XO, !1)))
                })).catch((OO => {
                  console.error("Checking the texture pack's models failed:", OO)
                }))
              }(KO, (OO => {
                NO.current === KO && TO(OO)
              }))
          } catch {
            fO("Invalid Texture Pack Folder")
          } finally {
            zK(!1)
          }
        },
        useFsAccessApi: !1,
        disabled: oO
      });
      return (0, aK.jsxs)("div", {
        className: "CustomTexturePackContainer",
        children: [(0, aK.jsxs)("div", {
          className: "CustomTextureWarning",
          children: [LO("settingsMenu:customTextureWarning"), ".", (0, aK.jsx)("br", {}), LO("settingsMenu:viewDocumentation"), ":", " ", (0, aK.jsx)("a", {
            href: "https://github.com/Bloxdy/texturePacks",
            target: "_blank",
            rel: "noreferrer",
            children: "github.com/Bloxdy/texturePacks"
          })]
        }), AO && (0, aK.jsxs)("div", {
          className: "CustomTextureError",
          children: [LO("general:error"), ": ", AO]
        }), dO && (0, aK.jsx)("div", {
          className: "CustomTextureError",
          children: dO
        }), (0, aK.jsxs)("div", {
          ...IO({
            className: eO()("CustomTextureFolderUpload", {
              ActiveDrag: gK,
              Disabled: oO
            })
          }),
          children: [(0, aK.jsx)("input", {
            ...yK({
              webkitdirectory: "true"
            })
          }), QO && (0, aK.jsx)("div", {
            className: "CustomTextureFolderUploadLoading",
            children: (0, aK.jsx)(vK.e, {})
          }), !QO && !gK && KO && (0, aK.jsxs)(aK.Fragment, {
            children: [(0, aK.jsx)("div", {
              className: "CustomTextureFolderUploadIcon Active",
              children: (0, aK.jsx)(MO.d, {
                name: "folder-image"
              })
            }), (0, aK.jsx)("div", {
              className: "CustomTextureFolderUploadInstructions Active",
              children: KO
            })]
          }), !QO && (gK || !KO) && (0, aK.jsxs)(aK.Fragment, {
            children: [(0, aK.jsx)("div", {
              className: "CustomTextureFolderUploadIcon",
              children: (0, aK.jsx)(MO.d, {
                name: "up-from-bracket"
              })
            }), (0, aK.jsx)("div", {
              className: "CustomTextureFolderUploadInstructions",
              children: "Drag and drop a Texture Pack folder here"
            })]
          })]
        })]
      })
    }
  },
  4120: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      e: () => zK,
      h: () => VO,
      j: () => QO
    });
    var XO = pO(63),
      bK = pO(4123),
      eO = pO(3618),
      lO = pO(1195),
      vK = pO(4148),
      CO = pO(918),
      hO = pO.n(CO),
      DO = pO(1187),
      MO = pO(1481),
      aK = pO(4151),
      oO = pO(976);

    function FO(OO) {
      let {
        label: KO,
        onClick: pO,
        checked: XO,
        circleInfoText: bK,
        className: vK,
        disabled: CO
      } = OO;
      return (0, oO.jsx)("div", {
        "aria-disabled": CO || void 0,
        "data-pad-focusable": !0,
        className: hO()("SettingBox CheckboxContainer", {
          [vK]: vK,
          SettingBoxDisabled: CO
        }),
        onClick: () => {
          CO || pO(!XO)
        },
        children: (0, oO.jsxs)("div", {
          className: "CheckboxInputAndText",
          children: [(0, oO.jsx)("label", {
            className: "CheckboxClickableLabel",
            children: (0, oO.jsx)(eO.c, {
              className: "SettingsCheckbox",
              checked: XO,
              disabled: CO,
              onChange: () => {}
            })
          }), (0, oO.jsxs)("div", {
            className: "CheckboxText",
            children: [KO, bK && (0, oO.jsx)("span", {
              onClick: OO => OO.stopPropagation(),
              children: (0, oO.jsx)(lO.c, {
                className: "SettingsTextInputCircleInfo",
                hoverInfo: bK
              })
            })]
          })]
        })
      })
    }

    function VO(OO) {
      let {
        name: KO,
        onChange: pO,
        min: bK,
        max: eO,
        step: vK,
        initValue: CO,
        circleInfoText: DO,
        format: MO,
        className: aK,
        padStep: FO,
        disabled: VO = !1,
        selectableMax: QO,
        cappedNote: zK
      } = OO;
      const [AO, fO] = (0, XO.useState)(CO);
      (0, XO.useEffect)((() => {
        fO(CO)
      }), [CO]);
      const dO = void 0 !== QO && QO < eO,
        TO = dO ? {
          "--slider-selectable": (QO - bK) / (eO - bK)
        } : void 0;
      return (0, oO.jsxs)("div", {
        className: hO()("SettingBox SettingsSliderDiv", {
          [aK]: aK,
          SettingBoxDisabled: VO,
          SliderCapped: dO
        }),
        style: TO,
        children: [(0, oO.jsxs)("div", {
          className: "SliderText",
          children: [`${KO}: ${MO?MO(AO):AO}`, DO && (0, oO.jsx)(lO.c, {
            className: "SettingsTextInputCircleInfo",
            hoverInfo: DO
          })]
        }), (0, oO.jsx)("div", {
          className: "SliderDiv",
          children: (0, oO.jsx)(LO, {
            value: AO,
            min: bK,
            max: eO,
            step: vK,
            onChange: OO => {
              if (dO && OO >= QO && AO === QO) return;
              const KO = dO ? Math.min(OO, QO) : OO;
              fO(KO), pO(KO)
            },
            format: MO,
            padStep: FO,
            disabled: VO
          })
        }), dO && zK && (0, oO.jsx)("div", {
          className: "SliderNote",
          children: zK
        })]
      })
    }

    function LO(OO) {
      var KO;
      let {
        value: pO,
        min: eO,
        max: lO,
        step: vK,
        onChange: CO,
        orientation: hO,
        reverse: DO,
        setIsChanging: MO,
        tooltip: FO,
        labels: VO,
        handleLabel: LO,
        format: QO,
        onChangeStart: zK,
        onChangeComplete: AO,
        padStep: fO,
        disabled: dO = !1
      } = OO;
      const TO = (0, XO.useRef)(null),
        NO = (0, XO.useRef)(null);
      (0, XO.useLayoutEffect)((() => {
        var OO, KO, pO;
        const XO = null !== (OO = null === (KO = TO.current) || void 0 === KO ? void 0 : KO.querySelector(".rangeslider")) && void 0 !== OO ? OO : null;
        null === XO || void 0 === XO || XO.setAttribute("data-pad-slider", ""), null === XO || void 0 === XO || XO.setAttribute("data-pad-focusable", ""), null === XO || void 0 === XO || null === (pO = XO.querySelector(".rangeslider__handle")) || void 0 === pO || pO.setAttribute("data-pad-slider-handle", ""), NO.current = XO
      }), []), (0, XO.useLayoutEffect)((() => {
        var OO, KO;
        dO ? null === (OO = NO.current) || void 0 === OO || OO.setAttribute("aria-disabled", "true") : null === (KO = NO.current) || void 0 === KO || KO.removeAttribute("aria-disabled")
      }), [dO]);
      const IO = (null !== (KO = String(vK).split(".")[1]) && void 0 !== KO ? KO : "").length,
        yK = OO => {
          const KO = Number((Math.round((OO - eO) / vK) * vK + eO).toFixed(IO));
          return Math.min(lO, Math.max(eO, KO))
        },
        gK = (0, XO.useRef)(!1);
      return (0, aK.h)(NO, {
        adjust: OO => {
          if (dO) return;
          const KO = null !== fO && void 0 !== fO ? fO : Math.max(vK, Math.round((lO - eO) / 20 / vK) * vK),
            XO = yK(pO + OO * KO * (DO ? -1 : 1));
          XO !== pO && (null === zK || void 0 === zK || zK(), CO(XO), null === AO || void 0 === AO || AO())
        },
        setFraction: OO => {
          if (dO) return;
          const KO = yK(eO + (DO ? 1 - OO : OO) * (lO - eO));
          KO !== pO && (gK.current || (gK.current = !0, null === zK || void 0 === zK || zK()), CO(KO))
        },
        endDrag: () => {
          gK.current && (gK.current = !1, null === AO || void 0 === AO || AO())
        }
      }), (0, oO.jsx)("div", {
        ref: TO,
        style: {
          display: "contents"
        },
        children: (0, oO.jsx)(bK.c, {
          value: pO,
          min: eO,
          max: lO,
          step: vK,
          onChange: CO,
          orientation: hO,
          reverse: DO,
          tooltip: FO,
          labels: VO,
          handleLabel: LO,
          format: QO,
          onChangeStart: () => {
            null === zK || void 0 === zK || zK(), null === MO || void 0 === MO || MO(!0)
          },
          onChangeComplete: () => {
            null === MO || void 0 === MO || MO(!1), null === AO || void 0 === AO || AO()
          }
        })
      })
    }
    async function QO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
      const KO = DO.NotificationProvider.showPromptPopup({
        title: "settingsMenu:reloadPagePopupTitle",
        subtitle: "settingsMenu:reloadPagePopupSubtitle",
        confirmText: "settingsMenu:reloadPagePopupConfirm",
        confirmTooltip: "",
        cancelText: "general:cancel",
        cancelTooltip: "",
        unlockPointerKey: OO
      });
      !0 === await KO.getResult() && (0, MO.reloadBloxd)()
    }

    function zK(OO) {
      let {
        label: KO,
        options: pO,
        value: XO,
        onChange: bK,
        circleInfoText: eO
      } = OO;
      return (0, oO.jsxs)("div", {
        className: "SettingBox SegmentedSettingRow",
        children: [(0, oO.jsxs)("div", {
          className: "SliderText",
          children: [KO, eO && (0, oO.jsx)(lO.c, {
            className: "SettingsTextInputCircleInfo",
            hoverInfo: eO
          })]
        }), (0, oO.jsx)(vK.c, {
          ariaLabel: KO,
          options: pO,
          value: XO,
          onChange: bK
        })]
      })
    }
  },
  4118: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => QO,
      f: () => zK
    });
    var XO = pO(2454),
      bK = pO(2460),
      eO = pO(63),
      lO = pO(918),
      vK = pO.n(lO),
      CO = pO(1180),
      hO = pO(2446),
      DO = pO(1187),
      MO = pO(4120),
      aK = pO(4158),
      oO = pO(554),
      FO = pO(4160),
      VO = pO(976);

    function LO() {
      (0, MO.j)("texturePackPickReload")
    }

    function QO(OO) {
      var KO;
      let {
        setApplySettingsCallback: pO
      } = OO;
      const [, lO] = (0, eO.useReducer)((OO => OO + 1), 0), vK = (0, eO.useRef)(!1), CO = (0, eO.useRef)(null);

      function QO(OO, KO) {
        hO.c.setFromJson(OO, "player");
        const XO = hO.c.saveTexturePack();
        if (oO.s) {
          const OO = hO.c.toJson();
          XO.then((KO => {
            KO && (0, FO.f)(OO, LO)
          }))
        } else vK.current ||= KO, CO.current !== hO.c.getId() || hO.c.getId() === bK.o.CUSTOM && vK.current ? pO((() => MO.j)) : pO(null);
        lO()
      }
      async function AO(OO) {
        if (hO.c.getId() !== OO.metaData.id) {
          if (hO.c.getId() === bK.o.CUSTOM && hO.c.getFromFolderName()) {
            const OO = DO.NotificationProvider.showPromptPopup({
              title: "settingsMenu:loseChangesTitle",
              subtitle: "settingsMenu:loseChangesSubtitle",
              confirmText: "general:continue",
              destructive: !0,
              confirmTooltip: "",
              cancelText: "general:cancel",
              cancelTooltip: ""
            });
            if (!0 !== await OO.getResult()) return
          }
          QO(OO, !1)
        }
      }(0, eO.useEffect)((() => {
        CO.current = hO.c.getId()
      }), []);
      const fO = XO.c,
        dO = [fO, ...Object.values(bK.o).filter((OO => OO !== fO))];
      return (0, VO.jsx)(VO.Fragment, {
        children: (0, VO.jsxs)("div", {
          className: "TexturePackCategory SettingsMenuRightInner",
          children: [(0, VO.jsx)("div", {
            className: "TexturePackList",
            children: dO.map((OO => (0, VO.jsx)(zK, {
              id: OO,
              isSelected: OO === hO.c.getId(),
              setSelected: AO
            }, OO)))
          }), hO.c.getId() === bK.o.CUSTOM && (0, VO.jsx)(aK.c, {
            folderName: null !== (KO = hO.c.getFromFolderName()) && void 0 !== KO ? KO : null,
            onTexturePackUpdated: function(OO) {
              QO(OO, !0)
            },
            packOwner: "player"
          })]
        })
      })
    }

    function zK(OO) {
      let {
        id: KO,
        isSelected: pO,
        setSelected: lO,
        disabled: hO = !1
      } = OO;
      const [DO, MO] = (0, eO.useState)(!0), [aK, oO] = (0, eO.useState)(""), [FO, LO] = (0, eO.useState)(""), [QO, zK] = (0, eO.useState)(""), AO = (0, eO.useRef)({});
      return (0, eO.useEffect)((() => {
        (0, XO.j)(KO).then((OO => {
          var KO;
          OO && (AO.current = OO, MO(!1), oO(AO.current.metaData.name), LO(AO.current.metaData.author), zK(null !== (KO = AO.current.metaData.previewImage) && void 0 !== KO ? KO : ""))
        })).catch((OO => {
          console.warn(`Failed to fetch texture pack ${KO}`, OO)
        }))
      }), [KO]), (0, VO.jsxs)("div", {
        "data-pad-focusable": !0,
        "aria-disabled": hO || void 0,
        className: vK()("TexturePack", {
          Selected: pO,
          Custom: KO === bK.o.CUSTOM,
          Disabled: hO
        }),
        onClick: () => {
          DO || hO || lO(AO.current)
        },
        children: [(0, VO.jsx)("div", {
          className: "TexturePackBg",
          style: {
            backgroundImage: QO ? `url(${QO})` : void 0
          }
        }), DO && (0, VO.jsx)("div", {
          className: "TexturePackName",
          children: (0, VO.jsx)(CO.e, {})
        }), !DO && aK && (0, VO.jsx)("div", {
          className: "TexturePackName",
          children: aK
        }), !DO && FO && (0, VO.jsx)("div", {
          className: "TexturePackAuthor",
          children: FO
        })]
      })
    }
  },
  4148: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(976);

    function lO(OO) {
      let {
        options: KO,
        value: pO,
        onChange: XO,
        ariaLabel: lO
      } = OO;
      return (0, eO.jsx)("div", {
        className: "SegmentedToggle",
        role: "group",
        "aria-label": lO,
        children: KO.map((OO => {
          const KO = OO.value === pO;
          return (0, eO.jsx)("button", {
            type: "button",
            "aria-pressed": KO,
            className: bK()("SegmentedToggleOption SmallTextLight", {
              SegmentedToggleOptionSelected: KO
            }),
            onClick: () => {
              KO || XO(OO.value)
            },
            children: OO.label
          }, OO.value)
        }))
      })
    }
  },
  4151: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      h: () => lO
    });
    var XO = pO(63);
    const bK = new WeakMap,
      eO = OO => {
        var KO;
        const pO = OO.closest("[data-pad-slider]");
        return pO && null !== (KO = bK.get(pO)) && void 0 !== KO ? KO : null
      },
      lO = (OO, KO) => {
        const pO = (0, XO.useRef)(KO);
        pO.current = KO, (0, XO.useEffect)((() => {
          if (OO.current) return ((OO, KO) => (bK.set(OO, KO), () => {
            bK.get(OO) === KO && bK.delete(OO)
          }))(OO.current, {
            adjust: OO => {
              pO.current.adjust(OO)
            },
            setFraction: OO => {
              pO.current.setFraction(OO)
            },
            endDrag: () => {
              pO.current.endDrag()
            }
          })
        }), [OO])
      }
  },
  4160: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      f: () => lO
    });
    var XO = pO(2460),
      bK = pO(4169);
    let eO = null;

    function lO(OO, KO) {
      eO = {
        pack: OO.metaData.id === XO.c ? null : OO,
        prompt: KO
      }
    }

    function vK(OO, KO) {
      const pO = eO;
      null !== pO && (0, bK.b)(pO.pack, OO) && (eO = null, KO && pO.prompt())
    }
  },
  4169: (OO, KO, pO) => {
    function XO(OO, KO) {
      return bK(OO, KO)
    }

    function bK(OO, KO) {
      if (OO === KO) return !0;
      if ("object" !== typeof OO || "object" !== typeof KO || null === OO || null === KO || Array.isArray(OO) !== Array.isArray(KO)) return !1;
      const pO = OO,
        XO = KO,
        eO = Object.keys(pO);
      return eO.length === Object.keys(XO).length && eO.every((OO => Object.prototype.hasOwnProperty.call(XO, OO) && bK(pO[OO], XO[OO])))
    }
    pO.d(KO, {
      b: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);