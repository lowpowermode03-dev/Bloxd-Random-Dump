export const id = 240;
export const ids = [240];
export const modules = {
  38347: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => aK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(35688),
      vK = pO(38301),
      CO = pO(38206),
      hO = pO(35676),
      DO = pO(38275),
      MO = pO(38077);
    let aK = (() => {
      var OO, KO;
      let pO, aK, oO, FO, VO, LO, QO, zK, AO, fO, dO, TO, NO, IO = vK.c,
        yK = [],
        gK = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [],
        RO = [],
        SO = [],
        JO = [],
        cK = [],
        BO = [],
        ZO = [],
        GO = [],
        qK = [];
      return OO = class extends IO {
        get range() {
          return this._range
        }
        set range(OO) {
          this._range = OO, this._inverseSquaredRange = 1 / (this.range * this.range)
        }
        get intensityMode() {
          return this._intensityMode
        }
        set intensityMode(OO) {
          this._intensityMode = OO, this._computePhotometricScale()
        }
        get radius() {
          return this._radius
        }
        set radius(OO) {
          this._radius = OO, this._computePhotometricScale()
        }
        get renderPriority() {
          return (0, XO.b)(this, KO, "f")
        }
        set renderPriority(OO) {
          (0, XO.e)(this, KO, OO, "f")
        }
        get shadowEnabled() {
          return this._shadowEnabled
        }
        set shadowEnabled(OO) {
          this._shadowEnabled !== OO && (this._shadowEnabled = OO, this._markMeshesAsLightDirty())
        }
        get includedOnlyMeshes() {
          return this._includedOnlyMeshes
        }
        set includedOnlyMeshes(OO) {
          this._includedOnlyMeshes = OO, this._hookArrayForIncludedOnly(OO)
        }
        get excludedMeshes() {
          return this._excludedMeshes
        }
        set excludedMeshes(OO) {
          this._excludedMeshes = OO, this._hookArrayForExcluded(OO)
        }
        get excludeWithLayerMask() {
          return this._excludeWithLayerMask
        }
        set excludeWithLayerMask(OO) {
          this._excludeWithLayerMask = OO, this._resyncMeshes()
        }
        get includeOnlyWithLayerMask() {
          return this._includeOnlyWithLayerMask
        }
        set includeOnlyWithLayerMask(OO) {
          this._includeOnlyWithLayerMask = OO, this._resyncMeshes()
        }
        get lightmapMode() {
          return this._lightmapMode
        }
        set lightmapMode(OO) {
          this._lightmapMode !== OO && (this._lightmapMode = OO, this._markMeshesAsLightDirty())
        }
        getViewMatrix(OO) {
          return null
        }
        getProjectionMatrix(OO, KO) {
          return null
        }
        constructor(pO, bK, eO) {
          super(pO, bK, !1), this.diffuse = ((0, XO.i)(this, yK), (0, XO.i)(this, gK, new lO.e(1, 1, 1))), this.specular = ((0, XO.i)(this, uO), (0, XO.i)(this, EO, new lO.e(1, 1, 1))), this.falloffType = ((0, XO.i)(this, jK), (0, XO.i)(this, YO, OO.FALLOFF_DEFAULT)), this.intensity = ((0, XO.i)(this, wO), (0, XO.i)(this, iK, 1)), this._range = ((0, XO.i)(this, rK), Number.MAX_VALUE), this._inverseSquaredRange = 0, this._photometricScale = 1, this._intensityMode = OO.INTENSITYMODE_AUTOMATIC, this._radius = 1e-5, this._renderPriority = (0, XO.i)(this, PO, void 0), KO.set(this, ((0, XO.i)(this, mK), (0, XO.i)(this, sO, 0))), this._shadowEnabled = ((0, XO.i)(this, HO), (0, XO.i)(this, RO, !0)), this._includedOnlyMeshes = (0, XO.i)(this, SO), this._excludeWithLayerMask = (0, XO.i)(this, JO, 0), this._includeOnlyWithLayerMask = ((0, XO.i)(this, cK), (0, XO.i)(this, BO, 0)), this._lightmapMode = ((0, XO.i)(this, ZO), (0, XO.i)(this, GO, 0)), this._shadowGenerators = ((0, XO.i)(this, qK), null), this._excludedMeshesIds = new Array, this._includedOnlyMeshesIds = new Array, this._currentViewDepth = 0, this._clusteredContainer = null, this._isLight = !0, eO || this.JKO().addLight(this), this._uniformBuffer = new CO.d(this.JKO().qb(), void 0, void 0, pO), this._buildUniformLayout(), this.includedOnlyMeshes = [], this.excludedMeshes = [], eO || this._resyncMeshes()
        }
        transferTexturesToEffect(OO, KO) {
          return this
        }
        _bindLight(OO, KO, pO, XO) {
          let bK = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
          const eO = OO.toString();
          let vK = !1;
          if (this._uniformBuffer.bindToEffect(pO, "Light" + eO), this._renderId !== KO.getRenderId() || this._lastUseSpecular !== XO || !this._uniformBuffer.useUbo) {
            this._renderId = KO.getRenderId(), this._lastUseSpecular = XO;
            const OO = this.getScaledIntensity();
            this.transferToEffect(pO, eO), this.diffuse.scaleToRef(OO, lO.j.Color3[0]), this._uniformBuffer.updateColor4("vLightDiffuse", lO.j.Color3[0], this.range, eO), XO && (this.specular.scaleToRef(OO, lO.j.Color3[1]), this._uniformBuffer.updateColor4("vLightSpecular", lO.j.Color3[1], this.radius, eO)), vK = !0
          }
          if (this.transferTexturesToEffect(pO, eO), KO.shadowsEnabled && this.shadowEnabled && bK) {
            const OO = this.getShadowGenerator(KO.activeCamera) ?? this.getShadowGenerator();
            OO && (OO.bindShadowLight(eO, pO), vK = !0)
          }
          vK ? this._uniformBuffer.update() : this._uniformBuffer.bindUniformBuffer()
        }
        getClassName() {
          return "Light"
        }
        toString(OO) {
          let KO = "Name: " + this.name;
          if (KO += ", type: " + ["Point", "Directional", "Spot", "Hemispheric", "Clustered"][this.getTypeID()], this.animations)
            for (let pO = 0; pO < this.animations.length; pO++) KO += ", animation[0]: " + this.animations[pO].toString(OO);
          return KO
        }
        _syncParentEnabledState() {
          super._syncParentEnabledState(), this.FhO() || this._resyncMeshes()
        }
        WE(OO) {
          super.WE(OO), this._resyncMeshes()
        }
        getShadowGenerator() {
          let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          return null === this._shadowGenerators ? null : this._shadowGenerators.get(OO) ?? null
        }
        getShadowGenerators() {
          return this._shadowGenerators
        }
        getAbsolutePosition() {
          return eO.o.Zero()
        }
        canAffectMesh(OO) {
          return !OO || !(this.includedOnlyMeshes && this.includedOnlyMeshes.length > 0 && -1 === this.includedOnlyMeshes.indexOf(OO)) && (!(this.excludedMeshes && this.excludedMeshes.length > 0 && -1 !== this.excludedMeshes.indexOf(OO)) && ((0 === this.includeOnlyWithLayerMask || 0 !== (this.includeOnlyWithLayerMask & OO.layerMask)) && !(0 !== this.excludeWithLayerMask && this.excludeWithLayerMask & OO.layerMask)))
        }
        dispose(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (this._shadowGenerators) {
            const OO = this._shadowGenerators.values();
            for (let KO = OO.next(); !0 !== KO.done; KO = OO.next()) {
              KO.value.dispose()
            }
            this._shadowGenerators = null
          }
          if (this.JKO().stopAnimation(this), this._parentContainer) {
            const OO = this._parentContainer.lights.indexOf(this);
            OO > -1 && this._parentContainer.lights.splice(OO, 1), this._parentContainer = null
          }
          for (const pO of this.JKO().meshes) pO._removeLightSource(this, !0);
          this._uniformBuffer.dispose(), this.JKO().removeLight(this), super.dispose(OO, KO)
        }
        getTypeID() {
          return 0
        }
        getScaledIntensity() {
          return this._photometricScale * this.intensity
        }
        clone(KO) {
          let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          const XO = OO.GetConstructorFromName(this.getTypeID(), KO, this.JKO());
          if (!XO) return null;
          const bK = MO.c.Clone(XO, this);
          return KO && (bK.name = KO), pO && (bK.parent = pO), bK.WE(this.isEnabled()), this.onClonedObservable.notifyObservers(bK), bK
        }
        serialize() {
          const OO = MO.c.Serialize(this);
          if (OO.uniqueId = this.uniqueId, OO.type = this.getTypeID(), this.parent && this.parent._serializeAsParent(OO), this.excludedMeshes.length > 0) {
            OO.excludedMeshesIds = [];
            for (const KO of this.excludedMeshes) OO.excludedMeshesIds.push(KO.id)
          }
          if (this.includedOnlyMeshes.length > 0) {
            OO.includedOnlyMeshesIds = [];
            for (const KO of this.includedOnlyMeshes) OO.includedOnlyMeshesIds.push(KO.id)
          }
          return MO.c.AppendSerializedAnimations(this, OO), OO.Xl = this.serializeAnimationRanges(), OO.isEnabled = this.isEnabled(), OO
        }
        static GetConstructorFromName(OO, KO, pO) {
          const XO = vK.c.Construct("Light_Type_" + OO, KO, pO);
          return XO || null
        }
        static Parse(KO, pO) {
          let XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
          const bK = OO.GetConstructorFromName(KO.type, KO.name, pO);
          if (!bK) return null;
          const eO = MO.c.Parse(bK, KO, pO, XO);
          if (KO.excludedMeshesIds && (eO._excludedMeshesIds = KO.excludedMeshesIds), KO.includedOnlyMeshesIds && (eO._includedOnlyMeshesIds = KO.includedOnlyMeshesIds), void 0 !== KO.parentId && (eO._waitingParentId = KO.parentId), void 0 !== KO.parentInstanceIndex && (eO._waitingParentInstanceIndex = KO.parentInstanceIndex), void 0 !== KO.falloffType && (eO.falloffType = KO.falloffType), void 0 !== KO.lightmapMode && (eO.lightmapMode = KO.lightmapMode), KO.animations) {
            for (let OO = 0; OO < KO.animations.length; OO++) {
              const pO = KO.animations[OO],
                XO = (0, hO.e)("BABYLON.Animation");
              XO && eO.animations.push(XO.Parse(pO))
            }
            vK.c.ParseAnimationRanges(eO, KO, pO)
          }
          return KO.autoAnimate && pO.beginAnimation(eO, KO.autoAnimateFrom, KO.autoAnimateTo, KO.autoAnimateLoop, KO.autoAnimateSpeed || 1), void 0 !== KO.isEnabled && eO.WE(KO.isEnabled), eO._onParsed(KO, pO, XO), eO
        }
        _onParsed(OO, KO) {}
        _hookArrayForExcluded(OO) {
          var KO = this;
          const pO = OO.push;
          OO.push = function() {
            for (var XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
            const lO = pO.apply(OO, bK);
            if (KO._clusteredContainer) return lO;
            for (const OO of bK) OO._resyncLightSource(KO);
            return lO
          };
          const XO = OO.splice;
          OO.splice = (KO, pO) => {
            const bK = XO.call(OO, KO, pO ?? OO.length);
            if (this._clusteredContainer) return bK;
            for (const OO of bK) OO._resyncLightSource(this);
            return bK
          }, this._resyncMeshes()
        }
        _hookArrayForIncludedOnly(OO) {
          var KO = this;
          const pO = OO.push;
          OO.push = function() {
            for (var XO = arguments.length, bK = new Array(XO), eO = 0; eO < XO; eO++) bK[eO] = arguments[eO];
            const lO = pO.apply(OO, bK);
            return KO._resyncMeshes(), lO
          };
          const XO = OO.splice;
          OO.splice = (KO, pO) => {
            const bK = XO.call(OO, KO, pO ?? OO.length);
            return this._resyncMeshes(), bK
          }, this._resyncMeshes()
        }
        _resyncMeshes() {
          if (!this._clusteredContainer)
            for (const OO of this.JKO().meshes) OO._resyncLightSource(this)
        }
        _markMeshesAsLightDirty() {
          for (const OO of this.JKO().meshes) - 1 !== OO.lightSources.indexOf(this) && OO._markSubMeshesAsLightDirty()
        }
        _computePhotometricScale() {
          this._photometricScale = this._getPhotometricScale(), this.JKO().resetCachedMaterial()
        }
        _getPhotometricScale() {
          let KO = 0;
          const pO = this.getTypeID();
          let XO = this.intensityMode;
          switch (XO === OO.INTENSITYMODE_AUTOMATIC && (XO = pO === OO.LIGHTTYPEID_DIRECTIONALLIGHT ? OO.INTENSITYMODE_ILLUMINANCE : OO.INTENSITYMODE_LUMINOUSINTENSITY), pO) {
            case OO.LIGHTTYPEID_POINTLIGHT:
            case OO.LIGHTTYPEID_SPOTLIGHT:
              switch (XO) {
                case OO.INTENSITYMODE_LUMINOUSPOWER:
                  KO = 1 / (4 * Math.PI);
                  break;
                case OO.INTENSITYMODE_LUMINOUSINTENSITY:
                  KO = 1;
                  break;
                case OO.INTENSITYMODE_LUMINANCE:
                  KO = this.radius * this.radius
              }
              break;
            case OO.LIGHTTYPEID_DIRECTIONALLIGHT:
              switch (XO) {
                case OO.INTENSITYMODE_ILLUMINANCE:
                  KO = 1;
                  break;
                case OO.INTENSITYMODE_LUMINANCE: {
                  let OO = this.radius;
                  OO = Math.max(OO, .001);
                  KO = 2 * Math.PI * (1 - Math.cos(OO));
                  break
                }
              }
              break;
            case OO.LIGHTTYPEID_HEMISPHERICLIGHT:
            case OO.LIGHTTYPEID_RECT_AREALIGHT:
              KO = 1
          }
          return KO
        }
        _reorderLightsInScene() {
          const OO = this.JKO();
          0 != this._renderPriority && (OO.requireLightSorting = !0), this.JKO().sortLightsByPriority()
        }
        areLightTexturesReady() {
          return !0
        }
        _isReady() {
          return !0
        }
      }, KO = new WeakMap, (() => {
        const KO = "function" === typeof Symbol && Symbol.metadata ? Object.create(IO[Symbol.metadata] ?? null) : void 0;
        pO = [(0, bK.r)()], aK = [(0, bK.r)()], oO = [(0, bK.M)()], FO = [(0, bK.M)()], VO = [(0, bK.M)()], LO = [(0, bK.M)()], QO = [(0, bK.M)()], zK = [(0, bK.M)()], AO = [(0, bK.h)("_reorderLightsInScene")], fO = [(0, bK.M)("shadowEnabled")], dO = [(0, bK.M)("excludeWithLayerMask")], TO = [(0, bK.M)("includeOnlyWithLayerMask")], NO = [(0, bK.M)("lightmapMode")], (0, XO.f)(OO, null, VO, {
          kind: "getter",
          name: "range",
          static: !1,
          private: !1,
          access: {
            has: OO => "range" in OO,
            get: OO => OO.range
          },
          metadata: KO
        }, null, yK), (0, XO.f)(OO, null, LO, {
          kind: "getter",
          name: "intensityMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "intensityMode" in OO,
            get: OO => OO.intensityMode
          },
          metadata: KO
        }, null, yK), (0, XO.f)(OO, null, QO, {
          kind: "getter",
          name: "radius",
          static: !1,
          private: !1,
          access: {
            has: OO => "radius" in OO,
            get: OO => OO.radius
          },
          metadata: KO
        }, null, yK), (0, XO.f)(OO, null, AO, {
          kind: "accessor",
          name: "renderPriority",
          static: !1,
          private: !1,
          access: {
            has: OO => "renderPriority" in OO,
            get: OO => OO.renderPriority,
            set: (OO, KO) => {
              OO.renderPriority = KO
            }
          },
          metadata: KO
        }, sO, HO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "diffuse",
          static: !1,
          private: !1,
          access: {
            has: OO => "diffuse" in OO,
            get: OO => OO.diffuse,
            set: (OO, KO) => {
              OO.diffuse = KO
            }
          },
          metadata: KO
        }, gK, uO), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "specular",
          static: !1,
          private: !1,
          access: {
            has: OO => "specular" in OO,
            get: OO => OO.specular,
            set: (OO, KO) => {
              OO.specular = KO
            }
          },
          metadata: KO
        }, EO, jK), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "falloffType",
          static: !1,
          private: !1,
          access: {
            has: OO => "falloffType" in OO,
            get: OO => OO.falloffType,
            set: (OO, KO) => {
              OO.falloffType = KO
            }
          },
          metadata: KO
        }, YO, wO), (0, XO.f)(null, null, FO, {
          kind: "field",
          name: "intensity",
          static: !1,
          private: !1,
          access: {
            has: OO => "intensity" in OO,
            get: OO => OO.intensity,
            set: (OO, KO) => {
              OO.intensity = KO
            }
          },
          metadata: KO
        }, iK, rK), (0, XO.f)(null, null, zK, {
          kind: "field",
          name: "_renderPriority",
          static: !1,
          private: !1,
          access: {
            has: OO => "_renderPriority" in OO,
            get: OO => OO._renderPriority,
            set: (OO, KO) => {
              OO._renderPriority = KO
            }
          },
          metadata: KO
        }, PO, mK), (0, XO.f)(null, null, fO, {
          kind: "field",
          name: "_shadowEnabled",
          static: !1,
          private: !1,
          access: {
            has: OO => "_shadowEnabled" in OO,
            get: OO => OO._shadowEnabled,
            set: (OO, KO) => {
              OO._shadowEnabled = KO
            }
          },
          metadata: KO
        }, RO, SO), (0, XO.f)(null, null, dO, {
          kind: "field",
          name: "_excludeWithLayerMask",
          static: !1,
          private: !1,
          access: {
            has: OO => "_excludeWithLayerMask" in OO,
            get: OO => OO._excludeWithLayerMask,
            set: (OO, KO) => {
              OO._excludeWithLayerMask = KO
            }
          },
          metadata: KO
        }, JO, cK), (0, XO.f)(null, null, TO, {
          kind: "field",
          name: "_includeOnlyWithLayerMask",
          static: !1,
          private: !1,
          access: {
            has: OO => "_includeOnlyWithLayerMask" in OO,
            get: OO => OO._includeOnlyWithLayerMask,
            set: (OO, KO) => {
              OO._includeOnlyWithLayerMask = KO
            }
          },
          metadata: KO
        }, BO, ZO), (0, XO.f)(null, null, NO, {
          kind: "field",
          name: "_lightmapMode",
          static: !1,
          private: !1,
          access: {
            has: OO => "_lightmapMode" in OO,
            get: OO => OO._lightmapMode,
            set: (OO, KO) => {
              OO._lightmapMode = KO
            }
          },
          metadata: KO
        }, GO, qK), KO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: KO
        })
      })(), OO.FALLOFF_DEFAULT = DO.e.FALLOFF_DEFAULT, OO.FALLOFF_PHYSICAL = DO.e.FALLOFF_PHYSICAL, OO.FALLOFF_GLTF = DO.e.FALLOFF_GLTF, OO.FALLOFF_STANDARD = DO.e.FALLOFF_STANDARD, OO.LIGHTMAP_DEFAULT = DO.e.LIGHTMAP_DEFAULT, OO.LIGHTMAP_SPECULAR = DO.e.LIGHTMAP_SPECULAR, OO.LIGHTMAP_SHADOWSONLY = DO.e.LIGHTMAP_SHADOWSONLY, OO.INTENSITYMODE_AUTOMATIC = DO.e.INTENSITYMODE_AUTOMATIC, OO.INTENSITYMODE_LUMINOUSPOWER = DO.e.INTENSITYMODE_LUMINOUSPOWER, OO.INTENSITYMODE_LUMINOUSINTENSITY = DO.e.INTENSITYMODE_LUMINOUSINTENSITY, OO.INTENSITYMODE_ILLUMINANCE = DO.e.INTENSITYMODE_ILLUMINANCE, OO.INTENSITYMODE_LUMINANCE = DO.e.INTENSITYMODE_LUMINANCE, OO.LIGHTTYPEID_POINTLIGHT = DO.e.LIGHTTYPEID_POINTLIGHT, OO.LIGHTTYPEID_DIRECTIONALLIGHT = DO.e.LIGHTTYPEID_DIRECTIONALLIGHT, OO.LIGHTTYPEID_SPOTLIGHT = DO.e.LIGHTTYPEID_SPOTLIGHT, OO.LIGHTTYPEID_HEMISPHERICLIGHT = DO.e.LIGHTTYPEID_HEMISPHERICLIGHT, OO.LIGHTTYPEID_RECT_AREALIGHT = DO.e.LIGHTTYPEID_RECT_AREALIGHT, OO
    })()
  },
  38301: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => MO
    });
    var XO = pO(38063),
      bK = pO(35632),
      eO = pO(38066),
      lO = pO(35660),
      vK = pO(35653),
      CO = pO(37938),
      hO = pO(38077);
    class DO {
      constructor() {
        this._doNotSerialize = !1, this._isDisposed = !1, this._sceneRootNodesIndex = -1, this._isEnabled = !0, this._isParentEnabled = !0, this._isReady = !0, this._onEnabledStateChangedObservable = new lO.e, this._onEffectiveEnabledStateChangedObservable = null, this._onClonedObservable = new lO.e, this._inheritVisibility = !1, this._isVisible = !0
      }
    }
    let MO = (() => {
      var OO;
      let KO, pO, MO, aK, oO, FO = [],
        VO = [],
        LO = [],
        QO = [],
        zK = [],
        AO = [],
        fO = [],
        dO = [],
        TO = [],
        NO = [];
      return OO = class {
        static AddNodeConstructor(OO, KO) {
          this._NodeConstructors[OO] = KO
        }
        static Construct(OO, KO, pO, XO) {
          const bK = this._NodeConstructors[OO];
          return bK ? bK(KO, pO, XO) : null
        }
        set accessibilityTag(OO) {
          this._accessibilityTag = OO, this.onAccessibilityTagChangedObservable.notifyObservers(OO)
        }
        get accessibilityTag() {
          return this._accessibilityTag
        }
        get doNotSerialize() {
          return !!this._nodeDataStorage._doNotSerialize || !!this._parentNode && this._parentNode.doNotSerialize
        }
        set doNotSerialize(OO) {
          this._nodeDataStorage._doNotSerialize = OO
        }
        FhO() {
          return this._nodeDataStorage._isDisposed
        }
        set parent(OO) {
          if (this._parentNode === OO) return;
          const KO = this._parentNode;
          if (this._parentNode && void 0 !== this._parentNode._children && null !== this._parentNode._children) {
            const KO = this._parentNode._children.indexOf(this); - 1 !== KO && this._parentNode._children.splice(KO, 1), OO || this._nodeDataStorage._isDisposed || this._addToSceneRootNodes()
          }
          this._parentNode = OO, this._isDirty = !0, this._parentNode && (void 0 !== this._parentNode._children && null !== this._parentNode._children || (this._parentNode._children = new Array), this._parentNode._children.push(this), KO || this._removeFromSceneRootNodes()), this._syncParentEnabledState()
        }
        get parent() {
          return this._parentNode
        }
        get inheritVisibility() {
          return this._nodeDataStorage._inheritVisibility
        }
        set inheritVisibility(OO) {
          this._nodeDataStorage._inheritVisibility = OO
        }
        get isVisible() {
          return !(this.inheritVisibility && this._parentNode && !this._parentNode.isVisible) && this._nodeDataStorage._isVisible
        }
        set isVisible(OO) {
          this._nodeDataStorage._isVisible = OO
        }
        _serializeAsParent(OO) {
          OO.parentId = this.uniqueId
        }
        _addToSceneRootNodes() {
          -1 === this._nodeDataStorage._sceneRootNodesIndex && (this._nodeDataStorage._sceneRootNodesIndex = this._scene.rootNodes.length, this._scene.rootNodes.push(this))
        }
        _removeFromSceneRootNodes() {
          if (-1 !== this._nodeDataStorage._sceneRootNodesIndex) {
            const OO = this._scene.rootNodes,
              KO = OO.length - 1;
            OO[this._nodeDataStorage._sceneRootNodesIndex] = OO[KO], OO[this._nodeDataStorage._sceneRootNodesIndex]._nodeDataStorage._sceneRootNodesIndex = this._nodeDataStorage._sceneRootNodesIndex, this._scene.rootNodes.pop(), this._nodeDataStorage._sceneRootNodesIndex = -1
          }
        }
        get animationPropertiesOverride() {
          return this._animationPropertiesOverride ? this._animationPropertiesOverride : this._scene.animationPropertiesOverride
        }
        set animationPropertiesOverride(OO) {
          this._animationPropertiesOverride = OO
        }
        getClassName() {
          return "Node"
        }
        set onDispose(OO) {
          this._onDisposeObserver && this.cpO.remove(this._onDisposeObserver), this._onDisposeObserver = this.cpO.add(OO)
        }
        get onEnabledStateChangedObservable() {
          return this._nodeDataStorage._onEnabledStateChangedObservable
        }
        get onEffectiveEnabledStateChangedObservable() {
          var OO;
          return (OO = this._nodeDataStorage)._onEffectiveEnabledStateChangedObservable ?? (OO._onEffectiveEnabledStateChangedObservable = new lO.e)
        }
        get onClonedObservable() {
          return this._nodeDataStorage._onClonedObservable
        }
        constructor(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
            pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
          this._isDirty = !1, this._nodeDataStorage = new DO, this.name = (0, XO.i)(this, FO, void 0), this.id = ((0, XO.i)(this, VO), (0, XO.i)(this, LO, void 0)), this.uniqueId = ((0, XO.i)(this, QO), (0, XO.i)(this, zK, void 0)), this.state = ((0, XO.i)(this, AO), (0, XO.i)(this, fO, "")), this.metadata = ((0, XO.i)(this, dO), (0, XO.i)(this, TO, null)), this._internalMetadata = (0, XO.i)(this, NO), this.reservedDataStore = null, this._accessibilityTag = null, this.onAccessibilityTagChangedObservable = new lO.e, this._parentContainer = null, this.animations = [], this._ranges = {}, this.onReady = null, this._currentRenderId = -1, this._parentUpdateId = -1, this._childUpdateId = -1, this._waitingParentId = null, this._waitingParentInstanceIndex = null, this._waitingParsedUniqueId = null, this._cache = {}, this._parentNode = null, this._children = null, this._worldMatrix = bK.c.Identity(), this._worldMatrixDeterminant = 0, this._worldMatrixDeterminantIsDirty = !0, this._animationPropertiesOverride = null, this._isNode = !0, this.cpO = new lO.e, this._onDisposeObserver = null, this._behaviors = new Array, this.name = OO, this.id = OO, this._scene = KO || vK.c.LastCreatedScene, this.uniqueId = this._scene.getUniqueId(), this._initCache(), pO && this._addToSceneRootNodes()
        }
        JKO() {
          return this._scene
        }
        qb() {
          return this._scene.qb()
        }
        addBehavior(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          return -1 !== this._behaviors.indexOf(OO) || (OO.init(), this._scene.isLoading && !KO ? this._scene.onDataLoadedObservable.addOnce((() => {
            this._behaviors.includes(OO) && OO.attach(this)
          })) : OO.attach(this), this._behaviors.push(OO)), this
        }
        removeBehavior(OO) {
          const KO = this._behaviors.indexOf(OO);
          return -1 === KO || (this._behaviors.splice(KO, 1), OO.detach()), this
        }
        get behaviors() {
          return this._behaviors
        }
        getBehaviorByName(OO) {
          for (const KO of this._behaviors)
            if (KO.name === OO) return KO;
          return null
        }
        getWorldMatrix() {
          return this._currentRenderId !== this._scene.getRenderId() && this.computeWorldMatrix(), this._worldMatrix
        }
        _getWorldMatrixDeterminant() {
          return this._worldMatrixDeterminantIsDirty && (this._worldMatrixDeterminantIsDirty = !1, this._worldMatrixDeterminant = this._worldMatrix.determinant()), this._worldMatrixDeterminant
        }
        get worldMatrixFromCache() {
          return this._worldMatrix
        }
        _initCache() {
          this._cache = {}
        }
        updateCache(OO) {
          !OO && this.isSynchronized() || this._updateCache()
        }
        _getActionManagerForTrigger(OO) {
          return this.parent ? this.parent._getActionManagerForTrigger(OO, !1) : null
        }
        _updateCache(OO) {}
        _isSynchronized() {
          return !0
        }
        _markSyncedWithParent() {
          this._parentNode && (this._parentUpdateId = this._parentNode._childUpdateId)
        }
        isSynchronizedWithParent() {
          return !this._parentNode || !this._parentNode._isDirty && this._parentUpdateId === this._parentNode._childUpdateId && this._parentNode.isSynchronized()
        }
        isSynchronized() {
          return !(this._parentNode && !this.isSynchronizedWithParent()) && this._isSynchronized()
        }
        isReady() {
          return this._nodeDataStorage._isReady
        }
        jhO(OO) {
          return this._currentRenderId = Number.MAX_VALUE, this._isDirty = !0, this
        }
        isEnabled() {
          return !1 === (!(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0]) ? this._nodeDataStorage._isEnabled : !!this._nodeDataStorage._isEnabled && this._nodeDataStorage._isParentEnabled
        }
        _hasEffectiveEnabledStateObservers() {
          const OO = this._nodeDataStorage._onEffectiveEnabledStateChangedObservable;
          return !!OO && OO.hasObservers()
        }
        _syncParentEnabledState() {
          const OO = this._hasEffectiveEnabledStateObservers(),
            KO = OO ? this.isEnabled() : null;
          if (this._nodeDataStorage._isParentEnabled = !this._parentNode || this._parentNode.isEnabled(), this._children)
            for (const pO of this._children) pO._syncParentEnabledState();
          if (OO) {
            const OO = this.isEnabled();
            OO !== KO && this._nodeDataStorage._onEffectiveEnabledStateChangedObservable.notifyObservers(OO)
          }
        }
        WE(OO) {
          if (this._nodeDataStorage._isEnabled === OO) return;
          const KO = this._hasEffectiveEnabledStateObservers(),
            pO = KO ? this.isEnabled() : null;
          if (this._nodeDataStorage._isEnabled = OO, this._syncParentEnabledState(), this._nodeDataStorage._onEnabledStateChangedObservable.notifyObservers(OO), KO) {
            const OO = this.isEnabled();
            OO !== pO && this._nodeDataStorage._onEffectiveEnabledStateChangedObservable.notifyObservers(OO)
          }
        }
        isDescendantOf(OO) {
          return !!this.parent && (this.parent === OO || this.parent.isDescendantOf(OO))
        }
        _getDescendants(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            pO = arguments.length > 2 ? arguments[2] : void 0;
          if (this._children)
            for (let XO = 0; XO < this._children.length; XO++) {
              const bK = this._children[XO];
              pO && !pO(bK) || OO.push(bK), KO || bK._getDescendants(OO, !1, pO)
            }
        }
        getDescendants(OO, KO) {
          const pO = [];
          return this._getDescendants(pO, OO, KO), pO
        }
        getChildMeshes(OO, KO) {
          const pO = [];
          return this._getDescendants(pO, OO, (OO => (!KO || KO(OO)) && void 0 !== OO.cullingStrategy)), pO
        }
        getChildren(OO) {
          let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          return this.getDescendants(KO, OO)
        }
        _setReady(OO) {
          OO !== this._nodeDataStorage._isReady && (OO ? (this.onReady && this.onReady(this), this._nodeDataStorage._isReady = !0) : this._nodeDataStorage._isReady = !1)
        }
        getAnimationByName(OO) {
          for (let KO = 0; KO < this.animations.length; KO++) {
            const pO = this.animations[KO];
            if (pO.name === OO) return pO
          }
          return null
        }
        createAnimationRange(KO, pO, XO) {
          if (!this._ranges[KO]) {
            this._ranges[KO] = OO._AnimationRangeFactory(KO, pO, XO);
            for (let OO = 0, bK = this.animations.length; OO < bK; OO++) this.animations[OO] && this.animations[OO].createRange(KO, pO, XO)
          }
        }
        deleteAnimationRange(OO) {
          let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          for (let pO = 0, XO = this.animations.length; pO < XO; pO++) this.animations[pO] && this.animations[pO].deleteRange(OO, KO);
          this._ranges[OO] = null
        }
        getAnimationRange(OO) {
          return this._ranges[OO] || null
        }
        clone(KO, pO, XO) {
          const bK = hO.c.Clone((() => new OO(KO, this.JKO())), this);
          if (pO && (bK.parent = pO), !XO) {
            const OO = this.getDescendants(!0);
            for (let pO = 0; pO < OO.length; pO++) {
              const XO = OO[pO];
              XO.clone(KO + "." + XO.name, bK)
            }
          }
          return bK
        }
        getAnimationRanges() {
          const OO = [];
          let KO;
          for (KO in this._ranges) OO.push(this._ranges[KO]);
          return OO
        }
        beginAnimation(OO, KO, pO, XO) {
          const bK = this.getAnimationRange(OO);
          return bK ? this._scene.beginAnimation(this, bK.from, bK.to, KO, pO, XO) : null
        }
        serializeAnimationRanges() {
          const OO = [];
          for (const KO in this._ranges) {
            const pO = this._ranges[KO];
            if (!pO) continue;
            const XO = {};
            XO.name = KO, XO.from = pO.from, XO.to = pO.to, OO.push(XO)
          }
          return OO
        }
        computeWorldMatrix(OO) {
          return this._worldMatrix || (this._worldMatrix = bK.c.Identity()), this._worldMatrix
        }
        dispose(OO) {
          let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (this._nodeDataStorage._isDisposed = !0, !OO) {
            const pO = this.getDescendants(!0);
            for (const XO of pO) XO.dispose(OO, KO)
          }
          this.parent ? this.parent = null : this._removeFromSceneRootNodes(), this.cpO.notifyObservers(this), this.cpO.clear(), this.onEnabledStateChangedObservable.clear(), this._nodeDataStorage._onEffectiveEnabledStateChangedObservable?.clear(), this.onClonedObservable.clear();
          for (const pO of this._behaviors) pO.detach();
          this._behaviors.length = 0, this.metadata = null
        }
        static ParseAnimationRanges(OO, KO, pO) {
          if (KO.Xl)
            for (let XO = 0; XO < KO.Xl.length; XO++) {
              const pO = KO.Xl[XO];
              OO.createAnimationRange(pO.name, pO.from, pO.to)
            }
        }
        getHierarchyBoundingVectors() {
          let OO, KO, pO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            XO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          this.JKO().incrementRenderId(), this.computeWorldMatrix(!0);
          const eO = this;
          if (eO.hpO && eO.au) {
            const pO = eO.hpO();
            OO = pO.boundingBox.minimumWorld.clone(), KO = pO.boundingBox.maximumWorld.clone()
          } else OO = new bK.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), KO = new bK.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
          if (pO) {
            const pO = this.getDescendants(!1);
            for (const eO of pO) {
              const pO = eO;
              if (pO.computeWorldMatrix(!0), XO && !XO(pO)) continue;
              if (!pO.hpO || 0 === pO.getTotalVertices()) continue;
              const lO = pO.hpO().boundingBox,
                vK = lO.minimumWorld,
                CO = lO.maximumWorld;
              bK.o.CheckExtends(vK, OO, KO), bK.o.CheckExtends(CO, OO, KO)
            }
          }
          return {
            min: OO,
            max: KO
          }
        }
      }, (() => {
        const bK = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, eO.M)()], pO = [(0, eO.M)()], MO = [(0, eO.M)()], aK = [(0, eO.M)()], oO = [(0, eO.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "name",
          static: !1,
          private: !1,
          access: {
            has: OO => "name" in OO,
            get: OO => OO.name,
            set: (OO, KO) => {
              OO.name = KO
            }
          },
          metadata: bK
        }, FO, VO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "id",
          static: !1,
          private: !1,
          access: {
            has: OO => "id" in OO,
            get: OO => OO.id,
            set: (OO, KO) => {
              OO.id = KO
            }
          },
          metadata: bK
        }, LO, QO), (0, XO.f)(null, null, MO, {
          kind: "field",
          name: "uniqueId",
          static: !1,
          private: !1,
          access: {
            has: OO => "uniqueId" in OO,
            get: OO => OO.uniqueId,
            set: (OO, KO) => {
              OO.uniqueId = KO
            }
          },
          metadata: bK
        }, zK, AO), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "state",
          static: !1,
          private: !1,
          access: {
            has: OO => "state" in OO,
            get: OO => OO.state,
            set: (OO, KO) => {
              OO.state = KO
            }
          },
          metadata: bK
        }, fO, dO), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "metadata",
          static: !1,
          private: !1,
          access: {
            has: OO => "metadata" in OO,
            get: OO => OO.metadata,
            set: (OO, KO) => {
              OO.metadata = KO
            }
          },
          metadata: bK
        }, TO, NO), bK && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: bK
        })
      })(), OO._AnimationRangeFactory = (OO, KO, pO) => {
        throw (0, CO.j)("AnimationRange")
      }, OO._NodeConstructors = {}, OO
    })()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);