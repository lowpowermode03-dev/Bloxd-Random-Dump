export const id = 46;
export const ids = [46];
export const modules = {
  41370: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      startPageTexturePackFeed: () => lO
    });
    var XO = pO(1056),
      bK = pO(36),
      eO = pO(41355);

    function lO(OO, KO) {
      const pO = new eO.b({
        store: bK.d,
        warn: OO,
        oneShot: KO,
        fetchLatest: async OO => {
          const KO = await fetch(`${XO.clientSideServerUrls.texturePackUrl}/${OO}.json`, {
            cache: "reload"
          });
          if (!KO.ok) throw new Error(`fetching texture pack ${OO} answered HTTP ${KO.status}`);
          return await KO.json()
        }
      });
      return (0, eO.f)(pO), pO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);