export const id = 245;
export const ids = [245];
export const modules = {
  38572: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => NO,
      c: () => dO,
      d: () => AO,
      h: () => fO,
      k: () => zK,
      m: () => QO
    });
    var XO = pO(38077),
      bK = pO(38170),
      eO = pO(35632),
      lO = pO(38216),
      vK = pO(38580),
      CO = pO(38449),
      hO = pO(38112),
      DO = pO(38447),
      MO = pO(35653),
      aK = pO(38431),
      oO = pO(38424),
      FO = pO(38460),
      VO = pO(35676);
    const LO = {
      effect: null,
      subMesh: null
    };
    class QO extends DO.d {
      constructor(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        super(OO, KO, !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4]), this._textures = {}, this._internalTextures = {}, this._textureArrays = {}, this._externalTextures = {}, this._floats = {}, this._ints = {}, this._uints = {}, this._floatsArrays = {}, this._colors3 = {}, this._colors3Arrays = {}, this._colors4 = {}, this._colors4Arrays = {}, this._vectors2 = {}, this._vectors3 = {}, this._vectors4 = {}, this._quaternions = {}, this._quaternionsArrays = {}, this._matrices = {}, this._matrixArrays = {}, this._matrices3x3 = {}, this._matrices2x2 = {}, this._vectors2Arrays = {}, this._vectors3Arrays = {}, this._vectors4Arrays = {}, this._uniformBuffers = {}, this._textureSamplers = {}, this._storageBuffers = {}, this._cachedWorldViewMatrix = new eO.c, this._cachedWorldViewProjectionMatrix = new eO.c, this._multiview = !1, this._vertexPullingMetadata = null, this._materialHelperNeedsPreviousMatrices = !1, this._shaderPath = pO, this._options = {
          needAlphaBlending: !1,
          needAlphaTesting: !1,
          attributes: ["position", "normal", "uv"],
          uniforms: ["worldViewProjection"],
          uniformBuffers: [],
          samplers: [],
          externalTextures: [],
          samplerObjects: [],
          storageBuffers: [],
          defines: [],
          useClipPlane: !1,
          ...XO
        }
      }
      get shaderPath() {
        return this._shaderPath
      }
      set shaderPath(OO) {
        this._shaderPath = OO
      }
      get options() {
        return this._options
      }
      get isMultiview() {
        return this._multiview
      }
      getClassName() {
        return "ShaderMaterial"
      }
      needAlphaBlending() {
        return this.alpha < 1 || this._options.needAlphaBlending
      }
      needAlphaTesting() {
        return this._options.needAlphaTesting
      }
      _checkUniform(OO) {
        -1 === this._options.uniforms.indexOf(OO) && this._options.uniforms.push(OO)
      }
      setTexture(OO, KO) {
        return -1 === this._options.samplers.indexOf(OO) && this._options.samplers.push(OO), this._textures[OO] = KO, this
      }
      setInternalTexture(OO, KO) {
        return -1 === this._options.samplers.indexOf(OO) && this._options.samplers.push(OO), this._internalTextures[OO] = KO, this
      }
      removeTexture(OO) {
        delete this._textures[OO]
      }
      setTextureArray(OO, KO) {
        return -1 === this._options.samplers.indexOf(OO) && this._options.samplers.push(OO), this._checkUniform(OO), this._textureArrays[OO] = KO, this
      }
      setExternalTexture(OO, KO) {
        return -1 === this._options.externalTextures.indexOf(OO) && this._options.externalTextures.push(OO), this._externalTextures[OO] = KO, this
      }
      setFloat(OO, KO) {
        return this._checkUniform(OO), this._floats[OO] = KO, this
      }
      setInt(OO, KO) {
        return this._checkUniform(OO), this._ints[OO] = KO, this
      }
      setUInt(OO, KO) {
        return this._checkUniform(OO), this._uints[OO] = KO, this
      }
      setFloats(OO, KO) {
        return this._checkUniform(OO), this._floatsArrays[OO] = KO, this
      }
      setColor3(OO, KO) {
        return this._checkUniform(OO), this._colors3[OO] = KO, this
      }
      setColor3Array(OO, KO) {
        return this._checkUniform(OO), this._colors3Arrays[OO] = KO.reduce(((OO, KO) => (OO.push(KO.r, KO.g, KO.b), OO)), []), this
      }
      setColor4(OO, KO) {
        return this._checkUniform(OO), this._colors4[OO] = KO, this
      }
      setColor4Array(OO, KO) {
        return this._checkUniform(OO), this._colors4Arrays[OO] = KO.reduce(((OO, KO) => (OO.push(KO.r, KO.g, KO.b, KO.a), OO)), []), this
      }
      setVector2(OO, KO) {
        return this._checkUniform(OO), this._vectors2[OO] = KO, this
      }
      setVector3(OO, KO) {
        return this._checkUniform(OO), this._vectors3[OO] = KO, this
      }
      setVector4(OO, KO) {
        return this._checkUniform(OO), this._vectors4[OO] = KO, this
      }
      setQuaternion(OO, KO) {
        return this._checkUniform(OO), this._quaternions[OO] = KO, this
      }
      setQuaternionArray(OO, KO) {
        return this._checkUniform(OO), this._quaternionsArrays[OO] = KO.reduce(((OO, KO) => (KO.toArray(OO, OO.length), OO)), []), this
      }
      setMatrix(OO, KO) {
        return this._checkUniform(OO), this._matrices[OO] = KO, this
      }
      setMatrices(OO, KO) {
        this._checkUniform(OO);
        const pO = new Float32Array(16 * KO.length);
        for (let XO = 0; XO < KO.length; XO++) {
          KO[XO].copyToArray(pO, 16 * XO)
        }
        return this._matrixArrays[OO] = pO, this
      }
      setMatrix3x3(OO, KO) {
        return this._checkUniform(OO), this._matrices3x3[OO] = KO, this
      }
      setMatrix2x2(OO, KO) {
        return this._checkUniform(OO), this._matrices2x2[OO] = KO, this
      }
      setArray2(OO, KO) {
        return this._checkUniform(OO), this._vectors2Arrays[OO] = KO, this
      }
      setArray3(OO, KO) {
        return this._checkUniform(OO), this._vectors3Arrays[OO] = KO, this
      }
      setArray4(OO, KO) {
        return this._checkUniform(OO), this._vectors4Arrays[OO] = KO, this
      }
      setUniformBuffer(OO, KO) {
        return -1 === this._options.uniformBuffers.indexOf(OO) && this._options.uniformBuffers.push(OO), this._uniformBuffers[OO] = KO, this
      }
      setTextureSampler(OO, KO) {
        return -1 === this._options.samplerObjects.indexOf(OO) && this._options.samplerObjects.push(OO), this._textureSamplers[OO] = KO, this
      }
      setStorageBuffer(OO, KO) {
        return -1 === this._options.storageBuffers.indexOf(OO) && this._options.storageBuffers.push(OO), this._storageBuffers[OO] = KO, this
      }
      setDefine(OO, KO) {
        const pO = OO.trimEnd() + " ",
          XO = this.options.defines.findIndex((KO => KO === OO || KO.startsWith(pO)));
        return XO >= 0 && this.options.defines.splice(XO, 1), ("boolean" !== typeof KO || KO) && this.options.defines.push(pO + KO), this
      }
      isReadyForSubMesh(OO, KO, pO) {
        return this.isReady(OO, pO, KO)
      }
      isReady(OO, KO, pO) {
        const XO = pO && this._storeEffectOnSubMeshes;
        if (this.isFrozen) {
          const OO = XO ? pO._drawWrapper : this._drawWrapper;
          if (OO.effect && OO._wasPreviouslyReady && OO._wasPreviouslyUsingInstances === KO) return !0
        }
        const eO = this.JKO(),
          vK = eO.qb(),
          hO = [],
          DO = [];
        let MO = null,
          VO = this._shaderPath,
          QO = this._options.uniforms,
          zK = this._options.uniformBuffers,
          AO = this._options.samplers;
        vK.getCaps().multiview && eO.activeCamera && eO.activeCamera.outputRenderTarget && eO.activeCamera.outputRenderTarget.getViewCount() > 1 && (this._multiview = !0, hO.push("#define MULTIVIEW"), -1 !== QO.indexOf("viewProjection") && -1 === QO.indexOf("viewProjectionR") && QO.push("viewProjectionR"));
        for (let bK = 0; bK < this._options.defines.length; bK++) {
          const OO = 0 === this._options.defines[bK].indexOf("#define") ? this._options.defines[bK] : `#define ${this._options.defines[bK]}`;
          hO.push(OO)
        }
        for (let bK = 0; bK < this._options.attributes.length; bK++) DO.push(this._options.attributes[bK]);
        if (OO && OO.isVerticesDataPresent(lO.j.ColorKind) && (-1 === DO.indexOf(lO.j.ColorKind) && DO.push(lO.j.ColorKind), hO.push("#define VERTEXCOLOR")), KO && (hO.push("#define INSTANCES"), (0, oO.vb)(DO, this._materialHelperNeedsPreviousMatrices), OO?.hasThinInstances && (hO.push("#define THIN_INSTANCES"), OO && OO.isVerticesDataPresent(lO.j.ColorInstanceKind) && (DO.push(lO.j.ColorInstanceKind), hO.push("#define INSTANCESCOLOR")))), OO && OO.useBones && OO.computeBonesUsingShaders && OO.skeleton) {
          DO.push(lO.j.MatricesIndicesKind), DO.push(lO.j.MatricesWeightsKind), OO.numBoneInfluencers > 4 && (DO.push(lO.j.MatricesIndicesExtraKind), DO.push(lO.j.MatricesWeightsExtraKind));
          const KO = OO.skeleton;
          hO.push("#define NUM_BONE_INFLUENCERS " + OO.numBoneInfluencers), MO = new CO.c, MO.addCPUSkinningFallback(0, OO), KO.isUsingTextureForMatrices ? (hO.push("#define BONETEXTURE"), -1 === QO.indexOf("boneTextureInfo") && QO.push("boneTextureInfo"), -1 === this._options.samplers.indexOf("boneSampler") && this._options.samplers.push("boneSampler")) : (hO.push("#define BonesPerMesh " + (KO.bones.length + 1)), -1 === QO.indexOf("mBones") && QO.push("mBones"))
        } else hO.push("#define NUM_BONE_INFLUENCERS 0");
        let fO = 0;
        const dO = OO ? OO.morphTargetManager : null;
        if (dO) {
          const KO = -1 !== hO.indexOf("#define UV1"),
            pO = -1 !== hO.indexOf("#define UV2"),
            XO = -1 !== hO.indexOf("#define TANGENT"),
            bK = -1 !== hO.indexOf("#define NORMAL"),
            eO = -1 !== hO.indexOf("#define VERTEXCOLOR");
          fO = (0, oO.R)(dO, hO, DO, OO, !0, bK, XO, KO, pO, eO), dO.isUsingTextureForTargets && (-1 === QO.indexOf("morphTargetTextureIndices") && QO.push("morphTargetTextureIndices"), -1 === this._options.samplers.indexOf("morphTargets") && this._options.samplers.push("morphTargets")), fO > 0 && (QO = QO.slice(), QO.push("morphTargetInfluences"), QO.push("morphTargetCount"), QO.push("morphTargetTextureInfo"), QO.push("morphTargetTextureIndices"))
        } else hO.push("#define NUM_MORPH_INFLUENCERS 0");
        if (OO) {
          const pO = OO.bakedVertexAnimationManager;
          pO && pO.isEnabled && (hO.push("#define BAKED_VERTEX_ANIMATION_TEXTURE"), -1 === QO.indexOf("bakedVertexAnimationSettings") && QO.push("bakedVertexAnimationSettings"), -1 === QO.indexOf("bakedVertexAnimationTextureSizeInverted") && QO.push("bakedVertexAnimationTextureSizeInverted"), -1 === QO.indexOf("bakedVertexAnimationTime") && QO.push("bakedVertexAnimationTime"), -1 === this._options.samplers.indexOf("bakedVertexAnimationTexture") && this._options.samplers.push("bakedVertexAnimationTexture"), KO && DO.push("bakedVertexAnimationSettingsInstanced"))
        }
        for (const bK in this._textures)
          if (!this._textures[bK].isReady()) return !1;
        for (const bK in this._internalTextures)
          if (!this._internalTextures[bK].isReady) return !1;
        OO && this.needAlphaTestingForMesh(OO) && hO.push("#define ALPHATEST"), !1 !== this._options.useClipPlane && ((0, aK.c)(QO), (0, aK.l)(this, eO, hO)), eO.fogEnabled && OO?.applyFog && eO.fogMode !== bK.e.FOGMODE_NONE && (hO.push("#define FOG"), -1 === QO.indexOf("view") && QO.push("view"), -1 === QO.indexOf("vFogInfos") && QO.push("vFogInfos"), -1 === QO.indexOf("vFogColor") && QO.push("vFogColor")), this._useLogarithmicDepth && (hO.push("#define LOGARITHMICDEPTH"), -1 === QO.indexOf("logarithmicDepthConstant") && QO.push("logarithmicDepthConstant"));
        const TO = pO ? pO.getRenderingMesh() : OO;
        if (TO && this.useVertexPulling) {
          const OO = TO.geometry;
          OO && (this._vertexPullingMetadata = (0, FO.e)(OO), this._vertexPullingMetadata && this._vertexPullingMetadata.forEach(((OO, KO) => {
            QO.push(`vp_${KO}_info`)
          }))), hO.push("#define USE_VERTEX_PULLING");
          const KO = TO.geometry?.getIndexBuffer();
          KO && !TO.isUnIndexed && (hO.push("#define VERTEX_PULLING_USE_INDEX_BUFFER"), KO.is32Bits && hO.push("#define VERTEX_PULLING_INDEX_BUFFER_32BITS"))
        }
        this.customShaderNameResolve && (QO = QO.slice(), zK = zK.slice(), AO = AO.slice(), VO = this.customShaderNameResolve(this.name, QO, zK, AO, hO, DO));
        const NO = XO ? pO._getDrawWrapper(void 0, !0) : this._drawWrapper,
          IO = NO?.effect ?? null,
          yK = NO?.defines ?? null,
          gK = hO.join("\n");
        let uO = IO;
        return yK !== gK && (uO = vK.createEffect(VO, {
          attributes: DO,
          uniformsNames: QO,
          uniformBuffersNames: zK,
          samplers: AO,
          defines: gK,
          fallbacks: MO,
          onCompiled: this.onCompiled,
          onError: this.onError,
          indexParameters: {
            maxSimultaneousMorphTargets: fO
          },
          shaderLanguage: this._options.shaderLanguage,
          extraInitializationsAsync: this._options.extraInitializationsAsync
        }, vK), XO ? pO.setEffect(uO, gK, this._materialContext) : NO && NO.setEffect(uO, gK), this._onEffectCreatedObservable && (LO.effect = uO, LO.subMesh = pO ?? OO?.au[0] ?? null, this._onEffectCreatedObservable.notifyObservers(LO))), NO._wasPreviouslyUsingInstances = !!KO, !!uO?.isReady() && (IO !== uO && eO.resetCachedMaterial(), NO._wasPreviouslyReady = !0, !0)
      }
      bindOnlyWorldMatrix(OO, KO) {
        const pO = KO ?? this.getEffect();
        if (!pO) return;
        const XO = this._options.uniforms; - 1 !== XO.indexOf("world") && pO.setMatrix("world", OO);
        const bK = this.JKO(); - 1 !== XO.indexOf("worldView") && (OO.multiplyToRef(bK.getViewMatrix(), this._cachedWorldViewMatrix), pO.setMatrix("worldView", this._cachedWorldViewMatrix)), -1 !== XO.indexOf("worldViewProjection") && (OO.multiplyToRef(bK.getTransformMatrix(), this._cachedWorldViewProjectionMatrix), pO.setMatrix("worldViewProjection", this._cachedWorldViewProjectionMatrix)), -1 !== XO.indexOf("view") && pO.setMatrix("view", bK.getViewMatrix())
      }
      bindForSubMesh(OO, KO, pO) {
        this.bind(OO, KO, pO._drawWrapperOverride?.effect, pO)
      }
      bind(OO, KO, pO, XO) {
        const bK = XO && this._storeEffectOnSubMeshes,
          eO = pO ?? (bK ? XO.effect : this.getEffect());
        if (!eO) return;
        const lO = this.JKO();
        this._activeEffect = eO, this.bindOnlyWorldMatrix(OO, pO);
        const vK = this._options.uniformBuffers;
        let CO = !1;
        if (eO && vK && vK.length > 0 && lO.qb().supportsUniformBuffers)
          for (let DO = 0; DO < vK.length; ++DO) {
            switch (vK[DO]) {
              case "Mesh":
                KO && (KO.getMeshUniformBuffer().bindToEffect(eO, "Mesh"), KO.transferToEffect(OO));
                break;
              case "Scene":
                (0, oO.A)(eO, lO.getSceneUniformBuffer()), lO.finalizeSceneUbo(), CO = !0
            }
          }
        const hO = KO && bK ? this._mustRebind(lO, eO, XO, KO.visibility) : lO.getCachedMaterial() !== this;
        if (eO && hO) {
          let OO;
          for (OO in CO || -1 === this._options.uniforms.indexOf("view") || eO.setMatrix("view", lO.getViewMatrix()), CO || -1 === this._options.uniforms.indexOf("projection") || eO.setMatrix("projection", lO.getProjectionMatrix()), CO || -1 === this._options.uniforms.indexOf("viewProjection") || (eO.setMatrix("viewProjection", lO.getTransformMatrix()), this._multiview && eO.setMatrix("viewProjectionR", lO._transformMatrixR)), lO.activeCamera && -1 !== this._options.uniforms.indexOf("cameraPosition") && eO.setVector3("cameraPosition", lO.activeCamera.globalPosition), (0, oO.g)(KO, eO), (0, aK.e)(eO, this, lO), this._vertexPullingMetadata && (0, FO.c)(eO, this._vertexPullingMetadata), this._useLogarithmicDepth && (0, oO.s)(bK ? XO.materialDefines : eO.defines, eO, lO), KO && (0, oO.i)(lO, KO, eO), this._textures) eO.setTexture(OO, this._textures[OO]);
          for (OO in this._internalTextures) eO._bindTexture(OO, this._internalTextures[OO]);
          for (OO in this._textureArrays) eO.setTextureArray(OO, this._textureArrays[OO]);
          for (OO in this._ints) eO.setInt(OO, this._ints[OO]);
          for (OO in this._uints) eO.setUInt(OO, this._uints[OO]);
          for (OO in this._floats) eO.setFloat(OO, this._floats[OO]);
          for (OO in this._floatsArrays) eO.setArray(OO, this._floatsArrays[OO]);
          for (OO in this._colors3) eO.setColor3(OO, this._colors3[OO]);
          for (OO in this._colors3Arrays) eO.setArray3(OO, this._colors3Arrays[OO]);
          for (OO in this._colors4) {
            const KO = this._colors4[OO];
            eO.setFloat4(OO, KO.r, KO.g, KO.b, KO.a)
          }
          for (OO in this._colors4Arrays) eO.setArray4(OO, this._colors4Arrays[OO]);
          for (OO in this._vectors2) eO.setVector2(OO, this._vectors2[OO]);
          for (OO in this._vectors3) eO.setVector3(OO, this._vectors3[OO]);
          for (OO in this._vectors4) eO.setVector4(OO, this._vectors4[OO]);
          for (OO in this._quaternions) eO.setQuaternion(OO, this._quaternions[OO]);
          for (OO in this._matrices) eO.setMatrix(OO, this._matrices[OO]);
          for (OO in this._matrixArrays) eO.setMatrices(OO, this._matrixArrays[OO]);
          for (OO in this._matrices3x3) eO.setMatrix3x3(OO, this._matrices3x3[OO]);
          for (OO in this._matrices2x2) eO.setMatrix2x2(OO, this._matrices2x2[OO]);
          for (OO in this._vectors2Arrays) eO.setArray2(OO, this._vectors2Arrays[OO]);
          for (OO in this._vectors3Arrays) eO.setArray3(OO, this._vectors3Arrays[OO]);
          for (OO in this._vectors4Arrays) eO.setArray4(OO, this._vectors4Arrays[OO]);
          for (OO in this._quaternionsArrays) eO.setArray4(OO, this._quaternionsArrays[OO]);
          for (OO in this._uniformBuffers) {
            const KO = this._uniformBuffers[OO].getBuffer();
            KO && eO.bindUniformBuffer(KO, OO)
          }
          const pO = lO.qb(),
            vK = pO.setExternalTexture;
          if (vK)
            for (OO in this._externalTextures) vK.call(pO, OO, this._externalTextures[OO]);
          const hO = pO.setTextureSampler;
          if (hO)
            for (OO in this._textureSamplers) hO.call(pO, OO, this._textureSamplers[OO]);
          const DO = pO.setStorageBuffer;
          if (DO)
            for (OO in this._storageBuffers) DO.call(pO, OO, this._storageBuffers[OO])
        }
        if (eO && KO && (hO || !this.isFrozen)) {
          (0, oO.w)(KO, eO), KO.morphTargetManager && KO.morphTargetManager.isUsingTextureForTargets && KO.morphTargetManager._bind(eO);
          const OO = KO.bakedVertexAnimationManager;
          if (OO && OO.isEnabled) {
            const OO = bK ? XO._drawWrapper : this._drawWrapper;
            KO.bakedVertexAnimationManager?.bind(eO, !!OO._wasPreviouslyUsingInstances)
          }
        }
        this._afterBind(KO, eO, XO)
      }
      getActiveTextures() {
        const OO = super.getActiveTextures();
        for (const KO in this._textures) OO.push(this._textures[KO]);
        for (const KO in this._textureArrays) {
          const pO = this._textureArrays[KO];
          for (let KO = 0; KO < pO.length; KO++) OO.push(pO[KO])
        }
        return OO
      }
      hasTexture(OO) {
        if (super.hasTexture(OO)) return !0;
        for (const pO in this._textures)
          if (this._textures[pO] === OO) return !0;
        const KO = OO.getInternalTexture();
        for (const pO in this._internalTextures)
          if (this._internalTextures[pO] === KO) return !0;
        for (const pO in this._textureArrays) {
          const KO = this._textureArrays[pO];
          for (let pO = 0; pO < KO.length; pO++)
            if (KO[pO] === OO) return !0
        }
        return !1
      }
      clone(OO) {
        const KO = XO.c.Clone((() => new QO(OO, this.JKO(), this._shaderPath, this._options, this._storeEffectOnSubMeshes)), this);
        KO.name = OO, KO.id = OO, "object" === typeof KO._shaderPath && (KO._shaderPath = {
          ...KO._shaderPath
        }), this._options = {
          ...this._options
        };
        const pO = Object.keys(this._options);
        for (const XO of pO) {
          const OO = this._options[XO];
          Array.isArray(OO) && (this._options[XO] = OO.slice(0))
        }
        this.stencil.copyTo(KO.stencil);
        for (const XO in this._textures) KO.setTexture(XO, this._textures[XO]);
        for (const XO in this._internalTextures) KO.setInternalTexture(XO, this._internalTextures[XO]);
        for (const XO in this._textureArrays) KO.setTextureArray(XO, this._textureArrays[XO]);
        for (const XO in this._externalTextures) KO.setExternalTexture(XO, this._externalTextures[XO]);
        for (const XO in this._ints) KO.setInt(XO, this._ints[XO]);
        for (const XO in this._uints) KO.setUInt(XO, this._uints[XO]);
        for (const XO in this._floats) KO.setFloat(XO, this._floats[XO]);
        for (const XO in this._floatsArrays) KO.setFloats(XO, this._floatsArrays[XO]);
        for (const XO in this._colors3) KO.setColor3(XO, this._colors3[XO]);
        for (const XO in this._colors3Arrays) KO._colors3Arrays[XO] = this._colors3Arrays[XO];
        for (const XO in this._colors4) KO.setColor4(XO, this._colors4[XO]);
        for (const XO in this._colors4Arrays) KO._colors4Arrays[XO] = this._colors4Arrays[XO];
        for (const XO in this._vectors2) KO.setVector2(XO, this._vectors2[XO]);
        for (const XO in this._vectors3) KO.setVector3(XO, this._vectors3[XO]);
        for (const XO in this._vectors4) KO.setVector4(XO, this._vectors4[XO]);
        for (const XO in this._quaternions) KO.setQuaternion(XO, this._quaternions[XO]);
        for (const XO in this._quaternionsArrays) KO._quaternionsArrays[XO] = this._quaternionsArrays[XO];
        for (const XO in this._matrices) KO.setMatrix(XO, this._matrices[XO]);
        for (const XO in this._matrixArrays) KO._matrixArrays[XO] = this._matrixArrays[XO].slice();
        for (const XO in this._matrices3x3) KO.setMatrix3x3(XO, this._matrices3x3[XO]);
        for (const XO in this._matrices2x2) KO.setMatrix2x2(XO, this._matrices2x2[XO]);
        for (const XO in this._vectors2Arrays) KO.setArray2(XO, this._vectors2Arrays[XO]);
        for (const XO in this._vectors3Arrays) KO.setArray3(XO, this._vectors3Arrays[XO]);
        for (const XO in this._vectors4Arrays) KO.setArray4(XO, this._vectors4Arrays[XO]);
        for (const XO in this._uniformBuffers) KO.setUniformBuffer(XO, this._uniformBuffers[XO]);
        for (const XO in this._textureSamplers) KO.setTextureSampler(XO, this._textureSamplers[XO]);
        for (const XO in this._storageBuffers) KO.setStorageBuffer(XO, this._storageBuffers[XO]);
        return KO
      }
      dispose(OO, KO, pO) {
        if (KO) {
          let OO;
          for (OO in this._textures) this._textures[OO].dispose();
          for (OO in this._internalTextures) this._internalTextures[OO].dispose();
          for (OO in this._textureArrays) {
            const KO = this._textureArrays[OO];
            for (let OO = 0; OO < KO.length; OO++) KO[OO].dispose()
          }
        }
        this._textures = {}, this._internalTextures = {}, super.dispose(OO, KO, pO)
      }
      serialize() {
        const OO = XO.c.Serialize(this);
        let KO;
        for (KO in OO.customType = "BABYLON.ShaderMaterial", OO.uniqueId = this.uniqueId, OO.options = this._options, OO.shaderPath = this._shaderPath, OO.storeEffectOnSubMeshes = this._storeEffectOnSubMeshes, OO.stencil = this.stencil.serialize(), OO.textures = {}, this._textures) OO.textures[KO] = this._textures[KO].serialize();
        for (KO in OO.textureArrays = {}, this._textureArrays) {
          OO.textureArrays[KO] = [];
          const pO = this._textureArrays[KO];
          for (let XO = 0; XO < pO.length; XO++) OO.textureArrays[KO].push(pO[XO].serialize())
        }
        for (KO in OO.ints = {}, this._ints) OO.ints[KO] = this._ints[KO];
        for (KO in OO.uints = {}, this._uints) OO.uints[KO] = this._uints[KO];
        for (KO in OO.floats = {}, this._floats) OO.floats[KO] = this._floats[KO];
        for (KO in OO.floatsArrays = {}, this._floatsArrays) OO.floatsArrays[KO] = this._floatsArrays[KO];
        for (KO in OO.colors3 = {}, this._colors3) {
          const pO = this._colors3[KO];
          OO.colors3[KO] = [pO.r, pO.g, pO.b]
        }
        for (KO in OO.colors3Arrays = {}, this._colors3Arrays) OO.colors3Arrays[KO] = this._colors3Arrays[KO];
        for (KO in OO.colors4 = {}, this._colors4) {
          const pO = this._colors4[KO];
          OO.colors4[KO] = [pO.r, pO.g, pO.b, pO.a]
        }
        for (KO in OO.colors4Arrays = {}, this._colors4Arrays) OO.colors4Arrays[KO] = this._colors4Arrays[KO];
        for (KO in OO.vectors2 = {}, this._vectors2) {
          const pO = this._vectors2[KO];
          OO.vectors2[KO] = [pO.x, pO.y]
        }
        for (KO in OO.vectors3 = {}, this._vectors3) {
          const pO = this._vectors3[KO];
          OO.vectors3[KO] = [pO.x, pO.y, pO.z]
        }
        for (KO in OO.vectors4 = {}, this._vectors4) {
          const pO = this._vectors4[KO];
          OO.vectors4[KO] = [pO.x, pO.y, pO.z, pO.w]
        }
        for (KO in OO.quaternions = {}, this._quaternions) OO.quaternions[KO] = this._quaternions[KO].WhO();
        for (KO in OO.matrices = {}, this._matrices) OO.matrices[KO] = this._matrices[KO].WhO();
        for (KO in OO.matrixArray = {}, this._matrixArrays) OO.matrixArray[KO] = this._matrixArrays[KO];
        for (KO in OO.matrices3x3 = {}, this._matrices3x3) OO.matrices3x3[KO] = this._matrices3x3[KO];
        for (KO in OO.matrices2x2 = {}, this._matrices2x2) OO.matrices2x2[KO] = this._matrices2x2[KO];
        for (KO in OO.vectors2Arrays = {}, this._vectors2Arrays) OO.vectors2Arrays[KO] = this._vectors2Arrays[KO];
        for (KO in OO.vectors3Arrays = {}, this._vectors3Arrays) OO.vectors3Arrays[KO] = this._vectors3Arrays[KO];
        for (KO in OO.vectors4Arrays = {}, this._vectors4Arrays) OO.vectors4Arrays[KO] = this._vectors4Arrays[KO];
        for (KO in OO.quaternionsArrays = {}, this._quaternionsArrays) OO.quaternionsArrays[KO] = this._quaternionsArrays[KO];
        return OO
      }
    }

    function zK(OO, KO, pO) {
      const bK = XO.c.Parse((() => new QO(OO.name, KO, OO.shaderPath, OO.options, OO.storeEffectOnSubMeshes)), OO, KO, pO);
      let lO;
      for (lO in OO.stencil && bK.stencil.parse(OO.stencil, KO, pO), OO.textures) bK.setTexture(lO, vK.e.Parse(OO.textures[lO], KO, pO));
      for (lO in OO.textureArrays) {
        const XO = OO.textureArrays[lO],
          eO = [];
        for (let OO = 0; OO < XO.length; OO++) eO.push(vK.e.Parse(XO[OO], KO, pO));
        bK.setTextureArray(lO, eO)
      }
      for (lO in OO.ints) bK.setInt(lO, OO.ints[lO]);
      for (lO in OO.uints) bK.setUInt(lO, OO.uints[lO]);
      for (lO in OO.floats) bK.setFloat(lO, OO.floats[lO]);
      for (lO in OO.floatsArrays) bK.setFloats(lO, OO.floatsArrays[lO]);
      for (lO in OO.colors3) {
        const KO = OO.colors3[lO];
        bK.setColor3(lO, {
          r: KO[0],
          g: KO[1],
          b: KO[2]
        })
      }
      for (lO in OO.colors3Arrays) {
        const KO = OO.colors3Arrays[lO].reduce(((OO, KO, pO) => (pO % 3 === 0 ? OO.push([KO]) : OO[OO.length - 1].push(KO), OO)), []).map((OO => ({
          r: OO[0],
          g: OO[1],
          b: OO[2]
        })));
        bK.setColor3Array(lO, KO)
      }
      for (lO in OO.colors4) {
        const KO = OO.colors4[lO];
        bK.setColor4(lO, {
          r: KO[0],
          g: KO[1],
          b: KO[2],
          a: KO[3]
        })
      }
      for (lO in OO.colors4Arrays) {
        const KO = OO.colors4Arrays[lO].reduce(((OO, KO, pO) => (pO % 4 === 0 ? OO.push([KO]) : OO[OO.length - 1].push(KO), OO)), []).map((OO => ({
          r: OO[0],
          g: OO[1],
          b: OO[2],
          a: OO[3]
        })));
        bK.setColor4Array(lO, KO)
      }
      for (lO in OO.vectors2) {
        const KO = OO.vectors2[lO];
        bK.setVector2(lO, {
          x: KO[0],
          y: KO[1]
        })
      }
      for (lO in OO.vectors3) {
        const KO = OO.vectors3[lO];
        bK.setVector3(lO, {
          x: KO[0],
          y: KO[1],
          z: KO[2]
        })
      }
      for (lO in OO.vectors4) {
        const KO = OO.vectors4[lO];
        bK.setVector4(lO, {
          x: KO[0],
          y: KO[1],
          z: KO[2],
          w: KO[3]
        })
      }
      for (lO in OO.quaternions) bK.setQuaternion(lO, eO.g.FromArray(OO.quaternions[lO]));
      for (lO in OO.matrices) bK.setMatrix(lO, eO.c.FromArray(OO.matrices[lO]));
      const CO = bK;
      for (lO in OO.matrixArray) CO._matrixArrays[lO] = new Float32Array(OO.matrixArray[lO]);
      for (lO in OO.matrices3x3) bK.setMatrix3x3(lO, OO.matrices3x3[lO]);
      for (lO in OO.matrices2x2) bK.setMatrix2x2(lO, OO.matrices2x2[lO]);
      for (lO in OO.vectors2Arrays) bK.setArray2(lO, OO.vectors2Arrays[lO]);
      for (lO in OO.vectors3Arrays) bK.setArray3(lO, OO.vectors3Arrays[lO]);
      for (lO in OO.vectors4Arrays) bK.setArray4(lO, OO.vectors4Arrays[lO]);
      for (lO in OO.quaternionsArrays) bK.setArray4(lO, OO.quaternionsArrays[lO]);
      return bK
    }
    async function AO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "";
      return await new Promise(((bK, eO) => {
        const lO = new hO.b;
        lO.addEventListener("readystatechange", (() => {
          if (4 == lO.readyState)
            if (200 == lO.status) {
              const KO = zK(JSON.parse(lO.responseText), pO || MO.c.LastCreatedScene, XO);
              OO && (KO.name = OO), bK(KO)
            } else eO("Unable to load the ShaderMaterial")
        })), lO.open("GET", KO), lO.send()
      }))
    }
    async function fO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
      const XO = this?.SnippetUrl ?? QO.SnippetUrl;
      return await new Promise(((bK, eO) => {
        const lO = new hO.b;
        lO.addEventListener("readystatechange", (() => {
          if (4 == lO.readyState)
            if (200 == lO.status) {
              const XO = JSON.parse(JSON.parse(lO.responseText).jsonPayload),
                eO = zK(JSON.parse(XO.shaderMaterial), KO || MO.c.LastCreatedScene, pO);
              eO.snippetId = OO, bK(eO)
            } else eO("Unable to load the snippet " + OO)
        })), lO.open("GET", XO + "/" + OO.replace(/#/g, "/")), lO.send()
      }))
    }
    QO.SnippetUrl = "https://snippet.babylonjs.com";
    const dO = fO;
    let TO = !1;

    function NO() {
      TO || (TO = !0, QO.Parse = zK, QO.ParseFromFileAsync = AO, QO.ParseFromSnippetAsync = fO, QO.CreateFromSnippetAsync = dO, (0, VO.h)("BABYLON.ShaderMaterial", QO))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);