export const id = 271;
export const ids = [271];
export const modules = {
  39242: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => AO,
      g: () => iK,
      j: () => LO,
      l: () => QO,
      o: () => aK,
      q: () => VO,
      t: () => FO,
      w: () => oO
    });
    var XO = pO(35632),
      bK = pO(35688),
      eO = pO(35664),
      lO = pO(39248),
      vK = pO(38301),
      CO = pO(38073),
      hO = pO(38112),
      DO = pO(38077),
      MO = pO(35676);
    const aK = Object.freeze(new XO.g(0, 0, 0, 0)),
      oO = Object.freeze(XO.o.Zero()),
      FO = Object.freeze(XO.m.Zero()),
      VO = Object.freeze(CO.c.Zero()),
      LO = Object.freeze(bK.e.Black()),
      QO = Object.freeze(new bK.g(0, 0, 0, 0)),
      zK = {
        key: 0,
        repeatCount: 0,
        i4: 2
      };
    class AO {
      static _PrepareAnimation(OO, KO, pO, eO, lO, vK, hO, DO) {
        let MO;
        if (!isNaN(parseFloat(lO)) && isFinite(lO) ? MO = AO.ANIMATIONTYPE_FLOAT : lO instanceof XO.g ? MO = AO.ANIMATIONTYPE_QUATERNION : lO instanceof XO.o ? MO = AO.ANIMATIONTYPE_VECTOR3 : lO instanceof XO.m ? MO = AO.ANIMATIONTYPE_VECTOR2 : lO instanceof bK.e ? MO = AO.ANIMATIONTYPE_COLOR3 : lO instanceof bK.g ? MO = AO.ANIMATIONTYPE_COLOR4 : lO instanceof CO.c && (MO = AO.ANIMATIONTYPE_SIZE), void 0 == MO) return null;
        const aK = new AO(OO, KO, pO, MO, hO),
          oO = [{
            frame: 0,
            value: lO
          }, {
            frame: eO,
            value: vK
          }];
        return aK.setKeys(oO), void 0 !== DO && aK.setEasingFunction(DO), aK
      }
      get runtimeAnimations() {
        return this._runtimeAnimations
      }
      get hasRunningRuntimeAnimations() {
        for (const OO of this._runtimeAnimations)
          if (!OO.isStopped()) return !0;
        return !1
      }
      constructor(OO, KO, pO, XO, bK, eO) {
        this.name = OO, this.targetProperty = KO, this.framePerSecond = pO, this.dataType = XO, this.i4 = bK, this.enableBlending = eO, this._easingFunction = null, this._runtimeAnimations = new Array, this._events = new Array, this.blendingSpeed = .01, this._ranges = {}, this._coreAnimation = null, this.targetPropertyPath = KO.split("."), this.dataType = XO, this.i4 = void 0 === bK ? AO.ANIMATIONLOOPMODE_CYCLE : bK, this.uniqueId = AO._UniqueIdGenerator++
      }
      toString(OO) {
        let KO = "Name: " + this.name + ", property: " + this.targetProperty;
        if (KO += ", datatype: " + ["Float", "WX", "Quaternion", "Matrix", "Color3", "Vector2"][this.dataType], KO += ", nKeys: " + (this._keys ? this._keys.length : "none"), KO += ", nRanges: " + (this._ranges ? Object.keys(this._ranges).length : "none"), OO) {
          KO += ", Ranges: {";
          let OO = !0;
          for (const pO in this._ranges) OO || (KO += ", "), OO = !1, KO += pO;
          KO += "}"
        }
        return KO
      }
      addEvent(OO) {
        this._events.push(OO), this._events.sort(((OO, KO) => OO.frame - KO.frame))
      }
      removeEvents(OO) {
        for (let KO = 0; KO < this._events.length; KO++) this._events[KO].frame === OO && (this._events.splice(KO, 1), KO--)
      }
      getEvents() {
        return this._events
      }
      createRange(OO, KO, pO) {
        this._ranges[OO] || (this._ranges[OO] = new lO.b(OO, KO, pO))
      }
      deleteRange(OO) {
        let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
        const pO = this._ranges[OO];
        if (pO) {
          if (KO) {
            const OO = pO.from,
              KO = pO.to;
            for (let pO = this._keys.length - 1; pO >= 0; pO--) this._keys[pO].frame >= OO && this._keys[pO].frame <= KO && this._keys.splice(pO, 1)
          }
          this._ranges[OO] = null
        }
      }
      getRange(OO) {
        return this._ranges[OO]
      }
      getKeys() {
        return this._keys
      }
      getHighestFrame() {
        let OO = 0;
        for (let KO = 0, pO = this._keys.length; KO < pO; KO++) OO < this._keys[KO].frame && (OO = this._keys[KO].frame);
        return OO
      }
      getEasingFunction() {
        return this._easingFunction
      }
      setEasingFunction(OO) {
        this._easingFunction = OO
      }
      floatInterpolateFunction(OO, KO, pO) {
        return (0, eO.Lerp)(OO, KO, pO)
      }
      floatInterpolateFunctionWithTangents(OO, KO, pO, XO, bK) {
        return (0, eO.Hermite)(OO, KO, pO, XO, bK)
      }
      quaternionInterpolateFunction(OO, KO, pO) {
        return XO.g.Slerp(OO, KO, pO)
      }
      quaternionInterpolateFunctionWithTangents(OO, KO, pO, bK, eO) {
        return XO.g.Hermite(OO, KO, pO, bK, eO).normalize()
      }
      vector3InterpolateFunction(OO, KO, pO) {
        return XO.o.Lerp(OO, KO, pO)
      }
      vector3InterpolateFunctionWithTangents(OO, KO, pO, bK, eO) {
        return XO.o.Hermite(OO, KO, pO, bK, eO)
      }
      vector2InterpolateFunction(OO, KO, pO) {
        return XO.m.Lerp(OO, KO, pO)
      }
      vector2InterpolateFunctionWithTangents(OO, KO, pO, bK, eO) {
        return XO.m.Hermite(OO, KO, pO, bK, eO)
      }
      sizeInterpolateFunction(OO, KO, pO) {
        return CO.c.Lerp(OO, KO, pO)
      }
      color3InterpolateFunction(OO, KO, pO) {
        return bK.e.Lerp(OO, KO, pO)
      }
      color3InterpolateFunctionWithTangents(OO, KO, pO, XO, eO) {
        return bK.e.Hermite(OO, KO, pO, XO, eO)
      }
      color4InterpolateFunction(OO, KO, pO) {
        return bK.g.Lerp(OO, KO, pO)
      }
      color4InterpolateFunctionWithTangents(OO, KO, pO, XO, eO) {
        return bK.g.Hermite(OO, KO, pO, XO, eO)
      }
      _getKeyValue(OO) {
        return "function" === typeof OO ? OO() : OO
      }
      evaluate(OO) {
        return zK.key = 0, this._interpolate(OO, zK)
      }
      _interpolate(OO, KO) {
        let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (KO.i4 === AO.ANIMATIONLOOPMODE_CONSTANT && KO.repeatCount > 0) return KO.highLimitValue.clone ? KO.highLimitValue.clone() : KO.highLimitValue;
        const XO = this._keys;
        let bK;
        if (this._coreAnimation) bK = this._coreAnimation._key;
        else {
          const eO = XO.length;
          for (bK = KO.key; bK >= 0 && OO < XO[bK].frame;) --bK;
          for (; bK + 1 <= eO - 1 && OO >= XO[bK + 1].frame;) ++bK;
          if (KO.key = bK, bK < 0) return pO ? void 0 : this._getKeyValue(XO[0].value);
          if (bK + 1 > eO - 1) return pO ? void 0 : this._getKeyValue(XO[eO - 1].value);
          this._key = bK
        }
        const eO = XO[bK],
          lO = XO[bK + 1];
        if (pO && (OO === eO.frame || OO === lO.frame)) return;
        const vK = this._getKeyValue(eO.value),
          CO = this._getKeyValue(lO.value);
        if (1 === eO.interpolation) return lO.frame > OO ? vK : CO;
        const hO = void 0 !== eO.outTangent && void 0 !== lO.inTangent,
          DO = lO.frame - eO.frame;
        let MO = (OO - eO.frame) / DO;
        const zK = eO.easingFunction || this.getEasingFunction();
        switch (zK && (MO = zK.ease(MO)), this.dataType) {
          case AO.ANIMATIONTYPE_FLOAT: {
            const OO = hO ? this.floatInterpolateFunctionWithTangents(vK, eO.outTangent * DO, CO, lO.inTangent * DO, MO) : this.floatInterpolateFunction(vK, CO, MO);
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return OO;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return (KO.offsetValue ?? 0) * KO.repeatCount + OO
            }
            break
          }
          case AO.ANIMATIONTYPE_QUATERNION: {
            const OO = hO ? this.quaternionInterpolateFunctionWithTangents(vK, eO.outTangent.scale(DO), CO, lO.inTangent.scale(DO), MO) : this.quaternionInterpolateFunction(vK, CO, MO);
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return OO;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return OO.addInPlace((KO.offsetValue || aK).scale(KO.repeatCount))
            }
            return OO
          }
          case AO.ANIMATIONTYPE_VECTOR3: {
            const OO = hO ? this.vector3InterpolateFunctionWithTangents(vK, eO.outTangent.scale(DO), CO, lO.inTangent.scale(DO), MO) : this.vector3InterpolateFunction(vK, CO, MO);
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return OO;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return OO.add((KO.offsetValue || oO).scale(KO.repeatCount))
            }
            break
          }
          case AO.ANIMATIONTYPE_VECTOR2: {
            const OO = hO ? this.vector2InterpolateFunctionWithTangents(vK, eO.outTangent.scale(DO), CO, lO.inTangent.scale(DO), MO) : this.vector2InterpolateFunction(vK, CO, MO);
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return OO;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return OO.add((KO.offsetValue || FO).scale(KO.repeatCount))
            }
            break
          }
          case AO.ANIMATIONTYPE_SIZE:
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return this.sizeInterpolateFunction(vK, CO, MO);
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return this.sizeInterpolateFunction(vK, CO, MO).add((KO.offsetValue || VO).scale(KO.repeatCount))
            }
            break;
          case AO.ANIMATIONTYPE_COLOR3: {
            const OO = hO ? this.color3InterpolateFunctionWithTangents(vK, eO.outTangent.scale(DO), CO, lO.inTangent.scale(DO), MO) : this.color3InterpolateFunction(vK, CO, MO);
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return OO;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return OO.add((KO.offsetValue || LO).scale(KO.repeatCount))
            }
            break
          }
          case AO.ANIMATIONTYPE_COLOR4: {
            const OO = hO ? this.color4InterpolateFunctionWithTangents(vK, eO.outTangent.scale(DO), CO, lO.inTangent.scale(DO), MO) : this.color4InterpolateFunction(vK, CO, MO);
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return OO;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return OO.add((KO.offsetValue || QO).scale(KO.repeatCount))
            }
            break
          }
          case AO.ANIMATIONTYPE_MATRIX:
            switch (KO.i4) {
              case AO.ANIMATIONLOOPMODE_CYCLE:
              case AO.ANIMATIONLOOPMODE_CONSTANT:
              case AO.ANIMATIONLOOPMODE_YOYO:
                return AO.AllowMatricesInterpolation ? this.matrixInterpolateFunction(vK, CO, MO, KO.workValue) : vK;
              case AO.ANIMATIONLOOPMODE_RELATIVE:
              case AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT:
                return vK
            }
        }
        return 0
      }
      matrixInterpolateFunction(OO, KO, pO, bK) {
        return AO.AllowMatrixDecomposeForInterpolation ? bK ? (XO.c.DecomposeLerpToRef(OO, KO, pO, bK), bK) : XO.c.DecomposeLerp(OO, KO, pO) : bK ? (XO.c.LerpToRef(OO, KO, pO, bK), bK) : XO.c.Lerp(OO, KO, pO)
      }
      clone() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        const KO = new AO(this.name, this.targetPropertyPath.join("."), this.framePerSecond, this.dataType, this.i4);
        if (KO.enableBlending = this.enableBlending, KO.blendingSpeed = this.blendingSpeed, this._keys && KO.setKeys(this._keys, !1, OO), this._ranges) {
          KO._ranges = {};
          for (const OO in this._ranges) {
            const pO = this._ranges[OO];
            pO && (KO._ranges[OO] = pO.clone())
          }
        }
        return KO
      }
      setKeys(OO) {
        let KO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
        if (arguments.length > 1 && void 0 !== arguments[1] && arguments[1]) this._keys = OO;
        else if (this._keys = OO.slice(0), KO)
          for (let pO = 0; pO < this._keys.length; pO++) {
            const OO = this._keys[pO];
            this._keys[pO] = {
              frame: OO.frame,
              value: OO.value.clone ? OO.value.clone() : OO.value,
              inTangent: OO.inTangent && OO.inTangent.clone ? OO.inTangent.clone() : OO.inTangent,
              outTangent: OO.outTangent && OO.outTangent.clone ? OO.outTangent.clone() : OO.outTangent,
              interpolation: OO.interpolation,
              lockedTangent: OO.lockedTangent,
              easingFunction: OO.easingFunction
            }
          }
      }
      createKeyForFrame(OO) {
        zK.key = 0;
        const KO = this._interpolate(OO, zK, !0);
        if (!KO) return this._keys[zK.key].frame === OO ? zK.key : zK.key + 1;
        const pO = {
          frame: OO,
          value: KO.clone ? KO.clone() : KO
        };
        return this._keys.splice(zK.key + 1, 0, pO), zK.key + 1
      }
      serialize() {
        const OO = {};
        OO.name = this.name, OO.property = this.targetProperty, OO.framePerSecond = this.framePerSecond, OO.dataType = this.dataType, OO.loopBehavior = this.i4, OO.enableBlending = this.enableBlending, OO.blendingSpeed = this.blendingSpeed;
        const KO = this.dataType;
        OO.keys = [];
        const pO = this.getKeys();
        for (let XO = 0; XO < pO.length; XO++) {
          const bK = pO[XO],
            eO = {};
          switch (eO.frame = bK.frame, KO) {
            case AO.ANIMATIONTYPE_FLOAT:
              eO.values = [bK.value], void 0 !== bK.inTangent && eO.values.push(bK.inTangent), void 0 !== bK.outTangent && (void 0 === bK.inTangent && eO.values.push(void 0), eO.values.push(bK.outTangent)), void 0 !== bK.interpolation && (void 0 === bK.inTangent && eO.values.push(void 0), void 0 === bK.outTangent && eO.values.push(void 0), eO.values.push(bK.interpolation));
              break;
            case AO.ANIMATIONTYPE_QUATERNION:
            case AO.ANIMATIONTYPE_MATRIX:
            case AO.ANIMATIONTYPE_VECTOR3:
            case AO.ANIMATIONTYPE_COLOR3:
            case AO.ANIMATIONTYPE_COLOR4:
              eO.values = bK.value.WhO(), void 0 != bK.inTangent && eO.values.push(bK.inTangent.WhO()), void 0 != bK.outTangent && (void 0 === bK.inTangent && eO.values.push(void 0), eO.values.push(bK.outTangent.WhO())), void 0 !== bK.interpolation && (void 0 === bK.inTangent && eO.values.push(void 0), void 0 === bK.outTangent && eO.values.push(void 0), eO.values.push(bK.interpolation))
          }
          OO.keys.push(eO)
        }
        OO.Xl = [];
        for (const XO in this._ranges) {
          const KO = this._ranges[XO];
          if (!KO) continue;
          const pO = {};
          pO.name = XO, pO.from = KO.from, pO.to = KO.to, OO.Xl.push(pO)
        }
        return OO
      }
      static _UniversalLerp(OO, KO, pO) {
        const XO = OO.constructor;
        return XO.Lerp ? XO.Lerp(OO, KO, pO) : XO.Slerp ? XO.Slerp(OO, KO, pO) : OO.toFixed ? OO * (1 - pO) + pO * KO : KO
      }
    }

    function fO(OO, KO, pO) {
      let bK;
      bK = "object" === typeof KO ? KO : {
        referenceFrame: KO ?? 0,
        range: pO,
        cloneOriginalAnimation: arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
        clonedAnimationName: arguments.length > 4 ? arguments[4] : void 0
      };
      let eO = OO;
      bK.cloneOriginalAnimation && (eO = OO.clone(), eO.name = bK.clonedAnimationName || eO.name);
      const lO = eO.getKeys();
      if (!lO.length) return eO;
      const vK = bK.referenceFrame && bK.referenceFrame >= 0 ? bK.referenceFrame : 0;
      let CO = 0;
      const hO = lO[0];
      let DO = lO.length - 1;
      const MO = lO[DO],
        aK = {
          referenceValue: hO.value,
          referencePosition: XO.j.WX[0],
          referenceQuaternion: XO.j.Quaternion[0],
          referenceScaling: XO.j.WX[1],
          keyPosition: XO.j.WX[2],
          keyQuaternion: XO.j.Quaternion[1],
          keyScaling: XO.j.WX[3]
        };
      let oO = hO.frame,
        FO = MO.frame;
      if (bK.range) {
        const OO = eO.getRange(bK.range);
        OO && (oO = OO.from, FO = OO.to)
      } else oO = bK.fromFrame ?? oO, FO = bK.toFrame ?? FO;
      oO !== hO.frame && (CO = eO.createKeyForFrame(oO)), FO !== MO.frame && (DO = eO.createKeyForFrame(FO));
      const VO = eO.getKeys();
      if (1 === VO.length) {
        const OO = eO._getKeyValue(VO[0].value);
        aK.referenceValue = OO.clone ? OO.clone() : OO
      } else if (vK <= hO.frame) {
        const OO = eO._getKeyValue(hO.value);
        aK.referenceValue = OO.clone ? OO.clone() : OO
      } else if (vK >= MO.frame) {
        const OO = eO._getKeyValue(MO.value);
        aK.referenceValue = OO.clone ? OO.clone() : OO
      } else {
        zK.key = 0;
        const OO = eO._interpolate(vK, zK);
        aK.referenceValue = OO.clone ? OO.clone() : OO
      }
      eO.dataType === AO.ANIMATIONTYPE_QUATERNION ? aK.referenceValue.normalize().conjugateInPlace() : eO.dataType === AO.ANIMATIONTYPE_MATRIX && (aK.referenceValue.decompose(aK.referenceScaling, aK.referenceQuaternion, aK.referencePosition), aK.referenceQuaternion.normalize().conjugateInPlace());
      let LO = Number.MAX_VALUE;
      const QO = bK.clipKeys ? [] : null;
      for (let zK = CO; zK <= DO; zK++) {
        let OO = VO[zK];
        if ((QO || bK.cloneOriginalAnimation) && (OO = {
            frame: OO.frame,
            value: OO.value.clone ? OO.value.clone() : OO.value,
            inTangent: OO.inTangent,
            outTangent: OO.outTangent,
            interpolation: OO.interpolation,
            lockedTangent: OO.lockedTangent,
            easingFunction: OO.easingFunction
          }, QO && (LO === Number.MAX_VALUE && (LO = OO.frame), OO.frame -= LO, QO.push(OO))), !zK || eO.dataType === AO.ANIMATIONTYPE_FLOAT || OO.value !== hO.value) switch (eO.dataType) {
          case AO.ANIMATIONTYPE_MATRIX:
            OO.value.decompose(aK.keyScaling, aK.keyQuaternion, aK.keyPosition), aK.keyPosition.oDO(aK.referencePosition), aK.keyScaling.divideInPlace(aK.referenceScaling), aK.referenceQuaternion.multiplyToRef(aK.keyQuaternion, aK.keyQuaternion), XO.c.ComposeToRef(aK.keyScaling, aK.keyQuaternion, aK.keyPosition, OO.value);
            break;
          case AO.ANIMATIONTYPE_QUATERNION:
            aK.referenceValue.multiplyToRef(OO.value, OO.value);
            break;
          case AO.ANIMATIONTYPE_VECTOR2:
          case AO.ANIMATIONTYPE_VECTOR3:
          case AO.ANIMATIONTYPE_COLOR3:
          case AO.ANIMATIONTYPE_COLOR4:
            OO.value.subtractToRef(aK.referenceValue, OO.value);
            break;
          case AO.ANIMATIONTYPE_SIZE:
            OO.value.width -= aK.referenceValue.width, OO.value.height -= aK.referenceValue.height;
            break;
          default:
            OO.value -= aK.referenceValue
        }
      }
      return QO && eO.setKeys(QO, !0), eO
    }

    function dO(OO, KO, pO, XO) {
      const bK = new AO(OO + "Animation", OO, pO, KO, AO.ANIMATIONLOOPMODE_CONSTANT);
      return bK.setEasingFunction(XO), bK
    }

    function TO(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
      const MO = AO._PrepareAnimation(OO, pO, XO, bK, eO, lO, vK, CO);
      return MO ? (KO.JKO && (DO = KO.JKO()), DO ? DO.beginDirectAnimation(KO, [MO], 0, bK, MO.i4 !== AO.ANIMATIONLOOPMODE_CONSTANT, 1, hO) : null) : null
    }

    function NO(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
      const MO = AO._PrepareAnimation(OO, XO, bK, eO, lO, vK, CO, hO);
      if (!MO) return null;
      return KO.JKO().beginDirectHierarchyAnimation(KO, pO, [MO], 0, eO, 1 === MO.i4, 1, DO)
    }

    function IO(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
      const DO = AO._PrepareAnimation(OO, pO, XO, bK, eO, lO, vK, CO);
      return DO ? (KO.animations.push(DO), KO.JKO().beginAnimation(KO, 0, bK, 1 === DO.i4, 1, hO)) : null
    }

    function yK(OO, KO, pO, XO, bK, eO, lO) {
      let vK = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
        CO = !(arguments.length > 8 && void 0 !== arguments[8]) || arguments[8],
        hO = arguments.length > 9 ? arguments[9] : void 0;
      if (lO <= 0) return pO[OO] = KO, vK && vK(), null;
      const DO = bK * (lO / 1e3);
      eO.setKeys(hO ?? [{
        frame: 0,
        value: pO[OO].clone ? pO[OO].clone() : pO[OO]
      }, {
        frame: DO,
        value: KO
      }]), pO.animations || (pO.animations = []), pO.animations.push(eO);
      return XO.beginAnimation(pO, 0, DO, !1, 1, vK ?? void 0, void 0, CO)
    }

    function gK(OO, KO) {
      DO.c.AppendSerializedAnimations(OO, KO)
    }

    function uO(OO) {
      const KO = new AO(OO.name, OO.property, OO.framePerSecond, OO.dataType, OO.loopBehavior),
        pO = OO.dataType,
        eO = [];
      let lO, vK;
      for (OO.enableBlending && (KO.enableBlending = OO.enableBlending), OO.blendingSpeed && (KO.blendingSpeed = OO.blendingSpeed), vK = 0; vK < OO.keys.length; vK++) {
        const KO = OO.keys[vK];
        let CO, hO, DO;
        switch (pO) {
          case AO.ANIMATIONTYPE_FLOAT:
            lO = KO.values[0], KO.values.length >= 2 && (CO = KO.values[1]), KO.values.length >= 3 && (hO = KO.values[2]), KO.values.length >= 4 && (DO = KO.values[3]);
            break;
          case AO.ANIMATIONTYPE_QUATERNION:
            if (lO = XO.g.FromArray(KO.values), KO.values.length >= 8) {
              const OO = XO.g.FromArray(KO.values.slice(4, 8));
              OO.equals(XO.g.Zero()) || (CO = OO)
            }
            if (KO.values.length >= 12) {
              const OO = XO.g.FromArray(KO.values.slice(8, 12));
              OO.equals(XO.g.Zero()) || (hO = OO)
            }
            KO.values.length >= 13 && (DO = KO.values[12]);
            break;
          case AO.ANIMATIONTYPE_MATRIX:
            lO = XO.c.FromArray(KO.values), KO.values.length >= 17 && (DO = KO.values[16]);
            break;
          case AO.ANIMATIONTYPE_COLOR3:
            lO = bK.e.FromArray(KO.values), KO.values[3] && (CO = bK.e.FromArray(KO.values[3])), KO.values[4] && (hO = bK.e.FromArray(KO.values[4])), KO.values[5] && (DO = KO.values[5]);
            break;
          case AO.ANIMATIONTYPE_COLOR4:
            lO = bK.g.FromArray(KO.values), KO.values[4] && (CO = bK.g.FromArray(KO.values[4])), KO.values[5] && (hO = bK.g.FromArray(KO.values[5])), KO.values[6] && (DO = KO.values[6]);
            break;
          case AO.ANIMATIONTYPE_VECTOR3:
          default:
            lO = XO.o.FromArray(KO.values), KO.values[3] && (CO = XO.o.FromArray(KO.values[3])), KO.values[4] && (hO = XO.o.FromArray(KO.values[4])), KO.values[5] && (DO = KO.values[5])
        }
        const MO = {};
        MO.frame = KO.frame, MO.value = lO, void 0 != CO && (MO.inTangent = CO), void 0 != hO && (MO.outTangent = hO), void 0 != DO && (MO.interpolation = DO), eO.push(MO)
      }
      if (KO.setKeys(eO), OO.Xl)
        for (vK = 0; vK < OO.Xl.length; vK++) lO = OO.Xl[vK], KO.createRange(lO.name, lO.from, lO.to);
      return KO
    }
    async function EO(OO, KO) {
      return await new Promise(((pO, XO) => {
        const bK = new hO.b;
        bK.addEventListener("readystatechange", (() => {
          if (4 == bK.readyState)
            if (200 == bK.status) {
              let KO = JSON.parse(bK.responseText);
              if (KO.animations && (KO = KO.animations), KO.length) {
                const OO = [];
                for (const pO of KO) OO.push(uO(pO));
                pO(OO)
              } else {
                const XO = uO(KO);
                OO && (XO.name = OO), pO(XO)
              }
            } else XO("Unable to load the animation")
        })), bK.open("GET", KO), bK.send()
      }))
    }
    async function jK(OO) {
      const KO = this?.SnippetUrl ?? AO.SnippetUrl;
      return await new Promise(((pO, XO) => {
        const bK = new hO.b;
        bK.addEventListener("readystatechange", (() => {
          if (4 == bK.readyState)
            if (200 == bK.status) {
              const KO = JSON.parse(JSON.parse(bK.responseText).jsonPayload);
              if (KO.animations) {
                const XO = JSON.parse(KO.animations),
                  bK = [];
                for (const KO of XO.animations) {
                  const pO = uO(KO);
                  pO.snippetId = OO, bK.push(pO)
                }
                pO(bK)
              } else {
                const XO = uO(JSON.parse(KO.animation));
                XO.snippetId = OO, pO(XO)
              }
            } else XO("Unable to load the snippet " + OO)
        })), bK.open("GET", KO + "/" + OO.replace(/#/g, "/")), bK.send()
      }))
    }
    AO._UniqueIdGenerator = 0, AO.AllowMatricesInterpolation = !1, AO.AllowMatrixDecomposeForInterpolation = !0, AO.InheritOriginalValueFromActiveAnimations = !1, AO.SnippetUrl = "https://snippet.babylonjs.com", AO.ANIMATIONTYPE_FLOAT = 0, AO.ANIMATIONTYPE_VECTOR3 = 1, AO.ANIMATIONTYPE_QUATERNION = 2, AO.ANIMATIONTYPE_MATRIX = 3, AO.ANIMATIONTYPE_COLOR3 = 4, AO.ANIMATIONTYPE_COLOR4 = 7, AO.ANIMATIONTYPE_VECTOR2 = 5, AO.ANIMATIONTYPE_SIZE = 6, AO.ANIMATIONLOOPMODE_RELATIVE = 0, AO.ANIMATIONLOOPMODE_CYCLE = 1, AO.ANIMATIONLOOPMODE_CONSTANT = 2, AO.ANIMATIONLOOPMODE_YOYO = 4, AO.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT = 5;
    const YO = jK;
    let wO = !1;

    function iK() {
      wO || (wO = !0, AO.Parse = uO, AO.ParseFromFileAsync = EO, AO.ParseFromSnippetAsync = jK, AO.CreateFromSnippetAsync = YO, AO.CreateAnimation = dO, AO.CreateAndStartAnimation = TO, AO.CreateAndStartHierarchyAnimation = NO, AO.CreateMergeAndStartAnimation = IO, AO.MakeAnimationAdditive = fO, AO.TransitionTo = yK, AO.AppendSerializedAnimations = gK, (0, MO.h)("BABYLON.Animation", AO), vK.c._AnimationRangeFactory = (OO, KO, pO) => new lO.b(OO, KO, pO))
    }
  },
  39248: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      constructor(OO, KO, pO) {
        this.name = OO, this.from = KO, this.to = pO
      }
      clone() {
        return new XO(this.name, this.from, this.to)
      }
    }
  },
  39297: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.b,
      f: () => XO.j
    });
    var XO = pO(38216);
    (0, XO.d)()
  },
  39279: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO.e
    });
    var XO = pO(38580);
    (0, XO.d)()
  },
  39254: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO.d
    });
    var XO = pO(38568);
    (0, XO.f)()
  },
  39305: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO.c
    });
    var XO = pO(38502);
    (0, XO.f)()
  },
  39251: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => XO.i
    });
    var XO = pO(38544);
    (0, XO.e)()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);