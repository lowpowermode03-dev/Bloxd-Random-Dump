export const id = 283;
export const ids = [283];
export const modules = {
  39568: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      installImageBitmapTextureLoader: () => hO
    });
    var XO = pO(37930),
      bK = pO(39575),
      eO = pO(2494);

    function lO(OO, KO) {
      if ("string" === typeof OO) {
        const pO = (0, eO.c)(OO);
        return pO ? new Blob([(0, eO.b)(pO.base64)], {
          type: pO.mimeType || KO
        }) : null
      }
      return OO instanceof Blob ? OO : new Blob([OO], {
        type: KO
      })
    }
    const vK = function(OO, KO, pO, XO) {
      let eO, vK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "",
        CO = arguments.length > 5 ? arguments[5] : void 0,
        hO = arguments.length > 6 ? arguments[6] : void 0;
      try {
        eO = lO(OO, vK)
      } catch {
        eO = null
      }
      return eO ? (createImageBitmap(eO, {
        premultiplyAlpha: "none",
        colorSpaceConversion: "none",
        ...CO
      }).then((OO => {
        KO(OO)
      }), (() => {
        (0, bK.g)(OO, KO, pO, XO, vK, CO, hO)
      })), null) : (0, bK.g)(OO, KO, pO, XO, vK, CO, hO)
    };
    let CO = "idle";

    function hO() {
      "idle" === CO && "function" === typeof createImageBitmap && (CO = "pending", async function() {
        const OO = document.createElement("canvas");
        OO.width = 1, OO.height = 2;
        const KO = OO.getContext("2d");
        if (!KO) throw new Error("2d context unavailable");
        KO.fillStyle = "#f00", KO.fillRect(0, 0, 1, 1), KO.fillStyle = "#0f0", KO.fillRect(0, 1, 1, 1);
        const pO = lO(OO.toDataURL(), "");
        if (!pO) throw new Error("toDataURL did not produce a base64 data URL");
        const XO = await createImageBitmap(pO, {
          premultiplyAlpha: "none",
          colorSpaceConversion: "none",
          imageOrientation: "flipY"
        });
        KO.drawImage(XO, 0, 0);
        const bK = KO.getImageData(0, 0, 1, 1).data;
        return bK[1] > bK[0]
      }().catch((() => (CO = "idle", !1))).then((OO => {
        "pending" === CO && (CO = "concluded"), OO && (XO.e.loadImage = vK)
      })))
    }
  },
  39575: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO.i,
      g: () => XO.s
    });
    var XO = pO(38104);
    (0, XO.v)()
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);