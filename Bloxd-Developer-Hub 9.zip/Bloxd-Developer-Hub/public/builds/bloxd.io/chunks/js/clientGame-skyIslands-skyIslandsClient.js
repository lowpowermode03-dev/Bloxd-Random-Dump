export const id = 23;
export const ids = [23];
export const modules = {
  37758: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => XO
    });
    const XO = function() {
      let OO;
      return {
        onCreate: KO => {
          OO = KO
        },
        onPlayerAltAction: (KO, pO, XO, bK, eO, lO) => {
          if (!lO || "Mesh" !== OO.getEntityType(lO)) return;
          const vK = OO.getEntityName(lO);
          "Perks" === vK ? OO.openShop(KO, !1, "Perks") : "Returning Bonus" === vK && OO.openShop(KO, !1, "Returning Player Bonus")
        }
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);