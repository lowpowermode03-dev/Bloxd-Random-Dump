export const id = 352;
export const ids = [352];
export const modules = {
  59336: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      passPixelShader: () => lO
    });
    var XO = pO(37907);
    const bK = "passPixelShader",
      eO = "varying vec2 vUV;uniform sampler2D textureSampler;\n#define CUSTOM_FRAGMENT_DEFINITIONS\nvoid main(void) \n{gl_FragColor=texture2D(textureSampler,vUV);}";
    XO.b.ShadersStore[bK] || (XO.b.ShadersStore[bK] = eO);
    const lO = {
      name: bK,
      shader: eO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);