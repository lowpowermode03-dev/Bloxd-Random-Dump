export const id = 343;
export const ids = [343];
export const modules = {
  59165: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      A: () => hO,
      B: () => MO,
      C: () => DO,
      X: () => aK
    });
    var XO = pO(39742),
      bK = (OO, KO) => OO.order - KO.order;

    function eO(OO, KO, pO) {
      OO.pendingDisposers.set(KO, pO)
    }

    function lO(OO, KO, pO) {
      pO && OO.pendingDisposers.get(KO) === pO && OO.pendingDisposers.delete(KO)
    }
    var vK = null,
      CO = null;

    function hO(OO, KO, pO, XO) {
      if (!KO || pO.material !== KO) return XO ?? Promise.resolve();
      const bK = MO(OO, KO._buildGroup, pO);
      return XO ? Promise.all([XO, bK]).then((() => {})) : bK
    }

    function DO(OO, KO, pO) {
      let XO = pO;
      for (const bK of KO) {
        const KO = Array.isArray(bK),
          pO = KO ? bK[0] : bK;
        XO = hO(OO, KO ? bK[1] : pO.material, pO, XO)
      }
      return (XO ?? Promise.resolve()).catch((KO => {
        OO._runtimeBuilds?._x(KO)
      }))
    }

    function MO(OO, KO, XO) {
      if (OO._z || !OO.meshes.includes(XO)) return OO._runtimeBuilds?.all().catch((() => {})) ?? Promise.resolve();
      if (function(OO, KO, pO) {
          for (const [bK, eO] of OO._groups)
            if (bK !== KO) {
              const OO = eO.indexOf(pO);
              OO >= 0 && eO.splice(OO, 1)
            } let XO = OO._groups.get(KO);
          XO || (XO = [], OO._groups.set(KO, XO));
          XO.includes(pO) || XO.push(pO)
        }(OO, KO, XO), "pbr" === KO._materialFamily && (OO._built || OO._groups.get(KO)?.r)) {
        const KO = OO._runtimeBuilds ?? oO(OO),
          XO = pO.e(373).then((() => pO(59784))).then((KO => {
            let {
              rebuildScenePbrPipelines: pO
            } = KO;
            return OO._z ? void 0 : pO(OO, !0)
          })).catch((KO => {
            OO._runtimeBuilds?._x(KO)
          }));
        return KO.track(XO)
      }
      return (OO._runtimeBuilds ?? oO(OO)).queue(KO, XO).catch((() => {}))
    }

    function aK(OO, KO, pO) {
      return OO._z ? Promise.resolve(void 0) : (OO._runtimeBuilds ?? oO(OO)).exclusive(KO, pO)
    }

    function oO(OO) {
      const KO = {
          YX: !1,
          error: null,
          active: new Set,
          chains: new WeakMap,
          generations: new WeakMap,
          installed: new WeakMap,
          installedMeshes: new Set,
          pendingDisposers: new WeakMap,
          tail: null
        },
        pO = OO,
        hO = {
          queue: (pO, DO) => {
            const MO = (KO.generations.get(DO) ?? 0) + 1,
              aK = DO.material;
            KO.generations.set(DO, MO);
            const oO = KO.chains.get(DO),
              FO = [KO.tail, vK?.get(pO)].filter((OO => !!OO));
            let VO = () => {};
            const AO = new Promise((OO => {
              VO = OO
            }));
            KO.tail = AO, (vK ??= new WeakMap).set(pO, AO);
            const fO = (oO ? oO.catch((() => {})) : Promise.resolve()).then((() => Promise.all(FO))).then((() => async function(OO, KO, pO, vK, hO, DO) {
              if (!LO(OO, KO, pO, vK, hO, DO)) return;
              const MO = OO._meshDisposables.get(vK);
              MO && (OO._meshDisposables.delete(vK), eO(KO, vK, MO));
              const aK = pO._rebuildSingle,
                oO = CO?.get(pO)?.llO.get(OO) ?? OO._groups.get(pO)?.r,
                FO = !!OO._groups.get(pO)?.r,
                VO = OO._disposables.length,
                AO = OO,
                fO = AO._pbrGeomContext;
              let dO, TO;
              try {
                TO = await pO(OO, [vK]), dO = AO._pbrGeomContext
              } catch (yK) {
                if (QO(OO, KO, vK, MO), zK(OO, KO), !LO(OO, KO, pO, vK, hO, DO)) return;
                throw yK
              } finally {
                pO._rebuildSingle = aK, "pbr" === pO._materialFamily && FO && (AO._pbrGeomContext = fO)
              }
              if (!LO(OO, KO, pO, vK, hO, DO)) return QO(OO, KO, vK, MO), void zK(OO, KO);
              for (let XO = OO._renderables.length - 1; XO >= 0; XO--) OO._renderables[XO].mesh === vK && OO._renderables.splice(XO, 1);
              if (MO) {
                for (const KO of MO) {
                  const pO = OO._disposables.indexOf(KO);
                  pO >= 0 && OO._disposables.splice(pO, 1);
                  const XO = KO.p;
                  if (XO) {
                    XO._disposed = !0;
                    const OO = XO._owner;
                    if (OO) {
                      const KO = OO.indexOf(XO);
                      KO >= 0 && OO.splice(KO, 1), XO._owner = void 0, 0 === OO.length && XO._onOwnerEmpty?.()
                    } else XO._onOwnerEmpty?.();
                    XO._onOwnerEmpty && (XO._onOwnerEmpty = void 0)
                  }
                }(0, XO.d)(OO.surface.engine, (() => {
                  for (const OO of MO) OO()
                }))
              }
              lO(KO, vK, MO), OO._renderables.push(...TO.renderables);
              const NO = OO._groups.get(pO);
              NO && (NO.o = [...(NO.o ?? []).filter((OO => OO.mesh !== vK)), ...TO.renderables]);
              TO.updater && OO._uniformUpdaters.push(TO.updater);
              FO && function(OO, KO) {
                const pO = new Set(OO._disposables.slice(0, KO));
                for (let XO = OO._disposables.length - 1; XO >= KO; XO--) pO.has(OO._disposables[XO]) && OO._disposables.splice(XO, 1)
              }(OO, VO);
              "pbr" === pO._materialFamily && FO && dO && (AO._pbrMeshGeomContexts ??= new WeakMap).set(vK, dO);
              (function(OO, KO, pO, XO, bK, eO) {
                let lO = CO?.get(pO);
                if (!lO) {
                  const OO = new WeakMap,
                    KO = new WeakMap,
                    XO = (XO, bK, eO, lO) => {
                      const vK = OO.get(XO)?.get(bK);
                      if (vK) return vK(XO, bK, eO, lO);
                      const CO = KO.get(XO) ?? XO._groups.get(pO)?.r;
                      if (CO) return CO(XO, bK, eO, lO);
                      throw new Error("Material group has not completed its initial build")
                    };
                  lO = {
                    llO: KO,
                    dispatch: XO,
                    scenes: OO
                  }, (CO ??= new WeakMap).set(pO, lO)
                }
                let vK = lO.scenes.get(OO);
                vK || (vK = new WeakMap, lO.scenes.set(OO, vK));
                vK.set(XO, bK), lO.llO.has(OO) || lO.llO.set(OO, eO ?? bK);
                const hO = OO._groups.get(pO);
                hO && (hO.r = lO.dispatch);
                let DO = KO.installed.get(XO);
                DO || (DO = new Set, KO.installed.set(XO, DO));
                DO.add(pO), KO.installedMeshes.add(XO)
              })(OO, KO, pO, vK, TO.rebuildSingle, FO ? oO : TO.rebuildSingle), vK.material._csmGen = (vK.material._csmGen ?? 0) + 1;
              const IO = OO._groups.get(pO);
              IO && !FO && (IO.r = TO.rebuildSingle);
              OO._renderables.sort(bK), OO._renderableVersion++, OO._materialEpoch++
            }(OO, KO, pO, DO, aK, MO))).catch((XO => {
              throw LO(OO, KO, pO, DO, aK, MO) && (KO.error = XO instanceof Error ? XO : new Error("Runtime mesh build failed", {
                cause: XO
              })), XO
            })).finally((() => {
              VO(), KO.tail === AO && (KO.tail = null), vK?.get(pO) === AO && vK.delete(pO)
            })).finally((() => {
              KO.chains.get(DO) === fO && KO.chains.delete(DO)
            }));
            return KO.chains.set(DO, fO), hO.track(fO)
          },
          all: () => Promise.all(KO.active).then((() => {})),
          track: OO => {
            const pO = OO.finally((() => KO.active.delete(pO)));
            return KO.active.add(pO), Promise.all(KO.active).then((() => {}))
          },
          base: (KO, pO) => {
            const XO = CO?.get(KO);
            return XO && XO.llO.set(OO, pO), XO?.dispatch ?? pO
          },
          get w() {
            return !!KO.tail
          },
          pendingDisposers: OO => KO.pendingDisposers.get(OO),
          holdPendingDisposers: (OO, pO) => eO(KO, OO, pO),
          releasePendingDisposers: (OO, pO) => lO(KO, OO, pO),
          reset: XO => {
            VO(OO, KO, XO), pO._pbrMeshGeomContexts?.delete(XO)
          },
          remove: XO => {
            KO.generations.set(XO, (KO.generations.get(XO) ?? 0) + 1), KO.chains.delete(XO), FO(OO, KO, XO), pO._pbrMeshGeomContexts?.delete(XO)
          },
          dropBase: KO => {
            const pO = CO?.get(KO);
            pO && (pO.llO.delete(OO), pO.scenes.delete(OO))
          },
          wait: async OO => {
            const pO = new Set;
            for (const XO of OO) {
              const OO = KO.chains.get(XO);
              OO && pO.add(OO)
            }
            await Promise.all(pO)
          },
          _e: function() {
            let OO = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (KO.error) {
              const pO = KO.error;
              throw OO && (KO.error = null), pO
            }
          },
          _x: OO => {
            KO.error = OO instanceof Error ? OO : new Error("Runtime mesh build failed", {
              cause: OO
            })
          },
          _d: () => KO.YX,
          exclusive: (OO, pO) => {
            const XO = [];
            KO.tail && XO.push(KO.tail);
            const bK = vK?.get(OO);
            bK && XO.push(bK);
            const eO = Promise.all(XO).then(pO),
              lO = eO.then((() => {}), (() => {}));
            return KO.tail = lO, (vK ??= new WeakMap).set(OO, lO), lO.then((() => {
              KO.tail === lO && (KO.tail = null), vK?.get(OO) === lO && vK.delete(OO)
            })), eO
          }
        };
      return OO._runtimeBuilds = hO, (OO._beforeRender ??= []).push((() => {
        hO._e()
      })), OO._disposables.push((() => {
        KO.YX = !0, KO.active.clear();
        for (const pO of KO.installedMeshes) VO(OO, KO, pO);
        for (const KO of OO._groups.keys()) CO?.get(KO)?.llO.delete(OO);
        OO._runtimeBuilds = void 0, pO._pbrMeshGeomContexts = void 0
      })), hO
    }

    function FO(OO, KO, pO) {
      const XO = KO.installed.get(pO);
      if (XO) {
        for (const KO of XO) CO?.get(KO)?.scenes.get(OO)?.delete(pO);
        KO.installed.delete(pO), KO.installedMeshes.delete(pO)
      }
    }

    function VO(OO, KO, pO) {
      FO(OO, KO, pO)
    }

    function LO(OO, KO, pO, XO, bK, eO) {
      return !KO.YX && KO.generations.get(XO) === eO && OO.meshes.includes(XO) && XO.material === bK && bK._buildGroup === pO
    }

    function QO(OO, KO, pO, bK) {
      const eO = OO._meshDisposables.get(pO);
      if (eO && eO !== bK) {
        OO._meshDisposables.delete(pO);
        for (const OO of eO) OO()
      }
      if (bK)
        if (OO.meshes.includes(pO)) OO._meshDisposables.set(pO, bK);
        else if (KO.YX)
        for (const XO of bK) XO();
      else(0, XO.d)(OO.surface.engine, (() => {
        for (const OO of bK) OO()
      }));
      lO(KO, pO, bK)
    }

    function zK(OO, KO) {
      if (!KO.YX) return;
      const pO = OO._disposables.splice(0);
      for (const XO of pO) XO()
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);