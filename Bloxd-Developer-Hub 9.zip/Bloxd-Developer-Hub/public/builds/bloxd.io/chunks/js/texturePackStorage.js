export const id = 47;
export const ids = [47];
export const modules = {
  8343: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      announceStoredTexturePack: () => bK.c,
      takeOneShotTexturePack: () => XO.k
    });
    var XO = pO(8347),
      bK = pO(8355)
  },
  8355: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK,
      f: () => eO
    });
    var XO = pO(2553);

    function bK() {
      if ("undefined" === typeof BroadcastChannel) return null;
      const OO = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
      try {
        const KO = new BroadcastChannel(XO.h);
        KO.postMessage({
          stored: OO
        }), KO.close()
      } catch {
        return null
      }
      return OO
    }

    function eO(OO) {
      const KO = "object" === typeof OO && null !== OO ? OO.stored : null;
      return "string" === typeof KO ? KO : null
    }
  },
  8347: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      g: () => bK,
      k: () => eO
    });
    var XO = pO(2553);
    async function bK(OO, KO, pO) {
      let bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : () => !1;
      const eO = lO(await OO.getItem(XO.f, KO));
      if (null === eO || bK()) return null;
      const vK = await OO.getItem(XO.g, KO);
      return bK() ? null : (await async function(OO) {
        await Promise.all([OO.removeItem(XO.f), OO.removeItem(XO.g)])
      }(OO).catch(pO), {
        pack: eO,
        source: "string" === typeof vK ? vK : null
      })
    }

    function eO(OO) {
      return (0, XO.l)() ? Promise.resolve(null) : bK(OO, !1, (OO => {
        console.error("Error removing temporary texture pack: ", OO)
      }), XO.l)
    }

    function lO(OO) {
      if ("object" !== typeof OO || null === OO) return null;
      const KO = OO.metaData;
      return "object" !== typeof KO || null === KO || "string" !== typeof KO.id ? null : OO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);