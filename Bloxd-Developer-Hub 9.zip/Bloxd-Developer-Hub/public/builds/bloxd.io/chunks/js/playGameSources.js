export const id = 42;
export const ids = [42];
export const modules = {
  37837: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => CO,
      g: () => eO,
      k: () => bK
    });
    const XO = 6e3;

    function bK(OO, KO) {
      return [Math.floor(OO[0] / KO) * KO, Math.floor(OO[1] / KO) * KO, Math.floor(OO[2] / KO) * KO]
    }

    function eO(OO) {
      const KO = (null !== OO && void 0 !== OO ? OO : "").match(/-?\d+(?:\.\d+)?/g);
      return KO && KO.length >= 3 ? [Number(KO[0]), Number(KO[1]), Number(KO[2])] : null
    }

    function lO(OO, KO) {
      return OO === KO ? String(OO) : `${OO}-${KO}`
    }

    function vK(OO, KO, pO, XO) {
      const bK = [];
      let eO = new Map;
      for (let lO = OO[2]; lO < OO[2] + KO; lO++) {
        const vK = new Map;
        let CO = OO[0];
        for (; CO < OO[0] + KO;) {
          const bK = XO(CO, pO, lO);
          let hO = CO;
          for (; hO + 1 < OO[0] + KO && XO(hO + 1, pO, lO) === bK;) hO++;
          if (null !== bK) {
            const OO = `${CO} ${hO} ${bK}`,
              KO = eO.get(OO);
            KO ? (KO.z1 = lO, eO.delete(OO), vK.set(OO, KO)) : vK.set(OO, {
              x0: CO,
              x1: hO,
              z0: lO,
              z1: lO,
              name: bK
            })
          }
          CO = hO + 1
        }
        bK.push(...eO.values()), eO = vK
      }
      return bK.push(...eO.values()), bK.sort(((OO, KO) => OO.z0 - KO.z0 || OO.x0 - KO.x0)).map((OO => `x${lO(OO.x0,OO.x1)} z${lO(OO.z0,OO.z1)} ${OO.name}`))
    }

    function CO(OO, KO, pO, bK) {
      let eO = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : XO;
      const CO = [OO[0] + KO - 1, OO[1] + KO - 1, OO[2] + KO - 1],
        hO = null !== bK && bK.every(((KO, pO) => Math.floor(KO) >= OO[pO] && Math.floor(KO) <= CO[pO])),
        DO = [`The chunk from ${OO.join(" ")} to ${CO.join(" ")}. Each line is one layer (y), with boxes of one block: x from-to, z from-to, then the block. Air is left out.`];
      null !== bK && DO.push(`The player's feet are at ${bK.map(Math.floor).join(" ")}, ${hO?"in this chunk":"outside this chunk"}.`);
      const MO = [];
      for (let XO = OO[1]; XO <= CO[1]; XO++) {
        const bK = vK(OO, KO, XO, pO).join("; "),
          eO = MO[MO.length - 1];
        (null === eO || void 0 === eO ? void 0 : eO.boxes) === bK ? eO.to = XO : MO.push({
          from: XO,
          to: XO,
          boxes: bK
        })
      }
      const aK = MO.filter((OO => "" !== OO.boxes));
      0 === aK.length && DO.push("It is all air.");
      let oO = DO.join("\n").length;
      for (const XO of aK) {
        const OO = `y${lO(XO.from,XO.to)}: ${XO.boxes}`;
        if (oO += OO.length + 1, oO > eO) {
          DO.push(`Cut short: the layers from y${XO.from} up aren't shown, as there are too many blocks.`);
          break
        }
        DO.push(OO)
      }
      return DO.join("\n")
    }
  },
  7875: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK
    });
    var XO = pO(22);

    function bK() {
      return !XO.d.get("isTouchScreen") && null !== document.pointerLockElement
    }
  },
  35421: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      d: () => eO,
      e: () => bK
    });
    const XO = [.25, .5, 1, 2, 4, 8, 16];

    function bK(OO, KO) {
      const pO = XO;
      let bK = pO.indexOf(OO);
      return -1 === bK && (bK = pO.findIndex((KO => KO >= OO)), -1 === bK && (bK = pO.length - 1)), "up" === KO ? pO[Math.min(bK + 1, pO.length - 1)] : pO[Math.max(bK - 1, 0)]
    }

    function eO(OO) {
      return OO <= XO[0]
    }

    function lO(OO) {
      return OO >= XO[XO.length - 1]
    }
  },
  37345: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(26),
      bK = pO(1569);

    function eO(OO) {
      let {
        taskId: KO,
        progress: pO
      } = OO;
      const XO = bK.c.get("_tasks");
      null !== XO && void 0 !== XO && XO[KO] && bK.c.apply({
        _tasks: {
          ...XO,
          [KO]: {
            ...XO[KO],
            progress: pO
          }
        }
      })
    }
    XO.i.subscribe("clientTaskProgress", (OO => {
      eO(OO)
    }))
  },
  37811: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK,
      e: () => FO,
      i: () => hO,
      k: () => MO,
      o: () => CO,
      r: () => lO,
      s: () => DO,
      u: () => VO
    });
    var XO = pO(1569),
      bK = pO(26),
      eO = pO(1579);
    const lO = (0, eO.o)((function() {
        var OO, KO, pO, bK;
        return {
          health: null !== (OO = XO.c.get("_health")) && void 0 !== OO ? OO : null,
          maxHealth: null !== (KO = XO.c.get("_totalMaxHealth")) && void 0 !== KO ? KO : null,
          shield: null !== (pO = XO.c.get("_shield")) && void 0 !== pO ? pO : null,
          maxShield: null !== (bK = XO.c.get("maxShield")) && void 0 !== bK ? bK : null
        }
      }), [], (0, eO.n)("_health", "_totalMaxHealth", "_shield", "maxShield")),
      vK = [{
        canFly: !1,
        flying: !1
      }, {
        canFly: !1,
        flying: !0
      }, {
        canFly: !0,
        flying: !1
      }, {
        canFly: !0,
        flying: !0
      }];

    function CO(OO, KO) {
      return vK[(OO ? 2 : 0) + (KO ? 1 : 0)]
    }
    const hO = (0, eO.o)((function() {
      var OO;
      return null !== (OO = XO.c.get("_aura")) && void 0 !== OO ? OO : null
    }), [], (0, eO.n)("_aura"));

    function DO(OO) {
      return {
        watch: KO => (0, bK.j)("shotPlayer", (pO => {
          let {
            playerId: XO,
            damage: bK,
            wasCrit: eO,
            distance: lO
          } = pO;
          OO(XO) && KO({
            damage: bK,
            wasCrit: eO,
            distance: lO
          })
        }))
      }
    }

    function MO(OO) {
      return (0, eO.c)("chat", (KO => {
        let {
          serverChatMsgId: pO,
          content: XO,
          chatterEId: bK
        } = KO;
        return {
          serverChatMsgId: null !== pO && void 0 !== pO ? pO : null,
          content: XO,
          author: bK ? OO(bK) : null
        }
      }))
    }
    class aK {
      constructor() {
        this.shown = null, this.needed = null, this.neededSince = 0
      }
      update(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Date.now();
        const pO = this.shown;
        return OO !== this.needed && (this.needed = OO, this.neededSince = KO, null === OO && (this.shown = null)), this.shown !== this.needed && KO - this.neededSince > 200 && (this.shown = this.needed), this.shown !== pO
      }
    }

    function oO(OO) {
      return [{
        translationKey: `touchKeys:${OO}`
      }]
    }
    const FO = {
      open: oO("open"),
      close: oO("close"),
      milk: oO("milk"),
      shear: oO("shear"),
      tame: oO("tame"),
      feed: oO("feed"),
      ride: oO("ride")
    };

    function VO(OO) {
      return [{
        translationKey: "touchKeys:tameWith"
      }, " ", {
        icon: OO
      }]
    }
  },
  38831: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      g: () => lO
    });
    var XO = pO(2567);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= pO.e(193).then((() => pO(34916))).then((OO => {
        let {
          ITEM_SPRITES: KO,
          ITEM_SPRITES_WITHOUT_FILE: pO,
          ITEM_FILES_WITHOUT_SPRITE: eO
        } = OO;
        bK = function(OO, KO, pO) {
          const bK = new Set,
            eO = (0, XO.w)(KO);
          let lO = 0;
          for (const [XO, vK] of OO.entries()) XO === eO[lO] ? lO++ : bK.add(vK);
          if ("" !== pO)
            for (const vK of pO.split(XO.r)) bK.add(vK);
          return bK
        }(KO.split(XO.r), pO, eO)
      }), (OO => {
        throw eO = null, OO
      })), eO
    }

    function vK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = bK) || void 0 === pO ? void 0 : pO.has(OO)) && void 0 !== KO && KO
    }
  },
  37804: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      return Math.hypot(OO[0] - KO[0], OO[1] - KO[1], OO[2] - KO[2]) < pO + .5
    }
    pO.d(KO, {
      b: () => XO
    })
  },
  37359: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO
    });
    var XO = pO(1077),
      bK = pO(1165),
      eO = pO(22),
      lO = pO(1152),
      vK = pO(1163),
      CO = pO(1344),
      hO = pO(35015);

    function DO(OO) {
      let {
        pOO: KO,
        XOO: pO
      } = OO;
      const DO = null !== KO && void 0 !== KO ? KO : (0, vK.b)().gameNameWithVariation;
      (0, XO.H)(DO) && ((0, hO.p)(), (0, lO.qb)((() => {
        console.log("Received matchmaking order from game server to game", KO), (0, eO.j)("inGameReplay"), (0, CO.navigatePreserveSearch)((0, bK.b)(DO, null !== pO && void 0 !== pO ? pO : void 0))
      }), "video_start"))
    }
  },
  37538: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(26),
      bK = pO(1591);

    function eO(OO) {
      var KO, pO;
      const eO = (0, bK.j)(null !== (KO = null === (pO = bK.s.toggleFreeCam) || void 0 === pO ? void 0 : pO[0]) && void 0 !== KO ? KO : null);
      XO.i.pl("showBottomMessage", {
        message: `Free Camera ${OO?"Enabled":"Disabled"}${eO?` - Press ${eO} to toggle`:""}`,
        timeoutLength: 2e3,
        type: "Warning"
      })
    }
  },
  37353: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => CO,
      e: () => lO,
      i: () => vK,
      m: () => hO
    });
    var XO = pO(26),
      bK = pO(1187);
    const eO = new Map;

    function lO(OO, KO) {
      XO.i.pl("newUiRequest", {
        id: OO,
        clientParameters: KO
      }, !0)
    }

    function vK(OO) {
      XO.i.pl("removeUiRequest", OO, !0);
      const KO = eO.get(OO);
      KO && (KO.tearDownNotification(), eO.delete(OO))
    }

    function CO() {
      XO.i.pl("clearUiRequests");
      for (const OO of eO.values()) OO.tearDownNotification();
      eO.clear()
    }

    function hO(OO, KO, pO) {
      const XO = bK.NotificationProvider.showPromptPopup({
        title: KO,
        confirmText: "general:yes",
        cancelText: "general:no",
        unlockPointerKey: "uiRequestPopup"
      });
      eO.set(OO, XO), XO.getResult().then((KO => {
        eO.delete(OO), "notificationTornDown" !== KO && pO(KO)
      }))
    }
  },
  37833: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => MO,
      e: () => aK
    });
    var XO = pO(171),
      bK = pO(37837);
    const eO = 20;

    function lO(OO) {
      return OO.map(Math.floor).join(" ")
    }

    function vK(OO) {
      return null === OO.amount || 1 === OO.amount ? OO.name : `${OO.amount} ${OO.name}`
    }
    var CO = pO(37843),
      hO = pO(1569),
      DO = pO(1163);

    function MO(OO, KO) {
      if (!OO) return CO.d;
      const pO = OO.playerFeet();
      if (!pO) return "The player isn't in the world yet, so no blocks can be seen.";
      const eO = XO.h.SX,
        lO = (0, bK.k)(null !== KO && void 0 !== KO ? KO : pO, eO),
        vK = OO.chunkBlocks(lO);
      return vK ? (0, bK.c)(lO, eO, ((KO, pO, XO) => {
        const bK = vK(KO, pO, XO);
        return 0 === bK ? null : OO.blockName(bK).split("|")[0]
      }), pO) : `The chunk from ${lO.join(" ")} isn't loaded: only chunks near the player are. The player's feet are at ${pO.map(Math.floor).join(" ")}.`
    }

    function aK(OO) {
      var KO, pO, XO;
      if (!OO) return CO.g;
      const bK = OO.playerFeet();
      if (!bK) return "The player isn't in the world yet, so nothing in it can be seen.";
      const {
        slots: MO,
        heldSlot: aK
      } = OO.inventory();
      return function(OO) {
        const KO = [];
        null !== OO.game && KO.push(`Game: ${OO.game}.`);
        const pO = null === OO.health ? "" : `, health ${Math.round(OO.health)}${null===OO.maxHealth?"":` of ${Math.round(OO.maxHealth)}`}`;
        KO.push(`The player (the creator) stands at ${lO(OO.position)}${pO}, ${OO.creative?"in":"not in"} creative mode.`);
        const XO = OO.slots[OO.heldSlot];
        KO.push(XO ? `Holding (slot ${OO.heldSlot}): ${vK(XO)}.` : `Holding nothing (slot ${OO.heldSlot} is empty).`);
        const bK = OO.slots.flatMap(((OO, KO) => OO ? [`slot ${KO}: ${vK(OO)}`] : []));
        KO.push(bK.length > 0 ? `Inventory: ${bK.join(", ")}.` : "Inventory: empty.");
        const CO = KO => Math.hypot(KO.position[0] - OO.position[0], KO.position[1] - OO.position[1], KO.position[2] - OO.position[2]),
          hO = [...OO.nearby].sort(((OO, KO) => CO(OO) - CO(KO)));
        if (0 === hO.length) KO.push("No other players or mobs are near enough to see.");
        else {
          KO.push("Near them, nearest first:");
          for (const OO of hO.slice(0, eO)) {
            const pO = "player" === OO.kind ? `player "${OO.name||"?"}"` : OO.name && OO.name !== OO.kind ? `${OO.kind} "${OO.name}"` : OO.kind,
              XO = Math.round(CO(OO));
            KO.push(`- ${pO} at ${lO(OO.position)}, ${XO} block${1===XO?"":"s"} away`)
          }
          hO.length > eO && KO.push(`- and ${hO.length-eO} more further away`)
        }
        return OO.droppedItems > 0 && KO.push(`${OO.droppedItems} dropped item${1===OO.droppedItems?" is":"s are"} on the ground nearby.`), KO.join("\n")
      }({
        game: null !== (KO = (0, DO.b)().gameNameWithVariation) && void 0 !== KO ? KO : null,
        position: bK,
        health: null !== (pO = hO.c.get("_health")) && void 0 !== pO ? pO : null,
        maxHealth: null !== (XO = hO.c.get("_totalMaxHealth")) && void 0 !== XO ? XO : null,
        creative: !0 === hO.c.get("creative"),
        heldSlot: aK,
        slots: MO,
        nearby: OO.nearby(),
        droppedItems: OO.droppedItems()
      })
    }
  },
  37378: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => vK,
      e: () => CO,
      g: () => hO
    });
    var XO = pO(1077),
      bK = pO(886),
      eO = pO(35356),
      lO = pO(26);

    function vK(OO) {
      let {
        lobbyName: KO,
        gameNameWithVariation: pO
      } = OO;
      return !(0, XO.J)(KO) || null !== pO && (pO.startsWith("testGym") || (0, bK.k)(pO))
    }

    function CO(OO) {
      return OO.Zm === eO.b.Leave || OO.Zm === eO.b.Cursor
    }

    function hO(OO) {
      lO.i.pl("codeCollab", {
        type: OO.Zm,
        docKey: OO.Wm,
        version: OO.Xs,
        editorCount: OO.lKO,
        peers: OO.vpO,
        updates: OO.Fs,
        playerId: OO.CKO,
        playerName: OO.hKO,
        colour: OO.DKO,
        anchor: OO.Qs,
        head: OO.jH,
        existingCursors: OO.MKO,
        files: OO.apO,
        engineSettings: OO.FKO
      })
    }
  },
  38798: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => WO,
      C: () => mK,
      D: () => jK,
      G: () => PO,
      I: () => EO,
      K: () => ZO,
      N: () => BO,
      P: () => wO,
      b: () => GO,
      c: () => HO,
      d: () => gK,
      h: () => qK,
      l: () => uO,
      n: () => yK,
      q: () => sO,
      s: () => YO,
      w: () => rK,
      x: () => iK
    });
    var XO = pO(1225),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(1964),
      vK = pO(3962),
      CO = pO(3923);
    let hO, DO = !1,
      MO = !1,
      aK = !1,
      oO = !1;
    const FO = 1300,
      VO = 3e3;
    let LO = 0,
      QO = !1,
      zK = !1,
      AO = 0;
    const fO = 2;
    let dO = !1,
      TO = !1;
    const NO = new Set,
      IO = new Set;

    function yK() {
      return DO
    }

    function gK() {
      return zK
    }

    function uO() {
      return TO
    }

    function EO() {
      return (0, eO.l)() && !TO
    }

    function jK(OO) {
      let KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      if (OO !== TO) {
        TO = OO;
        for (const OO of [...IO]) OO(TO);
        KO && BO()
      }
    }

    function YO(OO) {
      return IO.add(OO), () => {
        IO.delete(OO)
      }
    }

    function wO() {
      (0, vK.j)(lO.u.Menu, (0, eO.l)() ? 0 : lO.u.Menu)
    }

    function iK() {
      zK = !1, AO = 0, wO(), BO()
    }

    function rK(OO) {
      return NO.add(OO), () => {
        NO.delete(OO)
      }
    }

    function PO(OO) {
      MO = !1, OO !== DO && (DO = OO, oO = !1, clearTimeout(hO), aK = !DO && dO, DO ? (QO = !1, zK = !1, AO = 0) : EO() && !dO && (zK = !0), dO = !1, DO && !EO() && nO(), tK(), aK && BO())
    }

    function mK(OO) {
      OO !== QO && (QO = OO, OO || BO())
    }

    function sO() {
      MO = !1, oO || !0 !== JO() || (oO = !0, clearTimeout(hO), hO = setTimeout(RO, FO))
    }

    function HO() {
      return (!MO || performance.now() - LO > VO) && (MO = (0, CO.F)().lockPointer(), LO = performance.now()), MO
    }

    function RO() {
      SO() && cK() && HO()
    }

    function SO() {
      return EO() && !DO && !QO && !(0, XO.h)()
    }

    function JO() {
      var OO;
      return "undefined" === typeof navigator || null === (OO = navigator.userActivation) || void 0 === OO ? void 0 : OO.isActive
    }

    function cK() {
      return aK && (!navigator.userAgent.includes("Firefox/") || Boolean(document.fullscreenElement)) || !1 !== JO()
    }

    function BO() {
      EO() ? SO() && !zK && cK() && HO() : DO && !dO && nO()
    }

    function ZO() {
      zK ? navigator.vendor.startsWith("Apple") ? xK() : AO = fO : BO()
    }

    function GO() {
      AO > 0 && 0 === --AO && xK()
    }

    function qK() {
      AO = 0
    }

    function xK() {
      SO() && !0 === JO() && HO()
    }

    function nO() {
      dO = !0, (0, CO.F)().unlockPointer()
    }

    function WO() {
      MO = !1, aK = !1, oO = !1, clearTimeout(hO), QO = !1, zK = !1, AO = 0, dO = !1;
      const OO = DO;
      DO = !1, OO && tK()
    }

    function tK() {
      for (const OO of [...NO]) OO(DO);
      bK.i.pl("pointerLockUpdate", DO)
    }
  },
  38769: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => aK,
      e: () => vK,
      f: () => MO,
      h: () => hO,
      l: () => lO,
      o: () => DO,
      q: () => CO
    });
    let XO = null,
      bK = null,
      eO = null;

    function lO(OO) {
      XO = OO
    }

    function vK() {
      return XO
    }

    function CO(OO) {
      bK = OO
    }

    function hO() {
      return bK
    }

    function DO(OO) {
      eO = OO
    }

    function MO() {
      return eO
    }

    function aK() {
      var OO, KO;
      return !0 === (null === (OO = bK) || void 0 === OO || null === (KO = OO.currentViewer) || void 0 === KO ? void 0 : KO.inPlayback)
    }
  },
  38812: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      loadIcons: () => uO,
      setIconFileOverrides: () => EO,
      wasmIconLookups: () => HO,
      wasmIconQueries: () => sO
    });
    var XO = pO(3692),
      bK = pO(3660),
      eO = pO(38819),
      lO = pO(1561),
      vK = pO(1556),
      CO = pO(2560),
      hO = pO(2567);
    let DO = null,
      MO = null;

    function aK(OO) {
      const KO = OO.startsWith(hO.k),
        [pO, XO = pO, bK = pO] = (KO ? OO.slice(hO.k.length) : OO).split(hO.g);
      return {
        top: pO,
        left: XO,
        right: bK,
        half: KO
      }
    }

    function oO(OO) {
      const KO = null === DO ? void 0 : (0, CO.c)(OO),
        pO = void 0 === KO ? 0 : DO.codes[KO];
      return 0 === pO ? void 0 : DO.pool[pO - 1]
    }
    var FO = pO(2557),
      VO = pO(3647),
      LO = pO(3686),
      QO = pO(38828);
    const zK = "item:";
    let AO = null,
      fO = null,
      dO = null,
      TO = null,
      NO = !1,
      IO = !1,
      yK = null,
      gK = 0;

    function uO() {
      return IO || (IO = !0, (0, LO.h)().then((OO => {
        OO && (0, lO.d)()
      }))), dO ??= Promise.all([(0, FO.h)(), (MO ??= pO.e(1).then((() => pO(40657))).then((OO => {
        let {
          BLOCK_FACE_RUNS: KO,
          BLOCK_FACES: pO,
          MAX_FACE_ITEM_ID: XO
        } = OO;
        DO = {
          codes: (0, hO.A)(KO, XO + 1),
          pool: pO.split(hO.r).map(aK)
        }
      }), (OO => {
        throw MO = null, OO
      })), MO), (0, QO.g)(), pO.e(199).then((() => pO(35217)))]).then((OO => {
        let [, , KO, pO] = OO;
        KO.loadBundledTextures(), AO = KO, fO = pO, (0, lO.d)()
      }), (OO => {
        dO = null, console.warn("[bloxd-wasm-client] the item icon tables did not load, so item icons stay blank", OO)
      })), dO
    }

    function EO(OO) {
      yK = OO, gK++, (0, lO.d)()
    }

    function jK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = yK) || void 0 === pO ? void 0 : pO.itemSprite(OO)) && void 0 !== KO ? KO : AO.itemSpriteUrl(OO)
    }

    function YO(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = yK) || void 0 === pO ? void 0 : pO.blockTexture(OO)) && void 0 !== KO ? KO : AO.blockTextureUrl(OO)
    }

    function wO(OO) {
      var KO;
      return null !== (KO = (0, FO.d)(OO)) && void 0 !== KO ? KO : OO
    }

    function iK(OO, KO) {
      var pO, XO, bK;
      return null !== (pO = null !== (XO = null !== (bK = YO(OO)) && void 0 !== bK ? bK : null === KO || void 0 === KO ? void 0 : KO.rotated[OO]) && void 0 !== XO ? XO : null === KO || void 0 === KO ? void 0 : KO.animated[OO]) && void 0 !== pO ? pO : AO.notFoundUrl()
    }

    function rK(OO) {
      return void 0 !== (0, CO.c)(OO) ? OO : /^[1-9][0-9]*$/.test(OO) ? (0, CO.e)(Number(OO)) : void 0
    }

    function PO(OO) {
      var KO;
      if (OO.startsWith(zK)) {
        var pO;
        const KO = (0, FO.d)(OO.slice(5));
        return null !== (pO = void 0 === KO ? null : jK(KO)) && void 0 !== pO ? pO : AO.notFoundUrl()
      }
      return null !== (KO = AO.particleUrl(OO)) && void 0 !== KO ? KO : AO.notFoundUrl()
    }

    function mK(OO, KO) {
      return "StairsBlock" === OO ? OO : KO ? "SlabBlock" : "CubeBlock"
    }
    const sO = {
        async blockIcon(OO) {
          var KO;
          let {
            name: XO,
            size: bK,
            lineWidth: eO
          } = OO;
          await uO();
          const vK = null !== (KO = rK(XO)) && void 0 !== KO ? KO : XO,
            hO = (0, LO.e)(vK, bK, eO);
          if (null !== hO) return hO;
          const DO = oO(vK),
            MO = (0, CO.c)(vK),
            aK = void 0 === MO || null === fO ? void 0 : fO.itemTypeNameOf(MO);
          if (null === AO || void 0 === DO) return "";
          const FO = [DO.top, DO.left, DO.right].some((OO => null === YO(OO))),
            QO = FO ? await (TO ??= pO.e(187).then((() => pO(33017))).then((OO => (NO && (NO = !1, (0, lO.d)()), {
              rotated: OO.rotatedBlockTextures,
              animated: OO.animatedBlockTextures
            })), (OO => (TO = null, NO = !0, console.warn("[bloxd-wasm-client] the built block atlas did not load, so some block icons stay blank", OO), null))), TO) : null;
          if (FO && null === QO) return "";
          const zK = {
              top: iK(DO.top, QO),
              left: iK(DO.left, QO),
              right: iK(DO.right, QO),
              itemType: mK(aK, DO.half)
            },
            dO = 0 === gK ? vK : `${vK}#${gK}`;
          return (await (0, VO.d)()).drawBlockIconUrl(dO, bK, eO, (() => zK))
        }
      },
      HO = {
        itemIcon: function(OO) {
          var KO, pO;
          if (null === AO) return uO(), vK.DEFAULT_CLIENT_PAGE_SOURCES.lookups.itemIcon(OO);
          if ((0, bK.g)(OO)) return {
            kind: "icon",
            url: null !== (pO = AO.ingameIconUrl(OO)) && void 0 !== pO ? pO : AO.notFoundUrl()
          };
          if (OO.startsWith(bK.b)) return {
            kind: "icon",
            url: PO(OO.slice(bK.b.length))
          };
          if (0 === (0, CO.f)()) return (0, eO.d)(), vK.DEFAULT_CLIENT_PAGE_SOURCES.lookups.itemIcon(OO);
          const lO = null !== (KO = rK(OO)) && void 0 !== KO ? KO : OO,
            hO = (0, CO.c)(lO),
            DO = void 0 === hO ? void 0 : fO.itemTypeNameOf(hO);
          if (void 0 !== oO(lO)) return {
            kind: "drawnBlock"
          };
          const MO = function(OO) {
            var KO;
            return null !== (KO = jK(wO(OO))) && void 0 !== KO ? KO : AO.notFoundUrl()
          }(lO);
          if ((0, LO.f)(lO) && ! function(OO) {
              return null !== yK && (null !== yK.itemSprite(wO(OO)) || null !== yK.model(OO))
            }(lO)) return {
            kind: "model",
            url: MO
          };
          if ("Gun" === DO) return {
            kind: "gun",
            url: MO
          };
          if (void 0 !== hO && "GrayscaleArmour" === fO.itemTypeOf(hO) || Object.hasOwn(XO.e, lO)) {
            var aK;
            const KO = null !== (aK = (0, XO.h)(OO)) && void 0 !== aK ? aK : (0, XO.h)(lO);
            if (KO) return {
              kind: "item",
              url: MO,
              tint: KO
            }
          }
          return {
            kind: "item",
            url: MO
          }
        },
        hasIcon: function(OO) {
          return void 0 !== rK(OO) || (0, bK.g)(OO) || OO.startsWith(bK.b)
        },
        isItemName: function(OO) {
          return void 0 !== rK(OO)
        }
      }
  },
  38766: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      attachPlayGameSources: () => Yp,
      playGameSources: () => jX
    });
    var XO = pO(1556),
      bK = pO(38769),
      eO = pO(3923),
      lO = pO(38674),
      vK = pO(38771),
      CO = pO(37811),
      hO = pO(26),
      DO = pO(3943),
      MO = pO(3934),
      aK = pO(38717),
      oO = pO(38745),
      FO = pO(38776),
      VO = pO(38723);
    (0, VO.n)(DO.Hb.Chat, (OO => {
      if (OO.payloadKind !== MO.cc.Msgpack) return;
      const KO = function(OO) {
        if (null === OO || "object" !== typeof OO || !("content" in OO)) return null;
        const {
          chatMsgId: KO,
          content: pO,
          chatterEId: XO
        } = OO;
        return {
          serverChatMsgId: null !== KO && void 0 !== KO ? KO : void 0,
          content: pO,
          chatterEId: void 0 === XO || null === XO ? void 0 : String(XO)
        }
      }((0, aK.c)(OO.payload));
      null !== KO && hO.i.pl("chat", KO, !0)
    }));
    const LO = {
        chatReceived: (0, CO.k)((function(OO) {
          var KO, pO, XO;
          return {
            id: OO,
            name: null !== (KO = FO.g.getName(OO)) && void 0 !== KO ? KO : null,
            local: (0, oO.d)() === OO,
            profileEffect: null !== (pO = null === (XO = (0, FO.j)(OO)) || void 0 === XO ? void 0 : XO.profileEffect) && void 0 !== pO ? pO : null
          }
        }))
      },
      QO = {
        sendChatMessage(OO) {
          var KO;
          let {
            Tl: pO,
            channelName: XO
          } = OO;
          null === (KO = (0, lO.g)()) || void 0 === KO || KO.clientApi.sendChat(pO, XO)
        }
      };
    var zK = pO(171),
      AO = pO(1569),
      fO = pO(38667),
      dO = pO(37804);
    const TO = [0, 0, 0],
      NO = {
        codeBlockClickable(OO) {
          var KO;
          const pO = (0, lO.g)();
          if (null === pO || void 0 === pO || !pO.isSessionLive) return !1;
          const XO = pO.api;
          if (0 !== (fO.t.playerFlags(XO.apiView, 0) & fO.Ad.Crouching)) return !1;
          const bK = XO.queries.directorEntity(XO.localId) >= fO.jb.BYTES ? XO.memoryData(XO.scratch(), fO.jb.BYTES, 8, "the local player's DirectorEntity") : null;
          if (null === bK) return !1;
          for (let eO = 0; eO < 3; eO++) TO[eO] = fO.jb.feet(bK, 0, eO);
          return TO[1] += fO.jb.eyeHeight(bK, 0), (0, dO.b)(TO, OO, null !== (KO = AO.c.get("blockReach")) && void 0 !== KO ? KO : zK.h.RD)
        }
      },
      IO = {
        clickCodeBlock(OO) {
          var KO;
          null === (KO = (0, lO.g)()) || void 0 === KO || KO.clickCodeBlock(OO)
        }
      };
    var yK = pO(38689),
      gK = pO(38783),
      uO = pO(886),
      EO = pO(37419),
      jK = pO(3916),
      YO = pO(38700),
      wO = pO(38680),
      iK = pO(38709);

    function rK(OO) {
      if (null === OO) return null;
      const KO = [];
      for (const pO of OO) {
        const OO = Object.keys(pO)[0];
        if ("Kw" === OO) {
          const {
            str: OO,
            style: XO,
            clickableUrl: bK
          } = pO.Kw, eO = Object.keys(OO)[0], lO = OO[eO];
          "string" !== eO && "styledEntityName" !== eO && "styledTranslatedText" !== eO || KO.push({
            str: lO,
            style: XO,
            clickableUrl: bK
          })
        } else KO.push(pO[OO])
      }
      return KO
    }
    const PO = {
      screenPos(OO) {
        var KO, pO;
        return null !== (KO = null === (pO = (0, lO.g)()) || void 0 === pO ? void 0 : pO.renderFrame.projectWorldPosToScreenPos(OO)) && void 0 !== KO ? KO : {
          x: 0,
          y: 0
        }
      }
    };
    let mK = !1;

    function sO() {
      mK || (mK = !0, (0, VO.n)(DO.Hb.ProgressBarUpdate, (OO => {
        const KO = (0, iK.g)(OO);
        (0, iK.b)(KO) && hO.i.pl("progressBarUpdate", KO, !0)
      })), (0, VO.n)(YO.w, (OO => {
        const KO = (0, iK.d)(YO.w, OO);
        KO && hO.i.pl("middleScreenBarInitiate", {
          duration: KO.bOO,
          vOO: KO.vOO,
          horizBarRemOffset: KO.aOO
        }, !0)
      })), (0, VO.n)(DO.Hb.RemoveMiddleScreenBar, (() => {
        hO.i.pl("middleScreenBarRemove")
      })), (0, VO.n)(YO.ab, (OO => {
        const KO = (0, iK.d)(YO.ab, OO);
        if (KO) {
          var pO;
          const OO = KO.jsO ? null === (pO = (0, lO.g)()) || void 0 === pO ? void 0 : pO.renderFrame.projectDirectionToScreenPos(KO.jsO) : void 0;
          hO.i.pl("sendHitmarker", {
            qOO: KO.qOO,
            screenPos: OO
          }, !0)
        }
      })), (0, VO.n)(YO.fb, (OO => {
        const KO = (0, iK.d)(YO.fb, OO);
        if (KO) {
          const {
            id: OO,
            position: pO,
            style: XO,
            text: bK,
            Dk: eO
          } = KO;
          hO.i.pl("setDirectionArrow", {
            id: OO,
            position: pO,
            style: XO,
            text: rK(bK),
            Dk: eO
          }, !0)
        }
      })), (0, VO.n)(YO.h, (OO => {
        const KO = (0, iK.d)(YO.h, OO);
        KO && hO.i.pl("clearDirectionArrow", {
          id: KO.id
        }, !0)
      })), (0, VO.n)(YO.p, (OO => {
        const KO = (0, iK.d)(YO.p, OO);
        KO && hO.i.pl("flyingMiddleMessage", {
          content: rK(KO.HOO),
          ROO: KO.ROO,
          SOO: KO.SOO
        }, !0)
      })), (0, VO.n)(DO.Hb.WorldVariation, (OO => {
        const KO = (0, iK.g)(OO);
        if ("string" === typeof KO) {
          const OO = KO === uO.f ? null : {
            message: `Currently loaded as variation: ${KO}`,
            type: "Warning"
          };
          hO.i.pl("showPermanentBottomMessage", OO, !0)
        }
      })), (0, VO.n)(YO.L, (OO => {
        const KO = (0, iK.d)(YO.L, OO);
        KO && function(OO, KO) {
          const {
            type: pO,
            params: XO
          } = (0, EO.c)(KO), bK = {
            ...XO
          };
          for (const eO of EO.b) bK[eO] && (bK[eO] = rK(bK[eO]));
          jK.e.queueQTE(OO, pO, bK).getResult().then((KO => {
            var pO;
            "boolean" === typeof KO && (null === (pO = (0, lO.g)()) || void 0 === pO || pO.send(wO.b.QteResponse, {
              qteId: OO,
              qteResponse: KO
            }))
          }))
        }(KO.id, KO.r_)
      })), (0, VO.n)(YO.W, (OO => {
        const KO = (0, iK.d)(YO.W, OO);
        "number" === typeof KO && jK.e.cancelQTE(KO)
      })), (0, VO.g)((() => {
        jK.e.reset(), hO.i.pl("showPermanentBottomMessage", null, !0)
      })), (0, VO.k)((() => {
        jK.e.reset()
      })), (0, VO.n)(DO.Hb.EditItemCraftingRecipes, (OO => {
        const KO = (0, iK.g)(OO);
        (0, iK.b)(KO) && hO.i.pl("craftingRecipesEdited", {
          itemName: KO.craftingRecipeItemName,
          recipesForItem: KO.recipesForItem
        })
      })), (0, VO.n)(YO.U, (OO => {
        const KO = (0, iK.d)(YO.U, OO);
        KO && hO.i.pl("craftingRecipesEdited", {
          itemName: KO.P5,
          recipesForItem: []
        })
      })))
    }
    var HO = pO(37538);
    let RO = !1,
      SO = !1;

    function JO() {
      const OO = (0, lO.g)();
      if (null === OO || void 0 === OO || !OO.isSessionLive) return void(RO = !1);
      const KO = 0 !== (fO.t.playerFlags(OO.api.apiView, 0) & fO.Ad.FreeCam);
      KO !== RO && (RO = KO, (0, HO.e)(KO))
    }
    var cK = pO(256),
      BO = pO(35501),
      ZO = pO(1579);
    var GO = pO(38790),
      qK = pO(38741);
    const xK = {
      interactPrompt: null,
      blockText: null,
      neededTool: null
    };
    let nO = "off";

    function WO(OO) {
      var KO;
      return null === OO ? null : {
        label: null !== (KO = (0, GO.d)(OO, "interactionPrompt")) && void 0 !== KO ? KO : null
      }
    }
    const tK = new Map([
      [fO.rc.Open, {
        label: CO.e.open
      }],
      [fO.rc.Close, {
        label: CO.e.close
      }],
      [fO.rc.Milk, {
        label: CO.e.milk
      }],
      [fO.rc.Shear, {
        label: CO.e.shear
      }],
      [fO.rc.Tame, {
        label: CO.e.tame
      }],
      [fO.rc.Feed, {
        label: CO.e.feed
      }],
      [fO.rc.Ride, {
        label: CO.e.ride
      }]
    ]);
    class kK {
      constructor() {
        this.target = xK, this.yl = fO.Xc, this.optionName = null, this.pickaxe = new CO.d
      }
      read(OO) {
        var KO;
        const pO = fO.t.targetBlockId(OO.api.apiView, 0);
        pO !== this.yl && (this.yl = pO, this.optionName = pO === fO.Xc ? null : `${OO.tables.getMetaInfo(pO).rootName}CrosshairText`);
        const XO = null === this.optionName ? null : null !== (KO = OO.tables.getClientOption(this.optionName)) && void 0 !== KO ? KO : null;
        this.pickaxe.update(function(OO, KO) {
          var pO, XO, bK;
          if (0 === (fO.t.playerFlags(OO.api.apiView, 0) & fO.Ad.Breaking) || KO === fO.Xc || 0 === KO) return null;
          const {
            tables: eO
          } = OO;
          if (!0 === eO.getClientOption("creative")) return null;
          const lO = eO.nameOfId(KO),
            vK = null === (pO = OO.items.JK()) || void 0 === pO ? void 0 : pO.name,
            CO = null !== (XO = eO.getItemStat(lO, "harvestLevel")) && void 0 !== XO ? XO : 0;
          return (0, cK.vc)({
            blockHarvestType: eO.getDefaultItemStat(lO, "harvestType"),
            blockHarvestLevel: eO.getDefaultItemStat(lO, "harvestLevel"),
            harvestLevel: CO,
            heldToolType: void 0 === vK ? void 0 : eO.getDefaultItemStat(vK, "harvests"),
            heldToolLevel: void 0 === vK ? void 0 : eO.getDefaultItemStat(vK, "level")
          }) && null !== (bK = BO.r[CO]) && void 0 !== bK ? bK : null
        }(OO, pO)), OO.watchPromptPick(nO);
        const bK = "touch" === nO ? function(OO) {
          var KO;
          const pO = OO.interactLabel;
          return pO === fO.rc.Entity ? WO(OO.promptEntity) : pO === fO.rc.TameWith ? {
            label: (0, CO.u)(OO.tables.nameOfId(OO.interactIcon))
          } : null !== (KO = tK.get(pO)) && void 0 !== KO ? KO : null
        }(OO) : WO(OO.promptEntity);
        return this.target = (0, ZO.p)(this.target, {
          interactPrompt: bK,
          blockText: XO,
          neededTool: this.pickaxe.shown
        }), this.target
      }
    }
    let UO = null;
    const OK = {
      current: () => {
        var OO, KO;
        return null !== (OO = null === (KO = UO) || void 0 === KO ? void 0 : KO.target) && void 0 !== OO ? OO : xK
      },
      watch: OO => {
        const KO = new kK;
        UO = KO;
        const pO = (0, oO.e)((pO => {
          let XO = KO.read(pO);
          OO(XO);
          const bK = (0, eO.v)((() => {
            const bK = KO.read(pO);
            bK !== XO && (XO = bK, OO(bK))
          }));
          return () => {
            bK(), pO.watchPromptPick("off")
          }
        }));
        return () => {
          pO(), UO === KO && (UO = null)
        }
      }
    };
    let KK = 0,
      pK = 0;
    const XK = {
        health: CO.r,
        aura: CO.i,
        hotbar: qK.c.states.hotbar,
        heldItemAim: qK.c.states.heldItemAim,
        crouching: (0, oO.c)((OO => function(OO) {
          const KO = () => 0 !== (fO.t.playerFlags(OO.apiView, 0) & fO.Ad.Crouching);
          return {
            current: KO,
            watch(OO) {
              let pO = KO();
              return (0, eO.u)((() => {
                const XO = KO();
                XO !== pO && (pO = XO, OO(XO))
              }))
            }
          }
        }(OO.api).current), !1, (OO => (0, eO.u)(OO))),
        flight: (0, oO.c)((OO => () => function(OO) {
          const KO = fO.t.playerFlags(OO.apiView, 0);
          return (0, CO.o)(0 !== (KO & fO.Ad.CanFly), 0 !== (KO & fO.Ad.Flying))
        }(OO.api)), (0, CO.o)(!1, !1), (OO => (0, eO.u)(OO))),
        gliderBoostFuel: (0, oO.c)((OO => () => fO.t.gliderBoostFuel(OO.api.apiView, 0)), 0, (OO => (0, eO.u)(OO))),
        crosshairTarget: OK
      },
      bp = {
        hotbarSlotRequested: qK.c.events.hotbarSlotRequested,
        hotbarScrolled: qK.c.events.hotbarScrolled,
        numberKeyPressed: qK.c.events.numberKeyPressed,
        shotDamageToShow: (0, CO.s)((OO => !0 === (0, GO.d)(OO, "showDamageAmounts")))
      },
      eK = {
        selectHotbarSlot: qK.c.commands.selectHotbarSlot,
        setCrosshairInteractPrompt: OO => {
          nO = OO
        }
      },
      lK = {
        momentumFrac: function() {
          var OO, KO, pO;
          const XO = (0, lO.g)(),
            bK = performance.now(),
            eO = null === XO || void 0 === XO || null === (OO = XO.items.JK()) || void 0 === OO || null === (KO = OO.attributes) || void 0 === KO || null === (pO = KO.customAttributes) || void 0 === pO ? void 0 : pO.enchantments;
          return KK = null !== XO && null !== eO && void 0 !== eO && eO.Momentum ? 0 !== (fO.t.playerFlags(XO.api.apiView, 0) & fO.Ad.Breaking) ? Math.max(0, fO.t.momentumFrac(XO.api.apiView, 0)) : Math.max(0, KK - (bK - pK) / 1500) : 0, pK = bK, KK
        }
      };
    var vp = pO(38671),
      CK = pO(1098),
      hK = pO(22),
      DK = pO(35020),
      MK = pO(7875),
      ap = pO(1441),
      oK = pO(1964),
      FK = pO(3952);
    let VK = !1;

    function LK(OO) {
      VK = OO
    }

    function QK() {
      "inGame" !== hK.d.get("gameState") || (0, ap.l)() || hO.i.pl("ctrlCrouchWithoutFullscreen")
    }
    let zp = !1;
    const AK = {
        OpenEmoteWheel: () => {
          LK(!0), zp = !0, queueMicrotask((() => {
            zp && (zp = !1, hO.i.pl("requestEmoteWheelHoldOpen"))
          }))
        },
        ToggleFullCoordinateOverlay: () => {
          hO.i.pl("toggleFullCoordinateOverlay")
        },
        KeyYPressed: () => {
          (0, DK.c)() || hO.i.pl("YKeyPressed")
        },
        KeyXPressed: () => {
          (0, DK.c)() || hO.i.pl("XKeyPressed")
        },
        CtrlCrouch: QK,
        "primary-fire": () => {
          hO.i.pl("mouseState", {
            PJ: CK.b.DownFirePrimary,
            isDown: !0
          })
        },
        "alt-fire": () => {
          hO.i.pl("mouseState", {
            PJ: CK.b.DownFireSecondary,
            isDown: !0
          })
        },
        TouchHold: () => {
          hO.i.pl("mouseState", {
            PJ: CK.b.TouchDownLong,
            isDown: !0
          })
        }
      },
      fK = {
        OpenEmoteWheel: () => {
          LK(!1), zp ? (zp = !1, (0, MK.b)() || hO.i.pl("requestEmoteWheelHoldOpen")) : hO.i.pl("requestEmoteWheelHoldRelease")
        },
        CtrlCrouch: QK,
        "primary-fire": () => {
          hO.i.pl("mouseState", {
            PJ: CK.b.UpFirePrimary,
            isDown: !1
          })
        },
        "alt-fire": () => {
          hO.i.pl("mouseState", {
            PJ: CK.b.UpFireSecondary,
            isDown: !1
          })
        },
        TouchDig: () => {
          hO.i.pl("mouseState", {
            PJ: CK.b.UpFirePrimary,
            isDown: !1
          })
        }
      };
    let dK = !1;

    function TK() {
      dK || (dK = !0, (0, FK.h)((OO => {
        if ((0, bK.c)()) return;
        const KO = (0, FK.f)(OO) ? "primary-fire" : OO.action;
        var pO;
        if (OO.down) {
          if (0 === (OO.flags & oK.b.Synthetic)) {
            var XO;
            null === (XO = AK[KO]) || void 0 === XO || XO.call(AK)
          }
        } else null === (pO = fK[KO]) || void 0 === pO || pO.call(fK)
      })))
    }
    var NK = pO(243),
      IK = pO(94),
      yp = pO(36),
      gp = pO(38798),
      uK = pO(1163),
      EK = pO(37378);
    let jp = !1;
    const YK = {
      sendCodeCollab(OO) {
        var KO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.CodeCollab, (0, wO.j)(OO), (0, EK.e)(OO))
      }
    };
    let wK = null,
      ip = !1,
      rp = null;

    function PK() {
      return "inGame" === hK.d.get("gameState") && !(0, DK.c)()
    }
    const mp = {
        OpenInventory: OO => {
          (0, ap.t)(OO, "inventory", (0, vp.i)())
        },
        OpenShop: OO => {
          wK && PK() && (0, ap.p)(OO, NK.o.SHOP, !wK.shopIsEmpty(AO.c.get("shopInfo")))
        },
        OpenLobbyLeaderboard: OO => {
          PK() && (0, ap.p)(OO, NK.o.LOBBY_LEADERBOARD, !!AO.c.get("lobbyLeaderboardInfo"))
        },
        OpenTasksAndLeaderboard: OO => {
          var KO;
          const pO = null === (KO = wK) || void 0 === KO ? void 0 : KO.getClientGameMapKey();
          pO ? (0, ap.v)(OO, !0, pO) : (0, ap.t)(OO, "retentionFeatures", !(!AO.c.get("_tasks") && !AO.c.get("_availableLeaderboards")))
        },
        OpenInviteLink: OO => {
          (0, ap.t)(OO, "inviteLink", IK.featureFlags.canUseInviteLinks)
        },
        OpenCodeEditor: OO => {
          PK() && function(OO) {
            var KO;
            const pO = (0, lO.g)(),
              XO = null !== pO && void 0 !== pO && pO.isSessionLive ? pO.api : null,
              bK = XO ? XO.fV(XO.localId) : null,
              eO = null !== (KO = null === bK || void 0 === bK ? void 0 : bK.map((OO => Math.floor(OO)))) && void 0 !== KO ? KO : null;
            (0, ap.v)(OO, null !== eO && (0, EK.c)((0, uK.b)()), (() => {
              hO.i.pl("EditLobbyCode", eO)
            }))
          }(OO)
        },
        HideUi: () => {
          hO.i.pl("showUi", !1)
        }
      },
      sK = {
        HideUi: () => {
          hO.i.pl("showUi", !0)
        }
      };

    function HK() {
      ip || (ip = !0, pO.e(144).then((() => pO(40640))).then((OO => {
        wK = OO
      }), (OO => {
        console.error("[bloxd-wasm-client] the menu keys' checks did not load", OO)
      })), (0, gp.w)((OO => {
        OO || !(0, gp.d)() || (0, IK.isMobile)() || !yp.e.getItem("disableFullscreen") || (0, ap.i)() || hK.d.set({
          openEverythingMenuName: NK.o.SETTINGS
        })
      })), (0, FK.h)((OO => {
        let {
          action: KO,
          down: pO,
          press: XO
        } = OO;
        var eO, lO;
        (0, bK.c)() || (pO ? null === (eO = mp[KO]) || void 0 === eO || eO.call(mp, function(OO) {
          var KO;
          if (0 === OO || (null === (KO = rp) || void 0 === KO ? void 0 : KO.press) !== OO) {
            const KO = {
              press: OO,
              event: new Event("inputAction")
            };
            rp = KO, queueMicrotask((() => {
              rp === KO && (rp = null)
            }))
          }
          return rp.event
        }(XO)) : null === (lO = sK[KO]) || void 0 === lO || lO.call(sK))
      })))
    }
    var RK = pO(37345),
      SK = pO(37359),
      JK = pO(37353);
    const cp = {
      completeTask(OO) {
        var KO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.CompleteTask, (0, wO.l)(OO))
      },
      setServerCookie(OO) {
        var KO;
        let {
          key: pO,
          value: XO
        } = OO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.GeneralCookieSet, (0, wO.t)({
          zq: pO,
          YG: XO
        }))
      },
      answerUiRequest(OO) {
        var KO;
        let {
          id: pO,
          lV: XO
        } = OO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.UiRequestResp, (0, wO.R)({
          lY: pO,
          hY: XO,
          FY: 5
        }))
      },
      chooseRewardedAd(OO) {
        var KO;
        let {
          id: pO,
          lV: XO
        } = OO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.UiRequestResponded, (0, wO.O)({
          id: pO,
          lV: XO
        }))
      },
      requestLeaderboard(OO) {
        var KO;
        let {
          category: pO,
          timeframe: XO,
          seeTop: bK
        } = OO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.LeaderboardRequest, {
          category: pO,
          timeframe: XO,
          seeTop: bK
        })
      }
    };
    let BK = !1;
    const ZK = zK.h.gM / 2,
      GK = [ZK, -ZK, -ZK, -ZK, ZK, ZK, -ZK, ZK],
      qp = [0, 0, 0];

    function xp(OO, KO, pO) {
      for (let XO = 0; XO < OO.length; XO += 2)
        if (OO[XO] === KO && OO[XO + 1] === pO) return !0;
      return !1
    }
    const nK = {
      blocksStandingOn: function() {
        const OO = (0, lO.g)();
        if (null === OO) return [];
        const {
          api: KO,
          chunks: pO,
          tables: XO
        } = OO;
        if (!KO.readPosition(KO.localId, qp)) return [];
        const [bK, eO, vK] = qp, CO = Math.ceil(eO) - 1, hO = [], DO = [];
        for (let lO = 0; lO < GK.length; lO += 2) {
          const OO = bK + GK[lO],
            KO = vK + GK[lO + 1];
          if (Number.isInteger(OO) || Number.isInteger(KO)) continue;
          const eO = Math.floor(OO),
            MO = Math.floor(KO);
          if (xp(DO, eO, MO)) continue;
          const aK = pO.yl(eO, CO, MO);
          XO.isSolidBlockId(aK) && (DO.push(eO, MO), hO.push(XO.nameOfId(aK)))
        }
        return hO
      },
      dropAhead: function() {
        const OO = (0, lO.g)();
        return null !== OO && 0 !== (fO.t.playerFlags(OO.api.apiView, 0) & fO.Ad.DropAhead)
      }
    };
    var WK = pO(35421),
      tp = pO(37456),
      kp = pO(1187),
      UK = pO(38748);
    const Op = new Set(["replayLoad", "replaySave", "replaySaveAs", "replayTimelineZoomIn", "replayTimelineZoomOut"]),
      Kp = new Set(["replaySkipBack", "replaySkipForward", "replaySpeedUp", "replaySpeedDown", "replayRecordKeyframe"]);

    function pp() {
      const OO = new Set;
      return {
        add: KO => (OO.add(KO), () => {
          OO.delete(KO)
        }),
        fire() {
          for (const KO of OO) KO()
        }
      }
    }
    const Xp = Object.freeze([]);

    function bX(OO, KO) {
      let pO, {
        rereads: XO,
        followLocalId: bK
      } = KO;
      const lO = () => (pO = (0, ZO.p)(pO, OO()), pO);
      return {
        current: lO,
        watch(OO) {
          const KO = (0, FO.e)((KO => {
            XO(KO) && OO(lO())
          }));
          if (!bK) return KO;
          let pO = (0, oO.d)();
          const vK = (0, eO.v)((() => {
            const KO = (0, oO.d)();
            KO !== pO && (pO = KO, OO(lO()))
          }));
          return () => {
            KO(), vK()
          }
        }
      }
    }
    const ep = {
        players: bX((function() {
          const OO = FO.g.ids(),
            KO = {};
          for (const eO of OO) {
            var pO, XO, bK;
            KO[eO] = {
              name: null !== (pO = FO.g.getName(eO)) && void 0 !== pO ? pO : null,
              ranks: null !== (XO = FO.g.getSetting(eO, "ranks")) && void 0 !== XO ? XO : Xp,
              cosmetics: null !== (bK = (0, FO.j)(eO)) && void 0 !== bK ? bK : null
            }
          }
          return {
            ids: OO,
            byId: KO,
            localId: (0, oO.d)()
          }
        }), {
          rereads: OO => "roster" !== OO.kind || OO.members || OO.settings.has("ranks"),
          followLocalId: !0
        }),
        lobbyLeaderboardRows: bX((function() {
          const OO = {};
          for (const bK of FO.g.ids()) {
            var KO, pO, XO;
            OO[bK] = {
              colour: null !== (KO = FO.g.getSetting(bK, "colorInLobbyLeaderboard")) && void 0 !== KO ? KO : null,
              values: null !== (pO = FO.g.getSetting(bK, "lobbyLeaderboardValues")) && void 0 !== pO ? pO : null,
              tags: null !== (XO = FO.g.getSetting(bK, "lobbyLeaderboardTags")) && void 0 !== XO ? XO : null
            }
          }
          return OO
        }), {
          rereads: function(OO) {
            if ("roster" !== OO.kind) return "reset" === OO.kind;
            const {
              members: KO,
              settings: pO
            } = OO;
            return KO || pO.has("colorInLobbyLeaderboard") || pO.has("lobbyLeaderboardValues") || pO.has("lobbyLeaderboardTags")
          },
          followLocalId: !1
        })
      },
      lp = {
        cosmeticsUpdated: {
          watch: OO => (0, FO.e)((KO => {
            if ("cosmetics" !== KO.kind) return;
            const pO = (0, oO.d)();
            OO(KO.updates.map((OO => {
              let {
                EW: KO,
                oV: XO,
                VV: bK
              } = OO;
              return {
                local: KO === pO,
                oV: XO,
                VV: bK
              }
            })))
          }))
        }
      };
    var vX = pO(2302),
      Cp = pO(1481),
      hp = pO(959),
      Dp = pO(38800);
    let Mp = !1,
      aX = null;
    const op = {
      setShopOpen(OO) {
        var KO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.ShopMenuChanged, (0, wO.J)(OO))
      },
      buyShopItem(OO) {
        var KO;
        let {
          categoryKey: pO,
          itemKey: XO,
          userInput: bK
        } = OO;
        null === (KO = (0, lO.g)()) || void 0 === KO || KO.send(wO.b.ItemBought, {
          categoryKey: pO,
          itemKey: XO,
          shopVersion: AO.c.get("_shopVersion"),
          userInput: bK
        })
      }
    };
    let Fp = !1;
    var Vp = pO(3962);
    const Lp = oK.u.LookFrozen | oK.u.ClicksSuppressed;

    function Qp(OO, KO) {
      var pO;
      null !== (pO = (0, lO.g)()) && void 0 !== pO && pO.send(OO, KO) || console.warn(`[bloxd-wasm-client] message ${OO} not sent: no live game or the core's command ring is full`)
    }(0, VO.n)(YO.gb, (OO => {
      const KO = (0, iK.d)(YO.gb, OO);
      void 0 !== KO && hO.i.pl("setDiscordReportKey", KO)
    }));
    const zX = {
      ignorePlayer(OO) {
        Qp(wO.b.IgnoreUser, (0, wO.x)({
          sH: OO
        }))
      },
      reportPlayer(OO) {
        let {
          playerId: KO,
          chatMsgId: pO,
          LX: XO,
          details: bK
        } = OO;
        Qp(wO.b.UserReport, (0, wO.db)({
          WG: KO,
          lq: pO,
          LX: XO,
          Ur: bK
        }))
      },
      reportWorldCodeChat(OO) {
        let {
          chatMsgId: KO,
          LX: pO,
          details: XO
        } = OO;
        Qp(wO.b.UserReport, (0, wO.db)({
          WG: "",
          lq: KO,
          LX: pO,
          Ur: XO
        }))
      },
      requestDiscordReportKey(OO) {
        Qp(wO.b.ReqDiscordReportKey, (0, wO.D)(OO))
      },
      reportLobbyOrGame(OO) {
        let {
          target: KO,
          LX: pO,
          details: XO
        } = OO;
        "customGame" === KO ? Qp(wO.b.CustomGameReport, (0, wO.p)({
          LX: pO,
          Ur: XO
        })) : Qp(wO.b.LobbyReport, (0, wO.y)({
          LX: pO,
          Ur: XO
        }))
      },
      updateMyCosmetic(OO) {
        Qp(wO.b.UpdateMyCosmetic, (0, wO.$)(OO))
      },
      holdEmoteWheel(OO) {
        !OO || VK ? (0, Vp.j)(Lp, OO ? Lp : 0) : hO.i.pl("requestEmoteWheelHoldRelease")
      }
    };
    var Ap = pO(38803),
      fp = pO(1561),
      dp = pO(38805);

    function Tp() {
      const OO = (0, lO.g)();
      return !0 === (null === OO || void 0 === OO ? void 0 : OO.isCoreRunning) ? function(OO) {
        if (OO.queries.drawCensus() < fO.rb.BYTES) return [];
        const KO = OO.memoryData(OO.scratch(), fO.rb.BYTES, 4, "the draw census");
        if (null === KO) return [];
        const pO = fO.rb.terrainOpaque(KO, 0),
          XO = fO.rb.terrainTransparent(KO, 0),
          bK = fO.rb.earthSky(KO, 0),
          eO = fO.rb.skyMeshes(KO, 0),
          lO = fO.rb.regular(KO, 0),
          vK = fO.rb.thin(KO, 0),
          CO = fO.rb.line(KO, 0),
          hO = fO.rb.text(KO, 0),
          DO = fO.rb.particles(KO, 0);
        return [{
          label: "Drawn",
          value: `${pO+XO+bK+eO+lO+vK+CO+hO+DO}`
        }, {
          label: "Terrain",
          value: `${pO} opaque / ${XO} transparent (${fO.rb.terrainPack(KO,0)} shader pack)`
        }, {
          label: "Meshes / Thin bases",
          value: `${lO} / ${vK}`
        }, {
          label: "Text / Lines",
          value: `${hO} / ${CO}`
        }, {
          label: "Sky / Particles",
          value: `${bK+eO} / ${DO}`
        }]
      }(OO.api) : []
    }
    var Np = pO(38812);
    var Ip = pO(518),
      yX = pO(37833);

    function gX(OO) {
      if (null === OO || void 0 === OO || !OO.isCoreRunning) return null;
      const {
        api: KO,
        chunks: pO,
        items: XO,
        tables: bK
      } = OO;
      return {
        playerFeet() {
          const OO = KO.fV(KO.localId);
          return null !== OO && void 0 !== OO && OO.every(Number.isFinite) ? OO : null
        },
        chunkBlocks: OO => pO.isLoaded(OO[0], OO[1], OO[2]) ? (OO, KO, XO) => pO.yl(OO, KO, XO) : null,
        blockName: OO => bK.nameOfId(OO),
        inventory: () => ({
          slots: XO.playerItems().map((OO => OO ? {
            name: OO.name,
            amount: OO.amount
          } : null)),
          heldSlot: XO.selectedSlot
        }),
        nearby() {
          const pO = [];
          for (let bK = 0; bK < KO.idStr.length; bK++) {
            var XO;
            const eO = KO.idStr[bK],
              lO = KO.serverIds[bK],
              vK = KO.kinds[bK];
            if (null === eO || KO.isLocal(lO) || vK >>> fO.e !== fO.r.Lifeform) continue;
            const CO = KO.fV(lO),
              hO = Ip.h[vK & fO.h];
            CO && void 0 !== hO && pO.push({
              kind: "Player" === hO ? "player" : hO,
              name: null !== (XO = OO.clientApi.getEntityName(eO)) && void 0 !== XO ? XO : null,
              position: CO
            })
          }
          return pO
        },
        droppedItems() {
          let OO = 0;
          for (let pO = 0; pO < KO.idStr.length; pO++) null !== KO.idStr[pO] && KO.kinds[pO] >>> fO.e === fO.r.Item && OO++;
          return OO
        }
      }
    }
    const upO = {
        worldCodeAiChunk: OO => Promise.resolve((0, yX.d)(gX((0, lO.g)()), OO)),
        worldCodeAiGameState: () => Promise.resolve((0, yX.e)(gX((0, lO.g)())))
      },
      Ep = function(OO) {
        const KO = pp(),
          XO = pp(),
          bK = new Set,
          eO = new Set,
          lO = () => {
            var KO, pO;
            return null !== (KO = null === (pO = OO.runtime()) || void 0 === pO ? void 0 : pO.currentViewer) && void 0 !== KO ? KO : null
          };
        let vK = null,
          CO = null;
        const DO = (OO, KO) => ({
            current: OO,
            watch(pO) {
              let XO = OO();
              return KO.add((() => {
                const KO = OO();
                KO !== XO && (XO = KO, pO(KO))
              }))
            }
          }),
          aK = OO => ({
            watch: KO => (OO.add(KO), () => {
              OO.delete(KO)
            })
          }),
          oO = OO => {
            const KO = lO(),
              pO = null === KO || void 0 === KO ? void 0 : KO.view;
            KO && pO && KO.seek(Math.max(0, Math.min(pO.totalTicks - 1, pO.KK + OO * MO.md)))
          },
          FO = {
            replay: DO((() => {
              var OO;
              const KO = lO(),
                pO = null !== (OO = null === KO || void 0 === KO ? void 0 : KO.view) && void 0 !== OO ? OO : null;
              return null === KO || null === pO || pO.state === MO.cd.None ? (vK = null, null) : (vK = (0, ZO.p)(vK, {
                id: KO.id,
                KK: pO.KK,
                totalTicks: pO.totalTicks,
                RKO: MO.md,
                playing: pO.state === MO.cd.Playing,
                speed: pO.speed,
                cameraMode: pO.cameraMode,
                freecam: "freecam" === pO.cameraMode
              }), vK)
            }), KO),
            replayEdits: DO((() => {
              var OO;
              const KO = lO(),
                pO = null !== (OO = null === KO || void 0 === KO ? void 0 : KO.view) && void 0 !== OO ? OO : null;
              return null === KO || null === pO || pO.state === MO.cd.None ? (CO = null, null) : (CO = (0, ZO.p)(CO, {
                cameraKeyframes: [...KO.keyframes],
                playbackMark: pO.mark,
                fileName: KO.fileName,
                unsavedChanges: KO.unsavedChanges,
                suggestSaveAs: KO.suggestSaveAs
              }), CO)
            }), KO),
            replayRecorder: DO((() => {
              var KO, pO;
              return null !== (KO = null === (pO = OO.runtime()) || void 0 === pO ? void 0 : pO.recorder.current) && void 0 !== KO ? KO : UK.c.states.replayRecorder.current()
            }), XO),
            replayVideoExporting: {
              current: tp.c,
              watch: OO => (0, hO.j)("replayViewer|videoExportChanged", (() => {
                OO((0, tp.c)())
              }))
            }
          },
          VO = {
            replayUiActionRequested: aK(eO),
            replayViewerRequested: aK(bK)
          },
          LO = OO => {
            for (const KO of bK) KO(OO)
          },
          QO = () => {
            var XO;
            !0 === (null === (XO = lO()) || void 0 === XO ? void 0 : XO.isOpen) && Promise.all([pO.e(83), pO.e(58)]).then((() => pO(40648))).then((pO => {
              let {
                startWasmReplayVideoExport: XO
              } = pO;
              return XO({
                viewer: lO,
                canvas: () => {
                  var KO, pO;
                  return null !== (KO = null === (pO = OO.canvas) || void 0 === pO ? void 0 : pO.call(OO)) && void 0 !== KO ? KO : null
                },
                watchViewer: KO.add,
                requestViewer: LO
              })
            }), (OO => {
              console.error("Couldn't load the video export", OO), kp.NotificationProvider.showAlertPopup({
                title: "Video export failed",
                subtitle: "Check your connection, then try again."
              })
            })).catch((OO => {
              console.error("The video export failed", OO)
            }))
          },
          zK = {
            replayAction(OO) {
              if ((0, tp.c)()) return;
              const KO = lO();
              switch (OO) {
                case "replaySkipBack":
                  oO(-1);
                  break;
                case "replaySkipForward":
                  oO(1);
                  break;
                case "replaySpeedUp":
                case "replaySpeedDown":
                  null !== KO && void 0 !== KO && KO.view && KO.setSpeed((0, WK.e)(KO.view.speed, "replaySpeedUp" === OO ? "up" : "down"));
                  break;
                case "replayRecordKeyframe":
                  null === KO || void 0 === KO || KO.addKeyframe()
              }
            },
            setReplayPlaying(OO) {
              var KO, pO;
              (0, tp.c)() || (OO ? null === (KO = lO()) || void 0 === KO || KO.play() : null === (pO = lO()) || void 0 === pO || pO.pause())
            },
            seekReplay(OO) {
              var KO;
              let {
                KK: pO,
                ignorePlaybackMark: XO
              } = OO;
              null === (KO = lO()) || void 0 === KO || KO.seek(pO, null !== XO && void 0 !== XO && XO)
            },
            setReplayCameraMode(OO) {
              var KO;
              null === (KO = lO()) || void 0 === KO || KO.setCameraMode(OO)
            },
            syncReplayCameraMode() {},
            setReplayCameraKeyframe(OO) {
              var KO;
              null === (KO = lO()) || void 0 === KO || KO.setKeyframe(OO)
            },
            moveReplayCameraKeyframe(OO) {
              var KO;
              let {
                from: pO,
                to: XO
              } = OO;
              null === (KO = lO()) || void 0 === KO || KO.moveKeyframe(pO, XO)
            },
            deleteReplayCameraKeyframes(OO) {
              var KO;
              let {
                start: pO,
                end: XO
              } = OO;
              null === (KO = lO()) || void 0 === KO || KO.deleteKeyframes(pO, XO)
            },
            setReplayPlaybackMark(OO) {
              var KO;
              null === (KO = lO()) || void 0 === KO || KO.setMark(OO)
            },
            cropReplay(OO) {
              var KO, pO;
              let {
                start: XO,
                end: bK
              } = OO;
              return !(0, tp.c)() && (null !== (KO = null === (pO = lO()) || void 0 === pO ? void 0 : pO.crop(XO, bK)) && void 0 !== KO && KO)
            },
            holdReplayForShaderPackFailure(OO) {
              const KO = lO();
              KO && (KO.holdForShaderPackFailure(), function(OO) {
                pO.e(122).then((() => pO(37568))).then((KO => {
                  let {
                    shaderPackPage: pO
                  } = KO;
                  pO.block(OO)
                })).catch((OO => {
                  console.warn("[bloxd-wasm-client] the shader pack could not be blocked", OO)
                }))
              }(OO))
            },
            exportReplayVideo() {
              QO()
            },
            toggleRecording() {
              var KO;
              null === (KO = OO.runtime()) || void 0 === KO || KO.recorder.toggleRecording()
            },
            saveClip() {
              var KO;
              null === (KO = OO.runtime()) || void 0 === KO || KO.recorder.saveClip()
            },
            setRecorderPrefs(KO) {
              var pO;
              let {
                clipping: XO,
                clipSeconds: bK
              } = KO;
              null === (pO = OO.runtime()) || void 0 === pO || pO.recorder.setPrefs(XO, bK)
            },
            setReplayViewerOpen(KO) {
              var pO;
              (0, DK.e)(KO) && (null === (pO = OO.runtime()) || void 0 === pO || pO.recorder.viewerShown(KO))
            },
            recordFlyingMiddleText(KO) {
              var pO;
              let {
                content: XO,
                ROO: bK,
                angle: eO,
                SOO: lO
              } = KO;
              null === (pO = OO.runtime()) || void 0 === pO || pO.recorder.recordFlyingText(JSON.stringify(XO), bK, eO, lO)
            },
            dragReplayCamera(KO) {
              var pO;
              let {
                dx: XO,
                dy: bK
              } = KO;
              null === (pO = OO.freecam()) || void 0 === pO || pO.drag(XO, bK)
            },
            moveReplayFreecam(KO) {
              var pO;
              null === (pO = OO.freecam()) || void 0 === pO || pO.move(KO)
            },
            holdReplayFreecamVertical(KO) {
              var pO;
              let {
                action: XO,
                JK: bK
              } = KO;
              null === (pO = OO.freecam()) || void 0 === pO || pO.holdVertical(XO, bK)
            }
          },
          AO = OO => {
            var KO;
            const pO = lO(),
              XO = null !== (KO = null === pO || void 0 === pO ? void 0 : pO.view) && void 0 !== KO ? KO : null;
            Op.has(OO) ? (OO => {
              for (const KO of eO) KO(OO)
            })(OO) : Kp.has(OO) ? zK.replayAction(OO) : "replayPlayPause" === OO ? pO && XO && XO.state !== MO.cd.None && zK.setReplayPlaying(XO.state !== MO.cd.Playing) : "replayChangeCameraMode" === OO ? null === pO || void 0 === pO || pO.cycleCameraMode() : "replayExit" === OO ? !0 === (null === pO || void 0 === pO ? void 0 : pO.inPlayback) && (0, uK.n)("/") : "replayExportVideo" === OO && QO()
          };
        let fO = !1;
        return {
          states: FO,
          events: VO,
          commands: zK,
          lookups: {
            replayCamera() {
              var KO, pO, XO;
              return !0 !== (null === (KO = lO()) || void 0 === KO ? void 0 : KO.isOpen) ? null : null !== (pO = null === (XO = OO.cameraView) || void 0 === XO ? void 0 : XO.call(OO)) && void 0 !== pO ? pO : null
            },
            leaveGameReloadsPage() {
              var OO;
              return !0 === (null === (OO = lO()) || void 0 === OO ? void 0 : OO.inPlayback)
            }
          },
          feed: {
            viewerChanged: () => {
              var OO;
              const pO = !0 === (null === (OO = lO()) || void 0 === OO ? void 0 : OO.inPlayback);
              pO !== fO && (fO = pO, hO.i.pl("connectedGameChanged")), KO.fire()
            },
            recorderChanged: XO.fire,
            keyDown: OO => {
              var KO;
              switch (OO) {
                case "recordGame":
                  return void zK.toggleRecording();
                case "recordClip":
                  return void((0, DK.c)() || zK.saveClip())
              }(0, tp.c)() || ("replayViewerOpen" !== OO ? OO.startsWith("replay") && ((0, DK.c)() || !0 === (null === (KO = lO()) || void 0 === KO ? void 0 : KO.inPlayback)) && AO(OO) : LO("toggle"))
            }
          }
        }
      }({
        runtime: bK.h,
        cameraView: () => {
          var OO;
          const KO = null === (OO = (0, lO.g)()) || void 0 === OO ? void 0 : OO.renderFrame;
          if (!KO) return null;
          const [pO, XO, bK] = KO.cameraPosition, [eO, vK, CO] = KO.cameraDirection;
          return {
            position: [pO, XO, bK],
            direction: [eO, vK, CO]
          }
        },
        canvas: () => {
          var OO, KO, pO;
          return null !== (OO = null === (KO = (pO = (0, eO.F)()).canvas) || void 0 === KO ? void 0 : KO.call(pO)) && void 0 !== OO ? OO : null
        },
        freecam: bK.f
      }),
      jX = {
        states: {
          ...XK,
          ...vp.g,
          ...Ep.states,
          ...ep
        },
        events: {
          ...bp,
          ...LO,
          ...vp.e,
          ...gK.e,
          ...Ap.i,
          ...Ep.events,
          ...lp,
          ...yK.j
        },
        commands: {
          ...IO,
          ...eK,
          ...QO,
          ...vp.b,
          ...cp,
          ...zX,
          ...yK.f,
          ...YK,
          ...Ep.commands,
          ...op
        },
        queries: {
          ...vp.f,
          ...upO
        },
        lookups: {
          ...lK,
          ...PO,
          ...Ap.k,
          ...Ep.lookups,
          ...NO,
          ...nK
        }
      };

    function Yp() {
      (0, vK.h)(VO.q), (0, bK.l)(Ep.feed), (0, gK.i)(), BK || (BK = !0, (0, VO.n)(YO.l, (OO => {
        const KO = (0, iK.d)(YO.l, OO);
        "string" === typeof KO && Promise.resolve().then((() => pO(2905))).then((OO => {
          let {
            onCosmeticPackGranted: pO
          } = OO;
          pO(KO)
        }))
      })), (0, VO.n)(YO.bb, (OO => {
        const KO = (0, iK.d)(YO.bb, OO);
        "number" === typeof KO && hO.i.pl("serverUpdating", Date.now() + KO, !0)
      })), (0, VO.n)(YO.H, (OO => {
        const KO = (0, iK.d)(YO.H, OO);
        if ((0, iK.b)(KO)) {
          const {
            pOO: OO,
            XOO: pO
          } = KO;
          (0, SK.d)({
            pOO: "string" === typeof OO ? OO : null,
            XOO: "string" === typeof pO ? pO : null
          })
        }
      })), (0, VO.n)(DO.Hb.NewUiRequest, (OO => {
        const KO = (0, iK.g)(OO);
        (0, iK.b)(KO) && "number" === typeof KO.id && (0, iK.b)(KO.clientParameters) && (0, JK.e)(KO.id, KO.clientParameters)
      })), (0, VO.n)(YO.Y, (OO => {
        const KO = (0, iK.d)(YO.Y, OO);
        "number" === typeof KO && (0, JK.i)(KO)
      })), (0, VO.k)(JK.d), (0, VO.n)(DO.Hb.UiRequestPopup, (OO => {
        const KO = (0, iK.g)(OO);
        if ((0, iK.b)(KO) && "number" === typeof KO.id && "string" === typeof KO.text) {
          const OO = KO.id;
          (0, JK.m)(OO, KO.text, (KO => {
            cp.answerUiRequest({
              id: OO,
              lV: KO
            })
          }))
        }
      })), (0, VO.n)(DO.Hb.TopRightHelper, (OO => {
        const KO = (0, iK.g)(OO);
        void 0 !== KO && hO.i.pl("TopRightHelper", KO, !0)
      })), (0, VO.n)(DO.Hb.TaskProgress, (OO => {
        const KO = (0, iK.g)(OO);
        (0, iK.b)(KO) && "string" === typeof KO.taskId && "number" === typeof KO.progress && (0, RK.e)({
          taskId: KO.taskId,
          progress: KO.progress
        })
      }))), Fp || (Fp = !0, (0, VO.n)(YO.s, (OO => {
        const KO = (0, iK.d)(YO.s, OO);
        (0, iK.b)(KO) && hO.i.pl("showShopFromServer", {
          toggle: KO.pW,
          DW: KO.DW
        }, !0)
      })), (0, VO.n)(DO.Hb.OverShopInfo, (OO => {
        const KO = (0, iK.g)(OO);
        (0, iK.b)(KO) && hO.i.pl("overShopInfo", KO.info, !0)
      })), (0, VO.n)(DO.Hb.ShowShopTutorial, (() => {
        hO.i.pl("showShopTutorial", null, !0)
      }))), Mp || (Mp = !0, (0, VO.g)((() => {
        var OO;
        (0, vX.z)(), null === (OO = aX) || void 0 === OO || OO(), aX = (0, VO.e)() ? (0, hp.c)(VO.e) : null
      })), (0, VO.n)(DO.Hb.SetCookie, (OO => {
        const KO = (0, iK.g)(OO),
          pO = (0, uK.b)().gameNameWithVariation;
        (0, iK.b)(KO) && "string" === typeof KO.key && null !== pO && (0, Cp.setCookie)(pO, KO.key, KO.value)
      })), (0, VO.n)(DO.Hb.LeaveValues, (OO => {
        const KO = (0, iK.g)(OO);
        if ((0, iK.b)(KO) && "string" === typeof KO.leaveEventType) {
          const {
            leaveEventType: OO,
            category: pO,
            subCategory: XO,
            value: bK
          } = KO;
          (0, vX.H)({
            leaveEventType: OO,
            category: pO,
            subCategory: XO,
            value: bK
          })
        }
      })), (0, VO.n)(DO.Hb.CustomAnalyticsEvent, (OO => {
        const KO = (0, iK.g)(OO);
        if ((0, iK.b)(KO) && "string" === typeof KO.cat1) {
          const {
            cat1: OO,
            cat2: pO,
            cat3: XO,
            value: bK
          } = KO;
          (0, vX.s)({
            cat1: OO,
            cat2: pO,
            cat3: XO,
            value: bK
          })
        }
      })), (0, VO.n)(DO.Hb.ProgressionEvent, (OO => {
        const KO = (0, iK.g)(OO);
        if ((0, iK.b)(KO)) {
          const {
            type: OO,
            location1: pO,
            location2: XO,
            location3: bK,
            score: eO
          } = KO;
          (0, vX.u)({
            type: OO,
            location1: pO,
            location2: XO,
            location3: bK,
            score: eO
          })
        }
      })), (0, VO.n)(DO.Hb.ResourceEvent, (OO => {
        const KO = (0, iK.g)(OO);
        if ((0, iK.b)(KO)) {
          const {
            type: OO,
            resourceType: pO,
            amount: XO,
            category: bK,
            itemName: eO
          } = KO;
          (0, vX.w)({
            type: OO,
            resourceType: pO,
            amount: XO,
            category: bK,
            itemName: eO
          })
        }
      })), (0, VO.n)(DO.Hb.LeaderboardResponse, (OO => {
        const KO = (0, iK.g)(OO);
        if ((0, iK.b)(KO)) {
          const {
            category: OO,
            timeframe: pO,
            data: XO
          } = KO;
          hO.i.pl("leaderboardResponse", {
            category: OO,
            timeframe: pO,
            data: XO
          })
        }
      })), (0, VO.n)(YO.A, (OO => {
        const KO = (0, iK.d)(YO.A, OO);
        "string" === typeof KO && (0, Dp.b)(OO.conn, KO)
      })), (0, VO.n)(YO.D, (OO => {
        const KO = (0, iK.d)(YO.D, OO);
        "string" === typeof KO && console.error(`[logErrorToConsole]: ${KO}`)
      }))), sO(), (0, Ap.c)(), jp || (jp = !0, (0, VO.n)(YO.i, (OO => {
        const KO = (0, iK.d)(YO.i, OO);
        void 0 !== KO && (0, EK.g)(KO)
      }))), HK(), TK(), SO || (SO = !0, (0, eO.u)(JO)), XO.gameBridge.attach(jX), (0, XO.installPageSources)({
        commands: {
          ...XO.DEFAULT_CLIENT_PAGE_SOURCES.commands,
          setChunkAddDistance: dp.k
        },
        queries: Np.wasmIconQueries,
        lookups: {
          ...XO.DEFAULT_CLIENT_PAGE_SOURCES.lookups,
          ...Np.wasmIconLookups,
          RV: dp.e,
          drawCallStats: Tp
        }
      }), (0, fp.d)(), (0, Np.loadIcons)()
    }
  },
  38805: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      h: () => eO,
      k: () => vK
    });
    let XO = null,
      bK = null;

    function eO(OO, KO) {
      return XO = OO, bK = null, vK(KO), () => {
        XO === OO && (XO = null, bK = null)
      }
    }

    function lO() {
      return null === bK ? null : {
        ...bK
      }
    }

    function vK(OO) {
      var KO;
      null !== (KO = XO) && void 0 !== KO && KO(OO) && (bK = {
        ...OO
      })
    }
  },
  38800: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => bK,
      c: () => eO
    });
    let XO = null;

    function bK(OO, KO) {
      XO = {
        conn: OO,
        reason: KO
      }
    }

    function eO(OO) {
      var KO;
      const pO = (null === (KO = XO) || void 0 === KO ? void 0 : KO.conn) === OO ? XO.reason : null;
      return XO = null, pO
    }
  },
  38771: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => bK
    });
    let XO = {
      fire: () => {},
      close: () => {}
    };

    function bK(OO) {
      XO = OO
    }

    function eO() {
      return XO
    }
  },
  38828: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => vK
    });
    var XO = pO(38831);
    let bK = null,
      eO = null;

    function lO() {
      return bK ??= pO.e(53).then((() => pO(40661))).catch((OO => {
        throw bK = null, OO
      })), bK
    }

    function vK() {
      return eO ??= Promise.all([lO(), (0, XO.g)()]).then((OO => {
        let [KO] = OO;
        return KO
      }), (OO => {
        throw eO = null, OO
      })), eO
    }
  },
  35526: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    const XO = {
      "skyblock:forged:astral-astral-astral": {
        name: "Heart of the Cosmos",
        lore: "Three shards of the night sky, forged as one. The stars answer whoever holds it.",
        damageMultiplier: 1.8,
        cooldownMultiplier: .8,
        ability: "starfall"
      },
      "skyblock:forged:astral-moonstone-sanguine": {
        name: "Eclipse Edge",
        lore: "Moonlight over starlight over blood: the sky goes dark wherever it is drawn.",
        damageMultiplier: 1.7,
        cooldownMultiplier: .81,
        ability: "eclipseField"
      },
      "skyblock:forged:astral-diamond-moonstone": {
        name: "Starcutter",
        lore: "A blade so sharp the Forge Mother swears it once cut a falling star in two.",
        damageMultiplier: 1.65,
        cooldownMultiplier: .83,
        ability: "starfall"
      },
      "skyblock:forged:astral-sanguine-magmasteel": {
        name: "Triune Flame",
        lore: "Each of Lord Vulcan's three faces, bound into one burning edge.",
        damageMultiplier: 1.65,
        cooldownMultiplier: .83,
        ability: "magmaWave"
      },
      "skyblock:forged:magmasteel-magmasteel-magmasteel": {
        name: "Vulcan's Bane",
        lore: "Forged in the heat of his own rift. It remembers the way down.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "magmaWave"
      },
      "skyblock:forged:magmasteel-astral-sanguine": {
        name: "Comet's Wake",
        lore: "It leaves a trail of fire through the air, like something falling from very far up.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "starfall"
      },
      "skyblock:forged:magmasteel-sanguine-astral": {
        name: "Vulcan's Ruin",
        lore: "The Forge Mother made only one, then sat down for a long while.",
        damageMultiplier: 1.6,
        cooldownMultiplier: .83,
        ability: "warcry"
      },
      "skyblock:forged:magmasteel-iron-stone": {
        name: "Forgehand",
        lore: "A smith's sword: plain to look at, and it hits like a hammer.",
        damageMultiplier: 1.4,
        cooldownMultiplier: .9,
        ability: "quake"
      },
      "skyblock:forged:sanguine-sanguine-sanguine": {
        name: "Crimson Covenant",
        lore: "It drinks, and so do you.",
        damageMultiplier: 1.53,
        cooldownMultiplier: .83,
        ability: "bloodPact"
      },
      "skyblock:forged:sanguine-astral-moonstone": {
        name: "Nightbloom",
        lore: "A red flower that only opens after dark.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "eclipseField"
      },
      "skyblock:forged:sanguine-iron-wood": {
        name: "Butcher's Oath",
        lore: "Heavy, honest and always hungry.",
        damageMultiplier: 1.35,
        cooldownMultiplier: .95,
        ability: "bloodPact"
      },
      "skyblock:forged:moonstone-moonstone-moonstone": {
        name: "Lunar Requiem",
        lore: "Swung, it leaves a pale arc that lingers like a second moon.",
        damageMultiplier: 1.35,
        cooldownMultiplier: .85,
        ability: "moonDash"
      },
      "skyblock:forged:moonstone-astral-moonstone": {
        name: "Silver Tide",
        lore: "Pulled by the same moon that pulls the sea.",
        damageMultiplier: 1.4,
        cooldownMultiplier: .84,
        ability: "moonDash"
      },
      "skyblock:forged:diamond-diamond-diamond": {
        name: "Prism Fang",
        lore: "Every facet catches a different light, and every strike finds a different weakness.",
        damageMultiplier: 1.29,
        cooldownMultiplier: .88,
        ability: "gildedEdge",
        traits: {
          crit: 1.8
        }
      },
      "skyblock:forged:diamond-moonstone-gold": {
        name: "Jeweller's Pride",
        lore: "Too pretty to fight with. Fight with it anyway.",
        damageMultiplier: 1.24,
        cooldownMultiplier: .91,
        ability: "gildedEdge"
      },
      "skyblock:forged:gold-gold-gold": {
        name: "King's Ransom",
        lore: "Worth more than the treasure it guards.",
        damageMultiplier: 1.18,
        cooldownMultiplier: .91,
        ability: "gildedEdge",
        traits: {
          coins: 2.5
        }
      },
      "skyblock:forged:gold-moonstone-gold": {
        name: "Midas Moon",
        lore: "Mobs it fells seem to rattle with coins.",
        damageMultiplier: 1.18,
        cooldownMultiplier: .92,
        ability: "gildedEdge",
        traits: {
          coins: 2,
          bossBane: .6
        }
      },
      "skyblock:forged:iron-iron-iron": {
        name: "Old Faithful",
        lore: "It has never let anyone down. It never will.",
        damageMultiplier: 1.15,
        cooldownMultiplier: .94,
        ability: "warcry"
      },
      "skyblock:forged:iron-wood-wood": {
        name: "Militia Blade",
        lore: "Handed out at the outpost gate when the rift first opened.",
        damageMultiplier: 1.09,
        cooldownMultiplier: .97,
        ability: "warcry"
      },
      "skyblock:forged:stone-stone-stone": {
        name: "Quarryman's Cleaver",
        lore: "Chipped from one block of stone, handle and all.",
        damageMultiplier: 1.09,
        cooldownMultiplier: .97,
        ability: "quake"
      },
      "skyblock:forged:wood-wood-wood": {
        name: "Lorenzo's Lesson",
        lore: "Courage matters more than the blade. This one is mostly courage.",
        damageMultiplier: 1.06,
        cooldownMultiplier: .97,
        ability: "warcry"
      }
    }
  },
  37419: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO,
      c: () => bK
    });
    const XO = ["description", "label"];

    function bK(OO) {
      const KO = OO.type;
      return {
        type: KO,
        params: OO[KO]
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);