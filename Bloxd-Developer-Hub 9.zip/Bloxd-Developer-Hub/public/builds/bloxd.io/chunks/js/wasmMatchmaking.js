/*! For license information please see vjxd5n.wasmMatchmaking.dda8d46c.chunk.js.LICENSE.txt */
export const id = 54;
export const ids = [54];
export const modules = {
  5800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    var XO = pO(36);
    const bK = "shaderPack";
    async function eO() {
      var OO;
      let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return null !== (OO = await XO.d.getItem(bK, KO)) && void 0 !== OO ? OO : null
    }
  },
  34995: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      InGameUi: () => FO.e,
      LobbyLeaderboard: () => VO.b,
      loadCharacterCustomisationUI: () => LO,
      loadCharacterPreview: () => QO,
      matchmakeAndPlay: () => fO,
      setUpGame: () => zK
    });
    var XO = pO(1104),
      bK = pO(149),
      eO = pO(35e3),
      lO = pO(35008),
      vK = pO(1569),
      CO = pO(35017);

    function hO() {
      return !1 !== vK.c.get("canCustomiseChar")
    }
    let DO = !1;
    var MO = pO(1163),
      aK = pO(2831),
      oO = pO(7961);
    var FO = pO(35025),
      VO = pO(35477);

    function LO() {
      return Promise.all([pO.e(269), pO.e(375)]).then((() => pO(39217)))
    }

    function QO() {
      return pO.e(270).then((() => pO(39219)))
    }

    function zK() {
      return (0, oO.d)()
    }
    DO || (DO = !0, document.addEventListener("keydown", (OO => {
        (0, CO.d)(OO, hO)
      }))),
      function(OO) {
        var KO;
        return !0 !== (null === OO || void 0 === OO ? void 0 : OO.saveData) && !/2g$/.test(null !== (KO = null === OO || void 0 === OO ? void 0 : OO.effectiveType) && void 0 !== KO ? KO : "")
      }(navigator.connection) && (0, aK.d)((() => {
        (0, oO.h)() || Promise.all([pO.e(127), pO.e(126), pO.e(50)]).then((() => pO(38833))).then((OO => {
          let {
            prefetchWasmClient: KO
          } = OO;
          return KO(oO.h)
        }), (OO => {
          console.warn("[bloxd-wasm-client] the prefetch did not load: the join downloads the client itself", OO)
        }))
      })), (0, eO.b)();
    const AO = (0, lO.e)((async function(OO, KO) {
      let {
        place: pO,
        userContext: eO,
        direct: lO,
        rematch: vK
      } = OO;
      const CO = lO ? 1 / 0 : performance.now();
      let hO;
      try {
        hO = await (0, oO.c)()
      } catch (DO) {
        return console.error("The wasm client did not load:", DO), (0, MO.q)({
          websocketUrl: null
        }), XO.c.errorWithCode(String(DO), bK.f.CONNECT_TO_GAME_SERVER, {
          error: DO,
          severity: KO.aborted ? "low" : "medium",
          dl: KO.aborted
        })
      }
      return hO.playWasmGame({
        userContext: eO,
        place: pO,
        matchedAt: CO,
        rematch: vK
      }, KO)
    }));

    function fO() {
      return (0, oO.c)().catch((() => {})), AO(...arguments)
    }
  },
  7961: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      d: () => CO,
      h: () => vK
    });
    var XO = pO(2446);
    let bK = null,
      eO = !1;

    function lO() {
      return eO = !0, Promise.all([pO.e(62), pO.e(65), pO.e(63), pO.e(64), pO.e(75), pO.e(74), pO.e(229), pO.e(201), pO.e(226), pO.e(227), pO.e(42)]).then((() => pO(38766))).catch((() => {})), Promise.all([pO.e(127), pO.e(126), pO.e(50)]).then((() => pO(38833))).then((OO => {
        let {
          startJoinLoad: KO
        } = OO;
        KO()
      }), (() => {})), bK ??= Promise.all([pO.e(64), pO.e(127), pO.e(75), pO.e(122), pO.e(107), pO.e(126), pO.e(178), pO.e(76), pO.e(227), pO.e(55)]).then((() => pO(38900))).then((OO => (OO.startWasmPlay(), OO.followPageUiPack((OO => {
        XO.c.showGamePack(OO)
      })), OO)), (OO => {
        throw bK = null, OO
      })), bK
    }

    function vK() {
      return eO
    }

    function CO() {
      return Promise.all([pO.e(64), pO.e(127), pO.e(75), pO.e(122), pO.e(107), pO.e(126), pO.e(178), pO.e(76), pO.e(227), pO.e(55)]).then((() => pO(38900))).then((OO => {
        OO.startWasmPreviews(), OO.prefetchWasmPreviews()
      }))
    }
  },
  35411: (OO, KO, pO) => {
    function XO(OO) {
      return OO.includes("Leaf Bed")
    }

    function bK(OO) {
      return / Bed(?: Head)?(?:\||$)/.test(OO) && !XO(OO)
    }

    function eO(OO) {
      return OO.includes(" Strongbed")
    }

    function lO(OO) {
      return XO(OO) || bK(OO) || eO(OO)
    }
    pO.d(KO, {
      c: () => lO,
      g: () => XO,
      k: () => eO,
      l: () => bK
    })
  },
  35409: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => hO
    });
    var XO = pO(35411),
      bK = pO(8365);
    const eO = [],
      lO = [],
      vK = [],
      CO = [];
    for (const DO of Object.keys(bK.r))(0, XO.g)(DO) ? eO.push(DO) : (0, XO.l)(DO) && lO.push(DO), (0, XO.k)(DO) && vK.push(DO), (DO.includes(" Bed Head") || DO.includes(" Strongbed Head")) && CO.push(DO);
    const hO = {
      leafBeds: eO,
      woolBeds: lO,
      strongBeds: vK,
      beds: [...eO, ...lO, ...vK],
      bedHeads: CO,
      blockRemoveActionRoots: ["Chest", "Loot Chest", "Iron Chest", "Mailbox", "Bookshelf", "Empty Bookshelf"]
    }
  },
  35228: OO => {
    OO.exports = function OO(KO, pO) {
      if (KO === pO) return !0;
      if (KO && pO && "object" == typeof KO && "object" == typeof pO) {
        if (KO.constructor !== pO.constructor) return !1;
        var XO, bK, eO;
        if (Array.isArray(KO)) {
          if ((XO = KO.length) != pO.length) return !1;
          for (bK = XO; 0 !== bK--;)
            if (!OO(KO[bK], pO[bK])) return !1;
          return !0
        }
        if (KO.constructor === RegExp) return KO.source === pO.source && KO.flags === pO.flags;
        if (KO.valueOf !== Object.prototype.valueOf) return KO.valueOf() === pO.valueOf();
        if (KO.toString !== Object.prototype.toString) return KO.toString() === pO.toString();
        if ((XO = (eO = Object.keys(KO)).length) !== Object.keys(pO).length) return !1;
        for (bK = XO; 0 !== bK--;)
          if (!Object.prototype.hasOwnProperty.call(pO, eO[bK])) return !1;
        for (bK = XO; 0 !== bK--;) {
          var lO = eO[bK];
          if (!OO(KO[lO], pO[lO])) return !1
        }
        return !0
      }
      return KO !== KO && pO !== pO
    }
  },
  35088: (OO, KO) => {
    function pO(OO) {
      if (OO && "object" === typeof OO) {
        var KO = OO.which || OO.keyCode || OO.charCode;
        KO && (OO = KO)
      }
      if ("number" === typeof OO) return lO[OO];
      var pO, eO = String(OO);
      return (pO = XO[eO.toLowerCase()]) ? pO : (pO = bK[eO.toLowerCase()]) || (1 === eO.length ? eO.charCodeAt(0) : void 0)
    }
    pO.isEventKey = function(OO, KO) {
      if (OO && "object" === typeof OO) {
        var pO = OO.which || OO.keyCode || OO.charCode;
        if (null === pO || void 0 === pO) return !1;
        if ("string" === typeof KO) {
          var eO;
          if (eO = XO[KO.toLowerCase()]) return eO === pO;
          if (eO = bK[KO.toLowerCase()]) return eO === pO
        } else if ("number" === typeof KO) return KO === pO;
        return !1
      }
    };
    var XO = (KO = OO.exports = pO).code = KO.codes = {
        backspace: 8,
        tab: 9,
        enter: 13,
        shift: 16,
        ctrl: 17,
        alt: 18,
        "pause/break": 19,
        "caps lock": 20,
        esc: 27,
        space: 32,
        "page up": 33,
        "page down": 34,
        end: 35,
        home: 36,
        left: 37,
        up: 38,
        right: 39,
        down: 40,
        insert: 45,
        delete: 46,
        command: 91,
        "left command": 91,
        "right command": 93,
        "numpad *": 106,
        "numpad +": 107,
        "numpad -": 109,
        "numpad .": 110,
        "numpad /": 111,
        "num lock": 144,
        "scroll lock": 145,
        "my computer": 182,
        "my calculator": 183,
        ";": 186,
        "=": 187,
        ",": 188,
        "-": 189,
        ".": 190,
        "/": 191,
        "`": 192,
        "[": 219,
        "\\": 220,
        "]": 221,
        "'": 222
      },
      bK = KO.aliases = {
        windows: 91,
        "\u21e7": 16,
        "\u2325": 18,
        "\u2303": 17,
        "\u2318": 91,
        ctl: 17,
        control: 17,
        option: 18,
        pause: 19,
        break: 19,
        caps: 20,
        return: 13,
        escape: 27,
        spc: 32,
        spacebar: 32,
        pgup: 33,
        pgdn: 34,
        ins: 45,
        del: 46,
        cmd: 91
      };
    for (eO = 97; eO < 123; eO++) XO[String.fromCharCode(eO)] = eO - 32;
    for (var eO = 48; eO < 58; eO++) XO[eO - 48] = eO;
    for (eO = 1; eO < 13; eO++) XO["f" + eO] = eO + 111;
    for (eO = 0; eO < 10; eO++) XO["numpad " + eO] = eO + 96;
    var lO = KO.names = KO.title = {};
    for (eO in XO) lO[XO[eO]] = eO;
    for (var vK in bK) XO[vK] = bK[vK]
  },
  35252: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO
    });
    var XO = pO(63);
    const bK = XO.useLayoutEffect;
    const eO = function(OO) {
      var KO = (0, XO.useRef)(OO);
      return bK((function() {
        KO.current = OO
      })), KO
    };
    var lO = function(OO) {
      var KO = eO(OO);
      (0, XO.useEffect)((function() {
        var OO = function(OO) {
          var pO;
          if (null != KO.current && (pO = KO.current(OO)), OO.defaultPrevented && (OO.returnValue = ""), "string" === typeof pO) return OO.returnValue = pO, pO
        };
        return window.addEventListener("beforeunload", OO),
          function() {
            window.removeEventListener("beforeunload", OO)
          }
      }), [])
    }
  },
  35116: OO => {
    var KO, pO = "undefined" !== typeof window ? window.navigator.userAgent : "",
      XO = /OS X/.test(pO),
      bK = /Opera/.test(pO),
      eO = !/like Gecko/.test(pO) && !bK,
      lO = OO.exports = {
        0: XO ? "<menu>" : "<UNK>",
        1: "<mouse 1>",
        2: "<mouse 2>",
        3: "<break>",
        4: "<mouse 3>",
        5: "<mouse 4>",
        6: "<mouse 5>",
        8: "<backspace>",
        9: "<tab>",
        12: "<clear>",
        13: "<enter>",
        16: "<shift>",
        17: "<control>",
        18: "<alt>",
        19: "<pause>",
        20: "<caps-lock>",
        21: "<ime-hangul>",
        23: "<ime-junja>",
        24: "<ime-final>",
        25: "<ime-kanji>",
        27: "<escape>",
        28: "<ime-convert>",
        29: "<ime-nonconvert>",
        30: "<ime-accept>",
        31: "<ime-mode-change>",
        32: "<space>",
        33: "<page-up>",
        34: "<page-down>",
        35: "<end>",
        36: "<home>",
        37: "<left>",
        38: "<up>",
        39: "<right>",
        40: "<down>",
        41: "<select>",
        42: "<print>",
        43: "<execute>",
        44: "<snapshot>",
        45: "<insert>",
        46: "<delete>",
        47: "<help>",
        91: "<meta>",
        92: "<meta>",
        93: XO ? "<meta>" : "<menu>",
        95: "<sleep>",
        106: "<num-*>",
        107: "<num-+>",
        108: "<num-enter>",
        109: "<num--\x3e",
        110: "<num-.>",
        111: "<num-/>",
        144: "<num-lock>",
        145: "<scroll-lock>",
        160: "<shift-left>",
        161: "<shift-right>",
        162: "<control-left>",
        163: "<control-right>",
        164: "<alt-left>",
        165: "<alt-right>",
        166: "<browser-back>",
        167: "<browser-forward>",
        168: "<browser-refresh>",
        169: "<browser-stop>",
        170: "<browser-search>",
        171: "<browser-favorites>",
        172: "<browser-home>",
        173: XO && eO ? "-" : "<volume-mute>",
        174: "<volume-down>",
        175: "<volume-up>",
        176: "<next-track>",
        177: "<prev-track>",
        178: "<stop>",
        179: "<play-pause>",
        180: "<launch-mail>",
        181: "<launch-media-select>",
        182: "<launch-app 1>",
        183: "<launch-app 2>",
        186: ";",
        187: "=",
        188: ",",
        189: "-",
        190: ".",
        191: "/",
        192: "`",
        219: "[",
        220: "\\",
        221: "]",
        222: "'",
        223: "<meta>",
        224: "<meta>",
        226: "<alt-gr>",
        229: "<ime-process>",
        231: bK ? "`" : "<unicode>",
        246: "<attention>",
        247: "<crsel>",
        248: "<exsel>",
        249: "<erase-eof>",
        250: "<play>",
        251: "<zoom>",
        252: "<no-name>",
        253: "<pa-1>",
        254: "<clear>"
      };
    for (KO = 58; KO < 65; ++KO) lO[KO] = String.fromCharCode(KO);
    for (KO = 48; KO < 58; ++KO) lO[KO] = KO - 48 + "";
    for (KO = 65; KO < 91; ++KO) lO[KO] = String.fromCharCode(KO);
    for (KO = 96; KO < 106; ++KO) lO[KO] = "<num-" + (KO - 96) + ">";
    for (KO = 112; KO < 136; ++KO) lO[KO] = "F" + (KO - 111)
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);