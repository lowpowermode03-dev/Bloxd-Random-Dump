export const id = 61;
export const ids = [61];
export const modules = {
  34981: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    const XO = {
      wait: function(OO) {
        return new Promise((KO => {
          setTimeout(KO, OO)
        }))
      },
      stallMs: 2e4
    };
    class bK {
      constructor(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : XO;
        this.url = OO, this.options = KO, this.timing = pO, this.fetched = null, this.scriptUrl = void 0, this.scriptUrl = OO
      }
      ready() {
        return this.fetched ??= this.fetchWithRetries(), this.fetched
      }
      start() {
        return new Worker(this.scriptUrl, this.options)
      }
      async fetchWithRetries() {
        for (let OO = 0;; OO++) {
          const KO = new URL(this.url);
          if (OO > 0 && KO.searchParams.set("cache-bust", `${Date.now()}-${OO}`), await this.fetchWhole(KO)) return void(this.scriptUrl = KO);
          if (OO >= 3) return;
          await this.timing.wait(500 * 2 ** OO)
        }
      }
      async fetchWhole(OO) {
        const KO = new AbortController;
        let pO;
        const XO = () => {
          clearTimeout(pO), pO = setTimeout((() => {
            KO.abort()
          }), this.timing.stallMs)
        };
        XO();
        try {
          var bK;
          const pO = await fetch(OO, {
            signal: KO.signal
          });
          if (!pO.ok) return !1;
          const eO = null === (bK = pO.body) || void 0 === bK ? void 0 : bK.getReader();
          if (!eO) return !1;
          for (;;) {
            const {
              done: OO
            } = await eO.read();
            if (OO) return !0;
            XO()
          }
        } catch {
          return !1
        } finally {
          clearTimeout(pO)
        }
      }
    }
  },
  41376: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      createWorldgenWorker: () => eO,
      worldgenWorkerReady: () => bK
    });
    const XO = new(pO(34981).c)(new URL(pO.p + pO.u(60), pO.b), {
      name: "worldgenWorker",
      type: "module"
    });

    function bK() {
      return XO.ready()
    }

    function eO() {
      return XO.start()
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);