export const id = 87;
export const ids = [87];
export const modules = {
  4021: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => fO
    });
    var XO = pO(1355),
      bK = pO(63),
      eO = pO(1051),
      lO = pO(1004),
      vK = pO(997),
      CO = pO(1663),
      hO = pO(1344),
      DO = pO(1180),
      MO = pO(989),
      aK = pO(22),
      oO = pO(1271),
      FO = pO(933),
      VO = pO(2043),
      LO = pO(1374),
      QO = pO(976);
    const zK = [{
        id: "myGames",
        icon: "joystick",
        title: "studio:myGames"
      }, {
        id: "leaderboard",
        icon: "trophy",
        title: "studio:leaderboard"
      }, {
        id: "docs",
        icon: "file-lines",
        title: "general:docs"
      }],
      AO = {
        myGames: "/studio",
        leaderboard: "/studio/leaderboard",
        docs: "/studio/docs"
      };

    function fO() {
      const {
        t: OO
      } = (0, eO.D)(), KO = (0, hO.useNavigatePreserveSearch)(), pO = (0, XO.p)(), {
        isUserContextUpdating: fO
      } = (0, lO.d)(), dO = (0, CO.e)(), TO = (0, vK.g)(), NO = (IO = pO.pathname).startsWith(LO.t) ? null : IO.startsWith(AO.docs) ? "docs" : IO.startsWith(AO.leaderboard) ? "leaderboard" : "myGames";
      var IO;
      const yK = function(OO) {
        if (!OO.startsWith(LO.t)) return {
          title: "studio:leaveStudio",
          icon: "left-from-bracket",
          to: "/"
        };
        const KO = (0, hO.getPreviousLocation)();
        return {
          title: "general:back",
          icon: "arrow-left",
          to: null !== KO && KO.startsWith(AO.myGames) ? -1 : AO.myGames
        }
      }(pO.pathname);
      return (0, bK.useEffect)((() => {
        aK.d.set({
          gameState: "studio",
          openEverythingMenuName: null
        })
      }), []), (0, QO.jsxs)("div", {
        className: "StudioLayout AnimFadeIn",
        children: [dO && (0, QO.jsx)("aside", {
          className: "StudioLayoutLeft",
          children: (0, QO.jsx)(VO.b, {})
        }), (0, QO.jsxs)("div", {
          className: "StudioLayoutRight",
          children: [(0, QO.jsxs)("div", {
            className: "StudioTop",
            children: [(0, QO.jsx)(MO.d, {
              show: !0,
              socialBarIsDocked: dO
            }), (0, QO.jsxs)("nav", {
              className: "StudioNav",
              children: [(0, QO.jsx)(oO.c, {
                icon: yK.icon,
                onClick: () => {
                  KO(yK.to)
                },
                children: OO(yK.title)
              }), (0, QO.jsx)("div", {
                className: "StudioNavTabs",
                children: zK.map((pO => (0, QO.jsxs)(oO.S, {
                  active: NO === pO.id,
                  href: AO[pO.id],
                  onClick: () => {
                    KO(AO[pO.id])
                  },
                  children: [(0, QO.jsx)(FO.d, {
                    name: pO.icon
                  }), !TO && OO(pO.title)]
                }, pO.id)))
              })]
            })]
          }), (0, QO.jsxs)("main", {
            className: "StudioBottom",
            children: [fO && (0, QO.jsx)("div", {
              className: "StudioCentredMessage",
              children: (0, QO.jsx)(DO.e, {})
            }), !fO && (0, QO.jsx)("div", {
              className: "StudioContent",
              children: (0, QO.jsx)(XO.e, {})
            })]
          })]
        })]
      })
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);