export const id = 130;
export const ids = [130];
export const modules = {
  38831: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => vK,
      g: () => lO
    });
    var XO = pO(2567);
    let bK = null,
      eO = null;

    function lO() {
      return eO ??= pO.e(193).then((() => pO(34916))).then((OO => {
        let {
          ITEM_SPRITES: KO,
          ITEM_SPRITES_WITHOUT_FILE: pO,
          ITEM_FILES_WITHOUT_SPRITE: eO
        } = OO;
        bK = function(OO, KO, pO) {
          const bK = new Set,
            eO = (0, XO.w)(KO);
          let lO = 0;
          for (const [XO, vK] of OO.entries()) XO === eO[lO] ? lO++ : bK.add(vK);
          if ("" !== pO)
            for (const vK of pO.split(XO.r)) bK.add(vK);
          return bK
        }(KO.split(XO.r), pO, eO)
      }), (OO => {
        throw eO = null, OO
      })), eO
    }

    function vK(OO) {
      var KO, pO;
      return null !== (KO = null === (pO = bK) || void 0 === pO ? void 0 : pO.has(OO)) && void 0 !== KO && KO
    }
  },
  37032: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => vK
    });
    var XO = pO(1077);

    function bK(OO) {
      const KO = /(\d*\.?\d+)px/.exec(OO);
      return KO ? Number(KO[1]) : null
    }

    function eO(OO) {
      return OO.split(/[\s,]+/).pop()
    }
    let lO = !1;
    const vK = {
      debug: !1,
      align: "center",
      vAlign: "middle",
      fontSize: 14,
      fontWeight: "",
      fontStyle: "",
      fontVariant: "",
      font: "Arial",
      lineHeight: null,
      justify: !1,
      drawText: function(OO, KO, XO, vK, CO, hO) {
        if (CO <= 0 || hO <= 0 || this.fontSize <= 0) return {
          height: 0
        };
        const {
          fontStyle: DO,
          fontVariant: MO,
          fontWeight: aK,
          fontSize: oO,
          font: FO
        } = this, VO = [DO, MO, aK, `${oO}px`, FO].filter(Boolean).join(" "), LO = [
          [aK, `${oO}px`, eO(FO)].filter(Boolean).join(" "), `${oO}px sans-serif`
        ], QO = OO.font, zK = function(OO, KO, pO) {
          for (const XO of KO) {
            OO.font = XO;
            const KO = bK(OO.font),
              lO = eO(XO);
            if (null !== KO && Math.abs(KO - pO) <= .5 && OO.font.toLowerCase().includes(lO.toLowerCase())) return XO
          }
          return null
        }(OO, [VO, ...LO], oO);
        zK !== VO && function(OO, KO, XO) {
          lO || (lO = !0, Promise.resolve().then((() => pO(951))).then((pO => {
            let {
              Zb: bK
            } = pO;
            bK(new Error("A canvas didn't take canvasTxt's font"), {
              font: OO,
              Sp: KO,
              drawnWith: null !== XO && void 0 !== XO ? XO : "the kept font, scaled"
            })
          })).catch((() => {})))
        }(VO, QO, zK);
        const AO = bK(OO.font);
        if (null === zK && null !== AO && AO > 0) {
          const pO = oO / AO;
          OO.save();
          try {
            return OO.scale(pO, pO), {
              height: this.drawLines(OO, KO, XO / pO, vK / pO, CO / pO, hO / pO, AO).height * pO
            }
          } finally {
            OO.restore()
          }
        }
        return this.drawLines(OO, KO, XO, vK, CO, hO, oO)
      },
      drawLines: function(OO, KO, pO, bK, eO, lO, vK) {
        const CO = pO + eO,
          hO = bK + lO;
        let DO, MO = bK + lO / 2 + vK / 2;
        "right" === this.align ? (DO = CO, OO.textAlign = "right") : "left" === this.align ? (DO = pO, OO.textAlign = "left") : (DO = pO + eO / 2, OO.textAlign = "center");
        for (const XO of KO) {
          OO.measureText(XO).width >= eO && (KO = KO.replace(XO, ""))
        }
        KO = (0, XO.P)(KO);
        const aK = [],
          oO = KO.split("\n"),
          FO = this.justify ? OO.measureText("\u200a").width : 0;
        oO.forEach((KO => {
          let pO = OO.measureText(KO).width;
          if (pO <= eO) aK.push(KO);
          else {
            let XO = KO;
            const bK = eO;
            let lO, vK, CO;
            for (pO = OO.measureText(XO).width; pO > bK;) {
              for (lO = 0, vK = 0, CO = ""; vK < bK;) lO++, CO = XO.substr(0, lO), vK = OO.measureText(CO).width;
              lO--, CO = CO.substr(0, lO);
              const KO = lO;
              if (" " !== XO.substr(lO, 1)) {
                for (;
                  " " !== XO.substr(lO, 1) && 0 !== lO;) lO--;
                0 === lO && (lO = KO), CO = XO.substr(0, lO)
              }
              CO = this.justify ? this.justifyLine(OO, CO, FO, "\u200a", eO) : CO, XO = XO.substr(lO), pO = OO.measureText(XO).width, aK.push(CO)
            }
            pO > 0 && aK.push(XO)
          }
        }));
        const VO = this.lineHeight ? this.lineHeight : this.getTextHeight(OO, KO),
          LO = VO * (aK.length - 1),
          QO = LO / 2;
        let zK = bK;
        "top" === this.vAlign ? MO = bK + vK : "bottom" === this.vAlign ? (MO = hO - LO, zK = hO) : (zK = bK + lO / 2, MO -= QO), aK.forEach((KO => {
          KO = KO.trim(), OO.fillText(KO, DO, MO), MO += VO
        })), this.debug && (OO.lineWidth = 3, OO.strokeStyle = "#00909e", OO.strokeRect(pO, bK, eO, lO), OO.lineWidth = 2, OO.strokeStyle = "#f6d743", OO.beginPath(), OO.moveTo(DO, bK), OO.lineTo(DO, hO), OO.stroke(), OO.strokeStyle = "#ff6363", OO.beginPath(), OO.moveTo(pO, zK), OO.lineTo(CO, zK), OO.stroke());
        return {
          height: LO + VO
        }
      },
      getTextHeight: function(OO, KO) {
        const pO = OO.textBaseline;
        OO.textBaseline = "bottom";
        const {
          actualBoundingBoxAscent: XO
        } = OO.measureText(KO);
        return OO.textBaseline = pO, XO
      },
      justifyLine: function(OO, KO, pO, XO, bK) {
        const eO = KO.trim(),
          lO = OO.measureText(eO).width,
          vK = eO.split(/\s+/).length - 1,
          CO = Math.floor((bK - lO) / pO);
        if (vK <= 0 || CO <= 0) return eO;
        const hO = Math.floor(CO / vK);
        let DO = CO - vK * hO,
          MO = [];
        for (let aK = 0; aK < hO; aK++) MO.push(XO);
        MO = MO.join("");
        return eO.replace(/\s+/g, (OO => {
          const KO = DO > 0 ? MO + XO : MO;
          return DO--, OO + KO
        }))
      }
    }
  },
  37040: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => VO,
      c: () => FO,
      f: () => aK,
      g: () => DO,
      k: () => MO
    });
    var XO = pO(3520),
      bK = pO(256);
    const eO = 1024,
      lO = 1536,
      vK = 2 * XO.j + 1,
      CO = new Intl.NumberFormat("en", {
        maximumSignificantDigits: 15
      }),
      hO = 1.5;

    function DO(OO, KO, pO) {
      if ("string" !== typeof OO) return KO;
      try {
        const pO = JSON.parse(OO);
        return pO && "object" === typeof pO ? pO : KO
      } catch (XO) {
        return void 0 !== pO && console.error(`Couldn't parse ${pO}`, XO), KO
      }
    }

    function MO(OO) {
      return DO(OO, null, "a leaderboard's rows")
    }

    function aK(OO, KO) {
      var pO, XO;
      return null !== KO && void 0 !== KO ? KO : {
        status: null !== (pO = OO.status) && void 0 !== pO ? pO : "loading",
        entries: null !== (XO = OO.entries) && void 0 !== XO ? XO : []
      }
    }

    function oO(OO, KO) {
      return "number" === typeof OO && Number.isFinite(OO) && OO > 0 ? OO : KO
    }

    function FO(OO, KO) {
      const pO = oO(OO.size, 1);
      let XO = oO(OO.width, oO(2.5 * pO, 2.5)),
        bK = oO(OO.height, oO(3.75 * pO, 3.75));
      Number.isFinite(eO * bK / XO) && Number.isFinite(lO * XO / bK) || (XO = 2.5, bK = 3.75);
      const vK = bK / XO,
        CO = Math.max(1, Math.min(eO, KO / vK));
      return {
        width: XO,
        height: bK,
        layoutWidth: Math.max(eO, lO / vK),
        layoutHeight: Math.max(lO, eO * vK),
        pixelWidth: Math.round(CO),
        pixelHeight: Math.round(Math.max(1, Math.min(KO, CO * vK)))
      }
    }

    function VO(OO, KO, pO, lO, DO, MO) {
      OO.setTransform(1, 0, 0, 1, 0, 0), OO.fillStyle = bK.J.defaultNameTagBackground, OO.fillRect(0, 0, KO, pO), OO.scale(KO / lO.layoutWidth, pO / lO.layoutHeight), OO.translate((lO.layoutWidth - eO) / 2, 0),
        function(OO, KO, pO, eO) {
          var lO, DO, MO, aK;
          const {
            top: oO,
            around: FO,
            showPlayerText: VO,
            localPlayerDbId: zK
          } = pO, {
            whiteUiText: AO,
            grayUiText: fO,
            yellowUiText: dO
          } = bK.J;
          OO.textBaseline = "middle";
          const TO = function(KO, pO, XO, bK, eO, lO) {
              let vK = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : "left";
              OO.font = `bold ${bK}px 'Jetbrains Mono', monospace`, OO.fillStyle = eO, OO.textAlign = vK;
              let CO = KO.replace(/[\r\n\t]/g, " ");
              if (OO.measureText(CO).width > lO) {
                for (; CO.length > 0 && OO.measureText(`${CO}\u2026`).width > lO;) CO = CO.slice(0, -1);
                CO += "\u2026"
              }
              OO.fillText(CO, pO, XO)
            },
            NO = KO => {
              OO.fillStyle = AO, OO.globalAlpha = .15, OO.fillRect(24, KO, 976, 2), OO.globalAlpha = 1
            },
            IO = null === zK ? null : (0, bK.mc)(zK),
            yK = OO => null !== IO && OO.playerHash === IO,
            gK = LO(oO.entries, XO.n),
            uO = "ready" === oO.status && gK.length > 0,
            EO = null === FO ? [] : LO(FO.entries, vK),
            jK = gK.some(yK),
            YO = null === FO ? null : function(OO) {
              const KO = OO;
              if (!KO || !Number.isFinite(KO.rank) || !Number.isFinite(KO.tied) || !Number.isFinite(KO.total)) return null;
              return KO
            }(FO.standing),
            wO = EO.find(yK),
            iK = gK.find(yK),
            rK = null === YO || void 0 === wO ? null : {
              value: wO.value,
              rank: YO.rank
            },
            PO = QO(gK, void 0 === iK || iK.value === (null === rK || void 0 === rK ? void 0 : rK.value) ? rK : null),
            mK = QO(EO, rK),
            sO = (OO, KO) => {
              const pO = OO.findIndex(yK);
              return pO >= 0 ? KO[pO] : null
            },
            HO = null !== (lO = null !== (DO = null === YO || void 0 === YO ? void 0 : YO.rank) && void 0 !== DO ? DO : sO(EO, mK)) && void 0 !== lO ? lO : sO(gK, PO);
          OO.font = "bold 34px 'Jetbrains Mono', monospace";
          const RO = [...uO ? PO : [], ...jK ? [] : mK],
            SO = Math.min(280, Math.max(0, ...RO.map((KO => OO.measureText(CO.format(KO)).width)))),
            JO = SO <= 80,
            cK = JO ? 80 : 32 + SO,
            BO = JO ? 148 : cK + 28,
            ZO = 660 - BO;
          TO(`TOP ${XO.n}  /  ALL TIME`, 24, 52, 28, fO, 976), TO(VO ? String(null !== (MO = KO.title) && void 0 !== MO ? MO : "Leaderboard").slice(0, 64) : "Leaderboard", 24, 108, 52, AO, 976), TO("RANK", 32, 174, 28, fO, BO - 40), TO("PLAYER", BO, 174, 28, fO, ZO), TO(VO ? String(null !== (aK = KO.scoreLabel) && void 0 !== aK ? aK : "Score").slice(0, 24) : "Score", 992, 174, 28, fO, 304, "right"), NO(202);
          const GO = (eO - 232) / (XO.n + hO + vK),
            qK = 208 + XO.n * GO,
            xK = qK + hO * GO,
            nO = (KO, pO, XO, bK) => {
              const eO = yK(KO);
              OO.fillStyle = eO ? dO : AO, OO.globalAlpha = eO ? .15 : bK ? .035 : 0, OO.fillRect(24, XO - GO / 2 + 1, 976, GO - 2), OO.globalAlpha = 1;
              const lO = eO ? dO : AO;
              TO(CO.format(pO), cK, XO, 34, lO, JO ? 80 : SO, JO ? "center" : "right"), TO(VO ? String(KO.name).slice(0, 64) : "Player", BO, XO, 34, lO, ZO);
              const vK = CO.format(KO.value);
              TO(OO.measureText(vK).width > 304 ? KO.value.toExponential(6) : vK, 992, XO, 34, lO, 304, "right")
            };
          if (uO)
            for (const [XO, bK] of gK.entries()) nO(bK, PO[XO], 208 + (XO + .5) * GO, XO % 2 === 0);
          else {
            const OO = "error" === oO.status,
              KO = OO ? "Couldn't load leaderboard" : "ready" === oO.status ? "No scores yet" : "Loading leaderboard\u2026",
              pO = OO ? "Trying again shortly" : "ready" === oO.status ? "Be the first on the board!" : "Fetching the top players",
              XO = (208 + qK) / 2;
            TO(KO, 512, XO - 28, 40, OO ? bK.J.redUiText : AO, 960, "center"), TO(pO, 512, XO + 27, 30, fO, 960, "center")
          }
          const WO = qK + hO * GO / 2;
          if (null === HO) NO(WO);
          else {
            const KO = null === YO ? 0 : YO.tied - 1,
              pO = `YOUR RANK #${CO.format(HO)}${null===YO?"":` of ${CO.format(YO.total)}`}`;
            OO.font = "bold 36px 'Jetbrains Mono', monospace";
            const XO = Math.max(20, Math.min(36, Math.floor(34560 / OO.measureText(pO).width)));
            TO(pO, 512, WO - (KO > 0 ? 15 : 0), XO, dO, 960, "center"), KO > 0 && TO(`Tied with ${CO.format(KO)} other${1===KO?"":"s"}`, 512, WO + 24, 24, fO, 960, "center")
          }
          if (null === FO) return;
          const tK = xK + vK * GO / 2;
          if (jK) TO(`You're in the top ${XO.n}!`, 512, tK, 40, dO, 960, "center");
          else if (0 === EO.length) TO("You're not on this board yet", 512, tK, 34, fO, 960, "center");
          else
            for (const [XO, bK] of EO.entries()) nO(bK, mK[XO], xK + (XO + .5) * GO, XO % 2 === 0)
        }(OO, DO, MO, lO.layoutHeight)
    }

    function LO(OO, KO) {
      return Array.isArray(OO) ? OO.slice(0, KO).filter((OO => OO && Number.isFinite(OO.rank) && Number.isFinite(OO.value))) : []
    }

    function QO(OO, KO) {
      const pO = [];
      let XO = !1;
      return OO.forEach(((bK, eO) => {
        if (null !== KO && bK.value === KO.value) return void pO.push(KO.rank);
        const lO = eO > 0 && bK.value === OO[eO - 1].value;
        lO || (XO = 0 === eO && 1 !== bK.rank), pO.push(lO && !XO ? pO[eO - 1] : bK.rank)
      })), pO
    }
  },
  37251: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      i: () => eO
    });
    const XO = 32;

    function bK(OO) {
      return Array.from(OO).length
    }

    function eO(OO) {
      const KO = [""];
      let pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        bK = "";
      const eO = () => {
        KO.push(""), pO = 0, bK = ""
      };
      for (const lO of OO.replace(/\\n/g, "\n").split(/(\r?\n|[^\S\r\n]+)/))
        if (/^\r?\n$/.test(lO)) eO();
        else if (/^\s+$/.test(lO)) bK += lO;
      else if (lO.length > 0) {
        const OO = Array.from(lO);
        pO > 0 && pO + bK.length + OO.length > XO && eO(), KO[KO.length - 1] += bK, pO += bK.length, bK = "";
        for (const bK of OO) pO >= XO && eO(), KO[KO.length - 1] += bK, pO++
      }
      return KO[KO.length - 1] += bK, KO
    }
  },
  38828: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      g: () => vK
    });
    var XO = pO(38831);
    let bK = null,
      eO = null;

    function lO() {
      return bK ??= pO.e(53).then((() => pO(40661))).catch((OO => {
        throw bK = null, OO
      })), bK
    }

    function vK() {
      return eO ??= Promise.all([lO(), (0, XO.g)()]).then((OO => {
        let [KO] = OO;
        return KO
      }), (OO => {
        throw eO = null, OO
      })), eO
    }
  },
  40634: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => wO,
      f: () => cK,
      i: () => sO,
      l: () => jK,
      n: () => YO,
      p: () => SO,
      s: () => EO,
      v: () => uO
    });
    var XO = pO(3668),
      bK = pO(3692),
      eO = pO(35217),
      lO = pO(2560),
      vK = pO(2557),
      CO = pO(39043),
      hO = pO(94),
      DO = pO(1119),
      MO = pO(38828),
      aK = pO(7145),
      oO = pO(6628),
      FO = pO(6767),
      VO = pO(6858),
      LO = pO(6998),
      QO = pO(7013);
    const zK = {
        youtube: aK.g,
        "person-military-pointing": oO.f,
        sparkle: FO.h,
        user: VO.f,
        wrench: LO.i,
        zap: QO.e
      },
      AO = new Map(Object.entries(zK).map((OO => {
        let [KO, pO] = OO;
        const [XO, bK, , , eO] = pO.icon;
        return [KO, {
          width: XO,
          height: bK,
          path: "string" === typeof eO ? eO : eO.join(" ")
        }]
      })));
    var fO = pO(38890);
    const dO = 397,
      TO = 1,
      NO = {
        translate: OO => [OO],
        keyBindingText: OO => OO,
        isFriend: () => !1,
        hiddenNames: {}
      };
    let IO = null,
      yK = 0,
      gK = "none";

    function uO() {
      return yK
    }

    function EO() {
      yK++, !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0] ? gK = "all" : "none" === gK && (gK = "notBoards")
    }

    function jK(OO) {
      Object.assign(NO, OO), EO(!1)
    }

    function YO(OO) {
      OO !== IO && (IO = OO, EO())
    }

    function wO(OO) {
      if ("none" === gK || null === OO) return;
      OO(dO, "all" === gK ? 0 : TO, new Uint8Array(0)) && (gK = "none")
    }
    const iK = new Map;

    function rK(OO, KO, pO) {
      const XO = pO ? `${OO}#${pO.join(",")}` : OO,
        bK = iK.get(XO);
      if (bK) return bK.image;
      const eO = {
        image: null
      };
      return iK.set(XO, eO), KO().then((async OO => {
        if (null === OO) return null;
        const KO = new Image;
        KO.crossOrigin = "anonymous", KO.src = OO, await KO.decode();
        const XO = await createImageBitmap(KO);
        if (!pO) return XO;
        try {
          return function(OO, KO) {
            let [pO, XO, bK] = KO;
            const eO = (0, CO.d)(OO.width, OO.height),
              {
                canvas: lO
              } = eO;
            return eO.drawImage(OO, 0, 0), eO.globalCompositeOperation = "multiply", eO.fillStyle = `rgb(${pO}, ${XO}, ${bK})`, eO.fillRect(0, 0, lO.width, lO.height), eO.globalCompositeOperation = "destination-in", eO.drawImage(OO, 0, 0), lO
          }(XO, pO)
        } finally {
          XO.close()
        }
      })).then((OO => {
        null !== OO && (eO.image = OO, EO(!1))
      }), (KO => {
        console.warn(`[bloxd-wasm-client] text icon ${OO} did not load`, KO), iK.get(XO) === eO && iK.delete(XO)
      })), null
    }
    const PO = new Set(XO.b),
      mK = new Set(["CubeBlock", "SlabBlock", "StairsBlock"]);

    function sO() {
      (0, MO.g)().catch((() => {}))
    }

    function HO(OO) {
      return PO.has(OO) ? rK(`icon:${OO}`, (async () => (await (0, MO.d)()).ingameIconUrl(OO))) : null
    }
    let RO = "unasked";
    const SO = {
      get canSeeRealPlayerNames() {
        return hO.featureFlags.canSeeRealPlayerNames
      },
      get canSeePlayerWrittenText() {
        return hO.featureFlags.canSeePlayerWrittenText
      },
      get localPlayerDbId() {
        return IO
      },
      shownPlayerName: OO => (0, DO.f)(OO, NO.hiddenNames),
      translate: (OO, KO) => {
        const pO = "object" === typeof KO && null !== KO ? KO : void 0;
        return NO.translate(OO, (0, DO.g)(pO, NO.hiddenNames))
      },
      keyBindingText: OO => NO.keyBindingText(OO),
      isFriend: OO => NO.isFriend(OO, NO.hiddenNames),
      iconImage: function(OO) {
        if (PO.has(OO)) return HO(OO);
        if ("unasked" === RO && (RO = "loading", (0, vK.h)().then((() => {
            RO = "in", EO(!1)
          }), (OO => {
            RO = "failed", console.warn("[bloxd-wasm-client] the item sprite table did not load, so text item icons stay blank", OO)
          }))), "in" !== RO) return null;
        const KO = (0, lO.c)(OO),
          pO = void 0 === KO ? void 0 : (0, eO.itemTypeNameOf)(KO);
        if ("Gun" === pO) return null;
        const XO = (0, vK.d)(OO),
          CO = void 0 !== pO && mK.has(pO);
        if (CO && void 0 === XO) return null;
        const hO = void 0 !== KO && "GrayscaleArmour" === (0, eO.itemTypeOf)(KO) || Object.hasOwn(bK.e, OO),
          DO = null !== XO && void 0 !== XO ? XO : OO;
        return rK(CO ? `block:${DO}` : `item:${DO}`, (async () => {
          var OO;
          const KO = await (0, MO.g)();
          return null !== (OO = KO.itemSpriteUrl(DO)) && void 0 !== OO ? OO : CO ? null : KO.notFoundUrl()
        }), hO ? (0, bK.h)(OO) : void 0)
      },
      effectImage: HO,
      rankIcon: function(OO) {
        var KO;
        return null !== (KO = AO.get(OO)) && void 0 !== KO ? KO : null
      }
    };
    let JO = null;

    function cK() {
      return JO ??= new FontFace("Jetbrains Mono", `url(${(0,fO.d)()}) format("woff2")`).load().then((OO => {
        document.fonts.add(OO), EO()
      }), (OO => {
        console.warn("[bloxd-wasm-client] the text font did not load", OO)
      })), JO
    }
  },
  38890: (OO, KO, pO) => {
    function XO() {
      return pO(38897)
    }
    pO.d(KO, {
      d: () => XO
    })
  },
  40627: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => TK,
      e: () => VK
    });
    var XO = pO(35255),
      bK = pO(39043),
      eO = pO(37251),
      lO = pO(512),
      vK = pO(243);
    const CO = {
        DEFAULT_FONT_SIZE: 47,
        DEFAULT_SUBTITLE_FONT_SIZE: 30,
        HORIZONTAL_PADDING: 30,
        VERTICAL_PADDING: 22,
        TEXT_SHADOW_WIDTH: 2,
        LINE_SPACING: 8,
        EFFECT_ICON_SIZE: 70
      },
      hO = 41;

    function DO(OO) {
      return `bolder ${OO}px 'Jetbrains Mono'`
    }

    function MO(OO) {
      return "object" === typeof OO && null !== OO
    }

    function aK(OO, KO) {
      const pO = "number" === typeof OO ? OO : "string" === typeof OO ? Number(OO.replace("px", "")) : NaN;
      return Number.isFinite(pO) && pO > 0 ? pO : KO
    }

    function oO(OO) {
      return MO(OO) ? OO : void 0
    }

    function FO(OO) {
      const KO = "number" === typeof OO ? lO.v[OO] : OO;
      return "string" === typeof KO && Object.hasOwn(lO.l, KO) ? lO.l[KO] : void 0
    }

    function VO(OO, KO) {
      return "string" === typeof OO ? OO : MO(OO) ? "string" === typeof OO.translationKey ? KO.translate(OO.translationKey, OO.params).map((OO => "string" === typeof OO ? OO : OO.icon)).join("") : "string" === typeof OO.entityName ? KO.shownPlayerName(OO.entityName) : "" : void 0 === OO || null === OO ? "" : String(OO)
    }

    function LO(OO, KO, pO, XO) {
      if (!Array.isArray(OO)) return [];
      const bK = [];
      for (const DO of OO) {
        var eO, lO;
        if (MO(DO) && "chatTag" in DO) {
          bK.push({
            kind: "rank",
            rank: DO
          });
          continue
        }
        if (MO(DO) && "icon" in DO && !("mainRGB" in DO)) {
          var hO;
          bK.push({
            kind: "icon",
            icon: String(DO.icon),
            size: aK(null === (hO = oO(DO.style)) || void 0 === hO ? void 0 : hO.fontSize, CO.DEFAULT_FONT_SIZE)
          });
          continue
        }
        if (MO(DO) && (0, vK.yb)(DO)) {
          bK.push({
            kind: "text",
            text: "",
            size: KO,
            colour: XO
          });
          continue
        }
        let OO, FO;
        MO(DO) && (0, vK.ub)(DO) ? (OO = pO.keyBindingText(String(DO.action)), FO = oO(DO.style)) : MO(DO) && "str" in DO ? (OO = DO.str, FO = oO(DO.style)) : OO = DO;
        const LO = aK(null === (eO = FO) || void 0 === eO ? void 0 : eO.fontSize, KO),
          QO = null !== (lO = (0, vK.Ub)(FO)) && void 0 !== lO ? lO : XO;
        if (MO(OO) && "string" === typeof OO.translationKey) {
          const KO = pO.translate(OO.translationKey, OO.params);
          if (KO.some((OO => "string" !== typeof OO))) {
            for (const OO of KO) bK.push("string" === typeof OO ? {
              kind: "text",
              text: OO,
              size: LO,
              colour: QO
            } : {
              kind: "icon",
              icon: OO.icon,
              size: LO
            });
            continue
          }
        }
        bK.push({
          kind: "text",
          text: VO(OO, pO),
          size: LO,
          colour: QO
        })
      }
      return bK
    }

    function QO(OO) {
      return void 0 !== OO && "rank" !== OO.kind
    }

    function zK(OO, KO) {
      const pO = QO(OO),
        XO = QO(KO);
      return void 0 === OO && !XO || !pO && void 0 === KO ? 0 : pO !== XO ? .5 * CO.HORIZONTAL_PADDING : 0
    }

    function AO(OO) {
      return "rank" === OO.kind ? CO.DEFAULT_FONT_SIZE : OO.size
    }

    function fO(OO, KO, pO) {
      return "icon" === OO.kind ? OO.size : "rank" === OO.kind ? function(OO, KO) {
        const pO = KO.rankIcon(OO.rank.icon);
        return pO ? hO * (pO.width / pO.height) : hO
      }(OO, pO) + CO.HORIZONTAL_PADDING : (KO.font = DO(OO.size), KO.measureText(OO.text).width)
    }

    function dO(OO, KO, pO) {
      if (0 === OO.length) return {
        width: 0,
        height: 0,
        sizes: []
      };
      let XO = 0;
      for (const lO of OO) XO = Math.max(XO, AO(lO));
      const bK = [];
      let eO = zK(void 0, OO[0]);
      for (let lO = 0; lO < OO.length; lO++) {
        const XO = eO;
        eO += fO(OO[lO], KO, pO), eO += zK(OO[lO], OO[lO + 1]), bK.push({
          x: XO,
          width: eO - XO
        })
      }
      return {
        width: eO,
        height: XO + CO.VERTICAL_PADDING,
        sizes: bK
      }
    }

    function TO(OO, KO, pO, XO, bK, eO, lO) {
      KO += zK(void 0, OO[0]);
      for (let vK = 0; vK < OO.length; vK++) {
        const CO = NO(OO[vK], KO, pO, XO, bK, eO, lO);
        KO += 0 === CO ? 0 : CO + zK(OO[vK], OO[vK + 1])
      }
    }

    function NO(OO, KO, pO, XO, bK, eO, lO, vK) {
      var MO;
      if ("icon" === OO.kind) {
        const XO = eO.iconImage(OO.icon);
        return XO && lO.push({
          image: XO,
          x: KO,
          y: pO + CO.VERTICAL_PADDING / 2,
          size: OO.size
        }), OO.size
      }
      if ("rank" === OO.kind) {
        const lO = null !== vK && void 0 !== vK ? vK : fO(OO, bK, eO);
        return function(OO, KO, pO, XO, bK, eO, lO) {
          var vK, DO;
          const {
            rank: MO
          } = OO;
          eO.fillStyle = MO.mainRGB, eO.fillRect(KO, pO, XO, bK);
          const aK = lO.rankIcon(MO.icon);
          if (!aK) return;
          const oO = hO / aK.height,
            FO = KO + (XO - aK.width * oO) / 2,
            VO = pO + (bK - hO) / 2,
            LO = new Path2D(aK.path),
            QO = CO.TEXT_SHADOW_WIDTH,
            zK = (null === (vK = MO.nameTag) || void 0 === vK ? void 0 : vK.iconShadowRGB) || "black";
          for (const CO of [-1, 1])
            for (const OO of [-1, 1]) yK(eO, LO, FO + QO * CO, VO + QO * OO, oO, zK);
          yK(eO, LO, FO, VO, oO, (null === (DO = MO.nameTag) || void 0 === DO ? void 0 : DO.iconRGB) || "white")
        }(OO, KO, pO, lO, XO, bK, eO), lO
      }
      if (0 === OO.text.length) return 0;
      const aK = DO(OO.size);
      bK.font = aK;
      const oO = null !== vK && void 0 !== vK ? vK : bK.measureText(OO.text).width;
      return function(OO, KO, pO, XO, bK, eO) {
        const lO = CO.TEXT_SHADOW_WIDTH;
        eO.font = XO, eO.fillStyle = "black";
        for (const vK of [-1, 1])
          for (const XO of [-1, 1]) eO.fillText(OO, KO + lO * vK, pO + lO * XO);
        eO.fillStyle = bK, eO.fillText(OO, KO, pO)
      }(OO.text, KO, pO + XO - CO.VERTICAL_PADDING + 5, aK, null !== (MO = OO.colour) && void 0 !== MO ? MO : "white", bK), oO
    }

    function IO(OO, KO) {
      for (const {
          image: pO,
          x: XO,
          y: bK,
          size: eO
        }
        of OO) KO.imageSmoothingEnabled = !1, KO.drawImage(pO, XO, bK, eO, eO)
    }

    function yK(OO, KO, pO, XO, bK, eO) {
      OO.save(), OO.translate(pO, XO), OO.scale(bK, bK), OO.fillStyle = eO, OO.fill(KO), OO.restore()
    }

    function gK(OO, KO, pO) {
      const XO = "object" === typeof OO && null !== OO ? OO : {},
        bK = function(OO, KO, pO) {
          if (!Array.isArray(OO) || 0 === OO.length) return [];
          const XO = [{
            width: 0,
            height: 0,
            y: 0,
            items: []
          }];
          for (const lO of LO(OO, CO.DEFAULT_FONT_SIZE, pO)) {
            if ("text" !== lO.kind) {
              XO[XO.length - 1].items.push({
                content: lO,
                chars: 1,
                size: {
                  x: 0,
                  width: 0
                }
              });
              continue
            }
            if (0 === lO.text.length) continue;
            const OO = XO[XO.length - 1].items.reduce(((OO, KO) => OO + ("text" === KO.content.kind ? (0, eO.e)(KO.content.text) : KO.chars)), 0);
            (0, eO.i)(lO.text, OO).forEach(((OO, KO) => {
              KO > 0 && XO.push({
                width: 0,
                height: 0,
                y: 0,
                items: []
              }), OO.length > 0 && XO[XO.length - 1].items.push({
                content: {
                  ...lO,
                  text: OO
                },
                chars: OO.length,
                size: {
                  x: 0,
                  width: 0
                }
              })
            }))
          }
          let bK = CO.VERTICAL_PADDING / 2;
          for (const eO of XO) {
            if (0 === eO.items.length) continue;
            const {
              width: OO,
              height: XO,
              sizes: lO
            } = dO(eO.items.map((OO => OO.content)), KO, pO);
            eO.items.forEach(((OO, KO) => {
              OO.size = lO[KO]
            })), eO.width = OO, eO.height = XO, eO.y = bK, bK += XO + CO.LINE_SPACING
          }
          return XO
        }(XO.content, KO, pO);
      let lO = 0,
        vK = CO.VERTICAL_PADDING,
        hO = 0;
      for (const eO of bK) {
        lO = Math.max(lO, eO.width + 2 * CO.HORIZONTAL_PADDING), vK += eO.height + CO.LINE_SPACING;
        for (const OO of eO.items) hO += OO.chars
      }
      const DO = "string" === typeof XO.backgroundColor ? XO.backgroundColor : "#22283b";
      return {
        width: lO,
        height: vK,
        chars: hO,
        draw: (OO, KO) => {
          const XO = [];
          if (OO.fillStyle = DO, OO.fillRect(0, 0, lO, vK), null === KO)
            for (const eO of bK) eO.items.length > 0 && TO(eO.items.map((OO => OO.content)), 0, eO.y, eO.height, OO, pO, XO);
          else {
            let eO = 0;
            for (const lO of bK)
              for (const bK of lO.items) {
                if (eO >= KO) break;
                NO("text" === bK.content.kind ? {
                  ...bK.content,
                  text: bK.content.text.substring(0, KO - eO)
                } : bK.content, bK.size.x, lO.y, lO.height, OO, pO, XO, bK.size.width), eO += bK.chars
              }
          }
          IO(XO, OO)
        }
      }
    }
    var uO = pO(3668),
      EO = pO(1123),
      jK = pO(1633);
    const YO = 10,
      wO = 3,
      iK = 3,
      rK = [{
        healthFraction: .25,
        colour: "#ff0000"
      }, {
        healthFraction: .5,
        colour: "#ffaa00"
      }, {
        healthFraction: 1,
        colour: "#00ff00"
      }],
      PO = 64,
      mK = 69,
      sO = {
        icon: jK.e,
        mainRGB: "transparent",
        chatTag: [],
        nameTag: {
          iconRGB: "#f38ab6",
          iconShadowRGB: "black"
        },
        visible: !0
      };

    function HO(OO) {
      return "object" !== typeof OO || null === OO || Array.isArray(OO) ? void 0 : OO
    }
    const RO = new Set(uO.b);

    function SO(OO, KO) {
      return "string" === typeof OO ? aK(OO, KO) : KO
    }

    function JO(OO) {
      return SO(OO.width, wO)
    }

    function cK(OO, KO) {
      var pO;
      const XO = null !== (pO = OO.applyTo) && void 0 !== pO ? pO : "both";
      return "both" === XO || XO === KO
    }

    function BO(OO) {
      const KO = JO(OO);
      return "glow" === OO.style ? KO * iK : Math.ceil(KO / 2) + 1
    }

    function ZO(OO, KO, pO) {
      var XO, bK;
      const eO = null !== (XO = HO(OO.info)) && void 0 !== XO ? XO : {},
        vK = "string" === typeof OO.name ? OO.name : "",
        hO = eO.subtitle;
      if (Array.isArray(eO.content) && 0 === eO.content.length && !(Array.isArray(hO) && hO.length > 0)) return null;
      const DO = "number" === typeof OO.hideNameSeed ? OO.hideNameSeed : null,
        MO = "" === vK || !0 === OO.mesh ? vK : (0, EO.c)(vK, !pO.canSeeRealPlayerNames, DO);
      if (!MO && !eO.content) return null;
      const aK = "string" === typeof OO.colour ? OO.colour : "default",
        oO = Object.hasOwn(lO.s, aK) ? lO.s[aK] : void 0,
        VO = eO.content ? LO(eO.content, CO.DEFAULT_FONT_SIZE, pO, oO) : [{
          kind: "text",
          text: MO,
          size: CO.DEFAULT_FONT_SIZE,
          colour: oO
        }],
        QO = [];
      for (const lO of Array.isArray(OO.ranks) ? OO.ranks : []) {
        const OO = FO(lO);
        null !== OO && void 0 !== OO && OO.nameTag && OO.visible && QO.push({
          kind: "rank",
          rank: OO
        })
      }
      QO.push(...VO);
      ("boolean" === typeof OO.player ? OO.player : Array.isArray(OO.ranks)) && "" !== vK && pO.isFriend(vK) && QO.push({
        kind: "rank",
        rank: sO
      }), "number" === typeof OO.OO && QO.push({
        kind: "text",
        text: ` ${OO.OO}m`,
        size: CO.DEFAULT_FONT_SIZE,
        colour: "#cef3ff"
      });
      const zK = hO ? LO(hO, CO.DEFAULT_SUBTITLE_FONT_SIZE, pO) : null,
        AO = "string" === typeof eO.backgroundColor ? eO.backgroundColor : "#22283b",
        fO = "string" === typeof eO.subtitleBackgroundColor ? eO.subtitleBackgroundColor : "#1a1e2d",
        NO = HO(eO.healthbar),
        yK = HO(eO.border),
        gK = Array.isArray(OO.effects) ? OO.effects.filter((OO => "string" === typeof OO && RO.has(OO))) : [],
        uO = "number" === typeof OO.health ? Math.max(0, Math.min(1, OO.health)) : null,
        jK = dO(QO, KO, pO),
        wO = dO(null !== zK && void 0 !== zK ? zK : [], KO, pO),
        ZO = {
          width: CO.EFFECT_ICON_SIZE * gK.length,
          height: gK.length > 0 ? CO.EFFECT_ICON_SIZE : 0
        },
        GO = yK && cK(yK, "nametag") ? BO(yK) : 0,
        qK = SO(null === NO || void 0 === NO ? void 0 : NO.height, YO),
        xK = yK && cK(yK, "healthbar") ? BO(yK) : 0,
        nO = "never" === (null !== (bK = null === NO || void 0 === NO ? void 0 : NO.display) && void 0 !== bK ? bK : "onDamage") ? 0 : qK + xK,
        WO = Math.max(ZO.height, GO),
        tK = Math.max(CO.VERTICAL_PADDING, nO, GO);
      let kK = Math.max(jK.width, wO.width, ZO.width);
      if (yK) {
        const OO = BO(yK) + CO.HORIZONTAL_PADDING / 2;
        kK = Math.max(kK, Math.max(jK.width, wO.width) + CO.HORIZONTAL_PADDING + 2 * OO)
      }
      const UO = jK.height + wO.height + WO + tK,
        OK = jK.width + CO.HORIZONTAL_PADDING,
        KK = wO.width + CO.HORIZONTAL_PADDING,
        pK = Math.max(OK, KK),
        XK = (kK - pK) / 2,
        bp = Math.max(ZO.height, GO);
      return {
        width: kK,
        height: UO,
        draw: OO => {
          const KO = [];
          if (OO.fillStyle = AO, OO.fillRect(XK, bp, pK, jK.height), TO(QO, (kK - OK) / 2 + CO.HORIZONTAL_PADDING / 2, bp, jK.height, OO, pO, KO), zK) {
            const XO = bp + jK.height;
            OO.fillStyle = fO, OO.fillRect(XK, XO, pK, wO.height), TO(zK, (kK - KK) / 2 + CO.HORIZONTAL_PADDING / 2, XO, wO.height, OO, pO, KO)
          }
          let XO = null;
          if (null !== uO) {
            const KO = UO - qK - xK;
            null !== NO && void 0 !== NO && NO.backgroundColour && (OO.fillStyle = NO.backgroundColour, OO.fillRect(XK, KO, pK, qK)), OO.fillStyle = function(OO, KO) {
              const pO = null === OO || void 0 === OO ? void 0 : OO.foregroundColour;
              if ("string" === typeof pO) return pO;
              const XO = [...Array.isArray(pO) && pO.length > 0 ? pO : rK].sort(((OO, KO) => OO.healthFraction - KO.healthFraction)),
                bK = XO.find((OO => KO <= OO.healthFraction));
              return (null !== bK && void 0 !== bK ? bK : XO[XO.length - 1]).colour
            }(NO, uO), OO.fillRect(XK, KO, Math.round(pK * uO), qK), XO = {
              x: XK,
              y: KO,
              width: pK,
              height: qK
            }
          }
          if (yK) {
            const KO = [];
            cK(yK, "nametag") && KO.push({
              x: XK,
              y: bp,
              width: pK,
              height: jK.height + (zK ? wO.height : 0)
            }), XO && cK(yK, "healthbar") && KO.push(XO), KO.length > 0 && function(OO, KO, pO) {
              const XO = JO(KO),
                bK = XO / 2,
                eO = OO => OO.width > 0 && OO.height > 0,
                lO = pO.map((OO => ({
                  x: OO.x + bK,
                  y: OO.y + bK,
                  width: OO.width - XO,
                  height: OO.height - XO
                }))).filter(eO);
              if (0 === lO.length) return;
              const vK = KO => {
                const pO = KO.filter(eO);
                if (0 !== pO.length) {
                  OO.beginPath();
                  for (const KO of pO) OO.rect(KO.x, KO.y, KO.width, KO.height);
                  OO.stroke()
                }
              };
              if (OO.save(), OO.strokeStyle = KO.colour, OO.lineWidth = XO, OO.lineJoin = "round", "glow" === KO.style) OO.shadowColor = KO.colour, OO.shadowBlur = XO * iK, vK(lO), vK(lO);
              else if ("double" === KO.style) {
                vK(lO);
                const OO = XO + 2;
                vK(lO.map((KO => ({
                  x: KO.x + OO,
                  y: KO.y + OO,
                  width: KO.width - 2 * OO,
                  height: KO.height - 2 * OO
                }))))
              } else vK(lO);
              OO.restore()
            }(OO, yK, KO)
          }
          IO(KO, OO);
          for (let bK = 0; bK < gK.length; bK++) {
            const KO = pO.effectImage(gK[bK]);
            KO && (OO.imageSmoothingEnabled = !1, OO.drawImage(KO, 5 + mK * bK, 5, PO, PO))
          }
        }
      }
    }
    var GO = pO(37032);
    const qK = 256,
      xK = 1024,
      nO = {
        width: 1,
        height: 7 / 8
      };
    var WO = pO(37040);
    const tK = {
      leaderboard: ""
    };
    var kK = pO(40634);
    const UO = {
        Nametag: 1,
        MultilineText: 2,
        Board: 3,
        Leaderboard: 4
      },
      OK = 2048,
      KK = 256,
      pK = 10,
      XK = 4,
      bp = 65536,
      eK = new TextDecoder;
    let lK = kK.p,
      vp = -1;
    const CK = new Map,
      hK = new Map;
    let DK = 0;
    const MK = new TextEncoder;

    function ap(OO, KO) {
      const pO = MK.encode(JSON.stringify(KO)),
        XO = new Uint8Array(pO.length + 1);
      return XO[0] = OO, XO.set(pO, 1), XO
    }
    const oK = {
        name: "Ag",
        info: null,
        colour: "default",
        ranks: [],
        effects: [],
        health: .5,
        OO: null,
        hideNameSeed: null
      },
      FK = [ap(UO.Nametag, oK), ap(UO.Nametag, {
        ...oK,
        info: {
          content: [{
            str: "Ag"
          }],
          subtitle: ["Ag"]
        }
      }), ap(UO.MultilineText, {
        box: {
          content: ["Ag"]
        },
        shown: null
      }), ...XO.e.map(((OO, KO) => ap(UO.Board, {
        shared: {
          text: "Ag",
          textSize: KO
        },
        w: 0,
        h: 0
      })))];

    function VK(OO) {
      (0, kK.f)().then((() => {
        if (OO()) return;
        const KO = (0, bK.d)(1, 1, {
          willReadFrequently: !0
        });
        var pO;
        KO && (pO = KO.canvas, FK.map((OO => TK(OO, pO))))
      }))
    }
    let LK = kK.v;

    function QK() {
      CK.clear(), hK.clear()
    }

    function zp(OO, KO) {
      const pO = OO.get(KO);
      return void 0 !== pO && (OO.delete(KO), OO.set(KO, pO)), pO
    }

    function AK(OO, KO, pO) {
      OO.set(KO, pO), OO.size > KK && OO.delete(OO.keys().next().value)
    }

    function fK(OO, KO, pO) {
      if (OO === UO.Nametag) {
        let OO = zp(CK, KO);
        return void 0 === OO && (OO = ZO(JSON.parse(KO), pO, lK), AK(CK, KO, OO)), OO
      }
      if (OO === UO.MultilineText) {
        var bK;
        const OO = JSON.parse(KO),
          XO = JSON.stringify(null !== (bK = OO.box) && void 0 !== bK ? bK : null),
          eO = "number" === typeof OO.shown ? OO.shown : null;
        let lO = zp(hK, XO);
        void 0 === lO && (lO = gK(OO.box, pO, lK), AK(hK, XO, lO));
        const vK = null === eO ? null : Math.min(Math.max(0, Math.floor(eO)), lO.chars),
          CO = lO;
        return {
          width: CO.width,
          height: CO.height,
          draw: OO => {
            CO.draw(OO, vK)
          }
        }
      }
      if (OO === UO.Board) return function(OO, KO) {
        var pO;
        if (!KO.canSeePlayerWrittenText) return null;
        const {
          shared: bK,
          w: eO = 0,
          h: lO = 0
        } = OO, vK = !eO;
        let CO;
        if (vK) {
          var hO, DO;
          CO = null !== (hO = null === bK || void 0 === bK || null === (DO = bK.text) || void 0 === DO ? void 0 : DO.toString()) && void 0 !== hO ? hO : ""
        } else {
          if ("string" !== typeof(null === bK || void 0 === bK ? void 0 : bK.text)) return null;
          CO = bK.text
        }
        if ("" === CO.trim()) return null;
        const MO = null !== (pO = null === bK || void 0 === bK ? void 0 : bK.textSize) && void 0 !== pO ? pO : 0,
          aK = XO.e[MO].ingameFontSize;
        let oO = nO,
          FO = qK;
        vK || (CO = (0, XO.m)(CO, MO, eO, lO), oO = (0, XO.s)(eO, lO), FO = Math.min(qK, xK / Math.max(oO.width, oO.height)));
        const VO = Math.round(FO * oO.width),
          LO = Math.round(FO * oO.height),
          QO = FO / qK;
        return {
          width: VO,
          height: LO,
          draw: OO => {
            GO.b.fontSize = aK * QO, GO.b.fontWeight = "bold", GO.b.font = "'Jetbrains Mono', monospace", GO.b.drawText(OO, CO, 0, (-10 - 7 * MO) * QO, VO, LO)
          }
        }
      }(JSON.parse(KO), lK);
      if (OO === UO.Leaderboard) return function(OO, KO, pO) {
        var XO;
        const bK = (0, WO.g)(OO.opts, tK),
          eO = (0, WO.c)(bK, pO),
          lO = {
            top: (0, WO.f)(bK, (0, WO.k)(OO.top)),
            around: null !== (XO = OO.around) && void 0 !== XO ? XO : null,
            showPlayerText: KO.canSeePlayerWrittenText,
            localPlayerDbId: KO.localPlayerDbId
          };
        return {
          width: eO.pixelWidth,
          height: eO.pixelHeight,
          draw: OO => {
            const {
              a: KO,
              d: pO
            } = OO.getTransform();
            (0, WO.b)(OO, Math.round(eO.pixelWidth * KO), Math.round(eO.pixelHeight * pO), eO, bK, lO)
          }
        }
      }(JSON.parse(KO), lK, OK);
      throw new Error(`unknown text plane kind ${OO}`)
    }
    const dK = 2 ** Math.floor(Math.log2(OK));

    function TK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
        XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
      try {
        if (OO.length < 2) return [0, 0];
        const eO = (0, bK.b)(KO);
        if (!eO) return [0, 0];
        const lO = LK();
        let vK;
        lO !== vp && (vp = lO, QK()), eO.save();
        try {
          vK = fK(OO[0], eK.decode(OO.subarray(1)), eO)
        } finally {
          eO.restore()
        }
        if (null === vK || !(vK.width > 0 && vK.height > 0)) return [0, 0];
        const CO = Math.min(1, OK / vK.width, OK / vK.height),
          hO = OO => XO ? function(OO) {
            const KO = 2 ** Math.ceil(Math.log2(OO));
            return Math.min(dK, KO - OO > OO - KO / 2 ? KO / 2 : KO)
          }(OO) : Math.min(OK, Math.ceil(OO * CO)),
          [DO, MO] = [hO(vK.width), hO(vK.height)];
        ! function(OO, KO, pO, XO, bK) {
          const eO = Math.max(OO.width, pO),
            lO = Math.max(OO.height, XO),
            vK = bK || eO * lO > Math.max(XK * pO * XO, bp),
            [CO, hO] = vK ? [pO, XO] : [eO, lO];
          CO === OO.width && hO === OO.height ? KO.clearRect(0, 0, CO, hO) : (OO.width = CO, OO.height = hO)
        }(KO, eO, DO, MO, pO), eO.save();
        try {
          const [OO, KO] = XO ? [DO / vK.width, MO / vK.height] : [CO, CO];
          1 === OO && 1 === KO || eO.scale(OO, KO), vK.draw(eO)
        } finally {
          eO.restore()
        }
        return [DO, MO]
      } catch (eO) {
        ! function(OO, KO) {
          DK < pK && (DK++, console.warn(`[bloxd-wasm-client] ${OO}`, KO))
        }("could not raster a text plane", eO);
        try {
          KO.width = 1
        } catch {}
        return [0, 0]
      }
    }
  },
  7145: (OO, KO) => {
    var pO = "youtube",
      XO = [61802],
      bK = "f167",
      eO = "M549.7 124.1C543.5 100.4 524.9 81.8 501.4 75.5 458.9 64 288.1 64 288.1 64S117.3 64 74.7 75.5C51.2 81.8 32.7 100.4 26.4 124.1 15 167 15 256.4 15 256.4s0 89.4 11.4 132.3c6.3 23.6 24.8 41.5 48.3 47.8 42.6 11.5 213.4 11.5 213.4 11.5s170.8 0 213.4-11.5c23.5-6.3 42-24.2 48.3-47.8 11.4-42.9 11.4-132.3 11.4-132.3s0-89.4-11.4-132.3zM232.2 337.6l0-162.4 142.7 81.2-142.7 81.2z";
    KO.e = {
      prefix: "fab",
      iconName: pO,
      icon: [576, 512, XO, bK, eO]
    }, KO.g = KO.e
  },
  5966: (OO, KO) => {
    Object.defineProperty(KO, "__esModule", {
      value: !0
    });
    var pO = "bolt",
      XO = [9889, "zap"],
      bK = "f0e7",
      eO = "M338.8-9.9c11.9 8.6 16.3 24.2 10.9 37.8L271.3 224 416 224c13.5 0 25.5 8.4 30.1 21.1s.7 26.9-9.6 35.5l-288 240c-11.3 9.4-27.4 9.9-39.3 1.3s-16.3-24.2-10.9-37.8L176.7 288 32 288c-13.5 0-25.5-8.4-30.1-21.1s-.7-26.9 9.6-35.5l288-240c11.3-9.4 27.4-9.9 39.3-1.3z";
    KO.definition = {
      prefix: "fas",
      iconName: pO,
      icon: [448, 512, XO, bK, eO]
    }, KO.faBolt = KO.definition, KO.prefix = "fas", KO.iconName = pO, KO.width = 448, KO.height = 512, KO.ligatures = XO, KO.unicode = bK, KO.svgPathData = eO, KO.aliases = XO
  },
  6628: (OO, KO) => {
    var pO = "person-military-pointing",
      XO = [],
      bK = "e54a",
      eO = "M214.9 14.1C202 15.2 192 26 192 39 192 52.8 203.2 64 217 64l151 0c8.8 0 16-7.2 16-16l0-30.6C384 8 376 .7 366.7 1.4L214.9 14.1zM208 112c0 44.2 35.8 80 80 80s80-35.8 80-80c0-5.5-.6-10.8-1.6-16L209.6 96c-1 5.2-1.6 10.5-1.6 16zM40 224c-22.1 0-40 17.9-40 40s17.9 40 40 40l152 0 0 89.4 162.8-162.8c-13.3-4.3-27.3-6.5-41.6-6.5L40 224zm345.7 20.9l-171.1 171.1 169.4 0 0-46.3 53.6 90.6c11.2 19 35.8 25.3 54.8 14.1s25.3-35.8 14.1-54.8L430.3 290.8c-11.2-19-26.6-34.5-44.6-45.9zM192 448l0 32c0 17.7 14.3 32 32 32l128 0c17.7 0 32-14.3 32-32l0-32-192 0z";
    KO.b = {
      prefix: "fas",
      iconName: pO,
      icon: [512, 512, XO, bK, eO]
    }, KO.f = KO.b
  },
  6767: (OO, KO) => {
    var pO = "sparkle",
      XO = [],
      bK = "e5d6",
      eO = "M278.5 15.6C275 6.2 266 0 256 0s-19 6.2-22.5 15.6L174.2 174.2 15.6 233.5C6.2 237 0 246 0 256s6.2 19 15.6 22.5l158.6 59.4 59.4 158.6C237 505.8 246 512 256 512s19-6.2 22.5-15.6l59.4-158.6 158.6-59.4C505.8 275 512 266 512 256s-6.2-19-15.6-22.5L337.8 174.2 278.5 15.6z";
    KO.d = {
      prefix: "fas",
      iconName: pO,
      icon: [512, 512, XO, bK, eO]
    }, KO.h = KO.d
  },
  6858: (OO, KO) => {
    var pO = "user",
      XO = [128100, 62144, 62470, "user-alt", "user-large"],
      bK = "f007",
      eO = "M224 248a120 120 0 1 0 0-240 120 120 0 1 0 0 240zm-29.7 56C95.8 304 16 383.8 16 482.3 16 498.7 29.3 512 45.7 512l356.6 0c16.4 0 29.7-13.3 29.7-29.7 0-98.5-79.8-178.3-178.3-178.3l-59.4 0z";
    KO.d = {
      prefix: "fas",
      iconName: pO,
      icon: [448, 512, XO, bK, eO]
    }, KO.f = KO.d
  },
  6998: (OO, KO) => {
    var pO = "wrench",
      XO = [128295],
      bK = "f0ad",
      eO = "M509.4 98.6c7.6-7.6 20.3-5.7 24.1 4.3 6.8 17.7 10.5 37 10.5 57.1 0 88.4-71.6 160-160 160-17.5 0-34.4-2.8-50.2-8L146.9 498.9c-28.1 28.1-73.7 28.1-101.8 0s-28.1-73.7 0-101.8L232 210.2c-5.2-15.8-8-32.6-8-50.2 0-88.4 71.6-160 160-160 20.1 0 39.4 3.7 57.1 10.5 10 3.8 11.8 16.5 4.3 24.1l-88.7 88.7c-3 3-4.7 7.1-4.7 11.3l0 41.4c0 8.8 7.2 16 16 16l41.4 0c4.2 0 8.3-1.7 11.3-4.7l88.7-88.7z";
    KO.e = {
      prefix: "fas",
      iconName: pO,
      icon: [576, 512, XO, bK, eO]
    }, KO.i = KO.e
  },
  7013: (OO, KO, pO) => {
    var XO = pO(5966);
    KO.d = {
      prefix: XO.prefix,
      iconName: XO.iconName,
      icon: [XO.width, XO.height, XO.aliases, XO.unicode, XO.svgPathData]
    }, KO.e = KO.d, XO.prefix, XO.iconName, XO.width, XO.height, XO.aliases, XO.unicode, XO.svgPathData, XO.aliases
  },
  38897: (OO, KO, pO) => {
    OO.exports = pO.p + "static/media/JetBrainsMonoNL-ExtraBold.e920f8e3b489009b4837.woff2"
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);