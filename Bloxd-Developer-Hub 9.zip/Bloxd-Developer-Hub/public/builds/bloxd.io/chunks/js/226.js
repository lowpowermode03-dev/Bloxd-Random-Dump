export const id = 226;
export const ids = [226];
export const modules = {
  38819: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      f: () => lO
    });
    var XO = pO(1561);
    let bK = !1;

    function eO() {
      bK = !0
    }

    function lO() {
      bK && (bK = !1, (0, XO.d)())
    }
  },
  38783: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => FO,
      i: () => aK,
      k: () => oO
    });
    var XO = pO(1567),
      bK = pO(1139),
      eO = pO(38674),
      lO = pO(38700),
      vK = pO(38709),
      CO = pO(38723);
    const hO = new bK.c;
    let DO = !1;

    function MO(OO) {
      const KO = (0, eO.g)();
      return null !== KO && +OO === KO.api.localId
    }

    function aK() {
      DO || (DO = !0, (0, CO.n)(lO.m, (OO => {
        var KO, pO;
        const XO = (0, vK.d)(lO.m, OO);
        if (!(0, vK.b)(XO)) return;
        const bK = XO;
        MO(bK.Qm) && oO(bK.Am, {
          icon: bK.v_,
          level: bK.y_,
          displayName: null !== (KO = bK.Tm) && void 0 !== KO ? KO : null,
          durationMs: null !== (pO = bK.Q0) && void 0 !== pO ? pO : null
        })
      })), (0, CO.n)(lO.S, (OO => {
        const KO = (0, vK.d)(lO.S, OO);
        if (!(0, vK.b)(KO)) return;
        const pO = KO;
        MO(pO.Qm) && XO.b.remove(pO.Am)
      })), (0, CO.g)((() => {
        XO.b.clear()
      })))
    }

    function oO(OO, KO) {
      XO.b.update(OO, KO), hO.forEach((KO => {
        KO(OO)
      }))
    }
    const FO = {
      localEffectUpdated: {
        watch: OO => hO.add(OO)
      }
    }
  },
  38790: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO
    });
    var XO = pO(3943),
      bK = pO(3934),
      eO = pO(38717),
      lO = pO(38723);
    const vK = new Set(XO.z),
      CO = XO.z.map((OO => (new TextEncoder).encode(OO))),
      hO = new Map;

    function DO(OO, KO) {
      var pO;
      return null === (pO = hO.get(OO)) || void 0 === pO ? void 0 : pO[KO]
    }(0, lO.n)(XO.Hb.NewOtherEntitySettings, (OO => {
      OO.payloadKind === bK.cc.Msgpack && CO.some((KO => function(OO, KO) {
        const pO = KO[0];
        for (let XO = OO.indexOf(pO); - 1 !== XO && XO + KO.length <= OO.length; XO = OO.indexOf(pO, XO + 1)) {
          let pO = 1;
          for (; pO < KO.length && OO[XO + pO] === KO[pO];) pO++;
          if (pO === KO.length) return !0
        }
        return !1
      }(OO.payload, KO))) && function(OO) {
        if (null === OO || "object" !== typeof OO || null === OO.settings || "object" !== typeof OO.settings) return;
        const KO = String(OO.eId),
          pO = OO.settings;
        let XO = hO.get(KO);
        for (const bK in pO) {
          if (!vK.has(bK)) continue;
          const OO = pO[bK];
          null === OO || void 0 === OO ? XO && delete XO[bK] : (XO ??= {}, XO[bK] = OO)
        }
        XO && hO.set(KO, XO)
      }((0, eO.c)(OO.payload))
    })), (0, lO.g)((() => {
      hO.clear()
    }))
  },
  38776: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      g: () => hO,
      j: () => MO
    });
    var XO = pO(37390),
      bK = pO(1558),
      eO = pO(1139),
      lO = pO(38700),
      vK = pO(38709),
      CO = pO(38723);
    const hO = new XO.d;
    let DO = {};

    function MO(OO) {
      return DO[OO]
    }
    const aK = new eO.c;

    function oO(OO) {
      return aK.add(OO)
    }

    function FO(OO) {
      aK.callEach(OO, "a roster listener")
    }(0, CO.n)(lO.Z, (OO => {
      const KO = (0, vK.d)(lO.Z, OO);
      if (void 0 === KO) return;
      const pO = KO.W4.some((OO => {
          let {
            y5: KO,
            E1: pO
          } = OO;
          return null !== pO && hO.has(KO) && hO.getName(KO) !== pO
        })),
        {
          added: XO,
          removed: eO,
          settingChanges: CO
        } = hO.apply(KO),
        DO = new Set;
      for (const bK of CO)
        for (const OO in bK.settings) DO.add(OO);
      const MO = pO || XO.length > 0 || eO.length > 0;
      (MO || DO.has("hideNameSeed")) && function() {
        const OO = new Map;
        for (const KO of hO.ids()) {
          const pO = hO.getName(KO),
            XO = hO.getSetting(KO, "hideNameSeed");
          void 0 !== pO && void 0 !== XO && null !== XO && OO.set(pO, XO)
        }
        bK.c.replaceAll(OO)
      }(), FO({
        kind: "roster",
        members: MO,
        settings: DO
      })
    })), (0, CO.n)(lO.O, (OO => {
      const KO = (0, vK.d)(lO.O, OO);
      if (void 0 !== KO) {
        for (const {
            EW: OO,
            oV: pO,
            VV: XO
          }
          of KO) DO[OO] = {
          ...DO[OO],
          [pO]: XO
        };
        FO({
          kind: "cosmetics",
          updates: KO
        })
      }
    })), (0, CO.g)((() => {
      hO.clear(), DO = {}, bK.c.clear(), FO({
        kind: "reset"
      })
    })), (0, CO.k)((() => {
      hO.clear(), FO({
        kind: "reset"
      })
    }))
  },
  38803: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => uO,
      g: () => LO,
      i: () => YO,
      k: () => wO
    });
    var XO = pO(1123),
      bK = pO(518),
      eO = pO(94),
      lO = pO(3943),
      vK = pO(38667),
      CO = pO(38698),
      hO = pO(38674),
      DO = pO(38790),
      MO = pO(38776),
      aK = pO(38709),
      oO = pO(38723);

    function FO(OO) {
      let {
        deadEId: KO,
        killerEId: pO,
        killerLifeformType: XO,
        withItem: bK,
        killstreak: eO
      } = OO;
      return {
        killer: fO({
          eId: pO,
          lifeformType: XO
        }),
        victim: fO({
          eId: KO
        }),
        withItem: bK,
        killstreak: eO
      }
    }

    function VO(OO) {
      let {
        killer: KO,
        victim: pO,
        withItem: XO
      } = OO;
      return {
        killer: fO(KO),
        victim: fO(pO),
        withItem: XO,
        killstreak: 0
      }
    }

    function LO(OO) {
      IO && gK((() => "killed" === OO.kind ? FO(OO.body) : VO(OO.body)))
    }
    const QO = "#2727f1",
      zK = "#912c2c";

    function AO(OO, KO) {
      var pO;
      return MO.g.has(OO) ? null === (pO = MO.g.getSettings(OO)) || void 0 === pO ? void 0 : pO[KO] : (0, DO.d)(OO, KO)
    }

    function fO(OO) {
      var KO, pO, lO, vK, DO;
      let {
        eId: aK,
        name: oO,
        colour: FO,
        lifeformType: VO
      } = OO;
      if (void 0 === aK || null === aK || "" === aK) {
        const OO = oO || null;
        return {
          id: null,
          shownName: OO,
          lifeformType: null === OO && null !== VO && void 0 !== VO ? VO : null,
          colour: FO || null,
          local: !1,
          realName: null
        }
      }
      const LO = String(aK),
        fO = null === (KO = (0, hO.g)()) || void 0 === KO ? void 0 : KO.api,
        dO = void 0 !== fO && String(fO.localId) === LO,
        TO = null !== (pO = MO.g.getName(LO)) && void 0 !== pO ? pO : null,
        NO = null !== (lO = AO(LO, "hideNameSeed")) && void 0 !== lO ? lO : null;
      let IO = null === TO ? null : (0, XO.c)(TO, !eO.featureFlags.canSeeRealPlayerNames, NO) || null,
        yK = null;
      if (null === IO && void 0 !== fO) {
        const OO = fO.getEntityType(LO);
        "Player" !== OO && (IO = (0, CO.f)(fO, +LO) || null), yK = bK.h.includes(OO) ? OO : null
      }
      return {
        id: LO,
        shownName: IO,
        lifeformType: null === IO && null !== (vK = null !== (DO = yK) && void 0 !== DO ? DO : VO) && void 0 !== vK ? vK : null,
        colour: FO || AO(LO, "killfeedColour") || (dO ? QO : zK),
        local: dO,
        realName: TO
      }
    }
    const dO = 32;
    let TO = [],
      NO = null,
      IO = !1,
      yK = !1;

    function gK(OO) {
      null === NO ? (TO.length === dO && TO.shift(), TO.push(OO)) : NO(OO())
    }

    function uO() {
      yK || (yK = !0, (0, oO.n)(lO.Hb.PlayerKilled, (OO => {
        const KO = (0, aK.g)(OO);
        (0, aK.b)(KO) && gK((() => FO(KO)))
      })), (0, oO.n)(lO.Hb.CustomKillfeed, (OO => {
        const KO = (0, aK.g)(OO);
        (0, aK.b)(KO) && (0, aK.b)(KO.killer) && (0, aK.b)(KO.victim) && gK((() => VO(KO)))
      })), (0, oO.g)((() => {
        TO = []
      })))
    }
    const EO = Object.freeze([0, 0, 0]),
      jK = [0, 0, 0],
      YO = {
        kill: {
          watch(OO) {
            if (IO = !0, 0 === TO.length) return NO = OO, () => {
              IO = !1, NO = null
            };
            const KO = setTimeout((() => {
              const KO = TO;
              TO = [], NO = OO;
              for (const XO of KO) try {
                OO(XO())
              } catch (pO) {
                console.error("[bloxd-wasm-client] a kept kill couldn't be handed on", pO)
              }
            }), 0);
            return () => {
              clearTimeout(KO), IO = !1, NO = null
            }
          }
        }
      },
      wO = {
        localPos() {
          const OO = (0, hO.g)();
          if (null === OO) return EO;
          const KO = OO.api.apiView;
          for (let pO = 0; pO < 3; pO++) jK[pO] = vK.t.localPos(KO, 0, pO);
          return jK
        }
      }
  },
  37390: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor() {
        this.members = new Map
      }
      apply(OO) {
        const KO = {
          added: [],
          removed: [],
          settingChanges: []
        };
        for (const XO of OO.W4) {
          let OO = this.members.get(XO.y5);
          if (OO || (OO = {
              name: null,
              settings: {}
            }, this.members.set(XO.y5, OO), KO.added.push(XO.y5)), null !== XO.E1 && (OO.name = XO.E1), null !== XO.Y1 || XO.i5.length > 0) {
            const pO = null === XO.Y1 ? {} : JSON.parse(XO.Y1);
            Object.assign(OO.settings, pO);
            for (const KO of XO.i5) delete OO.settings[KO], pO[KO] = void 0;
            KO.settingChanges.push({
              playerId: XO.y5,
              settings: pO
            })
          }
        }
        for (const XO of OO.t5) {
          const OO = this.members.get(XO);
          var pO;
          if (OO) this.members.delete(XO), KO.removed.push({
            playerId: XO,
            name: null !== (pO = OO.name) && void 0 !== pO ? pO : void 0
          })
        }
        return KO
      }
      has(OO) {
        return this.members.has(OO)
      }
      ids() {
        return [...this.members.keys()]
      }
      getName(OO) {
        var KO, pO;
        return null !== (KO = null === (pO = this.members.get(OO)) || void 0 === pO ? void 0 : pO.name) && void 0 !== KO ? KO : void 0
      }
      getSettings(OO) {
        var KO;
        return null === (KO = this.members.get(OO)) || void 0 === KO ? void 0 : KO.settings
      }
      getSetting(OO, KO) {
        var pO;
        return null === (pO = this.members.get(OO)) || void 0 === pO ? void 0 : pO.settings[KO]
      }
      clear() {
        this.members.clear()
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);