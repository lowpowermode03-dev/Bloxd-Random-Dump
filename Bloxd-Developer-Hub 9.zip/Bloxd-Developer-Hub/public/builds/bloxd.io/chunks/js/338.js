export const id = 338;
export const ids = [338];
export const modules = {
  59146: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      applyLightFoOffset: () => lO,
      getFloatingOriginOffset: () => bK,
      lightFoVersion: () => eO,
      wrapRenderableForFO: () => vK
    });
    var XO = pO(39747);

    function bK(OO) {
      const KO = OO.camera;
      if (!KO) return {
        x: 0,
        y: 0,
        z: 0
      };
      const pO = KO.worldMatrix;
      return {
        x: pO[12],
        y: pO[13],
        z: pO[14]
      }
    }

    function eO(OO) {
      return OO.camera ? OO.camera.worldMatrixVersion : 0
    }

    function lO(OO, KO) {
      const pO = KO.camera?.worldMatrix;
      if (!pO) return;
      const bK = pO[12],
        eO = pO[13],
        lO = pO[14];
      let vK = 0;
      for (const CO of KO.lights) {
        if (vK >= XO.b) break;
        if (!CO._writeLightUbo) continue;
        const KO = 4 + 16 * vK,
          pO = OO[KO + 3];
        if (0 === pO || 2 === pO) {
          const pO = CO.worldMatrix;
          OO[KO] = pO[12] - bK, OO[KO + 1] = pO[13] - eO, OO[KO + 2] = pO[14] - lO
        }
        vK++
      }
    }

    function vK(OO, KO, pO) {
      let XO = -1;
      return () => {
        const bK = KO.camera ? KO.camera.worldMatrixVersion : -1;
        bK !== XO && (pO(), XO = bK), OO()
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);