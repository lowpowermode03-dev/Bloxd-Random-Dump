export const id = 210;
export const ids = [210];
export const modules = {
  35639: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      d: () => XO,
      e: () => bK
    });
    const XO = 1 / 2.2,
      bK = 2.2;
    Math.sqrt(5);
    let eO = .001
  },
  35664: (OO, KO, pO) => {
    function XO(OO) {
      return parseInt(OO.toString().replace(/\W/g, ""))
    }

    function bK(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1401298e-51;
      return Math.abs(OO - KO) <= pO
    }

    function eO(OO, KO, pO) {
      let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1401298e-51;
      return OO < KO - XO || OO > pO + XO
    }

    function lO(OO, KO) {
      return OO === KO ? OO : Math.random() * (KO - OO) + OO
    }

    function vK(OO, KO, pO) {
      return OO + (KO - OO) * pO
    }

    function CO(OO, KO, pO) {
      let XO = LO(KO - OO, 360);
      return XO > 180 && (XO -= 360), OO + XO * aK(pO)
    }

    function hO(OO, KO, pO) {
      let XO;
      return XO = OO != KO ? aK((pO - OO) / (KO - OO)) : 0, XO
    }

    function DO(OO, KO, pO, XO, bK) {
      const eO = bK * bK,
        lO = bK * eO;
      return OO * (2 * lO - 3 * eO + 1) + pO * (-2 * lO + 3 * eO) + KO * (lO - 2 * eO + bK) + XO * (lO - eO)
    }

    function MO(OO, KO, pO, XO, bK) {
      const eO = bK * bK;
      return 6 * (eO - bK) * OO + (3 * eO - 4 * bK + 1) * KO + 6 * (-eO + bK) * pO + (3 * eO - 2 * bK) * XO
    }

    function aK(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      return Math.min(pO, Math.max(KO, OO))
    }

    function oO(OO) {
      return OO -= 2 * Math.PI * Math.floor((OO + Math.PI) / (2 * Math.PI))
    }

    function FO(OO) {
      const KO = OO.toString(16);
      return OO <= 15 ? ("0" + KO).toUpperCase() : KO.toUpperCase()
    }

    function VO(OO) {
      if (Math.log2) return Math.floor(Math.log2(OO));
      if (OO < 0) return NaN;
      if (0 === OO) return -1 / 0;
      let KO = 0;
      if (OO < 1) {
        for (; OO < 1;) KO++, OO *= 2;
        KO = -KO
      } else if (OO > 1)
        for (; OO > 1;) KO++, OO = Math.floor(OO / 2);
      return KO
    }

    function LO(OO, KO) {
      return OO - Math.floor(OO / KO) * KO
    }

    function QO(OO, KO, pO) {
      return (OO - KO) / (pO - KO)
    }

    function zK(OO, KO, pO) {
      return OO * (pO - KO) + KO
    }

    function AO(OO, KO) {
      let pO = LO(KO - OO, 360);
      return pO > 180 && (pO -= 360), pO
    }

    function fO(OO, KO) {
      const pO = LO(OO, 2 * KO);
      return KO - Math.abs(pO - KO)
    }

    function dO(OO, KO, pO) {
      let XO = aK(pO);
      return XO = -2 * XO * XO * XO + 3 * XO * XO, KO * XO + OO * (1 - XO)
    }

    function TO(OO, KO, pO) {
      let XO;
      return XO = Math.abs(KO - OO) <= pO ? KO : OO + Math.sign(KO - OO) * pO, XO
    }

    function NO(OO, KO, pO) {
      const XO = AO(OO, KO);
      let bK;
      return bK = -pO < XO && XO < pO ? KO : TO(OO, KO = OO + XO, pO), bK
    }

    function IO(OO, KO, pO) {
      return (OO - KO) / (pO - KO)
    }

    function yK(OO, KO, pO) {
      return (pO - KO) * OO + KO
    }

    function gK(OO, KO) {
      const pO = OO % KO;
      return 0 === pO ? KO : gK(KO, pO)
    }
    pO.r(KO), pO.d(KO, {
      Clamp: () => aK,
      DeltaAngle: () => AO,
      Denormalize: () => zK,
      ExtractAsInt: () => XO,
      Hermite: () => DO,
      Hermite1stDerivative: () => MO,
      HighestCommonFactor: () => gK,
      ILog2: () => VO,
      InverseLerp: () => hO,
      Lerp: () => vK,
      LerpAngle: () => CO,
      MoveTowards: () => TO,
      MoveTowardsAngle: () => NO,
      Normalize: () => QO,
      NormalizeRadians: () => oO,
      OutsideRange: () => eO,
      PercentToRange: () => yK,
      PingPong: () => fO,
      RandomRange: () => lO,
      RangeToPercent: () => IO,
      Repeat: () => LO,
      SmoothStep: () => dO,
      ToHex: () => FO,
      WithinEpsilon: () => bK
    })
  },
  35624: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      Matrix: () => XO.c,
      Quaternion: () => XO.g,
      RegisterMathVector: () => XO.i,
      TmpVectors: () => XO.j,
      Vector2: () => XO.m,
      WX: () => XO.o,
      Vector4: () => XO.s
    });
    var XO = pO(35632);
    (0, XO.i)()
  },
  35641: (OO, KO, pO) => {
    function XO(OO, KO) {
      const pO = [];
      for (let XO = 0; XO < OO; ++XO) pO.push(KO());
      return pO
    }

    function bK(OO, KO) {
      return XO(OO, KO)
    }
    pO.d(KO, {
      d: () => XO,
      f: () => bK,
      g: () => lO
    });
    const eO = ["push", "splice", "pop", "shift", "unshift"];

    function lO(OO, KO) {
      const pO = eO.map((pO => function(OO, KO, pO) {
        const XO = OO[KO];
        if ("function" !== typeof XO) return null;
        const bK = function() {
          const XO = OO.length,
            eO = bK.previous.apply(OO, arguments);
          return pO(KO, XO), eO
        };
        return XO.next = bK, bK.previous = XO, OO[KO] = bK, () => {
          const pO = bK.previous;
          if (!pO) return;
          const XO = bK.next;
          XO ? (pO.next = XO, XO.previous = pO) : (pO.next = void 0, OO[KO] = pO), bK.next = void 0, bK.previous = void 0
        }
      }(OO, pO, KO)));
      return () => {
        for (const OO of pO) OO?.()
      }
    }
  },
  35676: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO,
      h: () => bK
    });
    const XO = {};

    function bK(OO, KO) {
      XO[OO] = KO
    }

    function eO(OO) {
      return XO[OO]
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);