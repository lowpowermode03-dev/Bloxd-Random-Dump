export const id = 227;
export const ids = [227];
export const modules = {
  37456: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      f: () => lO
    });
    var XO = pO(26);
    let bK = !1;

    function eO() {
      return bK
    }

    function lO(OO) {
      bK !== OO && (bK = OO, XO.i.pl("replayViewer|videoExportChanged"))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);