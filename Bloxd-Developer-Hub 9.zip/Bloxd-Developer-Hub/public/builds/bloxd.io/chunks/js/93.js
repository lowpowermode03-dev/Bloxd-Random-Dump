export const id = 93;
export const ids = [93];
export const modules = {
  34948: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => CO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(63),
      lO = pO(3755),
      vK = pO(976);

    function CO(OO) {
      let {
        locked: KO,
        children: pO
      } = OO;
      const XO = (0, eO.useRef)(null),
        CO = (0, lO.d)(XO, "y");
      return (0, vK.jsx)("div", {
        ref: XO,
        className: bK()("CreateCustomLobbyBody", {
          CreateCustomLobbyBodyMoreAbove: CO.before,
          CreateCustomLobbyBodyMoreBelow: CO.after
        }),
        "data-pad-ignore": KO || void 0,
        children: pO
      })
    }
  },
  34993: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      showFirstWorldSetupPopup: () => FO
    });
    pO(4061), pO(34932);
    var XO = pO(3812),
      bK = pO(63),
      eO = pO(3764),
      lO = pO(1051),
      vK = pO(1187),
      CO = pO(34948),
      hO = pO(1271),
      DO = pO(2737),
      MO = pO(34940),
      aK = pO(3803),
      oO = pO(976);

    function FO(OO) {
      const KO = {
        requested: !1,
        closed: !1
      };
      vK.NotificationProvider.showCustomPopup({
        body: pO => (0, oO.jsx)(VO, {
          flow: KO,
          close: pO,
          ...OO
        }),
        middleScreenPopupClassName: "CreateCustomLobbyPopup",
        onClose: () => {
          KO.closed = !0, KO.requested || (0, aK.e)()
        }
      })
    }

    function VO(OO) {
      let {
        flow: KO,
        close: pO,
        onCreating: vK,
        onCreated: FO,
        join: VO
      } = OO;
      const {
        t: LO
      } = (0, lO.D)(), [QO, zK] = (0, bK.useState)(XO.r), [AO, fO] = (0, bK.useState)(!1), [dO, TO] = (0, bK.useState)(""), NO = (0, DO.b)();
      (0, bK.useEffect)((() => {
        (0, aK.k)()
      }), []);
      return (0, oO.jsxs)("div", {
        className: "CreateCustomLobby",
        children: [(0, oO.jsx)("div", {
          className: "CreateCustomLobbyTitleContainer",
          children: (0, oO.jsx)("div", {
            className: "CreateCustomLobbyTitle",
            children: LO("homePage:myWorld")
          })
        }), (0, oO.jsx)(CO.b, {
          locked: AO,
          children: (0, oO.jsxs)("div", {
            className: "CreateCustomLobbyFields",
            children: [(0, oO.jsx)(MO.b, {
              value: QO.defaultGamemode,
              onChange: OO => {
                (0, XO.t)(OO) && OO !== QO.defaultGamemode && ((0, aK.g)({
                  defaultGamemode: OO
                }), zK({
                  ...QO,
                  defaultGamemode: OO
                }))
              },
              showAll: !1,
              disabled: AO
            }), (0, oO.jsx)(MO.c, {
              mapTypes: XO.f,
              value: QO.mapType,
              onChange: OO => {
                (0, XO.w)(OO) && OO !== QO.mapType && ((0, aK.g)({
                  mapType: OO
                }), zK({
                  ...QO,
                  mapType: OO
                }))
              },
              showAll: !1,
              disabled: AO
            })]
          })
        }), (0, oO.jsxs)("div", {
          className: "CreateCustomLobbyFooter",
          children: [(0, oO.jsx)(hO.m, {
            className: "CreateCustomLobbyButton",
            padDefaultFocus: !0,
            loading: AO,
            onClick: () => {
              KO.requested = !0, fO(!0), vK(!0), TO(""), (0, aK.j)(QO), eO.e.createPersonalWorld(QO).then((OO => {
                vK(!1), FO(OO), !KO.closed && NO.current ? (pO(), VO(OO)) : (0, aK.e)()
              }), (OO => {
                console.error("Failed to create personal world:", OO), vK(!1), KO.requested = !1, !KO.closed && NO.current ? (TO(OO.message), fO(!1)) : (0, aK.e)()
              }))
            },
            children: LO("general:play")
          }), dO && (0, oO.jsx)("div", {
            className: "CreateCustomLobbyError AnimFadeInScaleUp",
            children: dO
          })]
        })]
      })
    }
  },
  34940: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => hO,
      c: () => DO
    });
    pO(63);
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(3812),
      lO = pO(243),
      vK = pO(1051),
      CO = pO(976);

    function hO(OO) {
      let {
        value: KO,
        onChange: pO,
        showAll: XO,
        disabled: hO = !1
      } = OO;
      const {
        t: DO
      } = (0, vK.D)();
      return (0, CO.jsxs)("div", {
        className: bK()("BloxdForm GamemodeForm", {
          BasicOptions: !XO
        }),
        children: [(0, CO.jsx)("div", {
          className: "SectionTitle",
          children: DO("classic:defaultGamemode")
        }), (0, CO.jsx)("div", {
          className: "SectionBody",
          children: eO.B.map((OO => XO || (0, eO.t)(OO) ? (0, CO.jsx)("button", {
            type: "button",
            className: bK()("WorldGamemode", {
              Selected: KO === OO
            }),
            disabled: hO,
            onClick: () => {
              pO(OO)
            },
            style: {
              "--background-image": `url(${lO.s[OO]})`
            },
            children: lO.r[OO]
          }, OO) : null))
        })]
      })
    }

    function DO(OO) {
      let {
        mapTypes: KO,
        value: pO,
        onChange: XO,
        showAll: hO,
        disabled: DO = !1,
        children: MO
      } = OO;
      const {
        t: aK
      } = (0, vK.D)();
      return (0, CO.jsxs)("div", {
        className: bK()("BloxdForm MapTypeForm", {
          BasicOptions: !hO
        }),
        children: [(0, CO.jsx)("div", {
          className: "SectionTitle",
          children: aK("customLobby:mapType")
        }), (0, CO.jsx)("div", {
          className: "SectionBody",
          children: KO.map((OO => hO || (0, eO.w)(OO) ? (0, CO.jsx)("button", {
            type: "button",
            className: bK()("MapType", {
              Selected: pO === OO
            }),
            disabled: DO,
            onClick: () => {
              XO(OO)
            },
            style: {
              "--background-image": `url(${lO.n[OO]})`
            },
            children: lO.j[OO]
          }, OO) : null))
        }), MO]
      })
    }
  },
  4061: () => {},
  34932: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);