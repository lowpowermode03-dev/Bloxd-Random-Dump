export const id = 99;
export const ids = [99];
export const modules = {
  4111: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(1056);
    async function bK(OO) {
      const KO = await fetch(`${XO.clientSideServerUrls.s3Url}/${OO}`, {
        headers: {
          Accept: "application/json"
        }
      });
      if (404 === KO.status || 403 === KO.status) return null;
      if (!KO.ok) throw new Error(`Failed to download the texture pack (${KO.status})`);
      return await KO.json()
    }
  },
  41344: (OO, KO, pO) => {
    pO.d(KO, {
      gamePackSource: () => eO
    });
    var XO = pO(4111),
      bK = pO(1329);

    function eO(OO) {
      return {
        packKey: async KO => (await bK.c.getGame(OO, KO, !0)).customTexturePackKey,
        fetchPack: XO.c
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);