export const id = 294;
export const ids = [294];
export const modules = {
  39865: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      _TGATextureLoader: () => vK
    });
    var XO = pO(37061);

    function bK(OO) {
      let KO = 0;
      return {
        id_length: OO[KO++],
        colormap_type: OO[KO++],
        image_type: OO[KO++],
        colormap_index: OO[KO++] | OO[KO++] << 8,
        colormap_length: OO[KO++] | OO[KO++] << 8,
        colormap_size: OO[KO++],
        origin: [OO[KO++] | OO[KO++] << 8, OO[KO++] | OO[KO++] << 8],
        width: OO[KO++] | OO[KO++] << 8,
        height: OO[KO++] | OO[KO++] << 8,
        pixel_size: OO[KO++],
        flags: OO[17]
      }
    }

    function eO(OO, KO) {
      if (KO.length < 19) return void XO.b.Error("Unable to load TGA file - Not enough data to contain header");
      let pO = 18;
      const eO = bK(KO);
      if (eO.id_length + pO > KO.length) return void XO.b.Error("Unable to load TGA file - Not enough data");
      pO += eO.id_length;
      let vK, CO = !1,
        hO = !1,
        DO = !1;
      switch (eO.image_type) {
        case 9:
          CO = !0;
        case 1:
          hO = !0;
          break;
        case 10:
          CO = !0;
        case 2:
          break;
        case 11:
          CO = !0;
        case 3:
          DO = !0
      }
      const MO = eO.pixel_size >> 3,
        aK = eO.width * eO.height * MO;
      let oO, FO, VO, LO, QO, zK, AO;
      if (hO && (oO = KO.subarray(pO, pO += eO.colormap_length * (eO.colormap_size >> 3))), CO) {
        let OO, XO, bK;
        vK = new Uint8Array(aK);
        let eO = 0;
        const lO = new Uint8Array(MO);
        for (; pO < aK && eO < aK;)
          if (OO = KO[pO++], XO = 1 + (127 & OO), 128 & OO) {
            for (bK = 0; bK < MO; ++bK) lO[bK] = KO[pO++];
            for (bK = 0; bK < XO; ++bK) vK.set(lO, eO + bK * MO);
            eO += MO * XO
          } else {
            for (XO *= MO, bK = 0; bK < XO; ++bK) vK[eO + bK] = KO[pO++];
            eO += XO
          }
      } else vK = KO.subarray(pO, pO + (hO ? eO.width * eO.height : aK));
      switch ((48 & eO.flags) >> 4) {
        default:
        case 2:
          FO = 0, LO = 1, AO = eO.width, VO = 0, QO = 1, zK = eO.height;
          break;
        case 0:
          FO = 0, LO = 1, AO = eO.width, VO = eO.height - 1, QO = -1, zK = -1;
          break;
        case 3:
          FO = eO.width - 1, LO = -1, AO = -1, VO = 0, QO = 1, zK = eO.height;
          break;
        case 1:
          FO = eO.width - 1, LO = -1, AO = -1, VO = eO.height - 1, QO = -1, zK = -1
      }
      const fO = "_getImageData" + (DO ? "Grey" : "") + eO.pixel_size + "bits",
        dO = lO[fO](eO, oO, vK, VO, QO, zK, FO, LO, AO);
      OO.qb()._uploadDataToTextureDirectly(OO, dO)
    }
    const lO = {
      GetTGAHeader: bK,
      UploadContent: eO,
      _getImageData8bits: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = pO,
          DO = KO,
          MO = OO.width,
          aK = OO.height;
        let oO, FO, VO, LO = 0;
        const QO = new Uint8Array(MO * aK * 4);
        for (VO = XO; VO !== eO; VO += bK)
          for (FO = lO; FO !== CO; FO += vK, LO++) oO = hO[LO], QO[4 * (FO + MO * VO) + 3] = 255, QO[4 * (FO + MO * VO) + 2] = DO[3 * oO + 0], QO[4 * (FO + MO * VO) + 1] = DO[3 * oO + 1], QO[4 * (FO + MO * VO) + 0] = DO[3 * oO + 2];
        return QO
      },
      _getImageData16bits: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = pO,
          DO = OO.width,
          MO = OO.height;
        let aK, oO, FO, VO = 0;
        const LO = new Uint8Array(DO * MO * 4);
        for (FO = XO; FO !== eO; FO += bK)
          for (oO = lO; oO !== CO; oO += vK, VO += 2) {
            aK = hO[VO + 0] + (hO[VO + 1] << 8);
            const OO = 255 * ((31744 & aK) >> 10) / 31 | 0,
              KO = 255 * ((992 & aK) >> 5) / 31 | 0,
              pO = 255 * (31 & aK) / 31 | 0;
            LO[4 * (oO + DO * FO) + 0] = OO, LO[4 * (oO + DO * FO) + 1] = KO, LO[4 * (oO + DO * FO) + 2] = pO, LO[4 * (oO + DO * FO) + 3] = 32768 & aK ? 0 : 255
          }
        return LO
      },
      _getImageData24bits: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = pO,
          DO = OO.width,
          MO = OO.height;
        let aK, oO, FO = 0;
        const VO = new Uint8Array(DO * MO * 4);
        for (oO = XO; oO !== eO; oO += bK)
          for (aK = lO; aK !== CO; aK += vK, FO += 3) VO[4 * (aK + DO * oO) + 3] = 255, VO[4 * (aK + DO * oO) + 2] = hO[FO + 0], VO[4 * (aK + DO * oO) + 1] = hO[FO + 1], VO[4 * (aK + DO * oO) + 0] = hO[FO + 2];
        return VO
      },
      _getImageData32bits: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = pO,
          DO = OO.width,
          MO = OO.height;
        let aK, oO, FO = 0;
        const VO = new Uint8Array(DO * MO * 4);
        for (oO = XO; oO !== eO; oO += bK)
          for (aK = lO; aK !== CO; aK += vK, FO += 4) VO[4 * (aK + DO * oO) + 2] = hO[FO + 0], VO[4 * (aK + DO * oO) + 1] = hO[FO + 1], VO[4 * (aK + DO * oO) + 0] = hO[FO + 2], VO[4 * (aK + DO * oO) + 3] = hO[FO + 3];
        return VO
      },
      _getImageDataGrey8bits: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = pO,
          DO = OO.width,
          MO = OO.height;
        let aK, oO, FO, VO = 0;
        const LO = new Uint8Array(DO * MO * 4);
        for (FO = XO; FO !== eO; FO += bK)
          for (oO = lO; oO !== CO; oO += vK, VO++) aK = hO[VO], LO[4 * (oO + DO * FO) + 0] = aK, LO[4 * (oO + DO * FO) + 1] = aK, LO[4 * (oO + DO * FO) + 2] = aK, LO[4 * (oO + DO * FO) + 3] = 255;
        return LO
      },
      _getImageDataGrey16bits: function(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
        const hO = pO,
          DO = OO.width,
          MO = OO.height;
        let aK, oO, FO = 0;
        const VO = new Uint8Array(DO * MO * 4);
        for (oO = XO; oO !== eO; oO += bK)
          for (aK = lO; aK !== CO; aK += vK, FO += 2) VO[4 * (aK + DO * oO) + 0] = hO[FO + 0], VO[4 * (aK + DO * oO) + 1] = hO[FO + 0], VO[4 * (aK + DO * oO) + 2] = hO[FO + 0], VO[4 * (aK + DO * oO) + 3] = hO[FO + 1];
        return VO
      }
    };
    class vK {
      constructor() {
        this.supportCascades = !1
      }
      loadCubeData() {
        throw ".env not supported in Cube."
      }
      loadData(OO, KO, pO) {
        const XO = new Uint8Array(OO.buffer, OO.byteOffset, OO.byteLength),
          lO = bK(XO);
        pO(lO.width, lO.height, KO.generateMipMaps, !1, (() => {
          eO(KO, XO)
        }))
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);