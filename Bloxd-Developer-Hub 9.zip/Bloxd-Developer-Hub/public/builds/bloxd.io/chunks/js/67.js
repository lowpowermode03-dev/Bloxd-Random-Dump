export const id = 67;
export const ids = [67];
export const modules = {
  3870: OO => {
    function KO(OO) {
      return OO instanceof Map ? OO.clear = OO.delete = OO.set = function() {
        throw new Error("map is read-only")
      } : OO instanceof Set && (OO.add = OO.clear = OO.delete = function() {
        throw new Error("set is read-only")
      }), Object.freeze(OO), Object.getOwnPropertyNames(OO).forEach((pO => {
        const XO = OO[pO],
          bK = typeof XO;
        "object" !== bK && "function" !== bK || Object.isFrozen(XO) || KO(XO)
      })), OO
    }
    class pO {
      constructor(OO) {
        void 0 === OO.data && (OO.data = {}), this.data = OO.data, this.isMatchIgnored = !1
      }
      ignoreMatch() {
        this.isMatchIgnored = !0
      }
    }

    function XO(OO) {
      return OO.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;")
    }

    function bK(OO) {
      const KO = Object.create(null);
      for (const eO in OO) KO[eO] = OO[eO];
      for (var pO = arguments.length, XO = new Array(pO > 1 ? pO - 1 : 0), bK = 1; bK < pO; bK++) XO[bK - 1] = arguments[bK];
      return XO.forEach((function(OO) {
        for (const pO in OO) KO[pO] = OO[pO]
      })), KO
    }
    const eO = OO => !!OO.scope;
    class lO {
      constructor(OO, KO) {
        this.buffer = "", this.classPrefix = KO.classPrefix, OO.walk(this)
      }
      addText(OO) {
        this.buffer += XO(OO)
      }
      openNode(OO) {
        if (!eO(OO)) return;
        const KO = ((OO, KO) => {
          let {
            prefix: pO
          } = KO;
          if (OO.startsWith("language:")) return OO.replace("language:", "language-");
          if (OO.includes(".")) {
            const KO = OO.split(".");
            return [`${pO}${KO.shift()}`, ...KO.map(((OO, KO) => `${OO}${"_".repeat(KO+1)}`))].join(" ")
          }
          return `${pO}${OO}`
        })(OO.scope, {
          prefix: this.classPrefix
        });
        this.span(KO)
      }
      closeNode(OO) {
        eO(OO) && (this.buffer += "</span>")
      }
      value() {
        return this.buffer
      }
      span(OO) {
        this.buffer += `<span class="${OO}">`
      }
    }
    const vK = function() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
      const KO = {
        children: []
      };
      return Object.assign(KO, OO), KO
    };
    class CO {
      constructor() {
        this.KV = vK(), this.stack = [this.KV]
      }
      get top() {
        return this.stack[this.stack.length - 1]
      }
      get root() {
        return this.KV
      }
      add(OO) {
        this.top.children.push(OO)
      }
      openNode(OO) {
        const KO = vK({
          scope: OO
        });
        this.add(KO), this.stack.push(KO)
      }
      closeNode() {
        if (this.stack.length > 1) return this.stack.pop()
      }
      closeAllNodes() {
        for (; this.closeNode(););
      }
      toJSON() {
        return JSON.stringify(this.KV, null, 4)
      }
      walk(OO) {
        return this.constructor._walk(OO, this.KV)
      }
      static _walk(OO, KO) {
        return "string" === typeof KO ? OO.addText(KO) : KO.children && (OO.openNode(KO), KO.children.forEach((KO => this._walk(OO, KO))), OO.closeNode(KO)), OO
      }
      static _collapse(OO) {
        "string" !== typeof OO && OO.children && (OO.children.every((OO => "string" === typeof OO)) ? OO.children = [OO.children.join("")] : OO.children.forEach((OO => {
          CO._collapse(OO)
        })))
      }
    }
    class hO extends CO {
      constructor(OO) {
        super(), this.options = OO
      }
      addText(OO) {
        "" !== OO && this.add(OO)
      }
      startScope(OO) {
        this.openNode(OO)
      }
      endScope() {
        this.closeNode()
      }
      __addSublanguage(OO, KO) {
        const pO = OO.root;
        KO && (pO.scope = `language:${KO}`), this.add(pO)
      }
      toHTML() {
        return new lO(this, this.options).value()
      }
      finalize() {
        return this.closeAllNodes(), !0
      }
    }

    function DO(OO) {
      return OO ? "string" === typeof OO ? OO : OO.source : null
    }

    function MO(OO) {
      return FO("(?=", OO, ")")
    }

    function aK(OO) {
      return FO("(?:", OO, ")*")
    }

    function oO(OO) {
      return FO("(?:", OO, ")?")
    }

    function FO() {
      for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
      return KO.map((OO => DO(OO))).join("")
    }

    function VO() {
      for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
      const XO = function(OO) {
        const KO = OO[OO.length - 1];
        return "object" === typeof KO && KO.constructor === Object ? (OO.splice(OO.length - 1, 1), KO) : {}
      }(KO);
      return "(" + (XO.capture ? "" : "?:") + KO.map((OO => DO(OO))).join("|") + ")"
    }

    function LO(OO) {
      return new RegExp(OO.toString() + "|").exec("").length - 1
    }
    const QO = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;

    function zK(OO, KO) {
      let {
        joinWith: pO
      } = KO, XO = 0;
      return OO.map((OO => {
        XO += 1;
        const KO = XO;
        let pO = DO(OO),
          bK = "";
        for (; pO.length > 0;) {
          const OO = QO.exec(pO);
          if (!OO) {
            bK += pO;
            break
          }
          bK += pO.substring(0, OO.index), pO = pO.substring(OO.index + OO[0].length), "\\" === OO[0][0] && OO[1] ? bK += "\\" + String(Number(OO[1]) + KO) : (bK += OO[0], "(" === OO[0] && XO++)
        }
        return bK
      })).map((OO => `(${OO})`)).join(pO)
    }
    const AO = "[a-zA-Z]\\w*",
      fO = "[a-zA-Z_]\\w*",
      dO = "\\b\\d+(\\.\\d+)?",
      TO = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)",
      NO = "\\b(0b[01]+)",
      IO = {
        Ip: "\\\\[\\s\\S]",
        relevance: 0
      },
      yK = {
        scope: "string",
        Ip: "'",
        end: "'",
        illegal: "\\n",
        contains: [IO]
      },
      gK = {
        scope: "string",
        Ip: '"',
        end: '"',
        illegal: "\\n",
        contains: [IO]
      },
      uO = function(OO, KO) {
        const pO = bK({
          scope: "comment",
          Ip: OO,
          end: KO,
          contains: []
        }, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {});
        pO.contains.push({
          scope: "doctag",
          Ip: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
          end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
          excludeBegin: !0,
          relevance: 0
        });
        const XO = VO("I", "a", "is", "so", "us", "to", "at", "if", "in", "it", "on", /[A-Za-z]+['](d|ve|re|ll|t|s|n)/, /[A-Za-z]+[-][a-z]+/, /[A-Za-z][a-z]{2,}/);
        return pO.contains.push({
          Ip: FO(/[ ]+/, "(", XO, /[.]?[:]?([.][ ]|[ ])/, "){3}")
        }), pO
      },
      EO = uO("//", "$"),
      jK = uO("/\\*", "\\*/"),
      YO = uO("#", "$"),
      wO = {
        scope: "number",
        Ip: dO,
        relevance: 0
      },
      iK = {
        scope: "number",
        Ip: TO,
        relevance: 0
      },
      rK = {
        scope: "number",
        Ip: NO,
        relevance: 0
      },
      PO = {
        scope: "regexp",
        Ip: /\/(?=[^/\n]*\/)/,
        end: /\/[gimuy]*/,
        contains: [IO, {
          Ip: /\[/,
          end: /\]/,
          relevance: 0,
          contains: [IO]
        }]
      },
      mK = {
        scope: "title",
        Ip: AO,
        relevance: 0
      },
      sO = {
        scope: "title",
        Ip: fO,
        relevance: 0
      },
      HO = {
        Ip: "\\.\\s*" + fO,
        relevance: 0
      };
    var RO = Object.freeze({
      __proto__: null,
      APOS_STRING_MODE: yK,
      BACKSLASH_ESCAPE: IO,
      BINARY_NUMBER_MODE: rK,
      BINARY_NUMBER_RE: NO,
      COMMENT: uO,
      C_BLOCK_COMMENT_MODE: jK,
      C_LINE_COMMENT_MODE: EO,
      C_NUMBER_MODE: iK,
      C_NUMBER_RE: TO,
      END_SAME_AS_BEGIN: function(OO) {
        return Object.assign(OO, {
          "on:begin": (OO, KO) => {
            KO.data._beginMatch = OO[1]
          },
          "on:end": (OO, KO) => {
            KO.data._beginMatch !== OO[1] && KO.ignoreMatch()
          }
        })
      },
      HASH_COMMENT_MODE: YO,
      IDENT_RE: AO,
      MATCH_NOTHING_RE: /\b\B/,
      METHOD_GUARD: HO,
      NUMBER_MODE: wO,
      NUMBER_RE: dO,
      PHRASAL_WORDS_MODE: {
        Ip: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/
      },
      QUOTE_STRING_MODE: gK,
      REGEXP_MODE: PO,
      RE_STARTERS_RE: "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~",
      SHEBANG: function() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const KO = /^#![ ]*\//;
        return OO.binary && (OO.Ip = FO(KO, /.*\b/, OO.binary, /\b.*/)), bK({
          scope: "meta",
          Ip: KO,
          end: /$/,
          relevance: 0,
          "on:begin": (OO, KO) => {
            0 !== OO.index && KO.ignoreMatch()
          }
        }, OO)
      },
      TITLE_MODE: mK,
      UNDERSCORE_IDENT_RE: fO,
      UNDERSCORE_TITLE_MODE: sO
    });

    function SO(OO, KO) {
      "." === OO.input[OO.index - 1] && KO.ignoreMatch()
    }

    function JO(OO, KO) {
      void 0 !== OO.className && (OO.scope = OO.className, delete OO.className)
    }

    function cK(OO, KO) {
      KO && OO.beginKeywords && (OO.Ip = "\\b(" + OO.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", OO.__beforeBegin = SO, OO.keywords = OO.keywords || OO.beginKeywords, delete OO.beginKeywords, void 0 === OO.relevance && (OO.relevance = 0))
    }

    function BO(OO, KO) {
      Array.isArray(OO.illegal) && (OO.illegal = VO(...OO.illegal))
    }

    function ZO(OO, KO) {
      if (OO.match) {
        if (OO.Ip || OO.end) throw new Error("begin & end are not supported with match");
        OO.Ip = OO.match, delete OO.match
      }
    }

    function GO(OO, KO) {
      void 0 === OO.relevance && (OO.relevance = 1)
    }
    const qK = (OO, KO) => {
        if (!OO.beforeMatch) return;
        if (OO.starts) throw new Error("beforeMatch cannot be used with starts");
        const pO = Object.assign({}, OO);
        Object.keys(OO).forEach((KO => {
          delete OO[KO]
        })), OO.keywords = pO.keywords, OO.Ip = FO(pO.beforeMatch, MO(pO.Ip)), OO.starts = {
          relevance: 0,
          contains: [Object.assign(pO, {
            endsParent: !0
          })]
        }, OO.relevance = 0, delete pO.beforeMatch
      },
      xK = ["of", "and", "for", "in", "not", "or", "if", "then", "parent", "list", "value"];

    function nO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "keyword";
      const XO = Object.create(null);
      return "string" === typeof OO ? bK(pO, OO.split(" ")) : Array.isArray(OO) ? bK(pO, OO) : Object.keys(OO).forEach((function(pO) {
        Object.assign(XO, nO(OO[pO], KO, pO))
      })), XO;

      function bK(OO, pO) {
        KO && (pO = pO.map((OO => OO.toLowerCase()))), pO.forEach((function(KO) {
          const pO = KO.split("|");
          XO[pO[0]] = [OO, WO(pO[0], pO[1])]
        }))
      }
    }

    function WO(OO, KO) {
      return KO ? Number(KO) : function(OO) {
        return xK.includes(OO.toLowerCase())
      }(OO) ? 0 : 1
    }
    const tK = {},
      kK = OO => {
        console.error(OO)
      },
      UO = function(OO) {
        for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
        console.log(`WARN: ${OO}`, ...pO)
      },
      OK = (OO, KO) => {
        tK[`${OO}/${KO}`] || (console.log(`Deprecated as of ${OO}. ${KO}`), tK[`${OO}/${KO}`] = !0)
      },
      KK = new Error;

    function pK(OO, KO, pO) {
      let {
        key: XO
      } = pO, bK = 0;
      const eO = OO[XO],
        lO = {},
        vK = {};
      for (let CO = 1; CO <= KO.length; CO++) vK[CO + bK] = eO[CO], lO[CO + bK] = !0, bK += LO(KO[CO - 1]);
      OO[XO] = vK, OO[XO]._emit = lO, OO[XO]._multi = !0
    }

    function XK(OO) {
      ! function(OO) {
        OO.scope && "object" === typeof OO.scope && null !== OO.scope && (OO.beginScope = OO.scope, delete OO.scope)
      }(OO), "string" === typeof OO.beginScope && (OO.beginScope = {
          _wrap: OO.beginScope
        }), "string" === typeof OO.endScope && (OO.endScope = {
          _wrap: OO.endScope
        }),
        function(OO) {
          if (Array.isArray(OO.Ip)) {
            if (OO.skip || OO.excludeBegin || OO.returnBegin) throw kK("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), KK;
            if ("object" !== typeof OO.beginScope || null === OO.beginScope) throw kK("beginScope must be object"), KK;
            pK(OO, OO.Ip, {
              key: "beginScope"
            }), OO.Ip = zK(OO.Ip, {
              joinWith: ""
            })
          }
        }(OO),
        function(OO) {
          if (Array.isArray(OO.end)) {
            if (OO.skip || OO.excludeEnd || OO.returnEnd) throw kK("skip, excludeEnd, returnEnd not compatible with endScope: {}"), KK;
            if ("object" !== typeof OO.endScope || null === OO.endScope) throw kK("endScope must be object"), KK;
            pK(OO, OO.end, {
              key: "endScope"
            }), OO.end = zK(OO.end, {
              joinWith: ""
            })
          }
        }(OO)
    }

    function bp(OO) {
      function KO(KO, pO) {
        return new RegExp(DO(KO), "m" + (OO.case_insensitive ? "i" : "") + (OO.unicodeRegex ? "u" : "") + (pO ? "g" : ""))
      }
      class pO {
        constructor() {
          this.matchIndexes = {}, this.regexes = [], this.matchAt = 1, this.position = 0
        }
        addRule(OO, KO) {
          KO.position = this.position++, this.matchIndexes[this.matchAt] = KO, this.regexes.push([KO, OO]), this.matchAt += LO(OO) + 1
        }
        compile() {
          0 === this.regexes.length && (this.exec = () => null);
          const OO = this.regexes.map((OO => OO[1]));
          this.matcherRe = KO(zK(OO, {
            joinWith: "|"
          }), !0), this.lastIndex = 0
        }
        exec(OO) {
          this.matcherRe.lastIndex = this.lastIndex;
          const KO = this.matcherRe.exec(OO);
          if (!KO) return null;
          const pO = KO.findIndex(((OO, KO) => KO > 0 && void 0 !== OO)),
            XO = this.matchIndexes[pO];
          return KO.splice(0, pO), Object.assign(KO, XO)
        }
      }
      class XO {
        constructor() {
          this.rules = [], this.multiRegexes = [], this.count = 0, this.lastIndex = 0, this.regexIndex = 0
        }
        getMatcher(OO) {
          if (this.multiRegexes[OO]) return this.multiRegexes[OO];
          const KO = new pO;
          return this.rules.slice(OO).forEach((OO => {
            let [pO, XO] = OO;
            return KO.addRule(pO, XO)
          })), KO.compile(), this.multiRegexes[OO] = KO, KO
        }
        resumingScanAtSamePosition() {
          return 0 !== this.regexIndex
        }
        considerAll() {
          this.regexIndex = 0
        }
        addRule(OO, KO) {
          this.rules.push([OO, KO]), "Ip" === KO.type && this.count++
        }
        exec(OO) {
          const KO = this.getMatcher(this.regexIndex);
          KO.lastIndex = this.lastIndex;
          let pO = KO.exec(OO);
          if (this.resumingScanAtSamePosition())
            if (pO && pO.index === this.lastIndex);
            else {
              const KO = this.getMatcher(0);
              KO.lastIndex = this.lastIndex + 1, pO = KO.exec(OO)
            } return pO && (this.regexIndex += pO.position + 1, this.regexIndex === this.count && this.considerAll()), pO
        }
      }
      if (OO.compilerExtensions || (OO.compilerExtensions = []), OO.contains && OO.contains.includes("self")) throw new Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation.");
      return OO.classNameAliases = bK(OO.classNameAliases || {}),
        function pO(eO, lO) {
          const vK = eO;
          if (eO.isCompiled) return vK;
          [JO, ZO, XK, qK].forEach((OO => OO(eO, lO))), OO.compilerExtensions.forEach((OO => OO(eO, lO))), eO.__beforeBegin = null, [cK, BO, GO].forEach((OO => OO(eO, lO))), eO.isCompiled = !0;
          let CO = null;
          return "object" === typeof eO.keywords && eO.keywords.$pattern && (eO.keywords = Object.assign({}, eO.keywords), CO = eO.keywords.$pattern, delete eO.keywords.$pattern), CO = CO || /\w+/, eO.keywords && (eO.keywords = nO(eO.keywords, OO.case_insensitive)), vK.keywordPatternRe = KO(CO, !0), lO && (eO.Ip || (eO.Ip = /\B|\b/), vK.beginRe = KO(vK.Ip), eO.end || eO.endsWithParent || (eO.end = /\B|\b/), eO.end && (vK.endRe = KO(vK.end)), vK.terminatorEnd = DO(vK.end) || "", eO.endsWithParent && lO.terminatorEnd && (vK.terminatorEnd += (eO.end ? "|" : "") + lO.terminatorEnd)), eO.illegal && (vK.illegalRe = KO(eO.illegal)), eO.contains || (eO.contains = []), eO.contains = [].concat(...eO.contains.map((function(OO) {
            return function(OO) {
              OO.variants && !OO.cachedVariants && (OO.cachedVariants = OO.variants.map((function(KO) {
                return bK(OO, {
                  variants: null
                }, KO)
              })));
              if (OO.cachedVariants) return OO.cachedVariants;
              if (eK(OO)) return bK(OO, {
                starts: OO.starts ? bK(OO.starts) : null
              });
              if (Object.isFrozen(OO)) return bK(OO);
              return OO
            }("self" === OO ? eO : OO)
          }))), eO.contains.forEach((function(OO) {
            pO(OO, vK)
          })), eO.starts && pO(eO.starts, lO), vK.matcher = function(OO) {
            const KO = new XO;
            return OO.contains.forEach((OO => KO.addRule(OO.Ip, {
              rule: OO,
              type: "Ip"
            }))), OO.terminatorEnd && KO.addRule(OO.terminatorEnd, {
              type: "end"
            }), OO.illegal && KO.addRule(OO.illegal, {
              type: "illegal"
            }), KO
          }(vK), vK
        }(OO)
    }

    function eK(OO) {
      return !!OO && (OO.endsWithParent || eK(OO.starts))
    }
    class lK extends Error {
      constructor(OO, KO) {
        super(OO), this.name = "HTMLInjectionError", this.html = KO
      }
    }
    const vp = XO,
      CK = bK,
      hK = Symbol("nomatch"),
      DK = function(OO) {
        const XO = Object.create(null),
          bK = Object.create(null),
          eO = [];
        let lO = !0;
        const vK = "Could not find the language '{}', did you forget to load/include a language module?",
          CO = {
            disableAutodetect: !0,
            name: "Plain text",
            contains: []
          };
        let DO = {
          ignoreUnescapedHTML: !1,
          throwUnescapedHTML: !1,
          noHighlightRe: /^(no-?highlight)$/i,
          languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
          classPrefix: "hljs-",
          cssSelector: "pre code",
          languages: null,
          __emitter: hO
        };

        function LO(OO) {
          return DO.noHighlightRe.test(OO)
        }

        function QO(OO, KO, pO) {
          let XO = "",
            bK = "";
          "object" === typeof KO ? (XO = OO, pO = KO.ignoreIllegals, bK = KO.language) : (OK("10.7.0", "highlight(lang, code, ...args) has been deprecated."), OK("10.7.0", "Please use highlight(code, options) instead.\nhttps://github.com/highlightjs/highlight.js/issues/2277"), bK = OO, XO = KO), void 0 === pO && (pO = !0);
          const eO = {
            code: XO,
            language: bK
          };
          gK("before:highlight", eO);
          const lO = eO.result ? eO.result : zK(eO.language, eO.code, pO);
          return lO.code = eO.code, gK("after:highlight", lO), lO
        }

        function zK(OO, KO, bK, eO) {
          const CO = Object.create(null);

          function hO() {
            if (!gK.keywords) return void EO.addText(jK);
            let OO = 0;
            gK.keywordPatternRe.lastIndex = 0;
            let KO = gK.keywordPatternRe.exec(jK),
              pO = "";
            for (; KO;) {
              pO += jK.substring(OO, KO.index);
              const bK = TO.case_insensitive ? KO[0].toLowerCase() : KO[0],
                eO = (XO = bK, gK.keywords[XO]);
              if (eO) {
                const [OO, XO] = eO;
                if (EO.addText(pO), pO = "", CO[bK] = (CO[bK] || 0) + 1, CO[bK] <= 7 && (YO += XO), OO.startsWith("_")) pO += KO[0];
                else {
                  const pO = TO.classNameAliases[OO] || OO;
                  aK(KO[0], pO)
                }
              } else pO += KO[0];
              OO = gK.keywordPatternRe.lastIndex, KO = gK.keywordPatternRe.exec(jK)
            }
            var XO;
            pO += jK.substring(OO), EO.addText(pO)
          }

          function MO() {
            null != gK.subLanguage ? function() {
              if ("" === jK) return;
              let OO = null;
              if ("string" === typeof gK.subLanguage) {
                if (!XO[gK.subLanguage]) return void EO.addText(jK);
                OO = zK(gK.subLanguage, jK, !0, uO[gK.subLanguage]), uO[gK.subLanguage] = OO._top
              } else OO = AO(jK, gK.subLanguage.length ? gK.subLanguage : null);
              gK.relevance > 0 && (YO += OO.relevance), EO.__addSublanguage(OO._emitter, OO.language)
            }() : hO(), jK = ""
          }

          function aK(OO, KO) {
            "" !== OO && (EO.startScope(KO), EO.addText(OO), EO.endScope())
          }

          function oO(OO, KO) {
            let pO = 1;
            const XO = KO.length - 1;
            for (; pO <= XO;) {
              if (!OO._emit[pO]) {
                pO++;
                continue
              }
              const XO = TO.classNameAliases[OO[pO]] || OO[pO],
                bK = KO[pO];
              XO ? aK(bK, XO) : (jK = bK, hO(), jK = ""), pO++
            }
          }

          function FO(OO, KO) {
            return OO.scope && "string" === typeof OO.scope && EO.openNode(TO.classNameAliases[OO.scope] || OO.scope), OO.beginScope && (OO.beginScope._wrap ? (aK(jK, TO.classNameAliases[OO.beginScope._wrap] || OO.beginScope._wrap), jK = "") : OO.beginScope._multi && (oO(OO.beginScope, KO), jK = "")), gK = Object.create(OO, {
              parent: {
                value: gK
              }
            }), gK
          }

          function VO(OO, KO, XO) {
            let bK = function(OO, KO) {
              const pO = OO && OO.exec(KO);
              return pO && 0 === pO.index
            }(OO.endRe, XO);
            if (bK) {
              if (OO["on:end"]) {
                const XO = new pO(OO);
                OO["on:end"](KO, XO), XO.isMatchIgnored && (bK = !1)
              }
              if (bK) {
                for (; OO.endsParent && OO.parent;) OO = OO.parent;
                return OO
              }
            }
            if (OO.endsWithParent) return VO(OO.parent, KO, XO)
          }

          function LO(OO) {
            return 0 === gK.matcher.regexIndex ? (jK += OO[0], 1) : (rK = !0, 0)
          }

          function QO(OO) {
            const pO = OO[0],
              XO = KO.substring(OO.index),
              bK = VO(gK, OO, XO);
            if (!bK) return hK;
            const eO = gK;
            gK.endScope && gK.endScope._wrap ? (MO(), aK(pO, gK.endScope._wrap)) : gK.endScope && gK.endScope._multi ? (MO(), oO(gK.endScope, OO)) : eO.skip ? jK += pO : (eO.returnEnd || eO.excludeEnd || (jK += pO), MO(), eO.excludeEnd && (jK = pO));
            do {
              gK.scope && EO.closeNode(), gK.skip || gK.subLanguage || (YO += gK.relevance), gK = gK.parent
            } while (gK !== bK.parent);
            return bK.starts && FO(bK.starts, OO), eO.returnEnd ? 0 : pO.length
          }
          let fO = {};

          function dO(XO, eO) {
            const vK = eO && eO[0];
            if (jK += XO, null == vK) return MO(), 0;
            if ("Ip" === fO.type && "end" === eO.type && fO.index === eO.index && "" === vK) {
              if (jK += KO.slice(eO.index, eO.index + 1), !lO) {
                const KO = new Error(`0 width match regex (${OO})`);
                throw KO.languageName = OO, KO.badRule = fO.rule, KO
              }
              return 1
            }
            if (fO = eO, "Ip" === eO.type) return function(OO) {
              const KO = OO[0],
                XO = OO.rule,
                bK = new pO(XO),
                eO = [XO.__beforeBegin, XO["on:begin"]];
              for (const pO of eO)
                if (pO && (pO(OO, bK), bK.isMatchIgnored)) return LO(KO);
              return XO.skip ? jK += KO : (XO.excludeBegin && (jK += KO), MO(), XO.returnBegin || XO.excludeBegin || (jK = KO)), FO(XO, OO), XO.returnBegin ? 0 : KO.length
            }(eO);
            if ("illegal" === eO.type && !bK) {
              const OO = new Error('Illegal lexeme "' + vK + '" for mode "' + (gK.scope || "<unnamed>") + '"');
              throw OO.mode = gK, OO
            }
            if ("end" === eO.type) {
              const OO = QO(eO);
              if (OO !== hK) return OO
            }
            if ("illegal" === eO.type && "" === vK) return jK += "\n", 1;
            if (iK > 1e5 && iK > 3 * eO.index) {
              throw new Error("potential infinite loop, way more iterations than matches")
            }
            return jK += vK, vK.length
          }
          const TO = NO(OO);
          if (!TO) throw kK(vK.replace("{}", OO)), new Error('Unknown language: "' + OO + '"');
          const IO = bp(TO);
          let yK = "",
            gK = eO || IO;
          const uO = {},
            EO = new DO.__emitter(DO);
          ! function() {
            const OO = [];
            for (let KO = gK; KO !== TO; KO = KO.parent) KO.scope && OO.unshift(KO.scope);
            OO.forEach((OO => EO.openNode(OO)))
          }();
          let jK = "",
            YO = 0,
            wO = 0,
            iK = 0,
            rK = !1;
          try {
            if (TO.__emitTokens) TO.__emitTokens(KO, EO);
            else {
              for (gK.matcher.considerAll();;) {
                iK++, rK ? rK = !1 : gK.matcher.considerAll(), gK.matcher.lastIndex = wO;
                const OO = gK.matcher.exec(KO);
                if (!OO) break;
                const pO = dO(KO.substring(wO, OO.index), OO);
                wO = OO.index + pO
              }
              dO(KO.substring(wO))
            }
            return EO.finalize(), yK = EO.toHTML(), {
              language: OO,
              value: yK,
              relevance: YO,
              illegal: !1,
              _emitter: EO,
              _top: gK
            }
          } catch (PO) {
            if (PO.message && PO.message.includes("Illegal")) return {
              language: OO,
              value: vp(KO),
              illegal: !0,
              relevance: 0,
              _illegalBy: {
                message: PO.message,
                index: wO,
                context: KO.slice(wO - 100, wO + 100),
                mode: PO.mode,
                resultSoFar: yK
              },
              _emitter: EO
            };
            if (lO) return {
              language: OO,
              value: vp(KO),
              illegal: !1,
              relevance: 0,
              errorRaised: PO,
              _emitter: EO,
              _top: gK
            };
            throw PO
          }
        }

        function AO(OO, KO) {
          KO = KO || DO.languages || Object.keys(XO);
          const pO = function(OO) {
              const KO = {
                value: vp(OO),
                illegal: !1,
                relevance: 0,
                _top: CO,
                _emitter: new DO.__emitter(DO)
              };
              return KO._emitter.addText(OO), KO
            }(OO),
            bK = KO.filter(NO).filter(yK).map((KO => zK(KO, OO, !1)));
          bK.unshift(pO);
          const eO = bK.sort(((OO, KO) => {
              if (OO.relevance !== KO.relevance) return KO.relevance - OO.relevance;
              if (OO.language && KO.language) {
                if (NO(OO.language).supersetOf === KO.language) return 1;
                if (NO(KO.language).supersetOf === OO.language) return -1
              }
              return 0
            })),
            [lO, vK] = eO,
            hO = lO;
          return hO.secondBest = vK, hO
        }

        function fO(OO) {
          let KO = null;
          const pO = function(OO) {
            let KO = OO.className + " ";
            KO += OO.parentNode ? OO.parentNode.className : "";
            const pO = DO.languageDetectRe.exec(KO);
            if (pO) {
              const KO = NO(pO[1]);
              return KO || (UO(vK.replace("{}", pO[1])), UO("Falling back to no-highlight mode for this block.", OO)), KO ? pO[1] : "no-highlight"
            }
            return KO.split(/\s+/).find((OO => LO(OO) || NO(OO)))
          }(OO);
          if (LO(pO)) return;
          if (gK("before:highlightElement", {
              el: OO,
              language: pO
            }), OO.dataset.highlighted) return void console.log("Element previously highlighted. To highlight again, first unset `dataset.highlighted`.", OO);
          if (OO.children.length > 0 && (DO.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(OO)), DO.throwUnescapedHTML)) {
            throw new lK("One of your code blocks includes unescaped HTML.", OO.innerHTML)
          }
          KO = OO;
          const XO = KO.textContent,
            eO = pO ? QO(XO, {
              language: pO,
              ignoreIllegals: !0
            }) : AO(XO);
          OO.innerHTML = eO.value, OO.dataset.highlighted = "yes",
            function(OO, KO, pO) {
              const XO = KO && bK[KO] || pO;
              OO.classList.add("hljs"), OO.classList.add(`language-${XO}`)
            }(OO, pO, eO.language), OO.result = {
              language: eO.language,
              re: eO.relevance,
              relevance: eO.relevance
            }, eO.secondBest && (OO.secondBest = {
              language: eO.secondBest.language,
              relevance: eO.secondBest.relevance
            }), gK("after:highlightElement", {
              el: OO,
              result: eO,
              text: XO
            })
        }
        let dO = !1;

        function TO() {
          if ("loading" === document.readyState) return dO || window.addEventListener("DOMContentLoaded", (function() {
            TO()
          }), !1), void(dO = !0);
          document.querySelectorAll(DO.cssSelector).forEach(fO)
        }

        function NO(OO) {
          return OO = (OO || "").toLowerCase(), XO[OO] || XO[bK[OO]]
        }

        function IO(OO, KO) {
          let {
            languageName: pO
          } = KO;
          "string" === typeof OO && (OO = [OO]), OO.forEach((OO => {
            bK[OO.toLowerCase()] = pO
          }))
        }

        function yK(OO) {
          const KO = NO(OO);
          return KO && !KO.disableAutodetect
        }

        function gK(OO, KO) {
          const pO = OO;
          eO.forEach((function(OO) {
            OO[pO] && OO[pO](KO)
          }))
        }
        Object.assign(OO, {
          highlight: QO,
          highlightAuto: AO,
          highlightAll: TO,
          highlightElement: fO,
          highlightBlock: function(OO) {
            return OK("10.7.0", "highlightBlock will be removed entirely in v12.0"), OK("10.7.0", "Please use highlightElement now."), fO(OO)
          },
          configure: function(OO) {
            DO = CK(DO, OO)
          },
          initHighlighting: () => {
            TO(), OK("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now.")
          },
          initHighlightingOnLoad: function() {
            TO(), OK("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now.")
          },
          registerLanguage: function(KO, pO) {
            let bK = null;
            try {
              bK = pO(OO)
            } catch (eO) {
              if (kK("Language definition for '{}' could not be registered.".replace("{}", KO)), !lO) throw eO;
              kK(eO), bK = CO
            }
            bK.name || (bK.name = KO), XO[KO] = bK, bK.rawDefinition = pO.bind(null, OO), bK.aliases && IO(bK.aliases, {
              languageName: KO
            })
          },
          unregisterLanguage: function(OO) {
            delete XO[OO];
            for (const KO of Object.keys(bK)) bK[KO] === OO && delete bK[KO]
          },
          listLanguages: function() {
            return Object.keys(XO)
          },
          getLanguage: NO,
          registerAliases: IO,
          autoDetection: yK,
          inherit: CK,
          addPlugin: function(OO) {
            ! function(OO) {
              OO["before:highlightBlock"] && !OO["before:highlightElement"] && (OO["before:highlightElement"] = KO => {
                OO["before:highlightBlock"](Object.assign({
                  block: KO.el
                }, KO))
              }), OO["after:highlightBlock"] && !OO["after:highlightElement"] && (OO["after:highlightElement"] = KO => {
                OO["after:highlightBlock"](Object.assign({
                  block: KO.el
                }, KO))
              })
            }(OO), eO.push(OO)
          },
          removePlugin: function(OO) {
            const KO = eO.indexOf(OO); - 1 !== KO && eO.splice(KO, 1)
          }
        }), OO.debugMode = function() {
          lO = !1
        }, OO.safeMode = function() {
          lO = !0
        }, OO.versionString = "11.11.1", OO.regex = {
          concat: FO,
          lookahead: MO,
          either: VO,
          optional: oO,
          anyNumberOfTimes: aK
        };
        for (const pO in RO) "object" === typeof RO[pO] && KO(RO[pO]);
        return Object.assign(OO, RO), OO
      },
      MK = DK({});
    MK.newInstance = () => DK({}), OO.exports = MK, MK.HighlightJS = MK, MK.default = MK
  },
  3868: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    const XO = pO(3870)
  },
  3874: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => MO
    });
    const XO = "[A-Za-z$_][0-9A-Za-z$_]*",
      bK = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends", "using"],
      eO = ["true", "false", "null", "undefined", "NaN", "Infinity"],
      lO = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
      vK = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
      CO = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
      hO = ["arguments", "this", "super", "console", "window", "document", "localStorage", "sessionStorage", "module", "global"],
      DO = [].concat(CO, lO, vK);

    function MO(OO) {
      const KO = OO.regex,
        pO = XO,
        MO = "<>",
        aK = "</>",
        oO = {
          Ip: /<[A-Za-z0-9\\._:-]+/,
          end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
          isTrulyOpeningTag: (OO, KO) => {
            const pO = OO[0].length + OO.index,
              XO = OO.input[pO];
            if ("<" === XO || "," === XO) return void KO.ignoreMatch();
            let bK;
            ">" === XO && (((OO, KO) => {
              let {
                after: pO
              } = KO;
              const XO = "</" + OO[0].slice(1);
              return -1 !== OO.input.indexOf(XO, pO)
            })(OO, {
              after: pO
            }) || KO.ignoreMatch());
            const eO = OO.input.substring(pO);
            ((bK = eO.match(/^\s*=/)) || (bK = eO.match(/^\s+extends\s+/)) && 0 === bK.index) && KO.ignoreMatch()
          }
        },
        FO = {
          $pattern: XO,
          keyword: bK,
          literal: eO,
          built_in: DO,
          "variable.language": hO
        },
        VO = "[0-9](_?[0-9])*",
        LO = `\\.(${VO})`,
        QO = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
        zK = {
          className: "number",
          variants: [{
            Ip: `(\\b(${QO})((${LO})|\\.)?|(${LO}))[eE][+-]?(${VO})\\b`
          }, {
            Ip: `\\b(${QO})\\b((${LO})\\b|\\.)?|(${LO})\\b`
          }, {
            Ip: "\\b(0|[1-9](_?[0-9])*)n\\b"
          }, {
            Ip: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
          }, {
            Ip: "\\b0[bB][0-1](_?[0-1])*n?\\b"
          }, {
            Ip: "\\b0[oO][0-7](_?[0-7])*n?\\b"
          }, {
            Ip: "\\b0[0-7]+n?\\b"
          }],
          relevance: 0
        },
        AO = {
          className: "subst",
          Ip: "\\$\\{",
          end: "\\}",
          keywords: FO,
          contains: []
        },
        fO = {
          Ip: ".?html`",
          end: "",
          starts: {
            end: "`",
            returnEnd: !1,
            contains: [OO.BACKSLASH_ESCAPE, AO],
            subLanguage: "xml"
          }
        },
        dO = {
          Ip: ".?css`",
          end: "",
          starts: {
            end: "`",
            returnEnd: !1,
            contains: [OO.BACKSLASH_ESCAPE, AO],
            subLanguage: "css"
          }
        },
        TO = {
          Ip: ".?gql`",
          end: "",
          starts: {
            end: "`",
            returnEnd: !1,
            contains: [OO.BACKSLASH_ESCAPE, AO],
            subLanguage: "graphql"
          }
        },
        NO = {
          className: "string",
          Ip: "`",
          end: "`",
          contains: [OO.BACKSLASH_ESCAPE, AO]
        },
        IO = {
          className: "comment",
          variants: [OO.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
            relevance: 0,
            contains: [{
              Ip: "(?=@[A-Za-z]+)",
              relevance: 0,
              contains: [{
                className: "doctag",
                Ip: "@[A-Za-z]+"
              }, {
                className: "type",
                Ip: "\\{",
                end: "\\}",
                excludeEnd: !0,
                excludeBegin: !0,
                relevance: 0
              }, {
                className: "variable",
                Ip: pO + "(?=\\s*(-)|$)",
                endsParent: !0,
                relevance: 0
              }, {
                Ip: /(?=[^\n])\s/,
                relevance: 0
              }]
            }]
          }), OO.C_BLOCK_COMMENT_MODE, OO.C_LINE_COMMENT_MODE]
        },
        yK = [OO.APOS_STRING_MODE, OO.QUOTE_STRING_MODE, fO, dO, TO, NO, {
          match: /\$\d+/
        }, zK];
      AO.contains = yK.concat({
        Ip: /\{/,
        end: /\}/,
        keywords: FO,
        contains: ["self"].concat(yK)
      });
      const gK = [].concat(IO, AO.contains),
        uO = gK.concat([{
          Ip: /(\s*)\(/,
          end: /\)/,
          keywords: FO,
          contains: ["self"].concat(gK)
        }]),
        EO = {
          className: "params",
          Ip: /(\s*)\(/,
          end: /\)/,
          excludeBegin: !0,
          excludeEnd: !0,
          keywords: FO,
          contains: uO
        },
        jK = {
          variants: [{
            match: [/class/, /\s+/, pO, /\s+/, /extends/, /\s+/, KO.concat(pO, "(", KO.concat(/\./, pO), ")*")],
            scope: {
              1: "keyword",
              3: "title.class",
              5: "keyword",
              7: "title.class.inherited"
            }
          }, {
            match: [/class/, /\s+/, pO],
            scope: {
              1: "keyword",
              3: "title.class"
            }
          }]
        },
        YO = {
          relevance: 0,
          match: KO.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
          className: "title.class",
          keywords: {
            _: [...lO, ...vK]
          }
        },
        wO = {
          variants: [{
            match: [/function/, /\s+/, pO, /(?=\s*\()/]
          }, {
            match: [/function/, /\s*(?=\()/]
          }],
          className: {
            1: "keyword",
            3: "title.function"
          },
          label: "func.def",
          contains: [EO],
          illegal: /%/
        };
      const iK = {
        match: KO.concat(/\b/, (rK = [...CO, "super", "import"].map((OO => `${OO}\\s*\\(`)), KO.concat("(?!", rK.join("|"), ")")), pO, KO.lookahead(/\s*\(/)),
        className: "title.function",
        relevance: 0
      };
      var rK;
      const PO = {
          Ip: KO.concat(/\./, KO.lookahead(KO.concat(pO, /(?![0-9A-Za-z$_(])/))),
          end: pO,
          excludeBegin: !0,
          keywords: "prototype",
          className: "property",
          relevance: 0
        },
        mK = {
          match: [/get|set/, /\s+/, pO, /(?=\()/],
          className: {
            1: "keyword",
            3: "title.function"
          },
          contains: [{
            Ip: /\(\)/
          }, EO]
        },
        sO = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + OO.UNDERSCORE_IDENT_RE + ")\\s*=>",
        HO = {
          match: [/const|var|let/, /\s+/, pO, /\s*/, /=\s*/, /(async\s*)?/, KO.lookahead(sO)],
          keywords: "async",
          className: {
            1: "keyword",
            3: "title.function"
          },
          contains: [EO]
        };
      return {
        name: "JavaScript",
        aliases: ["js", "jsx", "mjs", "cjs"],
        keywords: FO,
        exports: {
          PARAMS_CONTAINS: uO,
          CLASS_REFERENCE: YO
        },
        illegal: /#(?![$_A-z])/,
        contains: [OO.SHEBANG({
          label: "shebang",
          binary: "node",
          relevance: 5
        }), {
          label: "use_strict",
          className: "meta",
          relevance: 10,
          Ip: /^\s*['"]use (strict|asm)['"]/
        }, OO.APOS_STRING_MODE, OO.QUOTE_STRING_MODE, fO, dO, TO, NO, IO, {
          match: /\$\d+/
        }, zK, YO, {
          scope: "attr",
          match: pO + KO.lookahead(":"),
          relevance: 0
        }, HO, {
          Ip: "(" + OO.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
          keywords: "return throw case",
          relevance: 0,
          contains: [IO, OO.REGEXP_MODE, {
            className: "function",
            Ip: sO,
            returnBegin: !0,
            end: "\\s*=>",
            contains: [{
              className: "params",
              variants: [{
                Ip: OO.UNDERSCORE_IDENT_RE,
                relevance: 0
              }, {
                className: null,
                Ip: /\(\s*\)/,
                skip: !0
              }, {
                Ip: /(\s*)\(/,
                end: /\)/,
                excludeBegin: !0,
                excludeEnd: !0,
                keywords: FO,
                contains: uO
              }]
            }]
          }, {
            Ip: /,/,
            relevance: 0
          }, {
            match: /\s+/,
            relevance: 0
          }, {
            variants: [{
              Ip: MO,
              end: aK
            }, {
              match: /<[A-Za-z0-9\\._:-]+\s*\/>/
            }, {
              Ip: oO.Ip,
              "on:begin": oO.isTrulyOpeningTag,
              end: oO.end
            }],
            subLanguage: "xml",
            contains: [{
              Ip: oO.Ip,
              end: oO.end,
              skip: !0,
              contains: ["self"]
            }]
          }]
        }, wO, {
          beginKeywords: "while if switch catch for"
        }, {
          Ip: "\\b(?!function)" + OO.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
          returnBegin: !0,
          label: "func.def",
          contains: [EO, OO.inherit(OO.TITLE_MODE, {
            Ip: pO,
            className: "title.function"
          })]
        }, {
          match: /\.\.\./,
          relevance: 0
        }, PO, {
          match: "\\$" + pO,
          relevance: 0
        }, {
          match: [/\bconstructor(?=\s*\()/],
          className: {
            1: "title.function"
          },
          contains: [EO]
        }, iK, {
          relevance: 0,
          match: /\b[A-Z][A-Z_0-9]+\b/,
          className: "variable.constant"
        }, jK, mK, {
          match: /\$[(.]/
        }]
      }
    }
  },
  3880: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => aK
    });
    const XO = "[A-Za-z$_][0-9A-Za-z$_]*",
      bK = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends", "using"],
      eO = ["true", "false", "null", "undefined", "NaN", "Infinity"],
      lO = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
      vK = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
      CO = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
      hO = ["arguments", "this", "super", "console", "window", "document", "localStorage", "sessionStorage", "module", "global"],
      DO = [].concat(CO, lO, vK);

    function MO(OO) {
      const KO = OO.regex,
        pO = XO,
        MO = "<>",
        aK = "</>",
        oO = {
          Ip: /<[A-Za-z0-9\\._:-]+/,
          end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
          isTrulyOpeningTag: (OO, KO) => {
            const pO = OO[0].length + OO.index,
              XO = OO.input[pO];
            if ("<" === XO || "," === XO) return void KO.ignoreMatch();
            let bK;
            ">" === XO && (((OO, KO) => {
              let {
                after: pO
              } = KO;
              const XO = "</" + OO[0].slice(1);
              return -1 !== OO.input.indexOf(XO, pO)
            })(OO, {
              after: pO
            }) || KO.ignoreMatch());
            const eO = OO.input.substring(pO);
            ((bK = eO.match(/^\s*=/)) || (bK = eO.match(/^\s+extends\s+/)) && 0 === bK.index) && KO.ignoreMatch()
          }
        },
        FO = {
          $pattern: XO,
          keyword: bK,
          literal: eO,
          built_in: DO,
          "variable.language": hO
        },
        VO = "[0-9](_?[0-9])*",
        LO = `\\.(${VO})`,
        QO = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
        zK = {
          className: "number",
          variants: [{
            Ip: `(\\b(${QO})((${LO})|\\.)?|(${LO}))[eE][+-]?(${VO})\\b`
          }, {
            Ip: `\\b(${QO})\\b((${LO})\\b|\\.)?|(${LO})\\b`
          }, {
            Ip: "\\b(0|[1-9](_?[0-9])*)n\\b"
          }, {
            Ip: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
          }, {
            Ip: "\\b0[bB][0-1](_?[0-1])*n?\\b"
          }, {
            Ip: "\\b0[oO][0-7](_?[0-7])*n?\\b"
          }, {
            Ip: "\\b0[0-7]+n?\\b"
          }],
          relevance: 0
        },
        AO = {
          className: "subst",
          Ip: "\\$\\{",
          end: "\\}",
          keywords: FO,
          contains: []
        },
        fO = {
          Ip: ".?html`",
          end: "",
          starts: {
            end: "`",
            returnEnd: !1,
            contains: [OO.BACKSLASH_ESCAPE, AO],
            subLanguage: "xml"
          }
        },
        dO = {
          Ip: ".?css`",
          end: "",
          starts: {
            end: "`",
            returnEnd: !1,
            contains: [OO.BACKSLASH_ESCAPE, AO],
            subLanguage: "css"
          }
        },
        TO = {
          Ip: ".?gql`",
          end: "",
          starts: {
            end: "`",
            returnEnd: !1,
            contains: [OO.BACKSLASH_ESCAPE, AO],
            subLanguage: "graphql"
          }
        },
        NO = {
          className: "string",
          Ip: "`",
          end: "`",
          contains: [OO.BACKSLASH_ESCAPE, AO]
        },
        IO = {
          className: "comment",
          variants: [OO.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
            relevance: 0,
            contains: [{
              Ip: "(?=@[A-Za-z]+)",
              relevance: 0,
              contains: [{
                className: "doctag",
                Ip: "@[A-Za-z]+"
              }, {
                className: "type",
                Ip: "\\{",
                end: "\\}",
                excludeEnd: !0,
                excludeBegin: !0,
                relevance: 0
              }, {
                className: "variable",
                Ip: pO + "(?=\\s*(-)|$)",
                endsParent: !0,
                relevance: 0
              }, {
                Ip: /(?=[^\n])\s/,
                relevance: 0
              }]
            }]
          }), OO.C_BLOCK_COMMENT_MODE, OO.C_LINE_COMMENT_MODE]
        },
        yK = [OO.APOS_STRING_MODE, OO.QUOTE_STRING_MODE, fO, dO, TO, NO, {
          match: /\$\d+/
        }, zK];
      AO.contains = yK.concat({
        Ip: /\{/,
        end: /\}/,
        keywords: FO,
        contains: ["self"].concat(yK)
      });
      const gK = [].concat(IO, AO.contains),
        uO = gK.concat([{
          Ip: /(\s*)\(/,
          end: /\)/,
          keywords: FO,
          contains: ["self"].concat(gK)
        }]),
        EO = {
          className: "params",
          Ip: /(\s*)\(/,
          end: /\)/,
          excludeBegin: !0,
          excludeEnd: !0,
          keywords: FO,
          contains: uO
        },
        jK = {
          variants: [{
            match: [/class/, /\s+/, pO, /\s+/, /extends/, /\s+/, KO.concat(pO, "(", KO.concat(/\./, pO), ")*")],
            scope: {
              1: "keyword",
              3: "title.class",
              5: "keyword",
              7: "title.class.inherited"
            }
          }, {
            match: [/class/, /\s+/, pO],
            scope: {
              1: "keyword",
              3: "title.class"
            }
          }]
        },
        YO = {
          relevance: 0,
          match: KO.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
          className: "title.class",
          keywords: {
            _: [...lO, ...vK]
          }
        },
        wO = {
          variants: [{
            match: [/function/, /\s+/, pO, /(?=\s*\()/]
          }, {
            match: [/function/, /\s*(?=\()/]
          }],
          className: {
            1: "keyword",
            3: "title.function"
          },
          label: "func.def",
          contains: [EO],
          illegal: /%/
        };
      const iK = {
        match: KO.concat(/\b/, (rK = [...CO, "super", "import"].map((OO => `${OO}\\s*\\(`)), KO.concat("(?!", rK.join("|"), ")")), pO, KO.lookahead(/\s*\(/)),
        className: "title.function",
        relevance: 0
      };
      var rK;
      const PO = {
          Ip: KO.concat(/\./, KO.lookahead(KO.concat(pO, /(?![0-9A-Za-z$_(])/))),
          end: pO,
          excludeBegin: !0,
          keywords: "prototype",
          className: "property",
          relevance: 0
        },
        mK = {
          match: [/get|set/, /\s+/, pO, /(?=\()/],
          className: {
            1: "keyword",
            3: "title.function"
          },
          contains: [{
            Ip: /\(\)/
          }, EO]
        },
        sO = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + OO.UNDERSCORE_IDENT_RE + ")\\s*=>",
        HO = {
          match: [/const|var|let/, /\s+/, pO, /\s*/, /=\s*/, /(async\s*)?/, KO.lookahead(sO)],
          keywords: "async",
          className: {
            1: "keyword",
            3: "title.function"
          },
          contains: [EO]
        };
      return {
        name: "JavaScript",
        aliases: ["js", "jsx", "mjs", "cjs"],
        keywords: FO,
        exports: {
          PARAMS_CONTAINS: uO,
          CLASS_REFERENCE: YO
        },
        illegal: /#(?![$_A-z])/,
        contains: [OO.SHEBANG({
          label: "shebang",
          binary: "node",
          relevance: 5
        }), {
          label: "use_strict",
          className: "meta",
          relevance: 10,
          Ip: /^\s*['"]use (strict|asm)['"]/
        }, OO.APOS_STRING_MODE, OO.QUOTE_STRING_MODE, fO, dO, TO, NO, IO, {
          match: /\$\d+/
        }, zK, YO, {
          scope: "attr",
          match: pO + KO.lookahead(":"),
          relevance: 0
        }, HO, {
          Ip: "(" + OO.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
          keywords: "return throw case",
          relevance: 0,
          contains: [IO, OO.REGEXP_MODE, {
            className: "function",
            Ip: sO,
            returnBegin: !0,
            end: "\\s*=>",
            contains: [{
              className: "params",
              variants: [{
                Ip: OO.UNDERSCORE_IDENT_RE,
                relevance: 0
              }, {
                className: null,
                Ip: /\(\s*\)/,
                skip: !0
              }, {
                Ip: /(\s*)\(/,
                end: /\)/,
                excludeBegin: !0,
                excludeEnd: !0,
                keywords: FO,
                contains: uO
              }]
            }]
          }, {
            Ip: /,/,
            relevance: 0
          }, {
            match: /\s+/,
            relevance: 0
          }, {
            variants: [{
              Ip: MO,
              end: aK
            }, {
              match: /<[A-Za-z0-9\\._:-]+\s*\/>/
            }, {
              Ip: oO.Ip,
              "on:begin": oO.isTrulyOpeningTag,
              end: oO.end
            }],
            subLanguage: "xml",
            contains: [{
              Ip: oO.Ip,
              end: oO.end,
              skip: !0,
              contains: ["self"]
            }]
          }]
        }, wO, {
          beginKeywords: "while if switch catch for"
        }, {
          Ip: "\\b(?!function)" + OO.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
          returnBegin: !0,
          label: "func.def",
          contains: [EO, OO.inherit(OO.TITLE_MODE, {
            Ip: pO,
            className: "title.function"
          })]
        }, {
          match: /\.\.\./,
          relevance: 0
        }, PO, {
          match: "\\$" + pO,
          relevance: 0
        }, {
          match: [/\bconstructor(?=\s*\()/],
          className: {
            1: "title.function"
          },
          contains: [EO]
        }, iK, {
          relevance: 0,
          match: /\b[A-Z][A-Z_0-9]+\b/,
          className: "variable.constant"
        }, jK, mK, {
          match: /\$[(.]/
        }]
      }
    }

    function aK(OO) {
      const KO = OO.regex,
        pO = MO(OO),
        lO = XO,
        vK = ["any", "void", "number", "boolean", "string", "object", "never", "symbol", "bigint", "unknown"],
        CO = {
          Ip: [/namespace/, /\s+/, OO.IDENT_RE],
          beginScope: {
            1: "keyword",
            3: "title.class"
          }
        },
        aK = {
          beginKeywords: "interface",
          end: /\{/,
          excludeEnd: !0,
          keywords: {
            keyword: "interface extends",
            built_in: vK
          },
          contains: [pO.exports.CLASS_REFERENCE]
        },
        oO = {
          $pattern: XO,
          keyword: bK.concat(["type", "interface", "public", "private", "protected", "implements", "declare", "abstract", "readonly", "enum", "override", "satisfies"]),
          literal: eO,
          built_in: DO.concat(vK),
          "variable.language": hO
        },
        FO = {
          className: "meta",
          Ip: "@" + lO
        },
        VO = (OO, KO, pO) => {
          const XO = OO.contains.findIndex((OO => OO.label === KO));
          if (-1 === XO) throw new Error("can not find mode to replace");
          OO.contains.splice(XO, 1, pO)
        };
      Object.assign(pO.keywords, oO), pO.exports.PARAMS_CONTAINS.push(FO);
      const LO = pO.contains.find((OO => "attr" === OO.scope)),
        QO = Object.assign({}, LO, {
          match: KO.concat(lO, KO.lookahead(/\s*\?:/))
        });
      pO.exports.PARAMS_CONTAINS.push([pO.exports.CLASS_REFERENCE, LO, QO]), pO.contains = pO.contains.concat([FO, CO, aK, QO]), VO(pO, "shebang", OO.SHEBANG()), VO(pO, "use_strict", {
        className: "meta",
        relevance: 10,
        Ip: /^\s*['"]use strict['"]/
      });
      return pO.contains.find((OO => "func.def" === OO.label)).relevance = 0, Object.assign(pO, {
        name: "TypeScript",
        aliases: ["ts", "tsx", "mts", "cts"]
      }), pO
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);