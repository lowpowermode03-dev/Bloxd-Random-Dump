export const id = 100;
export const ids = [100];
export const modules = {
  4120: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => FO,
      e: () => zK,
      h: () => VO,
      j: () => QO
    });
    var XO = pO(63),
      bK = pO(4123),
      eO = pO(3618),
      lO = pO(1195),
      vK = pO(4148),
      CO = pO(918),
      hO = pO.n(CO),
      DO = pO(1187),
      MO = pO(1481),
      aK = pO(4151),
      oO = pO(976);

    function FO(OO) {
      let {
        label: KO,
        onClick: pO,
        checked: XO,
        circleInfoText: bK,
        className: vK,
        disabled: CO
      } = OO;
      return (0, oO.jsx)("div", {
        "aria-disabled": CO || void 0,
        "data-pad-focusable": !0,
        className: hO()("SettingBox CheckboxContainer", {
          [vK]: vK,
          SettingBoxDisabled: CO
        }),
        onClick: () => {
          CO || pO(!XO)
        },
        children: (0, oO.jsxs)("div", {
          className: "CheckboxInputAndText",
          children: [(0, oO.jsx)("label", {
            className: "CheckboxClickableLabel",
            children: (0, oO.jsx)(eO.c, {
              className: "SettingsCheckbox",
              checked: XO,
              disabled: CO,
              onChange: () => {}
            })
          }), (0, oO.jsxs)("div", {
            className: "CheckboxText",
            children: [KO, bK && (0, oO.jsx)("span", {
              onClick: OO => OO.stopPropagation(),
              children: (0, oO.jsx)(lO.c, {
                className: "SettingsTextInputCircleInfo",
                hoverInfo: bK
              })
            })]
          })]
        })
      })
    }

    function VO(OO) {
      let {
        name: KO,
        onChange: pO,
        min: bK,
        max: eO,
        step: vK,
        initValue: CO,
        circleInfoText: DO,
        format: MO,
        className: aK,
        padStep: FO,
        disabled: VO = !1,
        selectableMax: QO,
        cappedNote: zK
      } = OO;
      const [AO, fO] = (0, XO.useState)(CO);
      (0, XO.useEffect)((() => {
        fO(CO)
      }), [CO]);
      const dO = void 0 !== QO && QO < eO,
        TO = dO ? {
          "--slider-selectable": (QO - bK) / (eO - bK)
        } : void 0;
      return (0, oO.jsxs)("div", {
        className: hO()("SettingBox SettingsSliderDiv", {
          [aK]: aK,
          SettingBoxDisabled: VO,
          SliderCapped: dO
        }),
        style: TO,
        children: [(0, oO.jsxs)("div", {
          className: "SliderText",
          children: [`${KO}: ${MO?MO(AO):AO}`, DO && (0, oO.jsx)(lO.c, {
            className: "SettingsTextInputCircleInfo",
            hoverInfo: DO
          })]
        }), (0, oO.jsx)("div", {
          className: "SliderDiv",
          children: (0, oO.jsx)(LO, {
            value: AO,
            min: bK,
            max: eO,
            step: vK,
            onChange: OO => {
              if (dO && OO >= QO && AO === QO) return;
              const KO = dO ? Math.min(OO, QO) : OO;
              fO(KO), pO(KO)
            },
            format: MO,
            padStep: FO,
            disabled: VO
          })
        }), dO && zK && (0, oO.jsx)("div", {
          className: "SliderNote",
          children: zK
        })]
      })
    }

    function LO(OO) {
      var KO;
      let {
        value: pO,
        min: eO,
        max: lO,
        step: vK,
        onChange: CO,
        orientation: hO,
        reverse: DO,
        setIsChanging: MO,
        tooltip: FO,
        labels: VO,
        handleLabel: LO,
        format: QO,
        onChangeStart: zK,
        onChangeComplete: AO,
        padStep: fO,
        disabled: dO = !1
      } = OO;
      const TO = (0, XO.useRef)(null),
        NO = (0, XO.useRef)(null);
      (0, XO.useLayoutEffect)((() => {
        var OO, KO, pO;
        const XO = null !== (OO = null === (KO = TO.current) || void 0 === KO ? void 0 : KO.querySelector(".rangeslider")) && void 0 !== OO ? OO : null;
        null === XO || void 0 === XO || XO.setAttribute("data-pad-slider", ""), null === XO || void 0 === XO || XO.setAttribute("data-pad-focusable", ""), null === XO || void 0 === XO || null === (pO = XO.querySelector(".rangeslider__handle")) || void 0 === pO || pO.setAttribute("data-pad-slider-handle", ""), NO.current = XO
      }), []), (0, XO.useLayoutEffect)((() => {
        var OO, KO;
        dO ? null === (OO = NO.current) || void 0 === OO || OO.setAttribute("aria-disabled", "true") : null === (KO = NO.current) || void 0 === KO || KO.removeAttribute("aria-disabled")
      }), [dO]);
      const IO = (null !== (KO = String(vK).split(".")[1]) && void 0 !== KO ? KO : "").length,
        yK = OO => {
          const KO = Number((Math.round((OO - eO) / vK) * vK + eO).toFixed(IO));
          return Math.min(lO, Math.max(eO, KO))
        },
        gK = (0, XO.useRef)(!1);
      return (0, aK.h)(NO, {
        adjust: OO => {
          if (dO) return;
          const KO = null !== fO && void 0 !== fO ? fO : Math.max(vK, Math.round((lO - eO) / 20 / vK) * vK),
            XO = yK(pO + OO * KO * (DO ? -1 : 1));
          XO !== pO && (null === zK || void 0 === zK || zK(), CO(XO), null === AO || void 0 === AO || AO())
        },
        setFraction: OO => {
          if (dO) return;
          const KO = yK(eO + (DO ? 1 - OO : OO) * (lO - eO));
          KO !== pO && (gK.current || (gK.current = !0, null === zK || void 0 === zK || zK()), CO(KO))
        },
        endDrag: () => {
          gK.current && (gK.current = !1, null === AO || void 0 === AO || AO())
        }
      }), (0, oO.jsx)("div", {
        ref: TO,
        style: {
          display: "contents"
        },
        children: (0, oO.jsx)(bK.c, {
          value: pO,
          min: eO,
          max: lO,
          step: vK,
          onChange: CO,
          orientation: hO,
          reverse: DO,
          tooltip: FO,
          labels: VO,
          handleLabel: LO,
          format: QO,
          onChangeStart: () => {
            null === zK || void 0 === zK || zK(), null === MO || void 0 === MO || MO(!0)
          },
          onChangeComplete: () => {
            null === MO || void 0 === MO || MO(!1), null === AO || void 0 === AO || AO()
          }
        })
      })
    }
    async function QO() {
      let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
      const KO = DO.NotificationProvider.showPromptPopup({
        title: "settingsMenu:reloadPagePopupTitle",
        subtitle: "settingsMenu:reloadPagePopupSubtitle",
        confirmText: "settingsMenu:reloadPagePopupConfirm",
        confirmTooltip: "",
        cancelText: "general:cancel",
        cancelTooltip: "",
        unlockPointerKey: OO
      });
      !0 === await KO.getResult() && (0, MO.reloadBloxd)()
    }

    function zK(OO) {
      let {
        label: KO,
        options: pO,
        value: XO,
        onChange: bK,
        circleInfoText: eO
      } = OO;
      return (0, oO.jsxs)("div", {
        className: "SettingBox SegmentedSettingRow",
        children: [(0, oO.jsxs)("div", {
          className: "SliderText",
          children: [KO, eO && (0, oO.jsx)(lO.c, {
            className: "SettingsTextInputCircleInfo",
            hoverInfo: eO
          })]
        }), (0, oO.jsx)(vK.c, {
          ariaLabel: KO,
          options: pO,
          value: XO,
          onChange: bK
        })]
      })
    }
  },
  5805: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => nO
    });
    var XO = pO(63),
      bK = pO(1355),
      eO = pO(5678),
      lO = pO(1077),
      vK = pO(256),
      CO = pO(1180),
      hO = pO(1344),
      DO = pO(1271),
      MO = pO(1195),
      aK = pO(2061),
      oO = pO(2189),
      FO = pO(3732),
      VO = pO(1004),
      LO = pO(1329),
      QO = pO(94),
      zK = pO(1051);
    const AO = pO.p + "static/media/bloxdhubLogo.6a6c367af2ad6e6f1eb3.webp";
    var fO = pO(918),
      dO = pO.n(fO),
      TO = pO(933),
      NO = pO(1187),
      IO = pO(5674),
      yK = pO(976);
    const gK = (0, XO.lazy)((() => Promise.all([pO.e(94), pO.e(127), pO.e(124), pO.e(118), pO.e(117)]).then((() => pO(5703))).then((OO => ({
      default: OO.ShaderPackPublishForm
    })))));

    function uO(OO) {
      let {
        details: KO,
        owner: pO,
        onChanged: bK
      } = OO;
      const {
        t: lO
      } = (0, zK.D)(), vK = (0, hO.useNavigatePreserveSearch)(), {
        userContext: MO
      } = (0, VO.d)(), [aK, oO] = (0, XO.useState)(!1), [FO, QO] = (0, XO.useState)(null), [AO, fO] = (0, XO.useState)(!1), {
        packId: uO,
        name: EO,
        description: jK,
        live: YO
      } = KO;
      async function wO(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : bK;
        oO(!0), QO(null);
        try {
          await OO(), KO()
        } catch (pO) {
          console.error("Failed to change a shader pack", pO), QO((0, IO.w)(pO, lO, "shaderPackListing:ownerActionFailed"))
        } finally {
          oO(!1)
        }
      }
      const iK = (0, IO.r)(MO);
      return (0, yK.jsxs)("section", {
        className: "ShaderPackOwnerPanel",
        children: [(0, yK.jsx)("h2", {
          className: "ShaderPackSectionTitle",
          children: lO("general:manage")
        }), (0, IO.V)(pO, !(null === YO || void 0 === YO || !YO.renderId), Date.now(), lO).map((OO => (0, yK.jsxs)("div", {
          className: dO()("ShaderPackOwnerNotice", {
            Warning: "warning" === OO.tone
          }),
          children: [(0, yK.jsx)(TO.d, {
            name: "warning" === OO.tone ? "triangle-exclamation" : "circle-info"
          }), (0, yK.jsxs)("div", {
            children: [OO.text, OO.detail && (0, yK.jsx)("pre", {
              className: "ShaderPackOwnerNoticeDetail",
              children: OO.detail
            })]
          })]
        }, OO.text))), KO.ban && (0, yK.jsxs)("div", {
          className: "ShaderPackOwnerNotice Warning",
          children: [(0, yK.jsx)(TO.d, {
            name: "ban"
          }), (0, yK.jsxs)("div", {
            children: ["Banned by ", KO.ban.byName, " on ", new Date(KO.ban.at).toLocaleString()]
          })]
        }), FO && (0, yK.jsx)("div", {
          className: "ShaderPackOwnerError",
          children: FO
        }), (0, yK.jsxs)("div", {
          className: "ShaderPackOwnerActions",
          children: [(0, yK.jsxs)(DO.S, {
            disabled: aK,
            onClick: () => {
              !async function() {
                const OO = await NO.NotificationProvider.showInputPopup({
                  title: "shaderPackListing:renameTitle",
                  initialValue: EO,
                  maxLength: eO.w,
                  submitText: "general:save",
                  validate: OO => OO.trim().length < eO.x ? lO("shaderPackListing:nameTooShort", {
                    min: String(eO.x)
                  }) : null
                }).getResult();
                "notificationTornDown" !== OO && "submit" === (null === OO || void 0 === OO ? void 0 : OO.type) && OO.value.trim() !== EO && await wO((() => LO.c.updateShaderPack(MO, {
                  packId: uO,
                  name: OO.value.trim()
                })))
              }()
            },
            children: [(0, yK.jsx)(TO.d, {
              name: "pen"
            }), " ", lO("shaderPackListing:rename")]
          }), (0, yK.jsxs)(DO.S, {
            disabled: aK,
            onClick: () => {
              !async function() {
                const OO = await NO.NotificationProvider.showInputPopup({
                  title: "shaderPackListing:editDescription",
                  initialValue: jK,
                  maxLength: eO.s,
                  multiline: !0,
                  allowEmptySubmit: !0,
                  submitText: "general:save"
                }).getResult();
                "notificationTornDown" !== OO && "submit" === (null === OO || void 0 === OO ? void 0 : OO.type) && OO.value.trim() !== jK && await wO((() => LO.c.updateShaderPack(MO, {
                  packId: uO,
                  description: OO.value.trim()
                })))
              }()
            },
            children: [(0, yK.jsx)(TO.d, {
              name: "file-lines"
            }), " ", lO("shaderPackListing:editDescription")]
          }), (0, yK.jsxs)(DO.S, {
            disabled: aK || pO.isBanned && !pO.listed,
            onClick: () => {
              wO((() => LO.c.updateShaderPack(MO, {
                packId: uO,
                listed: !pO.listed
              })))
            },
            children: [(0, yK.jsx)(TO.d, {
              name: pO.listed ? "eye-slash" : "eye"
            }), " ", lO(pO.listed ? "shaderPackListing:unlist" : "shaderPackListing:relist")]
          }), !pO.isBanned && (0, yK.jsxs)(DO.d, {
            disabled: aK,
            onClick: () => {
              fO(!AO)
            },
            children: [(0, yK.jsx)(TO.d, {
              name: "upload"
            }), " ", lO("shaderPackListing:uploadVersion")]
          }), (0, yK.jsxs)(DO.M, {
            disabled: aK || pO.isBanned,
            onClick: () => {
              !async function() {
                !0 === await NO.NotificationProvider.showPromptPopup({
                  title: "shaderPackListing:deleteTitle",
                  subtitle: "shaderPackListing:deleteSubtitle",
                  confirmText: "general:delete",
                  cancelText: "general:cancel",
                  destructive: !0
                }).getResult() && await wO((() => LO.c.deleteShaderPack(MO, uO)), (() => {
                  vK(`${IO.S}?section=mine`, {
                    replace: !0
                  })
                }))
              }()
            },
            children: [(0, yK.jsx)(TO.d, {
              name: "trash-can"
            }), " ", lO("general:delete")]
          }), iK && (0, yK.jsxs)(DO.M, {
            disabled: aK,
            onClick: () => {
              wO((() => LO.c.setShaderPackBanned(MO, uO, !pO.isBanned)))
            },
            children: [(0, yK.jsx)(TO.d, {
              name: pO.isBanned ? "circle-check" : "ban"
            }), " ", pO.isBanned ? "Unban" : "Ban"]
          })]
        }), AO && (0, yK.jsx)(XO.Suspense, {
          fallback: (0, yK.jsx)(CO.e, {}),
          children: (0, yK.jsx)(gK, {
            existing: {
              packId: uO,
              name: EO,
              description: jK
            },
            onPublished: () => {
              fO(!1), bK()
            }
          })
        })]
      })
    }
    var EO = pO(77),
      jK = pO(1531),
      YO = pO(1134),
      wO = pO(4151),
      iK = pO(1056),
      rK = pO(5684),
      PO = pO(5680),
      mK = pO(5698);

    function sO(OO) {
      let {
        item: KO
      } = OO;
      const {
        t: pO
      } = (0, zK.D)(), [bK] = (0, rK.i)(), [lO, vK] = (0, XO.useState)(bK), [CO, hO] = (0, XO.useState)(!1), [DO, MO] = (0, XO.useState)(!1), {
        s3Url: aK
      } = iK.clientSideServerUrls, {
        width: oO,
        height: FO
      } = eO.t.large, VO = (0, eO.u)(aK, KO, lO, "large"), {
        renderVersion: LO
      } = KO;
      return (0, yK.jsxs)("div", {
        className: "ShaderPackPreviews",
        children: [(0, yK.jsx)(mK.d, {
          selected: lO,
          onSelect: OO => {
            vK(OO), hO(!1)
          },
          imageUrl: OO => (0, eO.u)(aK, KO, OO, "thumb")
        }), (0, yK.jsxs)("div", {
          className: "ShaderPackPreviewStage",
          children: [!CO && (0, yK.jsxs)("button", {
            type: "button",
            className: "ShaderPackPreviewMain",
            title: null === LO ? void 0 : pO("shaderPackListing:fullSize"),
            disabled: null === LO,
            onClick: () => {
              MO(!0)
            },
            children: [(0, yK.jsx)("img", {
              src: VO,
              width: oO,
              height: FO,
              alt: pO(IO.bb[lO]),
              draggable: !1
            }), (0, yK.jsx)(PO.d, {
              item: KO
            })]
          }), !CO && null !== LO && (0, yK.jsxs)(JO, {
            side: "Right",
            onClick: () => {
              hO(!0)
            },
            children: [(0, yK.jsx)(TO.d, {
              name: "arrows-left-right"
            }), " ", pO("shaderPackListing:compare")]
          }), CO && null !== LO && (0, yK.jsx)(SO, {
            item: KO,
            packUrl: VO,
            baselineUrl: (0, eO.o)(aK, LO, lO, "large")
          }), CO && (0, yK.jsx)(JO, {
            side: "Left",
            onClick: () => {
              hO(!1)
            },
            children: pO("shaderPackListing:withPack")
          }), CO && (0, yK.jsx)(JO, {
            side: "Right",
            onClick: () => {
              hO(!1)
            },
            children: pO("shaderPackListing:withoutPack")
          })]
        }), DO && (0, yK.jsx)(HO, {
          fullUrl: (0, eO.u)(aK, KO, lO, "full"),
          largeUrl: VO,
          alt: pO(IO.bb[lO]),
          onClose: () => {
            MO(!1)
          }
        })]
      })
    }

    function HO(OO) {
      let {
        fullUrl: KO,
        largeUrl: pO,
        alt: bK,
        onClose: eO
      } = OO;
      const lO = (0, XO.useRef)(null);
      return (0, YO.q)("popup", lO, eO), (0, XO.useEffect)((() => {
        function OO(OO) {
          "Escape" === OO.key && (OO.stopPropagation(), eO())
        }
        return window.addEventListener("keydown", OO, !0), () => {
          window.removeEventListener("keydown", OO, !0)
        }
      }), [eO]), (0, EO.createPortal)((0, yK.jsxs)("div", {
        ref: lO,
        className: "ShaderPackFullSize",
        onClick: eO,
        children: [(0, yK.jsx)("img", {
          className: "ShaderPackFullSizeImage",
          src: KO,
          alt: bK,
          draggable: !1,
          style: {
            backgroundImage: `url(${pO})`
          }
        }), (0, yK.jsx)(DO.i, {
          className: "ShaderPackFullSizeClose",
          onClick: eO
        })]
      }), document.body)
    }
    const RO = 5;

    function SO(OO) {
      let {
        item: KO,
        packUrl: pO,
        baselineUrl: bK
      } = OO;
      const {
        t: lO
      } = (0, zK.D)(), [vK, CO] = (0, XO.useState)(50), hO = (0, XO.useRef)(!1), DO = (0, XO.useRef)(null), {
        width: MO,
        height: aK
      } = eO.t.large;

      function oO(OO) {
        CO((KO => (0, jK.g)(KO + OO, 0, 100)))
      }

      function FO(OO) {
        const KO = OO.currentTarget.getBoundingClientRect();
        CO((0, jK.g)((OO.clientX - KO.left) / KO.width * 100, 0, 100))
      }
      return (0, wO.h)(DO, {
        adjust: OO => {
          oO(OO * RO)
        },
        setFraction: OO => {
          CO(100 * OO)
        },
        endDrag: () => {}
      }), (0, yK.jsxs)("div", {
        ref: DO,
        className: "ShaderPackCompare",
        "data-pad-slider": "",
        "data-pad-focusable": "",
        role: "slider",
        tabIndex: 0,
        "aria-label": lO("shaderPackListing:compare"),
        "aria-valuemin": 0,
        "aria-valuemax": 100,
        "aria-valuenow": Math.round(vK),
        style: {
          "--split": `${vK}%`
        },
        onKeyDown: function(OO) {
          const KO = "ArrowLeft" === OO.key ? -RO : "ArrowRight" === OO.key ? RO : 0;
          0 !== KO && (OO.preventDefault(), oO(KO))
        },
        onPointerDown: OO => {
          hO.current = !0, OO.currentTarget.setPointerCapture(OO.pointerId), FO(OO)
        },
        onPointerMove: OO => {
          hO.current && FO(OO)
        },
        onPointerUp: () => {
          hO.current = !1
        },
        onPointerCancel: () => {
          hO.current = !1
        },
        children: [(0, yK.jsx)("img", {
          className: "ShaderPackCompareBaseline",
          src: bK,
          width: MO,
          height: aK,
          alt: "",
          draggable: !1,
          style: {
            backgroundImage: `url(${pO})`
          }
        }), (0, yK.jsx)("div", {
          className: "ShaderPackCompareLine"
        }), (0, yK.jsx)("img", {
          className: "ShaderPackComparePack",
          src: pO,
          width: MO,
          height: aK,
          alt: "",
          draggable: !1
        }), (0, yK.jsx)(PO.d, {
          item: KO,
          className: "ShaderPackCompareNotice"
        })]
      })
    }

    function JO(OO) {
      let {
        side: KO,
        onClick: pO,
        children: XO
      } = OO;
      return (0, yK.jsx)("button", {
        type: "button",
        className: `ShaderPackStageButton ${KO}`,
        onClick: pO,
        children: (0, yK.jsx)("span", {
          className: "ShaderPackStageButtonFace SmallTextBold",
          children: XO
        })
      })
    }
    var cK = pO(4120),
      BO = pO(233),
      ZO = pO(5800);
    const GO = {
      compiler: "shaderPack:compilerUnavailable",
      download: "shaderPackListing:useDownloadFailed",
      apiVersion: "shaderPackListing:useOtherApiVersion",
      invalid: "shaderPackListing:useInvalid",
      errors: "shaderPackListing:useFailsHere",
      save: "shaderPack:saveFailed"
    };

    function qK(OO) {
      const {
        userContext: KO
      } = (0, VO.d)(), [bK, eO] = (0, XO.useState)(null), [lO, vK] = (0, XO.useState)(!1), [CO, hO] = (0, XO.useState)(!1), [DO, MO] = (0, XO.useState)(null), aK = null === OO || void 0 === OO ? void 0 : OO.packId, oO = null === OO || void 0 === OO ? void 0 : OO.sourceHash;
      return (0, XO.useEffect)((() => {
        if (vK(!1), MO(null), void 0 === aK) return;
        let OO = !1;
        return Promise.all([(0, QO.hasUsableWebGpuAdapter)(), (0, ZO.h)()]).then((KO => {
          let [pO, XO] = KO;
          var bK;
          OO || (eO(pO), vK((null === XO || void 0 === XO || null === (bK = XO.listing) || void 0 === bK ? void 0 : bK.packId) === aK && XO.listing.sourceHash === oO))
        })).catch((KO => {
          console.error("Failed to check whether this shader pack can be used", KO), OO || eO(!1)
        })), () => {
          OO = !0
        }
      }), [aK, oO]), {
        webGpuUsable: bK,
        inUse: lO,
        busy: CO,
        errorKey: DO,
        use: () => {
          null !== OO && async function(OO) {
            hO(!0), MO(null);
            try {
              const {
                installListedShaderPack: XO
              } = await Promise.all([pO.e(127), pO.e(124), pO.e(119)]).then((() => pO(38595))), bK = await XO({
                packId: OO.packId,
                sourceHash: OO.sourceHash,
                name: OO.name,
                ownerName: OO.ownerName,
                description: OO.description
              });
              if ("failed" === bK.kind) return void MO(GO[bK.reason]);
              vK(!0), LO.c.recordShaderPackDownload(KO, OO.packId).catch((OO => {
                console.error("Failed to count a shader pack's download", OO)
              })), (0, cK.j)()
            } catch (XO) {
              console.error("Failed to use the shader pack", XO), MO("shaderPack:unexpectedError")
            } finally {
              hO(!1)
            }
          }(OO)
        }
      }
    }

    function xK(OO) {
      let {
        packUse: KO
      } = OO;
      const {
        t: pO
      } = (0, zK.D)(), {
        webGpuUsable: XO,
        inUse: bK,
        busy: eO,
        errorKey: lO,
        use: vK
      } = KO;
      return (0, yK.jsxs)("div", {
        className: "ShaderPackUse",
        children: [(0, yK.jsxs)(DO.m, {
          disabled: !0 !== XO || bK,
          loading: eO,
          onClick: vK,
          children: [(0, yK.jsx)(TO.d, {
            name: bK ? "check" : "download"
          }), " ", pO(bK ? "shaderPackListing:inUse" : "shaderPackListing:use")]
        }), !1 === XO && (0, yK.jsx)("div", {
          className: "ShaderPackUseNote",
          children: pO((0, BO.e)() ? "shaderPack:needsWebGpuDisabledUntilRestart" : "shaderPack:needsWebGpu")
        }), lO && (0, yK.jsx)("div", {
          className: "ShaderPackUseNote Error",
          children: pO(lO)
        })]
      })
    }

    function nO() {
      var OO;
      const {
        t: KO
      } = (0, zK.D)(), pO = (0, hO.useNavigatePreserveSearch)(), {
        packId: eO
      } = (0, bK.w)(), {
        userContext: lO,
        isUserContextUpdating: vK
      } = (0, VO.d)(), [MO, aK] = (0, XO.useState)(null), [oO, QO] = (0, XO.useState)(null), [AO, fO] = (0, XO.useState)(0), dO = (0, XO.useRef)(0);

      function TO() {
        var OO;
        null !== (OO = (0, hO.getPreviousLocation)()) && void 0 !== OO && OO.startsWith(IO.S) ? pO(-1) : pO(IO.S)
      }(0, FO.e)(TO), (0, rK.c)(), (0, XO.useEffect)((() => {
        if (vK || void 0 === eO) return;
        const OO = ++dO.current;
        QO(null), LO.c.getShaderPack(lO, eO).then((KO => {
          dO.current === OO && aK(KO)
        })).catch((KO => {
          dO.current === OO && (console.error("Failed to get the shader pack", KO), aK(null), QO({
            error: KO
          }))
        }))
      }), [eO, lO, vK, AO]);
      const NO = () => {
          fO((OO => OO + 1))
        },
        gK = (null === MO || void 0 === MO ? void 0 : MO.packId) === eO ? MO : null,
        EO = (0, rK.j)(),
        jK = qK(null !== (OO = null === gK || void 0 === gK ? void 0 : gK.live) && void 0 !== OO ? OO : null),
        YO = null !== gK && void 0 !== gK && gK.live ? (0, yK.jsx)(WO, {
          item: gK.live,
          favourites: EO,
          packUse: jK
        }) : null;
      return (0, yK.jsxs)("article", {
        className: "ShaderPackInformation AnimFadeIn",
        children: [(0, yK.jsx)(DO.c, {
          onClick: TO,
          children: KO("shaderPackListing:backToPacks")
        }), null === gK && null === oO && (0, yK.jsx)("div", {
          className: "ShaderPackInformationMessage",
          children: (0, yK.jsx)(CO.e, {})
        }), null !== oO && (0, yK.jsxs)("div", {
          className: "ShaderPackInformationMessage",
          children: [(0, IO.w)(oO.error, KO, "shaderPackListing:loadPackFailed"), (0, yK.jsx)(DO.d, {
            onClick: NO,
            children: KO("general:tryAgain")
          })]
        }), null !== gK && null === oO && (0, yK.jsxs)("div", {
          className: "ShaderPackInformationBody",
          children: [(0, yK.jsxs)("header", {
            className: "ShaderPackInformationHeader",
            children: [(0, yK.jsx)("h1", {
              className: "FullyFancyText",
              children: gK.name
            }), YO]
          }), gK.live && (0, yK.jsx)(sO, {
            item: gK.live
          }), gK.live && (0, yK.jsx)(tK, {
            item: gK.live,
            ownerPreview: gK.ownerPreview,
            bloxdhubSlug: gK.bloxdhubSlug,
            actions: YO
          }), gK.owner && (0, yK.jsx)(uO, {
            details: gK,
            owner: gK.owner,
            onChanged: NO
          })]
        })]
      })
    }

    function WO(OO) {
      let {
        item: KO,
        favourites: pO,
        packUse: XO
      } = OO;
      const bK = pO.isFavourite(KO.packId);
      return (0, yK.jsxs)("div", {
        className: "ShaderPackInformationActions",
        children: [QO.featureFlags.settings.canUseShaderPacks && (0, yK.jsx)(xK, {
          packUse: XO
        }), (0, yK.jsx)(DO.w, {
          className: "ShaderPackInformationLike",
          onClick: () => {
            pO.toggle(KO.packId)
          },
          isLiked: !0 === bK,
          isLoading: null === bK
        })]
      })
    }

    function tK(OO) {
      let {
        item: KO,
        ownerPreview: pO,
        bloxdhubSlug: XO,
        actions: bK
      } = OO;
      const {
        t: vK
      } = (0, zK.D)(), CO = (0, oO.i)(), DO = null === XO ? null : (0, eO.g)(XO);
      return (0, yK.jsxs)("div", {
        className: "ShaderPackFacts",
        children: [KO.description && (0, yK.jsx)("p", {
          className: "ShaderPackDescription",
          children: KO.description
        }), (0, yK.jsxs)("div", {
          className: "ShaderPackFeatureList",
          children: [(null !== pO || null !== DO) && (0, yK.jsx)("div", {
            className: "ShaderPackAuthor",
            children: null !== pO ? (0, yK.jsxs)(yK.Fragment, {
              children: [(0, yK.jsx)(aK.h, {
                playerSocialPreview: pO,
                showLocation: !1,
                linkToProfile: !0
              }), null !== DO && (0, yK.jsx)("a", {
                className: "ShaderPackBloxdhubLogo",
                href: DO,
                target: "_blank",
                rel: "noopener noreferrer",
                children: (0, yK.jsx)("img", {
                  src: AO,
                  alt: eO.d
                })
              })]
            }) : (0, yK.jsxs)("a", {
              className: "ShaderPackBloxdhubName",
              href: DO,
              target: "_blank",
              rel: "noopener noreferrer",
              children: [eO.d, (0, yK.jsx)("img", {
                src: AO,
                alt: ""
              })]
            })
          }), IO.z.filter((OO => KO.features.includes(OO))).map((OO => (0, yK.jsx)(hO.LinkPreserveSearch, {
            className: "ShaderPackFeature",
            to: (0, IO.I)(OO),
            children: vK(IO.M[OO])
          }, OO)))]
        }), bK, (0, yK.jsxs)("dl", {
          className: "ShaderPackFactList",
          children: [(0, yK.jsxs)("div", {
            children: [(0, yK.jsx)("dt", {
              children: vK("shaderPackListing:downloads")
            }), (0, yK.jsx)("dd", {
              children: (0, lO.L)(KO.downloads)
            })]
          }), (0, yK.jsx)(kK, {
            label: vK("shaderPackListing:updated"),
            time: KO.listedUpdatedAt,
            now: CO
          }), (0, yK.jsx)(kK, {
            label: vK("shaderPackListing:created"),
            time: KO.publishedAt,
            now: CO
          }), null !== KO.gpuCost && (0, yK.jsxs)("div", {
            children: [(0, yK.jsx)("dt", {
              children: vK("shaderPackListing:lag")
            }), (0, yK.jsx)("dd", {
              children: vK("shaderPackListing:lagPercent", {
                percent: String((0, IO.Q)(KO.gpuCost))
              })
            })]
          }), (0, yK.jsxs)("div", {
            children: [(0, yK.jsx)("dt", {
              children: vK("shaderPackListing:size")
            }), (0, yK.jsx)("dd", {
              children: vK("shaderPackListing:sizeValue", {
                kilobytes: String((0, IO.O)(KO.sourceBytes))
              })
            })]
          }), (0, yK.jsxs)("div", {
            children: [(0, yK.jsx)("dt", {
              children: vK("shaderPackListing:files")
            }), (0, yK.jsx)("dd", {
              children: KO.fileCount
            })]
          })]
        })]
      })
    }

    function kK(OO) {
      let {
        label: KO,
        time: pO,
        now: XO
      } = OO;
      const {
        t: bK,
        selectedLanguage: eO
      } = (0, zK.D)(), lO = new Date(pO);
      let CO = lO.toLocaleDateString();
      if (XO - pO <= 30 * vK.h) {
        const OO = (0, zK.o)(eO.code, "shaderPackListing:timeAgo");
        CO = bK("shaderPackListing:timeAgo", {
          time: (0, vK.Z)(OO, pO, XO)
        })
      }
      return (0, yK.jsx)(MO.g, {
        tooltipInner: lO.toLocaleString(),
        children: (0, yK.jsxs)("div", {
          children: [(0, yK.jsx)("dt", {
            children: KO
          }), (0, yK.jsx)("dd", {
            children: CO
          })]
        })
      })
    }
  },
  4148: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO
    });
    var XO = pO(918),
      bK = pO.n(XO),
      eO = pO(976);

    function lO(OO) {
      let {
        options: KO,
        value: pO,
        onChange: XO,
        ariaLabel: lO
      } = OO;
      return (0, eO.jsx)("div", {
        className: "SegmentedToggle",
        role: "group",
        "aria-label": lO,
        children: KO.map((OO => {
          const KO = OO.value === pO;
          return (0, eO.jsx)("button", {
            type: "button",
            "aria-pressed": KO,
            className: bK()("SegmentedToggleOption SmallTextLight", {
              SegmentedToggleOptionSelected: KO
            }),
            onClick: () => {
              KO || XO(OO.value)
            },
            children: OO.label
          }, OO.value)
        }))
      })
    }
  },
  4151: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO,
      h: () => lO
    });
    var XO = pO(63);
    const bK = new WeakMap,
      eO = OO => {
        var KO;
        const pO = OO.closest("[data-pad-slider]");
        return pO && null !== (KO = bK.get(pO)) && void 0 !== KO ? KO : null
      },
      lO = (OO, KO) => {
        const pO = (0, XO.useRef)(KO);
        pO.current = KO, (0, XO.useEffect)((() => {
          if (OO.current) return ((OO, KO) => (bK.set(OO, KO), () => {
            bK.get(OO) === KO && bK.delete(OO)
          }))(OO.current, {
            adjust: OO => {
              pO.current.adjust(OO)
            },
            setFraction: OO => {
              pO.current.setFraction(OO)
            },
            endDrag: () => {
              pO.current.endDrag()
            }
          })
        }), [OO])
      }
  },
  5800: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK,
      h: () => eO
    });
    var XO = pO(36);
    const bK = "shaderPack";
    async function eO() {
      var OO;
      let KO = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      return null !== (OO = await XO.d.getItem(bK, KO)) && void 0 !== OO ? OO : null
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);