export const id = 241;
export const ids = [241];
export const modules = {
  39231: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => SO
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35660),
      lO = pO(35632),
      vK = pO(35664),
      CO = pO(38301),
      hO = pO(38502),
      DO = pO(38254),
      MO = pO(37966),
      aK = pO(35639);
    class oO {
      constructor() {
        this._zoomStopsAnimation = !1, this._idleRotationSpeed = .05, this._idleRotationWaitTime = 2e3, this._idleRotationSpinupTime = 2e3, this.targetAlpha = null, this._attachedCamera = null, this._isPointerDown = !1, this._lastFrameTime = null, this._lastInteractionTime = -1 / 0, this._cameraRotationSpeed = 0, this._lastFrameRadius = 0
      }
      get name() {
        return "AutoRotation"
      }
      set zoomStopsAnimation(OO) {
        this._zoomStopsAnimation = OO
      }
      get zoomStopsAnimation() {
        return this._zoomStopsAnimation
      }
      set idleRotationSpeed(OO) {
        this._idleRotationSpeed = OO
      }
      get idleRotationSpeed() {
        return this._idleRotationSpeed
      }
      set idleRotationWaitTime(OO) {
        this._idleRotationWaitTime = OO
      }
      get idleRotationWaitTime() {
        return this._idleRotationWaitTime
      }
      set idleRotationSpinupTime(OO) {
        this._idleRotationSpinupTime = OO
      }
      get idleRotationSpinupTime() {
        return this._idleRotationSpinupTime
      }
      get rotationInProgress() {
        return Math.abs(this._cameraRotationSpeed) > 0
      }
      get attachedNode() {
        return this._attachedCamera
      }
      init() {}
      attach(OO) {
        this._attachedCamera = OO;
        const KO = this._attachedCamera.JKO();
        this._onPrePointerObservableObserver = KO.onPrePointerObservable.add((OO => {
          OO.type !== DO.c.POINTERDOWN ? OO.type === DO.c.POINTERUP && (this._isPointerDown = !1) : this._isPointerDown = !0
        })), this._onAfterCheckInputsObserver = OO.onAfterCheckInputsObservable.add((() => {
          if (this._reachTargetAlpha()) return;
          const OO = MO.d.Now;
          let KO = 0;
          null != this._lastFrameTime && (KO = OO - this._lastFrameTime), this._lastFrameTime = OO, this._applyUserInteraction();
          const pO = OO - this._lastInteractionTime - this._idleRotationWaitTime,
            XO = Math.max(Math.min(pO / this._idleRotationSpinupTime, 1), 0);
          this._cameraRotationSpeed = this._idleRotationSpeed * XO, this._attachedCamera && (this._attachedCamera.alpha -= this._cameraRotationSpeed * (KO / 1e3))
        }))
      }
      detach() {
        if (!this._attachedCamera) return;
        const OO = this._attachedCamera.JKO();
        this._onPrePointerObservableObserver && OO.onPrePointerObservable.remove(this._onPrePointerObservableObserver), this._attachedCamera.onAfterCheckInputsObservable.remove(this._onAfterCheckInputsObserver), this._attachedCamera = null, this._lastFrameTime = null
      }
      resetLastInteractionTime(OO) {
        this._lastInteractionTime = OO ?? MO.d.Now
      }
      _reachTargetAlpha() {
        return !(!this._attachedCamera || null === this.targetAlpha) && Math.abs(this._attachedCamera.alpha - this.targetAlpha) < aK.c
      }
      _userIsZooming() {
        return !!this._attachedCamera && 0 !== this._attachedCamera.inertialRadiusOffset
      }
      _shouldAnimationStopForInteraction() {
        if (!this._attachedCamera) return !1;
        let OO = !1;
        return this._lastFrameRadius === this._attachedCamera.radius && 0 !== this._attachedCamera.inertialRadiusOffset && (OO = !0), this._lastFrameRadius = this._attachedCamera.radius, this._zoomStopsAnimation ? OO : this._userIsZooming()
      }
      _applyUserInteraction() {
        this._userIsMoving() && !this._shouldAnimationStopForInteraction() && (this._lastInteractionTime = MO.d.Now)
      }
      _userIsMoving() {
        return !!this._attachedCamera && (0 !== this._attachedCamera.inertialAlphaOffset || 0 !== this._attachedCamera.inertialBetaOffset || 0 !== this._attachedCamera.inertialRadiusOffset || 0 !== this._attachedCamera.inertialPanningX || 0 !== this._attachedCamera.inertialPanningY || this._isPointerDown)
      }
    }
    pO(39234);
    class FO {
      constructor() {
        this._easingMode = FO.EASINGMODE_EASEIN
      }
      setEasingMode(OO) {
        const KO = Math.min(Math.max(OO, 0), 2);
        this._easingMode = KO
      }
      getEasingMode() {
        return this._easingMode
      }
      easeInCore(OO) {
        throw new Error("You must implement this method")
      }
      ease(OO) {
        switch (this._easingMode) {
          case FO.EASINGMODE_EASEIN:
            return this.easeInCore(OO);
          case FO.EASINGMODE_EASEOUT:
            return 1 - this.easeInCore(1 - OO)
        }
        return OO >= .5 ? .5 * (1 - this.easeInCore(2 * (1 - OO))) + .5 : .5 * this.easeInCore(2 * OO)
      }
    }
    FO.EASINGMODE_EASEIN = 0, FO.EASINGMODE_EASEOUT = 1, FO.EASINGMODE_EASEINOUT = 2;
    var VO = pO(39242);
    class LO {
      constructor() {
        this.transitionDuration = 450, this.lowerRadiusTransitionRange = 2, this.upperRadiusTransitionRange = -2, this._autoTransitionRange = !1, this._attachedCamera = null, this._radiusIsAnimating = !1, this._radiusBounceTransition = null, this._animatables = new Array
      }
      get name() {
        return "Bouncing"
      }
      get autoTransitionRange() {
        return this._autoTransitionRange
      }
      set autoTransitionRange(OO) {
        if (this._autoTransitionRange === OO) return;
        this._autoTransitionRange = OO;
        const KO = this._attachedCamera;
        KO && (OO ? this._onMeshTargetChangedObserver = KO.onMeshTargetChangedObservable.add((OO => {
          if (OO && (OO.computeWorldMatrix(!0), OO.hpO)) {
            const KO = OO.hpO().diagonalLength;
            this.lowerRadiusTransitionRange = .05 * KO, this.upperRadiusTransitionRange = .05 * KO
          }
        })) : this._onMeshTargetChangedObserver && KO.onMeshTargetChangedObservable.remove(this._onMeshTargetChangedObserver))
      }
      get attachedNode() {
        return this._attachedCamera
      }
      init() {}
      attach(OO) {
        this._attachedCamera = OO, this._onAfterCheckInputsObserver = OO.onAfterCheckInputsObservable.add((() => {
          this._attachedCamera && (this._isRadiusAtLimit(this._attachedCamera.lowerRadiusLimit) && this._applyBoundRadiusAnimation(this.lowerRadiusTransitionRange), this._isRadiusAtLimit(this._attachedCamera.upperRadiusLimit) && this._applyBoundRadiusAnimation(this.upperRadiusTransitionRange))
        }))
      }
      detach() {
        this._attachedCamera && (this._onAfterCheckInputsObserver && this._attachedCamera.onAfterCheckInputsObservable.remove(this._onAfterCheckInputsObserver), this._onMeshTargetChangedObserver && this._attachedCamera.onMeshTargetChangedObservable.remove(this._onMeshTargetChangedObserver), this._attachedCamera = null)
      }
      _isRadiusAtLimit(OO) {
        return !!this._attachedCamera && (this._attachedCamera.radius === OO && !this._radiusIsAnimating)
      }
      _applyBoundRadiusAnimation(OO) {
        if (!this._attachedCamera) return;
        this._radiusBounceTransition || (LO.EasingFunction.setEasingMode(LO.EasingMode), this._radiusBounceTransition = VO.e.CreateAnimation("radius", VO.e.ANIMATIONTYPE_FLOAT, 60, LO.EasingFunction)), this._cachedWheelPrecision = this._attachedCamera.wheelPrecision, this._attachedCamera.wheelPrecision = 1 / 0, this._attachedCamera.inertialRadiusOffset = 0, this.stopAllAnimations(), this._radiusIsAnimating = !0;
        const KO = VO.e.TransitionTo("radius", this._attachedCamera.radius + OO, this._attachedCamera, this._attachedCamera.JKO(), 60, this._radiusBounceTransition, this.transitionDuration, (() => this._clearAnimationLocks()));
        KO && this._animatables.push(KO)
      }
      _clearAnimationLocks() {
        this._radiusIsAnimating = !1, this._attachedCamera && (this._attachedCamera.wheelPrecision = this._cachedWheelPrecision)
      }
      stopAllAnimations() {
        for (this._attachedCamera && (this._attachedCamera.animations = []); this._animatables.length;) this._animatables[0].onAnimationEnd = null, this._animatables[0].stop(), this._animatables.shift()
      }
    }
    LO.EasingFunction = new class extends FO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
        super(), this.amplitude = OO
      }
      easeInCore(OO) {
        const KO = Math.max(0, this.amplitude);
        return Math.pow(OO, 3) - OO * KO * Math.sin(3.141592653589793 * OO)
      }
    }(.3), LO.EasingMode = FO.EASINGMODE_EASEOUT;
    class QO {
      constructor() {
        this.onTargetFramingAnimationEndObservable = new eO.e, this._mode = QO.FitFrustumSidesMode, this._radiusScale = 1, this._positionScale = .5, this._defaultElevation = .3, this._elevationReturnTime = 1500, this._elevationReturnWaitTime = 1e3, this._zoomStopsAnimation = !1, this._framingTime = 1500, this.autoCorrectCameraLimitsAndSensibility = !0, this._attachedCamera = null, this._isPointerDown = !1, this._lastInteractionTime = -1 / 0, this._animatables = new Array, this._betaIsAnimating = !1
      }
      get name() {
        return "Framing"
      }
      set mode(OO) {
        this._mode = OO
      }
      get mode() {
        return this._mode
      }
      set radiusScale(OO) {
        this._radiusScale = OO
      }
      get radiusScale() {
        return this._radiusScale
      }
      set positionScale(OO) {
        this._positionScale = OO
      }
      get positionScale() {
        return this._positionScale
      }
      set defaultElevation(OO) {
        this._defaultElevation = OO
      }
      get defaultElevation() {
        return this._defaultElevation
      }
      set elevationReturnTime(OO) {
        this._elevationReturnTime = OO
      }
      get elevationReturnTime() {
        return this._elevationReturnTime
      }
      set elevationReturnWaitTime(OO) {
        this._elevationReturnWaitTime = OO
      }
      get elevationReturnWaitTime() {
        return this._elevationReturnWaitTime
      }
      set zoomStopsAnimation(OO) {
        this._zoomStopsAnimation = OO
      }
      get zoomStopsAnimation() {
        return this._zoomStopsAnimation
      }
      set framingTime(OO) {
        this._framingTime = OO
      }
      get framingTime() {
        return this._framingTime
      }
      get attachedNode() {
        return this._attachedCamera
      }
      init() {}
      attach(OO) {
        this._attachedCamera = OO;
        const KO = this._attachedCamera.JKO();
        QO.EasingFunction.setEasingMode(QO.EasingMode), this._onPrePointerObservableObserver = KO.onPrePointerObservable.add((OO => {
          OO.type !== DO.c.POINTERDOWN ? OO.type === DO.c.POINTERUP && (this._isPointerDown = !1) : this._isPointerDown = !0
        })), this._onMeshTargetChangedObserver = OO.onMeshTargetChangedObservable.add((OO => {
          OO && OO.hpO && this.zoomOnMesh(OO, void 0, (() => {
            this.onTargetFramingAnimationEndObservable.notifyObservers()
          }))
        })), this._onAfterCheckInputsObserver = OO.onAfterCheckInputsObservable.add((() => {
          this._applyUserInteraction(), this._maintainCameraAboveGround()
        }))
      }
      detach() {
        if (!this._attachedCamera) return;
        const OO = this._attachedCamera.JKO();
        this._onPrePointerObservableObserver && OO.onPrePointerObservable.remove(this._onPrePointerObservableObserver), this._onAfterCheckInputsObserver && this._attachedCamera.onAfterCheckInputsObservable.remove(this._onAfterCheckInputsObserver), this._onMeshTargetChangedObserver && this._attachedCamera.onMeshTargetChangedObservable.remove(this._onMeshTargetChangedObserver), this._attachedCamera = null
      }
      zoomOnMesh(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        OO.computeWorldMatrix(!0);
        const XO = OO.hpO().boundingBox;
        this.zoomOnBoundingInfo(XO.minimumWorld, XO.maximumWorld, KO, pO)
      }
      zoomOnMeshHierarchy(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        OO.computeWorldMatrix(!0);
        const XO = OO.getHierarchyBoundingVectors(!0);
        this.zoomOnBoundingInfo(XO.min, XO.max, KO, pO)
      }
      zoomOnMeshesHierarchy(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
        const XO = new lO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE),
          bK = new lO.o(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
        for (let eO = 0; eO < OO.length; eO++) {
          const KO = OO[eO].getHierarchyBoundingVectors(!0);
          lO.o.CheckExtends(KO.min, XO, bK), lO.o.CheckExtends(KO.max, XO, bK)
        }
        this.zoomOnBoundingInfo(XO, bK, KO, pO)
      }
      zoomOnBoundingInfo(OO, KO) {
        let pO, XO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
          bK = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null;
        if (!this._attachedCamera) return !1;
        const eO = OO.y,
          vK = eO + (KO.y - eO) * this._positionScale,
          CO = KO.subtract(OO).scale(.5);
        if (!isFinite(vK)) return !1;
        if (XO) pO = new lO.o(0, vK, 0);
        else {
          const KO = OO.add(CO);
          pO = new lO.o(KO.x, vK, KO.z)
        }
        this._vectorTransition || (this._vectorTransition = VO.e.CreateAnimation("target", VO.e.ANIMATIONTYPE_VECTOR3, 60, QO.EasingFunction)), this._betaIsAnimating = !0;
        let hO = VO.e.TransitionTo("target", pO, this._attachedCamera, this._attachedCamera.JKO(), 60, this._vectorTransition, this._framingTime);
        hO && this._animatables.push(hO);
        let DO = 0;
        if (this._mode === QO.FitFrustumSidesMode) {
          const pO = this._calculateLowerRadiusFromModelBoundingSphere(OO, KO);
          this.autoCorrectCameraLimitsAndSensibility && (this._attachedCamera.lowerRadiusLimit = CO.length() + this._attachedCamera.minZ), DO = pO
        } else this._mode === QO.IgnoreBoundsSizeMode && (DO = this._calculateLowerRadiusFromModelBoundingSphere(OO, KO), this.autoCorrectCameraLimitsAndSensibility && null === this._attachedCamera.lowerRadiusLimit && (this._attachedCamera.lowerRadiusLimit = this._attachedCamera.minZ));
        if (this.autoCorrectCameraLimitsAndSensibility) {
          const pO = KO.subtract(OO).length();
          this._attachedCamera.panningSensibility = 5e3 / pO, this._attachedCamera.wheelPrecision = 100 / DO
        }
        return this._radiusTransition || (this._radiusTransition = VO.e.CreateAnimation("radius", VO.e.ANIMATIONTYPE_FLOAT, 60, QO.EasingFunction)), hO = VO.e.TransitionTo("radius", DO, this._attachedCamera, this._attachedCamera.JKO(), 60, this._radiusTransition, this._framingTime, (() => {
          this.stopAllAnimations(), bK && bK(), this._attachedCamera && this._attachedCamera.useInputToRestoreState && this._attachedCamera.storeState()
        })), hO && this._animatables.push(hO), !0
      }
      _calculateLowerRadiusFromModelBoundingSphere(OO, KO) {
        const pO = this._attachedCamera;
        if (!pO) return 0;
        let XO = pO._calculateLowerRadiusFromModelBoundingSphere(OO, KO, this._radiusScale);
        return pO.lowerRadiusLimit && this._mode === QO.IgnoreBoundsSizeMode && (XO = XO < pO.lowerRadiusLimit ? pO.lowerRadiusLimit : XO), pO.upperRadiusLimit && (XO = XO > pO.upperRadiusLimit ? pO.upperRadiusLimit : XO), XO
      }
      _maintainCameraAboveGround() {
        if (this._elevationReturnTime < 0) return;
        const OO = MO.d.Now - this._lastInteractionTime,
          KO = .5 * Math.PI - this._defaultElevation,
          pO = .5 * Math.PI;
        if (this._attachedCamera && !this._betaIsAnimating && this._attachedCamera.beta > pO && OO >= this._elevationReturnWaitTime) {
          this._betaIsAnimating = !0, this.stopAllAnimations(), this._betaTransition || (this._betaTransition = VO.e.CreateAnimation("beta", VO.e.ANIMATIONTYPE_FLOAT, 60, QO.EasingFunction));
          const OO = VO.e.TransitionTo("beta", KO, this._attachedCamera, this._attachedCamera.JKO(), 60, this._betaTransition, this._elevationReturnTime, (() => {
            this._clearAnimationLocks(), this.stopAllAnimations()
          }));
          OO && this._animatables.push(OO)
        }
      }
      _clearAnimationLocks() {
        this._betaIsAnimating = !1
      }
      _applyUserInteraction() {
        this.isUserIsMoving && (this._lastInteractionTime = MO.d.Now, this.stopAllAnimations(), this._clearAnimationLocks())
      }
      stopAllAnimations() {
        for (this._attachedCamera && (this._attachedCamera.animations = []); this._animatables.length;) this._animatables[0] && (this._animatables[0].onAnimationEnd = null, this._animatables[0].stop()), this._animatables.shift()
      }
      get isUserIsMoving() {
        return !!this._attachedCamera && (0 !== this._attachedCamera.inertialAlphaOffset || 0 !== this._attachedCamera.inertialBetaOffset || 0 !== this._attachedCamera.inertialRadiusOffset || 0 !== this._attachedCamera.inertialPanningX || 0 !== this._attachedCamera.inertialPanningY || this._isPointerDown)
      }
    }
    QO.EasingFunction = new class extends FO {
      constructor() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 2;
        super(), this.exponent = OO
      }
      easeInCore(OO) {
        return this.exponent <= 0 ? OO : (Math.exp(this.exponent * OO) - 1) / (Math.exp(this.exponent) - 1)
      }
    }, QO.EasingMode = FO.EASINGMODE_EASEINOUT, QO.IgnoreBoundsSizeMode = 0, QO.FitFrustumSidesMode = 1;
    var zK = pO(38294),
      AO = pO(38287),
      fO = pO(38330),
      dO = pO(38172);
    let TO = (() => {
        var OO;
        let KO, pO = [],
          eO = [];
        return OO = class {
          constructor() {
            this._currentMousePointerIdDown = -1, this.buttons = (0, XO.i)(this, pO, [0, 1, 2]), this._pointerInput = (0, XO.i)(this, eO)
          }
          attachControl(OO) {
            OO = dO.k.BackCompatCameraNoPreventDefault(arguments);
            const KO = this.camera.qb(),
              pO = KO.getInputElement();
            let XO = 0,
              bK = null;
            this._pointA = null, this._pointB = null, this._altKey = !1, this._ctrlKey = !1, this._metaKey = !1, this._shiftKey = !1, this._buttonsPressed = 0, this._pointerInput = eO => {
              const lO = eO.event,
                vK = "touch" === lO.pointerType;
              if (eO.type !== DO.c.POINTERMOVE && -1 === this.buttons.indexOf(lO.button)) return;
              const CO = lO.target;
              if (this._altKey = lO.altKey, this._ctrlKey = lO.ctrlKey, this._metaKey = lO.metaKey, this._shiftKey = lO.shiftKey, this._buttonsPressed = lO.buttons, KO.isPointerLock) {
                const OO = lO.movementX,
                  KO = lO.movementY;
                this.onTouch(null, OO, KO), this._pointA = null, this._pointB = null
              } else {
                if (eO.type !== DO.c.POINTERDOWN && eO.type !== DO.c.POINTERDOUBLETAP && vK && this._pointA?.pointerId !== lO.pointerId && this._pointB?.pointerId !== lO.pointerId) return;
                if (eO.type !== DO.c.POINTERDOWN || -1 !== this._currentMousePointerIdDown && !vK)
                  if (eO.type === DO.c.POINTERDOUBLETAP) this.onDoubleTap(lO.pointerType, lO);
                  else if (eO.type !== DO.c.POINTERUP || this._currentMousePointerIdDown !== lO.pointerId && !vK) {
                  if (eO.type === DO.c.POINTERMOVE)
                    if (OO || lO.preventDefault(), this._pointA && null === this._pointB) {
                      const OO = lO.clientX - this._pointA.x,
                        KO = lO.clientY - this._pointA.y;
                      this._pointA.x = lO.clientX, this._pointA.y = lO.clientY, this.onTouch(this._pointA, OO, KO)
                    } else if (this._pointA && this._pointB) {
                    const OO = this._pointA.pointerId === lO.pointerId ? this._pointA : this._pointB;
                    OO.x = lO.clientX, OO.y = lO.clientY;
                    const KO = this._pointA.x - this._pointB.x,
                      pO = this._pointA.y - this._pointB.y,
                      vK = KO * KO + pO * pO,
                      CO = {
                        x: (this._pointA.x + this._pointB.x) / 2,
                        y: (this._pointA.y + this._pointB.y) / 2,
                        pointerId: lO.pointerId,
                        type: eO.type
                      };
                    this.onMultiTouch(this._pointA, this._pointB, XO, vK, bK, CO), bK = CO, XO = vK
                  }
                } else {
                  try {
                    CO?.releasePointerCapture(lO.pointerId)
                  } catch (hO) {}
                  vK || (this._pointB = null), KO._badOS ? this._pointA = this._pointB = null : this._pointB && this._pointA && this._pointA.pointerId == lO.pointerId ? (this._pointA = this._pointB, this._pointB = null) : this._pointA && this._pointB && this._pointB.pointerId == lO.pointerId ? this._pointB = null : this._pointA = this._pointB = null, (0 !== XO || bK) && (this.onMultiTouch(this._pointA, this._pointB, XO, 0, bK, null), XO = 0, bK = null), this._currentMousePointerIdDown = -1, this.onButtonUp(lO), OO || lO.preventDefault()
                } else {
                  try {
                    CO?.setPointerCapture(lO.pointerId)
                  } catch (hO) {}
                  if (null === this._pointA) this._pointA = {
                    x: lO.clientX,
                    y: lO.clientY,
                    pointerId: lO.pointerId,
                    type: lO.pointerType,
                    button: lO.button
                  };
                  else {
                    if (null !== this._pointB) return;
                    this._pointB = {
                      x: lO.clientX,
                      y: lO.clientY,
                      pointerId: lO.pointerId,
                      type: lO.pointerType,
                      button: lO.button
                    }
                  } - 1 !== this._currentMousePointerIdDown || vK || (this._currentMousePointerIdDown = lO.pointerId), this.onButtonDown(lO), OO || (lO.preventDefault(), pO && pO.focus())
                }
              }
            }, this._observer = this.camera.JKO()._inputManager._addCameraPointerObserver(this._pointerInput, DO.c.POINTERDOWN | DO.c.POINTERUP | DO.c.POINTERMOVE | DO.c.POINTERDOUBLETAP), this._onLostFocus = () => {
              this._pointA = this._pointB = null, XO = 0, bK = null, this.onLostFocus()
            }, this._contextMenuBind = OO => this.onContextMenu(OO), pO && pO.addEventListener("contextmenu", this._contextMenuBind, !1);
            const eO = this.camera.JKO().qb().getHostWindow();
            eO && dO.k.RegisterTopRootEvents(eO, [{
              name: "blur",
              handler: this._onLostFocus
            }])
          }
          detachControl() {
            if (this._onLostFocus) {
              const OO = this.camera.JKO().qb().getHostWindow();
              OO && dO.k.UnregisterTopRootEvents(OO, [{
                name: "blur",
                handler: this._onLostFocus
              }])
            }
            if (this._observer) {
              if (this.camera.JKO()._inputManager._removeCameraPointerObserver(this._observer), this._observer = null, this._contextMenuBind) {
                const OO = this.camera.JKO().qb().getInputElement();
                OO && OO.removeEventListener("contextmenu", this._contextMenuBind)
              }
              this._onLostFocus = null
            }
            this._altKey = !1, this._ctrlKey = !1, this._metaKey = !1, this._shiftKey = !1, this._buttonsPressed = 0, this._currentMousePointerIdDown = -1
          }
          getClassName() {
            return "BaseCameraPointersInput"
          }
          getSimpleName() {
            return "pointers"
          }
          onDoubleTap(OO, KO) {}
          onTouch(OO, KO, pO) {}
          onMultiTouch(OO, KO, pO, XO, bK, eO) {}
          onContextMenu(OO) {
            OO.preventDefault()
          }
          onButtonDown(OO) {}
          onButtonUp(OO) {}
          onLostFocus() {}
        }, (() => {
          const lO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
          KO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "buttons",
            static: !1,
            private: !1,
            access: {
              has: OO => "buttons" in OO,
              get: OO => OO.buttons,
              set: (OO, KO) => {
                OO.buttons = KO
              }
            },
            metadata: lO
          }, pO, eO), lO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: lO
          })
        })(), OO
      })(),
      NO = (() => {
        var OO;
        let KO, pO, eO, lO = TO,
          vK = [],
          CO = [],
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        return OO = class extends lO {
          constructor() {
            super(...arguments), this.pinchZoom = (0, XO.i)(this, vK, !0), this.multiTouchPanning = ((0, XO.i)(this, CO), (0, XO.i)(this, hO, !0)), this.multiTouchPanAndZoom = ((0, XO.i)(this, DO), (0, XO.i)(this, MO, !0)), this._isPinching = ((0, XO.i)(this, aK), !1), this._twoFingerActivityCount = 0, this._shouldStartPinchZoom = !1
          }
          _computePinchZoom(OO, KO) {}
          _computeMultiTouchPanning(OO, KO) {}
          onMultiTouch(OO, KO, pO, XO, bK, eO) {
            0 === pO && null === bK || 0 === XO && null === eO || (this.multiTouchPanAndZoom ? (this._computePinchZoom(pO, XO), this._computeMultiTouchPanning(bK, eO)) : this.multiTouchPanning && this.pinchZoom ? (this._twoFingerActivityCount++, this._isPinching || this._shouldStartPinchZoom ? (this._computePinchZoom(pO, XO), this._isPinching = !0) : this._computeMultiTouchPanning(bK, eO)) : this.multiTouchPanning ? this._computeMultiTouchPanning(bK, eO) : this.pinchZoom && this._computePinchZoom(pO, XO))
          }
          onButtonUp(OO) {
            this._twoFingerActivityCount = 0, this._isPinching = !1
          }
          onLostFocus() {
            this._twoFingerActivityCount = 0, this._isPinching = !1
          }
        }, (() => {
          const oO = "function" === typeof Symbol && Symbol.metadata ? Object.create(lO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "pinchZoom",
            static: !1,
            private: !1,
            access: {
              has: OO => "pinchZoom" in OO,
              get: OO => OO.pinchZoom,
              set: (OO, KO) => {
                OO.pinchZoom = KO
              }
            },
            metadata: oO
          }, vK, CO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "multiTouchPanning",
            static: !1,
            private: !1,
            access: {
              has: OO => "multiTouchPanning" in OO,
              get: OO => OO.multiTouchPanning,
              set: (OO, KO) => {
                OO.multiTouchPanning = KO
              }
            },
            metadata: oO
          }, hO, DO), (0, XO.f)(null, null, eO, {
            kind: "field",
            name: "multiTouchPanAndZoom",
            static: !1,
            private: !1,
            access: {
              has: OO => "multiTouchPanAndZoom" in OO,
              get: OO => OO.multiTouchPanAndZoom,
              set: (OO, KO) => {
                OO.multiTouchPanAndZoom = KO
              }
            },
            metadata: oO
          }, MO, aK), oO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: oO
          })
        })(), OO
      })(),
      IO = (() => {
        var OO;
        let KO, pO, eO, lO, vK, CO, hO, DO = NO,
          MO = [],
          aK = [],
          oO = [],
          FO = [],
          VO = [],
          LO = [],
          QO = [],
          zK = [],
          AO = [],
          fO = [],
          dO = [],
          TO = [],
          IO = [],
          yK = [];
        return OO = class extends DO {
          constructor() {
            super(...arguments), this.buttons = (0, XO.i)(this, MO, [0, 1, 2]), this.angularSensibilityX = ((0, XO.i)(this, aK), (0, XO.i)(this, oO, 1e3)), this.angularSensibilityY = ((0, XO.i)(this, FO), (0, XO.i)(this, VO, 1e3)), this.pinchPrecision = ((0, XO.i)(this, LO), (0, XO.i)(this, QO, 12)), this.pinchDeltaPercentage = ((0, XO.i)(this, zK), (0, XO.i)(this, AO, 0)), this.useNaturalPinchZoom = ((0, XO.i)(this, fO), (0, XO.i)(this, dO, !1)), this.panningSensibility = ((0, XO.i)(this, TO), (0, XO.i)(this, IO, 1e3)), this.pinchInwards = ((0, XO.i)(this, yK), !0), this._activeEntry = null, this._pointerLockConditions = {
              button: 0,
              modifiers: {}
            }, this._pointerModifiers = {
              ctrl: !1,
              alt: !1,
              shift: !1
            }, this._pointerConditions = {
              modifiers: this._pointerModifiers
            }
          }
          getClassName() {
            return "ArcRotateCameraPointersInput"
          }
          _computeMultiTouchPanning(OO, KO) {
            if (OO && KO) {
              const pO = KO.x - OO.x,
                XO = KO.y - OO.y,
                bK = this.camera.movement.input.getEntry("pointer", "pan"),
                eO = bK?.sensitivity ?? (0 !== this.panningSensibility ? 1 / this.panningSensibility : 0);
              0 !== eO && (this.camera.movement.activeInput = !0, this.camera.movement.panAccumulatedPixels.x += -pO * eO, this.camera.movement.panAccumulatedPixels.y += XO * eO)
            }
          }
          _computePinchZoom(KO, pO) {
            const XO = this.camera.radius || OO.MinimumRadiusForPinch;
            if (this.useNaturalPinchZoom) this.camera.radius = XO * Math.sqrt(KO) / Math.sqrt(pO);
            else if (this.pinchDeltaPercentage) {
              const OO = .001 * (pO - KO) * XO * this.pinchDeltaPercentage;
              this.camera.movement.activeInput = !0, this.camera.movement.zoomAccumulatedPixels += OO
            } else {
              const OO = (pO - KO) / (this.pinchPrecision * (this.pinchInwards ? 1 : -1) * (this.angularSensibilityX + this.angularSensibilityY) / 2);
              this.camera.movement.activeInput = !0, this.camera.movement.zoomAccumulatedPixels += OO
            }
          }
          onTouch(OO, KO, pO) {
            const XO = this._activeEntry ?? (this.camera.qb().isPointerLock ? this.camera.movement.input.resolveInteraction("pointer", this._pointerLockConditions) : null);
            if (XO)
              if ("pan" === XO.interaction) {
                const OO = XO.sensitivity ?? (0 !== this.panningSensibility ? 1 / this.panningSensibility : 0);
                0 !== OO && (this.camera.movement.activeInput = !0, this.camera.movement.panAccumulatedPixels.x += -KO * OO, this.camera.movement.panAccumulatedPixels.y += pO * OO)
              } else if ("rotate" === XO.interaction) {
              const OO = XO.tbO ?? XO.sensitivity ?? 1 / this.angularSensibilityX,
                bK = XO.kbO ?? XO.sensitivity ?? 1 / this.angularSensibilityY;
              this.camera.movement.activeInput = !0, this.camera.movement.rotationAccumulatedPixels.x += -KO * OO, this.camera.movement.rotationAccumulatedPixels.y += -pO * bK
            }
          }
          onDoubleTap() {
            this.camera.useInputToRestoreState && this.camera.restoreState()
          }
          onMultiTouch(OO, KO, pO, XO, bK, eO) {
            this._shouldStartPinchZoom = this._twoFingerActivityCount < 20 && Math.abs(Math.sqrt(XO) - Math.sqrt(pO)) > this.camera.pinchToPanMaxDistance, super.onMultiTouch(OO, KO, pO, XO, bK, eO)
          }
          onButtonDown(OO) {
            this._pointerConditions.button = OO.button, this._pointerModifiers.ctrl = OO.ctrlKey, this._pointerModifiers.alt = OO.altKey, this._pointerModifiers.shift = OO.shiftKey, this._activeEntry = this.camera.movement.input.resolveInteraction("pointer", this._pointerConditions), super.onButtonDown(OO)
          }
          onButtonUp(OO) {
            this._activeEntry = null, super.onButtonUp(OO)
          }
          onLostFocus() {
            this._activeEntry = null, super.onLostFocus()
          }
        }, (() => {
          const NO = "function" === typeof Symbol && Symbol.metadata ? Object.create(DO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], lO = [(0, bK.M)()], vK = [(0, bK.M)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "buttons",
            static: !1,
            private: !1,
            access: {
              has: OO => "buttons" in OO,
              get: OO => OO.buttons,
              set: (OO, KO) => {
                OO.buttons = KO
              }
            },
            metadata: NO
          }, MO, aK), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "angularSensibilityX",
            static: !1,
            private: !1,
            access: {
              has: OO => "angularSensibilityX" in OO,
              get: OO => OO.angularSensibilityX,
              set: (OO, KO) => {
                OO.angularSensibilityX = KO
              }
            },
            metadata: NO
          }, oO, FO), (0, XO.f)(null, null, eO, {
            kind: "field",
            name: "angularSensibilityY",
            static: !1,
            private: !1,
            access: {
              has: OO => "angularSensibilityY" in OO,
              get: OO => OO.angularSensibilityY,
              set: (OO, KO) => {
                OO.angularSensibilityY = KO
              }
            },
            metadata: NO
          }, VO, LO), (0, XO.f)(null, null, lO, {
            kind: "field",
            name: "pinchPrecision",
            static: !1,
            private: !1,
            access: {
              has: OO => "pinchPrecision" in OO,
              get: OO => OO.pinchPrecision,
              set: (OO, KO) => {
                OO.pinchPrecision = KO
              }
            },
            metadata: NO
          }, QO, zK), (0, XO.f)(null, null, vK, {
            kind: "field",
            name: "pinchDeltaPercentage",
            static: !1,
            private: !1,
            access: {
              has: OO => "pinchDeltaPercentage" in OO,
              get: OO => OO.pinchDeltaPercentage,
              set: (OO, KO) => {
                OO.pinchDeltaPercentage = KO
              }
            },
            metadata: NO
          }, AO, fO), (0, XO.f)(null, null, CO, {
            kind: "field",
            name: "useNaturalPinchZoom",
            static: !1,
            private: !1,
            access: {
              has: OO => "useNaturalPinchZoom" in OO,
              get: OO => OO.useNaturalPinchZoom,
              set: (OO, KO) => {
                OO.useNaturalPinchZoom = KO
              }
            },
            metadata: NO
          }, dO, TO), (0, XO.f)(null, null, hO, {
            kind: "field",
            name: "panningSensibility",
            static: !1,
            private: !1,
            access: {
              has: OO => "panningSensibility" in OO,
              get: OO => OO.panningSensibility,
              set: (OO, KO) => {
                OO.panningSensibility = KO
              }
            },
            metadata: NO
          }, IO, yK), NO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: NO
          })
        })(), OO.MinimumRadiusForPinch = .001, OO
      })();
    fO.b.ArcRotateCameraPointersInput = IO;
    var yK = pO(38258);
    let gK = (() => {
      var OO;
      let KO, pO, eO, vK, CO, hO, DO, MO, aK, oO, FO, VO = [],
        LO = [],
        QO = [],
        zK = [],
        AO = [],
        fO = [],
        TO = [],
        NO = [],
        IO = [],
        gK = [],
        uO = [],
        EO = [],
        jK = [],
        YO = [],
        wO = [],
        iK = [],
        rK = [],
        PO = [],
        mK = [],
        sO = [],
        HO = [];
      return OO = class {
        constructor() {
          this.camera = (0, XO.i)(this, VO), this.keysUp = (0, XO.i)(this, LO, [38]), this.keysDown = ((0, XO.i)(this, QO), (0, XO.i)(this, zK, [40])), this.keysLeft = ((0, XO.i)(this, AO), (0, XO.i)(this, fO, [37])), this.keysRight = ((0, XO.i)(this, TO), (0, XO.i)(this, NO, [39])), this.keysReset = ((0, XO.i)(this, IO), (0, XO.i)(this, gK, [220])), this.keysZoomIn = ((0, XO.i)(this, uO), (0, XO.i)(this, EO, [187, 107])), this.keysZoomOut = ((0, XO.i)(this, jK), (0, XO.i)(this, YO, [189, 109])), this.panningSensibility = ((0, XO.i)(this, wO), (0, XO.i)(this, iK, 50)), this.zoomingSensibility = ((0, XO.i)(this, rK), (0, XO.i)(this, PO, 25)), this.angularSpeed = ((0, XO.i)(this, mK), (0, XO.i)(this, sO, .01)), this._useAltToZoom = ((0, XO.i)(this, HO), !0), this._keys = new Array, this._keyboardModifiers = {
            ctrl: !1,
            alt: !1
          }, this._keyboardConditions = {
            modifiers: this._keyboardModifiers
          }, this._rotateDirection = new lO.m, this._panDirection = new lO.m
        }
        get useAltToZoom() {
          return this._useAltToZoom
        }
        set useAltToZoom(OO) {
          this._useAltToZoom = OO, this._applyUseAltToZoomToInputMap()
        }
        _applyUseAltToZoomToInputMap() {
          if (!this.camera?.movement) return;
          const OO = this.camera.movement.input,
            KO = OO.getEntry("keyboard", "zoom", {
              modifiers: {
                alt: !0
              }
            });
          !this._useAltToZoom && KO ? OO.inputMap.splice(OO.inputMap.indexOf(KO), 1) : this._useAltToZoom && !KO && OO.addEntry({
            source: "keyboard",
            modifiers: {
              alt: !0
            },
            interaction: "zoom"
          })
        }
        attachControl(OO) {
          OO = dO.k.BackCompatCameraNoPreventDefault(arguments), this._onCanvasBlurObserver || (this._scene = this.camera.JKO(), this._engine = this._scene.qb(), this._applyUseAltToZoomToInputMap(), this._onCanvasBlurObserver = this._engine.onCanvasBlurObservable.add((() => {
            this._keys.length = 0
          })), this._onKeyboardObserver = this._scene.onKeyboardObservable.add((KO => {
            const pO = KO.event;
            if (!pO.metaKey)
              if (KO.type === yK.d.KEYDOWN) {
                if (this._ctrlPressed = pO.ctrlKey, this._altPressed = pO.altKey, -1 !== this.keysUp.indexOf(pO.keyCode) || -1 !== this.keysDown.indexOf(pO.keyCode) || -1 !== this.keysLeft.indexOf(pO.keyCode) || -1 !== this.keysRight.indexOf(pO.keyCode) || -1 !== this.keysReset.indexOf(pO.keyCode) || -1 !== this.keysZoomIn.indexOf(pO.keyCode) || -1 !== this.keysZoomOut.indexOf(pO.keyCode)) {
                  -1 === this._keys.indexOf(pO.keyCode) && this._keys.push(pO.keyCode), pO.preventDefault && (OO || pO.preventDefault())
                }
              } else if (-1 !== this.keysUp.indexOf(pO.keyCode) || -1 !== this.keysDown.indexOf(pO.keyCode) || -1 !== this.keysLeft.indexOf(pO.keyCode) || -1 !== this.keysRight.indexOf(pO.keyCode) || -1 !== this.keysReset.indexOf(pO.keyCode) || -1 !== this.keysZoomIn.indexOf(pO.keyCode) || -1 !== this.keysZoomOut.indexOf(pO.keyCode)) {
              const KO = this._keys.indexOf(pO.keyCode);
              KO >= 0 && this._keys.splice(KO, 1), pO.preventDefault && (OO || pO.preventDefault())
            }
          })))
        }
        detachControl() {
          this._scene && (this._onKeyboardObserver && this._scene.onKeyboardObservable.remove(this._onKeyboardObserver), this._onCanvasBlurObserver && this._engine.onCanvasBlurObservable.remove(this._onCanvasBlurObserver), this._onKeyboardObserver = null, this._onCanvasBlurObserver = null), this._keys.length = 0
        }
        checkInputs() {
          if (this._onKeyboardObserver) {
            const OO = this.camera,
              KO = OO.movement.input;
            this._keyboardModifiers.ctrl = this._ctrlPressed, this._keyboardModifiers.alt = this._altPressed;
            const pO = this._rotateDirection.set(0, 0),
              XO = this._panDirection.set(0, 0);
            let bK = 0,
              eO = 0;
            for (let lO = 0; lO < this._keys.length; lO++) {
              const vK = this._keys[lO];
              if (this._keyboardConditions.key = vK, -1 === this.keysReset.indexOf(vK)) {
                const OO = KO.resolveInteraction("keyboard", this._keyboardConditions);
                if (OO)
                  if ("pan" === OO.interaction) eO = Math.max(eO, OO.sensitivity ?? 1 / this.panningSensibility), -1 !== this.keysLeft.indexOf(vK) ? XO.x -= 1 : -1 !== this.keysRight.indexOf(vK) ? XO.x += 1 : -1 !== this.keysUp.indexOf(vK) ? XO.y += 1 : -1 !== this.keysDown.indexOf(vK) && (XO.y -= 1);
                  else if ("zoom" === OO.interaction) {
                  const pO = OO.sensitivity ?? 1 / this.zoomingSensibility; - 1 !== this.keysUp.indexOf(vK) || -1 !== this.keysZoomIn.indexOf(vK) ? KO.handlers.zoom(pO) : -1 === this.keysDown.indexOf(vK) && -1 === this.keysZoomOut.indexOf(vK) || KO.handlers.zoom(-pO)
                } else "rotate" === OO.interaction && (bK = Math.max(bK, OO.sensitivity ?? this.angularSpeed), -1 !== this.keysLeft.indexOf(vK) ? pO.x -= 1 : -1 !== this.keysRight.indexOf(vK) ? pO.x += 1 : -1 !== this.keysUp.indexOf(vK) ? pO.y -= 1 : -1 !== this.keysDown.indexOf(vK) && (pO.y += 1))
              } - 1 !== this.keysReset.indexOf(vK) && OO.useInputToRestoreState && OO.restoreState()
            }
            0 === pO.x && 0 === pO.y || (pO.normalize().scaleInPlace(bK), KO.handlers.rotate(pO.x, pO.y)), 0 === XO.x && 0 === XO.y || (XO.normalize().scaleInPlace(eO), KO.handlers.pan(XO.x, XO.y))
          }
        }
        getClassName() {
          return "ArcRotateCameraKeyboardMoveInput"
        }
        getSimpleName() {
          return "keyboard"
        }
      }, (() => {
        const lO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], vK = [(0, bK.M)()], CO = [(0, bK.M)()], hO = [(0, bK.M)()], DO = [(0, bK.M)()], MO = [(0, bK.M)()], aK = [(0, bK.M)()], oO = [(0, bK.M)()], FO = [(0, bK.M)()], (0, XO.f)(OO, null, FO, {
          kind: "getter",
          name: "useAltToZoom",
          static: !1,
          private: !1,
          access: {
            has: OO => "useAltToZoom" in OO,
            get: OO => OO.useAltToZoom
          },
          metadata: lO
        }, null, VO), (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "keysUp",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysUp" in OO,
            get: OO => OO.keysUp,
            set: (OO, KO) => {
              OO.keysUp = KO
            }
          },
          metadata: lO
        }, LO, QO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "keysDown",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysDown" in OO,
            get: OO => OO.keysDown,
            set: (OO, KO) => {
              OO.keysDown = KO
            }
          },
          metadata: lO
        }, zK, AO), (0, XO.f)(null, null, eO, {
          kind: "field",
          name: "keysLeft",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysLeft" in OO,
            get: OO => OO.keysLeft,
            set: (OO, KO) => {
              OO.keysLeft = KO
            }
          },
          metadata: lO
        }, fO, TO), (0, XO.f)(null, null, vK, {
          kind: "field",
          name: "keysRight",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysRight" in OO,
            get: OO => OO.keysRight,
            set: (OO, KO) => {
              OO.keysRight = KO
            }
          },
          metadata: lO
        }, NO, IO), (0, XO.f)(null, null, CO, {
          kind: "field",
          name: "keysReset",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysReset" in OO,
            get: OO => OO.keysReset,
            set: (OO, KO) => {
              OO.keysReset = KO
            }
          },
          metadata: lO
        }, gK, uO), (0, XO.f)(null, null, hO, {
          kind: "field",
          name: "keysZoomIn",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysZoomIn" in OO,
            get: OO => OO.keysZoomIn,
            set: (OO, KO) => {
              OO.keysZoomIn = KO
            }
          },
          metadata: lO
        }, EO, jK), (0, XO.f)(null, null, DO, {
          kind: "field",
          name: "keysZoomOut",
          static: !1,
          private: !1,
          access: {
            has: OO => "keysZoomOut" in OO,
            get: OO => OO.keysZoomOut,
            set: (OO, KO) => {
              OO.keysZoomOut = KO
            }
          },
          metadata: lO
        }, YO, wO), (0, XO.f)(null, null, MO, {
          kind: "field",
          name: "panningSensibility",
          static: !1,
          private: !1,
          access: {
            has: OO => "panningSensibility" in OO,
            get: OO => OO.panningSensibility,
            set: (OO, KO) => {
              OO.panningSensibility = KO
            }
          },
          metadata: lO
        }, iK, rK), (0, XO.f)(null, null, aK, {
          kind: "field",
          name: "zoomingSensibility",
          static: !1,
          private: !1,
          access: {
            has: OO => "zoomingSensibility" in OO,
            get: OO => OO.zoomingSensibility,
            set: (OO, KO) => {
              OO.zoomingSensibility = KO
            }
          },
          metadata: lO
        }, PO, mK), (0, XO.f)(null, null, oO, {
          kind: "field",
          name: "angularSpeed",
          static: !1,
          private: !1,
          access: {
            has: OO => "angularSpeed" in OO,
            get: OO => OO.angularSpeed,
            set: (OO, KO) => {
              OO.angularSpeed = KO
            }
          },
          metadata: lO
        }, sO, HO), lO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: lO
        })
      })(), OO
    })();
    fO.b.ArcRotateCameraKeyboardMoveInput = gK;
    var uO = pO(36146),
      EO = pO(38266);
    let jK = (() => {
      var OO;
      let KO, pO, eO, CO = [],
        hO = [],
        MO = [],
        oO = [],
        FO = [],
        VO = [];
      return OO = class {
        constructor() {
          this.wheelPrecision = (0, XO.i)(this, CO, 3), this.zoomToMouseLocation = ((0, XO.i)(this, hO), (0, XO.i)(this, MO, !1)), this.wheelDeltaPercentage = ((0, XO.i)(this, oO), (0, XO.i)(this, FO, 0)), this.customComputeDeltaFromMouseWheel = ((0, XO.i)(this, VO), null), this._viewOffset = new lO.o(0, 0, 0), this._globalOffset = new lO.o(0, 0, 0), this._inertialPanning = lO.o.Zero(), this._zoomToMouseRadiusOffset = 0
        }
        _computeDeltaFromMouseWheelLegacyEvent(OO, KO) {
          let pO;
          const XO = .01 * OO * this.wheelDeltaPercentage * KO;
          return pO = OO > 0 ? XO / (1 + this.wheelDeltaPercentage) : XO * (1 + this.wheelDeltaPercentage), pO
        }
        attachControl(OO) {
          OO = dO.k.BackCompatCameraNoPreventDefault(arguments), this._wheel = KO => {
            if (KO.type !== DO.c.POINTERWHEEL) return;
            const pO = KO.event;
            let XO;
            const bK = pO.deltaMode === EO.e.DOM_DELTA_LINE ? 40 : 1,
              eO = -pO.deltaY * bK;
            if (this.customComputeDeltaFromMouseWheel) XO = this.customComputeDeltaFromMouseWheel(eO, this, pO);
            else if (this.wheelDeltaPercentage) {
              if (XO = this._computeDeltaFromMouseWheelLegacyEvent(eO, this.camera.radius), XO > 0) {
                const OO = this.zoomToMouseLocation ? this._zoomToMouseRadiusOffset : this.camera.inertialRadiusOffset;
                let KO = this.camera.radius,
                  pO = OO + XO;
                for (let XO = 0; XO < 20 && !(KO <= pO) && !(Math.abs(pO * this.camera.inertia) < .001); XO++) KO -= pO, pO *= this.camera.inertia;
                KO = (0, vK.Clamp)(KO, 0, Number.MAX_VALUE), XO = this._computeDeltaFromMouseWheelLegacyEvent(eO, KO)
              }
            } else {
              const OO = this.camera.movement.input.getEntry("wheel", "zoom");
              XO = eO * (OO?.sensitivity ?? 1 / (40 * this.wheelPrecision))
            }
            XO && (this.zoomToMouseLocation ? (this._hitPlane || this._updateHitPlane(), this._zoomToMouse(XO)) : this.camera.movement.zoomAccumulatedPixels += XO), pO.preventDefault && (OO || pO.preventDefault())
          }, this._observer = this.camera.JKO()._inputManager._addCameraPointerObserver(this._wheel, DO.c.POINTERWHEEL), this.zoomToMouseLocation && this._inertialPanning.plO(0)
        }
        detachControl() {
          this._observer && (this.camera.JKO()._inputManager._removeCameraPointerObserver(this._observer), this._observer = null, this._wheel = null)
        }
        checkInputs() {
          if (!this.zoomToMouseLocation) return;
          const OO = this.camera;
          if (Math.abs(this._zoomToMouseRadiusOffset) + this._inertialPanning.lengthSquared() + Math.abs(OO.inertialAlphaOffset) + Math.abs(OO.inertialBetaOffset) + Math.abs(OO.inertialRadiusOffset)) {
            this._updateHitPlane(), OO.target.addInPlace(this._inertialPanning), OO.radius -= this._zoomToMouseRadiusOffset;
            const KO = OO.movement.getFrameIndependentDecay(OO.inertia);
            this._inertialPanning.scaleInPlace(KO), this._zoomToMouseRadiusOffset *= KO, this._zeroIfClose(this._inertialPanning), Math.abs(this._zoomToMouseRadiusOffset) < aK.c && (this._zoomToMouseRadiusOffset = 0)
          }
        }
        getClassName() {
          return "ArcRotateCameraMouseWheelInput"
        }
        getSimpleName() {
          return "mousewheel"
        }
        _updateHitPlane() {
          const OO = this.camera,
            KO = OO.target.subtract(OO.position);
          this._hitPlane = uO.d.FromPositionAndNormal(OO.target, KO)
        }
        _getPosition() {
          const OO = this.camera,
            KO = OO.JKO(),
            pO = KO.createPickingRay(KO.pointerX, KO.pointerY, lO.c.Identity(), OO, !1);
          0 === OO.targetScreenOffset.x && 0 === OO.targetScreenOffset.y || (this._viewOffset.set(OO.targetScreenOffset.x, OO.targetScreenOffset.y, 0), OO.getViewMatrix().invertToRef(OO._cameraTransformMatrix), this._globalOffset = lO.o.TransformNormal(this._viewOffset, OO._cameraTransformMatrix), pO.origin.addInPlace(this._globalOffset));
          let XO = 0;
          return this._hitPlane && (XO = pO.intersectsPlane(this._hitPlane) ?? 0), pO.origin.addInPlace(pO.direction.scaleInPlace(XO))
        }
        _zoomToMouse(OO) {
          const KO = this.camera,
            pO = 1 - KO.inertia,
            XO = KO.movement.getFrameIndependentInputScale(KO.inertia);
          if (KO.lowerRadiusLimit) {
            const bK = KO.lowerRadiusLimit ?? 0;
            KO.radius - (this._zoomToMouseRadiusOffset + OO * XO) / pO < bK && (OO = ((KO.radius - bK) * pO - this._zoomToMouseRadiusOffset) / XO)
          }
          if (KO.upperRadiusLimit) {
            const bK = KO.upperRadiusLimit ?? 0;
            KO.radius - (this._zoomToMouseRadiusOffset + OO * XO) / pO > bK && (OO = ((KO.radius - bK) * pO - this._zoomToMouseRadiusOffset) / XO)
          }
          const bK = OO / pO / KO.radius,
            eO = this._getPosition(),
            vK = lO.j.WX[6];
          eO.subtractToRef(KO.target, vK), vK.scaleInPlace(bK), vK.scaleInPlace(pO), vK.scaleInPlace(XO), this._inertialPanning.addInPlace(vK), this._zoomToMouseRadiusOffset += OO * XO
        }
        _zeroIfClose(OO) {
          Math.abs(OO.x) < aK.c && (OO.x = 0), Math.abs(OO.y) < aK.c && (OO.y = 0), Math.abs(OO.z) < aK.c && (OO.z = 0)
        }
      }, (() => {
        const lO = "function" === typeof Symbol && Symbol.metadata ? Object.create(null) : void 0;
        KO = [(0, bK.M)()], pO = [(0, bK.M)()], eO = [(0, bK.M)()], (0, XO.f)(null, null, KO, {
          kind: "field",
          name: "wheelPrecision",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelPrecision" in OO,
            get: OO => OO.wheelPrecision,
            set: (OO, KO) => {
              OO.wheelPrecision = KO
            }
          },
          metadata: lO
        }, CO, hO), (0, XO.f)(null, null, pO, {
          kind: "field",
          name: "zoomToMouseLocation",
          static: !1,
          private: !1,
          access: {
            has: OO => "zoomToMouseLocation" in OO,
            get: OO => OO.zoomToMouseLocation,
            set: (OO, KO) => {
              OO.zoomToMouseLocation = KO
            }
          },
          metadata: lO
        }, MO, oO), (0, XO.f)(null, null, eO, {
          kind: "field",
          name: "wheelDeltaPercentage",
          static: !1,
          private: !1,
          access: {
            has: OO => "wheelDeltaPercentage" in OO,
            get: OO => OO.wheelDeltaPercentage,
            set: (OO, KO) => {
              OO.wheelDeltaPercentage = KO
            }
          },
          metadata: lO
        }, FO, VO), lO && Object.defineProperty(OO, Symbol.metadata, {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: lO
        })
      })(), OO
    })();
    fO.b.ArcRotateCameraMouseWheelInput = jK;
    var YO, wO, iK = pO(37938);
    class rK extends fO.c {
      constructor(OO) {
        super(OO)
      }
      addMouseWheel() {
        return this.add(new jK), this
      }
      addPointers() {
        return this.add(new IO), this
      }
      addKeyboard() {
        return this.add(new gK), this
      }
    }(YO = rK.prototype).addVRDeviceOrientation ?? (YO.addVRDeviceOrientation = (0, iK.h)("ArcRotateCameraInputsManager", "addVRDeviceOrientation")), (wO = rK.prototype).addGamepad ?? (wO.addGamepad = (0, iK.h)("ArcRotateCameraInputsManager", "addGamepad"));
    var PO = pO(35676),
      mK = pO(38319),
      sO = pO(38322);
    class HO extends mK.c {
      constructor(OO, KO, pO) {
        super(OO, KO, pO), this.input = new sO.e({
          pan: (OO, KO) => {
            this.panAccumulatedPixels.x += OO, this.panAccumulatedPixels.y += KO
          },
          rotate: (OO, KO) => {
            this.rotationAccumulatedPixels.x += OO, this.rotationAccumulatedPixels.y += KO
          },
          zoom: OO => {
            this.zoomAccumulatedPixels += OO
          }
        }, (() => this._createDefaultInputMap()))
      }
      _createDefaultInputMap() {
        return [{
          source: "pointer",
          button: 0,
          modifiers: {
            ctrl: !0
          },
          interaction: "pan"
        }, {
          source: "pointer",
          button: 0,
          interaction: "rotate"
        }, {
          source: "pointer",
          button: 2,
          interaction: "pan"
        }, {
          source: "wheel",
          interaction: "zoom"
        }, {
          source: "keyboard",
          key: [187, 107, 189, 109],
          interaction: "zoom"
        }, {
          source: "keyboard",
          modifiers: {
            ctrl: !0
          },
          interaction: "pan"
        }, {
          source: "keyboard",
          modifiers: {
            alt: !0
          },
          interaction: "zoom"
        }, {
          source: "keyboard",
          interaction: "rotate"
        }]
      }
    }

    function RO(OO, KO) {
      return isNaN(OO) ? KO : OO
    }
    let SO = (() => {
        var OO;
        let KO, pO, CO, DO, MO, FO, VO, fO, TO, NO, IO, yK, gK, uO, EO, jK, YO, wO, iK, PO, mK, sO, SO, JO, cK, BO, ZO, GO, qK = AO.f,
          xK = [],
          nO = [],
          WO = [],
          tK = [],
          kK = [],
          UO = [],
          OK = [],
          KK = [],
          pK = [],
          XK = [],
          bp = [],
          eK = [],
          lK = [],
          vp = [],
          CK = [],
          hK = [],
          DK = [],
          MK = [],
          ap = [],
          oK = [],
          FK = [],
          VK = [],
          LK = [],
          QK = [],
          zp = [],
          AK = [],
          fK = [],
          dK = [],
          TK = [],
          NK = [],
          IK = [],
          yp = [],
          gp = [],
          uK = [],
          EK = [],
          jp = [],
          YK = [],
          wK = [],
          ip = [],
          rp = [],
          PK = [],
          mp = [],
          sK = [],
          HK = [],
          RK = [],
          SK = [],
          JK = [];
        return OO = class extends qK {
          get target() {
            return this.GbO
          }
          set target(OO) {
            this.setTarget(OO)
          }
          get targetHost() {
            return this._targetHost
          }
          set targetHost(OO) {
            OO && this.setTarget(OO)
          }
          getTarget() {
            return this.target
          }
          get position() {
            return this._position
          }
          set position(OO) {
            this.setPosition(OO)
          }
          set upVector(OO) {
            this._upToYMatrix || (this._yToUpMatrix = new lO.c, this._upToYMatrix = new lO.c, this._upVector = lO.o.Zero()), OO.normalize(), this._upVector.NhO(OO), this.setMatUp()
          }
          get upVector() {
            return this._upVector
          }
          setMatUp() {
            lO.c.RotationAlignToRef(lO.o.UpReadOnly, this._upVector, this._yToUpMatrix), lO.c.RotationAlignToRef(this._upVector, lO.o.UpReadOnly, this._upToYMatrix)
          }
          get inertialAlphaOffset() {
            if (0 !== this._inertialAlphaOffset) return this._inertialAlphaOffset;
            if (0 !== this.movement.rotationAccumulatedPixels.x) return this.movement.rotationAccumulatedPixels.x;
            const OO = this.movement.rotationDeltaCurrentFrame.x;
            return Math.abs(OO) < this._rotationEpsilon ? 0 : OO
          }
          set inertialAlphaOffset(OO) {
            this._inertialAlphaOffset = OO, 0 === OO && this.movement.resetRotationVelocity()
          }
          get inertialBetaOffset() {
            if (0 !== this._inertialBetaOffset) return this._inertialBetaOffset;
            if (0 !== this.movement.rotationAccumulatedPixels.y) return this.movement.rotationAccumulatedPixels.y;
            const OO = this.movement.rotationDeltaCurrentFrame.y;
            return Math.abs(OO) < this._rotationEpsilon ? 0 : OO
          }
          set inertialBetaOffset(OO) {
            this._inertialBetaOffset = OO, 0 === OO && this.movement.resetRotationVelocity()
          }
          get inertialRadiusOffset() {
            if (0 !== this._inertialRadiusOffset) return this._inertialRadiusOffset;
            if (0 !== this.movement.zoomAccumulatedPixels) return this.movement.zoomAccumulatedPixels;
            const OO = this.movement.zoomDeltaCurrentFrame;
            return Math.abs(OO) < this._rotationEpsilon ? 0 : OO
          }
          set inertialRadiusOffset(OO) {
            this._inertialRadiusOffset = OO, 0 === OO && this.movement.resetZoomVelocity()
          }
          get panningInertia() {
            return this._panningInertia
          }
          set panningInertia(OO) {
            this._panningInertia = OO, this.movement && (this.movement.panInertia = OO)
          }
          get inertia() {
            return this._inertia
          }
          set inertia(OO) {
            this._inertia = OO, this.movement && (this.movement.rotationInertia = OO, this.movement.zoomInertia = OO)
          }
          get angularSensibilityX() {
            const OO = this.inputs.attached.pointers;
            return OO ? OO.angularSensibilityX : 0
          }
          set angularSensibilityX(OO) {
            const KO = this.inputs.attached.pointers;
            KO && (KO.angularSensibilityX = OO)
          }
          get angularSensibilityY() {
            const OO = this.inputs.attached.pointers;
            return OO ? OO.angularSensibilityY : 0
          }
          set angularSensibilityY(OO) {
            const KO = this.inputs.attached.pointers;
            KO && (KO.angularSensibilityY = OO)
          }
          get pinchPrecision() {
            const OO = this.inputs.attached.pointers;
            return OO ? OO.pinchPrecision : 0
          }
          set pinchPrecision(OO) {
            const KO = this.inputs.attached.pointers;
            KO && (KO.pinchPrecision = OO)
          }
          get pinchDeltaPercentage() {
            const OO = this.inputs.attached.pointers;
            return OO ? OO.pinchDeltaPercentage : 0
          }
          set pinchDeltaPercentage(OO) {
            const KO = this.inputs.attached.pointers;
            KO && (KO.pinchDeltaPercentage = OO)
          }
          get useNaturalPinchZoom() {
            const OO = this.inputs.attached.pointers;
            return !!OO && OO.useNaturalPinchZoom
          }
          set useNaturalPinchZoom(OO) {
            const KO = this.inputs.attached.pointers;
            KO && (KO.useNaturalPinchZoom = OO)
          }
          get panningSensibility() {
            const OO = this.inputs.attached.pointers;
            return OO ? OO.panningSensibility : 0
          }
          set panningSensibility(OO) {
            const KO = this.inputs.attached.pointers;
            KO && (KO.panningSensibility = OO)
          }
          get keysUp() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysUp : []
          }
          set keysUp(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysUp = OO)
          }
          get keysDown() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysDown : []
          }
          set keysDown(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysDown = OO)
          }
          get keysLeft() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysLeft : []
          }
          set keysLeft(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysLeft = OO)
          }
          get keysRight() {
            const OO = this.inputs.attached.keyboard;
            return OO ? OO.keysRight : []
          }
          set keysRight(OO) {
            const KO = this.inputs.attached.keyboard;
            KO && (KO.keysRight = OO)
          }
          get wheelPrecision() {
            const OO = this.inputs.attached.mousewheel;
            return OO ? OO.wheelPrecision : 0
          }
          set wheelPrecision(OO) {
            const KO = this.inputs.attached.mousewheel;
            KO && (KO.wheelPrecision = OO)
          }
          get zoomToMouseLocation() {
            const OO = this.inputs.attached.mousewheel;
            return !!OO && OO.zoomToMouseLocation
          }
          set zoomToMouseLocation(OO) {
            const KO = this.inputs.attached.mousewheel;
            KO && (KO.zoomToMouseLocation = OO)
          }
          get wheelDeltaPercentage() {
            const OO = this.inputs.attached.mousewheel;
            return OO ? OO.wheelDeltaPercentage : 0
          }
          set wheelDeltaPercentage(OO) {
            const KO = this.inputs.attached.mousewheel;
            KO && (KO.wheelDeltaPercentage = OO)
          }
          get _useCtrlForPanning() {
            return this._useCtrlForPanningInternal
          }
          set _useCtrlForPanning(OO) {
            this._useCtrlForPanningInternal = OO;
            const KO = this.movement.input,
              pO = KO.getEntry("keyboard", "pan", {
                modifiers: {
                  ctrl: !0
                }
              });
            !OO && pO ? KO.inputMap.splice(KO.inputMap.indexOf(pO), 1) : OO && !pO && KO.addEntry({
              source: "keyboard",
              modifiers: {
                ctrl: !0
              },
              interaction: "pan"
            });
            const XO = KO.getEntry("pointer", "pan", {
              modifiers: {
                ctrl: !0
              }
            });
            !OO && XO ? KO.inputMap.splice(KO.inputMap.indexOf(XO), 1) : OO && !XO && KO.addEntry({
              source: "pointer",
              button: 0,
              modifiers: {
                ctrl: !0
              },
              interaction: "pan"
            })
          }
          get _panningMouseButton() {
            return this._panningMouseButtonInternal
          }
          set _panningMouseButton(OO) {
            this._panningMouseButtonInternal = OO;
            const KO = this.movement.input.getEntry("pointer", "pan", {
              modifiers: {}
            });
            KO && (KO.button = OO)
          }
          get isInterpolating() {
            return this._isInterpolating
          }
          get bouncingBehavior() {
            return this._bouncingBehavior
          }
          get useBouncingBehavior() {
            return null != this._bouncingBehavior
          }
          set useBouncingBehavior(OO) {
            OO !== this.useBouncingBehavior && (OO ? (this._bouncingBehavior = new LO, this.addBehavior(this._bouncingBehavior)) : this._bouncingBehavior && (this.removeBehavior(this._bouncingBehavior), this._bouncingBehavior = null))
          }
          get framingBehavior() {
            return this._framingBehavior
          }
          get useFramingBehavior() {
            return null != this._framingBehavior
          }
          set useFramingBehavior(OO) {
            OO !== this.useFramingBehavior && (OO ? (this._framingBehavior = new QO, this.addBehavior(this._framingBehavior)) : this._framingBehavior && (this.removeBehavior(this._framingBehavior), this._framingBehavior = null))
          }
          get autoRotationBehavior() {
            return this._autoRotationBehavior
          }
          get useAutoRotationBehavior() {
            return null != this._autoRotationBehavior
          }
          set useAutoRotationBehavior(OO) {
            OO !== this.useAutoRotationBehavior && (OO ? (this._autoRotationBehavior = new oO, this.addBehavior(this._autoRotationBehavior)) : this._autoRotationBehavior && (this.removeBehavior(this._autoRotationBehavior), this._autoRotationBehavior = null))
          }
          constructor(OO, KO, pO, bK, vK, CO) {
            var hO;
            let DO = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6];
            super(OO, lO.o.Zero(), CO, DO), hO = this, this.alpha = ((0, XO.i)(this, xK), (0, XO.i)(this, nO, void 0)), this.beta = ((0, XO.i)(this, WO), (0, XO.i)(this, tK, void 0)), this.radius = ((0, XO.i)(this, kK), (0, XO.i)(this, UO, void 0)), this.overrideCloneAlphaBetaRadius = ((0, XO.i)(this, OK), (0, XO.i)(this, KK, void 0)), this.GbO = ((0, XO.i)(this, pK), (0, XO.i)(this, XK, void 0)), this._targetHost = ((0, XO.i)(this, bp), (0, XO.i)(this, eK, void 0)), this._upToYMatrix = (0, XO.i)(this, lK), this._inertialAlphaOffset = 0, this._inertialBetaOffset = 0, this._inertialRadiusOffset = 0, this.lowerAlphaLimit = (0, XO.i)(this, vp, null), this.upperAlphaLimit = ((0, XO.i)(this, CK), (0, XO.i)(this, hK, null)), this.lowerBetaLimit = ((0, XO.i)(this, DK), (0, XO.i)(this, MK, .01)), this.upperBetaLimit = ((0, XO.i)(this, ap), (0, XO.i)(this, oK, Math.PI - .01)), this.lowerRadiusLimit = ((0, XO.i)(this, FK), (0, XO.i)(this, VK, null)), this.upperRadiusLimit = ((0, XO.i)(this, LK), (0, XO.i)(this, QK, null)), this.lowerTargetYLimit = ((0, XO.i)(this, zp), (0, XO.i)(this, AK, -1 / 0)), this.inertialPanningX = ((0, XO.i)(this, fK), (0, XO.i)(this, dK, 0)), this.inertialPanningY = ((0, XO.i)(this, TK), (0, XO.i)(this, NK, 0)), this.pinchToPanMaxDistance = ((0, XO.i)(this, IK), (0, XO.i)(this, yp, 20)), this.panningDistanceLimit = ((0, XO.i)(this, gp), (0, XO.i)(this, uK, null)), this.panningOriginTarget = ((0, XO.i)(this, EK), (0, XO.i)(this, jp, lO.o.Zero())), this._panningInertia = ((0, XO.i)(this, YK), .9), this._inertia = .9, this.zoomOnFactor = (0, XO.i)(this, wK, 1), this.targetScreenOffset = ((0, XO.i)(this, ip), (0, XO.i)(this, rp, lO.m.Zero())), this.allowUpsideDown = ((0, XO.i)(this, PK), (0, XO.i)(this, mp, !0)), this.useInputToRestoreState = ((0, XO.i)(this, sK), (0, XO.i)(this, HK, !0)), this.restoreStateInterpolationFactor = ((0, XO.i)(this, RK), (0, XO.i)(this, SK, 0)), this._currentInterpolationFactor = ((0, XO.i)(this, JK), 0), this._viewMatrix = new lO.c, this._useCtrlForPanningInternal = !0, this._panningMouseButtonInternal = 2, this.panningAxis = new lO.o(1, 1, 0), this._transformedDirection = new lO.o, this.mapPanning = !1, this._isInterpolating = !1, this.onMeshTargetChangedObservable = new eO.e, this.checkCollisions = !1, this.collisionRadius = new lO.o(.5, .5, .5), this._previousPosition = lO.o.Zero(), this._collisionVelocity = lO.o.Zero(), this._newPosition = lO.o.Zero(), this._computationVector = lO.o.Zero(), this._goalAlpha = NaN, this._goalBeta = NaN, this._goalRadius = NaN, this._goalTarget = new lO.o(NaN, NaN, NaN), this._goalTargetScreenOffset = new lO.m(NaN, NaN), this._onCollisionPositionChange = function(OO, KO) {
              let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null;
              pO ? (hO.setPosition(KO), hO.QK && hO.QK(pO)) : hO._previousPosition.NhO(hO._position);
              const XO = Math.cos(hO.alpha),
                bK = Math.sin(hO.alpha),
                eO = Math.cos(hO.beta);
              let lO = Math.sin(hO.beta);
              0 === lO && (lO = 1e-4);
              const vK = hO._getTargetPosition();
              hO._computationVector.rvO(hO.radius * XO * lO, hO.radius * eO, hO.radius * bK * lO), vK.addToRef(hO._computationVector, hO._newPosition), hO._position.NhO(hO._newPosition);
              let CO = hO.upVector;
              hO.allowUpsideDown && hO.beta < 0 && (CO = CO.clone(), CO = CO.hl()), hO._computeViewMatrix(hO._position, vK, CO), hO._viewMatrix.addAtIndex(12, hO.targetScreenOffset.x), hO._viewMatrix.addAtIndex(13, hO.targetScreenOffset.y), hO._collisionTriggered = !1
            }, this.GbO = lO.o.Zero(), vK && this.setTarget(vK), this.alpha = KO, this.beta = pO, this.radius = bK, this.getViewMatrix(), this.inputs = new rK(this), this.inputs.addKeyboard().addMouseWheel().addPointers(), this.movement = new HO(this.JKO(), this._position), this.movement.rotationInertia = this._inertia, this.movement.zoomInertia = this._inertia, this.movement.panInertia = this._panningInertia
          }
          _initCache() {
            super._initCache(), this._cache.GbO = new lO.o(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), this._cache.alpha = void 0, this._cache.beta = void 0, this._cache.radius = void 0, this._cache.targetScreenOffset = lO.m.Zero()
          }
          _updateCache(OO) {
            OO || super._updateCache(), this._cache.GbO.NhO(this._getTargetPosition()), this._cache.alpha = this.alpha, this._cache.beta = this.beta, this._cache.radius = this.radius, this._cache.targetScreenOffset.NhO(this.targetScreenOffset)
          }
          _getTargetPosition() {
            if (this._targetHost && this._targetHost.getAbsolutePosition) {
              const OO = this._targetHost.getAbsolutePosition();
              this._targetBoundingCenter ? OO.addToRef(this._targetBoundingCenter, this.GbO) : this.GbO.NhO(OO)
            }
            const OO = this._getLockedTargetPosition();
            return OO || this.GbO
          }
          storeState() {
            return this._storedAlpha = this.alpha, this._storedBeta = this.beta, this._storedRadius = this.radius, this._storedTarget = this._getTargetPosition().clone(), this._storedTargetScreenOffset = this.targetScreenOffset.clone(), super.storeState()
          }
          _restoreStateValues() {
            return this.hasStateStored() && this.restoreStateInterpolationFactor > aK.c && this.restoreStateInterpolationFactor < 1 ? (this.interpolateTo(this._storedAlpha, this._storedBeta, this._storedRadius, this._storedTarget, this._storedTargetScreenOffset, this.restoreStateInterpolationFactor), !0) : !!super._restoreStateValues() && (this.setTarget(this._storedTarget.clone()), this.alpha = this._storedAlpha, this.beta = this._storedBeta, this.radius = this._storedRadius, this.targetScreenOffset = this._storedTargetScreenOffset.clone(), this.inertialAlphaOffset = 0, this.inertialBetaOffset = 0, this.inertialRadiusOffset = 0, this.inertialPanningX = 0, this.inertialPanningY = 0, !0)
          }
          stopInterpolation() {
            this._goalAlpha = NaN, this._goalBeta = NaN, this._goalRadius = NaN, this._goalTarget.set(NaN, NaN, NaN), this._goalTargetScreenOffset.set(NaN, NaN)
          }
          interpolateTo() {
            let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.alpha,
              KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.beta,
              pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.radius,
              XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : this.target,
              bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : this.targetScreenOffset,
              eO = arguments.length > 5 ? arguments[5] : void 0;
            this.inertialAlphaOffset = 0, this.inertialBetaOffset = 0, this.inertialRadiusOffset = 0, this.inertialPanningX = 0, this.inertialPanningY = 0, null != eO ? this._currentInterpolationFactor = eO : 0 !== this.restoreStateInterpolationFactor ? this._currentInterpolationFactor = this.restoreStateInterpolationFactor : this._currentInterpolationFactor = .1, this._goalAlpha = RO(OO, this._goalAlpha), this._goalBeta = RO(KO, this._goalBeta), this._goalRadius = RO(pO, this._goalRadius), this._goalTarget.set(RO(XO.x, this._goalTarget.x), RO(XO.y, this._goalTarget.y), RO(XO.z, this._goalTarget.z)), this._goalTargetScreenOffset.set(RO(bK.x, this._goalTargetScreenOffset.x), RO(bK.y, this._goalTargetScreenOffset.y)), this._goalAlpha = (0, vK.Clamp)(this._goalAlpha, this.lowerAlphaLimit ?? -1 / 0, this.upperAlphaLimit ?? 1 / 0), this._goalBeta = (0, vK.Clamp)(this._goalBeta, this.lowerBetaLimit ?? -1 / 0, this.upperBetaLimit ?? 1 / 0), this._goalRadius = (0, vK.Clamp)(this._goalRadius, this.lowerRadiusLimit ?? -1 / 0, this.upperRadiusLimit ?? 1 / 0), this._goalTarget.y = (0, vK.Clamp)(this._goalTarget.y, this.lowerTargetYLimit ?? -1 / 0, 1 / 0), this._isInterpolating = !0
          }
          _isSynchronizedViewMatrix() {
            return !!super._isSynchronizedViewMatrix() && (this._cache.GbO.equals(this._getTargetPosition()) && this._cache.alpha === this.alpha && this._cache.beta === this.beta && this._cache.radius === this.radius && this._cache.targetScreenOffset.equals(this.targetScreenOffset))
          }
          attachControl(OO, KO) {
            let pO = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
              XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 2;
            const bK = arguments;
            KO = dO.k.BackCompatCameraNoPreventDefault(bK), this._useCtrlForPanning = pO, this._panningMouseButton = XO, "boolean" === typeof bK[0] && (bK.length > 1 && (this._useCtrlForPanning = bK[1]), bK.length > 2 && (this._panningMouseButton = bK[2])), this.inputs.attachElement(KO), this._reset = () => {
              this.inertialAlphaOffset = 0, this.inertialBetaOffset = 0, this.inertialRadiusOffset = 0, this.inertialPanningX = 0, this.inertialPanningY = 0
            }
          }
          detachControl() {
            this.inputs.detachElement(), this._reset && this._reset()
          }
          _applyRotationAndZoomDelta(OO, KO, pO) {
            const XO = this.invertRotation ? -1 : 1;
            let bK = OO * this._calculateHandednessMultiplier();
            this.beta < 0 && (bK *= -1), this.alpha += bK * XO, this.beta += KO * XO, this.radius -= pO
          }
          _applyPanDelta(OO, KO) {
            const pO = lO.j.WX[0].rvO(OO, KO, KO);
            if (this._viewMatrix.invertToRef(this._cameraTransformMatrix), pO.multiplyInPlace(this.panningAxis), lO.o.TransformNormalToRef(pO, this._cameraTransformMatrix, this._transformedDirection), this.mapPanning) {
              const OO = this.upVector,
                KO = lO.o.CrossToRef(this._transformedDirection, OO, this._transformedDirection);
              lO.o.CrossToRef(OO, KO, this._transformedDirection)
            } else this.panningAxis.y || (this._transformedDirection.y = 0);
            if (!this._targetHost)
              if (null !== this.panningDistanceLimit) {
                this._transformedDirection.addInPlace(this.GbO);
                lO.o.DistanceSquared(this._transformedDirection, this.panningOriginTarget) <= this.panningDistanceLimit * this.panningDistanceLimit && this.GbO.NhO(this._transformedDirection)
              } else {
                if (this.parent) {
                  const OO = lO.j.Matrix[0];
                  this.parent.getWorldMatrix().getRotationMatrixToRef(OO), OO.transposeToRef(OO), lO.o.TransformCoordinatesToRef(this._transformedDirection, OO, this._transformedDirection)
                }
                this.GbO.addInPlace(this._transformedDirection)
              }
          }
          _checkInputs() {
            if (this._collisionTriggered) return;
            this.inputs.checkInputs();
            let OO = !1;
            this.movement.computeCurrentFrameDeltas();
            const KO = this.movement.rotationDeltaCurrentFrame,
              pO = this.movement.zoomDeltaCurrentFrame,
              XO = this.movement.panDeltaCurrentFrame;
            if (0 === KO.x && 0 === KO.y && 0 === pO && 0 === XO.x && 0 === XO.y || (OO = !0, 0 === KO.x && 0 === KO.y && 0 === pO || this._applyRotationAndZoomDelta(KO.x, KO.y, pO), 0 === XO.x && 0 === XO.y || this._applyPanDelta(XO.x, XO.y)), 0 === this._inertialAlphaOffset && 0 === this._inertialBetaOffset && 0 === this._inertialRadiusOffset || (this._applyRotationAndZoomDelta(this._inertialAlphaOffset, this._inertialBetaOffset, this._inertialRadiusOffset), this._inertialAlphaOffset *= this.inertia, this._inertialBetaOffset *= this.inertia, this._inertialRadiusOffset *= this.inertia, Math.abs(this._inertialAlphaOffset) < this._rotationEpsilon && (this._inertialAlphaOffset = 0), Math.abs(this._inertialBetaOffset) < this._rotationEpsilon && (this._inertialBetaOffset = 0), Math.abs(this._inertialRadiusOffset) < this._rotationEpsilon && (this._inertialRadiusOffset = 0), OO = !0), 0 !== this.inertialPanningX || 0 !== this.inertialPanningY) {
              this._applyPanDelta(this.inertialPanningX, this.inertialPanningY), this.inertialPanningX *= this.panningInertia, this.inertialPanningY *= this.panningInertia;
              const KO = this._panningEpsilon;
              Math.abs(this.inertialPanningX) < KO && (this.inertialPanningX = 0), Math.abs(this.inertialPanningY) < KO && (this.inertialPanningY = 0), OO = !0
            }
            if (OO) this.stopInterpolation();
            else if (this._isInterpolating) {
              let OO = !1;
              const KO = this._scene.qb().getDeltaTime() / 1e3,
                pO = 1 - Math.pow(2, -KO / this._currentInterpolationFactor),
                XO = RO(this._goalRadius, this.radius);
              if (!isNaN(this._goalTarget.x) || !isNaN(this._goalTarget.y) || !isNaN(this._goalTarget.z)) {
                const KO = lO.j.WX[0].set(RO(this._goalTarget.x, this.GbO.x), RO(this._goalTarget.y, this.GbO.y), RO(this._goalTarget.z, this.GbO.z));
                lO.o.LerpToRef(this.target, KO, pO, this.GbO), 10 * lO.o.Distance(this.target, KO) / XO < aK.c ? (this._goalTarget.set(NaN, NaN, NaN), this.target.NhO(KO), this.setTarget(this.target, !1, !0, !0)) : OO = !0
              }
              if (!isNaN(this._goalAlpha) || !isNaN(this._goalBeta)) {
                const KO = lO.g.RotationAlphaBetaGammaToRef(RO(this._goalAlpha, this.alpha), RO(this._goalBeta, this.beta), 0, lO.j.Quaternion[0]),
                  XO = lO.g.RotationAlphaBetaGammaToRef(this.alpha, this.beta, 0, lO.j.Quaternion[1]),
                  bK = lO.g.SlerpToRef(XO, KO, pO, lO.j.Quaternion[2]);
                bK.normalize();
                const eO = bK.toAlphaBetaGammaToRef(lO.j.WX[0]);
                if (this.alpha = eO.x, this.beta = eO.y, bK.isApprox(KO, aK.c / 5)) {
                  this._goalAlpha = NaN, this._goalBeta = NaN;
                  const OO = KO.toAlphaBetaGammaToRef(lO.j.WX[0]);
                  this.alpha = OO.x, this.beta = OO.y
                } else OO = !0
              }
              if (isNaN(this._goalRadius) || (this.radius += (XO - this.radius) * pO, Math.abs(XO / this.radius - 1) < aK.c ? (this._goalRadius = NaN, this.radius = XO) : OO = !0), !isNaN(this._goalTargetScreenOffset.x) || !isNaN(this._goalTargetScreenOffset.y)) {
                const KO = lO.j.Vector2[0].set(RO(this._goalTargetScreenOffset.x, this.targetScreenOffset.x), RO(this._goalTargetScreenOffset.y, this.targetScreenOffset.y));
                lO.m.LerpToRef(this.targetScreenOffset, KO, pO, this.targetScreenOffset), lO.m.Distance(this.targetScreenOffset, KO) < aK.c ? (this._goalTargetScreenOffset.set(NaN, NaN), this.targetScreenOffset.NhO(KO)) : OO = !0
              }
              this._isInterpolating = OO
            }
            this._checkLimits(), super._checkInputs()
          }
          _checkLimits() {
            null === this.lowerBetaLimit || void 0 === this.lowerBetaLimit ? this.allowUpsideDown && this.beta > Math.PI && (this.beta = this.beta - 2 * Math.PI) : this.beta < this.lowerBetaLimit && (this.beta = this.lowerBetaLimit), null === this.upperBetaLimit || void 0 === this.upperBetaLimit ? this.allowUpsideDown && this.beta < -Math.PI && (this.beta = this.beta + 2 * Math.PI) : this.beta > this.upperBetaLimit && (this.beta = this.upperBetaLimit), null !== this.lowerAlphaLimit && this.alpha < this.lowerAlphaLimit && (this.alpha = this.lowerAlphaLimit), null !== this.upperAlphaLimit && this.alpha > this.upperAlphaLimit && (this.alpha = this.upperAlphaLimit), null !== this.lowerRadiusLimit && this.radius < this.lowerRadiusLimit && (this.radius = this.lowerRadiusLimit, this.inertialRadiusOffset = 0), null !== this.upperRadiusLimit && this.radius > this.upperRadiusLimit && (this.radius = this.upperRadiusLimit, this.inertialRadiusOffset = 0), this.target.y = Math.max(this.target.y, this.lowerTargetYLimit)
          }
          rebuildAnglesAndRadius() {
            this._position.subtractToRef(this._getTargetPosition(), this._computationVector), 0 === this._upVector.x && 1 === this._upVector.y && 0 === this._upVector.z || lO.o.TransformCoordinatesToRef(this._computationVector, this._upToYMatrix, this._computationVector), this.radius = this._computationVector.length(), 0 === this.radius && (this.radius = 1e-4);
            const OO = this.alpha;
            var KO, pO;
            this.alpha = function(OO) {
              let KO = Math.PI / 2;
              return 0 === OO.x && 0 === OO.z || (KO = Math.acos(OO.x / Math.sqrt(Math.pow(OO.x, 2) + Math.pow(OO.z, 2)))), OO.z < 0 && (KO = 2 * Math.PI - KO), KO
            }(this._computationVector), this.beta = (KO = this._computationVector.y, pO = this.radius, Math.acos(KO / pO));
            const XO = Math.round((OO - this.alpha) / (2 * Math.PI));
            this.alpha += 2 * XO * Math.PI, this._checkLimits()
          }
          setPosition(OO) {
            this._position.equals(OO) || (this._position.NhO(OO), this.rebuildAnglesAndRadius())
          }
          setTarget(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              pO = arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
              XO = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            if (XO = this.overrideCloneAlphaBetaRadius ?? XO, OO.computeWorldMatrix) KO && OO.hpO ? this._targetBoundingCenter = OO.hpO().boundingBox.centerWorld.clone() : this._targetBoundingCenter = null, OO.computeWorldMatrix(), this._targetHost = OO, this.GbO = this._getTargetPosition(), this.onMeshTargetChangedObservable.notifyObservers(this._targetHost);
            else {
              const KO = OO,
                XO = this._getTargetPosition();
              if (XO && !pO && XO.equals(KO)) return;
              this._targetHost = null, this.GbO = KO, this._targetBoundingCenter = null, this.onMeshTargetChangedObservable.notifyObservers(null)
            }
            XO || this.rebuildAnglesAndRadius()
          }
          _getViewMatrix() {
            const OO = Math.cos(this.alpha),
              KO = Math.sin(this.alpha),
              pO = Math.cos(this.beta);
            let XO = Math.sin(this.beta);
            0 === XO && (XO = 1e-4), 0 === this.radius && (this.radius = 1e-4);
            const bK = this._getTargetPosition();
            if (this._computationVector.rvO(this.radius * OO * XO, this.radius * pO, this.radius * KO * XO), 0 === this._upVector.x && 1 === this._upVector.y && 0 === this._upVector.z || lO.o.TransformCoordinatesToRef(this._computationVector, this._yToUpMatrix, this._computationVector), bK.addToRef(this._computationVector, this._newPosition), this.JKO().collisionsEnabled && this.checkCollisions) {
              const OO = this.JKO().collisionCoordinator;
              this._collider || (this._collider = OO.createCollider()), this._collider._radius = this.collisionRadius, this._newPosition.subtractToRef(this._position, this._collisionVelocity), this._collisionTriggered = !0, OO.getNewPosition(this._position, this._collisionVelocity, this._collider, 3, null, this._onCollisionPositionChange, this.uniqueId)
            } else {
              this._position.NhO(this._newPosition);
              let OO = this.upVector;
              this.allowUpsideDown && XO < 0 && (OO = OO.hl()), this._computeViewMatrix(this._position, bK, OO), this._viewMatrix.addAtIndex(12, this.targetScreenOffset.x), this._viewMatrix.addAtIndex(13, this.targetScreenOffset.y)
            }
            return this._currentTarget.NhO(bK), this._viewMatrix
          }
          zoomOn(OO) {
            let KO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            OO = OO || this.JKO().meshes;
            const pO = hO.c.MinMax(OO);
            let XO = this._calculateLowerRadiusFromModelBoundingSphere(pO.min, pO.max);
            if (XO = Math.max(Math.min(XO, this.upperRadiusLimit || Number.MAX_VALUE), this.lowerRadiusLimit || 0), this.radius = XO * this.zoomOnFactor, this.mode === zK.c.ORTHOGRAPHIC_CAMERA) {
              const OO = this.JKO().qb().getAspectRatio(this),
                KO = XO * this.zoomOnFactor / 2;
              this.orthoLeft = -KO * OO, this.orthoRight = KO * OO, this.orthoBottom = -KO, this.orthoTop = KO
            }
            this.focusOn({
              min: pO.min,
              max: pO.max,
              distance: XO
            }, KO)
          }
          focusOn(OO) {
            let KO, pO, XO = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (void 0 === OO.min) {
              const XO = OO || this.JKO().meshes;
              KO = hO.c.MinMax(XO), pO = lO.o.Distance(KO.min, KO.max)
            } else {
              KO = OO, pO = OO.distance
            }
            this.GbO = hO.c.Center(KO), XO || (this.maxZ = 2 * pO)
          }
          createRigCamera(KO, pO) {
            let XO = 0;
            switch (this.cameraRigMode) {
              case zK.c.RIG_MODE_STEREOSCOPIC_ANAGLYPH:
              case zK.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_PARALLEL:
              case zK.c.RIG_MODE_STEREOSCOPIC_OVERUNDER:
              case zK.c.RIG_MODE_STEREOSCOPIC_INTERLACED:
              case zK.c.RIG_MODE_VR:
                XO = this._cameraRigParams.stereoHalfAngle * (0 === pO ? 1 : -1);
                break;
              case zK.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED:
                XO = this._cameraRigParams.stereoHalfAngle * (0 === pO ? -1 : 1)
            }
            const bK = new OO(KO, this.alpha + XO, this.beta, this.radius, this.GbO, this.JKO());
            return bK._cameraRigParams = {}, bK.isRigCamera = !0, bK.rigParent = this, bK.upVector = this.upVector, bK.mode = this.mode, bK.orthoLeft = this.orthoLeft, bK.orthoRight = this.orthoRight, bK.orthoBottom = this.orthoBottom, bK.orthoTop = this.orthoTop, bK
          }
          _updateRigCameras() {
            const OO = this._rigCameras[0],
              KO = this._rigCameras[1];
            switch (OO.beta = KO.beta = this.beta, this.cameraRigMode) {
              case zK.c.RIG_MODE_STEREOSCOPIC_ANAGLYPH:
              case zK.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_PARALLEL:
              case zK.c.RIG_MODE_STEREOSCOPIC_OVERUNDER:
              case zK.c.RIG_MODE_STEREOSCOPIC_INTERLACED:
              case zK.c.RIG_MODE_VR:
                OO.alpha = this.alpha - this._cameraRigParams.stereoHalfAngle, KO.alpha = this.alpha + this._cameraRigParams.stereoHalfAngle;
                break;
              case zK.c.RIG_MODE_STEREOSCOPIC_SIDEBYSIDE_CROSSEYED:
                OO.alpha = this.alpha + this._cameraRigParams.stereoHalfAngle, KO.alpha = this.alpha - this._cameraRigParams.stereoHalfAngle
            }
            super._updateRigCameras()
          }
          _calculateLowerRadiusFromModelBoundingSphere(OO, KO) {
            let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
            const XO = lO.o.Distance(OO, KO),
              bK = this.JKO().qb().getAspectRatio(this),
              eO = Math.tan(this.fov / 2),
              vK = eO * bK,
              CO = .5 * XO * pO,
              hO = CO * Math.sqrt(1 + 1 / (vK * vK)),
              DO = CO * Math.sqrt(1 + 1 / (eO * eO));
            return Math.max(hO, DO)
          }
          dispose() {
            this.inputs.clear(), super.dispose()
          }
          getClassName() {
            return "ArcRotateCamera"
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(qK[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.M)()], pO = [(0, bK.M)()], CO = [(0, bK.M)()], DO = [(0, bK.M)()], MO = [(0, bK.L)("target")], FO = [(0, bK.D)("targetHost")], VO = [(0, bK.M)()], fO = [(0, bK.M)()], TO = [(0, bK.M)()], NO = [(0, bK.M)()], IO = [(0, bK.M)()], yK = [(0, bK.M)()], gK = [(0, bK.M)()], uO = [(0, bK.M)()], EO = [(0, bK.M)()], jK = [(0, bK.M)()], YO = [(0, bK.M)()], wO = [(0, bK.M)()], iK = [(0, bK.M)()], PO = [(0, bK.M)()], mK = [(0, bK.L)()], sO = [(0, bK.M)()], SO = [(0, bK.M)()], JO = [(0, bK.M)()], cK = [(0, bK.J)()], BO = [(0, bK.M)()], ZO = [(0, bK.M)()], GO = [(0, bK.M)()], (0, XO.f)(OO, null, VO, {
            kind: "getter",
            name: "inertialAlphaOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "inertialAlphaOffset" in OO,
              get: OO => OO.inertialAlphaOffset
            },
            metadata: eO
          }, null, xK), (0, XO.f)(OO, null, fO, {
            kind: "getter",
            name: "inertialBetaOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "inertialBetaOffset" in OO,
              get: OO => OO.inertialBetaOffset
            },
            metadata: eO
          }, null, xK), (0, XO.f)(OO, null, TO, {
            kind: "getter",
            name: "inertialRadiusOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "inertialRadiusOffset" in OO,
              get: OO => OO.inertialRadiusOffset
            },
            metadata: eO
          }, null, xK), (0, XO.f)(OO, null, sO, {
            kind: "getter",
            name: "panningInertia",
            static: !1,
            private: !1,
            access: {
              has: OO => "panningInertia" in OO,
              get: OO => OO.panningInertia
            },
            metadata: eO
          }, null, xK), (0, XO.f)(OO, null, SO, {
            kind: "getter",
            name: "zoomToMouseLocation",
            static: !1,
            private: !1,
            access: {
              has: OO => "zoomToMouseLocation" in OO,
              get: OO => OO.zoomToMouseLocation
            },
            metadata: eO
          }, null, xK), (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "alpha",
            static: !1,
            private: !1,
            access: {
              has: OO => "alpha" in OO,
              get: OO => OO.alpha,
              set: (OO, KO) => {
                OO.alpha = KO
              }
            },
            metadata: eO
          }, nO, WO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "beta",
            static: !1,
            private: !1,
            access: {
              has: OO => "beta" in OO,
              get: OO => OO.beta,
              set: (OO, KO) => {
                OO.beta = KO
              }
            },
            metadata: eO
          }, tK, kK), (0, XO.f)(null, null, CO, {
            kind: "field",
            name: "radius",
            static: !1,
            private: !1,
            access: {
              has: OO => "radius" in OO,
              get: OO => OO.radius,
              set: (OO, KO) => {
                OO.radius = KO
              }
            },
            metadata: eO
          }, UO, OK), (0, XO.f)(null, null, DO, {
            kind: "field",
            name: "overrideCloneAlphaBetaRadius",
            static: !1,
            private: !1,
            access: {
              has: OO => "overrideCloneAlphaBetaRadius" in OO,
              get: OO => OO.overrideCloneAlphaBetaRadius,
              set: (OO, KO) => {
                OO.overrideCloneAlphaBetaRadius = KO
              }
            },
            metadata: eO
          }, KK, pK), (0, XO.f)(null, null, MO, {
            kind: "field",
            name: "GbO",
            static: !1,
            private: !1,
            access: {
              has: OO => "GbO" in OO,
              get: OO => OO.GbO,
              set: (OO, KO) => {
                OO.GbO = KO
              }
            },
            metadata: eO
          }, XK, bp), (0, XO.f)(null, null, FO, {
            kind: "field",
            name: "_targetHost",
            static: !1,
            private: !1,
            access: {
              has: OO => "_targetHost" in OO,
              get: OO => OO._targetHost,
              set: (OO, KO) => {
                OO._targetHost = KO
              }
            },
            metadata: eO
          }, eK, lK), (0, XO.f)(null, null, NO, {
            kind: "field",
            name: "lowerAlphaLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "lowerAlphaLimit" in OO,
              get: OO => OO.lowerAlphaLimit,
              set: (OO, KO) => {
                OO.lowerAlphaLimit = KO
              }
            },
            metadata: eO
          }, vp, CK), (0, XO.f)(null, null, IO, {
            kind: "field",
            name: "upperAlphaLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "upperAlphaLimit" in OO,
              get: OO => OO.upperAlphaLimit,
              set: (OO, KO) => {
                OO.upperAlphaLimit = KO
              }
            },
            metadata: eO
          }, hK, DK), (0, XO.f)(null, null, yK, {
            kind: "field",
            name: "lowerBetaLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "lowerBetaLimit" in OO,
              get: OO => OO.lowerBetaLimit,
              set: (OO, KO) => {
                OO.lowerBetaLimit = KO
              }
            },
            metadata: eO
          }, MK, ap), (0, XO.f)(null, null, gK, {
            kind: "field",
            name: "upperBetaLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "upperBetaLimit" in OO,
              get: OO => OO.upperBetaLimit,
              set: (OO, KO) => {
                OO.upperBetaLimit = KO
              }
            },
            metadata: eO
          }, oK, FK), (0, XO.f)(null, null, uO, {
            kind: "field",
            name: "lowerRadiusLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "lowerRadiusLimit" in OO,
              get: OO => OO.lowerRadiusLimit,
              set: (OO, KO) => {
                OO.lowerRadiusLimit = KO
              }
            },
            metadata: eO
          }, VK, LK), (0, XO.f)(null, null, EO, {
            kind: "field",
            name: "upperRadiusLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "upperRadiusLimit" in OO,
              get: OO => OO.upperRadiusLimit,
              set: (OO, KO) => {
                OO.upperRadiusLimit = KO
              }
            },
            metadata: eO
          }, QK, zp), (0, XO.f)(null, null, jK, {
            kind: "field",
            name: "lowerTargetYLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "lowerTargetYLimit" in OO,
              get: OO => OO.lowerTargetYLimit,
              set: (OO, KO) => {
                OO.lowerTargetYLimit = KO
              }
            },
            metadata: eO
          }, AK, fK), (0, XO.f)(null, null, YO, {
            kind: "field",
            name: "inertialPanningX",
            static: !1,
            private: !1,
            access: {
              has: OO => "inertialPanningX" in OO,
              get: OO => OO.inertialPanningX,
              set: (OO, KO) => {
                OO.inertialPanningX = KO
              }
            },
            metadata: eO
          }, dK, TK), (0, XO.f)(null, null, wO, {
            kind: "field",
            name: "inertialPanningY",
            static: !1,
            private: !1,
            access: {
              has: OO => "inertialPanningY" in OO,
              get: OO => OO.inertialPanningY,
              set: (OO, KO) => {
                OO.inertialPanningY = KO
              }
            },
            metadata: eO
          }, NK, IK), (0, XO.f)(null, null, iK, {
            kind: "field",
            name: "pinchToPanMaxDistance",
            static: !1,
            private: !1,
            access: {
              has: OO => "pinchToPanMaxDistance" in OO,
              get: OO => OO.pinchToPanMaxDistance,
              set: (OO, KO) => {
                OO.pinchToPanMaxDistance = KO
              }
            },
            metadata: eO
          }, yp, gp), (0, XO.f)(null, null, PO, {
            kind: "field",
            name: "panningDistanceLimit",
            static: !1,
            private: !1,
            access: {
              has: OO => "panningDistanceLimit" in OO,
              get: OO => OO.panningDistanceLimit,
              set: (OO, KO) => {
                OO.panningDistanceLimit = KO
              }
            },
            metadata: eO
          }, uK, EK), (0, XO.f)(null, null, mK, {
            kind: "field",
            name: "panningOriginTarget",
            static: !1,
            private: !1,
            access: {
              has: OO => "panningOriginTarget" in OO,
              get: OO => OO.panningOriginTarget,
              set: (OO, KO) => {
                OO.panningOriginTarget = KO
              }
            },
            metadata: eO
          }, jp, YK), (0, XO.f)(null, null, JO, {
            kind: "field",
            name: "zoomOnFactor",
            static: !1,
            private: !1,
            access: {
              has: OO => "zoomOnFactor" in OO,
              get: OO => OO.zoomOnFactor,
              set: (OO, KO) => {
                OO.zoomOnFactor = KO
              }
            },
            metadata: eO
          }, wK, ip), (0, XO.f)(null, null, cK, {
            kind: "field",
            name: "targetScreenOffset",
            static: !1,
            private: !1,
            access: {
              has: OO => "targetScreenOffset" in OO,
              get: OO => OO.targetScreenOffset,
              set: (OO, KO) => {
                OO.targetScreenOffset = KO
              }
            },
            metadata: eO
          }, rp, PK), (0, XO.f)(null, null, BO, {
            kind: "field",
            name: "allowUpsideDown",
            static: !1,
            private: !1,
            access: {
              has: OO => "allowUpsideDown" in OO,
              get: OO => OO.allowUpsideDown,
              set: (OO, KO) => {
                OO.allowUpsideDown = KO
              }
            },
            metadata: eO
          }, mp, sK), (0, XO.f)(null, null, ZO, {
            kind: "field",
            name: "useInputToRestoreState",
            static: !1,
            private: !1,
            access: {
              has: OO => "useInputToRestoreState" in OO,
              get: OO => OO.useInputToRestoreState,
              set: (OO, KO) => {
                OO.useInputToRestoreState = KO
              }
            },
            metadata: eO
          }, HK, RK), (0, XO.f)(null, null, GO, {
            kind: "field",
            name: "restoreStateInterpolationFactor",
            static: !1,
            private: !1,
            access: {
              has: OO => "restoreStateInterpolationFactor" in OO,
              get: OO => OO.restoreStateInterpolationFactor,
              set: (OO, KO) => {
                OO.restoreStateInterpolationFactor = KO
              }
            },
            metadata: eO
          }, SK, JK), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      JO = !1;
    JO || (JO = !0, CO.c.AddNodeConstructor("ArcRotateCamera", ((OO, KO) => () => new SO(OO, 0, 0, 1, lO.o.Zero(), KO))), (0, PO.h)("BABYLON.ArcRotateCamera", SO))
  },
  38338: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO.d
    });
    var XO = pO(38343);
    (0, XO.h)()
  },
  38343: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => DO,
      h: () => aK
    });
    var XO = pO(38063),
      bK = pO(38066),
      eO = pO(35632),
      lO = pO(35688),
      vK = pO(38347),
      CO = pO(38301),
      hO = pO(35676);
    let DO = (() => {
        var OO;
        let KO, pO, CO = vK.b,
          hO = [],
          DO = [],
          MO = [],
          aK = [];
        return OO = class extends CO {
          constructor(OO, KO, pO, bK) {
            super(OO, pO, bK), this.groundColor = (0, XO.i)(this, hO, new lO.e(0, 0, 0)), this.direction = ((0, XO.i)(this, DO), (0, XO.i)(this, MO, void 0)), (0, XO.i)(this, aK), this.direction = KO || eO.o.Up()
          }
          _buildUniformLayout() {
            this._uniformBuffer.addUniform("vLightData", 4), this._uniformBuffer.addUniform("vLightDiffuse", 4), this._uniformBuffer.addUniform("vLightSpecular", 4), this._uniformBuffer.addUniform("vLightGround", 3), this._uniformBuffer.addUniform("shadowsInfo", 3), this._uniformBuffer.addUniform("depthValues", 2), this._uniformBuffer.create()
          }
          getClassName() {
            return "HemisphericLight"
          }
          setDirectionToTarget(OO) {
            return this.direction = eO.o.Normalize(OO.subtract(eO.o.Zero())), this.direction
          }
          getShadowGenerator() {
            return null
          }
          transferToEffect(OO, KO) {
            const pO = eO.o.Normalize(this.direction);
            return this._uniformBuffer.updateFloat4("vLightData", pO.x, pO.y, pO.z, 0, KO), this._uniformBuffer.updateColor3("vLightGround", this.groundColor.scale(this.intensity), KO), this
          }
          transferToNodeMaterialEffect(OO, KO) {
            const pO = eO.o.Normalize(this.direction);
            return OO.setFloat3(KO, pO.x, pO.y, pO.z), this
          }
          computeWorldMatrix() {
            return this._worldMatrix || (this._worldMatrix = eO.c.Identity()), this._worldMatrix
          }
          getTypeID() {
            return vK.b.LIGHTTYPEID_HEMISPHERICLIGHT
          }
          prepareLightSpecificDefines(OO, KO) {
            OO["HEMILIGHT" + KO] = !0
          }
        }, (() => {
          const eO = "function" === typeof Symbol && Symbol.metadata ? Object.create(CO[Symbol.metadata] ?? null) : void 0;
          KO = [(0, bK.r)()], pO = [(0, bK.L)()], (0, XO.f)(null, null, KO, {
            kind: "field",
            name: "groundColor",
            static: !1,
            private: !1,
            access: {
              has: OO => "groundColor" in OO,
              get: OO => OO.groundColor,
              set: (OO, KO) => {
                OO.groundColor = KO
              }
            },
            metadata: eO
          }, hO, DO), (0, XO.f)(null, null, pO, {
            kind: "field",
            name: "direction",
            static: !1,
            private: !1,
            access: {
              has: OO => "direction" in OO,
              get: OO => OO.direction,
              set: (OO, KO) => {
                OO.direction = KO
              }
            },
            metadata: eO
          }, MO, aK), eO && Object.defineProperty(OO, Symbol.metadata, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: eO
          })
        })(), OO
      })(),
      MO = !1;

    function aK() {
      MO || (MO = !0, CO.c.AddNodeConstructor("Light_Type_3", ((OO, KO) => () => new DO(OO, eO.o.Zero(), KO))), (0, hO.h)("BABYLON.HemisphericLight", DO))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);