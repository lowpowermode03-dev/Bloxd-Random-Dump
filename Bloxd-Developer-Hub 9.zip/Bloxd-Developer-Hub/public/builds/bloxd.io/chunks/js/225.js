export const id = 225;
export const ids = [225];
export const modules = {
  39234: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => lO,
      h: () => DO,
      i: () => hO
    });
    var XO, bK = pO(35664),
      eO = pO(35632);
    ! function(OO) {
      OO[OO.CW = 0] = "CW", OO[OO.CCW = 1] = "CCW"
    }(XO || (XO = {}));
    class lO {
      static Interpolate(OO, KO, pO, XO, bK) {
        if (0 === OO) return 0;
        const eO = 1 - 3 * XO + 3 * KO,
          lO = 3 * XO - 6 * KO,
          vK = 3 * KO;
        let CO = OO;
        for (let hO = 0; hO < 5; hO++) {
          const KO = CO * CO;
          CO -= (eO * (KO * CO) + lO * KO + vK * CO - OO) * (1 / (3 * eO * KO + 2 * lO * CO + vK)), CO = Math.min(1, Math.max(0, CO))
        }
        return 3 * Math.pow(1 - CO, 2) * CO * pO + 3 * (1 - CO) * Math.pow(CO, 2) * bK + Math.pow(CO, 3)
      }
    }
    class vK {
      constructor(OO) {
        this._radians = OO, this._radians < 0 && (this._radians += 2 * Math.PI)
      }
      degrees() {
        return 180 * this._radians / Math.PI
      }
      radians() {
        return this._radians
      }
      static BetweenTwoPoints(OO, KO) {
        const pO = KO.subtract(OO),
          XO = Math.atan2(pO.y, pO.x);
        return new vK(XO)
      }
      static BetweenTwoVectors(OO, KO) {
        let pO = OO.lengthSquared() * KO.lengthSquared();
        if (0 === pO) return new vK(Math.PI / 2);
        pO = Math.sqrt(pO);
        let XO = OO.dot(KO) / pO;
        XO = (0, bK.Clamp)(XO, -1, 1);
        const eO = Math.acos(XO);
        return new vK(eO)
      }
      static FromRadians(OO) {
        return new vK(OO)
      }
      static FromDegrees(OO) {
        return new vK(OO * Math.PI / 180)
      }
    }
    class CO {
      constructor(OO, KO, pO) {
        this.startPoint = OO, this.midPoint = KO, this.endPoint = pO;
        const XO = Math.pow(KO.x, 2) + Math.pow(KO.y, 2),
          bK = (Math.pow(OO.x, 2) + Math.pow(OO.y, 2) - XO) / 2,
          lO = (XO - Math.pow(pO.x, 2) - Math.pow(pO.y, 2)) / 2,
          CO = (OO.x - KO.x) * (KO.y - pO.y) - (KO.x - pO.x) * (OO.y - KO.y);
        this.centerPoint = new eO.m((bK * (KO.y - pO.y) - lO * (OO.y - KO.y)) / CO, ((OO.x - KO.x) * lO - (KO.x - pO.x) * bK) / CO), this.radius = this.centerPoint.subtract(this.startPoint).length(), this.startAngle = vK.BetweenTwoPoints(this.centerPoint, this.startPoint);
        const hO = this.startAngle.degrees();
        let DO = vK.BetweenTwoPoints(this.centerPoint, this.midPoint).degrees(),
          MO = vK.BetweenTwoPoints(this.centerPoint, this.endPoint).degrees();
        DO - hO > 180 && (DO -= 360), DO - hO < -180 && (DO += 360), MO - DO > 180 && (MO -= 360), MO - DO < -180 && (MO += 360), this.orientation = DO - hO < 0 ? 0 : 1, this.angle = vK.FromDegrees(0 === this.orientation ? hO - MO : MO - hO)
      }
    }
    class hO {
      constructor(OO, KO) {
        this._points = new Array, this._length = 0, this.closed = !1, this._points.push(new eO.m(OO, KO))
      }
      addLineTo(OO, KO) {
        if (this.closed) return this;
        const pO = new eO.m(OO, KO),
          XO = this._points[this._points.length - 1];
        return this._points.push(pO), this._length += pO.subtract(XO).length(), this
      }
      addArcTo(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 36;
        if (this.closed) return this;
        const lO = this._points[this._points.length - 1],
          vK = new eO.m(OO, KO),
          hO = new eO.m(pO, XO),
          DO = new CO(lO, vK, hO);
        let MO = DO.angle.radians() / bK;
        0 === DO.orientation && (MO *= -1);
        let aK = DO.startAngle.radians() + MO;
        for (let eO = 0; eO < bK; eO++) {
          const OO = Math.cos(aK) * DO.radius + DO.centerPoint.x,
            KO = Math.sin(aK) * DO.radius + DO.centerPoint.y;
          this.addLineTo(OO, KO), aK += MO
        }
        return this
      }
      addQuadraticCurveTo(OO, KO, pO, XO) {
        let bK = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 36;
        if (this.closed) return this;
        const eO = (OO, KO, pO, XO) => (1 - OO) * (1 - OO) * KO + 2 * OO * (1 - OO) * pO + OO * OO * XO,
          lO = this._points[this._points.length - 1];
        for (let vK = 0; vK <= bK; vK++) {
          const CO = vK / bK,
            hO = eO(CO, lO.x, OO, pO),
            DO = eO(CO, lO.y, KO, XO);
          this.addLineTo(hO, DO)
        }
        return this
      }
      addBezierCurveTo(OO, KO, pO, XO, bK, eO) {
        let lO = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 36;
        if (this.closed) return this;
        const vK = (OO, KO, pO, XO, bK) => (1 - OO) * (1 - OO) * (1 - OO) * KO + 3 * OO * (1 - OO) * (1 - OO) * pO + 3 * OO * OO * (1 - OO) * XO + OO * OO * OO * bK,
          CO = this._points[this._points.length - 1];
        for (let hO = 0; hO <= lO; hO++) {
          const DO = hO / lO,
            MO = vK(DO, CO.x, OO, pO, bK),
            aK = vK(DO, CO.y, KO, XO, eO);
          this.addLineTo(MO, aK)
        }
        return this
      }
      isPointInside(OO) {
        let KO = !1;
        const pO = this._points.length;
        for (let XO = pO - 1, bK = 0; bK < pO; XO = bK++) {
          let pO = this._points[XO],
            eO = this._points[bK],
            lO = eO.x - pO.x,
            vK = eO.y - pO.y;
          if (Math.abs(vK) > Number.EPSILON) {
            if (vK < 0 && (pO = this._points[bK], lO = -lO, eO = this._points[XO], vK = -vK), OO.y < pO.y || OO.y > eO.y) continue;
            if (OO.y === pO.y && OO.x === pO.x) return !0;
            {
              const XO = vK * (OO.x - pO.x) - lO * (OO.y - pO.y);
              if (0 === XO) return !0;
              if (XO < 0) continue;
              KO = !KO
            }
          } else {
            if (OO.y !== pO.y) continue;
            if (eO.x <= OO.x && OO.x <= pO.x || pO.x <= OO.x && OO.x <= eO.x) return !0
          }
        }
        return KO
      }
      close() {
        return this.closed = !0, this
      }
      length() {
        let OO = this._length;
        if (this.closed) {
          const KO = this._points[this._points.length - 1];
          OO += this._points[0].subtract(KO).length()
        }
        return OO
      }
      area() {
        const OO = this._points.length;
        let KO = 0;
        for (let pO = OO - 1, XO = 0; XO < OO; pO = XO++) KO += this._points[pO].x * this._points[XO].y - this._points[XO].x * this._points[pO].y;
        return .5 * KO
      }
      getPoints() {
        return this._points
      }
      getPointAtLengthPosition(OO) {
        if (OO < 0 || OO > 1) return eO.m.Zero();
        const KO = OO * this.length();
        let pO = 0;
        for (let XO = 0; XO < this._points.length; XO++) {
          const OO = (XO + 1) % this._points.length,
            bK = this._points[XO],
            lO = this._points[OO].subtract(bK),
            vK = lO.length() + pO;
          if (KO >= pO && KO <= vK) {
            const OO = lO.normalize(),
              XO = KO - pO;
            return new eO.m(bK.x + OO.x * XO, bK.y + OO.y * XO)
          }
          pO = vK
        }
        return eO.m.Zero()
      }
      static StartingAt(OO, KO) {
        return new hO(OO, KO)
      }
    }
    class DO {
      static CreateQuadraticBezier(OO, KO, pO, XO) {
        XO = XO > 2 ? XO : 3;
        const bK = [],
          lO = (OO, KO, pO, XO) => (1 - OO) * (1 - OO) * KO + 2 * OO * (1 - OO) * pO + OO * OO * XO;
        for (let vK = 0; vK <= XO; vK++) bK.push(new eO.o(lO(vK / XO, OO.x, KO.x, pO.x), lO(vK / XO, OO.y, KO.y, pO.y), lO(vK / XO, OO.z, KO.z, pO.z)));
        return new DO(bK)
      }
      static CreateCubicBezier(OO, KO, pO, XO, bK) {
        bK = bK > 3 ? bK : 4;
        const lO = [],
          vK = (OO, KO, pO, XO, bK) => (1 - OO) * (1 - OO) * (1 - OO) * KO + 3 * OO * (1 - OO) * (1 - OO) * pO + 3 * OO * OO * (1 - OO) * XO + OO * OO * OO * bK;
        for (let CO = 0; CO <= bK; CO++) lO.push(new eO.o(vK(CO / bK, OO.x, KO.x, pO.x, XO.x), vK(CO / bK, OO.y, KO.y, pO.y, XO.y), vK(CO / bK, OO.z, KO.z, pO.z, XO.z)));
        return new DO(lO)
      }
      static CreateHermiteSpline(OO, KO, pO, XO, bK) {
        const lO = [],
          vK = 1 / bK;
        for (let CO = 0; CO <= bK; CO++) lO.push(eO.o.Hermite(OO, KO, pO, XO, CO * vK));
        return new DO(lO)
      }
      static CreateCatmullRomSpline(OO, KO, pO) {
        const XO = [],
          bK = 1 / KO;
        let lO = 0;
        if (pO) {
          const pO = OO.length;
          for (let vK = 0; vK < pO; vK++) {
            lO = 0;
            for (let CO = 0; CO < KO; CO++) XO.push(eO.o.CatmullRom(OO[vK % pO], OO[(vK + 1) % pO], OO[(vK + 2) % pO], OO[(vK + 3) % pO], lO)), lO += bK
          }
          XO.push(XO[0])
        } else {
          const pO = [];
          pO.push(OO[0].clone()), pO.push(...OO), pO.push(OO[OO.length - 1].clone());
          let vK = 0;
          for (; vK < pO.length - 3; vK++) {
            lO = 0;
            for (let OO = 0; OO < KO; OO++) XO.push(eO.o.CatmullRom(pO[vK], pO[vK + 1], pO[vK + 2], pO[vK + 3], lO)), lO += bK
          }
          vK--, XO.push(eO.o.CatmullRom(pO[vK], pO[vK + 1], pO[vK + 2], pO[vK + 3], lO))
        }
        return new DO(XO)
      }
      static ArcThru3Points(OO, KO, pO) {
        let XO = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 32,
          bK = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
          lO = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
        const vK = [],
          CO = KO.subtract(OO),
          hO = pO.subtract(KO),
          MO = OO.subtract(pO),
          aK = eO.o.Cross(CO, hO),
          oO = aK.length();
        if (oO < Math.pow(10, -8)) return new DO(vK);
        const FO = CO.lengthSquared(),
          VO = hO.lengthSquared(),
          LO = MO.lengthSquared(),
          QO = aK.lengthSquared(),
          zK = .5 * CO.length() * hO.length() * MO.length() / oO,
          AO = -.5 * VO * eO.o.Dot(CO, MO) / QO,
          fO = -.5 * LO * eO.o.Dot(CO, hO) / QO,
          dO = -.5 * FO * eO.o.Dot(hO, MO) / QO,
          TO = OO.scale(AO).add(KO.scale(fO)).add(pO.scale(dO)),
          NO = OO.subtract(TO).normalize(),
          IO = eO.o.Cross(aK, NO).normalize();
        if (lO) {
          const KO = 2 * Math.PI / XO;
          for (let OO = 0; OO <= 2 * Math.PI; OO += KO) vK.push(TO.add(NO.scale(zK * Math.cos(OO)).add(IO.scale(zK * Math.sin(OO)))));
          vK.push(OO)
        } else {
          const KO = 1 / XO;
          let eO, lO = 0;
          do {
            eO = TO.add(NO.scale(zK * Math.cos(lO)).add(IO.scale(zK * Math.sin(lO)))), vK.push(eO), lO += KO
          } while (!eO.equalsWithEpsilon(pO, zK * KO * 1.1));
          vK.push(pO), bK && vK.push(OO)
        }
        return new DO(vK)
      }
      constructor(OO) {
        this._length = 0, this._points = OO, this._length = this._computeLength(OO)
      }
      getPoints() {
        return this._points
      }
      length() {
        return this._length
      }
      continue (OO) {
        const KO = this._points[this._points.length - 1],
          pO = this._points.slice(),
          XO = OO.getPoints();
        for (let bK = 1; bK < XO.length; bK++) pO.push(XO[bK].subtract(XO[0]).add(KO));
        return new DO(pO)
      }
      _computeLength(OO) {
        let KO = 0;
        for (let pO = 1; pO < OO.length; pO++) KO += OO[pO].subtract(OO[pO - 1]).length();
        return KO
      }
    }
  },
  37055: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => eO
    });
    var XO = pO(37061);
    const bK = (OO, KO, pO) => OO ? OO.getClassName && "Mesh" === OO.getClassName() ? null : !OO.getClassName || "SubMesh" !== OO.getClassName() && "PhysicsBody" !== OO.getClassName() ? OO.clone ? OO.clone() : Array.isArray(OO) ? OO.slice() : pO && "object" === typeof OO ? {
      ...OO
    } : null : OO.clone(KO) : null;
    class eO {
      static DeepCopy(OO, KO, pO, eO) {
        let lO = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
        const vK = function(OO) {
          const KO = [];
          do {
            const pO = Object.getOwnPropertyNames(OO);
            for (const OO of pO) - 1 === KO.indexOf(OO) && KO.push(OO)
          } while (OO = Object.getPrototypeOf(OO));
          return KO
        }(OO);
        for (const hO of vK) {
          if ("_" === hO[0] && (!eO || -1 === eO.indexOf(hO))) continue;
          if (hO.endsWith("Observable")) continue;
          if (pO && -1 !== pO.indexOf(hO)) continue;
          const vK = OO[hO],
            DO = typeof vK;
          if ("function" !== DO) try {
            if ("object" === DO)
              if (vK instanceof Uint8Array) KO[hO] = Uint8Array.from(vK);
              else if (vK instanceof Array) {
              if (KO[hO] = [], vK.length > 0)
                if ("object" == typeof vK[0])
                  for (let OO = 0; OO < vK.length; OO++) {
                    const pO = bK(vK[OO], KO, lO); - 1 === KO[hO].indexOf(pO) && KO[hO].push(pO)
                  } else KO[hO] = vK.slice(0)
            } else KO[hO] = bK(vK, KO, lO);
            else KO[hO] = vK
          } catch (CO) {
            XO.b.Warn(CO.message)
          }
        }
      }
    }
  },
  37061: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => XO
    });
    class XO {
      static _CheckLimit(OO, KO) {
        let pO = XO._LogLimitOutputs[OO];
        return pO ? pO.current++ : (pO = {
          limit: KO,
          current: 1
        }, XO._LogLimitOutputs[OO] = pO), pO.current <= pO.limit
      }
      static _GenerateLimitMessage(OO) {
        let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
        const pO = XO._LogLimitOutputs[OO];
        if (!pO || !XO.MessageLimitReached) return;
        const bK = this._Levels[KO];
        pO.current === pO.limit && XO[bK.name](XO.MessageLimitReached.replace(/%LIMIT%/g, "" + pO.limit).replace(/%TYPE%/g, bK.name ?? ""))
      }
      static _AddLogEntry(OO) {
        XO._LogCache = OO + XO._LogCache, XO.OnNewCacheEntry && XO.OnNewCacheEntry(OO)
      }
      static _FormatMessage(OO) {
        const KO = OO => OO < 10 ? "0" + OO : "" + OO,
          pO = new Date;
        return "[" + KO(pO.getHours()) + ":" + KO(pO.getMinutes()) + ":" + KO(pO.getSeconds()) + "]: " + OO
      }
      static _LogDisabled(OO, KO) {}
      static _LogEnabled() {
        let OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
          KO = arguments.length > 1 ? arguments[1] : void 0,
          pO = arguments.length > 2 ? arguments[2] : void 0;
        const bK = Array.isArray(KO) ? KO[0] : KO;
        if (void 0 !== pO && !XO._CheckLimit(bK, pO)) return;
        const eO = XO._FormatMessage(bK),
          lO = this._Levels[OO],
          vK = Array.isArray(KO) ? KO.slice(1) : [];
        lO.logFunc && lO.logFunc("BJS - " + eO, ...vK);
        const CO = `<div style='color:${lO.color}'>${eO}</div><br>`;
        XO._AddLogEntry(CO), XO._GenerateLimitMessage(bK, OO)
      }
      static get LogCache() {
        return XO._LogCache
      }
      static ClearLogCache() {
        XO._LogCache = "", XO._LogLimitOutputs = {}, XO.errorsCount = 0
      }
      static set LogLevels(OO) {
        XO.Log = XO._LogDisabled, XO.Warn = XO._LogDisabled, XO.Error = XO._LogDisabled;
        const KO = [XO.MessageLogLevel, XO.WarningLogLevel, XO.ErrorLogLevel];
        for (const pO of KO)
          if ((OO & pO) === pO) {
            const OO = this._Levels[pO];
            XO[OO.name] = XO._LogEnabled.bind(XO, pO)
          }
      }
    }
    XO.NoneLogLevel = 0, XO.MessageLogLevel = 1, XO.WarningLogLevel = 2, XO.ErrorLogLevel = 4, XO.AllLogLevel = 7, XO.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", XO._LogCache = "", XO._LogLimitOutputs = {}, XO._Levels = [{}, {
      color: "white",
      logFunc: console.log,
      name: "Log"
    }, {
      color: "orange",
      logFunc: console.warn,
      name: "Warn"
    }, {}, {
      color: "red",
      logFunc: console.error,
      name: "Error"
    }], XO.errorsCount = 0, XO.Log = XO._LogEnabled.bind(XO, XO.MessageLogLevel), XO.Warn = XO._LogEnabled.bind(XO, XO.WarningLogLevel), XO.Error = XO._LogEnabled.bind(XO, XO.ErrorLogLevel)
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);