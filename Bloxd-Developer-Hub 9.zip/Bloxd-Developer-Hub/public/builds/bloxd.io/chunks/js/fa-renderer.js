/*! For license information please see vjxd5n.fa-renderer.2dc27cc1.chunk.js.LICENSE.txt */
export const id = 29;
export const ids = [29];
export const modules = {
  5824: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      FontAwesomeIcon: () => IO
    });
    var XO = pO(5822),
      bK = pO(4087),
      eO = pO.n(bK),
      lO = pO(63);

    function vK(OO, KO) {
      (null == KO || KO > OO.length) && (KO = OO.length);
      for (var pO = 0, XO = Array(KO); pO < KO; pO++) XO[pO] = OO[pO];
      return XO
    }

    function CO(OO, KO, pO) {
      return (KO = function(OO) {
        var KO = function(OO, KO) {
          if ("object" != typeof OO || !OO) return OO;
          var pO = OO[Symbol.toPrimitive];
          if (void 0 !== pO) {
            var XO = pO.call(OO, KO || "default");
            if ("object" != typeof XO) return XO;
            throw new TypeError("@@toPrimitive must return a primitive value.")
          }
          return ("string" === KO ? String : Number)(OO)
        }(OO, "string");
        return "symbol" == typeof KO ? KO : KO + ""
      }(KO)) in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }

    function hO(OO, KO) {
      var pO = Object.keys(OO);
      if (Object.getOwnPropertySymbols) {
        var XO = Object.getOwnPropertySymbols(OO);
        KO && (XO = XO.filter((function(KO) {
          return Object.getOwnPropertyDescriptor(OO, KO).enumerable
        }))), pO.push.apply(pO, XO)
      }
      return pO
    }

    function DO(OO) {
      for (var KO = 1; KO < arguments.length; KO++) {
        var pO = null != arguments[KO] ? arguments[KO] : {};
        KO % 2 ? hO(Object(pO), !0).forEach((function(KO) {
          CO(OO, KO, pO[KO])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(OO, Object.getOwnPropertyDescriptors(pO)) : hO(Object(pO)).forEach((function(KO) {
          Object.defineProperty(OO, KO, Object.getOwnPropertyDescriptor(pO, KO))
        }))
      }
      return OO
    }

    function MO(OO, KO) {
      return function(OO) {
        if (Array.isArray(OO)) return OO
      }(OO) || function(OO, KO) {
        var pO = null == OO ? null : "undefined" != typeof Symbol && OO[Symbol.iterator] || OO["@@iterator"];
        if (null != pO) {
          var XO, bK, eO, lO, vK = [],
            CO = !0,
            hO = !1;
          try {
            if (eO = (pO = pO.call(OO)).next, 0 === KO) {
              if (Object(pO) !== pO) return;
              CO = !1
            } else
              for (; !(CO = (XO = eO.call(pO)).done) && (vK.push(XO.value), vK.length !== KO); CO = !0);
          } catch (OO) {
            hO = !0, bK = OO
          } finally {
            try {
              if (!CO && null != pO.return && (lO = pO.return(), Object(lO) !== lO)) return
            } finally {
              if (hO) throw bK
            }
          }
          return vK
        }
      }(OO, KO) || FO(OO, KO) || function() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function aK(OO) {
      return function(OO) {
        if (Array.isArray(OO)) return vK(OO)
      }(OO) || function(OO) {
        if ("undefined" != typeof Symbol && null != OO[Symbol.iterator] || null != OO["@@iterator"]) return Array.from(OO)
      }(OO) || FO(OO) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function oO(OO) {
      return oO = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(OO) {
        return typeof OO
      } : function(OO) {
        return OO && "function" == typeof Symbol && OO.constructor === Symbol && OO !== Symbol.prototype ? "symbol" : typeof OO
      }, oO(OO)
    }

    function FO(OO, KO) {
      if (OO) {
        if ("string" == typeof OO) return vK(OO, KO);
        var pO = {}.toString.call(OO).slice(8, -1);
        return "Object" === pO && OO.constructor && (pO = OO.constructor.name), "Map" === pO || "Set" === pO ? Array.from(OO) : "Arguments" === pO || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(pO) ? vK(OO, KO) : void 0
      }
    }
    var VO;
    try {
      var LO = pO(5827);
      VO = LO.version
    } catch (gK) {
      VO = "undefined" !== typeof process && {
        NODE_ENV: "production",
        PUBLIC_URL: "",
        WDS_SOCKET_HOST: void 0,
        WDS_SOCKET_PATH: void 0,
        WDS_SOCKET_PORT: void 0,
        FAST_REFRESH: !0,
        REACT_APP_DEV_URLS: "false"
      }.FA_VERSION || "7.0.0"
    }

    function QO(OO) {
      var KO = OO.beat,
        pO = OO.fade,
        XO = OO.beatFade,
        bK = OO.bounce,
        eO = OO.shake,
        lO = OO.flash,
        vK = OO.spin,
        hO = OO.spinPulse,
        DO = OO.spinReverse,
        aK = OO.pulse,
        oO = OO.fixedWidth,
        FO = OO.inverse,
        LO = OO.border,
        QO = OO.listItem,
        zK = OO.flip,
        AO = OO.size,
        fO = OO.rotation,
        dO = OO.pull,
        TO = OO.swapOpacity,
        NO = OO.rotateBy,
        IO = OO.widthAuto,
        yK = function(OO, KO) {
          for (var pO = MO(OO.split("-"), 2), XO = pO[0], bK = pO[1], eO = MO(KO.split("-"), 2), lO = eO[0], vK = eO[1], CO = XO.split("."), hO = lO.split("."), DO = 0; DO < Math.max(CO.length, hO.length); DO++) {
            var aK = CO[DO] || "0",
              oO = hO[DO] || "0",
              FO = parseInt(aK, 10),
              VO = parseInt(oO, 10);
            if (FO !== VO) return FO > VO
          }
          for (var LO = 0; LO < Math.max(CO.length, hO.length); LO++) {
            var QO = CO[LO] || "0",
              zK = hO[LO] || "0";
            if (QO !== zK && QO.length !== zK.length) return QO.length < zK.length
          }
          return !(bK && !vK)
        }(VO, "7.0.0"),
        gK = CO(CO(CO(CO(CO(CO({
          "fa-beat": KO,
          "fa-fade": pO,
          "fa-beat-fade": XO,
          "fa-bounce": bK,
          "fa-shake": eO,
          "fa-flash": lO,
          "fa-spin": vK,
          "fa-spin-reverse": DO,
          "fa-spin-pulse": hO,
          "fa-pulse": aK,
          "fa-fw": oO,
          "fa-inverse": FO,
          "fa-border": LO,
          "fa-li": QO,
          "fa-flip": !0 === zK,
          "fa-flip-horizontal": "horizontal" === zK || "both" === zK,
          "fa-flip-vertical": "vertical" === zK || "both" === zK
        }, "fa-".concat(AO), "undefined" !== typeof AO && null !== AO), "fa-rotate-".concat(fO), "undefined" !== typeof fO && null !== fO && 0 !== fO), "fa-pull-".concat(dO), "undefined" !== typeof dO && null !== dO), "fa-swap-opacity", TO), "fa-rotate-by", yK && NO), "fa-width-auto", yK && IO);
      return Object.keys(gK).map((function(OO) {
        return gK[OO] ? OO : null
      })).filter((function(OO) {
        return OO
      }))
    }

    function zK(OO) {
      return KO = OO, (KO -= 0) === KO ? OO : (OO = OO.replace(/[\-_\s]+(.)?/g, (function(OO, KO) {
        return KO ? KO.toUpperCase() : ""
      }))).substr(0, 1).toLowerCase() + OO.substr(1);
      var KO
    }
    var AO = ["style"];
    var fO = !1;
    try {
      fO = !0
    } catch (gK) {}

    function dO(OO) {
      return OO && "object" === oO(OO) && OO.prefix && OO.iconName && OO.icon ? OO : XO.parse.icon ? XO.parse.icon(OO) : null === OO ? null : OO && "object" === oO(OO) && OO.prefix && OO.iconName ? OO : Array.isArray(OO) && 2 === OO.length ? {
        prefix: OO[0],
        iconName: OO[1]
      } : "string" === typeof OO ? {
        prefix: "fas",
        iconName: OO
      } : void 0
    }

    function TO(OO, KO) {
      return Array.isArray(KO) && KO.length > 0 || !Array.isArray(KO) && KO ? CO({}, OO, KO) : {}
    }
    var NO = {
        border: !1,
        className: "",
        mask: null,
        maskId: null,
        fixedWidth: !1,
        inverse: !1,
        flip: !1,
        icon: null,
        listItem: !1,
        pull: null,
        pulse: !1,
        rotation: null,
        rotateBy: !1,
        size: null,
        spin: !1,
        spinPulse: !1,
        spinReverse: !1,
        beat: !1,
        fade: !1,
        beatFade: !1,
        bounce: !1,
        shake: !1,
        symbol: !1,
        title: "",
        titleId: null,
        transform: null,
        swapOpacity: !1,
        widthAuto: !1
      },
      IO = lO.forwardRef((function(OO, KO) {
        var pO = DO(DO({}, NO), OO),
          bK = pO.icon,
          eO = pO.mask,
          lO = pO.symbol,
          vK = pO.className,
          CO = pO.title,
          hO = pO.titleId,
          MO = pO.maskId,
          oO = dO(bK),
          FO = TO("classes", [].concat(aK(QO(pO)), aK((vK || "").split(" ")))),
          VO = TO("transform", "string" === typeof pO.transform ? XO.parse.transform(pO.transform) : pO.transform),
          LO = TO("mask", dO(eO)),
          zK = (0, XO.icon)(oO, DO(DO(DO(DO({}, FO), VO), LO), {}, {
            symbol: lO,
            title: CO,
            titleId: hO,
            maskId: MO
          }));
        if (!zK) return function() {
          var OO;
          !fO && console && "function" === typeof console.error && (OO = console).error.apply(OO, arguments)
        }("Could not find icon", oO), null;
        var AO = zK.abstract,
          IO = {
            ref: KO
          };
        return Object.keys(pO).forEach((function(OO) {
          NO.hasOwnProperty(OO) || (IO[OO] = pO[OO])
        })), yK(AO[0], IO)
      }));
    IO.displayName = "FontAwesomeIcon", IO.propTypes = {
      beat: eO().bool,
      border: eO().bool,
      beatFade: eO().bool,
      bounce: eO().bool,
      className: eO().string,
      fade: eO().bool,
      flash: eO().bool,
      mask: eO().oneOfType([eO().object, eO().array, eO().string]),
      maskId: eO().string,
      fixedWidth: eO().bool,
      inverse: eO().bool,
      flip: eO().oneOf([!0, !1, "horizontal", "vertical", "both"]),
      icon: eO().oneOfType([eO().object, eO().array, eO().string]),
      listItem: eO().bool,
      pull: eO().oneOf(["right", "left"]),
      pulse: eO().bool,
      rotation: eO().oneOf([0, 90, 180, 270]),
      rotateBy: eO().bool,
      shake: eO().bool,
      size: eO().oneOf(["2xs", "xs", "sm", "lg", "xl", "2xl", "1x", "2x", "3x", "4x", "5x", "6x", "7x", "8x", "9x", "10x"]),
      spin: eO().bool,
      spinPulse: eO().bool,
      spinReverse: eO().bool,
      symbol: eO().oneOfType([eO().bool, eO().string]),
      title: eO().string,
      titleId: eO().string,
      transform: eO().oneOfType([eO().string, eO().object]),
      swapOpacity: eO().bool,
      widthAuto: eO().bool
    };
    var yK = function OO(KO, pO) {
      var XO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
      if ("string" === typeof pO) return pO;
      var bK = (pO.children || []).map((function(pO) {
          return OO(KO, pO)
        })),
        eO = Object.keys(pO.attributes || {}).reduce((function(OO, KO) {
          var XO = pO.attributes[KO];
          switch (KO) {
            case "class":
              OO.attrs.className = XO, delete pO.attributes.class;
              break;
            case "style":
              OO.attrs.style = XO.split(";").map((function(OO) {
                return OO.trim()
              })).filter((function(OO) {
                return OO
              })).reduce((function(OO, KO) {
                var pO, XO = KO.indexOf(":"),
                  bK = zK(KO.slice(0, XO)),
                  eO = KO.slice(XO + 1).trim();
                return bK.startsWith("webkit") ? OO[(pO = bK, pO.charAt(0).toUpperCase() + pO.slice(1))] = eO : OO[bK] = eO, OO
              }), {});
              break;
            default:
              0 === KO.indexOf("aria-") || 0 === KO.indexOf("data-") ? OO.attrs[KO.toLowerCase()] = XO : OO.attrs[zK(KO)] = XO
          }
          return OO
        }), {
          attrs: {}
        }),
        lO = XO.style,
        vK = void 0 === lO ? {} : lO,
        CO = function(OO, KO) {
          if (null == OO) return {};
          var pO, XO, bK = function(OO, KO) {
            if (null == OO) return {};
            var pO = {};
            for (var XO in OO)
              if ({}.hasOwnProperty.call(OO, XO)) {
                if (-1 !== KO.indexOf(XO)) continue;
                pO[XO] = OO[XO]
              } return pO
          }(OO, KO);
          if (Object.getOwnPropertySymbols) {
            var eO = Object.getOwnPropertySymbols(OO);
            for (XO = 0; XO < eO.length; XO++) pO = eO[XO], -1 === KO.indexOf(pO) && {}.propertyIsEnumerable.call(OO, pO) && (bK[pO] = OO[pO])
          }
          return bK
        }(XO, AO);
      return eO.attrs.style = DO(DO({}, eO.attrs.style), vK), KO.apply(void 0, [pO.tag, DO(DO({}, eO.attrs), CO)].concat(aK(bK)))
    }.bind(null, lO.createElement)
  },
  4095: (OO, KO, pO) => {
    var XO = pO(4100);

    function bK() {}

    function eO() {}
    eO.resetWarningCache = bK, OO.exports = function() {
      function OO(OO, KO, pO, bK, eO, lO) {
        if (lO !== XO) {
          var vK = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
          throw vK.name = "Invariant Violation", vK
        }
      }

      function KO() {
        return OO
      }
      OO.isRequired = OO;
      var pO = {
        array: OO,
        bigint: OO,
        bool: OO,
        func: OO,
        number: OO,
        object: OO,
        string: OO,
        symbol: OO,
        any: OO,
        arrayOf: KO,
        element: OO,
        elementType: OO,
        instanceOf: KO,
        node: OO,
        objectOf: KO,
        oneOf: KO,
        oneOfType: KO,
        shape: KO,
        exact: KO,
        checkPropTypes: eO,
        resetWarningCache: bK
      };
      return pO.PropTypes = pO, pO
    }
  },
  4087: (OO, KO, pO) => {
    OO.exports = pO(4095)()
  },
  4100: OO => {
    OO.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
  },
  5822: (OO, KO, pO) => {
    function XO(OO, KO) {
      (null == KO || KO > OO.length) && (KO = OO.length);
      for (var pO = 0, XO = Array(KO); pO < KO; pO++) XO[pO] = OO[pO];
      return XO
    }

    function bK(OO, KO) {
      for (var pO = 0; pO < KO.length; pO++) {
        var XO = KO[pO];
        XO.enumerable = XO.enumerable || !1, XO.configurable = !0, "value" in XO && (XO.writable = !0), Object.defineProperty(OO, MO(XO.key), XO)
      }
    }

    function eO(OO, KO) {
      var pO = "undefined" != typeof Symbol && OO[Symbol.iterator] || OO["@@iterator"];
      if (!pO) {
        if (Array.isArray(OO) || (pO = oO(OO)) || KO && OO && "number" == typeof OO.length) {
          pO && (OO = pO);
          var XO = 0,
            bK = function() {};
          return {
            s: bK,
            n: function() {
              return XO >= OO.length ? {
                done: !0
              } : {
                done: !1,
                value: OO[XO++]
              }
            },
            e: function(OO) {
              throw OO
            },
            f: bK
          }
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }
      var eO, lO = !0,
        vK = !1;
      return {
        s: function() {
          pO = pO.call(OO)
        },
        n: function() {
          var OO = pO.next();
          return lO = OO.done, OO
        },
        e: function(OO) {
          vK = !0, eO = OO
        },
        f: function() {
          try {
            lO || null == pO.return || pO.return()
          } finally {
            if (vK) throw eO
          }
        }
      }
    }

    function lO(OO, KO, pO) {
      return (KO = MO(KO)) in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }

    function vK(OO, KO) {
      var pO = Object.keys(OO);
      if (Object.getOwnPropertySymbols) {
        var XO = Object.getOwnPropertySymbols(OO);
        KO && (XO = XO.filter((function(KO) {
          return Object.getOwnPropertyDescriptor(OO, KO).enumerable
        }))), pO.push.apply(pO, XO)
      }
      return pO
    }

    function CO(OO) {
      for (var KO = 1; KO < arguments.length; KO++) {
        var pO = null != arguments[KO] ? arguments[KO] : {};
        KO % 2 ? vK(Object(pO), !0).forEach((function(KO) {
          lO(OO, KO, pO[KO])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(OO, Object.getOwnPropertyDescriptors(pO)) : vK(Object(pO)).forEach((function(KO) {
          Object.defineProperty(OO, KO, Object.getOwnPropertyDescriptor(pO, KO))
        }))
      }
      return OO
    }

    function hO(OO, KO) {
      return function(OO) {
        if (Array.isArray(OO)) return OO
      }(OO) || function(OO, KO) {
        var pO = null == OO ? null : "undefined" != typeof Symbol && OO[Symbol.iterator] || OO["@@iterator"];
        if (null != pO) {
          var XO, bK, eO, lO, vK = [],
            CO = !0,
            hO = !1;
          try {
            if (eO = (pO = pO.call(OO)).next, 0 === KO) {
              if (Object(pO) !== pO) return;
              CO = !1
            } else
              for (; !(CO = (XO = eO.call(pO)).done) && (vK.push(XO.value), vK.length !== KO); CO = !0);
          } catch (OO) {
            hO = !0, bK = OO
          } finally {
            try {
              if (!CO && null != pO.return && (lO = pO.return(), Object(lO) !== lO)) return
            } finally {
              if (hO) throw bK
            }
          }
          return vK
        }
      }(OO, KO) || oO(OO, KO) || function() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function DO(OO) {
      return function(OO) {
        if (Array.isArray(OO)) return XO(OO)
      }(OO) || function(OO) {
        if ("undefined" != typeof Symbol && null != OO[Symbol.iterator] || null != OO["@@iterator"]) return Array.from(OO)
      }(OO) || oO(OO) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function MO(OO) {
      var KO = function(OO, KO) {
        if ("object" != typeof OO || !OO) return OO;
        var pO = OO[Symbol.toPrimitive];
        if (void 0 !== pO) {
          var XO = pO.call(OO, KO || "default");
          if ("object" != typeof XO) return XO;
          throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return ("string" === KO ? String : Number)(OO)
      }(OO, "string");
      return "symbol" == typeof KO ? KO : KO + ""
    }

    function aK(OO) {
      return aK = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(OO) {
        return typeof OO
      } : function(OO) {
        return OO && "function" == typeof Symbol && OO.constructor === Symbol && OO !== Symbol.prototype ? "symbol" : typeof OO
      }, aK(OO)
    }

    function oO(OO, KO) {
      if (OO) {
        if ("string" == typeof OO) return XO(OO, KO);
        var pO = {}.toString.call(OO).slice(8, -1);
        return "Object" === pO && OO.constructor && (pO = OO.constructor.name), "Map" === pO || "Set" === pO ? Array.from(OO) : "Arguments" === pO || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(pO) ? XO(OO, KO) : void 0
      }
    }
    pO.r(KO), pO.d(KO, {
      api: () => Wp,
      config: () => pb,
      counter: () => Mb,
      dom: () => be,
      findIconDefinition: () => lb,
      icon: () => Cb,
      layer: () => hb,
      library: () => Xb,
      noAuto: () => Kb,
      parse: () => eb,
      text: () => Db,
      toHtml: () => ve
    });
    var FO = function() {},
      VO = {},
      LO = {},
      QO = null,
      zK = {
        mark: FO,
        measure: FO
      };
    try {
      "undefined" !== typeof window && (VO = window), "undefined" !== typeof document && (LO = document), "undefined" !== typeof MutationObserver && (QO = MutationObserver), "undefined" !== typeof performance && (zK = performance)
    } catch (BO) {}
    var AO, fO, dO = (VO.navigator || {}).userAgent,
      TO = void 0 === dO ? "" : dO,
      NO = VO,
      IO = LO,
      yK = QO,
      gK = zK,
      uO = (NO.document, !!IO.documentElement && !!IO.head && "function" === typeof IO.addEventListener && "function" === typeof IO.createElement),
      EO = ~TO.indexOf("MSIE") || ~TO.indexOf("Trident/"),
      jK = {
        classic: {
          fa: "solid",
          fas: "solid",
          "fa-solid": "solid",
          far: "regular",
          "fa-regular": "regular",
          fal: "light",
          "fa-light": "light",
          fat: "thin",
          "fa-thin": "thin",
          fab: "brands",
          "fa-brands": "brands"
        },
        duotone: {
          fa: "solid",
          fad: "solid",
          "fa-solid": "solid",
          "fa-duotone": "solid",
          fadr: "regular",
          "fa-regular": "regular",
          fadl: "light",
          "fa-light": "light",
          fadt: "thin",
          "fa-thin": "thin"
        },
        sharp: {
          fa: "solid",
          fass: "solid",
          "fa-solid": "solid",
          fasr: "regular",
          "fa-regular": "regular",
          fasl: "light",
          "fa-light": "light",
          fast: "thin",
          "fa-thin": "thin"
        },
        "sharp-duotone": {
          fa: "solid",
          fasds: "solid",
          "fa-solid": "solid",
          fasdr: "regular",
          "fa-regular": "regular",
          fasdl: "light",
          "fa-light": "light",
          fasdt: "thin",
          "fa-thin": "thin"
        },
        slab: {
          "fa-regular": "regular",
          faslr: "regular"
        },
        "slab-press": {
          "fa-regular": "regular",
          faslpr: "regular"
        },
        thumbprint: {
          "fa-light": "light",
          fatl: "light"
        },
        whiteboard: {
          "fa-semibold": "semibold",
          fawsb: "semibold"
        },
        notdog: {
          "fa-solid": "solid",
          fans: "solid"
        },
        "notdog-duo": {
          "fa-solid": "solid",
          fands: "solid"
        },
        etch: {
          "fa-solid": "solid",
          faes: "solid"
        },
        graphite: {
          "fa-thin": "thin",
          fagt: "thin"
        },
        jelly: {
          "fa-regular": "regular",
          fajr: "regular"
        },
        "jelly-fill": {
          "fa-regular": "regular",
          fajfr: "regular"
        },
        "jelly-duo": {
          "fa-regular": "regular",
          fajdr: "regular"
        },
        chisel: {
          "fa-regular": "regular",
          facr: "regular"
        },
        utility: {
          "fa-semibold": "semibold",
          fausb: "semibold"
        },
        "utility-duo": {
          "fa-semibold": "semibold",
          faudsb: "semibold"
        },
        "utility-fill": {
          "fa-semibold": "semibold",
          faufsb: "semibold"
        }
      },
      YO = ["fa-classic", "fa-duotone", "fa-sharp", "fa-sharp-duotone", "fa-thumbprint", "fa-whiteboard", "fa-notdog", "fa-notdog-duo", "fa-chisel", "fa-etch", "fa-graphite", "fa-jelly", "fa-jelly-fill", "fa-jelly-duo", "fa-slab", "fa-slab-press", "fa-utility", "fa-utility-duo", "fa-utility-fill"],
      wO = "classic",
      iK = "duotone",
      rK = "sharp",
      PO = "sharp-duotone",
      mK = "chisel",
      sO = "etch",
      HO = "graphite",
      RO = "jelly",
      SO = "jelly-duo",
      JO = "jelly-fill",
      cK = "notdog",
      BO = "notdog-duo",
      ZO = "slab",
      GO = "slab-press",
      qK = "thumbprint",
      xK = "utility",
      nO = "utility-duo",
      WO = "utility-fill",
      tK = "whiteboard",
      kK = [wO, iK, rK, PO, mK, sO, HO, RO, SO, JO, cK, BO, ZO, GO, qK, xK, nO, WO, tK],
      UO = (lO(lO(lO(lO(lO(lO(lO(lO(lO(lO(AO = {}, wO, "Classic"), iK, "Duotone"), rK, "Sharp"), PO, "Sharp Duotone"), mK, "Chisel"), sO, "Etch"), HO, "Graphite"), RO, "Jelly"), SO, "Jelly Duo"), JO, "Jelly Fill"), lO(lO(lO(lO(lO(lO(lO(lO(lO(AO, cK, "Notdog"), BO, "Notdog Duo"), ZO, "Slab"), GO, "Slab Press"), qK, "Thumbprint"), xK, "Utility"), nO, "Utility Duo"), WO, "Utility Fill"), tK, "Whiteboard"), new Map([
        ["classic", {
          defaultShortPrefixId: "fas",
          defaultStyleId: "solid",
          styleIds: ["solid", "regular", "light", "thin", "brands"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["duotone", {
          defaultShortPrefixId: "fad",
          defaultStyleId: "solid",
          styleIds: ["solid", "regular", "light", "thin"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["sharp", {
          defaultShortPrefixId: "fass",
          defaultStyleId: "solid",
          styleIds: ["solid", "regular", "light", "thin"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["sharp-duotone", {
          defaultShortPrefixId: "fasds",
          defaultStyleId: "solid",
          styleIds: ["solid", "regular", "light", "thin"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["chisel", {
          defaultShortPrefixId: "facr",
          defaultStyleId: "regular",
          styleIds: ["regular"],
          futureStyleIds: [],
          defaultFontWeight: 400
        }],
        ["etch", {
          defaultShortPrefixId: "faes",
          defaultStyleId: "solid",
          styleIds: ["solid"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["graphite", {
          defaultShortPrefixId: "fagt",
          defaultStyleId: "thin",
          styleIds: ["thin"],
          futureStyleIds: [],
          defaultFontWeight: 100
        }],
        ["jelly", {
          defaultShortPrefixId: "fajr",
          defaultStyleId: "regular",
          styleIds: ["regular"],
          futureStyleIds: [],
          defaultFontWeight: 400
        }],
        ["jelly-duo", {
          defaultShortPrefixId: "fajdr",
          defaultStyleId: "regular",
          styleIds: ["regular"],
          futureStyleIds: [],
          defaultFontWeight: 400
        }],
        ["jelly-fill", {
          defaultShortPrefixId: "fajfr",
          defaultStyleId: "regular",
          styleIds: ["regular"],
          futureStyleIds: [],
          defaultFontWeight: 400
        }],
        ["notdog", {
          defaultShortPrefixId: "fans",
          defaultStyleId: "solid",
          styleIds: ["solid"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["notdog-duo", {
          defaultShortPrefixId: "fands",
          defaultStyleId: "solid",
          styleIds: ["solid"],
          futureStyleIds: [],
          defaultFontWeight: 900
        }],
        ["slab", {
          defaultShortPrefixId: "faslr",
          defaultStyleId: "regular",
          styleIds: ["regular"],
          futureStyleIds: [],
          defaultFontWeight: 400
        }],
        ["slab-press", {
          defaultShortPrefixId: "faslpr",
          defaultStyleId: "regular",
          styleIds: ["regular"],
          futureStyleIds: [],
          defaultFontWeight: 400
        }],
        ["thumbprint", {
          defaultShortPrefixId: "fatl",
          defaultStyleId: "light",
          styleIds: ["light"],
          futureStyleIds: [],
          defaultFontWeight: 300
        }],
        ["utility", {
          defaultShortPrefixId: "fausb",
          defaultStyleId: "semibold",
          styleIds: ["semibold"],
          futureStyleIds: [],
          defaultFontWeight: 600
        }],
        ["utility-duo", {
          defaultShortPrefixId: "faudsb",
          defaultStyleId: "semibold",
          styleIds: ["semibold"],
          futureStyleIds: [],
          defaultFontWeight: 600
        }],
        ["utility-fill", {
          defaultShortPrefixId: "faufsb",
          defaultStyleId: "semibold",
          styleIds: ["semibold"],
          futureStyleIds: [],
          defaultFontWeight: 600
        }],
        ["whiteboard", {
          defaultShortPrefixId: "fawsb",
          defaultStyleId: "semibold",
          styleIds: ["semibold"],
          futureStyleIds: [],
          defaultFontWeight: 600
        }]
      ])),
      OK = ["fak", "fa-kit", "fakd", "fa-kit-duotone"],
      KK = {
        fak: "kit",
        "fa-kit": "kit"
      },
      pK = {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      },
      XK = (lO(lO({}, "kit", "Kit"), "kit-duotone", "Kit Duotone"), {
        kit: "fak"
      }),
      bp = {
        "kit-duotone": "fakd"
      },
      eK = "duotone-group",
      lK = "swap-opacity",
      vp = "primary",
      CK = "secondary",
      hK = (lO(lO(lO(lO(lO(lO(lO(lO(lO(lO(fO = {}, "classic", "Classic"), "duotone", "Duotone"), "sharp", "Sharp"), "sharp-duotone", "Sharp Duotone"), "chisel", "Chisel"), "etch", "Etch"), "graphite", "Graphite"), "jelly", "Jelly"), "jelly-duo", "Jelly Duo"), "jelly-fill", "Jelly Fill"), lO(lO(lO(lO(lO(lO(lO(lO(lO(fO, "notdog", "Notdog"), "notdog-duo", "Notdog Duo"), "slab", "Slab"), "slab-press", "Slab Press"), "thumbprint", "Thumbprint"), "utility", "Utility"), "utility-duo", "Utility Duo"), "utility-fill", "Utility Fill"), "whiteboard", "Whiteboard"), lO(lO({}, "kit", "Kit"), "kit-duotone", "Kit Duotone"), {
        classic: {
          fab: "fa-brands",
          fad: "fa-duotone",
          fal: "fa-light",
          far: "fa-regular",
          fas: "fa-solid",
          fat: "fa-thin"
        },
        duotone: {
          fadr: "fa-regular",
          fadl: "fa-light",
          fadt: "fa-thin"
        },
        sharp: {
          fass: "fa-solid",
          fasr: "fa-regular",
          fasl: "fa-light",
          fast: "fa-thin"
        },
        "sharp-duotone": {
          fasds: "fa-solid",
          fasdr: "fa-regular",
          fasdl: "fa-light",
          fasdt: "fa-thin"
        },
        slab: {
          faslr: "fa-regular"
        },
        "slab-press": {
          faslpr: "fa-regular"
        },
        whiteboard: {
          fawsb: "fa-semibold"
        },
        thumbprint: {
          fatl: "fa-light"
        },
        notdog: {
          fans: "fa-solid"
        },
        "notdog-duo": {
          fands: "fa-solid"
        },
        etch: {
          faes: "fa-solid"
        },
        graphite: {
          fagt: "fa-thin"
        },
        jelly: {
          fajr: "fa-regular"
        },
        "jelly-fill": {
          fajfr: "fa-regular"
        },
        "jelly-duo": {
          fajdr: "fa-regular"
        },
        chisel: {
          facr: "fa-regular"
        },
        utility: {
          fausb: "fa-semibold"
        },
        "utility-duo": {
          faudsb: "fa-semibold"
        },
        "utility-fill": {
          faufsb: "fa-semibold"
        }
      }),
      DK = ["fa", "fas", "far", "fal", "fat", "fad", "fadr", "fadl", "fadt", "fab", "fass", "fasr", "fasl", "fast", "fasds", "fasdr", "fasdl", "fasdt", "faslr", "faslpr", "fawsb", "fatl", "fans", "fands", "faes", "fagt", "fajr", "fajfr", "fajdr", "facr", "fausb", "faudsb", "faufsb"].concat(["fa-classic", "fa-duotone", "fa-sharp", "fa-sharp-duotone", "fa-thumbprint", "fa-whiteboard", "fa-notdog", "fa-notdog-duo", "fa-chisel", "fa-etch", "fa-graphite", "fa-jelly", "fa-jelly-fill", "fa-jelly-duo", "fa-slab", "fa-slab-press", "fa-utility", "fa-utility-duo", "fa-utility-fill"], ["fa-solid", "fa-regular", "fa-light", "fa-thin", "fa-duotone", "fa-brands", "fa-semibold"]),
      MK = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
      ap = MK.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
      oK = [].concat(DO(Object.keys({
        classic: ["fas", "far", "fal", "fat", "fad"],
        duotone: ["fadr", "fadl", "fadt"],
        sharp: ["fass", "fasr", "fasl", "fast"],
        "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
        slab: ["faslr"],
        "slab-press": ["faslpr"],
        whiteboard: ["fawsb"],
        thumbprint: ["fatl"],
        notdog: ["fans"],
        "notdog-duo": ["fands"],
        etch: ["faes"],
        graphite: ["fagt"],
        jelly: ["fajr"],
        "jelly-fill": ["fajfr"],
        "jelly-duo": ["fajdr"],
        chisel: ["facr"],
        utility: ["fausb"],
        "utility-duo": ["faudsb"],
        "utility-fill": ["faufsb"]
      })), ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"], ["aw", "fw", "pull-left", "pull-right"], ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "border", "fade", "beat-fade", "bounce", "flip-both", "flip-horizontal", "flip-vertical", "flip", "inverse", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "stack-1x", "stack-2x", "stack", "ul", "width-auto", "width-fixed", eK, lK, vp, CK]).concat(MK.map((function(OO) {
        return "".concat(OO, "x")
      }))).concat(ap.map((function(OO) {
        return "w-".concat(OO)
      }))),
      FK = "___FONT_AWESOME___",
      VK = "svg-inline--fa",
      LK = "data-fa-i2svg",
      QK = "data-fa-pseudo-element",
      zp = "data-prefix",
      AK = "data-icon",
      fK = "fontawesome-i2svg",
      dK = ["HTML", "HEAD", "STYLE", "SCRIPT"],
      TK = ["::before", "::after", ":before", ":after"],
      NK = function() {
        try {
          return !0
        } catch (OO) {
          return !1
        }
      }();

    function IK(OO) {
      return new Proxy(OO, {
        get: function(OO, KO) {
          return KO in OO ? OO[KO] : OO[wO]
        }
      })
    }
    var yp = CO({}, jK);
    yp[wO] = CO(CO(CO(CO({}, {
      "fa-duotone": "duotone"
    }), jK[wO]), KK), pK);
    var gp = IK(yp),
      uK = CO({}, {
        chisel: {
          regular: "facr"
        },
        classic: {
          brands: "fab",
          light: "fal",
          regular: "far",
          solid: "fas",
          thin: "fat"
        },
        duotone: {
          light: "fadl",
          regular: "fadr",
          solid: "fad",
          thin: "fadt"
        },
        etch: {
          solid: "faes"
        },
        graphite: {
          thin: "fagt"
        },
        jelly: {
          regular: "fajr"
        },
        "jelly-duo": {
          regular: "fajdr"
        },
        "jelly-fill": {
          regular: "fajfr"
        },
        notdog: {
          solid: "fans"
        },
        "notdog-duo": {
          solid: "fands"
        },
        sharp: {
          light: "fasl",
          regular: "fasr",
          solid: "fass",
          thin: "fast"
        },
        "sharp-duotone": {
          light: "fasdl",
          regular: "fasdr",
          solid: "fasds",
          thin: "fasdt"
        },
        slab: {
          regular: "faslr"
        },
        "slab-press": {
          regular: "faslpr"
        },
        thumbprint: {
          light: "fatl"
        },
        utility: {
          semibold: "fausb"
        },
        "utility-duo": {
          semibold: "faudsb"
        },
        "utility-fill": {
          semibold: "faufsb"
        },
        whiteboard: {
          semibold: "fawsb"
        }
      });
    uK[wO] = CO(CO(CO(CO({}, {
      duotone: "fad"
    }), uK[wO]), XK), bp);
    var EK = IK(uK),
      jp = CO({}, hK);
    jp[wO] = CO(CO({}, jp[wO]), {
      fak: "fa-kit"
    });
    var YK = IK(jp),
      wK = CO({}, {
        classic: {
          "fa-brands": "fab",
          "fa-duotone": "fad",
          "fa-light": "fal",
          "fa-regular": "far",
          "fa-solid": "fas",
          "fa-thin": "fat"
        },
        duotone: {
          "fa-regular": "fadr",
          "fa-light": "fadl",
          "fa-thin": "fadt"
        },
        sharp: {
          "fa-solid": "fass",
          "fa-regular": "fasr",
          "fa-light": "fasl",
          "fa-thin": "fast"
        },
        "sharp-duotone": {
          "fa-solid": "fasds",
          "fa-regular": "fasdr",
          "fa-light": "fasdl",
          "fa-thin": "fasdt"
        },
        slab: {
          "fa-regular": "faslr"
        },
        "slab-press": {
          "fa-regular": "faslpr"
        },
        whiteboard: {
          "fa-semibold": "fawsb"
        },
        thumbprint: {
          "fa-light": "fatl"
        },
        notdog: {
          "fa-solid": "fans"
        },
        "notdog-duo": {
          "fa-solid": "fands"
        },
        etch: {
          "fa-solid": "faes"
        },
        graphite: {
          "fa-thin": "fagt"
        },
        jelly: {
          "fa-regular": "fajr"
        },
        "jelly-fill": {
          "fa-regular": "fajfr"
        },
        "jelly-duo": {
          "fa-regular": "fajdr"
        },
        chisel: {
          "fa-regular": "facr"
        },
        utility: {
          "fa-semibold": "fausb"
        },
        "utility-duo": {
          "fa-semibold": "faudsb"
        },
        "utility-fill": {
          "fa-semibold": "faufsb"
        }
      });
    wK[wO] = CO(CO({}, wK[wO]), {
      "fa-kit": "fak"
    });
    IK(wK);
    var ip = /fa(k|kd|s|r|l|t|d|dr|dl|dt|b|slr|slpr|wsb|tl|ns|nds|es|gt|jr|jfr|jdr|usb|ufsb|udsb|cr|ss|sr|sl|st|sds|sdr|sdl|sdt)?[\-\ ]/,
      rp = "fa-layers-text",
      PK = /Font ?Awesome ?([567 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit|Notdog Duo|Notdog|Chisel|Etch|Graphite|Thumbprint|Jelly Fill|Jelly Duo|Jelly|Utility|Utility Fill|Utility Duo|Slab Press|Slab|Whiteboard)?.*/i,
      mp = (IK(CO({}, {
        classic: {
          900: "fas",
          400: "far",
          normal: "far",
          300: "fal",
          100: "fat"
        },
        duotone: {
          900: "fad",
          400: "fadr",
          300: "fadl",
          100: "fadt"
        },
        sharp: {
          900: "fass",
          400: "fasr",
          300: "fasl",
          100: "fast"
        },
        "sharp-duotone": {
          900: "fasds",
          400: "fasdr",
          300: "fasdl",
          100: "fasdt"
        },
        slab: {
          400: "faslr"
        },
        "slab-press": {
          400: "faslpr"
        },
        whiteboard: {
          600: "fawsb"
        },
        thumbprint: {
          300: "fatl"
        },
        notdog: {
          900: "fans"
        },
        "notdog-duo": {
          900: "fands"
        },
        etch: {
          900: "faes"
        },
        graphite: {
          100: "fagt"
        },
        chisel: {
          400: "facr"
        },
        jelly: {
          400: "fajr"
        },
        "jelly-fill": {
          400: "fajfr"
        },
        "jelly-duo": {
          400: "fajdr"
        },
        utility: {
          600: "fausb"
        },
        "utility-duo": {
          600: "faudsb"
        },
        "utility-fill": {
          600: "faufsb"
        }
      })), ["class", "data-prefix", "data-icon", "data-fa-transform", "data-fa-mask"]),
      sK = {
        GROUP: "duotone-group",
        SWAP_OPACITY: "swap-opacity",
        PRIMARY: "primary",
        SECONDARY: "secondary"
      },
      HK = [].concat(DO(["kit"]), DO(oK)),
      RK = NO.FontAwesomeConfig || {};
    if (IO && "function" === typeof IO.querySelector) {
      [
        ["data-family-prefix", "familyPrefix"],
        ["data-css-prefix", "cssPrefix"],
        ["data-family-default", "familyDefault"],
        ["data-style-default", "styleDefault"],
        ["data-replacement-class", "replacementClass"],
        ["data-auto-replace-svg", "autoReplaceSvg"],
        ["data-auto-add-css", "autoAddCss"],
        ["data-search-pseudo-elements", "searchPseudoElements"],
        ["data-search-pseudo-elements-warnings", "searchPseudoElementsWarnings"],
        ["data-search-pseudo-elements-full-scan", "searchPseudoElementsFullScan"],
        ["data-observe-mutations", "observeMutations"],
        ["data-mutate-approach", "mutateApproach"],
        ["data-keep-original-source", "keepOriginalSource"],
        ["data-measure-performance", "measurePerformance"],
        ["data-show-missing-icons", "showMissingIcons"]
      ].forEach((function(OO) {
        var KO = hO(OO, 2),
          pO = KO[0],
          XO = KO[1],
          bK = function(OO) {
            return "" === OO || "false" !== OO && ("true" === OO || OO)
          }(function(OO) {
            var KO = IO.querySelector("script[" + OO + "]");
            if (KO) return KO.getAttribute(OO)
          }(pO));
        void 0 !== bK && null !== bK && (RK[XO] = bK)
      }))
    }
    var SK = {
      styleDefault: "solid",
      familyDefault: wO,
      cssPrefix: "fa",
      replacementClass: VK,
      autoReplaceSvg: !0,
      autoAddCss: !0,
      searchPseudoElements: !1,
      searchPseudoElementsWarnings: !0,
      searchPseudoElementsFullScan: !1,
      observeMutations: !0,
      mutateApproach: "async",
      keepOriginalSource: !0,
      measurePerformance: !1,
      showMissingIcons: !0
    };
    RK.familyPrefix && (RK.cssPrefix = RK.familyPrefix);
    var JK = CO(CO({}, SK), RK);
    JK.autoReplaceSvg || (JK.observeMutations = !1);
    var cp = {};
    Object.keys(SK).forEach((function(OO) {
      Object.defineProperty(cp, OO, {
        enumerable: !0,
        set: function(KO) {
          JK[OO] = KO, BK.forEach((function(OO) {
            return OO(cp)
          }))
        },
        get: function() {
          return JK[OO]
        }
      })
    })), Object.defineProperty(cp, "familyPrefix", {
      enumerable: !0,
      set: function(OO) {
        JK.cssPrefix = OO, BK.forEach((function(OO) {
          return OO(cp)
        }))
      },
      get: function() {
        return JK.cssPrefix
      }
    }), NO.FontAwesomeConfig = cp;
    var BK = [];
    var ZK = 16,
      GK = {
        size: 16,
        x: 0,
        y: 0,
        rotate: 0,
        flipX: !1,
        flipY: !1
      };

    function qp() {
      for (var OO = 12, KO = ""; OO-- > 0;) KO += "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" [62 * Math.random() | 0];
      return KO
    }

    function xp(OO) {
      for (var KO = [], pO = (OO || []).length >>> 0; pO--;) KO[pO] = OO[pO];
      return KO
    }

    function nK(OO) {
      return OO.classList ? xp(OO.classList) : (OO.getAttribute("class") || "").split(" ").filter((function(OO) {
        return OO
      }))
    }

    function WK(OO) {
      return "".concat(OO).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    }

    function tp(OO) {
      return Object.keys(OO || {}).reduce((function(KO, pO) {
        return KO + "".concat(pO, ": ").concat(OO[pO].trim(), ";")
      }), "")
    }

    function kp(OO) {
      return OO.size !== GK.size || OO.x !== GK.x || OO.y !== GK.y || OO.rotate !== GK.rotate || OO.flipX || OO.flipY
    }

    function UK() {
      var OO = "fa",
        KO = VK,
        pO = cp.cssPrefix,
        XO = cp.replacementClass,
        bK = ":root, :host {\n  --fa-font-solid: normal 900 1em/1 'Font Awesome 7 Free';\n  --fa-font-regular: normal 400 1em/1 'Font Awesome 7 Free';\n  --fa-font-light: normal 300 1em/1 'Font Awesome 7 Pro';\n  --fa-font-thin: normal 100 1em/1 'Font Awesome 7 Pro';\n  --fa-font-duotone: normal 900 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-regular: normal 400 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-light: normal 300 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-thin: normal 100 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-brands: normal 400 1em/1 'Font Awesome 7 Brands';\n  --fa-font-sharp-solid: normal 900 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-regular: normal 400 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-light: normal 300 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-thin: normal 100 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-duotone-solid: normal 900 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-regular: normal 400 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-light: normal 300 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-thin: normal 100 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-slab-regular: normal 400 1em/1 'Font Awesome 7 Slab';\n  --fa-font-slab-press-regular: normal 400 1em/1 'Font Awesome 7 Slab Press';\n  --fa-font-whiteboard-semibold: normal 600 1em/1 'Font Awesome 7 Whiteboard';\n  --fa-font-thumbprint-light: normal 300 1em/1 'Font Awesome 7 Thumbprint';\n  --fa-font-notdog-solid: normal 900 1em/1 'Font Awesome 7 Notdog';\n  --fa-font-notdog-duo-solid: normal 900 1em/1 'Font Awesome 7 Notdog Duo';\n  --fa-font-etch-solid: normal 900 1em/1 'Font Awesome 7 Etch';\n  --fa-font-graphite-thin: normal 100 1em/1 'Font Awesome 7 Graphite';\n  --fa-font-jelly-regular: normal 400 1em/1 'Font Awesome 7 Jelly';\n  --fa-font-jelly-fill-regular: normal 400 1em/1 'Font Awesome 7 Jelly Fill';\n  --fa-font-jelly-duo-regular: normal 400 1em/1 'Font Awesome 7 Jelly Duo';\n  --fa-font-chisel-regular: normal 400 1em/1 'Font Awesome 7 Chisel';\n  --fa-font-utility-semibold: normal 600 1em/1 'Font Awesome 7 Utility';\n  --fa-font-utility-duo-semibold: normal 600 1em/1 'Font Awesome 7 Utility Duo';\n  --fa-font-utility-fill-semibold: normal 600 1em/1 'Font Awesome 7 Utility Fill';\n}\n\n.svg-inline--fa {\n  box-sizing: content-box;\n  display: var(--fa-display, inline-block);\n  height: 1em;\n  overflow: visible;\n  vertical-align: -0.125em;\n  width: var(--fa-width, 1.25em);\n}\n.svg-inline--fa.fa-2xs {\n  vertical-align: 0.1em;\n}\n.svg-inline--fa.fa-xs {\n  vertical-align: 0em;\n}\n.svg-inline--fa.fa-sm {\n  vertical-align: -0.0714285714em;\n}\n.svg-inline--fa.fa-lg {\n  vertical-align: -0.2em;\n}\n.svg-inline--fa.fa-xl {\n  vertical-align: -0.25em;\n}\n.svg-inline--fa.fa-2xl {\n  vertical-align: -0.3125em;\n}\n.svg-inline--fa.fa-pull-left,\n.svg-inline--fa .fa-pull-start {\n  float: inline-start;\n  margin-inline-end: var(--fa-pull-margin, 0.3em);\n}\n.svg-inline--fa.fa-pull-right,\n.svg-inline--fa .fa-pull-end {\n  float: inline-end;\n  margin-inline-start: var(--fa-pull-margin, 0.3em);\n}\n.svg-inline--fa.fa-li {\n  width: var(--fa-li-width, 2em);\n  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));\n  inset-block-start: 0.25em; /* syncing vertical alignment with Web Font rendering */\n}\n\n.fa-layers-counter, .fa-layers-text {\n  display: inline-block;\n  position: absolute;\n  text-align: center;\n}\n\n.fa-layers {\n  display: inline-block;\n  height: 1em;\n  position: relative;\n  text-align: center;\n  vertical-align: -0.125em;\n  width: var(--fa-width, 1.25em);\n}\n.fa-layers .svg-inline--fa {\n  inset: 0;\n  margin: auto;\n  position: absolute;\n  transform-origin: center center;\n}\n\n.fa-layers-text {\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n  transform-origin: center center;\n}\n\n.fa-layers-counter {\n  background-color: var(--fa-counter-background-color, #ff253a);\n  border-radius: var(--fa-counter-border-radius, 1em);\n  box-sizing: border-box;\n  color: var(--fa-inverse, #fff);\n  line-height: var(--fa-counter-line-height, 1);\n  max-width: var(--fa-counter-max-width, 5em);\n  min-width: var(--fa-counter-min-width, 1.5em);\n  overflow: hidden;\n  padding: var(--fa-counter-padding, 0.25em 0.5em);\n  right: var(--fa-right, 0);\n  text-overflow: ellipsis;\n  top: var(--fa-top, 0);\n  transform: scale(var(--fa-counter-scale, 0.25));\n  transform-origin: top right;\n}\n\n.fa-layers-bottom-right {\n  bottom: var(--fa-bottom, 0);\n  right: var(--fa-right, 0);\n  top: auto;\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: bottom right;\n}\n\n.fa-layers-bottom-left {\n  bottom: var(--fa-bottom, 0);\n  left: var(--fa-left, 0);\n  right: auto;\n  top: auto;\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: bottom left;\n}\n\n.fa-layers-top-right {\n  top: var(--fa-top, 0);\n  right: var(--fa-right, 0);\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: top right;\n}\n\n.fa-layers-top-left {\n  left: var(--fa-left, 0);\n  right: auto;\n  top: var(--fa-top, 0);\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: top left;\n}\n\n.fa-1x {\n  font-size: 1em;\n}\n\n.fa-2x {\n  font-size: 2em;\n}\n\n.fa-3x {\n  font-size: 3em;\n}\n\n.fa-4x {\n  font-size: 4em;\n}\n\n.fa-5x {\n  font-size: 5em;\n}\n\n.fa-6x {\n  font-size: 6em;\n}\n\n.fa-7x {\n  font-size: 7em;\n}\n\n.fa-8x {\n  font-size: 8em;\n}\n\n.fa-9x {\n  font-size: 9em;\n}\n\n.fa-10x {\n  font-size: 10em;\n}\n\n.fa-2xs {\n  font-size: calc(10 / 16 * 1em); /* converts a 10px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 10 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 10 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-xs {\n  font-size: calc(12 / 16 * 1em); /* converts a 12px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 12 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 12 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-sm {\n  font-size: calc(14 / 16 * 1em); /* converts a 14px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 14 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 14 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-lg {\n  font-size: calc(20 / 16 * 1em); /* converts a 20px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 20 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 20 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-xl {\n  font-size: calc(24 / 16 * 1em); /* converts a 24px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 24 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 24 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-2xl {\n  font-size: calc(32 / 16 * 1em); /* converts a 32px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 32 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 32 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-width-auto {\n  --fa-width: auto;\n}\n\n.fa-fw,\n.fa-width-fixed {\n  --fa-width: 1.25em;\n}\n\n.fa-ul {\n  list-style-type: none;\n  margin-inline-start: var(--fa-li-margin, 2.5em);\n  padding-inline-start: 0;\n}\n.fa-ul > li {\n  position: relative;\n}\n\n.fa-li {\n  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));\n  position: absolute;\n  text-align: center;\n  width: var(--fa-li-width, 2em);\n  line-height: inherit;\n}\n\n/* Heads Up: Bordered Icons will not be supported in the future!\n  - This feature will be deprecated in the next major release of Font Awesome (v8)!\n  - You may continue to use it in this version *v7), but it will not be supported in Font Awesome v8.\n*/\n/* Notes:\n* --@{v.$css-prefix}-border-width = 1/16 by default (to render as ~1px based on a 16px default font-size)\n* --@{v.$css-prefix}-border-padding =\n  ** 3/16 for vertical padding (to give ~2px of vertical whitespace around an icon considering it's vertical alignment)\n  ** 4/16 for horizontal padding (to give ~4px of horizontal whitespace around an icon)\n*/\n.fa-border {\n  border-color: var(--fa-border-color, #eee);\n  border-radius: var(--fa-border-radius, 0.1em);\n  border-style: var(--fa-border-style, solid);\n  border-width: var(--fa-border-width, 0.0625em);\n  box-sizing: var(--fa-border-box-sizing, content-box);\n  padding: var(--fa-border-padding, 0.1875em 0.25em);\n}\n\n.fa-pull-left,\n.fa-pull-start {\n  float: inline-start;\n  margin-inline-end: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-pull-right,\n.fa-pull-end {\n  float: inline-end;\n  margin-inline-start: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-beat {\n  animation-name: fa-beat;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-bounce {\n  animation-name: fa-bounce;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));\n}\n\n.fa-fade {\n  animation-name: fa-fade;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-beat-fade {\n  animation-name: fa-beat-fade;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-flip {\n  animation-name: fa-flip;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-shake {\n  animation-name: fa-shake;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin {\n  animation-name: fa-spin;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 2s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin-reverse {\n  --fa-animation-direction: reverse;\n}\n\n.fa-pulse,\n.fa-spin-pulse {\n  animation-name: fa-spin;\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, steps(8));\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .fa-beat,\n  .fa-bounce,\n  .fa-fade,\n  .fa-beat-fade,\n  .fa-flip,\n  .fa-pulse,\n  .fa-shake,\n  .fa-spin,\n  .fa-spin-pulse {\n    animation: none !important;\n    transition: none !important;\n  }\n}\n@keyframes fa-beat {\n  0%, 90% {\n    transform: scale(1);\n  }\n  45% {\n    transform: scale(var(--fa-beat-scale, 1.25));\n  }\n}\n@keyframes fa-bounce {\n  0% {\n    transform: scale(1, 1) translateY(0);\n  }\n  10% {\n    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n  }\n  30% {\n    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n  }\n  50% {\n    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n  }\n  57% {\n    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n  }\n  64% {\n    transform: scale(1, 1) translateY(0);\n  }\n  100% {\n    transform: scale(1, 1) translateY(0);\n  }\n}\n@keyframes fa-fade {\n  50% {\n    opacity: var(--fa-fade-opacity, 0.4);\n  }\n}\n@keyframes fa-beat-fade {\n  0%, 100% {\n    opacity: var(--fa-beat-fade-opacity, 0.4);\n    transform: scale(1);\n  }\n  50% {\n    opacity: 1;\n    transform: scale(var(--fa-beat-fade-scale, 1.125));\n  }\n}\n@keyframes fa-flip {\n  50% {\n    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n  }\n}\n@keyframes fa-shake {\n  0% {\n    transform: rotate(-15deg);\n  }\n  4% {\n    transform: rotate(15deg);\n  }\n  8%, 24% {\n    transform: rotate(-18deg);\n  }\n  12%, 28% {\n    transform: rotate(18deg);\n  }\n  16% {\n    transform: rotate(-22deg);\n  }\n  20% {\n    transform: rotate(22deg);\n  }\n  32% {\n    transform: rotate(-12deg);\n  }\n  36% {\n    transform: rotate(12deg);\n  }\n  40%, 100% {\n    transform: rotate(0deg);\n  }\n}\n@keyframes fa-spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.fa-rotate-90 {\n  transform: rotate(90deg);\n}\n\n.fa-rotate-180 {\n  transform: rotate(180deg);\n}\n\n.fa-rotate-270 {\n  transform: rotate(270deg);\n}\n\n.fa-flip-horizontal {\n  transform: scale(-1, 1);\n}\n\n.fa-flip-vertical {\n  transform: scale(1, -1);\n}\n\n.fa-flip-both,\n.fa-flip-horizontal.fa-flip-vertical {\n  transform: scale(-1, -1);\n}\n\n.fa-rotate-by {\n  transform: rotate(var(--fa-rotate-angle, 0));\n}\n\n.svg-inline--fa .fa-primary {\n  fill: var(--fa-primary-color, currentColor);\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa .fa-secondary {\n  fill: var(--fa-secondary-color, currentColor);\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-primary {\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-secondary {\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa mask .fa-primary,\n.svg-inline--fa mask .fa-secondary {\n  fill: black;\n}\n\n.svg-inline--fa.fa-inverse {\n  fill: var(--fa-inverse, #fff);\n}\n\n.fa-stack {\n  display: inline-block;\n  height: 2em;\n  line-height: 2em;\n  position: relative;\n  vertical-align: middle;\n  width: 2.5em;\n}\n\n.fa-inverse {\n  color: var(--fa-inverse, #fff);\n}\n\n.svg-inline--fa.fa-stack-1x {\n  --fa-width: 1.25em;\n  height: 1em;\n  width: var(--fa-width);\n}\n.svg-inline--fa.fa-stack-2x {\n  --fa-width: 2.5em;\n  height: 2em;\n  width: var(--fa-width);\n}\n\n.fa-stack-1x,\n.fa-stack-2x {\n  inset: 0;\n  margin: auto;\n  position: absolute;\n  z-index: var(--fa-stack-z-index, auto);\n}";
      if (pO !== OO || XO !== KO) {
        var eO = new RegExp("\\.".concat(OO, "\\-"), "g"),
          lO = new RegExp("\\--".concat(OO, "\\-"), "g"),
          vK = new RegExp("\\.".concat(KO), "g");
        bK = bK.replace(eO, ".".concat(pO, "-")).replace(lO, "--".concat(pO, "-")).replace(vK, ".".concat(XO))
      }
      return bK
    }
    var Op = !1;

    function Kp() {
      cp.autoAddCss && !Op && (! function(OO) {
        if (OO && uO) {
          var KO = IO.createElement("style");
          KO.setAttribute("type", "text/css"), KO.innerHTML = OO;
          for (var pO = IO.head.childNodes, XO = null, bK = pO.length - 1; bK > -1; bK--) {
            var eO = pO[bK],
              lO = (eO.tagName || "").toUpperCase();
            ["STYLE", "LINK"].indexOf(lO) > -1 && (XO = eO)
          }
          IO.head.insertBefore(KO, XO)
        }
      }(UK()), Op = !0)
    }
    var pp = {
        mixout: function() {
          return {
            dom: {
              css: UK,
              insertCss: Kp
            }
          }
        },
        hooks: function() {
          return {
            beforeDOMElementCreation: function() {
              Kp()
            },
            beforeI2svg: function() {
              Kp()
            }
          }
        }
      },
      Xp = NO || {};
    Xp[FK] || (Xp[FK] = {}), Xp[FK].styles || (Xp[FK].styles = {}), Xp[FK].hooks || (Xp[FK].hooks = {}), Xp[FK].shims || (Xp[FK].shims = []);
    var bX = Xp[FK],
      ep = [],
      lp = function() {
        IO.removeEventListener("DOMContentLoaded", lp), vX = 1, ep.map((function(OO) {
          return OO()
        }))
      },
      vX = !1;

    function Cp(OO) {
      var KO = OO.tag,
        pO = OO.attributes,
        XO = void 0 === pO ? {} : pO,
        bK = OO.children,
        eO = void 0 === bK ? [] : bK;
      return "string" === typeof OO ? WK(OO) : "<".concat(KO, " ").concat(function(OO) {
        return Object.keys(OO || {}).reduce((function(KO, pO) {
          return KO + "".concat(pO, '="').concat(WK(OO[pO]), '" ')
        }), "").trim()
      }(XO), ">").concat(eO.map(Cp).join(""), "</").concat(KO, ">")
    }

    function hp(OO, KO, pO) {
      if (OO && OO[KO] && OO[KO][pO]) return {
        prefix: KO,
        iconName: pO,
        icon: OO[KO][pO]
      }
    }
    uO && ((vX = (IO.documentElement.doScroll ? /^loaded|^c/ : /^loaded|^i|^c/).test(IO.readyState)) || IO.addEventListener("DOMContentLoaded", lp));
    var Dp = function(OO, KO, pO, XO) {
      var bK, eO, lO, vK = Object.keys(OO),
        CO = vK.length,
        hO = void 0 !== XO ? function(OO, KO) {
          return function(pO, XO, bK, eO) {
            return OO.call(KO, pO, XO, bK, eO)
          }
        }(KO, XO) : KO;
      for (void 0 === pO ? (bK = 1, lO = OO[vK[0]]) : (bK = 0, lO = pO); bK < CO; bK++) lO = hO(lO, OO[eO = vK[bK]], eO, OO);
      return lO
    };

    function Mp(OO) {
      return 1 !== DO(OO).length ? null : OO.codePointAt(0).toString(16)
    }

    function aX(OO) {
      return Object.keys(OO).reduce((function(KO, pO) {
        var XO = OO[pO];
        return !!XO.icon ? KO[XO.iconName] = XO.icon : KO[pO] = XO, KO
      }), {})
    }

    function op(OO, KO) {
      var pO = (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}).skipHooks,
        XO = void 0 !== pO && pO,
        bK = aX(KO);
      "function" !== typeof bX.hooks.addPack || XO ? bX.styles[OO] = CO(CO({}, bX.styles[OO] || {}), bK) : bX.hooks.addPack(OO, aX(KO)), "fas" === OO && op("fa", KO)
    }
    var Fp = bX.styles,
      Vp = bX.shims,
      Lp = Object.keys(YK),
      Qp = Lp.reduce((function(OO, KO) {
        return OO[KO] = Object.keys(YK[KO]), OO
      }), {}),
      zX = null,
      Ap = {},
      fp = {},
      dp = {},
      Tp = {},
      Np = {};

    function Ip(OO, KO) {
      var pO, XO = KO.split("-"),
        bK = XO[0],
        eO = XO.slice(1).join("-");
      return bK !== OO || "" === eO || (pO = eO, ~HK.indexOf(pO)) ? null : eO
    }
    var yX, gX = function() {
      var OO = function(OO) {
        return Dp(Fp, (function(KO, pO, XO) {
          return KO[XO] = Dp(pO, OO, {}), KO
        }), {})
      };
      Ap = OO((function(OO, KO, pO) {
        (KO[3] && (OO[KO[3]] = pO), KO[2]) && KO[2].filter((function(OO) {
          return "number" === typeof OO
        })).forEach((function(KO) {
          OO[KO.toString(16)] = pO
        }));
        return OO
      })), fp = OO((function(OO, KO, pO) {
        (OO[pO] = pO, KO[2]) && KO[2].filter((function(OO) {
          return "string" === typeof OO
        })).forEach((function(KO) {
          OO[KO] = pO
        }));
        return OO
      })), Np = OO((function(OO, KO, pO) {
        var XO = KO[2];
        return OO[pO] = pO, XO.forEach((function(KO) {
          OO[KO] = pO
        })), OO
      }));
      var KO = "far" in Fp || cp.autoFetchSvg,
        pO = Dp(Vp, (function(OO, pO) {
          var XO = pO[0],
            bK = pO[1],
            eO = pO[2];
          return "far" !== bK || KO || (bK = "fas"), "string" === typeof XO && (OO.names[XO] = {
            prefix: bK,
            iconName: eO
          }), "number" === typeof XO && (OO.unicodes[XO.toString(16)] = {
            prefix: bK,
            iconName: eO
          }), OO
        }), {
          names: {},
          unicodes: {}
        });
      dp = pO.names, Tp = pO.unicodes, zX = wp(cp.styleDefault, {
        family: cp.familyDefault
      })
    };

    function upO(OO, KO) {
      return (Ap[OO] || {})[KO]
    }

    function Ep(OO, KO) {
      return (Np[OO] || {})[KO]
    }

    function jX(OO) {
      return dp[OO] || {
        prefix: null,
        iconName: null
      }
    }

    function Yp() {
      return zX
    }
    yX = function(OO) {
      zX = wp(OO.styleDefault, {
        family: cp.familyDefault
      })
    }, BK.push(yX), gX();

    function wp(OO) {
      var KO = (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}).family,
        pO = void 0 === KO ? wO : KO,
        XO = gp[pO][OO];
      if (pO === iK && !OO) return "fad";
      var bK = EK[pO][OO] || EK[pO][XO],
        eO = OO in bX.styles ? OO : null;
      return bK || eO || null
    }

    function iX(OO) {
      return OO.sort().filter((function(OO, KO, pO) {
        return pO.indexOf(OO) === KO
      }))
    }
    var rX = DK.concat(OK);

    function Pp(OO) {
      var KO = (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}).skipLookups,
        pO = void 0 !== KO && KO,
        XO = null,
        bK = iX(OO.filter((function(OO) {
          return rX.includes(OO)
        }))),
        eO = iX(OO.filter((function(OO) {
          return !rX.includes(OO)
        }))),
        lO = hO(bK.filter((function(OO) {
          return XO = OO, !YO.includes(OO)
        })), 1)[0],
        vK = void 0 === lO ? null : lO,
        DO = function(OO) {
          var KO = wO,
            pO = Lp.reduce((function(OO, KO) {
              return OO[KO] = "".concat(cp.cssPrefix, "-").concat(KO), OO
            }), {});
          return kK.forEach((function(XO) {
            (OO.includes(pO[XO]) || OO.some((function(OO) {
              return Qp[XO].includes(OO)
            }))) && (KO = XO)
          })), KO
        }(bK),
        MO = CO(CO({}, function(OO) {
          var KO = [],
            pO = null;
          return OO.forEach((function(OO) {
            var XO = Ip(cp.cssPrefix, OO);
            XO ? pO = XO : OO && KO.push(OO)
          })), {
            iconName: pO,
            rest: KO
          }
        }(eO)), {}, {
          prefix: wp(vK, {
            family: DO
          })
        });
      return CO(CO(CO({}, MO), function(OO) {
        var KO = OO.values,
          pO = OO.family,
          XO = OO.canonical,
          bK = OO.givenPrefix,
          eO = void 0 === bK ? "" : bK,
          lO = OO.styles,
          vK = void 0 === lO ? {} : lO,
          CO = OO.config,
          hO = void 0 === CO ? {} : CO,
          DO = pO === iK,
          MO = KO.includes("fa-duotone") || KO.includes("fad"),
          aK = "duotone" === hO.familyDefault,
          oO = "fad" === XO.prefix || "fa-duotone" === XO.prefix;
        !DO && (MO || aK || oO) && (XO.prefix = "fad");
        (KO.includes("fa-brands") || KO.includes("fab")) && (XO.prefix = "fab");
        if (!XO.prefix && mX.includes(pO)) {
          if (Object.keys(vK).find((function(OO) {
              return sp.includes(OO)
            })) || hO.autoFetchSvg) {
            var FO = UO.get(pO).defaultShortPrefixId;
            XO.prefix = FO, XO.iconName = Ep(XO.prefix, XO.iconName) || XO.iconName
          }
        }
        "fa" !== XO.prefix && "fa" !== eO || (XO.prefix = Yp() || "fas");
        return XO
      }({
        values: OO,
        family: DO,
        styles: Fp,
        config: cp,
        canonical: MO,
        givenPrefix: XO
      })), function(OO, KO, pO) {
        var XO = pO.prefix,
          bK = pO.iconName;
        if (OO || !XO || !bK) return {
          prefix: XO,
          iconName: bK
        };
        var eO = "fa" === KO ? jX(bK) : {},
          lO = Ep(XO, bK);
        bK = eO.iconName || lO || bK, "far" !== (XO = eO.prefix || XO) || Fp.far || !Fp.fas || cp.autoFetchSvg || (XO = "fas");
        return {
          prefix: XO,
          iconName: bK
        }
      }(pO, XO, MO))
    }
    var mX = kK.filter((function(OO) {
        return OO !== wO || OO !== iK
      })),
      sp = Object.keys(hK).filter((function(OO) {
        return OO !== wO
      })).map((function(OO) {
        return Object.keys(hK[OO])
      })).flat();
    var Hp = function() {
        return function(OO, KO, pO) {
          return KO && bK(OO.prototype, KO), pO && bK(OO, pO), Object.defineProperty(OO, "prototype", {
            writable: !1
          }), OO
        }((function OO() {
          ! function(OO, KO) {
            if (!(OO instanceof KO)) throw new TypeError("Cannot call a class as a function")
          }(this, OO), this.definitions = {}
        }), [{
          key: "add",
          value: function() {
            for (var OO = this, KO = arguments.length, pO = new Array(KO), XO = 0; XO < KO; XO++) pO[XO] = arguments[XO];
            var bK = pO.reduce(this._pullDefinitions, {});
            Object.keys(bK).forEach((function(KO) {
              OO.definitions[KO] = CO(CO({}, OO.definitions[KO] || {}), bK[KO]), op(KO, bK[KO]);
              var pO = YK[wO][KO];
              pO && op(pO, bK[KO]), gX()
            }))
          }
        }, {
          key: "reset",
          value: function() {
            this.definitions = {}
          }
        }, {
          key: "_pullDefinitions",
          value: function(OO, KO) {
            var pO = KO.prefix && KO.iconName && KO.icon ? {
              0: KO
            } : KO;
            return Object.keys(pO).map((function(KO) {
              var XO = pO[KO],
                bK = XO.prefix,
                eO = XO.iconName,
                lO = XO.icon,
                vK = lO[2];
              OO[bK] || (OO[bK] = {}), vK.length > 0 && vK.forEach((function(KO) {
                "string" === typeof KO && (OO[bK][KO] = lO)
              })), OO[bK][eO] = lO
            })), OO
          }
        }])
      }(),
      Rp = [],
      Sp = {},
      Jp = {},
      cX = Object.keys(Jp);

    function Bp(OO, KO) {
      for (var pO = arguments.length, XO = new Array(pO > 2 ? pO - 2 : 0), bK = 2; bK < pO; bK++) XO[bK - 2] = arguments[bK];
      return (Sp[OO] || []).forEach((function(OO) {
        KO = OO.apply(null, [KO].concat(XO))
      })), KO
    }

    function Zp(OO) {
      for (var KO = arguments.length, pO = new Array(KO > 1 ? KO - 1 : 0), XO = 1; XO < KO; XO++) pO[XO - 1] = arguments[XO];
      (Sp[OO] || []).forEach((function(OO) {
        OO.apply(null, pO)
      }))
    }

    function Gp() {
      var OO = arguments[0],
        KO = Array.prototype.slice.call(arguments, 1);
      return Jp[OO] ? Jp[OO].apply(null, KO) : void 0
    }

    function qX(OO) {
      "fa" === OO.prefix && (OO.prefix = "fas");
      var KO = OO.iconName,
        pO = OO.prefix || Yp();
      if (KO) return KO = Ep(pO, KO) || KO, hp(xX.definitions, pO, KO) || hp(bX.styles, pO, KO)
    }
    var xX = new Hp,
      np = {
        i2svg: function() {
          var OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          return uO ? (Zp("beforeI2svg", OO), Gp("pseudoElements2svg", OO), Gp("i2svg", OO)) : Promise.reject(new Error("Operation requires a DOM of some kind."))
        },
        watch: function() {
          var OO, KO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            pO = KO.autoReplaceSvgRoot;
          !1 === cp.autoReplaceSvg && (cp.autoReplaceSvg = !0), cp.observeMutations = !0, OO = function() {
            tX({
              autoReplaceSvgRoot: pO
            }), Zp("watch", KO)
          }, uO && (vX ? setTimeout(OO, 0) : ep.push(OO))
        }
      },
      Wp = {
        noAuto: function() {
          cp.autoReplaceSvg = !1, cp.observeMutations = !1, Zp("noAuto")
        },
        config: cp,
        dom: np,
        parse: {
          icon: function(OO) {
            if (null === OO) return null;
            if ("object" === aK(OO) && OO.prefix && OO.iconName) return {
              prefix: OO.prefix,
              iconName: Ep(OO.prefix, OO.iconName) || OO.iconName
            };
            if (Array.isArray(OO) && 2 === OO.length) {
              var KO = 0 === OO[1].indexOf("fa-") ? OO[1].slice(3) : OO[1],
                pO = wp(OO[0]);
              return {
                prefix: pO,
                iconName: Ep(pO, KO) || KO
              }
            }
            if ("string" === typeof OO && (OO.indexOf("".concat(cp.cssPrefix, "-")) > -1 || OO.match(ip))) {
              var XO = Pp(OO.split(" "), {
                skipLookups: !0
              });
              return {
                prefix: XO.prefix || Yp(),
                iconName: Ep(XO.prefix, XO.iconName) || XO.iconName
              }
            }
            if ("string" === typeof OO) {
              var bK = Yp();
              return {
                prefix: bK,
                iconName: Ep(bK, OO) || OO
              }
            }
          }
        },
        library: xX,
        findIconDefinition: qX,
        toHtml: Cp
      },
      tX = function() {
        var OO = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).autoReplaceSvgRoot,
          KO = void 0 === OO ? IO : OO;
        (Object.keys(bX.styles).length > 0 || cp.autoFetchSvg) && uO && cp.autoReplaceSvg && Wp.dom.i2svg({
          node: KO
        })
      };

    function kX(OO, KO) {
      return Object.defineProperty(OO, "abstract", {
        get: KO
      }), Object.defineProperty(OO, "html", {
        get: function() {
          return OO.abstract.map((function(OO) {
            return Cp(OO)
          }))
        }
      }), Object.defineProperty(OO, "node", {
        get: function() {
          if (uO) {
            var KO = IO.createElement("div");
            return KO.innerHTML = OO.html, KO.children
          }
        }
      }), OO
    }

    function Up(OO) {
      var KO = OO.icons,
        pO = KO.main,
        XO = KO.mask,
        bK = OO.prefix,
        eO = OO.iconName,
        lO = OO.transform,
        vK = OO.symbol,
        hO = OO.maskId,
        DO = OO.extra,
        MO = OO.watchable,
        aK = void 0 !== MO && MO,
        oO = XO.found ? XO : pO,
        FO = oO.width,
        VO = oO.height,
        LO = [cp.replacementClass, eO ? "".concat(cp.cssPrefix, "-").concat(eO) : ""].filter((function(OO) {
          return -1 === DO.classes.indexOf(OO)
        })).filter((function(OO) {
          return "" !== OO || !!OO
        })).concat(DO.classes).join(" "),
        QO = {
          children: [],
          attributes: CO(CO({}, DO.attributes), {}, {
            "data-prefix": bK,
            "data-icon": eO,
            class: LO,
            role: DO.attributes.role || "img",
            viewBox: "0 0 ".concat(FO, " ").concat(VO)
          })
        };
      (function(OO) {
        return ["aria-label", "aria-labelledby", "title", "role"].some((function(KO) {
          return KO in OO
        }))
      })(DO.attributes) || DO.attributes["aria-hidden"] || (QO.attributes["aria-hidden"] = "true"), aK && (QO.attributes[LK] = "");
      var zK = CO(CO({}, QO), {}, {
          prefix: bK,
          iconName: eO,
          main: pO,
          mask: XO,
          maskId: hO,
          transform: lO,
          symbol: vK,
          styles: CO({}, DO.styles)
        }),
        AO = XO.found && pO.found ? Gp("generateAbstractMask", zK) || {
          children: [],
          attributes: {}
        } : Gp("generateAbstractIcon", zK) || {
          children: [],
          attributes: {}
        },
        fO = AO.children,
        dO = AO.attributes;
      return zK.children = fO, zK.attributes = dO, vK ? function(OO) {
        var KO = OO.prefix,
          pO = OO.iconName,
          XO = OO.children,
          bK = OO.attributes,
          eO = OO.symbol,
          lO = !0 === eO ? "".concat(KO, "-").concat(cp.cssPrefix, "-").concat(pO) : eO;
        return [{
          tag: "svg",
          attributes: {
            style: "display: none;"
          },
          children: [{
            tag: "symbol",
            attributes: CO(CO({}, bK), {}, {
              id: lO
            }),
            children: XO
          }]
        }]
      }(zK) : function(OO) {
        var KO = OO.children,
          pO = OO.main,
          XO = OO.mask,
          bK = OO.attributes,
          eO = OO.styles,
          lO = OO.transform;
        if (kp(lO) && pO.found && !XO.found) {
          var vK = {
            x: pO.width / pO.height / 2,
            y: .5
          };
          bK.style = tp(CO(CO({}, eO), {}, {
            "transform-origin": "".concat(vK.x + lO.x / 16, "em ").concat(vK.y + lO.y / 16, "em")
          }))
        }
        return [{
          tag: "svg",
          attributes: bK,
          children: KO
        }]
      }(zK)
    }

    function OX(OO) {
      var KO = OO.content,
        pO = OO.width,
        XO = OO.height,
        bK = OO.transform,
        eO = OO.extra,
        lO = OO.watchable,
        vK = void 0 !== lO && lO,
        hO = CO(CO({}, eO.attributes), {}, {
          class: eO.classes.join(" ")
        });
      vK && (hO[LK] = "");
      var DO = CO({}, eO.styles);
      kp(bK) && (DO.transform = function(OO) {
        var KO = OO.transform,
          pO = OO.width,
          XO = void 0 === pO ? 16 : pO,
          bK = OO.height,
          eO = void 0 === bK ? 16 : bK,
          lO = OO.startCentered,
          vK = void 0 !== lO && lO,
          CO = "";
        return CO += vK && EO ? "translate(".concat(KO.x / ZK - XO / 2, "em, ").concat(KO.y / ZK - eO / 2, "em) ") : vK ? "translate(calc(-50% + ".concat(KO.x / ZK, "em), calc(-50% + ").concat(KO.y / ZK, "em)) ") : "translate(".concat(KO.x / ZK, "em, ").concat(KO.y / ZK, "em) "), CO += "scale(".concat(KO.size / ZK * (KO.flipX ? -1 : 1), ", ").concat(KO.size / ZK * (KO.flipY ? -1 : 1), ") "), CO + "rotate(".concat(KO.rotate, "deg) ")
      }({
        transform: bK,
        startCentered: !0,
        width: pO,
        height: XO
      }), DO["-webkit-transform"] = DO.transform);
      var MO = tp(DO);
      MO.length > 0 && (hO.style = MO);
      var aK = [];
      return aK.push({
        tag: "span",
        attributes: hO,
        children: [KO]
      }), aK
    }
    var KX = bX.styles;

    function pX(OO) {
      var KO = OO[0],
        pO = OO[1],
        XO = hO(OO.slice(4), 1)[0];
      return {
        found: !0,
        width: KO,
        height: pO,
        icon: Array.isArray(XO) ? {
          tag: "g",
          attributes: {
            class: "".concat(cp.cssPrefix, "-").concat(sK.GROUP)
          },
          children: [{
            tag: "path",
            attributes: {
              class: "".concat(cp.cssPrefix, "-").concat(sK.SECONDARY),
              fill: "currentColor",
              d: XO[0]
            }
          }, {
            tag: "path",
            attributes: {
              class: "".concat(cp.cssPrefix, "-").concat(sK.PRIMARY),
              fill: "currentColor",
              d: XO[1]
            }
          }]
        } : {
          tag: "path",
          attributes: {
            fill: "currentColor",
            d: XO
          }
        }
      }
    }
    var XX = {
      found: !1,
      width: 512,
      height: 512
    };

    function bb(OO, KO) {
      var pO = KO;
      return "fa" === KO && null !== cp.styleDefault && (KO = Yp()), new Promise((function(XO, bK) {
        if ("fa" === pO) {
          var eO = jX(OO) || {};
          OO = eO.iconName || OO, KO = eO.prefix || KO
        }
        if (OO && KO && KX[KO] && KX[KO][OO]) return XO(pX(KX[KO][OO]));
        ! function(OO, KO) {
          NK || cp.showMissingIcons || !OO || console.error('Icon with name "'.concat(OO, '" and prefix "').concat(KO, '" is missing.'))
        }(OO, KO), XO(CO(CO({}, XX), {}, {
          icon: cp.showMissingIcons && OO && Gp("missingIconAbstract") || {}
        }))
      }))
    }
    var eX = function() {},
      lX = cp.measurePerformance && gK && gK.mark && gK.measure ? gK : {
        mark: eX,
        measure: eX
      },
      vb = 'FA "7.2.0"',
      CX = function(OO) {
        lX.mark("".concat(vb, " ").concat(OO, " ends")), lX.measure("".concat(vb, " ").concat(OO), "".concat(vb, " ").concat(OO, " begins"), "".concat(vb, " ").concat(OO, " ends"))
      },
      hX = function(OO) {
        return lX.mark("".concat(vb, " ").concat(OO, " begins")),
          function() {
            return CX(OO)
          }
      },
      DX = function() {};

    function MX(OO) {
      return "string" === typeof(OO.getAttribute ? OO.getAttribute(LK) : null)
    }

    function ab(OO) {
      return IO.createElementNS("http://www.w3.org/2000/svg", OO)
    }

    function oX(OO) {
      return IO.createElement(OO)
    }

    function FX(OO) {
      var KO = (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}).ceFn,
        pO = void 0 === KO ? "svg" === OO.tag ? ab : oX : KO;
      if ("string" === typeof OO) return IO.createTextNode(OO);
      var XO = pO(OO.tag);
      return Object.keys(OO.attributes || []).forEach((function(KO) {
        XO.setAttribute(KO, OO.attributes[KO])
      })), (OO.children || []).forEach((function(OO) {
        XO.appendChild(FX(OO, {
          ceFn: pO
        }))
      })), XO
    }
    var VX = {
      replace: function(OO) {
        var KO = OO[0];
        if (KO.parentNode)
          if (OO[1].forEach((function(OO) {
              KO.parentNode.insertBefore(FX(OO), KO)
            })), null === KO.getAttribute(LK) && cp.keepOriginalSource) {
            var pO = IO.createComment(function(OO) {
              var KO = " ".concat(OO.outerHTML, " ");
              return "".concat(KO, "Font Awesome fontawesome.com ")
            }(KO));
            KO.parentNode.replaceChild(pO, KO)
          } else KO.remove()
      },
      nest: function(OO) {
        var KO = OO[0],
          pO = OO[1];
        if (~nK(KO).indexOf(cp.replacementClass)) return VX.replace(OO);
        var XO = new RegExp("".concat(cp.cssPrefix, "-.*"));
        if (delete pO[0].attributes.id, pO[0].attributes.class) {
          var bK = pO[0].attributes.class.split(" ").reduce((function(OO, KO) {
            return KO === cp.replacementClass || KO.match(XO) ? OO.toSvg.push(KO) : OO.toNode.push(KO), OO
          }), {
            toNode: [],
            toSvg: []
          });
          pO[0].attributes.class = bK.toSvg.join(" "), 0 === bK.toNode.length ? KO.removeAttribute("class") : KO.setAttribute("class", bK.toNode.join(" "))
        }
        var eO = pO.map((function(OO) {
          return Cp(OO)
        })).join("\n");
        KO.setAttribute(LK, ""), KO.innerHTML = eO
      }
    };

    function LX(OO) {
      OO()
    }

    function QX(OO, KO) {
      var pO = "function" === typeof KO ? KO : DX;
      if (0 === OO.length) pO();
      else {
        var XO = LX;
        "async" === cp.mutateApproach && (XO = NO.requestAnimationFrame || LX), XO((function() {
          var KO = !0 === cp.autoReplaceSvg ? VX.replace : VX[cp.autoReplaceSvg] || VX.replace,
            XO = hX("mutate");
          OO.map(KO), XO(), pO()
        }))
      }
    }
    var zb = !1;

    function AX() {
      zb = !0
    }

    function fX() {
      zb = !1
    }
    var dX = null;

    function TX(OO) {
      if (yK && cp.observeMutations) {
        var KO = OO.treeCallback,
          pO = void 0 === KO ? DX : KO,
          XO = OO.nodeCallback,
          bK = void 0 === XO ? DX : XO,
          eO = OO.pseudoElementsCallback,
          lO = void 0 === eO ? DX : eO,
          vK = OO.observeMutationsRoot,
          CO = void 0 === vK ? IO : vK;
        dX = new yK((function(OO) {
          if (!zb) {
            var KO = Yp();
            xp(OO).forEach((function(OO) {
              if ("childList" === OO.type && OO.addedNodes.length > 0 && !MX(OO.addedNodes[0]) && (cp.searchPseudoElements && lO(OO.target), pO(OO.target)), "attributes" === OO.type && OO.target.parentNode && cp.searchPseudoElements && lO([OO.target], !0), "attributes" === OO.type && MX(OO.target) && ~mp.indexOf(OO.attributeName))
                if ("class" === OO.attributeName && function(OO) {
                    var KO = OO.getAttribute ? OO.getAttribute(zp) : null,
                      pO = OO.getAttribute ? OO.getAttribute(AK) : null;
                    return KO && pO
                  }(OO.target)) {
                  var XO = Pp(nK(OO.target)),
                    eO = XO.prefix,
                    vK = XO.iconName;
                  OO.target.setAttribute(zp, eO || KO), vK && OO.target.setAttribute(AK, vK)
                } else(CO = OO.target) && CO.classList && CO.classList.contains && CO.classList.contains(cp.replacementClass) && bK(OO.target);
              var CO
            }))
          }
        })), uO && dX.observe(CO, {
          childList: !0,
          attributes: !0,
          characterData: !0,
          subtree: !0
        })
      }
    }

    function NX(OO) {
      var KO, pO, XO = OO.getAttribute("data-prefix"),
        bK = OO.getAttribute("data-icon"),
        eO = void 0 !== OO.innerText ? OO.innerText.trim() : "",
        lO = Pp(nK(OO));
      return lO.prefix || (lO.prefix = Yp()), XO && bK && (lO.prefix = XO, lO.iconName = bK), lO.iconName && lO.prefix || (lO.prefix && eO.length > 0 && (lO.iconName = (KO = lO.prefix, pO = OO.innerText, (fp[KO] || {})[pO] || upO(lO.prefix, Mp(OO.innerText)))), !lO.iconName && cp.autoFetchSvg && OO.firstChild && OO.firstChild.nodeType === Node.TEXT_NODE && (lO.iconName = OO.firstChild.data)), lO
    }

    function IX(OO) {
      var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
          styleParser: !0
        },
        pO = NX(OO),
        XO = pO.iconName,
        bK = pO.prefix,
        eO = pO.rest,
        lO = function(OO) {
          return xp(OO.attributes).reduce((function(OO, KO) {
            return "class" !== OO.name && "style" !== OO.name && (OO[KO.name] = KO.value), OO
          }), {})
        }(OO),
        vK = Bp("parseNodeAttributes", {}, OO),
        hO = KO.styleParser ? function(OO) {
          var KO = OO.getAttribute("style"),
            pO = [];
          return KO && (pO = KO.split(";").reduce((function(OO, KO) {
            var pO = KO.split(":"),
              XO = pO[0],
              bK = pO.slice(1);
            return XO && bK.length > 0 && (OO[XO] = bK.join(":").trim()), OO
          }), {})), pO
        }(OO) : [];
      return CO({
        iconName: XO,
        prefix: bK,
        transform: GK,
        mask: {
          iconName: null,
          prefix: null,
          rest: []
        },
        maskId: null,
        symbol: !1,
        extra: {
          classes: eO,
          styles: hO,
          attributes: lO
        }
      }, vK)
    }
    var yb = bX.styles;

    function gb(OO) {
      var KO = "nest" === cp.autoReplaceSvg ? IX(OO, {
        styleParser: !1
      }) : IX(OO);
      return ~KO.extra.classes.indexOf(rp) ? Gp("generateLayersText", OO, KO) : Gp("generateSvgReplacementMutation", OO, KO)
    }

    function uX(OO) {
      var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      if (!uO) return Promise.resolve();
      var pO = IO.documentElement.classList,
        XO = function(OO) {
          return pO.add("".concat(fK, "-").concat(OO))
        },
        bK = function(OO) {
          return pO.remove("".concat(fK, "-").concat(OO))
        },
        eO = cp.autoFetchSvg ? [].concat(DO(OK), DO(DK)) : YO.concat(Object.keys(yb));
      eO.includes("fa") || eO.push("fa");
      var lO = [".".concat(rp, ":not([").concat(LK, "])")].concat(eO.map((function(OO) {
        return ".".concat(OO, ":not([").concat(LK, "])")
      }))).join(", ");
      if (0 === lO.length) return Promise.resolve();
      var vK = [];
      try {
        vK = xp(OO.querySelectorAll(lO))
      } catch (MO) {}
      if (!(vK.length > 0)) return Promise.resolve();
      XO("pending"), bK("complete");
      var CO = hX("onTree"),
        hO = vK.reduce((function(OO, KO) {
          try {
            var pO = gb(KO);
            pO && OO.push(pO)
          } catch (MO) {
            NK || "MissingIcon" === MO.name && console.error(MO)
          }
          return OO
        }), []);
      return new Promise((function(OO, pO) {
        Promise.all(hO).then((function(pO) {
          QX(pO, (function() {
            XO("active"), XO("complete"), bK("pending"), "function" === typeof KO && KO(), CO(), OO()
          }))
        })).catch((function(OO) {
          CO(), pO(OO)
        }))
      }))
    }

    function EX(OO) {
      var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
      gb(OO).then((function(OO) {
        OO && QX([OO], KO)
      }))
    }
    var jb = function(OO) {
        var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          pO = KO.transform,
          XO = void 0 === pO ? GK : pO,
          bK = KO.symbol,
          eO = void 0 !== bK && bK,
          lO = KO.mask,
          vK = void 0 === lO ? null : lO,
          hO = KO.maskId,
          DO = void 0 === hO ? null : hO,
          MO = KO.classes,
          aK = void 0 === MO ? [] : MO,
          oO = KO.attributes,
          FO = void 0 === oO ? {} : oO,
          VO = KO.styles,
          LO = void 0 === VO ? {} : VO;
        if (OO) {
          var QO = OO.prefix,
            zK = OO.iconName,
            AO = OO.icon;
          return kX(CO({
            type: "icon"
          }, OO), (function() {
            return Zp("beforeDOMElementCreation", {
              iconDefinition: OO,
              params: KO
            }), Up({
              icons: {
                main: pX(AO),
                mask: vK ? pX(vK.icon) : {
                  found: !1,
                  width: null,
                  height: null,
                  icon: {}
                }
              },
              prefix: QO,
              iconName: zK,
              transform: CO(CO({}, GK), XO),
              symbol: eO,
              maskId: DO,
              extra: {
                attributes: FO,
                styles: LO,
                classes: aK
              }
            })
          }))
        }
      },
      YX = {
        mixout: function() {
          return {
            icon: (OO = jb, function(KO) {
              var pO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                XO = (KO || {}).icon ? KO : qX(KO || {}),
                bK = pO.mask;
              return bK && (bK = (bK || {}).icon ? bK : qX(bK || {})), OO(XO, CO(CO({}, pO), {}, {
                mask: bK
              }))
            })
          };
          var OO
        },
        hooks: function() {
          return {
            mutationObserverCallbacks: function(OO) {
              return OO.treeCallback = uX, OO.nodeCallback = EX, OO
            }
          }
        },
        provides: function(OO) {
          OO.i2svg = function(OO) {
            var KO = OO.node,
              pO = void 0 === KO ? IO : KO,
              XO = OO.callback;
            return uX(pO, void 0 === XO ? function() {} : XO)
          }, OO.generateSvgReplacementMutation = function(OO, KO) {
            var pO = KO.iconName,
              XO = KO.prefix,
              bK = KO.transform,
              eO = KO.symbol,
              lO = KO.mask,
              vK = KO.maskId,
              CO = KO.extra;
            return new Promise((function(KO, DO) {
              Promise.all([bb(pO, XO), lO.iconName ? bb(lO.iconName, lO.prefix) : Promise.resolve({
                found: !1,
                width: 512,
                height: 512,
                icon: {}
              })]).then((function(lO) {
                var DO = hO(lO, 2),
                  MO = DO[0],
                  aK = DO[1];
                KO([OO, Up({
                  icons: {
                    main: MO,
                    mask: aK
                  },
                  prefix: XO,
                  iconName: pO,
                  transform: bK,
                  symbol: eO,
                  maskId: vK,
                  extra: CO,
                  watchable: !0
                })])
              })).catch(DO)
            }))
          }, OO.generateAbstractIcon = function(OO) {
            var KO, pO = OO.children,
              XO = OO.attributes,
              bK = OO.main,
              eO = OO.transform,
              lO = tp(OO.styles);
            return lO.length > 0 && (XO.style = lO), kp(eO) && (KO = Gp("generateAbstractTransformGrouping", {
              main: bK,
              transform: eO,
              containerWidth: bK.width,
              iconWidth: bK.width
            })), pO.push(KO || bK.icon), {
              children: pO,
              attributes: XO
            }
          }
        }
      },
      wX = {
        mixout: function() {
          return {
            layer: function(OO) {
              var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                pO = KO.classes,
                XO = void 0 === pO ? [] : pO;
              return kX({
                type: "layer"
              }, (function() {
                Zp("beforeDOMElementCreation", {
                  assembler: OO,
                  params: KO
                });
                var pO = [];
                return OO((function(OO) {
                  Array.isArray(OO) ? OO.map((function(OO) {
                    pO = pO.concat(OO.abstract)
                  })) : pO = pO.concat(OO.abstract)
                })), [{
                  tag: "span",
                  attributes: {
                    class: ["".concat(cp.cssPrefix, "-layers")].concat(DO(XO)).join(" ")
                  },
                  children: pO
                }]
              }))
            }
          }
        }
      },
      ib = {
        mixout: function() {
          return {
            counter: function(OO) {
              var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                pO = KO.title,
                XO = void 0 === pO ? null : pO,
                bK = KO.classes,
                eO = void 0 === bK ? [] : bK,
                lO = KO.attributes,
                vK = void 0 === lO ? {} : lO,
                hO = KO.styles,
                MO = void 0 === hO ? {} : hO;
              return kX({
                type: "counter",
                content: OO
              }, (function() {
                return Zp("beforeDOMElementCreation", {
                    content: OO,
                    params: KO
                  }),
                  function(OO) {
                    var KO = OO.content,
                      pO = OO.extra,
                      XO = CO(CO({}, pO.attributes), {}, {
                        class: pO.classes.join(" ")
                      }),
                      bK = tp(pO.styles);
                    bK.length > 0 && (XO.style = bK);
                    var eO = [];
                    return eO.push({
                      tag: "span",
                      attributes: XO,
                      children: [KO]
                    }), eO
                  }({
                    content: OO.toString(),
                    title: XO,
                    extra: {
                      attributes: vK,
                      styles: MO,
                      classes: ["".concat(cp.cssPrefix, "-layers-counter")].concat(DO(eO))
                    }
                  })
              }))
            }
          }
        }
      },
      rb = {
        mixout: function() {
          return {
            text: function(OO) {
              var KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                pO = KO.transform,
                XO = void 0 === pO ? GK : pO,
                bK = KO.classes,
                eO = void 0 === bK ? [] : bK,
                lO = KO.attributes,
                vK = void 0 === lO ? {} : lO,
                hO = KO.styles,
                MO = void 0 === hO ? {} : hO;
              return kX({
                type: "text",
                content: OO
              }, (function() {
                return Zp("beforeDOMElementCreation", {
                  content: OO,
                  params: KO
                }), OX({
                  content: OO,
                  transform: CO(CO({}, GK), XO),
                  extra: {
                    attributes: vK,
                    styles: MO,
                    classes: ["".concat(cp.cssPrefix, "-layers-text")].concat(DO(eO))
                  }
                })
              }))
            }
          }
        },
        provides: function(OO) {
          OO.generateLayersText = function(OO, KO) {
            var pO = KO.transform,
              XO = KO.extra,
              bK = null,
              eO = null;
            if (EO) {
              var lO = parseInt(getComputedStyle(OO).fontSize, 10),
                vK = OO.getBoundingClientRect();
              bK = vK.width / lO, eO = vK.height / lO
            }
            return Promise.resolve([OO, OX({
              content: OO.innerHTML,
              width: bK,
              height: eO,
              transform: pO,
              extra: XO,
              watchable: !0
            })])
          }
        }
      },
      PX = new RegExp('"', "ug"),
      mb = [1105920, 1112319],
      sX = CO(CO(CO(CO({}, {
        FontAwesome: {
          normal: "fas",
          400: "fas"
        }
      }), {
        "Font Awesome 7 Free": {
          900: "fas",
          400: "far"
        },
        "Font Awesome 7 Pro": {
          900: "fas",
          400: "far",
          normal: "far",
          300: "fal",
          100: "fat"
        },
        "Font Awesome 7 Brands": {
          400: "fab",
          normal: "fab"
        },
        "Font Awesome 7 Duotone": {
          900: "fad",
          400: "fadr",
          normal: "fadr",
          300: "fadl",
          100: "fadt"
        },
        "Font Awesome 7 Sharp": {
          900: "fass",
          400: "fasr",
          normal: "fasr",
          300: "fasl",
          100: "fast"
        },
        "Font Awesome 7 Sharp Duotone": {
          900: "fasds",
          400: "fasdr",
          normal: "fasdr",
          300: "fasdl",
          100: "fasdt"
        },
        "Font Awesome 7 Jelly": {
          400: "fajr",
          normal: "fajr"
        },
        "Font Awesome 7 Jelly Fill": {
          400: "fajfr",
          normal: "fajfr"
        },
        "Font Awesome 7 Jelly Duo": {
          400: "fajdr",
          normal: "fajdr"
        },
        "Font Awesome 7 Slab": {
          400: "faslr",
          normal: "faslr"
        },
        "Font Awesome 7 Slab Press": {
          400: "faslpr",
          normal: "faslpr"
        },
        "Font Awesome 7 Thumbprint": {
          300: "fatl",
          normal: "fatl"
        },
        "Font Awesome 7 Notdog": {
          900: "fans",
          normal: "fans"
        },
        "Font Awesome 7 Notdog Duo": {
          900: "fands",
          normal: "fands"
        },
        "Font Awesome 7 Etch": {
          900: "faes",
          normal: "faes"
        },
        "Font Awesome 7 Graphite": {
          100: "fagt",
          normal: "fagt"
        },
        "Font Awesome 7 Chisel": {
          400: "facr",
          normal: "facr"
        },
        "Font Awesome 7 Whiteboard": {
          600: "fawsb",
          normal: "fawsb"
        },
        "Font Awesome 7 Utility": {
          600: "fausb",
          normal: "fausb"
        },
        "Font Awesome 7 Utility Duo": {
          600: "faudsb",
          normal: "faudsb"
        },
        "Font Awesome 7 Utility Fill": {
          600: "faufsb",
          normal: "faufsb"
        }
      }), {
        "Font Awesome 5 Free": {
          900: "fas",
          400: "far"
        },
        "Font Awesome 5 Pro": {
          900: "fas",
          400: "far",
          normal: "far",
          300: "fal"
        },
        "Font Awesome 5 Brands": {
          400: "fab",
          normal: "fab"
        },
        "Font Awesome 5 Duotone": {
          900: "fad"
        }
      }), {
        "Font Awesome Kit": {
          400: "fak",
          normal: "fak"
        },
        "Font Awesome Kit Duotone": {
          400: "fakd",
          normal: "fakd"
        }
      }),
      HX = Object.keys(sX).reduce((function(OO, KO) {
        return OO[KO.toLowerCase()] = sX[KO], OO
      }), {}),
      RX = Object.keys(HX).reduce((function(OO, KO) {
        var pO = HX[KO];
        return OO[KO] = pO[900] || DO(Object.entries(pO))[0][1], OO
      }), {});

    function SX(OO, KO) {
      var pO = "".concat("data-fa-pseudo-element-pending").concat(KO.replace(":", "-"));
      return new Promise((function(XO, bK) {
        if (null !== OO.getAttribute(pO)) return XO();
        var eO = xp(OO.children).filter((function(OO) {
            return OO.getAttribute(QK) === KO
          }))[0],
          lO = NO.getComputedStyle(OO, KO),
          vK = lO.getPropertyValue("font-family"),
          hO = vK.match(PK),
          MO = lO.getPropertyValue("font-weight"),
          aK = lO.getPropertyValue("content");
        if (eO && !hO) return OO.removeChild(eO), XO();
        if (hO && "none" !== aK && "" !== aK) {
          var oO = lO.getPropertyValue("content"),
            FO = function(OO, KO) {
              var pO = OO.replace(/^['"]|['"]$/g, "").toLowerCase(),
                XO = parseInt(KO),
                bK = isNaN(XO) ? "normal" : XO;
              return (HX[pO] || {})[bK] || RX[pO]
            }(vK, MO),
            VO = function(OO) {
              return Mp(DO(OO.replace(PX, ""))[0] || "")
            }(oO),
            LO = hO[0].startsWith("FontAwesome"),
            QO = function(OO) {
              var KO = OO.getPropertyValue("font-feature-settings").includes("ss01"),
                pO = OO.getPropertyValue("content").replace(PX, ""),
                XO = pO.codePointAt(0),
                bK = XO >= mb[0] && XO <= mb[1],
                eO = 2 === pO.length && pO[0] === pO[1];
              return bK || eO || KO
            }(lO),
            zK = upO(FO, VO),
            AO = zK;
          if (LO) {
            var fO = function(OO) {
              var KO = Tp[OO],
                pO = upO("fas", OO);
              return KO || (pO ? {
                prefix: "fas",
                iconName: pO
              } : null) || {
                prefix: null,
                iconName: null
              }
            }(VO);
            fO.iconName && fO.prefix && (zK = fO.iconName, FO = fO.prefix)
          }
          if (!zK || QO || eO && eO.getAttribute(zp) === FO && eO.getAttribute(AK) === AO) XO();
          else {
            OO.setAttribute(pO, AO), eO && OO.removeChild(eO);
            var dO = {
                iconName: null,
                prefix: null,
                transform: GK,
                symbol: !1,
                mask: {
                  iconName: null,
                  prefix: null,
                  rest: []
                },
                maskId: null,
                extra: {
                  classes: [],
                  styles: {},
                  attributes: {}
                }
              },
              TO = dO.extra;
            TO.attributes[QK] = KO, bb(zK, FO).then((function(bK) {
              var eO = Up(CO(CO({}, dO), {}, {
                  icons: {
                    main: bK,
                    mask: {
                      prefix: null,
                      iconName: null,
                      rest: []
                    }
                  },
                  prefix: FO,
                  iconName: AO,
                  extra: TO,
                  watchable: !0
                })),
                lO = IO.createElementNS("http://www.w3.org/2000/svg", "svg");
              "::before" === KO ? OO.insertBefore(lO, OO.firstChild) : OO.appendChild(lO), lO.outerHTML = eO.map((function(OO) {
                return Cp(OO)
              })).join("\n"), OO.removeAttribute(pO), XO()
            })).catch(bK)
          }
        } else XO()
      }))
    }

    function JX(OO) {
      return Promise.all([SX(OO, "::before"), SX(OO, "::after")])
    }

    function cb(OO) {
      return OO.parentNode !== document.head && !~dK.indexOf(OO.tagName.toUpperCase()) && !OO.getAttribute(QK) && (!OO.parentNode || "svg" !== OO.parentNode.tagName)
    }
    var BX = function(OO) {
        return !!OO && TK.some((function(KO) {
          return OO.includes(KO)
        }))
      },
      ZX = function(OO) {
        if (!OO) return [];
        var KO = new Set,
          pO = OO.split(/,(?![^()]*\))/).map((function(OO) {
            return OO.trim()
          }));
        pO = pO.flatMap((function(OO) {
          return OO.includes("(") ? OO : OO.split(",").map((function(OO) {
            return OO.trim()
          }))
        }));
        var XO, bK = eO(pO);
        try {
          for (bK.s(); !(XO = bK.n()).done;) {
            var lO = XO.value;
            if (BX(lO)) {
              var vK = TK.reduce((function(OO, KO) {
                return OO.replace(KO, "")
              }), lO);
              "" !== vK && "*" !== vK && KO.add(vK)
            }
          }
        } catch (CO) {
          bK.e(CO)
        } finally {
          bK.f()
        }
        return KO
      };

    function GX(OO) {
      if (uO) {
        var KO;
        if (arguments.length > 1 && void 0 !== arguments[1] && arguments[1]) KO = OO;
        else if (cp.searchPseudoElementsFullScan) KO = OO.querySelectorAll("*");
        else {
          var pO, XO = new Set,
            bK = eO(document.styleSheets);
          try {
            for (bK.s(); !(pO = bK.n()).done;) {
              var lO = pO.value;
              try {
                var vK, CO = eO(lO.cssRules);
                try {
                  for (CO.s(); !(vK = CO.n()).done;) {
                    var hO, DO = vK.value,
                      MO = eO(ZX(DO.selectorText));
                    try {
                      for (MO.s(); !(hO = MO.n()).done;) {
                        var aK = hO.value;
                        XO.add(aK)
                      }
                    } catch (FO) {
                      MO.e(FO)
                    } finally {
                      MO.f()
                    }
                  }
                } catch (FO) {
                  CO.e(FO)
                } finally {
                  CO.f()
                }
              } catch (VO) {
                cp.searchPseudoElementsWarnings && console.warn("Font Awesome: cannot parse stylesheet: ".concat(lO.href, " (").concat(VO.message, ')\nIf it declares any Font Awesome CSS pseudo-elements, they will not be rendered as SVG icons. Add crossorigin="anonymous" to the <link>, enable searchPseudoElementsFullScan for slower but more thorough DOM parsing, or suppress this warning by setting searchPseudoElementsWarnings to false.'))
              }
            }
          } catch (FO) {
            bK.e(FO)
          } finally {
            bK.f()
          }
          if (!XO.size) return;
          var oO = Array.from(XO).join(", ");
          try {
            KO = OO.querySelectorAll(oO)
          } catch (LO) {}
        }
        return new Promise((function(OO, pO) {
          var XO = xp(KO).filter(cb).map(JX),
            bK = hX("searchPseudoElements");
          AX(), Promise.all(XO).then((function() {
            bK(), fX(), OO()
          })).catch((function() {
            bK(), fX(), pO()
          }))
        }))
      }
    }
    var qb = {
        hooks: function() {
          return {
            mutationObserverCallbacks: function(OO) {
              return OO.pseudoElementsCallback = GX, OO
            }
          }
        },
        provides: function(OO) {
          OO.pseudoElements2svg = function(OO) {
            var KO = OO.node,
              pO = void 0 === KO ? IO : KO;
            cp.searchPseudoElements && GX(pO)
          }
        }
      },
      xb = !1,
      nX = function(OO) {
        return OO.toLowerCase().split(" ").reduce((function(OO, KO) {
          var pO = KO.toLowerCase().split("-"),
            XO = pO[0],
            bK = pO.slice(1).join("-");
          if (XO && "h" === bK) return OO.flipX = !0, OO;
          if (XO && "v" === bK) return OO.flipY = !0, OO;
          if (bK = parseFloat(bK), isNaN(bK)) return OO;
          switch (XO) {
            case "grow":
              OO.size = OO.size + bK;
              break;
            case "shrink":
              OO.size = OO.size - bK;
              break;
            case "left":
              OO.x = OO.x - bK;
              break;
            case "right":
              OO.x = OO.x + bK;
              break;
            case "up":
              OO.y = OO.y - bK;
              break;
            case "down":
              OO.y = OO.y + bK;
              break;
            case "rotate":
              OO.rotate = OO.rotate + bK
          }
          return OO
        }), {
          size: 16,
          x: 0,
          y: 0,
          flipX: !1,
          flipY: !1,
          rotate: 0
        })
      },
      WX = {
        mixout: function() {
          return {
            parse: {
              transform: function(OO) {
                return nX(OO)
              }
            }
          }
        },
        hooks: function() {
          return {
            parseNodeAttributes: function(OO, KO) {
              var pO = KO.getAttribute("data-fa-transform");
              return pO && (OO.transform = nX(pO)), OO
            }
          }
        },
        provides: function(OO) {
          OO.generateAbstractTransformGrouping = function(OO) {
            var KO = OO.main,
              pO = OO.transform,
              XO = OO.containerWidth,
              bK = OO.iconWidth,
              eO = {
                transform: "translate(".concat(XO / 2, " 256)")
              },
              lO = "translate(".concat(32 * pO.x, ", ").concat(32 * pO.y, ") "),
              vK = "scale(".concat(pO.size / 16 * (pO.flipX ? -1 : 1), ", ").concat(pO.size / 16 * (pO.flipY ? -1 : 1), ") "),
              hO = "rotate(".concat(pO.rotate, " 0 0)"),
              DO = {
                outer: eO,
                inner: {
                  transform: "".concat(lO, " ").concat(vK, " ").concat(hO)
                },
                path: {
                  transform: "translate(".concat(bK / 2 * -1, " -256)")
                }
              };
            return {
              tag: "g",
              attributes: CO({}, DO.outer),
              children: [{
                tag: "g",
                attributes: CO({}, DO.inner),
                children: [{
                  tag: KO.icon.tag,
                  children: KO.icon.children,
                  attributes: CO(CO({}, KO.icon.attributes), DO.path)
                }]
              }]
            }
          }
        }
      },
      tb = {
        x: 0,
        y: 0,
        width: "100%",
        height: "100%"
      };

    function kb(OO) {
      var KO = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
      return OO.attributes && (OO.attributes.fill || KO) && (OO.attributes.fill = "black"), OO
    }
    var UX = {
        hooks: function() {
          return {
            parseNodeAttributes: function(OO, KO) {
              var pO = KO.getAttribute("data-fa-mask"),
                XO = pO ? Pp(pO.split(" ").map((function(OO) {
                  return OO.trim()
                }))) : {
                  prefix: null,
                  iconName: null,
                  rest: []
                };
              return XO.prefix || (XO.prefix = Yp()), OO.mask = XO, OO.maskId = KO.getAttribute("data-fa-mask-id"), OO
            }
          }
        },
        provides: function(OO) {
          OO.generateAbstractMask = function(OO) {
            var KO, pO = OO.children,
              XO = OO.attributes,
              bK = OO.main,
              eO = OO.mask,
              lO = OO.maskId,
              vK = OO.transform,
              hO = bK.width,
              DO = bK.icon,
              MO = eO.width,
              aK = eO.icon,
              oO = function(OO) {
                var KO = OO.transform,
                  pO = OO.containerWidth,
                  XO = OO.iconWidth,
                  bK = {
                    transform: "translate(".concat(pO / 2, " 256)")
                  },
                  eO = "translate(".concat(32 * KO.x, ", ").concat(32 * KO.y, ") "),
                  lO = "scale(".concat(KO.size / 16 * (KO.flipX ? -1 : 1), ", ").concat(KO.size / 16 * (KO.flipY ? -1 : 1), ") "),
                  vK = "rotate(".concat(KO.rotate, " 0 0)");
                return {
                  outer: bK,
                  inner: {
                    transform: "".concat(eO, " ").concat(lO, " ").concat(vK)
                  },
                  path: {
                    transform: "translate(".concat(XO / 2 * -1, " -256)")
                  }
                }
              }({
                transform: vK,
                containerWidth: MO,
                iconWidth: hO
              }),
              FO = {
                tag: "rect",
                attributes: CO(CO({}, tb), {}, {
                  fill: "white"
                })
              },
              VO = DO.children ? {
                children: DO.children.map(kb)
              } : {},
              LO = {
                tag: "g",
                attributes: CO({}, oO.inner),
                children: [kb(CO({
                  tag: DO.tag,
                  attributes: CO(CO({}, DO.attributes), oO.path)
                }, VO))]
              },
              QO = {
                tag: "g",
                attributes: CO({}, oO.outer),
                children: [LO]
              },
              zK = "mask-".concat(lO || qp()),
              AO = "clip-".concat(lO || qp()),
              fO = {
                tag: "mask",
                attributes: CO(CO({}, tb), {}, {
                  id: zK,
                  maskUnits: "userSpaceOnUse",
                  maskContentUnits: "userSpaceOnUse"
                }),
                children: [FO, QO]
              },
              dO = {
                tag: "defs",
                children: [{
                  tag: "clipPath",
                  attributes: {
                    id: AO
                  },
                  children: (KO = aK, "g" === KO.tag ? KO.children : [KO])
                }, fO]
              };
            return pO.push(dO, {
              tag: "rect",
              attributes: CO({
                fill: "currentColor",
                "clip-path": "url(#".concat(AO, ")"),
                mask: "url(#".concat(zK, ")")
              }, tb)
            }), {
              children: pO,
              attributes: XO
            }
          }
        }
      },
      Ob = {
        provides: function(OO) {
          var KO = !1;
          NO.matchMedia && (KO = NO.matchMedia("(prefers-reduced-motion: reduce)").matches), OO.missingIconAbstract = function() {
            var OO = [],
              pO = {
                fill: "currentColor"
              },
              XO = {
                attributeType: "XML",
                repeatCount: "indefinite",
                dur: "2s"
              };
            OO.push({
              tag: "path",
              attributes: CO(CO({}, pO), {}, {
                d: "M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"
              })
            });
            var bK = CO(CO({}, XO), {}, {
                attributeName: "opacity"
              }),
              eO = {
                tag: "circle",
                attributes: CO(CO({}, pO), {}, {
                  cx: "256",
                  cy: "364",
                  r: "28"
                }),
                children: []
              };
            return KO || eO.children.push({
              tag: "animate",
              attributes: CO(CO({}, XO), {}, {
                attributeName: "r",
                values: "28;14;28;28;14;28;"
              })
            }, {
              tag: "animate",
              attributes: CO(CO({}, bK), {}, {
                values: "1;0;1;1;0;1;"
              })
            }), OO.push(eO), OO.push({
              tag: "path",
              attributes: CO(CO({}, pO), {}, {
                opacity: "1",
                d: "M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"
              }),
              children: KO ? [] : [{
                tag: "animate",
                attributes: CO(CO({}, bK), {}, {
                  values: "1;0;0;0;0;1;"
                })
              }]
            }), KO || OO.push({
              tag: "path",
              attributes: CO(CO({}, pO), {}, {
                opacity: "0",
                d: "M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"
              }),
              children: [{
                tag: "animate",
                attributes: CO(CO({}, bK), {}, {
                  values: "0;0;1;1;0;0;"
                })
              }]
            }), {
              tag: "g",
              attributes: {
                class: "missing"
              },
              children: OO
            }
          }
        }
      };
    ! function(OO, KO) {
      var pO = KO.mixoutsTo;
      Rp = OO, Sp = {}, Object.keys(Jp).forEach((function(OO) {
        -1 === cX.indexOf(OO) && delete Jp[OO]
      })), Rp.forEach((function(OO) {
        var KO = OO.mixout ? OO.mixout() : {};
        if (Object.keys(KO).forEach((function(OO) {
            "function" === typeof KO[OO] && (pO[OO] = KO[OO]), "object" === aK(KO[OO]) && Object.keys(KO[OO]).forEach((function(XO) {
              pO[OO] || (pO[OO] = {}), pO[OO][XO] = KO[OO][XO]
            }))
          })), OO.hooks) {
          var XO = OO.hooks();
          Object.keys(XO).forEach((function(OO) {
            Sp[OO] || (Sp[OO] = []), Sp[OO].push(XO[OO])
          }))
        }
        OO.provides && OO.provides(Jp)
      }))
    }([pp, YX, wX, ib, rb, qb, {
      mixout: function() {
        return {
          dom: {
            unwatch: function() {
              AX(), xb = !0
            }
          }
        }
      },
      hooks: function() {
        return {
          bootstrap: function() {
            TX(Bp("mutationObserverCallbacks", {}))
          },
          noAuto: function() {
            dX && dX.disconnect()
          },
          watch: function(OO) {
            var KO = OO.observeMutationsRoot;
            xb ? fX() : TX(Bp("mutationObserverCallbacks", {
              observeMutationsRoot: KO
            }))
          }
        }
      }
    }, WX, UX, Ob, {
      hooks: function() {
        return {
          parseNodeAttributes: function(OO, KO) {
            var pO = KO.getAttribute("data-fa-symbol"),
              XO = null !== pO && ("" === pO || pO);
            return OO.symbol = XO, OO
          }
        }
      }
    }], {
      mixoutsTo: Wp
    });
    var Kb = Wp.noAuto,
      pb = Wp.config,
      Xb = Wp.library,
      be = Wp.dom,
      eb = Wp.parse,
      lb = Wp.findIconDefinition,
      ve = Wp.toHtml,
      Cb = Wp.icon,
      hb = Wp.layer,
      Db = Wp.text,
      Mb = Wp.counter
  },
  5827: OO => {
    OO.exports = JSON.parse('{"description":"The iconic font, CSS, and SVG framework","keywords":["font","awesome","fontawesome","icon","svg","bootstrap"],"homepage":"https://fontawesome.com","bugs":{"url":"https://github.com/FortAwesome/Font-Awesome/issues"},"author":"The Font Awesome Team (https://github.com/orgs/FortAwesome/people)","repository":{"type":"git","url":"https://github.com/FortAwesome/Font-Awesome"},"engines":{"node":">=6"},"dependencies":{"@fortawesome/fontawesome-common-types":"7.2.0"},"version":"7.2.0","name":"@fortawesome/fontawesome-svg-core","main":"index.js","module":"index.mjs","jsnext:main":"index.mjs","style":"styles.css","license":"MIT","types":"./index.d.ts","exports":{".":{"types":"./index.d.ts","module":"./index.mjs","import":"./index.mjs","require":"./index.js","style":"./styles.css","default":"./index.js"},"./index":{"types":"./index.d.ts","module":"./index.mjs","import":"./index.mjs","require":"./index.js","default":"./index.js"},"./index.js":{"types":"./index.d.ts","module":"./index.mjs","import":"./index.mjs","require":"./index.js","default":"./index.js"},"./plugins":{"types":"./index.d.ts","module":"./plugins.mjs","import":"./plugins.mjs","default":"./plugins.mjs"},"./import.macro":"./import.macro.js","./import.macro.js":"./import.macro.js","./styles":"./styles.css","./styles.css":"./styles.css","./package.json":"./package.json"},"sideEffects":["./index.js","./index.mjs","./styles.css"]}')
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);