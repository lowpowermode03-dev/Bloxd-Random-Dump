/*! For license information please see vjxd5n.211.39fc0a17.chunk.js.LICENSE.txt */
export const id = 211;
export const ids = [211, 217];
export const modules = {
  36689: OO => {
    OO.exports = function(OO) {
      return null != OO && null != OO.constructor && "function" === typeof OO.constructor.isBuffer && OO.constructor.isBuffer(OO)
    }
  },
  36674: (OO, KO, pO) => {
    var XO = pO(36679),
      bK = pO(36682),
      eO = pO(36689);
    pO.g.__TYPEDARRAY_POOL || (pO.g.__TYPEDARRAY_POOL = {
      UINT8: bK([32, 0]),
      UINT16: bK([32, 0]),
      UINT32: bK([32, 0]),
      INT8: bK([32, 0]),
      INT16: bK([32, 0]),
      INT32: bK([32, 0]),
      FLOAT: bK([32, 0]),
      DOUBLE: bK([32, 0]),
      DATA: bK([32, 0]),
      UINT8C: bK([32, 0]),
      BUFFER: bK([32, 0])
    });
    var lO = "undefined" !== typeof Uint8ClampedArray,
      vK = pO.g.__TYPEDARRAY_POOL;
    vK.UINT8C || (vK.UINT8C = bK([32, 0])), vK.BUFFER || (vK.BUFFER = bK([32, 0]));
    var CO = vK.DATA,
      hO = vK.BUFFER;

    function DO(OO) {
      if (OO) {
        var KO = OO.length || OO.byteLength,
          pO = XO.log2(KO);
        CO[pO].push(OO)
      }
    }

    function MO(OO) {
      OO = XO.nextPow2(OO);
      var KO = XO.log2(OO),
        pO = CO[KO];
      return pO.length > 0 ? pO.pop() : new ArrayBuffer(OO)
    }

    function aK(OO) {
      return new Uint8Array(MO(OO), 0, OO)
    }

    function oO(OO) {
      return new Uint16Array(MO(2 * OO), 0, OO)
    }

    function FO(OO) {
      return new Uint32Array(MO(4 * OO), 0, OO)
    }

    function VO(OO) {
      return new Int8Array(MO(OO), 0, OO)
    }

    function LO(OO) {
      return new Int16Array(MO(2 * OO), 0, OO)
    }

    function QO(OO) {
      return new Int32Array(MO(4 * OO), 0, OO)
    }

    function zK(OO) {
      return new Float32Array(MO(4 * OO), 0, OO)
    }

    function AO(OO) {
      return new Float64Array(MO(8 * OO), 0, OO)
    }

    function fO(OO) {
      return lO ? new Uint8ClampedArray(MO(OO), 0, OO) : aK(OO)
    }

    function dO(OO) {
      return new DataView(MO(OO), 0, OO)
    }
    KO.free = function(OO) {
      if (eO(OO)) hO[XO.log2(OO.length)].push(OO);
      else {
        if ("[object ArrayBuffer]" !== Object.prototype.toString.call(OO) && (OO = OO.buffer), !OO) return;
        var KO = OO.length || OO.byteLength,
          pO = 0 | XO.log2(KO);
        CO[pO].push(OO)
      }
    }, KO.freeUint8 = KO.freeUint16 = KO.freeUint32 = KO.freeInt8 = KO.freeInt16 = KO.freeInt32 = KO.freeFloat32 = KO.freeFloat = KO.freeFloat64 = KO.freeDouble = KO.freeUint8Clamped = KO.freeDataView = function(OO) {
      DO(OO.buffer)
    }, KO.freeArrayBuffer = DO, KO.freeBuffer = function(OO) {
      hO[XO.log2(OO.length)].push(OO)
    }, KO.malloc = function(OO, KO) {
      if (void 0 === KO || "arraybuffer" === KO) return MO(OO);
      switch (KO) {
        case "uint8":
          return aK(OO);
        case "uint16":
          return oO(OO);
        case "uint32":
          return FO(OO);
        case "int8":
          return VO(OO);
        case "int16":
          return LO(OO);
        case "int32":
          return QO(OO);
        case "float":
        case "float32":
          return zK(OO);
        case "double":
        case "float64":
          return AO(OO);
        case "uint8_clamped":
          return fO(OO);
        case "buffer":
          throw "Buffer not supported";
        case "data":
        case "dataview":
          return dO(OO);
        default:
          return null
      }
      return null
    }, KO.mallocArrayBuffer = MO, KO.mallocUint8 = aK, KO.mallocUint16 = oO, KO.mallocUint32 = FO, KO.mallocInt8 = VO, KO.mallocInt16 = LO, KO.mallocInt32 = QO, KO.mallocFloat32 = KO.mallocFloat = zK, KO.mallocFloat64 = KO.mallocDouble = AO, KO.mallocUint8Clamped = fO, KO.mallocDataView = dO, KO.clearCache = function() {
      for (var OO = 0; OO < 32; ++OO) vK.UINT8[OO].length = 0, vK.UINT16[OO].length = 0, vK.UINT32[OO].length = 0, vK.INT8[OO].length = 0, vK.INT16[OO].length = 0, vK.INT32[OO].length = 0, vK.FLOAT[OO].length = 0, vK.DOUBLE[OO].length = 0, vK.UINT8C[OO].length = 0, CO[OO].length = 0, hO[OO].length = 0
    }
  },
  36679: (OO, KO) => {
    function pO(OO) {
      var KO = 32;
      return (OO &= -OO) && KO--, 65535 & OO && (KO -= 16), 16711935 & OO && (KO -= 8), 252645135 & OO && (KO -= 4), 858993459 & OO && (KO -= 2), 1431655765 & OO && (KO -= 1), KO
    }
    KO.INT_BITS = 32, KO.INT_MAX = 2147483647, KO.INT_MIN = -1 << 31, KO.sign = function(OO) {
      return (OO > 0) - (OO < 0)
    }, KO.abs = function(OO) {
      var KO = OO >> 31;
      return (OO ^ KO) - KO
    }, KO.min = function(OO, KO) {
      return KO ^ (OO ^ KO) & -(OO < KO)
    }, KO.max = function(OO, KO) {
      return OO ^ (OO ^ KO) & -(OO < KO)
    }, KO.isPow2 = function(OO) {
      return !(OO & OO - 1) && !!OO
    }, KO.log2 = function(OO) {
      var KO, pO;
      return KO = (OO > 65535) << 4, KO |= pO = ((OO >>>= KO) > 255) << 3, KO |= pO = ((OO >>>= pO) > 15) << 2, (KO |= pO = ((OO >>>= pO) > 3) << 1) | (OO >>>= pO) >> 1
    }, KO.log10 = function(OO) {
      return OO >= 1e9 ? 9 : OO >= 1e8 ? 8 : OO >= 1e7 ? 7 : OO >= 1e6 ? 6 : OO >= 1e5 ? 5 : OO >= 1e4 ? 4 : OO >= 1e3 ? 3 : OO >= 100 ? 2 : OO >= 10 ? 1 : 0
    }, KO.popCount = function(OO) {
      return 16843009 * ((OO = (858993459 & (OO -= OO >>> 1 & 1431655765)) + (OO >>> 2 & 858993459)) + (OO >>> 4) & 252645135) >>> 24
    }, KO.countTrailingZeros = pO, KO.nextPow2 = function(OO) {
      return OO += 0 === OO, --OO, OO |= OO >>> 1, OO |= OO >>> 2, OO |= OO >>> 4, OO |= OO >>> 8, (OO |= OO >>> 16) + 1
    }, KO.prevPow2 = function(OO) {
      return OO |= OO >>> 1, OO |= OO >>> 2, OO |= OO >>> 4, OO |= OO >>> 8, (OO |= OO >>> 16) - (OO >>> 1)
    }, KO.parity = function(OO) {
      return OO ^= OO >>> 16, OO ^= OO >>> 8, OO ^= OO >>> 4, 27030 >>> (OO &= 15) & 1
    };
    var XO = new Array(256);
    ! function(OO) {
      for (var KO = 0; KO < 256; ++KO) {
        var pO = KO,
          XO = KO,
          bK = 7;
        for (pO >>>= 1; pO; pO >>>= 1) XO <<= 1, XO |= 1 & pO, --bK;
        OO[KO] = XO << bK & 255
      }
    }(XO), KO.reverse = function(OO) {
      return XO[255 & OO] << 24 | XO[OO >>> 8 & 255] << 16 | XO[OO >>> 16 & 255] << 8 | XO[OO >>> 24 & 255]
    }, KO.interleave2 = function(OO, KO) {
      return (OO = 1431655765 & ((OO = 858993459 & ((OO = 252645135 & ((OO = 16711935 & ((OO &= 65535) | OO << 8)) | OO << 4)) | OO << 2)) | OO << 1)) | (KO = 1431655765 & ((KO = 858993459 & ((KO = 252645135 & ((KO = 16711935 & ((KO &= 65535) | KO << 8)) | KO << 4)) | KO << 2)) | KO << 1)) << 1
    }, KO.deinterleave2 = function(OO, KO) {
      return (OO = 65535 & ((OO = 16711935 & ((OO = 252645135 & ((OO = 858993459 & ((OO = OO >>> KO & 1431655765) | OO >>> 1)) | OO >>> 2)) | OO >>> 4)) | OO >>> 16)) << 16 >> 16
    }, KO.interleave3 = function(OO, KO, pO) {
      return OO = 1227133513 & ((OO = 3272356035 & ((OO = 251719695 & ((OO = 4278190335 & ((OO &= 1023) | OO << 16)) | OO << 8)) | OO << 4)) | OO << 2), (OO |= (KO = 1227133513 & ((KO = 3272356035 & ((KO = 251719695 & ((KO = 4278190335 & ((KO &= 1023) | KO << 16)) | KO << 8)) | KO << 4)) | KO << 2)) << 1) | (pO = 1227133513 & ((pO = 3272356035 & ((pO = 251719695 & ((pO = 4278190335 & ((pO &= 1023) | pO << 16)) | pO << 8)) | pO << 4)) | pO << 2)) << 2
    }, KO.deinterleave3 = function(OO, KO) {
      return (OO = 1023 & ((OO = 4278190335 & ((OO = 251719695 & ((OO = 3272356035 & ((OO = OO >>> KO & 1227133513) | OO >>> 2)) | OO >>> 4)) | OO >>> 8)) | OO >>> 16)) << 22 >> 22
    }, KO.nextCombination = function(OO) {
      var KO = OO | OO - 1;
      return KO + 1 | (~KO & -~KO) - 1 >>> pO(OO) + 1
    }
  },
  36669: (OO, KO, pO) => {
    OO.exports = function(OO, KO, pO) {
      switch (arguments.length) {
        case 1:
          return XO = [], hO(bK = OO, bK, DO, !0), XO;
        case 2:
          return "function" === typeof KO ? hO(OO, OO, KO, !0) : function(OO, KO) {
            return XO = [], hO(OO, KO, DO, !1), XO
          }(OO, KO);
        case 3:
          return hO(OO, KO, pO, !1);
        default:
          throw new Error("box-intersect: Invalid arguments")
      }
      var bK
    };
    var XO, bK = pO(36674),
      eO = pO(36693),
      lO = pO(36703);

    function vK(OO, KO) {
      for (var pO = 0; pO < OO; ++pO)
        if (!(KO[pO] <= KO[pO + OO])) return !0;
      return !1
    }

    function CO(OO, KO, pO, XO) {
      for (var bK = 0, eO = 0, lO = 0, CO = OO.length; lO < CO; ++lO) {
        var hO = OO[lO];
        if (!vK(KO, hO)) {
          for (var DO = 0; DO < 2 * KO; ++DO) pO[bK++] = hO[DO];
          XO[eO++] = lO
        }
      }
      return eO
    }

    function hO(OO, KO, pO, XO) {
      var vK = OO.length,
        hO = KO.length;
      if (!(vK <= 0 || hO <= 0)) {
        var DO = OO[0].length >>> 1;
        if (!(DO <= 0)) {
          var MO, aK = bK.mallocDouble(2 * DO * vK),
            oO = bK.mallocInt32(vK);
          if ((vK = CO(OO, DO, aK, oO)) > 0) {
            if (1 === DO && XO) eO.init(vK), MO = eO.sweepComplete(DO, pO, 0, vK, aK, oO, 0, vK, aK, oO);
            else {
              var FO = bK.mallocDouble(2 * DO * hO),
                VO = bK.mallocInt32(hO);
              (hO = CO(KO, DO, FO, VO)) > 0 && (eO.init(vK + hO), MO = 1 === DO ? eO.sweepBipartite(DO, pO, 0, vK, aK, oO, 0, hO, FO, VO) : lO(DO, pO, XO, vK, aK, oO, hO, FO, VO), bK.free(FO), bK.free(VO))
            }
            bK.free(aK), bK.free(oO)
          }
          return MO
        }
      }
    }

    function DO(OO, KO) {
      XO.push([OO, KO])
    }
  },
  36706: (OO, KO) => {
    var pO = "d",
      XO = "ax",
      bK = "fp",
      eO = "es",
      lO = "rs",
      vK = "re",
      CO = "rb",
      hO = "bs",
      DO = "be",
      MO = "bb",
      aK = [pO, XO, "vv", lO, vK, CO, "ri", hO, DO, MO, "bi"];

    function oO(OO) {
      var KO = "bruteForce" + (OO ? "Full" : "Partial"),
        XO = [],
        lO = aK.slice();
      OO || lO.splice(3, 0, bK);
      var vK = ["function " + KO + "(" + lO.join() + "){"];

      function CO(KO, bK) {
        var lO = function(OO, KO, XO) {
          var bK = "bruteForce" + (OO ? "Red" : "Blue") + (KO ? "Flip" : "") + (XO ? "Full" : ""),
            lO = ["function ", bK, "(", aK.join(), "){", "var ", eO, "=2*", pO, ";"],
            vK = "for(var i=rs,rp=es*rs;i<re;++i,rp+=es){var x0=rb[ax+rp],x1=rb[ax+rp+d],xi=ri[i];",
            CO = "for(var j=bs,bp=es*bs;j<be;++j,bp+=es){var y0=bb[ax+bp]," + (XO ? "y1=bb[ax+bp+d]," : "") + "yi=bi[j];";
          return OO ? lO.push(vK, "Q", ":", CO) : lO.push(CO, "Q", ":", vK), XO ? lO.push("if(y1<x0||x1<y0)continue;") : KO ? lO.push("if(y0<=x0||x1<y0)continue;") : lO.push("if(y0<x0||x1<y0)continue;"), lO.push("for(var k=ax+1;k<d;++k){var r0=rb[k+rp],r1=rb[k+d+rp],b0=bb[k+bp],b1=bb[k+d+bp];if(r1<b0||b1<r0)continue Q;}var rv=vv("), KO ? lO.push("yi,xi") : lO.push("xi,yi"), lO.push(");if(rv!==void 0)return rv;}}}"), {
            name: bK,
            code: lO.join("")
          }
        }(KO, bK, OO);
        XO.push(lO.code), vK.push("return " + lO.name + "(" + aK.join() + ");")
      }
      vK.push("if(re-rs>be-bs){"), OO ? (CO(!0, !1), vK.push("}else{"), CO(!1, !1)) : (vK.push("if(fp){"), CO(!0, !0), vK.push("}else{"), CO(!0, !1), vK.push("}}else{if(fp){"), CO(!1, !0), vK.push("}else{"), CO(!1, !1), vK.push("}")), vK.push("}}return " + KO);
      var hO = XO.join("") + vK.join("");
      return new Function(hO)()
    }
    KO.partial = oO(!1), KO.full = oO(!0)
  },
  36703: (OO, KO, pO) => {
    OO.exports = function(OO, KO, pO, eO, DO, uO, EO, jK, YO) {
      ! function(OO, KO) {
        var pO = 8 * bK.log2(KO + 1) * (OO + 1) | 0,
          eO = bK.nextPow2(fO * pO);
        TO.length < eO && (XO.free(TO), TO = XO.mallocInt32(eO));
        var lO = bK.nextPow2(dO * pO);
        NO.length < lO && (XO.free(NO), NO = XO.mallocDouble(lO))
      }(OO, eO + EO);
      var wO, iK = 0,
        rK = 2 * OO;
      IO(iK++, 0, 0, eO, 0, EO, pO ? 16 : 0, -1 / 0, 1 / 0), pO || IO(iK++, 0, 0, EO, 0, eO, 1, -1 / 0, 1 / 0);
      for (; iK > 0;) {
        var PO = (iK -= 1) * fO,
          mK = TO[PO],
          sO = TO[PO + 1],
          HO = TO[PO + 2],
          RO = TO[PO + 3],
          SO = TO[PO + 4],
          JO = TO[PO + 5],
          cK = iK * dO,
          BO = NO[cK],
          ZO = NO[cK + 1],
          GO = 1 & JO,
          qK = !!(16 & JO),
          xK = DO,
          nO = uO,
          WO = jK,
          tK = YO;
        if (GO && (xK = jK, nO = YO, WO = DO, tK = uO), !(2 & JO && sO >= (HO = LO(OO, mK, sO, HO, xK, nO, ZO))) && !(4 & JO && (sO = QO(OO, mK, sO, HO, xK, nO, BO)) >= HO)) {
          var kK = HO - sO,
            UO = SO - RO;
          if (qK) {
            if (OO * kK * (kK + UO) < oO) {
              if (void 0 !== (wO = CO.scanComplete(OO, mK, KO, sO, HO, xK, nO, RO, SO, WO, tK))) return wO;
              continue
            }
          } else {
            if (OO * Math.min(kK, UO) < MO) {
              if (void 0 !== (wO = lO(OO, mK, KO, GO, sO, HO, xK, nO, RO, SO, WO, tK))) return wO;
              continue
            }
            if (OO * kK * UO < aK) {
              if (void 0 !== (wO = CO.scanBipartite(OO, mK, KO, GO, sO, HO, xK, nO, RO, SO, WO, tK))) return wO;
              continue
            }
          }
          var OK = FO(OO, mK, sO, HO, xK, nO, BO, ZO);
          if (sO < OK)
            if (OO * (OK - sO) < MO) {
              if (void 0 !== (wO = vK(OO, mK + 1, KO, sO, OK, xK, nO, RO, SO, WO, tK))) return wO
            } else if (mK === OO - 2) {
            if (void 0 !== (wO = GO ? CO.sweepBipartite(OO, KO, RO, SO, WO, tK, sO, OK, xK, nO) : CO.sweepBipartite(OO, KO, sO, OK, xK, nO, RO, SO, WO, tK))) return wO
          } else IO(iK++, mK + 1, sO, OK, RO, SO, GO, -1 / 0, 1 / 0), IO(iK++, mK + 1, RO, SO, sO, OK, 1 ^ GO, -1 / 0, 1 / 0);
          if (OK < HO) {
            var KK = hO(OO, mK, RO, SO, WO, tK),
              pK = WO[rK * KK + mK],
              XK = VO(OO, mK, KK, SO, WO, tK, pK);
            if (XK < SO && IO(iK++, mK, OK, HO, XK, SO, (4 | GO) + (qK ? 16 : 0), pK, ZO), RO < KK && IO(iK++, mK, OK, HO, RO, KK, (2 | GO) + (qK ? 16 : 0), BO, pK), KK + 1 === XK) {
              if (void 0 !== (wO = qK ? gK(OO, mK, KO, OK, HO, xK, nO, KK, WO, tK[KK]) : yK(OO, mK, KO, GO, OK, HO, xK, nO, KK, WO, tK[KK]))) return wO
            } else if (KK < XK) {
              var bp;
              if (qK) {
                if (OK < (bp = zK(OO, mK, OK, HO, xK, nO, pK))) {
                  var eK = VO(OO, mK, OK, bp, xK, nO, pK);
                  if (mK === OO - 2) {
                    if (OK < eK && void 0 !== (wO = CO.sweepComplete(OO, KO, OK, eK, xK, nO, KK, XK, WO, tK))) return wO;
                    if (eK < bp && void 0 !== (wO = CO.sweepBipartite(OO, KO, eK, bp, xK, nO, KK, XK, WO, tK))) return wO
                  } else OK < eK && IO(iK++, mK + 1, OK, eK, KK, XK, 16, -1 / 0, 1 / 0), eK < bp && (IO(iK++, mK + 1, eK, bp, KK, XK, 0, -1 / 0, 1 / 0), IO(iK++, mK + 1, KK, XK, eK, bp, 1, -1 / 0, 1 / 0))
                }
              } else OK < (bp = GO ? AO(OO, mK, OK, HO, xK, nO, pK) : zK(OO, mK, OK, HO, xK, nO, pK)) && (mK === OO - 2 ? wO = GO ? CO.sweepBipartite(OO, KO, KK, XK, WO, tK, OK, bp, xK, nO) : CO.sweepBipartite(OO, KO, OK, bp, xK, nO, KK, XK, WO, tK) : (IO(iK++, mK + 1, OK, bp, KK, XK, GO, -1 / 0, 1 / 0), IO(iK++, mK + 1, KK, XK, OK, bp, 1 ^ GO, -1 / 0, 1 / 0)))
            }
          }
        }
      }
    };
    var XO = pO(36674),
      bK = pO(36679),
      eO = pO(36706),
      lO = eO.partial,
      vK = eO.full,
      CO = pO(36693),
      hO = pO(36711),
      DO = pO(36717),
      MO = 128,
      aK = 1 << 22,
      oO = 1 << 22,
      FO = DO("!(lo>=p0)&&!(p1>=hi)", ["p0", "p1"]),
      VO = DO("lo===p0", ["p0"]),
      LO = DO("lo<p0", ["p0"]),
      QO = DO("hi<=p0", ["p0"]),
      zK = DO("lo<=p0&&p0<=hi", ["p0"]),
      AO = DO("lo<p0&&p0<=hi", ["p0"]),
      fO = 6,
      dO = 2,
      TO = XO.mallocInt32(1024),
      NO = XO.mallocDouble(1024);

    function IO(OO, KO, pO, XO, bK, eO, lO, vK, CO) {
      var hO = fO * OO;
      TO[hO] = KO, TO[hO + 1] = pO, TO[hO + 2] = XO, TO[hO + 3] = bK, TO[hO + 4] = eO, TO[hO + 5] = lO;
      var DO = dO * OO;
      NO[DO] = vK, NO[DO + 1] = CO
    }

    function yK(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO, DO) {
      var MO = 2 * OO,
        aK = CO * MO,
        oO = hO[aK + KO];
      OO: for (var FO = bK, VO = bK * MO; FO < eO; ++FO, VO += MO) {
        var LO = lO[VO + KO],
          QO = lO[VO + KO + OO];
        if (!(oO < LO || QO < oO) && (!XO || oO !== LO)) {
          for (var zK, AO = vK[FO], fO = KO + 1; fO < OO; ++fO) {
            LO = lO[VO + fO], QO = lO[VO + fO + OO];
            var dO = hO[aK + fO],
              TO = hO[aK + fO + OO];
            if (QO < dO || TO < LO) continue OO
          }
          if (void 0 !== (zK = XO ? pO(DO, AO) : pO(AO, DO))) return zK
        }
      }
    }

    function gK(OO, KO, pO, XO, bK, eO, lO, vK, CO, hO) {
      var DO = 2 * OO,
        MO = vK * DO,
        aK = CO[MO + KO];
      OO: for (var oO = XO, FO = XO * DO; oO < bK; ++oO, FO += DO) {
        var VO = lO[oO];
        if (VO !== hO) {
          var LO = eO[FO + KO],
            QO = eO[FO + KO + OO];
          if (!(aK < LO || QO < aK)) {
            for (var zK = KO + 1; zK < OO; ++zK) {
              LO = eO[FO + zK], QO = eO[FO + zK + OO];
              var AO = CO[MO + zK],
                fO = CO[MO + zK + OO];
              if (QO < AO || fO < LO) continue OO
            }
            var dO = pO(VO, hO);
            if (void 0 !== dO) return dO
          }
        }
      }
    }
  },
  36711: (OO, KO, pO) => {
    OO.exports = function(OO, KO, pO, lO, vK, CO) {
      if (lO <= pO + 1) return pO;
      var hO = pO,
        DO = lO,
        MO = lO + pO >>> 1,
        aK = 2 * OO,
        oO = MO,
        FO = vK[aK * MO + KO];
      for (; hO < DO;) {
        if (DO - hO < bK) {
          eO(OO, KO, hO, DO, vK, CO), FO = vK[aK * MO + KO];
          break
        }
        var VO = DO - hO,
          LO = Math.random() * VO + hO | 0,
          QO = vK[aK * LO + KO],
          zK = Math.random() * VO + hO | 0,
          AO = vK[aK * zK + KO],
          fO = Math.random() * VO + hO | 0,
          dO = vK[aK * fO + KO];
        QO <= AO ? dO >= AO ? (oO = zK, FO = AO) : QO >= dO ? (oO = LO, FO = QO) : (oO = fO, FO = dO) : AO >= dO ? (oO = zK, FO = AO) : dO >= QO ? (oO = LO, FO = QO) : (oO = fO, FO = dO);
        for (var TO = aK * (DO - 1), NO = aK * oO, IO = 0; IO < aK; ++IO, ++TO, ++NO) {
          var yK = vK[TO];
          vK[TO] = vK[NO], vK[NO] = yK
        }
        var gK = CO[DO - 1];
        CO[DO - 1] = CO[oO], CO[oO] = gK;
        for (TO = aK * (DO - 1), NO = aK * (oO = XO(OO, KO, hO, DO - 1, vK, CO, FO)), IO = 0; IO < aK; ++IO, ++TO, ++NO) {
          yK = vK[TO];
          vK[TO] = vK[NO], vK[NO] = yK
        }
        gK = CO[DO - 1];
        if (CO[DO - 1] = CO[oO], CO[oO] = gK, MO < oO) {
          for (DO = oO - 1; hO < DO && vK[aK * (DO - 1) + KO] === FO;) DO -= 1;
          DO += 1
        } else {
          if (!(oO < MO)) break;
          for (hO = oO + 1; hO < DO && vK[aK * hO + KO] === FO;) hO += 1
        }
      }
      return XO(OO, KO, pO, MO, vK, CO, vK[aK * MO + KO])
    };
    var XO = pO(36717)("lo<p0", ["p0"]),
      bK = 8;

    function eO(OO, KO, pO, XO, bK, eO) {
      for (var lO = 2 * OO, vK = lO * (pO + 1) + KO, CO = pO + 1; CO < XO; ++CO, vK += lO)
        for (var hO = bK[vK], DO = CO, MO = lO * (CO - 1); DO > pO && bK[MO + KO] > hO; --DO, MO -= lO) {
          for (var aK = MO, oO = MO + lO, FO = 0; FO < lO; ++FO, ++aK, ++oO) {
            var VO = bK[aK];
            bK[aK] = bK[oO], bK[oO] = VO
          }
          var LO = eO[DO];
          eO[DO] = eO[DO - 1], eO[DO - 1] = LO
        }
    }
  },
  36717: OO => {
    OO.exports = function(OO, pO) {
      var XO = "abcdef".split("").concat(pO),
        bK = [];
      OO.indexOf("lo") >= 0 && bK.push("lo=e[k+n]");
      OO.indexOf("hi") >= 0 && bK.push("hi=e[k+o]");
      return XO.push(KO.replace("_", bK.join()).replace("$", OO)), Function.apply(void 0, XO)
    };
    var KO = "for(var j=2*a,k=j*c,l=k,m=c,n=b,o=a+b,p=c;d>p;++p,k+=j){var _;if($)if(m===p)m+=1,l+=j;else{for(var s=0;j>s;++s){var t=e[k+s];e[k+s]=e[l],e[l++]=t}var u=f[p];f[p]=f[m],f[m++]=u}}return m"
  },
  36695: OO => {
    OO.exports = function(OO, XO) {
      XO <= 4 * KO ? pO(0, XO - 1, OO) : hO(0, XO - 1, OO)
    };
    var KO = 32;

    function pO(OO, KO, pO) {
      for (var XO = 2 * (OO + 1), bK = OO + 1; bK <= KO; ++bK) {
        for (var eO = pO[XO++], lO = pO[XO++], vK = bK, CO = XO - 2; vK-- > OO;) {
          var hO = pO[CO - 2],
            DO = pO[CO - 1];
          if (hO < eO) break;
          if (hO === eO && DO < lO) break;
          pO[CO] = hO, pO[CO + 1] = DO, CO -= 2
        }
        pO[CO] = eO, pO[CO + 1] = lO
      }
    }

    function XO(OO, KO, pO) {
      KO *= 2;
      var XO = pO[OO *= 2],
        bK = pO[OO + 1];
      pO[OO] = pO[KO], pO[OO + 1] = pO[KO + 1], pO[KO] = XO, pO[KO + 1] = bK
    }

    function bK(OO, KO, pO) {
      KO *= 2, pO[OO *= 2] = pO[KO], pO[OO + 1] = pO[KO + 1]
    }

    function eO(OO, KO, pO, XO) {
      KO *= 2, pO *= 2;
      var bK = XO[OO *= 2],
        eO = XO[OO + 1];
      XO[OO] = XO[KO], XO[OO + 1] = XO[KO + 1], XO[KO] = XO[pO], XO[KO + 1] = XO[pO + 1], XO[pO] = bK, XO[pO + 1] = eO
    }

    function lO(OO, KO, pO, XO, bK) {
      KO *= 2, bK[OO *= 2] = bK[KO], bK[KO] = pO, bK[OO + 1] = bK[KO + 1], bK[KO + 1] = XO
    }

    function vK(OO, KO, pO) {
      KO *= 2;
      var XO = pO[OO *= 2],
        bK = pO[KO];
      return !(XO < bK) && (XO !== bK || pO[OO + 1] > pO[KO + 1])
    }

    function CO(OO, KO, pO, XO) {
      var bK = XO[OO *= 2];
      return bK < KO || bK === KO && XO[OO + 1] < pO
    }

    function hO(OO, DO, MO) {
      var aK = (DO - OO + 1) / 6 | 0,
        oO = OO + aK,
        FO = DO - aK,
        VO = OO + DO >> 1,
        LO = VO - aK,
        QO = VO + aK,
        zK = oO,
        AO = LO,
        fO = VO,
        dO = QO,
        TO = FO,
        NO = OO + 1,
        IO = DO - 1,
        yK = 0;
      vK(zK, AO, MO) && (yK = zK, zK = AO, AO = yK), vK(dO, TO, MO) && (yK = dO, dO = TO, TO = yK), vK(zK, fO, MO) && (yK = zK, zK = fO, fO = yK), vK(AO, fO, MO) && (yK = AO, AO = fO, fO = yK), vK(zK, dO, MO) && (yK = zK, zK = dO, dO = yK), vK(fO, dO, MO) && (yK = fO, fO = dO, dO = yK), vK(AO, TO, MO) && (yK = AO, AO = TO, TO = yK), vK(AO, fO, MO) && (yK = AO, AO = fO, fO = yK), vK(dO, TO, MO) && (yK = dO, dO = TO, TO = yK);
      for (var gK = MO[2 * AO], uO = MO[2 * AO + 1], EO = MO[2 * dO], jK = MO[2 * dO + 1], YO = 2 * zK, wO = 2 * fO, iK = 2 * TO, rK = 2 * oO, PO = 2 * VO, mK = 2 * FO, sO = 0; sO < 2; ++sO) {
        var HO = MO[YO + sO],
          RO = MO[wO + sO],
          SO = MO[iK + sO];
        MO[rK + sO] = HO, MO[PO + sO] = RO, MO[mK + sO] = SO
      }
      bK(LO, OO, MO), bK(QO, DO, MO);
      for (var JO = NO; JO <= IO; ++JO)
        if (CO(JO, gK, uO, MO)) JO !== NO && XO(JO, NO, MO), ++NO;
        else if (!CO(JO, EO, jK, MO))
        for (;;) {
          if (CO(IO, EO, jK, MO)) {
            CO(IO, gK, uO, MO) ? (eO(JO, NO, IO, MO), ++NO, --IO) : (XO(JO, IO, MO), --IO);
            break
          }
          if (--IO < JO) break
        }
      lO(OO, NO - 1, gK, uO, MO), lO(DO, IO + 1, EO, jK, MO), NO - 2 - OO <= KO ? pO(OO, NO - 2, MO) : hO(OO, NO - 2, MO), DO - (IO + 2) <= KO ? pO(IO + 2, DO, MO) : hO(IO + 2, DO, MO), IO - NO <= KO ? pO(NO, IO, MO) : hO(NO, IO, MO)
    }
  },
  36693: (OO, KO, pO) => {
    OO.exports = {
      init: function(OO) {
        var KO = bK.nextPow2(OO);
        CO.length < KO && (XO.free(CO), CO = XO.mallocInt32(KO));
        hO.length < KO && (XO.free(hO), hO = XO.mallocInt32(KO));
        DO.length < KO && (XO.free(DO), DO = XO.mallocInt32(KO));
        MO.length < KO && (XO.free(MO), MO = XO.mallocInt32(KO));
        aK.length < KO && (XO.free(aK), aK = XO.mallocInt32(KO));
        oO.length < KO && (XO.free(oO), oO = XO.mallocInt32(KO));
        var pO = 8 * KO;
        FO.length < pO && (XO.free(FO), FO = XO.mallocDouble(pO))
      },
      sweepBipartite: function(OO, KO, pO, XO, bK, vK, aK, oO, QO, zK) {
        for (var AO = 0, fO = 2 * OO, dO = OO - 1, TO = fO - 1, NO = pO; NO < XO; ++NO) {
          var IO = vK[NO],
            yK = fO * NO;
          FO[AO++] = bK[yK + dO], FO[AO++] = -(IO + 1), FO[AO++] = bK[yK + TO], FO[AO++] = IO
        }
        for (NO = aK; NO < oO; ++NO) {
          IO = zK[NO] + lO;
          var gK = fO * NO;
          FO[AO++] = QO[gK + dO], FO[AO++] = -IO, FO[AO++] = QO[gK + TO], FO[AO++] = IO
        }
        var uO = AO >>> 1;
        eO(FO, uO);
        var EO = 0,
          jK = 0;
        for (NO = 0; NO < uO; ++NO) {
          var YO = 0 | FO[2 * NO + 1];
          if (YO >= lO) VO(DO, MO, jK--, YO = YO - lO | 0);
          else if (YO >= 0) VO(CO, hO, EO--, YO);
          else if (YO <= -lO) {
            YO = -YO - lO | 0;
            for (var wO = 0; wO < EO; ++wO) {
              if (void 0 !== (iK = KO(CO[wO], YO))) return iK
            }
            LO(DO, MO, jK++, YO)
          } else {
            YO = -YO - 1 | 0;
            for (wO = 0; wO < jK; ++wO) {
              var iK;
              if (void 0 !== (iK = KO(YO, DO[wO]))) return iK
            }
            LO(CO, hO, EO++, YO)
          }
        }
      },
      sweepComplete: function(OO, KO, pO, XO, bK, lO, vK, QO, zK, AO) {
        for (var fO = 0, dO = 2 * OO, TO = OO - 1, NO = dO - 1, IO = pO; IO < XO; ++IO) {
          var yK = lO[IO] + 1 << 1,
            gK = dO * IO;
          FO[fO++] = bK[gK + TO], FO[fO++] = -yK, FO[fO++] = bK[gK + NO], FO[fO++] = yK
        }
        for (IO = vK; IO < QO; ++IO) {
          yK = AO[IO] + 1 << 1;
          var uO = dO * IO;
          FO[fO++] = zK[uO + TO], FO[fO++] = 1 | -yK, FO[fO++] = zK[uO + NO], FO[fO++] = 1 | yK
        }
        var EO = fO >>> 1;
        eO(FO, EO);
        var jK = 0,
          YO = 0,
          wO = 0;
        for (IO = 0; IO < EO; ++IO) {
          var iK = 0 | FO[2 * IO + 1],
            rK = 1 & iK;
          if (IO < EO - 1 && iK >> 1 === FO[2 * IO + 3] >> 1 && (rK = 2, IO += 1), iK < 0) {
            for (var PO = -(iK >> 1) - 1, mK = 0; mK < wO; ++mK) {
              if (void 0 !== (sO = KO(aK[mK], PO))) return sO
            }
            if (0 !== rK)
              for (mK = 0; mK < jK; ++mK) {
                if (void 0 !== (sO = KO(CO[mK], PO))) return sO
              }
            if (1 !== rK)
              for (mK = 0; mK < YO; ++mK) {
                var sO;
                if (void 0 !== (sO = KO(DO[mK], PO))) return sO
              }
            0 === rK ? LO(CO, hO, jK++, PO) : 1 === rK ? LO(DO, MO, YO++, PO) : 2 === rK && LO(aK, oO, wO++, PO)
          } else {
            PO = (iK >> 1) - 1;
            0 === rK ? VO(CO, hO, jK--, PO) : 1 === rK ? VO(DO, MO, YO--, PO) : 2 === rK && VO(aK, oO, wO--, PO)
          }
        }
      },
      scanBipartite: function(OO, KO, pO, XO, bK, vK, DO, MO, aK, oO, QO, zK) {
        var AO = 0,
          fO = 2 * OO,
          dO = KO,
          TO = KO + OO,
          NO = 1,
          IO = 1;
        XO ? IO = lO : NO = lO;
        for (var yK = bK; yK < vK; ++yK) {
          var gK = yK + NO,
            uO = fO * yK;
          FO[AO++] = DO[uO + dO], FO[AO++] = -gK, FO[AO++] = DO[uO + TO], FO[AO++] = gK
        }
        for (yK = aK; yK < oO; ++yK) {
          gK = yK + IO;
          var EO = fO * yK;
          FO[AO++] = QO[EO + dO], FO[AO++] = -gK
        }
        var jK = AO >>> 1;
        eO(FO, jK);
        var YO = 0;
        for (yK = 0; yK < jK; ++yK) {
          var wO = 0 | FO[2 * yK + 1];
          if (wO < 0) {
            var iK = !1;
            if ((gK = -wO) >= lO ? (iK = !XO, gK -= lO) : (iK = !!XO, gK -= 1), iK) LO(CO, hO, YO++, gK);
            else {
              var rK = zK[gK],
                PO = fO * gK,
                mK = QO[PO + KO + 1],
                sO = QO[PO + KO + 1 + OO];
              OO: for (var HO = 0; HO < YO; ++HO) {
                var RO = CO[HO],
                  SO = fO * RO;
                if (!(sO < DO[SO + KO + 1] || DO[SO + KO + 1 + OO] < mK)) {
                  for (var JO = KO + 2; JO < OO; ++JO)
                    if (QO[PO + JO + OO] < DO[SO + JO] || DO[SO + JO + OO] < QO[PO + JO]) continue OO;
                  var cK, BO = MO[RO];
                  if (void 0 !== (cK = XO ? pO(rK, BO) : pO(BO, rK))) return cK
                }
              }
            }
          } else VO(CO, hO, YO--, wO - NO)
        }
      },
      scanComplete: function(OO, KO, pO, XO, bK, vK, hO, DO, MO, aK, oO) {
        for (var VO = 0, LO = 2 * OO, QO = KO, zK = KO + OO, AO = XO; AO < bK; ++AO) {
          var fO = AO + lO,
            dO = LO * AO;
          FO[VO++] = vK[dO + QO], FO[VO++] = -fO, FO[VO++] = vK[dO + zK], FO[VO++] = fO
        }
        for (AO = DO; AO < MO; ++AO) {
          fO = AO + 1;
          var TO = LO * AO;
          FO[VO++] = aK[TO + QO], FO[VO++] = -fO
        }
        var NO = VO >>> 1;
        eO(FO, NO);
        var IO = 0;
        for (AO = 0; AO < NO; ++AO) {
          var yK = 0 | FO[2 * AO + 1];
          if (yK < 0) {
            if ((fO = -yK) >= lO) CO[IO++] = fO - lO;
            else {
              var gK = oO[fO -= 1],
                uO = LO * fO,
                EO = aK[uO + KO + 1],
                jK = aK[uO + KO + 1 + OO];
              OO: for (var YO = 0; YO < IO; ++YO) {
                var wO = CO[YO],
                  iK = hO[wO];
                if (iK === gK) break;
                var rK = LO * wO;
                if (!(jK < vK[rK + KO + 1] || vK[rK + KO + 1 + OO] < EO)) {
                  for (var PO = KO + 2; PO < OO; ++PO)
                    if (aK[uO + PO + OO] < vK[rK + PO] || vK[rK + PO + OO] < aK[uO + PO]) continue OO;
                  var mK = pO(iK, gK);
                  if (void 0 !== mK) return mK
                }
              }
            }
          } else {
            for (fO = yK - lO, YO = IO - 1; YO >= 0; --YO)
              if (CO[YO] === fO) {
                for (PO = YO + 1; PO < IO; ++PO) CO[PO - 1] = CO[PO];
                break
              }-- IO
          }
        }
      }
    };
    var XO = pO(36674),
      bK = pO(36679),
      eO = pO(36695),
      lO = 1 << 28,
      vK = 1024,
      CO = XO.mallocInt32(vK),
      hO = XO.mallocInt32(vK),
      DO = XO.mallocInt32(vK),
      MO = XO.mallocInt32(vK),
      aK = XO.mallocInt32(vK),
      oO = XO.mallocInt32(vK),
      FO = XO.mallocDouble(8192);

    function VO(OO, KO, pO, XO) {
      var bK = KO[XO],
        eO = OO[pO - 1];
      OO[bK] = eO, KO[eO] = bK
    }

    function LO(OO, KO, pO, XO) {
      OO[pO] = XO, KO[XO] = pO
    }
  },
  36682: OO => {
    function KO(OO, pO, XO) {
      var bK = 0 | OO[XO];
      if (bK <= 0) return [];
      var eO, lO = new Array(bK);
      if (XO === OO.length - 1)
        for (eO = 0; eO < bK; ++eO) lO[eO] = pO;
      else
        for (eO = 0; eO < bK; ++eO) lO[eO] = KO(OO, pO, XO + 1);
      return lO
    }
    OO.exports = function(OO, pO) {
      switch ("undefined" === typeof pO && (pO = 0), typeof OO) {
        case "number":
          if (OO > 0) return function(OO, KO) {
            var pO, XO;
            for (pO = new Array(OO), XO = 0; XO < OO; ++XO) pO[XO] = KO;
            return pO
          }(0 | OO, pO);
          break;
        case "object":
          if ("number" === typeof OO.length) return KO(OO, pO, 0)
      }
      return []
    }
  },
  36634: (OO, KO, pO) => {
    OO.exports = function() {
      var OO = this;
      this.components = {}, this.comps = this.components;
      var KO = this.components,
        pO = 1,
        bK = {},
        eO = [],
        lO = [],
        vK = {
          timeout: !1,
          removals: [],
          multiComps: []
        };

      function CO(OO, pO) {
        var XO = KO[pO],
          eO = bK[pO],
          lO = eO.hash[OO];
        lO && (eO.remove(OO), XO.ypO && (XO.multi ? (lO.forEach((KO => {
          KO && XO.ypO(OO, KO)
        })), lO.length = 0) : XO.ypO(OO, lO)), vK.removals.push(eO), hO())
      }

      function hO() {
        vK.timeout || (vK.timeout = !0, setTimeout(DO, 1))
      }

      function DO() {
        vK.timeout = !1, MO()
      }

      function MO() {
        vK.multiComps.length && function(OO) {
          for (var KO = 0; KO < OO.length; KO++) {
            var {
              entID: pO,
              data: XO
            } = OO[KO], bK = XO.hash[pO];
            if (bK) {
              for (var eO = 0; eO < bK.length; eO++) bK[eO] || (bK.splice(eO, 1), eO--);
              0 === bK.length && (XO.remove(pO), vK.removals.push(XO))
            }
          }
          OO.length = 0
        }(vK.multiComps), vK.removals.length && function(OO) {
          for (var KO = 0; KO < OO.length; KO++) {
            OO[KO].flush()
          }
          OO.length = 0
        }(vK.removals)
      }
      this.Rb = bK, this._systems = eO, this._renderSystems = lO, this.XbO = function(KO) {
        var XO = pO++;
        return Array.isArray(KO) && KO.forEach((KO => OO.UKO(XO, KO))), XO
      }, this.deleteEntity = function(KO) {
        return Object.keys(bK).forEach((OO => {
          bK[OO].hash[KO] && CO(KO, OO)
        })), OO
      }, this.ihO = function(OO) {
        if (!OO) throw new Error("Missing component definition");
        var pO = OO.name;
        if (!pO) throw new Error("Component definition must have a name property.");
        if ("string" !== typeof pO) throw new Error("Component name must be a string.");
        if ("" === pO) throw new Error("Component name must be a non-empty string.");
        if (bK[pO]) throw new Error(`Component ${pO} already exists.`);
        var vK = {};
        return vK.name = pO, vK.multi = !!OO.multi, vK.order = isNaN(OO.order) ? 99 : OO.order, vK.stateConstructor = OO.stateConstructor || null, vK.state = OO.state || {}, vK.qL = OO.qL || null, vK.ypO = OO.ypO || null, vK.system = OO.system || null, vK.lL = OO.lL || null, KO[pO] = vK, bK[pO] = new XO, bK[pO]._pendingMultiCleanup = !1, bK[pO]._multiCleanupIDs = vK.multi ? [] : null, vK.system && (eO.push(pO), eO.sort(((OO, pO) => KO[OO].order - KO[pO].order))), vK.lL && (lO.push(pO), lO.sort(((OO, pO) => KO[OO].order - KO[pO].order))), pO
      }, this.overwriteComponent = function(OO, pO) {
        var XO = KO[OO];
        if (!XO) throw new Error(`Unknown component: ${OO}`);
        if (!pO) throw new Error("Missing component definition");
        if (XO.name !== pO.name) throw new Error("Overwriting component must use the same name property.");
        var vK = {};
        vK.name = OO, vK.multi = !!pO.multi, vK.order = isNaN(pO.order) ? 99 : pO.order, vK.state = pO.state || {}, vK.qL = pO.qL || null, vK.ypO = pO.ypO || null, vK.system = pO.system || null, vK.lL = pO.lL || null, KO[OO] = vK, bK[OO]._pendingMultiCleanup = !1, bK[OO]._multiCleanupIDs = vK.multi ? [] : null;
        var CO = eO.indexOf(OO);
        vK.system && CO < 0 && eO.push(OO), !vK.system && CO >= 0 && eO.splice(CO, 1), eO.sort(((OO, pO) => KO[OO].order - KO[pO].order));
        var hO = lO.indexOf(OO);
        vK.lL && hO < 0 && lO.push(OO), !vK.lL && hO >= 0 && lO.splice(hO, 1), lO.sort(((OO, pO) => KO[OO].order - KO[pO].order));
        var DO = vK.state;
        return this.tpO(OO).forEach((OO => {
          for (var KO in DO) KO in OO || (OO[KO] = DO[KO]);
          vK.qL && vK.qL(OO.kpO, OO)
        })), OO
      }, this.deleteComponent = function(pO) {
        var XO = bK[pO];
        if (!XO) throw new Error(`Unknown component: ${pO}`);
        XO.flush(), XO.list.forEach((OO => {
          OO && CO(OO.kpO || OO[0].kpO, pO)
        }));
        var vK = eO.indexOf(pO),
          hO = lO.indexOf(pO);
        return vK > -1 && eO.splice(vK, 1), hO > -1 && lO.splice(hO, 1), bK[pO].dispose(), delete bK[pO], delete KO[pO], OO
      }, this.UKO = function(OO, pO, XO) {
        var eO, lO = KO[pO],
          vK = bK[pO];
        if (!vK) throw new Error(`Unknown component: ${pO}.`);
        if (vK.hash[OO] && !lO.multi) throw new Error(`Entity ${OO} already has component: ${pO}.`);
        if (lO.stateConstructor) {
          if (!(eO = new lO.stateConstructor).hasOwnProperty("kpO")) throw new Error(`Component ${lO.name} stateConstructor type does not have property __id`);
          Object.assign(eO, lO.state, XO)
        } else eO = {
          kpO: OO,
          ...lO.state,
          ...XO
        };
        if (eO.kpO = OO, lO.multi) {
          var CO = vK.hash[OO];
          CO || (CO = [], vK.add(OO, CO)), CO.push(eO)
        } else vK.add(OO, eO);
        return lO.qL && lO.qL(OO, eO), this
      }, this.gCO = function(OO, KO) {
        var pO = bK[KO];
        if (!pO) throw new Error(`Unknown component: ${KO}.`);
        return !!pO.hash[OO]
      }, this.OpO = function(KO, pO) {
        if (!bK[pO]) throw new Error(`Unknown component: ${pO}.`);
        return CO(KO, pO), OO
      }, this.getState = function(OO, KO) {
        var pO = bK[KO];
        if (!pO) throw new Error(`Unknown component: ${KO}.`);
        return pO.hash[OO]
      }, this.tpO = function(OO) {
        var KO = bK[OO];
        if (!KO) throw new Error(`Unknown component: ${OO}.`);
        return MO(), KO.list
      }, this.ahO = function(OO) {
        if (!bK[OO]) throw new Error(`Unknown component: ${OO}.`);
        var KO = bK[OO].hash;
        return OO => KO[OO]
      }, this.zhO = function(OO) {
        if (!bK[OO]) throw new Error(`Unknown component: ${OO}.`);
        var KO = bK[OO].hash;
        return OO => !!KO[OO]
      }, this.KK = function(pO) {
        MO();
        for (var XO = 0; XO < eO.length; XO++) {
          var lO = eO[XO],
            vK = KO[lO],
            CO = bK[lO];
          vK.system(pO, CO.list), MO()
        }
        return OO
      }, this.render = function(pO) {
        MO();
        for (var XO = 0; XO < lO.length; XO++) {
          var eO = lO[XO],
            vK = KO[eO],
            CO = bK[eO];
          vK.lL(pO, CO.list), MO()
        }
        return OO
      }, this.removeMultiComponent = function(pO, XO, eO) {
        var lO = KO[XO],
          CO = bK[XO];
        if (!CO) throw new Error(`Unknown component: ${XO}.`);
        if (!lO.multi) throw new Error("removeMultiComponent called on non-multi component");
        return function(OO, KO, pO, XO) {
          var bK = pO.hash[OO];
          if (bK) {
            var eO = bK[XO];
            eO && (bK[XO] = null, KO.ypO && KO.ypO(OO, eO), vK.multiComps.push({
              entID: OO,
              data: pO
            }), hO())
          }
        }(pO, lO, CO, eO), OO
      }
    };
    var XO = pO(36641)
  },
  36641: OO => {
    function KO(OO, KO) {
      var pO = OO._map[KO];
      if (delete OO.hash[KO], delete OO._map[KO], pO === OO.list.length - 1) OO.list.pop(), OO._idList.pop();
      else {
        var XO = OO.list.pop();
        OO.list[pO] = XO;
        var bK = OO._idList.pop();
        OO._idList[pO] = bK, OO._map[bK] = pO
      }
    }
    OO.exports = class {
      constructor() {
        this.list = [], this.hash = {}, this._map = {}, this._idList = [], this._pendingRemovals = []
      }
      add(OO, KO) {
        if ("number" === typeof this._map[OO]) {
          var pO = this._map[OO];
          this.hash[OO] = KO, this.list[pO] = KO, this._idList[pO] = OO
        } else this._map[OO] = this.list.length, this.hash[OO] = KO, this.list.push(KO), this._idList.push(OO)
      }
      remove(OO) {
        var KO = this._map[OO];
        this.hash[OO] = null, this.list[KO] = null, this._pendingRemovals.push(OO)
      }
      dispose() {
        this.list = null, this.hash = null, this._map = null, this._idList = null, this._pendingRemovals.length = 0
      }
      flush() {
        for (var OO = 0; OO < this._pendingRemovals.length; OO++) {
          var pO = this._pendingRemovals[OO];
          null === this.hash[pO] && KO(this, pO)
        }
        this._pendingRemovals.length = 0
      }
    }
  },
  36095: OO => {
    OO.exports = function(OO) {
      for (var KO = new Array(OO), pO = 0; pO < OO; ++pO) KO[pO] = pO;
      return KO
    }
  },
  36099: OO => {
    function KO(OO) {
      return !!OO.constructor && "function" === typeof OO.constructor.isBuffer && OO.constructor.isBuffer(OO)
    }
    OO.exports = function(OO) {
      return null != OO && (KO(OO) || function(OO) {
        return "function" === typeof OO.readFloatLE && "function" === typeof OO.slice && KO(OO.slice(0, 0))
      }(OO) || !!OO._isBuffer)
    }
  },
  36424: (OO, KO, pO) => {
    OO = pO.nmd(OO);
    var XO = "__lodash_hash_undefined__",
      bK = 9007199254740991,
      eO = "[object Arguments]",
      lO = "[object Boolean]",
      vK = "[object Date]",
      CO = "[object Function]",
      hO = "[object GeneratorFunction]",
      DO = "[object Map]",
      MO = "[object Number]",
      aK = "[object Object]",
      oO = "[object Promise]",
      FO = "[object RegExp]",
      VO = "[object Set]",
      LO = "[object String]",
      QO = "[object Symbol]",
      zK = "[object WeakMap]",
      AO = "[object ArrayBuffer]",
      fO = "[object DataView]",
      dO = "[object Float32Array]",
      TO = "[object Float64Array]",
      NO = "[object Int8Array]",
      IO = "[object Int16Array]",
      yK = "[object Int32Array]",
      gK = "[object Uint8Array]",
      uO = "[object Uint8ClampedArray]",
      EO = "[object Uint16Array]",
      jK = "[object Uint32Array]",
      YO = /\w*$/,
      wO = /^\[object .+?Constructor\]$/,
      iK = /^(?:0|[1-9]\d*)$/,
      rK = {};
    rK[eO] = rK["[object Array]"] = rK[AO] = rK[fO] = rK[lO] = rK[vK] = rK[dO] = rK[TO] = rK[NO] = rK[IO] = rK[yK] = rK[DO] = rK[MO] = rK[aK] = rK[FO] = rK[VO] = rK[LO] = rK[QO] = rK[gK] = rK[uO] = rK[EO] = rK[jK] = !0, rK["[object Error]"] = rK[CO] = rK[zK] = !1;
    var PO = "object" == typeof pO.g && pO.g && pO.g.Object === Object && pO.g,
      mK = "object" == typeof self && self && self.Object === Object && self,
      sO = PO || mK || Function("return this")(),
      HO = KO && !KO.nodeType && KO,
      RO = HO && OO && !OO.nodeType && OO,
      SO = RO && RO.exports === HO;

    function JO(OO, KO) {
      return OO.set(KO[0], KO[1]), OO
    }

    function cK(OO, KO) {
      return OO.add(KO), OO
    }

    function BO(OO, KO, pO, XO) {
      var bK = -1,
        eO = OO ? OO.length : 0;
      for (XO && eO && (pO = OO[++bK]); ++bK < eO;) pO = KO(pO, OO[bK], bK, OO);
      return pO
    }

    function ZO(OO) {
      var KO = !1;
      if (null != OO && "function" != typeof OO.toString) try {
        KO = !!(OO + "")
      } catch (pO) {}
      return KO
    }

    function GO(OO) {
      var KO = -1,
        pO = Array(OO.size);
      return OO.forEach((function(OO, XO) {
        pO[++KO] = [XO, OO]
      })), pO
    }

    function qK(OO, KO) {
      return function(pO) {
        return OO(KO(pO))
      }
    }

    function xK(OO) {
      var KO = -1,
        pO = Array(OO.size);
      return OO.forEach((function(OO) {
        pO[++KO] = OO
      })), pO
    }
    var nO = Array.prototype,
      WO = Function.prototype,
      tK = Object.prototype,
      kK = sO["__core-js_shared__"],
      UO = function() {
        var OO = /[^.]+$/.exec(kK && kK.keys && kK.keys.IE_PROTO || "");
        return OO ? "Symbol(src)_1." + OO : ""
      }(),
      OK = WO.toString,
      KK = tK.hasOwnProperty,
      pK = tK.toString,
      XK = RegExp("^" + OK.call(KK).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
      bp = SO ? sO.jb : void 0,
      eK = sO.Symbol,
      lK = sO.Uint8Array,
      vp = qK(Object.getPrototypeOf, Object),
      CK = Object.create,
      hK = tK.propertyIsEnumerable,
      DK = nO.splice,
      MK = Object.getOwnPropertySymbols,
      ap = bp ? bp.isBuffer : void 0,
      oK = qK(Object.keys, Object),
      FK = SK(sO, "DataView"),
      VK = SK(sO, "Map"),
      LK = SK(sO, "Promise"),
      QK = SK(sO, "Set"),
      zp = SK(sO, "WeakMap"),
      AK = SK(Object, "create"),
      fK = GK(FK),
      dK = GK(VK),
      TK = GK(LK),
      NK = GK(QK),
      IK = GK(zp),
      yp = eK ? eK.prototype : void 0,
      gp = yp ? yp.valueOf : void 0;

    function uK(OO) {
      var KO = -1,
        pO = OO ? OO.length : 0;
      for (this.clear(); ++KO < pO;) {
        var XO = OO[KO];
        this.set(XO[0], XO[1])
      }
    }

    function EK(OO) {
      var KO = -1,
        pO = OO ? OO.length : 0;
      for (this.clear(); ++KO < pO;) {
        var XO = OO[KO];
        this.set(XO[0], XO[1])
      }
    }

    function jp(OO) {
      var KO = -1,
        pO = OO ? OO.length : 0;
      for (this.clear(); ++KO < pO;) {
        var XO = OO[KO];
        this.set(XO[0], XO[1])
      }
    }

    function YK(OO) {
      this.__data__ = new EK(OO)
    }

    function wK(OO, KO) {
      var pO = xp(OO) || function(OO) {
          return function(OO) {
            return function(OO) {
              return !!OO && "object" == typeof OO
            }(OO) && nK(OO)
          }(OO) && KK.call(OO, "callee") && (!hK.call(OO, "callee") || pK.call(OO) == eO)
        }(OO) ? function(OO, KO) {
          for (var pO = -1, XO = Array(OO); ++pO < OO;) XO[pO] = KO(pO);
          return XO
        }(OO.length, String) : [],
        XO = pO.length,
        bK = !!XO;
      for (var lO in OO) !KO && !KK.call(OO, lO) || bK && ("length" == lO || BK(lO, XO)) || pO.push(lO);
      return pO
    }

    function ip(OO, KO, pO) {
      var XO = OO[KO];
      KK.call(OO, KO) && qp(XO, pO) && (void 0 !== pO || KO in OO) || (OO[KO] = pO)
    }

    function rp(OO, KO) {
      for (var pO = OO.length; pO--;)
        if (qp(OO[pO][0], KO)) return pO;
      return -1
    }

    function PK(OO, KO, pO, XO, bK, oO, zK) {
      var wO;
      if (XO && (wO = oO ? XO(OO, bK, oO, zK) : XO(OO)), void 0 !== wO) return wO;
      if (!kp(OO)) return OO;
      var iK = xp(OO);
      if (iK) {
        if (wO = function(OO) {
            var KO = OO.length,
              pO = OO.constructor(KO);
            KO && "string" == typeof OO[0] && KK.call(OO, "index") && (pO.index = OO.index, pO.input = OO.input);
            return pO
          }(OO), !KO) return function(OO, KO) {
          var pO = -1,
            XO = OO.length;
          KO || (KO = Array(XO));
          for (; ++pO < XO;) KO[pO] = OO[pO];
          return KO
        }(OO, wO)
      } else {
        var PO = cp(OO),
          mK = PO == CO || PO == hO;
        if (WK(OO)) return function(OO, KO) {
          if (KO) return OO.slice();
          var pO = new OO.constructor(OO.length);
          return OO.copy(pO), pO
        }(OO, KO);
        if (PO == aK || PO == eO || mK && !oO) {
          if (ZO(OO)) return oO ? OO : {};
          if (wO = function(OO) {
              return "function" != typeof OO.constructor || ZK(OO) ? {} : (KO = vp(OO), kp(KO) ? CK(KO) : {});
              var KO
            }(mK ? {} : OO), !KO) return function(OO, KO) {
            return HK(OO, JK(OO), KO)
          }(OO, function(OO, KO) {
            return OO && HK(KO, UK(KO), OO)
          }(wO, OO))
        } else {
          if (!rK[PO]) return oO ? OO : {};
          wO = function(OO, KO, pO, XO) {
            var bK = OO.constructor;
            switch (KO) {
              case AO:
                return sK(OO);
              case lO:
              case vK:
                return new bK(+OO);
              case fO:
                return function(OO, KO) {
                  var pO = KO ? sK(OO.buffer) : OO.buffer;
                  return new OO.constructor(pO, OO.byteOffset, OO.byteLength)
                }(OO, XO);
              case dO:
              case TO:
              case NO:
              case IO:
              case yK:
              case gK:
              case uO:
              case EO:
              case jK:
                return function(OO, KO) {
                  var pO = KO ? sK(OO.buffer) : OO.buffer;
                  return new OO.constructor(pO, OO.byteOffset, OO.length)
                }(OO, XO);
              case DO:
                return function(OO, KO, pO) {
                  var XO = KO ? pO(GO(OO), !0) : GO(OO);
                  return BO(XO, JO, new OO.constructor)
                }(OO, XO, pO);
              case MO:
              case LO:
                return new bK(OO);
              case FO:
                return function(OO) {
                  var KO = new OO.constructor(OO.source, YO.exec(OO));
                  return KO.lastIndex = OO.lastIndex, KO
                }(OO);
              case VO:
                return function(OO, KO, pO) {
                  var XO = KO ? pO(xK(OO), !0) : xK(OO);
                  return BO(XO, cK, new OO.constructor)
                }(OO, XO, pO);
              case QO:
                return eO = OO, gp ? Object(gp.call(eO)) : {}
            }
            var eO
          }(OO, PO, PK, KO)
        }
      }
      zK || (zK = new YK);
      var sO = zK.get(OO);
      if (sO) return sO;
      if (zK.set(OO, wO), !iK) var HO = pO ? function(OO) {
        return function(OO, KO, pO) {
          var XO = KO(OO);
          return xp(OO) ? XO : function(OO, KO) {
            for (var pO = -1, XO = KO.length, bK = OO.length; ++pO < XO;) OO[bK + pO] = KO[pO];
            return OO
          }(XO, pO(OO))
        }(OO, UK, JK)
      }(OO) : UK(OO);
      return function(OO, KO) {
        for (var pO = -1, XO = OO ? OO.length : 0; ++pO < XO && !1 !== KO(OO[pO], pO, OO););
      }(HO || OO, (function(bK, eO) {
        HO && (bK = OO[eO = bK]), ip(wO, eO, PK(bK, KO, pO, XO, eO, OO, zK))
      })), wO
    }

    function mp(OO) {
      return !(!kp(OO) || (KO = OO, UO && UO in KO)) && (tp(OO) || ZO(OO) ? XK : wO).test(GK(OO));
      var KO
    }

    function sK(OO) {
      var KO = new OO.constructor(OO.byteLength);
      return new lK(KO).set(new lK(OO)), KO
    }

    function HK(OO, KO, pO, XO) {
      pO || (pO = {});
      for (var bK = -1, eO = KO.length; ++bK < eO;) {
        var lO = KO[bK],
          vK = XO ? XO(pO[lO], OO[lO], lO, pO, OO) : void 0;
        ip(pO, lO, void 0 === vK ? OO[lO] : vK)
      }
      return pO
    }

    function RK(OO, KO) {
      var pO = OO.__data__;
      return function(OO) {
        var KO = typeof OO;
        return "string" == KO || "number" == KO || "symbol" == KO || "boolean" == KO ? "__proto__" !== OO : null === OO
      }(KO) ? pO["string" == typeof KO ? "string" : "hash"] : pO.map
    }

    function SK(OO, KO) {
      var pO = function(OO, KO) {
        return null == OO ? void 0 : OO[KO]
      }(OO, KO);
      return mp(pO) ? pO : void 0
    }
    uK.prototype.clear = function() {
      this.__data__ = AK ? AK(null) : {}
    }, uK.prototype.delete = function(OO) {
      return this.has(OO) && delete this.__data__[OO]
    }, uK.prototype.get = function(OO) {
      var KO = this.__data__;
      if (AK) {
        var pO = KO[OO];
        return pO === XO ? void 0 : pO
      }
      return KK.call(KO, OO) ? KO[OO] : void 0
    }, uK.prototype.has = function(OO) {
      var KO = this.__data__;
      return AK ? void 0 !== KO[OO] : KK.call(KO, OO)
    }, uK.prototype.set = function(OO, KO) {
      return this.__data__[OO] = AK && void 0 === KO ? XO : KO, this
    }, EK.prototype.clear = function() {
      this.__data__ = []
    }, EK.prototype.delete = function(OO) {
      var KO = this.__data__,
        pO = rp(KO, OO);
      return !(pO < 0) && (pO == KO.length - 1 ? KO.pop() : DK.call(KO, pO, 1), !0)
    }, EK.prototype.get = function(OO) {
      var KO = this.__data__,
        pO = rp(KO, OO);
      return pO < 0 ? void 0 : KO[pO][1]
    }, EK.prototype.has = function(OO) {
      return rp(this.__data__, OO) > -1
    }, EK.prototype.set = function(OO, KO) {
      var pO = this.__data__,
        XO = rp(pO, OO);
      return XO < 0 ? pO.push([OO, KO]) : pO[XO][1] = KO, this
    }, jp.prototype.clear = function() {
      this.__data__ = {
        hash: new uK,
        map: new(VK || EK),
        string: new uK
      }
    }, jp.prototype.delete = function(OO) {
      return RK(this, OO).delete(OO)
    }, jp.prototype.get = function(OO) {
      return RK(this, OO).get(OO)
    }, jp.prototype.has = function(OO) {
      return RK(this, OO).has(OO)
    }, jp.prototype.set = function(OO, KO) {
      return RK(this, OO).set(OO, KO), this
    }, YK.prototype.clear = function() {
      this.__data__ = new EK
    }, YK.prototype.delete = function(OO) {
      return this.__data__.delete(OO)
    }, YK.prototype.get = function(OO) {
      return this.__data__.get(OO)
    }, YK.prototype.has = function(OO) {
      return this.__data__.has(OO)
    }, YK.prototype.set = function(OO, KO) {
      var pO = this.__data__;
      if (pO instanceof EK) {
        var XO = pO.__data__;
        if (!VK || XO.length < 199) return XO.push([OO, KO]), this;
        pO = this.__data__ = new jp(XO)
      }
      return pO.set(OO, KO), this
    };
    var JK = MK ? qK(MK, Object) : function() {
        return []
      },
      cp = function(OO) {
        return pK.call(OO)
      };

    function BK(OO, KO) {
      return !!(KO = null == KO ? bK : KO) && ("number" == typeof OO || iK.test(OO)) && OO > -1 && OO % 1 == 0 && OO < KO
    }

    function ZK(OO) {
      var KO = OO && OO.constructor;
      return OO === ("function" == typeof KO && KO.prototype || tK)
    }

    function GK(OO) {
      if (null != OO) {
        try {
          return OK.call(OO)
        } catch (KO) {}
        try {
          return OO + ""
        } catch (KO) {}
      }
      return ""
    }

    function qp(OO, KO) {
      return OO === KO || OO !== OO && KO !== KO
    }(FK && cp(new FK(new ArrayBuffer(1))) != fO || VK && cp(new VK) != DO || LK && cp(LK.resolve()) != oO || QK && cp(new QK) != VO || zp && cp(new zp) != zK) && (cp = function(OO) {
      var KO = pK.call(OO),
        pO = KO == aK ? OO.constructor : void 0,
        XO = pO ? GK(pO) : void 0;
      if (XO) switch (XO) {
        case fK:
          return fO;
        case dK:
          return DO;
        case TK:
          return oO;
        case NK:
          return VO;
        case IK:
          return zK
      }
      return KO
    });
    var xp = Array.isArray;

    function nK(OO) {
      return null != OO && function(OO) {
        return "number" == typeof OO && OO > -1 && OO % 1 == 0 && OO <= bK
      }(OO.length) && !tp(OO)
    }
    var WK = ap || function() {
      return !1
    };

    function tp(OO) {
      var KO = kp(OO) ? pK.call(OO) : "";
      return KO == CO || KO == hO
    }

    function kp(OO) {
      var KO = typeof OO;
      return !!OO && ("object" == KO || "function" == KO)
    }

    function UK(OO) {
      return nK(OO) ? wK(OO) : function(OO) {
        if (!ZK(OO)) return oK(OO);
        var KO = [];
        for (var pO in Object(OO)) KK.call(OO, pO) && "constructor" != pO && KO.push(pO);
        return KO
      }(OO)
    }
    OO.exports = function(OO) {
      return PK(OO, !0, !0)
    }
  },
  36093: (OO, KO, pO) => {
    var XO = pO(36095),
      bK = pO(36099),
      eO = "undefined" !== typeof Float64Array;

    function lO(OO, KO) {
      return OO[0] - KO[0]
    }

    function vK() {
      var OO, KO = this.stride,
        pO = new Array(KO.length);
      for (OO = 0; OO < pO.length; ++OO) pO[OO] = [Math.abs(KO[OO]), OO];
      pO.sort(lO);
      var XO = new Array(pO.length);
      for (OO = 0; OO < XO.length; ++OO) XO[OO] = pO[OO][1];
      return XO
    }

    function CO(OO, KO) {
      var pO = ["View", KO, "d", OO].join("");
      KO < 0 && (pO = "View_Nil" + OO);
      var bK = "generic" === OO;
      if (-1 === KO) {
        var eO = "function " + pO + "(a){this.data=a;};var proto=" + pO + ".prototype;proto.dtype='" + OO + "';proto.index=function(){return -1};proto.size=0;proto.dimension=-1;proto.shape=proto.stride=proto.order=[];proto.lo=proto.hi=proto.transpose=proto.step=function(){return new " + pO + "(this.data);};proto.get=proto.set=function(){};proto.pick=function(){return null};return function construct_" + pO + "(a){return new " + pO + "(a);}";
        return new Function(eO)()
      }
      if (0 === KO) {
        eO = "function " + pO + "(a,d) {this.data = a;this.offset = d};var proto=" + pO + ".prototype;proto.dtype='" + OO + "';proto.index=function(){return this.offset};proto.dimension=0;proto.size=1;proto.shape=proto.stride=proto.order=[];proto.lo=proto.hi=proto.transpose=proto.step=function " + pO + "_copy() {return new " + pO + "(this.data,this.offset)};proto.pick=function " + pO + "_pick(){return TrivialArray(this.data);};proto.valueOf=proto.get=function " + pO + "_get(){return " + (bK ? "this.data.get(this.offset)" : "this.data[this.offset]") + "};proto.set=function " + pO + "_set(v){return " + (bK ? "this.data.set(this.offset,v)" : "this.data[this.offset]=v") + "};return function construct_" + pO + "(a,b,c,d){return new " + pO + "(a,d)}";
        return new Function("TrivialArray", eO)(hO[OO][0])
      }
      eO = ["'use strict'"];
      var lO = XO(KO),
        CO = lO.map((function(OO) {
          return "i" + OO
        })),
        DO = "this.offset+" + lO.map((function(OO) {
          return "this.stride[" + OO + "]*i" + OO
        })).join("+"),
        MO = lO.map((function(OO) {
          return "b" + OO
        })).join(","),
        aK = lO.map((function(OO) {
          return "c" + OO
        })).join(",");
      eO.push("function " + pO + "(a," + MO + "," + aK + ",d){this.data=a", "this.shape=[" + MO + "]", "this.stride=[" + aK + "]", "this.offset=d|0}", "var proto=" + pO + ".prototype", "proto.dtype='" + OO + "'", "proto.dimension=" + KO), eO.push("Object.defineProperty(proto,'size',{get:function " + pO + "_size(){return " + lO.map((function(OO) {
        return "this.shape[" + OO + "]"
      })).join("*"), "}})"), 1 === KO ? eO.push("proto.order=[0]") : (eO.push("Object.defineProperty(proto,'order',{get:"), KO < 4 ? (eO.push("function " + pO + "_order(){"), 2 === KO ? eO.push("return (Math.abs(this.stride[0])>Math.abs(this.stride[1]))?[1,0]:[0,1]}})") : 3 === KO && eO.push("var s0=Math.abs(this.stride[0]),s1=Math.abs(this.stride[1]),s2=Math.abs(this.stride[2]);if(s0>s1){if(s1>s2){return [2,1,0];}else if(s0>s2){return [1,2,0];}else{return [1,0,2];}}else if(s0>s2){return [2,0,1];}else if(s2>s1){return [0,1,2];}else{return [0,2,1];}}})")) : eO.push("ORDER})")), eO.push("proto.set=function " + pO + "_set(" + CO.join(",") + ",v){"), bK ? eO.push("return this.data.set(" + DO + ",v)}") : eO.push("return this.data[" + DO + "]=v}"), eO.push("proto.get=function " + pO + "_get(" + CO.join(",") + "){"), bK ? eO.push("return this.data.get(" + DO + ")}") : eO.push("return this.data[" + DO + "]}"), eO.push("proto.index=function " + pO + "_index(", CO.join(), "){return " + DO + "}"), eO.push("proto.hi=function " + pO + "_hi(" + CO.join(",") + "){return new " + pO + "(this.data," + lO.map((function(OO) {
        return ["(typeof i", OO, "!=='number'||i", OO, "<0)?this.shape[", OO, "]:i", OO, "|0"].join("")
      })).join(",") + "," + lO.map((function(OO) {
        return "this.stride[" + OO + "]"
      })).join(",") + ",this.offset)}");
      var oO = lO.map((function(OO) {
          return "a" + OO + "=this.shape[" + OO + "]"
        })),
        FO = lO.map((function(OO) {
          return "c" + OO + "=this.stride[" + OO + "]"
        }));
      eO.push("proto.lo=function " + pO + "_lo(" + CO.join(",") + "){var b=this.offset,d=0," + oO.join(",") + "," + FO.join(","));
      for (var VO = 0; VO < KO; ++VO) eO.push("if(typeof i" + VO + "==='number'&&i" + VO + ">=0){d=i" + VO + "|0;b+=c" + VO + "*d;a" + VO + "-=d}");
      eO.push("return new " + pO + "(this.data," + lO.map((function(OO) {
        return "a" + OO
      })).join(",") + "," + lO.map((function(OO) {
        return "c" + OO
      })).join(",") + ",b)}"), eO.push("proto.step=function " + pO + "_step(" + CO.join(",") + "){var " + lO.map((function(OO) {
        return "a" + OO + "=this.shape[" + OO + "]"
      })).join(",") + "," + lO.map((function(OO) {
        return "b" + OO + "=this.stride[" + OO + "]"
      })).join(",") + ",c=this.offset,d=0,ceil=Math.ceil");
      for (VO = 0; VO < KO; ++VO) eO.push("if(typeof i" + VO + "==='number'){d=i" + VO + "|0;if(d<0){c+=b" + VO + "*(a" + VO + "-1);a" + VO + "=ceil(-a" + VO + "/d)}else{a" + VO + "=ceil(a" + VO + "/d)}b" + VO + "*=d}");
      eO.push("return new " + pO + "(this.data," + lO.map((function(OO) {
        return "a" + OO
      })).join(",") + "," + lO.map((function(OO) {
        return "b" + OO
      })).join(",") + ",c)}");
      var LO = new Array(KO),
        QO = new Array(KO);
      for (VO = 0; VO < KO; ++VO) LO[VO] = "a[i" + VO + "]", QO[VO] = "b[i" + VO + "]";
      eO.push("proto.transpose=function " + pO + "_transpose(" + CO + "){" + CO.map((function(OO, KO) {
        return OO + "=(" + OO + "===undefined?" + KO + ":" + OO + "|0)"
      })).join(";"), "var a=this.shape,b=this.stride;return new " + pO + "(this.data," + LO.join(",") + "," + QO.join(",") + ",this.offset)}"), eO.push("proto.pick=function " + pO + "_pick(" + CO + "){var a=[],b=[],c=this.offset");
      for (VO = 0; VO < KO; ++VO) eO.push("if(typeof i" + VO + "==='number'&&i" + VO + ">=0){c=(c+this.stride[" + VO + "]*i" + VO + ")|0}else{a.push(this.shape[" + VO + "]);b.push(this.stride[" + VO + "])}");
      return eO.push("var ctor=CTOR_LIST[a.length+1];return ctor(this.data,a,b,c)}"), eO.push("return function construct_" + pO + "(data,shape,stride,offset){return new " + pO + "(data," + lO.map((function(OO) {
        return "shape[" + OO + "]"
      })).join(",") + "," + lO.map((function(OO) {
        return "stride[" + OO + "]"
      })).join(",") + ",offset)}"), new Function("CTOR_LIST", "ORDER", eO.join("\n"))(hO[OO], vK)
    }
    var hO = {
      float32: [],
      float64: [],
      int8: [],
      int16: [],
      int32: [],
      uint8: [],
      uint16: [],
      uint32: [],
      array: [],
      uint8_clamped: [],
      bigint64: [],
      biguint64: [],
      buffer: [],
      generic: []
    };
    OO.exports = function(OO, KO, pO, XO) {
      if (void 0 === OO) return (0, hO.array[0])([]);
      "number" === typeof OO && (OO = [OO]), void 0 === KO && (KO = [OO.length]);
      var lO = KO.length;
      if (void 0 === pO) {
        pO = new Array(lO);
        for (var vK = lO - 1, DO = 1; vK >= 0; --vK) pO[vK] = DO, DO *= KO[vK]
      }
      if (void 0 === XO) {
        XO = 0;
        for (vK = 0; vK < lO; ++vK) pO[vK] < 0 && (XO -= (KO[vK] - 1) * pO[vK])
      }
      for (var MO = function(OO) {
          if (bK(OO)) return "buffer";
          if (eO) switch (Object.prototype.toString.call(OO)) {
            case "[object Float64Array]":
              return "float64";
            case "[object Float32Array]":
              return "float32";
            case "[object Int8Array]":
              return "int8";
            case "[object Int16Array]":
              return "int16";
            case "[object Int32Array]":
              return "int32";
            case "[object Uint8Array]":
              return "uint8";
            case "[object Uint16Array]":
              return "uint16";
            case "[object Uint32Array]":
              return "uint32";
            case "[object Uint8ClampedArray]":
              return "uint8_clamped";
            case "[object BigInt64Array]":
              return "bigint64";
            case "[object BigUint64Array]":
              return "biguint64"
          }
          return Array.isArray(OO) ? "array" : "generic"
        }(OO), aK = hO[MO]; aK.length <= lO + 1;) aK.push(CO(MO, aK.length - 1));
      return (0, aK[lO + 1])(OO, KO, pO, XO)
    }
  },
  36844: OO => {
    function KO(OO, KO, pO) {
      for (var XO = OO.length, bK = -1 / 0, eO = 1 / 0, lO = 0; lO < XO; lO++) {
        var vK = (pO[0][lO] - OO[lO]) / KO[lO],
          CO = (pO[1][lO] - OO[lO]) / KO[lO];
        if (vK > CO) {
          var hO = vK;
          vK = CO, CO = hO
        }
        if (CO < bK || vK > eO) return 1 / 0;
        vK > bK && (bK = vK), CO < eO && (eO = CO)
      }
      return bK > eO ? 1 / 0 : bK
    }
    OO.exports = function(OO, pO, XO, bK) {
      var eO = KO(pO, XO, bK);
      if (eO === 1 / 0) OO = null;
      else {
        OO = OO || [];
        for (var lO = 0; lO < pO.length; lO++) OO[lO] = pO[lO] + XO[lO] * eO
      }
      return OO
    }, OO.exports.distance = KO
  },
  36111: (OO, KO, pO) => {
    var XO = pO(36117);

    function bK(OO) {
      for (var KO, pO, bK = 0, eO = OO.length, lO = 0; lO < OO.length;) {
        for (KO = OO[lO], pO = 0; lO < eO && OO[lO] === KO;) ++lO, ++pO;
        bK += XO.log2(pO) / 7 | 0, bK += XO.log2(KO >>> 0) / 7 | 0, bK += 2
      }
      return bK
    }
    KO.size = bK, KO.encode = function(OO, KO) {
      KO || (KO = new Uint8Array(bK(OO)));
      for (var pO, XO, eO = 0, lO = KO.length, vK = 0; vK < OO.length;) {
        for (pO = OO[vK], XO = 0; vK < OO.length && OO[vK] === pO;) ++vK, ++XO;
        for (; eO < lO && XO >= 128;) KO[eO++] = 128 + (127 & XO), XO >>>= 7;
        if (eO >= lO) throw new Error("RLE buffer overflow");
        for (KO[eO++] = XO, pO >>>= 0; eO < lO && pO >= 128;) KO[eO++] = 128 + (127 & pO), pO >>>= 7;
        if (eO >= lO) throw new Error("RLE buffer overflow");
        KO[eO++] = pO
      }
      return KO
    }, KO.decode = function(OO, KO) {
      for (var pO, XO, bK, eO, lO = KO.length, vK = OO.length, CO = 0, hO = 0; hO < vK;) {
        for (pO = 0, XO = 0; hO < vK && OO[hO] >= 128;) pO += (127 & OO[hO++]) << XO, XO += 7;
        if (pO += OO[hO++] << XO, hO >= vK) throw new Error("RLE buffer underrun");
        if (CO + pO > lO) throw new Error("Chunk buffer overflow");
        for (bK = 0, XO = 0; hO < vK && OO[hO] >= 128;) bK += (127 & OO[hO++]) << XO, XO += 7;
        if (hO >= vK) throw new Error("RLE buffer underrun");
        for (bK += OO[hO++] << XO, eO = 0; eO < pO; ++eO) KO[CO++] = bK
      }
      return KO
    }
  },
  36117: (OO, KO) => {
    function pO(OO) {
      var KO = 32;
      return (OO &= -OO) && KO--, 65535 & OO && (KO -= 16), 16711935 & OO && (KO -= 8), 252645135 & OO && (KO -= 4), 858993459 & OO && (KO -= 2), 1431655765 & OO && (KO -= 1), KO
    }
    KO.INT_BITS = 32, KO.INT_MAX = 2147483647, KO.INT_MIN = -1 << 31, KO.sign = function(OO) {
      return (OO > 0) - (OO < 0)
    }, KO.abs = function(OO) {
      var KO = OO >> 31;
      return (OO ^ KO) - KO
    }, KO.min = function(OO, KO) {
      return KO ^ (OO ^ KO) & -(OO < KO)
    }, KO.max = function(OO, KO) {
      return OO ^ (OO ^ KO) & -(OO < KO)
    }, KO.isPow2 = function(OO) {
      return !(OO & OO - 1) && !!OO
    }, KO.log2 = function(OO) {
      var KO, pO;
      return KO = (OO > 65535) << 4, KO |= pO = ((OO >>>= KO) > 255) << 3, KO |= pO = ((OO >>>= pO) > 15) << 2, (KO |= pO = ((OO >>>= pO) > 3) << 1) | (OO >>>= pO) >> 1
    }, KO.log10 = function(OO) {
      return OO >= 1e9 ? 9 : OO >= 1e8 ? 8 : OO >= 1e7 ? 7 : OO >= 1e6 ? 6 : OO >= 1e5 ? 5 : OO >= 1e4 ? 4 : OO >= 1e3 ? 3 : OO >= 100 ? 2 : OO >= 10 ? 1 : 0
    }, KO.popCount = function(OO) {
      return 16843009 * ((OO = (858993459 & (OO -= OO >>> 1 & 1431655765)) + (OO >>> 2 & 858993459)) + (OO >>> 4) & 252645135) >>> 24
    }, KO.countTrailingZeros = pO, KO.nextPow2 = function(OO) {
      return OO += 0 === OO, --OO, OO |= OO >>> 1, OO |= OO >>> 2, OO |= OO >>> 4, OO |= OO >>> 8, (OO |= OO >>> 16) + 1
    }, KO.prevPow2 = function(OO) {
      return OO |= OO >>> 1, OO |= OO >>> 2, OO |= OO >>> 4, OO |= OO >>> 8, (OO |= OO >>> 16) - (OO >>> 1)
    }, KO.parity = function(OO) {
      return OO ^= OO >>> 16, OO ^= OO >>> 8, OO ^= OO >>> 4, 27030 >>> (OO &= 15) & 1
    };
    var XO = new Array(256);
    ! function(OO) {
      for (var KO = 0; KO < 256; ++KO) {
        var pO = KO,
          XO = KO,
          bK = 7;
        for (pO >>>= 1; pO; pO >>>= 1) XO <<= 1, XO |= 1 & pO, --bK;
        OO[KO] = XO << bK & 255
      }
    }(XO), KO.reverse = function(OO) {
      return XO[255 & OO] << 24 | XO[OO >>> 8 & 255] << 16 | XO[OO >>> 16 & 255] << 8 | XO[OO >>> 24 & 255]
    }, KO.interleave2 = function(OO, KO) {
      return (OO = 1431655765 & ((OO = 858993459 & ((OO = 252645135 & ((OO = 16711935 & ((OO &= 65535) | OO << 8)) | OO << 4)) | OO << 2)) | OO << 1)) | (KO = 1431655765 & ((KO = 858993459 & ((KO = 252645135 & ((KO = 16711935 & ((KO &= 65535) | KO << 8)) | KO << 4)) | KO << 2)) | KO << 1)) << 1
    }, KO.deinterleave2 = function(OO, KO) {
      return (OO = 65535 & ((OO = 16711935 & ((OO = 252645135 & ((OO = 858993459 & ((OO = OO >>> KO & 1431655765) | OO >>> 1)) | OO >>> 2)) | OO >>> 4)) | OO >>> 16)) << 16 >> 16
    }, KO.interleave3 = function(OO, KO, pO) {
      return OO = 1227133513 & ((OO = 3272356035 & ((OO = 251719695 & ((OO = 4278190335 & ((OO &= 1023) | OO << 16)) | OO << 8)) | OO << 4)) | OO << 2), (OO |= (KO = 1227133513 & ((KO = 3272356035 & ((KO = 251719695 & ((KO = 4278190335 & ((KO &= 1023) | KO << 16)) | KO << 8)) | KO << 4)) | KO << 2)) << 1) | (pO = 1227133513 & ((pO = 3272356035 & ((pO = 251719695 & ((pO = 4278190335 & ((pO &= 1023) | pO << 16)) | pO << 8)) | pO << 4)) | pO << 2)) << 2
    }, KO.deinterleave3 = function(OO, KO) {
      return (OO = 1023 & ((OO = 4278190335 & ((OO = 251719695 & ((OO = 3272356035 & ((OO = OO >>> KO & 1227133513) | OO >>> 2)) | OO >>> 4)) | OO >>> 8)) | OO >>> 16)) << 22 >> 22
    }, KO.nextCombination = function(OO) {
      var KO = OO | OO - 1;
      return KO + 1 | (~KO & -~KO) - 1 >>> pO(OO) + 1
    }
  },
  35680: (OO, KO, pO) => {
    pO.d(KO, {
      Color3: () => XO.e,
      c: () => XO.g
    });
    var XO = pO(35688);
    (0, XO.h)()
  },
  36142: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => bK
    });
    var XO = pO(36146);
    class bK {
      static GetPlanes(OO) {
        const KO = [];
        for (let pO = 0; pO < 6; pO++) KO.push(new XO.d(0, 0, 0, 0));
        return bK.GetPlanesToRef(OO, KO), KO
      }
      static GetNearPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[2], KO.normal.y = pO[7] + pO[6], KO.normal.z = pO[11] + pO[10], KO.d = pO[15] + pO[14], KO.normalize()
      }
      static GetFarPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[2], KO.normal.y = pO[7] - pO[6], KO.normal.z = pO[11] - pO[10], KO.d = pO[15] - pO[14], KO.normalize()
      }
      static GetLeftPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[0], KO.normal.y = pO[7] + pO[4], KO.normal.z = pO[11] + pO[8], KO.d = pO[15] + pO[12], KO.normalize()
      }
      static GetRightPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[0], KO.normal.y = pO[7] - pO[4], KO.normal.z = pO[11] - pO[8], KO.d = pO[15] - pO[12], KO.normalize()
      }
      static GetTopPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] - pO[1], KO.normal.y = pO[7] - pO[5], KO.normal.z = pO[11] - pO[9], KO.d = pO[15] - pO[13], KO.normalize()
      }
      static GetBottomPlaneToRef(OO, KO) {
        const pO = OO.m;
        KO.normal.x = pO[3] + pO[1], KO.normal.y = pO[7] + pO[5], KO.normal.z = pO[11] + pO[9], KO.d = pO[15] + pO[13], KO.normalize()
      }
      static GetPlanesToRef(OO, KO) {
        bK.GetNearPlaneToRef(OO, KO[0]), bK.GetFarPlaneToRef(OO, KO[1]), bK.GetLeftPlaneToRef(OO, KO[2]), bK.GetRightPlaneToRef(OO, KO[3]), bK.GetTopPlaneToRef(OO, KO[4]), bK.GetBottomPlaneToRef(OO, KO[5])
      }
      static IsPointInFrustum(OO, KO) {
        for (let pO = 0; pO < 6; pO++)
          if (KO[pO].dotCoordinate(OO) < 0) return !1;
        return !0
      }
    }
  },
  36146: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    var XO = pO(35632);
    class bK {
      constructor(OO, KO, pO, bK) {
        this.normal = new XO.o(OO, KO, pO), this.d = bK
      }
      WhO() {
        return [this.normal.x, this.normal.y, this.normal.z, this.d]
      }
      clone() {
        return new bK(this.normal.x, this.normal.y, this.normal.z, this.d)
      }
      getClassName() {
        return "Plane"
      }
      getHashCode() {
        let OO = this.normal.getHashCode();
        return OO = 397 * OO ^ this.d, OO
      }
      normalize() {
        const OO = Math.sqrt(this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z);
        let KO = 0;
        return 0 !== OO && (KO = 1 / OO), this.normal.x *= KO, this.normal.y *= KO, this.normal.z *= KO, this.d *= KO, this
      }
      transform(OO) {
        const KO = bK._TmpMatrix;
        OO.invertToRef(KO);
        const pO = KO.m,
          XO = this.normal.x,
          eO = this.normal.y,
          lO = this.normal.z,
          vK = this.d,
          CO = XO * pO[0] + eO * pO[1] + lO * pO[2] + vK * pO[3],
          hO = XO * pO[4] + eO * pO[5] + lO * pO[6] + vK * pO[7],
          DO = XO * pO[8] + eO * pO[9] + lO * pO[10] + vK * pO[11],
          MO = XO * pO[12] + eO * pO[13] + lO * pO[14] + vK * pO[15];
        return new bK(CO, hO, DO, MO)
      }
      dotCoordinate(OO) {
        return this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z + this.d
      }
      copyFromPoints(OO, KO, pO) {
        const XO = KO.x - OO.x,
          bK = KO.y - OO.y,
          eO = KO.z - OO.z,
          lO = pO.x - OO.x,
          vK = pO.y - OO.y,
          CO = pO.z - OO.z,
          hO = bK * CO - eO * vK,
          DO = eO * lO - XO * CO,
          MO = XO * vK - bK * lO,
          aK = Math.sqrt(hO * hO + DO * DO + MO * MO);
        let oO;
        return oO = 0 !== aK ? 1 / aK : 0, this.normal.x = hO * oO, this.normal.y = DO * oO, this.normal.z = MO * oO, this.d = -(this.normal.x * OO.x + this.normal.y * OO.y + this.normal.z * OO.z), this
      }
      isFrontFacingTo(OO, KO) {
        return XO.o.Dot(this.normal, OO) <= KO
      }
      signedDistanceTo(OO) {
        return XO.o.Dot(OO, this.normal) + this.d
      }
      static FromArray(OO) {
        return new bK(OO[0], OO[1], OO[2], OO[3])
      }
      static FromPoints(OO, KO, pO) {
        const XO = new bK(0, 0, 0, 0);
        return XO.copyFromPoints(OO, KO, pO), XO
      }
      static FromPositionAndNormal(OO, KO) {
        const pO = new bK(0, 0, 0, 0);
        return this.FromPositionAndNormalToRef(OO, KO, pO)
      }
      static FromPositionAndNormalToRef(OO, KO, pO) {
        return pO.normal.NhO(KO), pO.normal.normalize(), pO.d = -OO.dot(pO.normal), pO
      }
      static SignedDistanceToPlaneFromPositionAndNormal(OO, KO, pO) {
        const bK = -(KO.x * OO.x + KO.y * OO.y + KO.z * OO.z);
        return XO.o.Dot(pO, KO) + bK
      }
    }
    bK._TmpMatrix = XO.c.Identity()
  },
  35624: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      Matrix: () => XO.c,
      Quaternion: () => XO.g,
      RegisterMathVector: () => XO.i,
      TmpVectors: () => XO.j,
      Vector2: () => XO.m,
      WX: () => XO.o,
      Vector4: () => XO.s
    });
    var XO = pO(35632);
    (0, XO.i)()
  },
  36513: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => XO
    });
    class XO {
      constructor(OO, KO, pO, XO) {
        this.x = OO, this.y = KO, this.width = pO, this.height = XO
      }
      toGlobal(OO, KO) {
        return new XO(this.x * OO, this.y * KO, this.width * OO, this.height * KO)
      }
      toGlobalToRef(OO, KO, pO) {
        return pO.x = this.x * OO, pO.y = this.y * KO, pO.width = this.width * OO, pO.height = this.height * KO, this
      }
      clone() {
        return new XO(this.x, this.y, this.width, this.height)
      }
    }
  },
  36274: (OO, KO, pO) => {
    function XO() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (OO => {
        const KO = 16 * Math.random() | 0;
        return ("x" === OO ? KO : 3 & KO | 8).toString(16)
      }))
    }
    pO.d(KO, {
      b: () => XO
    })
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);