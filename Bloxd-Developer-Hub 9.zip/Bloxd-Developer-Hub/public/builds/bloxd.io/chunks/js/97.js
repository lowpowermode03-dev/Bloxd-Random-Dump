export const id = 97;
export const ids = [97];
export const modules = {
  7956: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => hK
    });
    var XO = pO(1355),
      bK = pO(22),
      eO = pO(3821),
      lO = pO(63),
      vK = pO(1263);
    var CO = pO(1556),
      hO = pO(1344),
      DO = pO(1187),
      MO = pO(1051),
      aK = pO(3812);
    const oO = {
      private: "customLobby:cantJoinPrivate",
      notWhitelisted: "customLobby:cantJoinNotWhitelisted",
      banned: "customLobby:cantJoinBanned",
      adminLocked: "customLobby:cantJoinAdminLocked"
    };
    var FO = pO(3764),
      VO = pO(149),
      LO = pO(1008),
      QO = pO(26),
      zK = pO(1104),
      AO = pO(1481),
      fO = pO(1152),
      dO = pO(1253),
      TO = pO(3712),
      NO = pO(3606),
      IO = pO(94),
      yK = pO(2536),
      gK = pO(976);
    const uO = "https://discord.gg/playbloxd";

    function EO(OO) {
      let {
        failure: KO
      } = OO;
      const {
        t: pO
      } = (0, MO.D)(), XO = "chosen" === KO.packSource, bK = IO.featureFlags.useDiscord ? XO ? "texturePackLoad:failedHelpCustomPack" : "texturePackLoad:failedHelp" : XO ? "texturePackLoad:failedHelpCustomPackNoDiscord" : "texturePackLoad:failedHelpNoDiscord";
      return (0, gK.jsxs)(gK.Fragment, {
        children: [pO(bK, {
          code: KO.code
        }), "default" !== KO.packSource && KO.code === yK.h.Error && (0, gK.jsxs)("div", {
          style: {
            paddingTop: "1rem",
            overflowWrap: "anywhere"
          },
          children: [pO("texturePackLoad:details"), " ", KO.reason]
        }), IO.featureFlags.useDiscord && (0, gK.jsx)("div", {
          style: {
            paddingTop: "1rem"
          },
          children: (0, gK.jsx)("a", {
            href: uO,
            target: "_blank",
            rel: "noreferrer",
            children: pO("texturePackLoad:reportOnDiscord")
          })
        })]
      })
    }
    var jK = pO(1918),
      YO = pO(1165),
      wO = pO(638),
      iK = pO(1086),
      rK = pO(886),
      PO = pO(1329),
      mK = pO(1077),
      sO = pO(2571),
      HO = pO(2446),
      RO = pO(1193),
      SO = pO(1180),
      JO = pO(4111),
      cK = pO(7961),
      BO = pO(2314);

    function ZO(OO) {
      let {
        onApply: KO,
        onSkip: pO
      } = OO;
      const {
        t: XO
      } = (0, MO.D)();
      return (0, lO.useEffect)((() => {
        BO.g.skipPlayWait()
      }), []), (0, gK.jsx)(RO.i, {
        icon: "download",
        title: "customTexturePack:downloadTitle",
        subtitle: (0, gK.jsxs)("div", {
          className: "CustomTexturePackDownloaderSubtitleText",
          children: [XO("customTexturePack:downloadPrompt"), (0, gK.jsx)("div", {
            className: "CustomTexturePackDownloaderWarningText",
            children: XO("customTexturePack:authorWarning")
          }), (0, gK.jsx)("div", {
            className: "CustomTexturePackDownloaderSecondaryText",
            children: XO("customTexturePack:existingPackSaved")
          })]
        }),
        confirm: {
          text: "general:apply",
          onClick: KO
        },
        cancel: {
          text: "customTexturePack:skip",
          onClick: pO
        }
      })
    }
    async function GO() {
      let OO = !1;
      const KO = DO.NotificationProvider.showCustomPopup({
        body: KO => (0, gK.jsx)(ZO, {
          onApply: () => {
            OO = !0, KO()
          },
          onSkip: KO
        }),
        disableExitButton: !0,
        disablePressBackgroundToClose: !0
      });
      return await KO.getResult(), OO
    }
    let qK = {
      wanted: !1
    };
    let xK = null;

    function nO(OO) {
      OO.setGamePackConfirm(GO), xK = OO
    }
    var WO = pO(2737);

    function tK(OO) {
      let {
        schematicId: KO,
        texturePackKey: pO,
        onClose: XO
      } = OO;
      const [bK, eO] = (0, lO.useState)("prompt"), [vK, CO] = (0, lO.useState)(null), hO = (0, WO.b)();

      function DO() {
        XO()
      }
      return "prompt" === bK ? (0, gK.jsx)(ZO, {
        onApply: async function() {
          eO("downloading");
          try {
            const OO = await async function(OO, KO) {
              const pO = await (0, JO.c)(KO);
              if (pO) return {
                pack: pO,
                key: KO
              };
              const XO = await LO.userContextManager.getCurrentUserContext(),
                bK = (await PO.c.getGame(XO, OO, !0)).customTexturePackKey;
              if (!bK) return null;
              const eO = await (0, JO.c)(bK);
              if (!eO) throw new Error("The texture pack could not be found");
              return {
                pack: eO,
                key: bK
              }
            }(KO, pO);
            if (!hO.current) return;
            if (!OO) return void XO();
            if ((0, sO.j)(OO.pack)) return void eO("refused");
            HO.c.setFromJson(OO.pack, "customGame"), await HO.c.saveTemporaryTexturePack(OO.key), hO.current && (0, AO.reloadBloxd)()
          } catch (OO) {
            CO(OO instanceof Error ? OO.message : String(OO)), eO("error")
          }
        },
        onSkip: DO
      }) : "downloading" === bK ? (0, gK.jsx)(RO.i, {
        icon: "download",
        title: "customTexturePack:downloading",
        subtitle: (0, gK.jsx)("div", {
          className: "CustomTexturePackDownloaderLogoLoaderContainer",
          children: (0, gK.jsx)(SO.e, {
            showFace: !0
          })
        })
      }) : "error" === bK ? (0, gK.jsx)(RO.i, {
        icon: "face-worried",
        title: "customTexturePack:errorTitle",
        subtitle: vK,
        confirm: {
          text: "customTexturePack:refreshPage",
          onClick: () => {
            window.location.reload()
          }
        },
        cancel: {
          text: "customTexturePack:skip",
          onClick: DO
        }
      }) : "refused" === bK ? (0, gK.jsx)(RO.i, {
        icon: "face-worried",
        title: "customTexturePack:cantApplyTitle",
        subtitle: "customTexturePack:gamePackHasExternalUrls",
        confirm: {
          text: "general:continue",
          onClick: DO
        }
      }) : null
    }
    var kK = pO(7970),
      UO = pO(3581),
      OK = pO(1500),
      KK = pO(2516),
      pK = pO(2704),
      XK = pO(3846),
      bp = pO(1146),
      eK = pO(554),
      lK = pO(588);

    function vp() {
      const OO = bK.d.get("clientEscMenuOptions");
      CO.gameBridge.send("setLookSensitivity", bK.d.get("isTouchScreen") ? (0, lK.l)(OO) : OO.mouseSensitivity)
    }
    async function CK(OO, KO, pO) {
      const XO = (0, XK.G)(KO);
      async function lO(OO, KO, pO, XO) {
        var lO;
        if (XO.aborted) return null;
        null === bK.d.get("gameEntrySource") && (0, bK.j)("directPlayUrl"), eK.s && (0, cK.c)().catch((() => {})), bK.d.set({
          gameState: "findingLobby"
        }), QO.i.pl("loadingScreenState", "loadingPage:findingLobby");
        const vK = await LO.userContextManager.getCurrentUserContext();
        CO.gameBridge.send("setRequestedGame", {
          gameNameWithVariation: KO,
          discordContext: OO instanceof iK.d ? OO.getSerialisableParams() : null
        }), (0, OK.b)();
        const hO = await async function(OO, KO, pO, XO, bK) {
          try {
            await eO.reqLibsLoadedPromise
          } catch (lO) {
            return zK.c.errorWithCode(lO.toString(), VO.f.LOAD_REQUIRED_LIBS, {
              error: lO,
              severity: "medium"
            })
          }
          return QO.i.pl("matchmakeAndPlayStepCompleted", {
            step: VO.f.LOAD_REQUIRED_LIBS,
            totalSubSteps: 1
          }), (0, eO.matchmakeAndPlayMaybeUnloaded)(OO, KO, pO, XO, bK)
        }(OO, KO, pO, vK, XO), DO = hO.isError() ? hO.asError() : null;
        if (DO && !DO.debugResult.dl && (console.log("Failed to join lobby:", DO.message), (0, KK.i)("matchmake_failed", DO.message, VO.f[DO.code])), XO.aborted) return CO.gameBridge.send("leaveGame", {
          reloadPath: null
        }), null;
        if (null !== DO && void 0 !== DO && DO.debugResult.dl) return console.log("Join cancelled:", DO.message), null;
        if (DO) return hO;
        const {
          gameNameWithVariation: MO,
          lobbyName: aK,
          addLobbyToRecentlyPlayed: oO
        } = hO.getValue();
        let FO;
        vp(), (0, bp.v)().setGameViewShown(!0);
        const AO = null === (lO = wO.e[MO]) || void 0 === lO ? void 0 : lO.recentlyPlayedAs;
        return FO = (0, rK.k)(MO) ? {
          type: "custom",
          name: "",
          schematicId: (0, rK.o)(MO),
          recentLobbies: []
        } : "classic" !== MO || (0, mK.J)(aK) ? AO ? {
          type: "bloxd",
          gameNameWithVariation: AO,
          recentLobbies: []
        } : {
          type: "bloxd",
          gameNameWithVariation: MO,
          recentLobbies: []
        } : {
          type: "bloxd",
          gameNameWithVariation: "classic_worlds",
          recentLobbies: []
        }, PO.c.addRecentlyPlayedGame(vK, FO, oO && !AO ? aK : void 0).then((OO => {
          vK.setRecentlyPlayedGames(OO)
        })).catch((OO => {
          console.error("Failed to record recently played game", OO)
        })), (0, fO.ab)(), hO
      }
      return XO && (0, bK.j)("updateRejoin"), (0, pK.g)((async bK => {
        try {
          let vK = OO,
            CO = await lO(vK, KO, pO, bK);
          for (let OO = 0; XO && OO < XK.i; OO++) {
            var eO;
            if (null === (eO = CO) || void 0 === eO || !eO.isError() || CO.asError().code !== VO.f.REQUEST_TO_MATCHMAKING) break;
            if (!await (0, XK.K)((0, XK.r)(OO), bK)) return CO;
            vK = (0, XK.v)(vK, OO + 1, "string" === typeof vK && (0, mK.J)(vK)), CO = await lO(vK, KO, pO, bK)
          }
          return CO
        } catch (vK) {
          if ((0, KK.i)("matchmake_failed", vK, "unexpected"), CO.gameBridge.send("leaveGame", {
              reloadPath: bK.aborted ? null : "/"
            }), bK.aborted) return null;
          throw vK
        }
      }), (async OO => {
        var pO;
        if (XO) return;
        const bK = (0, fO.P)();
        null !== bK && (await bK, OO.aborted) || (null !== (pO = wO.e[KO]) && void 0 !== pO && pO.playAdBeforeMatchmaking ? (BO.g.skipPlayWait(), await new Promise((OO => {
          (0, fO.qb)((() => {
            OO(!0)
          }), "video_start")
        }))) : (0, fO.qb)((() => {}), "video_start"))
      }))
    }

    function hK() {
      const {
        t: OO
      } = (0, MO.D)(), KO = (0, hO.useNavigatePreserveSearch)(), pO = (0, XO.p)(), QO = (0, XO.w)(), zK = (0, lO.useRef)({
        t: OO,
        navigate: KO
      });
      zK.current = {
        t: OO,
        navigate: KO
      };
      const {
        gameState: IO,
        clientEscMenuOptions: uO
      } = (0, bK.l)(["gameState", "clientEscMenuOptions"]), wO = (0, lO.useRef)(null), iK = (0, lO.useRef)(null);
      var sO;
      (0, pK.k)(), (0, pK.l)(), sO = eK.s, (0, lO.useEffect)((() => {
        if (!sO) return;
        let OO = !0;
        return (0, cK.c)().then((KO => {
          OO && nO(KO)
        })).catch((() => {})), () => {
          var KO;
          OO = !1, qK.wanted = !1, null === (KO = xK) || void 0 === KO || KO.setGamePackConfirm(null), xK = null
        }
      }), [sO]), (0, lO.useEffect)((() => {
        var OO;
        (0, eO.needGameClientNow)();
        const {
          t: KO,
          navigate: XO
        } = zK.current, lO = (0, kK.e)(QO, pO.search);
        if (QO.lobbyName && !new URLSearchParams(pO.search).has("lobby")) return void XO((0, YO.b)(lO.gameNameWithVariation, lO.lobbyName), {
          replace: !0
        });
        let vK = Promise.resolve({
          shouldMatchmake: !0
        });
        if ("/play/discord-custom-lobby" === pO.pathname) {
          const OO = bK.d.get("discordContext");
          if (!OO) return void XO("/");
          vK = FO.e.setupDiscordLobby(OO, "classic").then((() => ({
            shouldMatchmake: !0,
            discordContext: OO
          }))).catch((KO => (console.error("Failed to setup discord lobby", KO), {
            shouldMatchmake: !1,
            discordContext: OO
          })))
        } else if (!lO.gameNameWithVariation || !(0, mK.H)(lO.gameNameWithVariation)) return console.error(`Valid game name with variation is required. Received ${lO.gameNameWithVariation}`), void XO(-1);
        if (lO.gameNameWithVariation === wO.current && lO.lobbyName === iK.current) return;
        if (CO.gameBridge.latest("connectedGame").replay) return void(0, pK.e)(null);
        (0, fO.W)(), bK.d.set({
          gameState: "loadingScreen"
        });
        const hO = function() {
          qK.wanted = !1;
          const OO = {
            wanted: !0
          };
          return qK = OO, () => OO.wanted
        }();
        if ("releaseCountdown" === (null === (OO = (0, jK.e)(lO.gameNameWithVariation)) || void 0 === OO ? void 0 : OO.type)) return console.error(`Game hasn't been released yet: ${lO.gameNameWithVariation}`), void XO(-1);
        const MO = lO.gameNameWithVariation;
        if (MO && (eK.s || (0, rK.k)(MO))) {
          const OO = eK.s ? Promise.all([(0, cK.c)(), LO.userContextManager.getCurrentUserContext()]).then((OO => {
            let [KO, pO] = OO;
            if (hO()) return nO(KO), KO.packForGame(MO, pO, hO)
          })) : async function(OO) {
            await HO.c.indexedDbValuesAreLoaded();
            const KO = await LO.userContextManager.getCurrentUserContext(),
              pO = (0, rK.o)(OO);
            let XO;
            try {
              XO = await PO.c.getGame(KO, pO, !0)
            } catch (lO) {
              return void console.error("Failed to get game", lO)
            }
            const bK = XO.customTexturePackKey;
            if (!bK) return void(HO.c.isUsingTemporaryTexturePack() && ((0, AO.reloadBloxd)(), await new Promise((() => {}))));
            if (HO.c.isUsingTemporaryTexturePack() && HO.c.getTemporaryTexturePackSource() === bK) return;
            const eO = DO.NotificationProvider.showCustomPopup({
              body: OO => (0, gK.jsx)(tK, {
                schematicId: pO,
                texturePackKey: bK,
                onClose: OO
              }),
              disableExitButton: !0,
              disablePressBackgroundToClose: !0
            });
            await eO.getResult()
          }(MO), KO = vK;
          vK = OO.catch((OO => {
            console.error("Failed to check for custom texture pack", OO)
          })).then((() => KO))
        }(0, pK.e)(null);
        let dO = !0;
        return vK.then((OO => {
          let {
            shouldMatchmake: pO,
            discordContext: eO
          } = OO;
          dO && (pO ? CK(null !== eO && void 0 !== eO ? eO : lO.lobbyName, eO ? "classic" : lO.gameNameWithVariation, lO.directJoinVmUrl).then((OO => {
            var pO, eO;
            if (null !== OO && dO)
              if (OO.isError()) {
                var vK;
                const hO = OO.asError(),
                  MO = null !== (vK = hO.debugResult.severity) && void 0 !== vK ? vK : "high";
                if (hO.code === VO.f.SHADER_PACK) return void(0, UO.b)(hO.message, XO);
                const FO = bK.d.get("gameEntrySource"),
                  LO = hO.code === VO.f.INITIALISE_WEBGL ? (0, NO.b)() : null,
                  {
                    error: QO
                  } = hO.debugResult,
                  zK = hO.code === VO.f.REQUEST_TO_MATCHMAKING ? function(OO) {
                    var KO;
                    return null !== (KO = Object.keys(aK.b).find((KO => aK.b[KO] === OO))) && void 0 !== KO ? KO : null
                  }(hO.message) : null;
                let fO;
                if (null !== zK) DO.NotificationProvider.showPromptPopup({
                  icon: "lock",
                  title: KO((eO = zK, "notWhitelisted" === eO ? "customLobby:cantJoinNotWhitelistedTitle" : "customLobby:cantJoinWorld")),
                  subtitle: KO(oO[zK]),
                  confirmText: KO("general:ok"),
                  cancelText: ""
                }), fO = Promise.resolve(!1);
                else if (null !== LO) fO = (0, NO.h)(LO);
                else if (QO instanceof yK.l) pO = QO, fO = DO.NotificationProvider.showPromptPopup({
                  icon: "face-dizzy",
                  title: "texturePackLoad:failedTitle",
                  subtitle: (0, gK.jsx)(EO, {
                    failure: pO
                  }),
                  confirmText: "general:tryAgain",
                  cancelText: "general:back"
                }).getResult().then((OO => !0 === OO));
                else {
                  let OO;
                  switch (MO) {
                    case "low":
                      OO = "face-diagonal-mouth";
                      break;
                    case "medium":
                      OO = "face-worried";
                      break;
                    case "high":
                      OO = "face-dizzy"
                  }
                  fO = DO.NotificationProvider.showPromptPopup({
                    icon: OO,
                    title: VO.x[hO.code],
                    subtitle: (0, gK.jsxs)(gK.Fragment, {
                      children: [hO.message, hO.debugResult.error instanceof Error && (0, gK.jsx)("div", {
                        style: {
                          fontSize: "0.9rem",
                          paddingTop: "1rem"
                        },
                        children: (0, gK.jsx)(TO.b, {
                          errorString: hO.debugResult.error.stack
                        })
                      })]
                    }),
                    confirmText: KO("general:tryAgain"),
                    cancelText: KO("general:cancel")
                  }).getResult().then((OO => !0 === OO))
                }
                fO.then((OO => {
                  if (OO) {
                    (0, bK.j)(FO);
                    const OO = (0, YO.b)(lO.gameNameWithVariation, lO.lobbyName);
                    "low" === MO ? XO(OO) : (0, AO.reloadBloxd)(OO)
                  }
                })), CO.gameBridge.send("leaveGame", {
                  reloadPath: "/"
                }), XO(-1)
              } else {
                wO.current = OO.getValue().gameNameWithVariation, iK.current = OO.getValue().lobbyName;
                const KO = (0, YO.b)(wO.current, OO.getValue().lobbyName);
                XO(KO, {
                  replace: !0
                })
              }
          })).catch((OO => {
            if (!dO) return;
            DO.NotificationProvider.showPromptPopup({
              icon: "face-dizzy",
              title: "Unexpected Error",
              subtitle: (0, gK.jsxs)(gK.Fragment, {
                children: [KO("homePage:pleaseCopyError"), (0, gK.jsx)("div", {
                  style: {
                    fontSize: "0.9rem",
                    paddingTop: "1rem"
                  },
                  children: (0, gK.jsx)(TO.b, {
                    errorString: OO.stack
                  })
                })]
              }),
              confirmText: KO("general:tryAgain"),
              cancelText: KO("general:cancel")
            }).getResult().then((OO => {
              !0 === OO && (0, AO.reloadBloxd)((0, YO.b)(lO.gameNameWithVariation, lO.lobbyName))
            })), XO(-1)
          })) : XO(-1))
        })), () => {
          dO = !1
        }
      }), [QO, pO.search, pO.pathname]), (0, lO.useEffect)((() => {
        uO.disableFullscreen && (0, dO.b)() ? (0, dO.g)() : !uO.disableFullscreen && (0, dO.c)() && (0, dO.q)()
      }), [IO, uO]), (0, lO.useEffect)((() => {
        "inGame" === IO && vp()
      }), [IO, uO]), (0, lO.useEffect)((() => {
        "inGame" !== IO && bK.d.set({
          openInGameMenuName: null
        })
      }), [IO]);
      const RO = function(OO) {
        const KO = (0, bK.h)(OO),
          [pO, XO] = (0, lO.useState)(0),
          [eO, CO] = (0, lO.useState)(!1);
        (0, vK.f)("gameJoined", (() => {
          (0, bK.h)(bK.d.get("gameState")) && (XO((OO => OO + 1)), CO(!0))
        })), (0, lO.useEffect)((() => {
          KO || CO(!1)
        }), [KO]);
        const hO = "inGame" === OO;
        return {
          mounted: hO || KO && eO,
          shown: hO,
          key: pO
        }
      }(IO);
      return (0, gK.jsx)(gK.Fragment, {
        children: RO.mounted && (0, gK.jsx)(eO.InGameUi, {
          shown: RO.shown
        }, RO.key)
      })
    }
  },
  4111: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => bK
    });
    var XO = pO(1056);
    async function bK(OO) {
      const KO = await fetch(`${XO.clientSideServerUrls.s3Url}/${OO}`, {
        headers: {
          Accept: "application/json"
        }
      });
      if (404 === KO.status || 403 === KO.status) return null;
      if (!KO.ok) throw new Error(`Failed to download the texture pack (${KO.status})`);
      return await KO.json()
    }
  },
  7970: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO
    });
    var XO = pO(1165),
      bK = pO(1077),
      eO = pO(533);

    function lO(OO) {
      return OO = function(OO, KO) {
        var pO;
        const XO = new URLSearchParams(KO),
          bK = XO.get("lobby"),
          eO = XO.get("vm"),
          lO = null !== (pO = bK) && void 0 !== pO ? pO : OO.lobbyName,
          vK = null !== eO && void 0 !== eO ? eO : OO.directJoinVmUrl;
        if (lO === OO.lobbyName && vK === OO.directJoinVmUrl) return OO;
        return {
          ...OO,
          lobbyName: lO,
          directJoinVmUrl: vK
        }
      }(OO, arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ""), OO = function(OO) {
        if ((0, eO.I)(OO.directJoinVmUrl)) return OO;
        const KO = (0, bK.Y)(OO.directJoinVmUrl);
        null === KO && (OO.directJoinVmUrl = void 0);
        return OO
      }(OO = function(OO) {
        if ((0, eO.I)(OO.gameNameWithVariation)) return OO;
        return OO.gameNameWithVariation = (0, XO.k)(OO.gameNameWithVariation), OO
      }(OO))
    }
  },
  7961: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => lO,
      d: () => CO,
      h: () => vK
    });
    var XO = pO(2446);
    let bK = null,
      eO = !1;

    function lO() {
      return eO = !0, Promise.all([pO.e(62), pO.e(65), pO.e(63), pO.e(64), pO.e(75), pO.e(74), pO.e(229), pO.e(201), pO.e(226), pO.e(227), pO.e(42)]).then((() => pO(38766))).catch((() => {})), Promise.all([pO.e(127), pO.e(126), pO.e(50)]).then((() => pO(38833))).then((OO => {
        let {
          startJoinLoad: KO
        } = OO;
        KO()
      }), (() => {})), bK ??= Promise.all([pO.e(64), pO.e(127), pO.e(75), pO.e(122), pO.e(107), pO.e(126), pO.e(178), pO.e(76), pO.e(227), pO.e(55)]).then((() => pO(38900))).then((OO => (OO.startWasmPlay(), OO.followPageUiPack((OO => {
        XO.c.showGamePack(OO)
      })), OO)), (OO => {
        throw bK = null, OO
      })), bK
    }

    function vK() {
      return eO
    }

    function CO() {
      return Promise.all([pO.e(64), pO.e(127), pO.e(75), pO.e(122), pO.e(107), pO.e(126), pO.e(178), pO.e(76), pO.e(227), pO.e(55)]).then((() => pO(38900))).then((OO => {
        OO.startWasmPreviews(), OO.prefetchWasmPreviews()
      }))
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);