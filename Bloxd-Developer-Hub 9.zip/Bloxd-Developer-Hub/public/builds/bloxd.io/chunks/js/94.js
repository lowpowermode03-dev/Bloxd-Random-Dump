export const id = 94;
export const ids = [94];
export const modules = {
  4106: (OO, KO) => {
    KO.e = function(OO, KO) {
      if (OO && KO) {
        var pO = Array.isArray(KO) ? KO : KO.split(","),
          XO = OO.name || "",
          bK = (OO.type || "").toLowerCase(),
          eO = bK.replace(/\/.*$/, "");
        return pO.some((function(OO) {
          var KO = OO.trim().toLowerCase();
          return "." === KO.charAt(0) ? XO.toLowerCase().endsWith(KO) : KO.endsWith("/*") ? eO === KO.replace(/\/.*$/, "") : bK === KO
        }))
      }
      return !0
    }
  },
  4080: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => oK
    });
    var XO = pO(63),
      bK = pO(4087),
      eO = pO.n(bK);

    function lO(OO, KO, pO, XO) {
      return new(pO || (pO = Promise))((function(bK, eO) {
        function lO(OO) {
          try {
            CO(XO.next(OO))
          } catch (KO) {
            eO(KO)
          }
        }

        function vK(OO) {
          try {
            CO(XO.throw(OO))
          } catch (KO) {
            eO(KO)
          }
        }

        function CO(OO) {
          var KO;
          OO.done ? bK(OO.value) : (KO = OO.value, KO instanceof pO ? KO : new pO((function(OO) {
            OO(KO)
          }))).then(lO, vK)
        }
        CO((XO = XO.apply(OO, KO || [])).next())
      }))
    }

    function vK(OO, KO) {
      var pO, XO, bK, eO, lO = {
        label: 0,
        sent: function() {
          if (1 & bK[0]) throw bK[1];
          return bK[1]
        },
        trys: [],
        ops: []
      };
      return eO = {
        next: vK(0),
        throw: vK(1),
        return: vK(2)
      }, "function" === typeof Symbol && (eO[Symbol.iterator] = function() {
        return this
      }), eO;

      function vK(vK) {
        return function(CO) {
          return function(vK) {
            if (pO) throw new TypeError("Generator is already executing.");
            for (; eO && (eO = 0, vK[0] && (lO = 0)), lO;) try {
              if (pO = 1, XO && (bK = 2 & vK[0] ? XO.return : vK[0] ? XO.throw || ((bK = XO.return) && bK.call(XO), 0) : XO.next) && !(bK = bK.call(XO, vK[1])).done) return bK;
              switch (XO = 0, bK && (vK = [2 & vK[0], bK.value]), vK[0]) {
                case 0:
                case 1:
                  bK = vK;
                  break;
                case 4:
                  return lO.label++, {
                    value: vK[1],
                    done: !1
                  };
                case 5:
                  lO.label++, XO = vK[1], vK = [0];
                  continue;
                case 7:
                  vK = lO.ops.pop(), lO.trys.pop();
                  continue;
                default:
                  if (!(bK = (bK = lO.trys).length > 0 && bK[bK.length - 1]) && (6 === vK[0] || 2 === vK[0])) {
                    lO = 0;
                    continue
                  }
                  if (3 === vK[0] && (!bK || vK[1] > bK[0] && vK[1] < bK[3])) {
                    lO.label = vK[1];
                    break
                  }
                  if (6 === vK[0] && lO.label < bK[1]) {
                    lO.label = bK[1], bK = vK;
                    break
                  }
                  if (bK && lO.label < bK[2]) {
                    lO.label = bK[2], lO.ops.push(vK);
                    break
                  }
                  bK[2] && lO.ops.pop(), lO.trys.pop();
                  continue
              }
              vK = KO.call(OO, lO)
            } catch (CO) {
              vK = [6, CO], XO = 0
            } finally {
              pO = bK = 0
            }
            if (5 & vK[0]) throw vK[1];
            return {
              value: vK[0] ? vK[1] : void 0,
              done: !0
            }
          }([vK, CO])
        }
      }
    }
    Object.create;

    function CO(OO, KO) {
      var pO = "function" === typeof Symbol && OO[Symbol.iterator];
      if (!pO) return OO;
      var XO, bK, eO = pO.call(OO),
        lO = [];
      try {
        for (;
          (void 0 === KO || KO-- > 0) && !(XO = eO.next()).done;) lO.push(XO.value)
      } catch (vK) {
        bK = {
          error: vK
        }
      } finally {
        try {
          XO && !XO.done && (pO = eO.return) && pO.call(eO)
        } finally {
          if (bK) throw bK.error
        }
      }
      return lO
    }

    function hO(OO, KO, pO) {
      if (pO || 2 === arguments.length)
        for (var XO, bK = 0, eO = KO.length; bK < eO; bK++) !XO && bK in KO || (XO || (XO = Array.prototype.slice.call(KO, 0, bK)), XO[bK] = KO[bK]);
      return OO.concat(XO || Array.prototype.slice.call(KO))
    }
    Object.create;
    "function" === typeof SuppressedError && SuppressedError;
    var DO = new Map([
      ["aac", "audio/aac"],
      ["abw", "application/x-abiword"],
      ["arc", "application/x-freearc"],
      ["avif", "image/avif"],
      ["avi", "video/x-msvideo"],
      ["azw", "application/vnd.amazon.ebook"],
      ["bin", "application/octet-stream"],
      ["bmp", "image/bmp"],
      ["bz", "application/x-bzip"],
      ["bz2", "application/x-bzip2"],
      ["cda", "application/x-cdf"],
      ["csh", "application/x-csh"],
      ["css", "text/css"],
      ["csv", "text/csv"],
      ["doc", "application/msword"],
      ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
      ["eot", "application/vnd.ms-fontobject"],
      ["epub", "application/epub+zip"],
      ["gz", "application/gzip"],
      ["gif", "image/gif"],
      ["heic", "image/heic"],
      ["heif", "image/heif"],
      ["htm", "text/html"],
      ["html", "text/html"],
      ["ico", "image/vnd.microsoft.icon"],
      ["ics", "text/calendar"],
      ["jar", "application/java-archive"],
      ["jpeg", "image/jpeg"],
      ["jpg", "image/jpeg"],
      ["js", "text/javascript"],
      ["json", "application/json"],
      ["jsonld", "application/ld+json"],
      ["mid", "audio/midi"],
      ["midi", "audio/midi"],
      ["mjs", "text/javascript"],
      ["mp3", "audio/mpeg"],
      ["mp4", "video/mp4"],
      ["mpeg", "video/mpeg"],
      ["mpkg", "application/vnd.apple.installer+xml"],
      ["odp", "application/vnd.oasis.opendocument.presentation"],
      ["ods", "application/vnd.oasis.opendocument.spreadsheet"],
      ["odt", "application/vnd.oasis.opendocument.text"],
      ["oga", "audio/ogg"],
      ["ogv", "video/ogg"],
      ["ogx", "application/ogg"],
      ["opus", "audio/opus"],
      ["otf", "font/otf"],
      ["png", "image/png"],
      ["pdf", "application/pdf"],
      ["php", "application/x-httpd-php"],
      ["ppt", "application/vnd.ms-powerpoint"],
      ["pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"],
      ["rar", "application/vnd.rar"],
      ["rtf", "application/rtf"],
      ["sh", "application/x-sh"],
      ["svg", "image/svg+xml"],
      ["swf", "application/x-shockwave-flash"],
      ["tar", "application/x-tar"],
      ["tif", "image/tiff"],
      ["tiff", "image/tiff"],
      ["ts", "video/mp2t"],
      ["ttf", "font/ttf"],
      ["txt", "text/plain"],
      ["vsd", "application/vnd.visio"],
      ["wav", "audio/wav"],
      ["weba", "audio/webm"],
      ["webm", "video/webm"],
      ["webp", "image/webp"],
      ["woff", "font/woff"],
      ["woff2", "font/woff2"],
      ["xhtml", "application/xhtml+xml"],
      ["xls", "application/vnd.ms-excel"],
      ["xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
      ["xml", "application/xml"],
      ["xul", "application/vnd.mozilla.xul+xml"],
      ["zip", "application/zip"],
      ["7z", "application/x-7z-compressed"],
      ["mkv", "video/x-matroska"],
      ["mov", "video/quicktime"],
      ["Tl", "application/vnd.ms-outlook"]
    ]);

    function MO(OO, KO) {
      var pO = function(OO) {
        var KO = OO.name;
        if (KO && -1 !== KO.lastIndexOf(".") && !OO.type) {
          var pO = KO.split(".").pop().toLowerCase(),
            XO = DO.get(pO);
          XO && Object.defineProperty(OO, "type", {
            value: XO,
            writable: !1,
            configurable: !1,
            enumerable: !0
          })
        }
        return OO
      }(OO);
      if ("string" !== typeof pO.path) {
        var XO = OO.webkitRelativePath;
        Object.defineProperty(pO, "path", {
          value: "string" === typeof KO ? KO : "string" === typeof XO && XO.length > 0 ? XO : OO.name,
          writable: !1,
          configurable: !1,
          enumerable: !0
        })
      }
      return pO
    }
    var aK = [".DS_Store", "Thumbs.db"];

    function oO(OO) {
      return "object" === typeof OO && null !== OO
    }

    function FO(OO) {
      return zK(OO.target.files).map((function(OO) {
        return MO(OO)
      }))
    }

    function VO(OO) {
      return lO(this, void 0, void 0, (function() {
        return vK(this, (function(KO) {
          switch (KO.label) {
            case 0:
              return [4, Promise.all(OO.map((function(OO) {
                return OO.getFile()
              })))];
            case 1:
              return [2, KO.sent().map((function(OO) {
                return MO(OO)
              }))]
          }
        }))
      }))
    }

    function LO(OO, KO) {
      return lO(this, void 0, void 0, (function() {
        var pO;
        return vK(this, (function(XO) {
          switch (XO.label) {
            case 0:
              return OO.items ? (pO = zK(OO.items).filter((function(OO) {
                return "file" === OO.kind
              })), "drop" !== KO ? [2, pO] : [4, Promise.all(pO.map(AO))]) : [3, 2];
            case 1:
              return [2, QO(fO(XO.sent()))];
            case 2:
              return [2, QO(zK(OO.files).map((function(OO) {
                return MO(OO)
              })))]
          }
        }))
      }))
    }

    function QO(OO) {
      return OO.filter((function(OO) {
        return -1 === aK.indexOf(OO.name)
      }))
    }

    function zK(OO) {
      if (null === OO) return [];
      for (var KO = [], pO = 0; pO < OO.length; pO++) {
        var XO = OO[pO];
        KO.push(XO)
      }
      return KO
    }

    function AO(OO) {
      if ("function" !== typeof OO.webkitGetAsEntry) return dO(OO);
      var KO = OO.webkitGetAsEntry();
      return KO && KO.isDirectory ? NO(KO) : dO(OO)
    }

    function fO(OO) {
      return OO.reduce((function(OO, KO) {
        return hO(hO([], CO(OO), !1), CO(Array.isArray(KO) ? fO(KO) : [KO]), !1)
      }), [])
    }

    function dO(OO) {
      var KO = OO.getAsFile();
      if (!KO) return Promise.reject("".concat(OO, " is not a File"));
      var pO = MO(KO);
      return Promise.resolve(pO)
    }

    function TO(OO) {
      return lO(this, void 0, void 0, (function() {
        return vK(this, (function(KO) {
          return [2, OO.isDirectory ? NO(OO) : IO(OO)]
        }))
      }))
    }

    function NO(OO) {
      var KO = OO.createReader();
      return new Promise((function(OO, pO) {
        var XO = [];
        ! function bK() {
          var eO = this;
          KO.readEntries((function(KO) {
            return lO(eO, void 0, void 0, (function() {
              var eO, lO, CO;
              return vK(this, (function(vK) {
                switch (vK.label) {
                  case 0:
                    if (KO.length) return [3, 5];
                    vK.label = 1;
                  case 1:
                    return vK.trys.push([1, 3, , 4]), [4, Promise.all(XO)];
                  case 2:
                    return eO = vK.sent(), OO(eO), [3, 4];
                  case 3:
                    return lO = vK.sent(), pO(lO), [3, 4];
                  case 4:
                    return [3, 6];
                  case 5:
                    CO = Promise.all(KO.map(TO)), XO.push(CO), bK(), vK.label = 6;
                  case 6:
                    return [2]
                }
              }))
            }))
          }), (function(OO) {
            pO(OO)
          }))
        }()
      }))
    }

    function IO(OO) {
      return lO(this, void 0, void 0, (function() {
        return vK(this, (function(KO) {
          return [2, new Promise((function(KO, pO) {
            OO.file((function(pO) {
              var XO = MO(pO, OO.fullPath);
              KO(XO)
            }), (function(OO) {
              pO(OO)
            }))
          }))]
        }))
      }))
    }
    var yK = pO(4106);

    function gK(OO) {
      return function(OO) {
        if (Array.isArray(OO)) return iK(OO)
      }(OO) || function(OO) {
        if ("undefined" !== typeof Symbol && null != OO[Symbol.iterator] || null != OO["@@iterator"]) return Array.from(OO)
      }(OO) || wO(OO) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function uO(OO, KO) {
      var pO = Object.keys(OO);
      if (Object.getOwnPropertySymbols) {
        var XO = Object.getOwnPropertySymbols(OO);
        KO && (XO = XO.filter((function(KO) {
          return Object.getOwnPropertyDescriptor(OO, KO).enumerable
        }))), pO.push.apply(pO, XO)
      }
      return pO
    }

    function EO(OO) {
      for (var KO = 1; KO < arguments.length; KO++) {
        var pO = null != arguments[KO] ? arguments[KO] : {};
        KO % 2 ? uO(Object(pO), !0).forEach((function(KO) {
          jK(OO, KO, pO[KO])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(OO, Object.getOwnPropertyDescriptors(pO)) : uO(Object(pO)).forEach((function(KO) {
          Object.defineProperty(OO, KO, Object.getOwnPropertyDescriptor(pO, KO))
        }))
      }
      return OO
    }

    function jK(OO, KO, pO) {
      return KO in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }

    function YO(OO, KO) {
      return function(OO) {
        if (Array.isArray(OO)) return OO
      }(OO) || function(OO, KO) {
        var pO = null == OO ? null : "undefined" !== typeof Symbol && OO[Symbol.iterator] || OO["@@iterator"];
        if (null == pO) return;
        var XO, bK, eO = [],
          lO = !0,
          vK = !1;
        try {
          for (pO = pO.call(OO); !(lO = (XO = pO.next()).done) && (eO.push(XO.value), !KO || eO.length !== KO); lO = !0);
        } catch (CO) {
          vK = !0, bK = CO
        } finally {
          try {
            lO || null == pO.return || pO.return()
          } finally {
            if (vK) throw bK
          }
        }
        return eO
      }(OO, KO) || wO(OO, KO) || function() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function wO(OO, KO) {
      if (OO) {
        if ("string" === typeof OO) return iK(OO, KO);
        var pO = Object.prototype.toString.call(OO).slice(8, -1);
        return "Object" === pO && OO.constructor && (pO = OO.constructor.name), "Map" === pO || "Set" === pO ? Array.from(OO) : "Arguments" === pO || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(pO) ? iK(OO, KO) : void 0
      }
    }

    function iK(OO, KO) {
      (null == KO || KO > OO.length) && (KO = OO.length);
      for (var pO = 0, XO = new Array(KO); pO < KO; pO++) XO[pO] = OO[pO];
      return XO
    }
    var rK = "file-invalid-type",
      PO = "file-too-large",
      mK = "file-too-small",
      sO = "too-many-files",
      HO = function(OO) {
        OO = Array.isArray(OO) && 1 === OO.length ? OO[0] : OO;
        var KO = Array.isArray(OO) ? "one of ".concat(OO.join(", ")) : OO;
        return {
          code: rK,
          message: "File type must be ".concat(KO)
        }
      },
      RO = function(OO) {
        return {
          code: PO,
          message: "File is larger than ".concat(OO, " ").concat(1 === OO ? "byte" : "bytes")
        }
      },
      SO = function(OO) {
        return {
          code: mK,
          message: "File is smaller than ".concat(OO, " ").concat(1 === OO ? "byte" : "bytes")
        }
      },
      JO = {
        code: sO,
        message: "Too many files"
      };

    function cK(OO, KO) {
      var pO = "application/x-moz-file" === OO.type || (0, yK.e)(OO, KO);
      return [pO, pO ? null : HO(KO)]
    }

    function BO(OO, KO, pO) {
      if (ZO(OO.size))
        if (ZO(KO) && ZO(pO)) {
          if (OO.size > pO) return [!1, RO(pO)];
          if (OO.size < KO) return [!1, SO(KO)]
        } else {
          if (ZO(KO) && OO.size < KO) return [!1, SO(KO)];
          if (ZO(pO) && OO.size > pO) return [!1, RO(pO)]
        } return [!0, null]
    }

    function ZO(OO) {
      return void 0 !== OO && null !== OO
    }

    function GO(OO) {
      return "function" === typeof OO.isPropagationStopped ? OO.isPropagationStopped() : "undefined" !== typeof OO.cancelBubble && OO.cancelBubble
    }

    function qK(OO) {
      return OO.dataTransfer ? Array.prototype.some.call(OO.dataTransfer.types, (function(OO) {
        return "Files" === OO || "application/x-moz-file" === OO
      })) : !!OO.target && !!OO.target.files
    }

    function xK(OO) {
      OO.preventDefault()
    }

    function nO() {
      for (var OO = arguments.length, KO = new Array(OO), pO = 0; pO < OO; pO++) KO[pO] = arguments[pO];
      return function(OO) {
        for (var pO = arguments.length, XO = new Array(pO > 1 ? pO - 1 : 0), bK = 1; bK < pO; bK++) XO[bK - 1] = arguments[bK];
        return KO.some((function(KO) {
          return !GO(OO) && KO && KO.apply(void 0, [OO].concat(XO)), GO(OO)
        }))
      }
    }

    function WO(OO) {
      return "audio/*" === OO || "video/*" === OO || "image/*" === OO || "text/*" === OO || /\w+\/[-+.\w]+/g.test(OO)
    }

    function tK(OO) {
      return /^.*\.[\w]+$/.test(OO)
    }
    var kK = ["children"],
      UO = ["open"],
      OK = ["refKey", "role", "onKeyDown", "onFocus", "onBlur", "onClick", "onDragEnter", "onDragOver", "onDragLeave", "onDrop"],
      KK = ["refKey", "onChange", "onClick"];

    function pK(OO) {
      return function(OO) {
        if (Array.isArray(OO)) return eK(OO)
      }(OO) || function(OO) {
        if ("undefined" !== typeof Symbol && null != OO[Symbol.iterator] || null != OO["@@iterator"]) return Array.from(OO)
      }(OO) || bp(OO) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function XK(OO, KO) {
      return function(OO) {
        if (Array.isArray(OO)) return OO
      }(OO) || function(OO, KO) {
        var pO = null == OO ? null : "undefined" !== typeof Symbol && OO[Symbol.iterator] || OO["@@iterator"];
        if (null == pO) return;
        var XO, bK, eO = [],
          lO = !0,
          vK = !1;
        try {
          for (pO = pO.call(OO); !(lO = (XO = pO.next()).done) && (eO.push(XO.value), !KO || eO.length !== KO); lO = !0);
        } catch (CO) {
          vK = !0, bK = CO
        } finally {
          try {
            lO || null == pO.return || pO.return()
          } finally {
            if (vK) throw bK
          }
        }
        return eO
      }(OO, KO) || bp(OO, KO) || function() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
      }()
    }

    function bp(OO, KO) {
      if (OO) {
        if ("string" === typeof OO) return eK(OO, KO);
        var pO = Object.prototype.toString.call(OO).slice(8, -1);
        return "Object" === pO && OO.constructor && (pO = OO.constructor.name), "Map" === pO || "Set" === pO ? Array.from(OO) : "Arguments" === pO || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(pO) ? eK(OO, KO) : void 0
      }
    }

    function eK(OO, KO) {
      (null == KO || KO > OO.length) && (KO = OO.length);
      for (var pO = 0, XO = new Array(KO); pO < KO; pO++) XO[pO] = OO[pO];
      return XO
    }

    function lK(OO, KO) {
      var pO = Object.keys(OO);
      if (Object.getOwnPropertySymbols) {
        var XO = Object.getOwnPropertySymbols(OO);
        KO && (XO = XO.filter((function(KO) {
          return Object.getOwnPropertyDescriptor(OO, KO).enumerable
        }))), pO.push.apply(pO, XO)
      }
      return pO
    }

    function vp(OO) {
      for (var KO = 1; KO < arguments.length; KO++) {
        var pO = null != arguments[KO] ? arguments[KO] : {};
        KO % 2 ? lK(Object(pO), !0).forEach((function(KO) {
          CK(OO, KO, pO[KO])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(OO, Object.getOwnPropertyDescriptors(pO)) : lK(Object(pO)).forEach((function(KO) {
          Object.defineProperty(OO, KO, Object.getOwnPropertyDescriptor(pO, KO))
        }))
      }
      return OO
    }

    function CK(OO, KO, pO) {
      return KO in OO ? Object.defineProperty(OO, KO, {
        value: pO,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }) : OO[KO] = pO, OO
    }

    function hK(OO, KO) {
      if (null == OO) return {};
      var pO, XO, bK = function(OO, KO) {
        if (null == OO) return {};
        var pO, XO, bK = {},
          eO = Object.keys(OO);
        for (XO = 0; XO < eO.length; XO++) pO = eO[XO], KO.indexOf(pO) >= 0 || (bK[pO] = OO[pO]);
        return bK
      }(OO, KO);
      if (Object.getOwnPropertySymbols) {
        var eO = Object.getOwnPropertySymbols(OO);
        for (XO = 0; XO < eO.length; XO++) pO = eO[XO], KO.indexOf(pO) >= 0 || Object.prototype.propertyIsEnumerable.call(OO, pO) && (bK[pO] = OO[pO])
      }
      return bK
    }
    var DK = (0, XO.forwardRef)((function(OO, KO) {
      var pO = OO.children,
        bK = oK(hK(OO, kK)),
        eO = bK.open,
        lO = hK(bK, UO);
      return (0, XO.useImperativeHandle)(KO, (function() {
        return {
          open: eO
        }
      }), [eO]), XO.createElement(XO.Fragment, null, pO(vp(vp({}, lO), {}, {
        open: eO
      })))
    }));
    DK.displayName = "Dropzone";
    var MK = {
      disabled: !1,
      getFilesFromEvent: function(OO) {
        return lO(this, void 0, void 0, (function() {
          return vK(this, (function(KO) {
            return oO(OO) && oO(OO.dataTransfer) ? [2, LO(OO.dataTransfer, OO.type)] : function(OO) {
              return oO(OO) && oO(OO.target)
            }(OO) ? [2, FO(OO)] : Array.isArray(OO) && OO.every((function(OO) {
              return "getFile" in OO && "function" === typeof OO.getFile
            })) ? [2, VO(OO)] : [2, []]
          }))
        }))
      },
      maxSize: 1 / 0,
      minSize: 0,
      multiple: !0,
      maxFiles: 0,
      preventDropOnDocument: !0,
      noClick: !1,
      noKeyboard: !1,
      noDrag: !1,
      noDragEventsBubbling: !1,
      validator: null,
      useFsAccessApi: !0,
      autoFocus: !1
    };
    DK.defaultProps = MK, DK.propTypes = {
      children: eO().func,
      accept: eO().objectOf(eO().arrayOf(eO().string)),
      multiple: eO().bool,
      preventDropOnDocument: eO().bool,
      noClick: eO().bool,
      noKeyboard: eO().bool,
      noDrag: eO().bool,
      noDragEventsBubbling: eO().bool,
      minSize: eO().number,
      maxSize: eO().number,
      maxFiles: eO().number,
      disabled: eO().bool,
      getFilesFromEvent: eO().func,
      onFileDialogCancel: eO().func,
      onFileDialogOpen: eO().func,
      useFsAccessApi: eO().bool,
      autoFocus: eO().bool,
      onDragEnter: eO().func,
      onDragLeave: eO().func,
      onDragOver: eO().func,
      onDrop: eO().func,
      onDropAccepted: eO().func,
      onDropRejected: eO().func,
      onError: eO().func,
      validator: eO().func
    };
    var ap = {
      YKO: !1,
      isFileDialogActive: !1,
      isDragActive: !1,
      isDragAccept: !1,
      isDragReject: !1,
      acceptedFiles: [],
      fileRejections: []
    };

    function oK() {
      var OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        KO = vp(vp({}, MK), OO),
        pO = KO.accept,
        bK = KO.disabled,
        eO = KO.getFilesFromEvent,
        lO = KO.maxSize,
        vK = KO.minSize,
        CO = KO.multiple,
        hO = KO.maxFiles,
        DO = KO.onDragEnter,
        MO = KO.onDragLeave,
        aK = KO.onDragOver,
        oO = KO.onDrop,
        FO = KO.onDropAccepted,
        VO = KO.onDropRejected,
        LO = KO.onFileDialogCancel,
        QO = KO.onFileDialogOpen,
        zK = KO.useFsAccessApi,
        AO = KO.autoFocus,
        fO = KO.preventDropOnDocument,
        dO = KO.noClick,
        TO = KO.noKeyboard,
        NO = KO.noDrag,
        IO = KO.noDragEventsBubbling,
        yK = KO.onError,
        uO = KO.validator,
        wO = (0, XO.useMemo)((function() {
          return function(OO) {
            if (ZO(OO)) return Object.entries(OO).reduce((function(OO, KO) {
              var pO = YO(KO, 2),
                XO = pO[0],
                bK = pO[1];
              return [].concat(gK(OO), [XO], gK(bK))
            }), []).filter((function(OO) {
              return WO(OO) || tK(OO)
            })).join(",")
          }(pO)
        }), [pO]),
        iK = (0, XO.useMemo)((function() {
          return function(OO) {
            return ZO(OO) ? [{
              description: "Files",
              accept: Object.entries(OO).filter((function(OO) {
                var KO = YO(OO, 2),
                  pO = KO[0],
                  XO = KO[1],
                  bK = !0;
                return WO(pO) || (console.warn('Skipped "'.concat(pO, '" because it is not a valid MIME type. Check https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types for a list of valid MIME types.')), bK = !1), Array.isArray(XO) && XO.every(tK) || (console.warn('Skipped "'.concat(pO, '" because an invalid file extension was provided.')), bK = !1), bK
              })).reduce((function(OO, KO) {
                var pO = YO(KO, 2),
                  XO = pO[0],
                  bK = pO[1];
                return EO(EO({}, OO), {}, jK({}, XO, bK))
              }), {})
            }] : OO
          }(pO)
        }), [pO]),
        rK = (0, XO.useMemo)((function() {
          return "function" === typeof QO ? QO : VK
        }), [QO]),
        PO = (0, XO.useMemo)((function() {
          return "function" === typeof LO ? LO : VK
        }), [LO]),
        mK = (0, XO.useRef)(null),
        sO = (0, XO.useRef)(null),
        HO = XK((0, XO.useReducer)(FK, ap), 2),
        RO = HO[0],
        SO = HO[1],
        kK = RO.YKO,
        UO = RO.isFileDialogActive,
        bp = (0, XO.useRef)("undefined" !== typeof window && window.isSecureContext && zK && "showOpenFilePicker" in window),
        eK = function() {
          !bp.current && UO && setTimeout((function() {
            sO.current && (sO.current.files.length || (SO({
              type: "closeDialog"
            }), PO()))
          }), 300)
        };
      (0, XO.useEffect)((function() {
        return window.addEventListener("focus", eK, !1),
          function() {
            window.removeEventListener("focus", eK, !1)
          }
      }), [sO, UO, PO, bp]);
      var lK = (0, XO.useRef)([]),
        DK = function(OO) {
          mK.current && mK.current.contains(OO.target) || (OO.preventDefault(), lK.current = [])
        };
      (0, XO.useEffect)((function() {
        return fO && (document.addEventListener("dragover", xK, !1), document.addEventListener("drop", DK, !1)),
          function() {
            fO && (document.removeEventListener("dragover", xK), document.removeEventListener("drop", DK))
          }
      }), [mK, fO]), (0, XO.useEffect)((function() {
        return !bK && AO && mK.current && mK.current.focus(),
          function() {}
      }), [mK, AO, bK]);
      var oK = (0, XO.useCallback)((function(OO) {
          yK ? yK(OO) : console.error(OO)
        }), [yK]),
        LK = (0, XO.useCallback)((function(OO) {
          OO.preventDefault(), OO.persist(), jp(OO), lK.current = [].concat(pK(lK.current), [OO.target]), qK(OO) && Promise.resolve(eO(OO)).then((function(KO) {
            if (!GO(OO) || IO) {
              var pO = KO.length,
                XO = pO > 0 && function(OO) {
                  var KO = OO.files,
                    pO = OO.accept,
                    XO = OO.minSize,
                    bK = OO.maxSize,
                    eO = OO.multiple,
                    lO = OO.maxFiles,
                    vK = OO.validator;
                  return !(!eO && KO.length > 1 || eO && lO >= 1 && KO.length > lO) && KO.every((function(OO) {
                    var KO = YO(cK(OO, pO), 1)[0],
                      eO = YO(BO(OO, XO, bK), 1)[0],
                      lO = vK ? vK(OO) : null;
                    return KO && eO && !lO
                  }))
                }({
                  files: KO,
                  accept: wO,
                  minSize: vK,
                  maxSize: lO,
                  multiple: CO,
                  maxFiles: hO,
                  validator: uO
                });
              SO({
                isDragAccept: XO,
                isDragReject: pO > 0 && !XO,
                isDragActive: !0,
                type: "setDraggedFiles"
              }), DO && DO(OO)
            }
          })).catch((function(OO) {
            return oK(OO)
          }))
        }), [eO, DO, oK, IO, wO, vK, lO, CO, hO, uO]),
        QK = (0, XO.useCallback)((function(OO) {
          OO.preventDefault(), OO.persist(), jp(OO);
          var KO = qK(OO);
          if (KO && OO.dataTransfer) try {
            OO.dataTransfer.dropEffect = "copy"
          } catch (pO) {}
          return KO && aK && aK(OO), !1
        }), [aK, IO]),
        zp = (0, XO.useCallback)((function(OO) {
          OO.preventDefault(), OO.persist(), jp(OO);
          var KO = lK.current.filter((function(OO) {
              return mK.current && mK.current.contains(OO)
            })),
            pO = KO.indexOf(OO.target); - 1 !== pO && KO.splice(pO, 1), lK.current = KO, KO.length > 0 || (SO({
            type: "setDraggedFiles",
            isDragActive: !1,
            isDragAccept: !1,
            isDragReject: !1
          }), qK(OO) && MO && MO(OO))
        }), [mK, MO, IO]),
        AK = (0, XO.useCallback)((function(OO, KO) {
          var pO = [],
            XO = [];
          OO.forEach((function(OO) {
            var KO = XK(cK(OO, wO), 2),
              bK = KO[0],
              eO = KO[1],
              CO = XK(BO(OO, vK, lO), 2),
              hO = CO[0],
              DO = CO[1],
              MO = uO ? uO(OO) : null;
            if (bK && hO && !MO) pO.push(OO);
            else {
              var aK = [eO, DO];
              MO && (aK = aK.concat(MO)), XO.push({
                file: OO,
                errors: aK.filter((function(OO) {
                  return OO
                }))
              })
            }
          })), (!CO && pO.length > 1 || CO && hO >= 1 && pO.length > hO) && (pO.forEach((function(OO) {
            XO.push({
              file: OO,
              errors: [JO]
            })
          })), pO.splice(0)), SO({
            acceptedFiles: pO,
            fileRejections: XO,
            type: "setFiles"
          }), oO && oO(pO, XO, KO), XO.length > 0 && VO && VO(XO, KO), pO.length > 0 && FO && FO(pO, KO)
        }), [SO, CO, wO, vK, lO, hO, oO, FO, VO, uO]),
        fK = (0, XO.useCallback)((function(OO) {
          OO.preventDefault(), OO.persist(), jp(OO), lK.current = [], qK(OO) && Promise.resolve(eO(OO)).then((function(KO) {
            GO(OO) && !IO || AK(KO, OO)
          })).catch((function(OO) {
            return oK(OO)
          })), SO({
            type: "reset"
          })
        }), [eO, AK, oK, IO]),
        dK = (0, XO.useCallback)((function() {
          if (bp.current) {
            SO({
              type: "openDialog"
            }), rK();
            var OO = {
              multiple: CO,
              types: iK
            };
            window.showOpenFilePicker(OO).then((function(OO) {
              return eO(OO)
            })).then((function(OO) {
              AK(OO, null), SO({
                type: "closeDialog"
              })
            })).catch((function(OO) {
              var KO;
              (KO = OO) instanceof DOMException && ("AbortError" === KO.name || KO.code === KO.ABORT_ERR) ? (PO(OO), SO({
                type: "closeDialog"
              })) : ! function(OO) {
                return OO instanceof DOMException && ("SecurityError" === OO.name || OO.code === OO.SECURITY_ERR)
              }(OO) ? oK(OO) : (bp.current = !1, sO.current ? (sO.current.value = null, sO.current.click()) : oK(new Error("Cannot open the file picker because the https://developer.mozilla.org/en-US/docs/Web/API/File_System_Access_API is not supported and no <input> was provided.")))
            }))
          } else sO.current && (SO({
            type: "openDialog"
          }), rK(), sO.current.value = null, sO.current.click())
        }), [SO, rK, PO, zK, AK, oK, iK, CO]),
        TK = (0, XO.useCallback)((function(OO) {
          mK.current && mK.current.isEqualNode(OO.target) && (" " !== OO.key && "Enter" !== OO.key && 32 !== OO.keyCode && 13 !== OO.keyCode || (OO.preventDefault(), dK()))
        }), [mK, dK]),
        NK = (0, XO.useCallback)((function() {
          SO({
            type: "focus"
          })
        }), []),
        IK = (0, XO.useCallback)((function() {
          SO({
            type: "blur"
          })
        }), []),
        yp = (0, XO.useCallback)((function() {
          dO || (! function() {
            var OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : window.navigator.userAgent;
            return function(OO) {
              return -1 !== OO.indexOf("MSIE") || -1 !== OO.indexOf("Trident/")
            }(OO) || function(OO) {
              return -1 !== OO.indexOf("Edge/")
            }(OO)
          }() ? dK() : setTimeout(dK, 0))
        }), [dO, dK]),
        gp = function(OO) {
          return bK ? null : OO
        },
        uK = function(OO) {
          return TO ? null : gp(OO)
        },
        EK = function(OO) {
          return NO ? null : gp(OO)
        },
        jp = function(OO) {
          IO && OO.stopPropagation()
        },
        YK = (0, XO.useMemo)((function() {
          return function() {
            var OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
              KO = OO.refKey,
              pO = void 0 === KO ? "ref" : KO,
              XO = OO.role,
              eO = OO.onKeyDown,
              lO = OO.onFocus,
              vK = OO.onBlur,
              CO = OO.onClick,
              hO = OO.onDragEnter,
              DO = OO.onDragOver,
              MO = OO.onDragLeave,
              aK = OO.onDrop,
              oO = hK(OO, OK);
            return vp(vp(CK({
              onKeyDown: uK(nO(eO, TK)),
              onFocus: uK(nO(lO, NK)),
              onBlur: uK(nO(vK, IK)),
              onClick: gp(nO(CO, yp)),
              onDragEnter: EK(nO(hO, LK)),
              onDragOver: EK(nO(DO, QK)),
              onDragLeave: EK(nO(MO, zp)),
              onDrop: EK(nO(aK, fK)),
              role: "string" === typeof XO && "" !== XO ? XO : "presentation"
            }, pO, mK), bK || TO ? {} : {
              tabIndex: 0
            }), oO)
          }
        }), [mK, TK, NK, IK, yp, LK, QK, zp, fK, TO, NO, bK]),
        wK = (0, XO.useCallback)((function(OO) {
          OO.stopPropagation()
        }), []),
        ip = (0, XO.useMemo)((function() {
          return function() {
            var OO = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
              KO = OO.refKey,
              pO = void 0 === KO ? "ref" : KO,
              XO = OO.onChange,
              bK = OO.onClick,
              eO = hK(OO, KK);
            return vp(vp({}, CK({
              accept: wO,
              multiple: CO,
              type: "file",
              style: {
                display: "none"
              },
              onChange: gp(nO(XO, fK)),
              onClick: gp(nO(bK, wK)),
              tabIndex: -1
            }, pO, sO)), eO)
          }
        }), [sO, pO, CO, fK, bK]);
      return vp(vp({}, RO), {}, {
        YKO: kK && !bK,
        getRootProps: YK,
        getInputProps: ip,
        rootRef: mK,
        inputRef: sO,
        open: gp(dK)
      })
    }

    function FK(OO, KO) {
      switch (KO.type) {
        case "focus":
          return vp(vp({}, OO), {}, {
            YKO: !0
          });
        case "blur":
          return vp(vp({}, OO), {}, {
            YKO: !1
          });
        case "openDialog":
          return vp(vp({}, ap), {}, {
            isFileDialogActive: !0
          });
        case "closeDialog":
          return vp(vp({}, OO), {}, {
            isFileDialogActive: !1
          });
        case "setDraggedFiles":
          return vp(vp({}, OO), {}, {
            isDragActive: KO.isDragActive,
            isDragAccept: KO.isDragAccept,
            isDragReject: KO.isDragReject
          });
        case "setFiles":
          return vp(vp({}, OO), {}, {
            acceptedFiles: KO.acceptedFiles,
            fileRejections: KO.fileRejections
          });
        case "reset":
          return vp({}, ap);
        default:
          return OO
      }
    }

    function VK() {}
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);