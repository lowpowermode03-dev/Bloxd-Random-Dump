export const id = 280;
export const ids = [280];
export const modules = {
  39514: (OO, KO, pO) => {
    pO.d(KO, {
      collectImportedWorldCodePluginNames: () => hO
    });
    var XO = pO(35356),
      bK = pO(35350),
      eO = pO(39432),
      lO = pO.n(eO);

    function vK(OO) {
      return lO().isImportDeclaration(OO) && lO().isStringLiteral(OO.moduleSpecifier) && function(OO) {
        const KO = OO.importClause;
        if (!KO) return !0;
        if (KO.isTypeOnly) return !1;
        const pO = KO.namedBindings;
        return !(pO && !lO().isNamespaceImport(pO)) || !!KO.name || pO.elements.some((OO => !OO.isTypeOnly))
      }(OO) || lO().isExportDeclaration(OO) && OO.moduleSpecifier && lO().isStringLiteral(OO.moduleSpecifier) && function(OO) {
        return !OO.isTypeOnly && (!OO.exportClause || !lO().isNamedExports(OO.exportClause) || 0 === OO.exportClause.elements.length || OO.exportClause.elements.some((OO => !OO.isTypeOnly)))
      }(OO) ? OO.moduleSpecifier.text : lO().isImportEqualsDeclaration(OO) && !OO.isTypeOnly && lO().isExternalModuleReference(OO.moduleReference) && OO.moduleReference.expression && lO().isStringLiteral(OO.moduleReference.expression) ? OO.moduleReference.expression.text : lO().isCallExpression(OO) && lO().isIdentifier(OO.expression) && "require" === OO.expression.text && 1 === OO.arguments.length && lO().isStringLiteral(OO.arguments[0]) ? OO.arguments[0].text : void 0
    }

    function CO(OO, KO, pO) {
      if (!KO.startsWith("./") && !KO.startsWith("../")) return;
      const bK = ((OO.includes("/") ? OO.slice(0, OO.lastIndexOf("/") + 1) : "") + KO).split("/"),
        eO = [];
      for (const XO of bK)
        if ("" !== XO && "." !== XO)
          if (".." !== XO) eO.push(XO);
          else {
            if (0 === eO.length) return;
            eO.pop()
          } const lO = eO.join("/");
      for (const vK of [lO, `${lO}.ts`, `${lO}.js`])
        if (vK in pO && !(0, XO.q)(vK)) return vK
    }

    function hO(OO) {
      const KO = new Set,
        pO = (0, bK.b)(OO);
      if (!pO) return [];
      const XO = [pO],
        eO = new Set;
      for (; XO.length > 0;) {
        const pO = XO.pop();
        if (!pO || eO.has(pO)) continue;
        eO.add(pO);
        const hO = lO().createSourceFile(pO, OO[pO], lO().ScriptTarget.Latest, !1),
          DO = hO => {
            const MO = vK(hO),
              aK = MO ? (0, bK.s)(MO) : null;
            if (aK) KO.add(aK);
            else if (MO) {
              const KO = CO(pO, MO, OO);
              KO && !eO.has(KO) && XO.push(KO)
            }
            lO().forEachChild(hO, DO)
          };
        DO(hO)
      }
      return [...KO].sort()
    }
  },
  39468: OO => {
    function KO(OO) {
      var KO = new Error("Cannot find module '" + OO + "'");
      throw KO.code = "MODULE_NOT_FOUND", KO
    }
    KO.keys = () => [], KO.resolve = KO, KO.id = 39468, OO.exports = KO
  },
  39455: () => {},
  39438: () => {},
  39476: () => {},
  39451: () => {},
  39447: () => {},
  39435: () => {},
  39460: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);