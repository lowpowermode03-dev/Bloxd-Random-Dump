export const id = 16;
export const ids = [16];
export const modules = {
  35130: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => oO,
      h: () => FO,
      i: () => aK,
      k: () => MO
    });
    var XO = pO(8311),
      bK = pO(35137),
      eO = pO(35139),
      lO = pO(7854),
      vK = pO(1263),
      CO = pO(63),
      hO = pO(77),
      DO = pO(976);

    function MO() {
      var OO;
      return (0, vK.h)(bK.d, (0, bK.l)()), (0, DO.jsx)(DO.Fragment, {
        children: null === (OO = (0, bK.l)()) || void 0 === OO ? void 0 : OO.content
      })
    }

    function aK(OO) {
      var KO;
      let {
        show: pO
      } = OO;
      (0, vK.h)(bK.d, (0, bK.l)());
      const hO = null === (KO = (0, bK.l)()) || void 0 === KO ? void 0 : KO.menu;
      return (0, CO.useEffect)((() => {
        var OO;
        pO || (null === hO || void 0 === hO || null === (OO = hO.onClose) || void 0 === OO || OO.call(hO), (0, eO.q)())
      }), [pO, hO]), (0, CO.useEffect)((() => pO ? (0, lO.f)(eO.y, eO.f) : void 0), [pO]), (0, DO.jsx)(XO.e, {
        showing: pO,
        globallyUniqueKey: "clientGameMenu",
        children: null === hO || void 0 === hO ? void 0 : hO.content
      })
    }

    function oO(OO) {
      let {
        placement: KO = "bottom"
      } = OO;
      return (0, DO.jsx)("div", {
        id: `clientGameHud-${KO}`,
        style: {
          display: "contents"
        }
      })
    }

    function FO(OO) {
      let {
        children: KO,
        placement: pO = "bottom"
      } = OO;
      const [XO, bK] = (0, CO.useState)(null);
      return (0, CO.useEffect)((() => {
        bK(document.getElementById(`clientGameHud-${pO}`))
      }), [pO]), XO ? (0, hO.createPortal)(KO, XO) : null
    }
  },
  8311: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => eO
    });
    var XO = pO(3725),
      bK = pO(3730);

    function eO(OO) {
      let {
        children: KO,
        showing: pO,
        globallyUniqueKey: eO,
        alwaysMountChildren: lO = !1,
        doGameplayStartStopOnShow: vK = !0,
        keepsMovement: CO = !1
      } = OO;
      return (0, bK.b)(!0, pO, eO, CO), (0, XO.e)(vK, pO), pO || lO ? KO : null
    }
  },
  35238: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      g: () => lO,
      h: () => vK,
      l: () => CO
    });
    var XO = pO(63),
      bK = pO(1e3);
    const eO = 8,
      lO = "InGameHeaderContainer",
      vK = "TopRightElements";

    function CO(OO) {
      const [KO] = (0, bK.c)(), [pO, CO] = (0, XO.useState)(!1);
      return (0, XO.useLayoutEffect)((() => {
        if (!OO) return;
        const KO = document.querySelector(`.${lO}`),
          pO = document.querySelector(`.${vK}`),
          XO = () => {
            const XO = OO.getBoundingClientRect(),
              bK = KO ? KO.getBoundingClientRect().right : 0,
              lO = pO ? pO.getBoundingClientRect().left : window.innerWidth,
              vK = XO.left < bK + eO,
              hO = XO.right > lO - eO;
            CO(vK || hO)
          };
        XO();
        const bK = new ResizeObserver(XO);
        return bK.observe(OO), KO && bK.observe(KO), pO && bK.observe(pO), () => {
          bK.disconnect()
        }
      }), [OO, KO]), pO
    }
  },
  35230: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    const XO = [{
      maxDist: 30,
      timeBetweenSoftChecks: 1e3,
      softUpdateDist: 2,
      hardUpdateDist: 10
    }, {
      maxDist: 200,
      timeBetweenSoftChecks: 2e3,
      softUpdateDist: 5,
      hardUpdateDist: 20
    }, {
      maxDist: 1 / 0,
      timeBetweenSoftChecks: 5e3,
      softUpdateDist: 30,
      hardUpdateDist: 100
    }];

    function bK(OO, KO, pO) {
      const bK = Math.abs(OO - KO),
        eO = Date.now() - pO;
      for (const lO of XO)
        if (OO < lO.maxDist) return bK >= lO.hardUpdateDist || eO > lO.timeBetweenSoftChecks && bK >= lO.softUpdateDist;
      return !1
    }
  },
  7854: (OO, KO, pO) => {
    pO.d(KO, {
      b: () => eO,
      f: () => bK
    });
    let XO = null;
    const bK = function(OO) {
        const KO = {
          cycle: OO,
          canCycle: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : () => !0
        };
        return XO = KO, () => {
          XO === KO && (XO = null)
        }
      },
      eO = () => {
        var OO;
        return null !== (OO = XO) && void 0 !== OO && OO.canCycle() ? XO.cycle : null
      }
  },
  36921: (OO, KO, pO) => {
    function XO(OO, KO, pO) {
      var XO;
      const {
        width: bK,
        height: eO
      } = pO, lO = null !== (XO = OO.text) && void 0 !== XO ? XO : OO, vK = (lO.x / 100 - .5) * bK, CO = (lO.y / 100 - .5) * eO, hO = bK / 2 - KO.x;
      if (null !== OO.text && Math.abs(vK) <= hO && CO >= KO.top - eO / 2 && CO <= eO / 2 - KO.bottom) return {
        x: lO.x,
        y: lO.y
      };
      const DO = Math.min(0 === vK ? 1 / 0 : hO / Math.abs(vK), CO > 0 ? (eO / 2 - KO.bottom) / CO : CO < 0 ? (KO.top - eO / 2) / CO : 1 / 0);
      return !Number.isFinite(DO) || DO < 0 ? {
        x: 50,
        y: 50
      } : {
        x: 50 + vK * DO / bK * 100,
        y: 50 + CO * DO / eO * 100
      }
    }
    pO.d(KO, {
      c: () => XO
    })
  },
  35139: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => zK,
      c: () => eO,
      f: () => VO,
      i: () => LO,
      m: () => vK,
      n: () => aK,
      q: () => QO,
      s: () => MO,
      u: () => AO,
      y: () => FO
    });
    var XO = pO(22),
      bK = pO(26);
    const eO = "clientGameInventoryButtonsChanged",
      lO = new Map;

    function vK() {
      return [...lO.values()].sort(((OO, KO) => {
        var pO, XO;
        return (null !== (pO = OO.order) && void 0 !== pO ? pO : 0) - (null !== (XO = KO.order) && void 0 !== XO ? XO : 0)
      }))
    }
    let CO = null;

    function hO(OO) {
      CO = OO
    }
    let DO = !1;

    function MO(OO) {
      DO = !0;
      try {
        OO.onClick()
      } finally {
        DO = !1
      }
      OO.panel && "clientGame" === XO.d.get("openInGameMenuName") && hO(OO.id)
    }

    function aK() {
      return DO
    }

    function oO() {
      return vK().filter((OO => OO.panel && !OO.disabled))
    }

    function FO(OO) {
      const KO = oO(),
        pO = KO.findIndex((OO => OO.id === CO));
      return !(pO < 0 || KO.length < 2) && (MO(KO[(pO + OO + KO.length) % KO.length]), !0)
    }

    function VO() {
      return null !== CO && oO().length > 1
    }

    function LO() {
      hO(null)
    }

    function QO() {
      "inventory" !== XO.d.get("openInGameMenuName") && hO(null)
    }

    function zK() {
      const OO = CO;
      return hO(null), OO
    }

    function AO(OO) {
      return lO.set(OO.id, OO), bK.i.pl(eO, vK(), !0), () => {
        lO.get(OO.id) === OO && (lO.delete(OO.id), bK.i.pl(eO, vK()))
      }
    }
  },
  35137: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => vK,
      g: () => LO,
      j: () => QO,
      k: () => aK,
      l: () => hO,
      o: () => VO,
      p: () => oO,
      q: () => DO
    });
    var XO = pO(22),
      bK = pO(26),
      eO = pO(1136),
      lO = pO(35139);
    const vK = "clientGameUiChanged";
    let CO = null;

    function hO() {
      return CO
    }

    function DO(OO, KO) {
      const pO = {
        content: OO,
        menu: KO
      };
      return CO = pO, bK.i.pl(vK, CO, !0), () => {
        CO === pO && (CO = null, FO = !1, LO(), bK.i.pl(vK, null))
      }
    }
    let MO = null;

    function aK() {
      return MO
    }

    function oO(OO) {
      return MO = OO, () => {
        MO === OO && (MO = null)
      }
    }
    let FO = !1;

    function VO() {
      const OO = XO.d.get("openInGameMenuName");
      "clientGame" !== OO && (FO = "inventory" === OO), (0, lO.n)() || (0, lO.i)(), (0, eO.k)("InGameMenu"), XO.d.set({
        openInGameMenuName: "clientGame",
        openEverythingMenuName: null
      })
    }

    function LO() {
      zK(!1)
    }

    function QO() {
      zK(FO)
    }

    function zK(OO) {
      "clientGame" === XO.d.get("openInGameMenuName") && XO.d.set({
        openInGameMenuName: OO ? "inventory" : null
      }), OO || (0, lO.i)(), FO = !1
    }
  },
  37651: (OO, KO, pO) => {
    pO.r(KO), pO.d(KO, {
      default: () => LK
    });
    const XO = ["skin", "head", "body", "legs", "shoes", "eyebrows", "eyes"];
    var bK = pO(63),
      eO = pO(35137),
      lO = pO(35501),
      vK = pO(35151),
      CO = pO(1481),
      hO = pO(26);
    const DO = {
      M1911: "pistol",
      Deagle: "pistol",
      "Block-19": "pistol",
      "AK-47": "rifle",
      M16: "rifle",
      "TAR-21": "rifle",
      SKAR: "rifle",
      FMR: "rifle",
      MP40: "smg",
      "Mini Izu": "smg",
      "Double Barrel": "shotgun",
      "Striker-12": "shotgun",
      DMR: "marksman",
      VSR: "marksman",
      GPMG: "machineGun",
      Minigun: "machineGun",
      RPG: "launcher",
      "Moonstone Dagger": "melee",
      "Moonstone Boomerang": "melee",
      "Frag Grenade": "throwable",
      "Smoke Grenade": "throwable",
      "Mining Grenade": "throwable",
      "Splash Instant Healing Potion": "throwable",
      Snowdash: "throwable"
    };
    const MO = 32;

    function aK(OO, KO, pO, XO) {
      return {
        tag: "line",
        attrs: {
          x1: OO,
          y1: KO,
          x2: pO,
          y2: XO,
          "stroke-width": arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 2
        }
      }
    }

    function oO(OO) {
      return {
        tag: "circle",
        attrs: {
          cx: MO,
          cy: arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : MO,
          r: OO,
          class: "Fill"
        }
      }
    }

    function FO(OO, KO) {
      return {
        tag: "path",
        attrs: {
          d: OO,
          "stroke-width": KO
        }
      }
    }

    function VO(OO, KO, pO) {
      return {
        tag: "circle",
        attrs: {
          cx: MO,
          cy: MO,
          r: OO,
          "stroke-width": KO,
          class: pO
        }
      }
    }

    function LO(OO, KO, pO) {
      return {
        tag: "text",
        attrs: {
          x: OO,
          y: KO,
          class: "Fill Label"
        },
        text: pO
      }
    }
    const QO = {
      pistol: OO => [aK(MO, MO - OO - 5, MO, MO - OO), aK(MO - OO - 5, MO, MO - OO, MO), aK(MO + OO, MO, MO + OO + 5, MO), oO(1.4)],
      rifle: OO => [aK(MO, MO - OO - 8, MO, MO - OO), aK(MO, MO + OO, MO, MO + OO + 8), aK(MO - OO - 8, MO, MO - OO, MO), aK(MO + OO, MO, MO + OO + 8, MO), oO(1)],
      smg: OO => {
        const KO = Math.PI / 2,
          pO = [];
        for (let lO = 0; lO < 4; lO++) pO.push((bK = lO * KO + .35, eO = (lO + 1) * KO - .35, FO(`M${MO+(XO=6+OO)*Math.cos(bK)} ${MO+XO*Math.sin(bK)} A${XO} ${XO} 0 0 1 ${MO+XO*Math.cos(eO)} ${MO+XO*Math.sin(eO)}`, 2)));
        var XO, bK, eO;
        return [...pO, oO(1.4)]
      },
      shotgun: OO => [VO(OO, 3, "Ring Outline"), VO(OO, 1.5, "Ring")],
      marksman: OO => [FO(`M${26-OO/2} ${39+OO/2} L32 33 L${38+OO/2} ${39+OO/2}`, 2), aK(14 - OO, MO, 24 - OO, MO, 1.5), aK(40 + OO, MO, 50 + OO, MO, 1.5), aK(14 - OO, 30, 14 - OO, 34, 1.5), aK(50 + OO, 30, 50 + OO, 34, 1.5)],
      machineGun: OO => {
        const KO = 10 + OO,
          pO = [];
        for (const [XO, bK] of [
            [-1, -1],
            [1, -1],
            [-1, 1],
            [1, 1]
          ]) pO.push(FO(`M${MO+XO*KO} ${MO+bK*(KO-5)} L${MO+XO*KO} ${MO+bK*KO} L${MO+XO*(KO-5)} ${MO+bK*KO}`, 2));
        return [...pO, aK(MO, 28, MO, 36, 1.5), aK(28, MO, 36, MO, 1.5)]
      },
      launcher: () => [aK(14, 30, 50, 30, 1.5), aK(MO, 24, MO, 52, 1.5), aK(28, 38, 36, 38, 1.5), aK(29, 44, 35, 44, 1.5), aK(30, 50, 34, 50, 1.5), LO(38, 40, "100"), LO(37, 46, "200"), oO(1.4, 30)],
      melee: () => [FO("M32 26 L38 32 L32 38 L26 32 Z", 1.5), oO(1.2)],
      throwable: () => [oO(1.6)]
    };

    function zK(OO) {
      let {
        tag: KO,
        attrs: pO,
        text: XO
      } = OO, bK = `<${KO}`;
      for (const [eO, lO] of Object.entries(pO)) bK += ` ${eO}="${lO}"`;
      return void 0 === XO ? `${bK}/>` : `${bK}>${XO}</${KO}>`
    }
    class AO {
      constructor(OO, KO) {
        this.api = OO, this.localPlayerId = KO, this.element = null, this.drawnFamily = null, this.shapes = [], this.drawnGap = 0, this.coneDrawn = !1, this.drawnVisible = null, this.drawnPressed = null, this.shownRadius = 0, this.ownsCrosshair = !1, this.enabled = !0, this.sniperOverlay = !1, this.mouseDown = !1, this.gapPerVh = 0, this.tokens = void 0, this.bindElement = OO => {
          this.element = OO, this.drawnFamily = null, this.drawnVisible = null, this.drawnPressed = null, OO && !this.enabled && (OO.style.display = "none")
        }, this.measure = () => {
          this.gapPerVh = window.innerHeight / 100 * (64 / (4 * (0, CO.getRemInPx)()))
        }, this.tokens = [hO.i.subscribe("aimingOverlay", (OO => {
          this.sniperOverlay = "sniper" === OO
        })), hO.i.subscribe("mouseState", (OO => {
          let {
            isDown: KO
          } = OO;
          this.mouseDown = KO
        }))], window.addEventListener("resize", this.measure), this.measure()
      }
      WE(OO) {
        OO !== this.enabled && (this.enabled = OO, this.drawnVisible = null, OO || (this.setOwnsCrosshair(!1), this.element && (this.element.style.display = "none")))
      }
      frame(OO, KO) {
        var pO, XO;
        if (!this.enabled) return;
        const {
          api: bK
        } = this, eO = bK.isAlive(this.localPlayerId) && null !== (pO = null === (XO = bK.mhO(this.localPlayerId)) || void 0 === XO ? void 0 : XO.name) && void 0 !== pO ? pO : null, lO = (vK = eO) && DO[vK] || null;
        var vK;
        if (this.setOwnsCrosshair(null !== lO), !this.element) return;
        const CO = bK.getHeldGunInaccuracy(),
          hO = null !== CO,
          MO = null !== lO && !this.sniperOverlay && bK.isCrosshairShown();
        if (MO !== this.drawnVisible && (this.drawnVisible = MO, this.element.style.display = MO ? "block" : "none"), !MO) return;
        const aK = hO ? function(OO) {
            return "launcher" === OO || "melee" === OO || "throwable" === OO ? "none" : "shotgun" === OO ? "cone" : "offset"
          }(lO) : "none",
          oO = null !== CO && void 0 !== CO ? CO : 0;
        "cone" === aK ? this.drawCone(lO, this.coneRadiusVh(oO, KO) * this.gapPerVh, OO) : (this.coneDrawn = !1, this.draw(lO, "none" === aK ? 2 : this.offsetGap(oO)));
        const FO = !hO && this.mouseDown;
        FO !== this.drawnPressed && (this.drawnPressed = FO, this.element.classList.toggle("Pressed", FO))
      }
      dispose() {
        for (const OO of this.tokens) hO.i.unsubscribe(OO);
        window.removeEventListener("resize", this.measure), this.setOwnsCrosshair(!1)
      }
      draw(OO, KO) {
        var pO, XO;
        OO !== this.drawnFamily ? (this.drawnFamily = OO, this.drawnGap = KO, this.element.innerHTML = function(OO, KO) {
          return `<svg viewBox="0 0 64 64">${QO[OO](KO).map(zK).join("")}</svg>`
        }(OO, KO), this.shapes = Array.from(null !== (pO = null === (XO = this.element.firstElementChild) || void 0 === XO ? void 0 : XO.children) && void 0 !== pO ? pO : [])) : KO !== this.drawnGap && (this.drawnGap = KO, function(OO, KO, pO) {
          const XO = QO[KO](pO);
          for (let bK = 0; bK < XO.length; bK++)
            for (const [KO, pO] of Object.entries(XO[bK].attrs)) {
              const XO = String(pO);
              OO[bK].getAttribute(KO) !== XO && OO[bK].setAttribute(KO, XO)
            }
        }(this.shapes, OO, KO))
      }
      drawCone(OO, KO, pO) {
        OO === this.drawnFamily && this.coneDrawn ? this.shownRadius += (KO - this.shownRadius) * (1 - Math.exp(-pO / 80)) : this.shownRadius = KO, this.coneDrawn = !0, this.draw(OO, Math.round(4 * this.shownRadius) / 4)
      }
      coneRadiusVh(OO, KO) {
        if (!(KO > 0)) return 1;
        const pO = OO * lO.k / 2;
        return Math.max(50 * Math.tan(pO) / KO, 1)
      }
      offsetGap(OO) {
        const KO = 2 + ((0, vK.e)(OO) - 1) * this.gapPerVh;
        return Math.min(24, Math.round(2 * KO) / 2)
      }
      setOwnsCrosshair(OO) {
        OO !== this.ownsCrosshair && (this.ownsCrosshair = OO, document.body.classList.toggle("FrontlineCustomCrosshair", OO))
      }
    }
    const fO = "FrontlineCustomDamage",
      dO = .45,
      TO = .2;
    class NO {
      constructor(OO, KO) {
        this.api = OO, this.localPlayerId = KO, this.root = null, this.lowLayer = null, this.arcLayer = null, this.arcs = [], this.flashes = [], this.lastHealthPool = null, this.lastDrop = {
          frac: 0,
          at: -1 / 0
        }, this.maxHealth = null, this.sOO = 1, this.dead = !1, this.enabled = !0, this.cameraHeading = 0, this.token = void 0, this.readHealth = NaN, this.readShield = NaN, this.readMaxHealth = NaN, this.bindElement = OO => {
          var KO, pO;
          this.clearHits(), this.root = OO, this.lowLayer = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.querySelector(".FrontlineDamageLow")) && void 0 !== KO ? KO : null, this.arcLayer = null !== (pO = null === OO || void 0 === OO ? void 0 : OO.querySelector(".FrontlineDamageArcs")) && void 0 !== pO ? pO : null, this.showRoot(), this.drawLow()
        }, this.token = hO.i.subscribe("damagedByOtherPlayer", (OO => {
          let {
            direction: KO,
            POO: pO
          } = OO;
          this.onHurt(KO, pO)
        })), this.syncHealth(), document.body.classList.add(fO)
      }
      WE(OO) {
        OO !== this.enabled && (this.enabled = OO, document.body.classList.toggle(fO, OO), OO || this.clearHits(), this.showRoot())
      }
      frame(OO) {
        this.syncHealth(), this.cameraHeading = OO;
        for (const KO of this.arcs) this.drawArcAngle(KO)
      }
      dispose() {
        hO.i.unsubscribe(this.token), this.clearHits(), document.body.classList.remove(fO)
      }
      showRoot() {
        this.root && (this.root.style.display = this.enabled ? "" : "none")
      }
      syncHealth() {
        const OO = this.api.getClientOption(this.localPlayerId, "_health"),
          KO = this.api.getClientOption(this.localPlayerId, "_shield"),
          pO = this.api.getClientOption(this.localPlayerId, "_totalMaxHealth");
        if (Object.is(OO, this.readHealth) && Object.is(KO, this.readShield) && Object.is(pO, this.readMaxHealth)) return;
        if (this.readHealth = OO, this.readShield = KO, this.readMaxHealth = pO, null === OO || void 0 === OO || !pO) return this.lastHealthPool = null, this.maxHealth = null, this.sOO = 1, this.dead = !1, void this.drawLow();
        const XO = OO + (null !== KO && void 0 !== KO ? KO : 0);
        if (null !== this.lastHealthPool && XO < this.lastHealthPool) {
          const OO = performance.now(),
            KO = (this.lastHealthPool - XO) / pO;
          this.lastDrop = OO - this.lastDrop.at < 300 ? {
            frac: this.lastDrop.frac + KO,
            at: this.lastDrop.at
          } : {
            frac: KO,
            at: OO
          }
        }
        this.dead = OO <= 0, this.dead && this.clearHits(), this.lastHealthPool = XO, this.maxHealth = pO, this.sOO = OO > 0 ? OO / pO : 1, this.drawLow()
      }
      onHurt(OO, KO) {
        if (this.syncHealth(), this.dead || !this.enabled) return;
        const pO = Math.min(1, this.takeDamageFrac(KO) / .3);
        null !== OO && this.showArc(OO, pO), this.flashEdge(null === OO ? null : OO - this.cameraHeading, .4 + .6 * pO)
      }
      takeDamageFrac(OO) {
        if (void 0 !== OO && this.maxHealth) return OO / this.maxHealth;
        if (performance.now() - this.lastDrop.at >= 300) return .12;
        const {
          frac: KO
        } = this.lastDrop;
        return this.lastDrop = {
          frac: 0,
          at: -1 / 0
        }, KO
      }
      drawLow() {
        if (!this.lowLayer) return;
        const OO = yK((dO - this.sOO) / .25),
          KO = yK((TO - this.sOO) / .15000000000000002),
          pO = this.sOO < dO;
        this.lowLayer.classList.toggle("Active", pO), this.lowLayer.classList.toggle("Critical", this.sOO < TO), this.lowLayer.style.opacity = String(pO ? .55 + .3 * OO + .15 * KO : 0)
      }
      showArc(OO, KO) {
        var pO, XO;
        if (!this.arcLayer) return;
        let bK = this.arcs.find((KO => IO(KO.direction, OO) < .6));
        if (!bK) {
          const KO = document.createElement("div");
          KO.className = "FrontlineDamageArc", KO.appendChild(document.createElement("div")).className = "FrontlineDamageArcBand", this.arcLayer.appendChild(KO), bK = {
            element: KO,
            direction: OO,
            drawnAngle: null,
            fade: null,
            pop: null
          }, this.arcs.push(bK)
        }
        bK.direction = OO, this.drawArcAngle(bK);
        const eO = bK.fade ? Number(getComputedStyle(bK.element).opacity) : 0;
        null === (pO = bK.fade) || void 0 === pO || pO.cancel(), null === (XO = bK.pop) || void 0 === XO || XO.cancel(), bK.element.style.opacity = "1";
        const lO = bK.element.animate([{
          opacity: eO
        }, {
          opacity: 1
        }], 144);
        bK.fade = lO, bK.pop = bK.element.animate([{
          scale: 1.1 + (1.16 - 1.1) * KO
        }, {
          scale: 1
        }], {
          duration: 160,
          easing: "cubic-bezier(0.2, 0.7, 0.3, 1)"
        });
        const vK = bK;
        lO.onfinish = () => {
          if (vK.fade !== lO) return;
          const OO = vK.element.animate([{
            opacity: 1
          }, {
            opacity: 0
          }], {
            delay: 936,
            duration: 864,
            easing: "cubic-bezier(0.4, 0, 0.7, 1)",
            fill: "forwards"
          });
          OO.startTime = lO.startTime, vK.fade = OO, OO.onfinish = () => {
            vK.fade === OO && (vK.element.remove(), gK(this.arcs, vK))
          }
        }
      }
      drawArcAngle(OO) {
        const KO = OO.direction - this.cameraHeading;
        (null === OO.drawnAngle || Math.abs(KO - OO.drawnAngle) > .005) && (OO.drawnAngle = KO, OO.element.style.rotate = `${KO}rad`)
      }
      flashEdge(OO, KO) {
        var pO, XO, bK;
        if (!this.root) return;
        let eO = this.flashes.find((KO => null === KO.angle || null === OO ? KO.angle === OO : IO(KO.angle, OO) < .5));
        if (!eO) {
          const KO = document.createElement("div");
          KO.className = "FrontlineDamageFlash";
          const pO = KO.appendChild(document.createElement("div"));
          pO.className = "FrontlineDamageFlashGlow", this.root.insertBefore(KO, this.arcLayer), eO = {
            element: KO,
            glow: pO,
            angle: OO,
            level: 0,
            animation: null
          }, this.flashes.push(eO)
        }
        const lO = null === (pO = eO.animation) || void 0 === pO || null === (XO = pO.effect) || void 0 === XO ? void 0 : XO.getComputedTiming().progress,
          vK = null === lO || void 0 === lO ? 0 : eO.level * (1 - lO);
        eO.level = Math.min(1, Math.max(KO, vK + .6 * KO)), eO.angle = OO;
        const {
          x: CO,
          y: hO,
          rx: DO,
          ry: MO
        } = function(OO, KO) {
          const pO = window.innerWidth,
            XO = window.innerHeight;
          if (null === OO) return {
            x: pO / 2,
            y: XO / 2,
            rx: 0,
            ry: 0
          };
          const bK = Math.sin(OO),
            eO = -Math.cos(OO),
            lO = pO / 2 / Math.max(1e-6, Math.abs(bK)),
            vK = XO / 2 / Math.max(1e-6, Math.abs(eO)),
            CO = Math.min(lO, vK),
            hO = Math.round(pO / 2 + bK * CO),
            DO = Math.round(XO / 2 + eO * CO),
            MO = XO / 100 * (.85 + .25 * KO),
            aK = lO <= vK,
            oO = Math.round((aK ? 30 : 74) * MO),
            FO = Math.round((aK ? 58 : 26) * MO);
          return {
            x: hO,
            y: DO,
            rx: oO,
            ry: FO
          }
        }(OO, eO.level), {
          style: aK
        } = eO.glow;
        eO.glow.classList.toggle("Everywhere", null === OO), aK.setProperty("--glowX", `${CO}px`), aK.setProperty("--glowY", `${hO}px`), aK.setProperty("--glowRx", `${DO}px`), aK.setProperty("--glowRy", `${MO}px`), eO.element.style.transformOrigin = `${CO}px ${hO}px`, null === (bK = eO.animation) || void 0 === bK || bK.cancel();
        const oO = eO.element.animate([{
          opacity: 0,
          scale: .82,
          easing: "cubic-bezier(0.2, 0.8, 0.3, 1)"
        }, {
          opacity: eO.level,
          scale: 1,
          offset: .12,
          easing: "linear"
        }, {
          opacity: .8 * eO.level,
          offset: .38,
          easing: "cubic-bezier(0.4, 0, 0.7, 1)"
        }, {
          opacity: 0,
          scale: .92
        }], {
          duration: 520 + 180 * eO.level
        });
        eO.animation = oO;
        const FO = eO;
        oO.onfinish = () => {
          FO.animation === oO && (FO.element.remove(), gK(this.flashes, FO))
        }
      }
      clearHits() {
        for (const XO of this.arcs) {
          var OO, KO;
          null === (OO = XO.fade) || void 0 === OO || OO.cancel(), XO.fade = null, null === (KO = XO.pop) || void 0 === KO || KO.cancel(), XO.element.remove()
        }
        this.arcs.length = 0;
        for (const XO of this.flashes) {
          var pO;
          null === (pO = XO.animation) || void 0 === pO || pO.cancel(), XO.element.remove()
        }
        this.flashes.length = 0
      }
    }

    function IO(OO, KO) {
      return Math.abs(Math.atan2(Math.sin(OO - KO), Math.cos(OO - KO)))
    }

    function yK(OO) {
      return Math.max(0, Math.min(1, OO))
    }

    function gK(OO, KO) {
      const pO = OO.indexOf(KO); - 1 !== pO && OO.splice(pO, 1)
    }
    var uO = pO(918),
      EO = pO.n(uO),
      jK = pO(35130),
      YO = pO(35238),
      wO = pO(1051),
      iK = pO(1263);
    const rK = "frontlineHudChanged",
      PO = "frontlineScoreboardChanged";
    class mK {
      constructor() {
        this.wire = ["none"], this.scoreboard = {
          wire: ["none"],
          endsAt: 0
        }
      }
      getWire() {
        return this.wire
      }
      getScoreboard() {
        return this.scoreboard
      }
      PX(OO) {
        this.wire = OO, hO.i.pl(rK, OO, !0)
      }
      receiveScoreboard(OO) {
        let KO = "scoreboard" === OO[0] ? performance.now() + OO[5] : 0;
        const pO = this.scoreboard.endsAt;
        0 !== KO && 0 !== pO && Math.abs(KO - pO) < 1e3 && (KO = pO), this.scoreboard = {
          wire: OO,
          endsAt: KO
        }, hO.i.pl(PO, this.scoreboard, !0)
      }
    }
    var sO = pO(976);
    const HO = {
      Red: "frontlineHud:teamRed",
      Blue: "frontlineHud:teamBlue"
    };

    function RO(OO) {
      const [KO, pO] = (0, bK.useState)((() => (OO - performance.now()) / 1e3));
      return (0, bK.useEffect)((() => {
        if (0 === OO) return;
        const KO = () => {
          pO((OO - performance.now()) / 1e3)
        };
        KO();
        const XO = window.setInterval(KO, 250);
        return () => {
          window.clearInterval(XO)
        }
      }), [OO]), KO
    }

    function SO(OO) {
      let {
        className: KO,
        point: pO
      } = OO;
      const [XO, bK, eO, lO, vK, CO] = pO;
      return (0, sO.jsxs)("div", {
        className: EO()(KO, `Owner-${bK||"None"}`, `Leader-${lO||"None"}`, {
          Contested: vK,
          Here: CO
        }),
        children: [(0, sO.jsx)("span", {
          className: "FrontlinePointLetter",
          children: XO
        }), (0, sO.jsx)("i", {
          className: "FrontlinePointFill",
          style: {
            width: `${eO}%`
          }
        })]
      })
    }
    const JO = (0, bK.memo)((function(OO) {
        let {
          points: KO,
          markers: pO
        } = OO;
        const {
          t: XO
        } = (0, wO.D)();
        return KO ? (0, sO.jsx)("div", {
          className: "FrontlinePointMarkers",
          children: KO.map((OO => {
            const [KO, , , , , , , bK] = OO;
            return (0, sO.jsxs)("div", {
              ref: pO.bindMarker(KO),
              className: "FrontlinePointMarker",
              children: [(0, sO.jsx)(SO, {
                className: "FrontlinePointMarkerTile",
                point: OO
              }), (0, sO.jsxs)("div", {
                className: "FrontlinePointMarkerLabels",
                children: [bK && (0, sO.jsx)("span", {
                  className: EO()("FrontlinePointMarkerHomeTurf", `Team-${bK}`),
                  children: XO("frontlineHud:homeTurf", {
                    team: XO(HO[bK])
                  })
                }), (0, sO.jsx)("span", {
                  className: "FrontlinePointMarkerDistance"
                })]
              })]
            }, KO)
          }))
        }) : null
      })),
      cK = {
        capturing: "frontlineHud:capturing",
        contesting: "frontlineHud:contesting",
        defending: "frontlineHud:defending",
        captured: "frontlineHud:captured"
      },
      BO = {
        captured: "frontlineHud:capturedTag",
        lost: "frontlineHud:lostTag",
        milestone: "frontlineHud:milestoneTag",
        nearVictory: "frontlineHud:nearVictoryTag",
        reinforcements: "frontlineHud:reinforcementsTag"
      };

    function ZO(OO) {
      let {
        hud: KO,
        crosshair: pO,
        damage: XO,
        markers: bK
      } = OO;
      const eO = (0, iK.h)(rK, KO.getWire()),
        lO = (0, iK.h)(PO, KO.getScoreboard());
      return (0, sO.jsxs)(sO.Fragment, {
        children: [(0, sO.jsx)(GO, {
          damage: XO
        }), (0, sO.jsx)(JO, {
          points: "scoreboard" === lO.wire[0] ? lO.wire[6] : null,
          markers: bK
        }), (0, sO.jsx)(xK, {
          view: lO
        }), (0, sO.jsx)("div", {
          className: "FrontlineReticle",
          ref: pO.bindElement
        }), (0, sO.jsx)(jK.h, {
          children: (0, sO.jsx)(qK, {
            wire: eO
          })
        })]
      })
    }
    const GO = (0, bK.memo)((function(OO) {
        let {
          damage: KO
        } = OO;
        return (0, sO.jsxs)("div", {
          className: "FrontlineDamage",
          ref: KO.bindElement,
          children: [(0, sO.jsx)("div", {
            className: "FrontlineDamageLow",
            children: (0, sO.jsx)("div", {
              className: "FrontlineDamageShade"
            })
          }), (0, sO.jsx)("div", {
            className: "FrontlineDamageArcs"
          })]
        })
      })),
      qK = (0, bK.memo)((function(OO) {
        let {
          wire: KO
        } = OO;
        const {
          t: pO
        } = (0, wO.D)();
        if ("capture" === KO[0]) {
          const [, OO, XO, bK, eO, lO, vK] = KO, CO = Math.round(bK / 100 * 24);
          return (0, sO.jsxs)("div", {
            className: EO()("FrontlinePlate", `Status-${XO}`, `Leader-${eO||"None"}`),
            children: [(0, sO.jsx)(kK, {}), (0, sO.jsxs)("div", {
              className: "FrontlinePlateRow",
              children: [(0, sO.jsx)("span", {
                className: "FrontlineObjective",
                children: OO
              }), (0, sO.jsxs)("div", {
                className: "FrontlinePlateMiddle",
                children: [(0, sO.jsx)("div", {
                  className: "FrontlinePlateMeta",
                  children: pO("frontlineHud:objective", {
                    point: OO,
                    friendly: lO,
                    enemy: vK
                  })
                }), (0, sO.jsx)("div", {
                  className: "FrontlinePlateStatus",
                  children: pO(cK[XO])
                })]
              }), (0, sO.jsxs)("span", {
                className: "FrontlinePercent",
                children: [String(bK).padStart(3, "0"), (0, sO.jsx)("small", {
                  children: "%"
                })]
              })]
            }), (0, sO.jsx)(WO, {
              segments: 24,
              lit: CO
            })]
          })
        }
        if ("alert" === KO[0]) {
          const [, OO, XO, bK] = KO;
          return (0, sO.jsxs)("div", {
            className: EO()("FrontlinePlate", "FrontlineAlert", `Tone-${bK}`),
            children: [(0, sO.jsx)(kK, {}), (0, sO.jsx)("div", {
              className: "FrontlinePlateMeta",
              children: pO(BO[OO])
            }), (0, sO.jsx)("div", {
              className: "FrontlinePlateStatus",
              children: XO
            })]
          })
        }
        return null
      })),
      xK = (0, bK.memo)((function(OO) {
        let {
          view: KO
        } = OO;
        const {
          t: pO
        } = (0, wO.D)(), XO = (0, bK.useRef)(null), eO = function(OO, KO) {
          const [pO, XO] = (0, bK.useState)(!1);
          return (0, bK.useLayoutEffect)((() => {
            const KO = OO.current;
            if (!KO) return;
            const pO = document.querySelector(`.${YO.g}`),
              bK = document.querySelector(`.${YO.h}`),
              eO = () => {
                var OO;
                const eO = KO.querySelector(".FrontlineTeamTrack"),
                  lO = (0, CO.getRemInPx)(),
                  vK = KO.getBoundingClientRect().width - 2 * (null !== (OO = null === eO || void 0 === eO ? void 0 : eO.getBoundingClientRect().width) && void 0 !== OO ? OO : 0),
                  hO = window.innerWidth / 2,
                  DO = pO ? pO.getBoundingClientRect().right : 0,
                  MO = bK ? bK.getBoundingClientRect().left : window.innerWidth,
                  aK = Math.min(hO - DO, MO - hO) - YO.c - vK / 2,
                  oO = aK < 6 * lO,
                  FO = oO ? (window.innerWidth - vK) / 2 - YO.c : aK;
                KO.style.setProperty("--frontlineTrackWidth", `${Math.max(0,Math.floor(Math.min(FO,14*lO)))}px`), XO(oO)
              };
            eO();
            const lO = new ResizeObserver(eO);
            for (const OO of [KO, pO, bK]) OO && lO.observe(OO);
            return window.addEventListener("resize", eO), () => {
              lO.disconnect(), window.removeEventListener("resize", eO)
            }
          }), [OO, KO]), pO
        }(XO, "scoreboard" === KO.wire[0]);
        if ("scoreboard" !== KO.wire[0]) return null;
        const [, lO, vK, hO, DO, , MO] = KO.wire, aK = "Red" === lO ? "Blue" : "Red";
        return (0, sO.jsxs)("div", {
          className: EO()("FrontlineScoreboardContainer", {
            Below: eO
          }),
          children: [(0, sO.jsxs)("div", {
            ref: XO,
            className: "FrontlineScoreboard",
            children: [(0, sO.jsx)(kK, {}), (0, sO.jsx)(nO, {
              team: lO,
              tickets: vK,
              goal: DO,
              side: "Friendly"
            }), (0, sO.jsx)("div", {
              className: "FrontlinePoints",
              children: MO.map((OO => (0, sO.jsx)(SO, {
                className: "FrontlinePoint",
                point: OO
              }, OO[0])))
            }), (0, sO.jsx)(nO, {
              team: aK,
              tickets: hO,
              goal: DO,
              side: "Enemy"
            })]
          }), (0, sO.jsxs)("div", {
            className: "FrontlineClockTab",
            children: [(0, sO.jsx)(tK, {
              endsAt: KO.endsAt
            }), (0, sO.jsx)("div", {
              className: "FrontlinePlateMeta",
              children: pO("frontlineHud:ticketGoal", {
                goal: DO
              })
            })]
          })]
        })
      }));

    function nO(OO) {
      let {
        team: KO,
        tickets: pO,
        goal: XO,
        side: bK
      } = OO;
      const {
        t: eO
      } = (0, wO.D)(), lO = String(pO).padStart(3, "0"), vK = lO.search(/[1-9]/), CO = -1 === vK ? lO : lO.slice(0, vK), hO = Math.min(20, Math.floor(pO / XO * 20));
      return (0, sO.jsxs)("div", {
        className: EO()("FrontlineTeamScore", bK, `Team-${KO}`),
        children: [(0, sO.jsxs)("div", {
          className: "FrontlineTickets",
          children: [(0, sO.jsx)("span", {
            className: "Lead",
            children: CO
          }), -1 !== vK && lO.slice(vK)]
        }), (0, sO.jsxs)("div", {
          className: "FrontlineTeamTrack",
          children: [(0, sO.jsx)("div", {
            className: "FrontlinePlateMeta",
            children: eO(HO[KO])
          }), (0, sO.jsx)(WO, {
            segments: 20,
            lit: hO
          })]
        })]
      })
    }

    function WO(OO) {
      let {
        segments: KO,
        lit: pO
      } = OO;
      return (0, sO.jsx)("div", {
        className: "FrontlineBar",
        children: Array.from({
          length: KO
        }, ((OO, KO) => (0, sO.jsx)("i", {
          className: EO()({
            Lit: KO < pO
          })
        }, KO)))
      })
    }

    function tK(OO) {
      let {
        endsAt: KO
      } = OO;
      const pO = Math.max(0, Math.ceil(RO(KO)));
      return (0, sO.jsxs)("div", {
        className: EO()("FrontlineClock", {
          Urgent: pO <= 60
        }),
        children: [Math.floor(pO / 60), ":", String(pO % 60).padStart(2, "0")]
      })
    }

    function kK() {
      return (0, sO.jsxs)(sO.Fragment, {
        children: [(0, sO.jsx)("i", {
          className: "FrontlineBracket TopRight"
        }), (0, sO.jsx)("i", {
          className: "FrontlineBracket BottomLeft"
        })]
      })
    }
    var UO = pO(35230),
      OK = pO(1109),
      KK = pO(36888),
      pK = pO(36921);
    class XK {
      constructor(OO) {
        var KO;
        this.hud = OO, this.markers = new Map, this.refs = new Map, this.viewport = {
          width: window.innerWidth,
          height: window.innerHeight
        }, this.render = null, this.YX = !1, this.tV = () => {
          this.viewport = {
            width: window.innerWidth,
            height: window.innerHeight
          }
        }, window.addEventListener("resize", this.tV), null === (KO = window.visualViewport) || void 0 === KO || KO.addEventListener("resize", this.tV)
      }
      bindMarker(OO) {
        let KO = this.refs.get(OO);
        return KO || (KO = KO => {
          var pO;
          null === (pO = this.markers.get(OO)) || void 0 === pO || pO.stopObserving(), this.markers.delete(OO), KO && !this.YX && this.markers.set(OO, this.mount(KO))
        }, this.refs.set(OO, KO)), KO
      }
      frame(OO, KO) {
        this.render = OO;
        const pO = this.hud.getScoreboard().wire;
        if ("scoreboard" === pO[0] && 0 !== this.markers.size)
          for (const [XO, , , , , , bK] of pO[6]) {
            const OO = this.markers.get(XO);
            OO && bK && (OO.target ??= [0, 0, 0], OO.target[0] = bK[0], OO.target[1] = bK[1] + 2.5, OO.target[2] = bK[2], this.place(OO), this.Dk(OO, KO && Math.hypot(bK[0] - KO[0], bK[1] - KO[1], bK[2] - KO[2])))
          }
      }
      dispose() {
        var OO;
        this.YX = !0, window.removeEventListener("resize", this.tV), null === (OO = window.visualViewport) || void 0 === OO || OO.removeEventListener("resize", this.tV);
        for (const KO of this.markers.values()) KO.stopObserving();
        this.markers.clear(), this.refs.clear(), this.render = null
      }
      place(OO) {
        const {
          render: KO,
          viewport: pO
        } = this;
        if (!KO || !OO.target) return;
        const XO = (50 - KO.screenBandPct.y) / 100 * pO.height,
          bK = {
            x: OO.halfSize.width + 8,
            top: OO.halfSize.height + 8,
            bottom: OO.halfSize.height + OO.labelsBelow + XO
          },
          eO = KO.projectWorldPosToViewport(OO.target),
          lO = null !== eO && void 0 !== eO ? eO : KO.projectWorldPosToScreenPos(OO.target),
          vK = (0, pK.c)({
            x: lO.x,
            y: lO.y,
            text: eO
          }, bK, pO);
        (0, KK.e)(OO.root, Math.round(100 * vK.x) / 100, Math.round(100 * vK.y) / 100)
      }
      Dk(OO, KO) {
        if (null === KO) return void(null !== OO.metres && (OO.metres = null, OO.distance.textContent = ""));
        const pO = Date.now();
        (null === OO.metres || (0, UO.d)(KO, OO.metres, OO.metresShownAt)) && (OO.metres = Math.round(KO), OO.metresShownAt = pO, OO.distance.textContent = (0, wO.z)(OK.f.get().getCurrentLanguageCode(), "frontlineHud:markerDistance", {
          distance: String(OO.metres)
        }))
      }
      mount(OO) {
        const KO = {
            root: OO,
            distance: OO.querySelector(".FrontlinePointMarkerDistance"),
            halfSize: {
              width: 0,
              height: 0
            },
            labelsBelow: 0,
            target: null,
            metres: null,
            metresShownAt: 0,
            stopObserving: () => {}
          },
          pO = OO.querySelector(".FrontlinePointMarkerLabels"),
          XO = new ResizeObserver((() => {
            KO.halfSize = {
              width: Math.max(OO.offsetWidth, pO.offsetWidth) / 2,
              height: OO.offsetHeight / 2
            }, KO.labelsBelow = pO.offsetTop + pO.offsetHeight - OO.offsetHeight, this.place(KO)
          }));
        return XO.observe(OO, {
          box: "border-box"
        }), XO.observe(pO, {
          box: "border-box"
        }), KO.stopObserving = () => {
          XO.disconnect()
        }, KO
      }
    }
    var bp = pO(5592),
      eK = pO(2085);
    const lK = "frontlineRoundEndChanged";
    class vp {
      constructor() {
        this.view = {
          wire: ["none"],
          key: 0,
          endsAt: 0
        }
      }
      getView() {
        return this.view
      }
      PX(OO) {
        const KO = "roundEnd" === OO[0] ? performance.now() + OO[5] : 0;
        this.view = {
          wire: OO,
          key: this.view.key + 1,
          endsAt: KO
        }, hO.i.pl(lK, this.view, !0)
      }
    }
    const CK = (0, bK.lazy)((() => (0, eK.b)(pO.e(202).then((() => pO(39766))), (OO => OO.FrontlineMvpLineup)))),
      hK = [4800, 4e3, 3200],
      DK = [1, 0, 2],
      MK = {
        victory: "frontlineRoundEnd:victory",
        defeat: "frontlineRoundEnd:defeat",
        draw: "frontlineRoundEnd:draw"
      },
      ap = ["frontlineRoundEnd:mvp", "frontlineRoundEnd:second", "frontlineRoundEnd:third"];

    function oK(OO) {
      let {
        controller: KO
      } = OO;
      const pO = (0, iK.h)(lK, KO.getView()),
        XO = RO(pO.endsAt);
      return "roundEnd" !== pO.wire[0] || 1e3 * XO < -2e3 ? null : (0, sO.jsx)(FK, {
        wire: pO.wire,
        secondsLeft: Math.max(0, Math.ceil(XO))
      }, pO.key)
    }
    const FK = (0, bK.memo)((function(OO) {
      let {
        wire: KO,
        secondsLeft: pO
      } = OO;
      const {
        t: eO
      } = (0, wO.D)(), [, lO, vK, CO, hO, , DO, MO] = KO, aK = (0, bK.useMemo)((() => DK.filter((OO => OO < MO.length))), [MO]), oO = (0, bK.useMemo)((() => aK.map((OO => {
        const [, , , , , KO, pO] = MO[OO];
        return {
          cosmetics: XO.map(((OO, pO) => [OO, KO[pO]])),
          size: 0 === OO ? 1.15 : .85,
          heldGun: {
            name: pO,
            aimed: 0 === OO
          },
          showAfterMs: hK[OO]
        }
      }))), [MO, aK]);
      return (0, sO.jsxs)("div", {
        className: EO()("FrontlineRoundEnd", `Result-${lO}`),
        style: {
          "--titleRiseMs": "2600ms"
        },
        children: [(0, sO.jsx)("div", {
          className: "FrontlineRoundEndVeil"
        }), (0, sO.jsxs)("div", {
          className: "FrontlineRoundEndTitle",
          children: [(0, sO.jsxs)("div", {
            className: "FrontlineRoundEndResult",
            children: [(0, sO.jsx)("i", {
              className: "FrontlineBracket TopLeft"
            }), (0, sO.jsx)("i", {
              className: "FrontlineBracket BottomRight"
            }), (FO = eO(MK[lO]), /\p{Script=Arabic}/u.test(FO) ? [FO] : (0, bp.d)(FO)).map(((OO, KO) => (0, sO.jsx)("span", {
              style: {
                "--letter": KO
              },
              children: OO
            }, KO)))]
          }), (0, sO.jsxs)("div", {
            className: "FrontlineRoundEndScore",
            children: [vK && "victory" === lO && (0, sO.jsx)("span", {
              className: "FrontlineRoundEndComeback",
              children: eO("frontlineRoundEnd:comeback")
            }), (0, sO.jsxs)("span", {
              className: "FrontlineRoundEndTickets",
              children: [(0, sO.jsx)("b", {
                className: "Friendly",
                children: CO
              }), " \u2013 ", (0, sO.jsx)("b", {
                className: "Enemy",
                children: hO
              })]
            })]
          })]
        }), aK.length > 0 && (0, sO.jsxs)("div", {
          className: "FrontlineRoundEndMvps",
          style: {
            "--columns": aK.length
          },
          children: [(0, sO.jsx)(bK.Suspense, {
            fallback: null,
            children: (0, sO.jsx)(CK, {
              className: "FrontlineRoundEndLineup",
              players: oO
            })
          }), aK.map((OO => (0, sO.jsx)(VK, {
            mvp: MO[OO],
            place: OO
          }, OO)))]
        }), (0, sO.jsx)("div", {
          className: "FrontlineRoundEndNext",
          children: eO("frontlineRoundEnd:nextFront", {
            map: DO,
            seconds: String(pO)
          })
        })]
      });
      var FO
    }));

    function VK(OO) {
      let {
        mvp: KO,
        place: pO
      } = OO;
      const {
        t: XO
      } = (0, wO.D)(), [bK, eO, lO, vK, CO] = KO, [hO, DO] = XO(function(OO, KO) {
        return 1 === KO && "damage" !== OO ? `frontlineRoundEnd:${OO}One` : `frontlineRoundEnd:${OO}`
      }(lO, vK), {
        name: "\0",
        count: vK.toLocaleString()
      }).split("\0");
      return (0, sO.jsxs)("div", {
        className: EO()("FrontlineMvpCard", `Place-${pO+1}`, `Team-${eO}`),
        style: {
          "--revealMs": `${hK[pO]}ms`
        },
        children: [(0, sO.jsx)("i", {
          className: "FrontlineBracket TopRight"
        }), (0, sO.jsx)("i", {
          className: "FrontlineBracket BottomLeft"
        }), (0, sO.jsx)("div", {
          className: "FrontlineMvpPlace",
          children: XO(ap[pO])
        }), (0, sO.jsxs)("div", {
          className: "FrontlineMvpLine",
          children: [hO, (0, sO.jsx)("span", {
            className: "FrontlineMvpName",
            children: bK
          }), DO]
        }), (0, sO.jsx)("div", {
          className: "FrontlineMvpKit",
          children: CO
        })]
      })
    }
    const LK = function(OO, KO, pO, XO) {
      let {
        localPlayerId: lO
      } = XO;
      const vK = new mK,
        CO = new vp;
      let hO = null,
        DO = null,
        MO = null,
        aK = null,
        oO = null,
        FO = [!1, !1];
      const VO = () => {
        var OO, KO;
        const [pO, XO] = FO;
        null === (OO = DO) || void 0 === OO || OO.WE(!pO), null === (KO = MO) || void 0 === KO || KO.WE(!XO)
      };
      return {
        onCreate: OO => {
          hO = OO, DO = new AO(OO, lO), MO = new NO(OO, lO), aK = new XK(vK), VO(), oO = (0, eO.q)((0, bK.createElement)(bK.Fragment, null, (0, bK.createElement)(ZO, {
            hud: vK,
            crosshair: DO,
            damage: MO,
            markers: aK
          }), (0, bK.createElement)(oK, {
            controller: CO
          })))
        },
        onClose: () => {
          var OO, KO, pO, XO;
          null === (OO = oO) || void 0 === OO || OO(), null === (KO = DO) || void 0 === KO || KO.dispose(), DO = null, null === (pO = MO) || void 0 === pO || pO.dispose(), MO = null, null === (XO = aK) || void 0 === XO || XO.dispose(), aK = null, hO = null
        },
        onAfterRender: (OO, KO) => {
          var pO, XO, bK, eO;
          null === (pO = DO) || void 0 === pO || pO.frame(OO, KO.tanHalfFovY), null === (XO = MO) || void 0 === XO || XO.frame(KO.cameraHeading), null === (bK = aK) || void 0 === bK || bK.frame(KO, null !== (eO = hO) && void 0 !== eO && eO.checkValid(lO) ? hO.fV(lO) : null)
        },
        onReceivedMessageFromServer: (OO, KO) => {
          "frontlineHud" === OO ? vK.PX(KO) : "frontlineScoreboard" === OO ? vK.receiveScoreboard(KO) : "frontlineRoundEnd" === OO ? CO.PX(KO) : "frontlinePrefs" === OO && (FO = KO, VO())
        }
      }
    }
  },
  5592: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => bK
    });
    const XO = "function" === typeof Intl.Segmenter ? new Intl.Segmenter(void 0, {
      granularity: "grapheme"
    }) : null;

    function bK(OO) {
      return null === XO ? Array.from(OO) : Array.from(XO.segment(OO), (OO => {
        let {
          segment: KO
        } = OO;
        return KO
      }))
    }
  },
  36888: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => lO,
      g: () => eO
    });
    const XO = new WeakMap;

    function bK(OO) {
      let KO = XO.get(OO);
      return KO || (KO = {
        hidden: OO.hidden,
        x: NaN,
        y: NaN
      }, XO.set(OO, KO)), KO
    }

    function eO(OO, KO) {
      const pO = bK(OO);
      pO.hidden !== KO && (pO.hidden = KO, OO.hidden = KO)
    }

    function lO(OO, KO, pO) {
      const XO = bK(OO);
      XO.x === KO && XO.y === pO || (XO.x = KO, XO.y = pO, OO.style.translate = `${KO}vw ${pO}vh`)
    }
  },
  35526: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => XO
    });
    const XO = {
      "skyblock:forged:astral-astral-astral": {
        name: "Heart of the Cosmos",
        lore: "Three shards of the night sky, forged as one. The stars answer whoever holds it.",
        damageMultiplier: 1.8,
        cooldownMultiplier: .8,
        ability: "starfall"
      },
      "skyblock:forged:astral-moonstone-sanguine": {
        name: "Eclipse Edge",
        lore: "Moonlight over starlight over blood: the sky goes dark wherever it is drawn.",
        damageMultiplier: 1.7,
        cooldownMultiplier: .81,
        ability: "eclipseField"
      },
      "skyblock:forged:astral-diamond-moonstone": {
        name: "Starcutter",
        lore: "A blade so sharp the Forge Mother swears it once cut a falling star in two.",
        damageMultiplier: 1.65,
        cooldownMultiplier: .83,
        ability: "starfall"
      },
      "skyblock:forged:astral-sanguine-magmasteel": {
        name: "Triune Flame",
        lore: "Each of Lord Vulcan's three faces, bound into one burning edge.",
        damageMultiplier: 1.65,
        cooldownMultiplier: .83,
        ability: "magmaWave"
      },
      "skyblock:forged:magmasteel-magmasteel-magmasteel": {
        name: "Vulcan's Bane",
        lore: "Forged in the heat of his own rift. It remembers the way down.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "magmaWave"
      },
      "skyblock:forged:magmasteel-astral-sanguine": {
        name: "Comet's Wake",
        lore: "It leaves a trail of fire through the air, like something falling from very far up.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "starfall"
      },
      "skyblock:forged:magmasteel-sanguine-astral": {
        name: "Vulcan's Ruin",
        lore: "The Forge Mother made only one, then sat down for a long while.",
        damageMultiplier: 1.6,
        cooldownMultiplier: .83,
        ability: "warcry"
      },
      "skyblock:forged:magmasteel-iron-stone": {
        name: "Forgehand",
        lore: "A smith's sword: plain to look at, and it hits like a hammer.",
        damageMultiplier: 1.4,
        cooldownMultiplier: .9,
        ability: "quake"
      },
      "skyblock:forged:sanguine-sanguine-sanguine": {
        name: "Crimson Covenant",
        lore: "It drinks, and so do you.",
        damageMultiplier: 1.53,
        cooldownMultiplier: .83,
        ability: "bloodPact"
      },
      "skyblock:forged:sanguine-astral-moonstone": {
        name: "Nightbloom",
        lore: "A red flower that only opens after dark.",
        damageMultiplier: 1.56,
        cooldownMultiplier: .83,
        ability: "eclipseField"
      },
      "skyblock:forged:sanguine-iron-wood": {
        name: "Butcher's Oath",
        lore: "Heavy, honest and always hungry.",
        damageMultiplier: 1.35,
        cooldownMultiplier: .95,
        ability: "bloodPact"
      },
      "skyblock:forged:moonstone-moonstone-moonstone": {
        name: "Lunar Requiem",
        lore: "Swung, it leaves a pale arc that lingers like a second moon.",
        damageMultiplier: 1.35,
        cooldownMultiplier: .85,
        ability: "moonDash"
      },
      "skyblock:forged:moonstone-astral-moonstone": {
        name: "Silver Tide",
        lore: "Pulled by the same moon that pulls the sea.",
        damageMultiplier: 1.4,
        cooldownMultiplier: .84,
        ability: "moonDash"
      },
      "skyblock:forged:diamond-diamond-diamond": {
        name: "Prism Fang",
        lore: "Every facet catches a different light, and every strike finds a different weakness.",
        damageMultiplier: 1.29,
        cooldownMultiplier: .88,
        ability: "gildedEdge",
        traits: {
          crit: 1.8
        }
      },
      "skyblock:forged:diamond-moonstone-gold": {
        name: "Jeweller's Pride",
        lore: "Too pretty to fight with. Fight with it anyway.",
        damageMultiplier: 1.24,
        cooldownMultiplier: .91,
        ability: "gildedEdge"
      },
      "skyblock:forged:gold-gold-gold": {
        name: "King's Ransom",
        lore: "Worth more than the treasure it guards.",
        damageMultiplier: 1.18,
        cooldownMultiplier: .91,
        ability: "gildedEdge",
        traits: {
          coins: 2.5
        }
      },
      "skyblock:forged:gold-moonstone-gold": {
        name: "Midas Moon",
        lore: "Mobs it fells seem to rattle with coins.",
        damageMultiplier: 1.18,
        cooldownMultiplier: .92,
        ability: "gildedEdge",
        traits: {
          coins: 2,
          bossBane: .6
        }
      },
      "skyblock:forged:iron-iron-iron": {
        name: "Old Faithful",
        lore: "It has never let anyone down. It never will.",
        damageMultiplier: 1.15,
        cooldownMultiplier: .94,
        ability: "warcry"
      },
      "skyblock:forged:iron-wood-wood": {
        name: "Militia Blade",
        lore: "Handed out at the outpost gate when the rift first opened.",
        damageMultiplier: 1.09,
        cooldownMultiplier: .97,
        ability: "warcry"
      },
      "skyblock:forged:stone-stone-stone": {
        name: "Quarryman's Cleaver",
        lore: "Chipped from one block of stone, handle and all.",
        damageMultiplier: 1.09,
        cooldownMultiplier: .97,
        ability: "quake"
      },
      "skyblock:forged:wood-wood-wood": {
        name: "Lorenzo's Lesson",
        lore: "Courage matters more than the blade. This one is mostly courage.",
        damageMultiplier: 1.06,
        cooldownMultiplier: .97,
        ability: "warcry"
      }
    }
  }
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);