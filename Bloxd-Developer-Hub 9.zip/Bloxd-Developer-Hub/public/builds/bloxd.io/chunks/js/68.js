export const id = 68;
export const ids = [68];
export const modules = {
  3887: (OO, KO, pO) => {
    pO.d(KO, {
      B: () => aK,
      c: () => XO,
      e: () => lO,
      i: () => LO,
      k: () => VO,
      o: () => vK,
      s: () => bK,
      u: () => eO,
      x: () => FO,
      y: () => oO
    });
    const XO = /\[([^\]]+)\]\((#[^)]+|[^)\s]+)\)/g;

    function bK(OO) {
      try {
        return decodeURIComponent(OO.slice(1))
      } catch {
        return OO.slice(1)
      }
    }

    function eO(OO) {
      return OO.replace(/`/g, "").trim().replace(/[^\w{}$-]+/g, "-").replace(/^-+|-+$/g, "")
    }
    const lO = new RegExp(`${/(`{1,2})(.+?)\1(?!`)|\*\*(.+?)\*\*|/.source}${XO.source}`, "g");

    function vK(OO, KO) {
      return 2 === OO.length ? KO.replace(/^ (.*) $/, "$1") : KO
    }

    function CO(OO) {
      return "" === OO.trim()
    }

    function hO(OO) {
      const KO = [];
      for (const pO of OO.trim().replace(/^\|/, "").replace(/\|$/, "").split("|")) KO.length > 0 && KO[KO.length - 1].endsWith("\\") ? KO[KO.length - 1] += `|${pO}` : KO.push(pO);
      return KO.map((OO => OO.trim().replaceAll("\\|", "|")))
    }
    const DO = /^([ \t]*)([-*]|\d+\.)[ \t]+(.*)$/;

    function MO(OO) {
      const KO = [],
        pO = [{
          indent: -1,
          items: KO
        }];
      let XO = null;
      for (const bK of OO) {
        const OO = bK.match(DO);
        if (!OO) {
          XO && (XO.text += ` ${bK.trim()}`);
          continue
        }
        const KO = OO[1].replace(/\t/g, "  ").length;
        for (; KO <= pO[pO.length - 1].indent;) pO.pop();
        XO = {
          text: OO[3].trim(),
          children: []
        }, pO[pO.length - 1].items.push(XO), pO.push({
          indent: KO,
          items: XO.children
        })
      }
      return KO
    }

    function aK(OO) {
      const KO = OO.replace(/\r\n/g, "\n").split("\n"),
        pO = [];
      let XO = 0;
      for (; XO < KO.length;) {
        const OO = KO[XO];
        if (CO(OO)) {
          XO++;
          continue
        }
        const bK = OO.match(/^\s*```\s*(\w*)\s*$/);
        if (bK) {
          const OO = [];
          for (XO++; XO < KO.length && !/^\s*```\s*$/.test(KO[XO]);) OO.push(KO[XO]), XO++;
          XO++, pO.push({
            kind: "code",
            lang: bK[1] || "text",
            code: OO.join("\n").replace(/\s+$/, "")
          });
          continue
        }
        const lO = OO.match(/^(#{1,6})\s+(.+?)\s*#*$/);
        if (lO) {
          const OO = lO[2].trim();
          pO.push({
            kind: "heading",
            level: lO[1].length,
            text: OO,
            anchor: eO(OO)
          }), XO++;
          continue
        }
        if (/^\s*(-{3,}|\*{3,})\s*$/.test(OO)) {
          pO.push({
            kind: "rule"
          }), XO++;
          continue
        }
        if (OO.trim().startsWith("|") && XO + 1 < KO.length && /^\s*\|[\s:|-]+\|\s*$/.test(KO[XO + 1])) {
          const bK = hO(OO),
            eO = [];
          for (XO += 2; XO < KO.length && KO[XO].trim().startsWith("|");) eO.push(hO(KO[XO])), XO++;
          pO.push({
            kind: "table",
            header: bK,
            rows: eO
          });
          continue
        }
        if (OO.startsWith(">")) {
          const OO = [];
          for (; XO < KO.length && KO[XO].startsWith(">");) OO.push(KO[XO].replace(/^>\s?/, "")), XO++;
          pO.push({
            kind: "quote",
            blocks: aK(OO.join("\n"))
          });
          continue
        }
        if (DO.test(OO)) {
          const bK = [],
            eO = /^\s*\d+\./.test(OO);
          for (; XO < KO.length && !CO(KO[XO]) && (DO.test(KO[XO]) || /^\s+\S/.test(KO[XO]));) bK.push(KO[XO]), XO++;
          pO.push({
            kind: "list",
            ordered: eO,
            items: MO(bK)
          });
          continue
        }
        const vK = [];
        for (; XO < KO.length && !CO(KO[XO]) && !/^\s*```/.test(KO[XO]) && !/^#{1,6}\s/.test(KO[XO]) && !KO[XO].startsWith(">") && !DO.test(KO[XO]) && (!KO[XO].trim().startsWith("|") || 0 !== vK.length);) vK.push(KO[XO].trim()), XO++;
        0 === vK.length && (vK.push(KO[XO].trim()), XO++), pO.push({
          kind: "paragraph",
          text: vK.join(" ")
        })
      }
      return pO
    }

    function oO(OO) {
      let KO = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
      const pO = aK(OO);
      let XO = "";
      const bK = [],
        eO = [],
        lO = new Map;
      for (const hO of pO) {
        if ("heading" === hO.kind) {
          var vK;
          const OO = (null !== (vK = lO.get(hO.anchor)) && void 0 !== vK ? vK : 0) + 1;
          lO.set(hO.anchor, OO), OO > 1 && (hO.anchor = `${hO.anchor}-${OO}`)
        }
        if ("heading" === hO.kind && 1 === hO.level && !XO) {
          XO = hO.text;
          continue
        }
        if ("heading" === hO.kind && hO.level <= KO) {
          eO.push({
            heading: hO,
            blocks: []
          });
          continue
        }
        const OO = eO.at(-1);
        OO ? OO.blocks.push(hO) : bK.push(hO)
      }
      const CO = OO => {
        for (;
          "rule" === (null === (KO = OO.at(-1)) || void 0 === KO ? void 0 : KO.kind);) {
          var KO;
          OO.pop()
        }
      };
      CO(bK);
      for (const hO of eO) CO(hO.blocks);
      return {
        title: XO,
        intro: bK,
        sections: eO
      }
    }

    function FO(OO) {
      return [{
        heading: null,
        blocks: OO.intro
      }, ...OO.sections.map((OO => ({
        heading: OO.heading,
        blocks: OO.blocks
      })))]
    }

    function VO(OO) {
      return OO.flatMap((OO => "code" === OO.kind ? [OO] : "quote" === OO.kind ? VO(OO.blocks) : []))
    }

    function LO(OO) {
      switch (OO.kind) {
        case "heading":
        case "paragraph":
          return OO.text;
        case "code":
          return OO.code;
        case "table":
          return [OO.header, ...OO.rows].map((OO => OO.join(" "))).join(" ");
        case "list": {
          const KO = OO => OO.map((OO => `${OO.text} ${KO(OO.children)}`)).join(" ");
          return KO(OO.items)
        }
        case "quote":
          return OO.blocks.map(LO).join(" ");
        case "rule":
          return ""
      }
    }
  },
  5649: (OO, KO, pO) => {
    pO.d(KO, {
      d: () => MO,
      g: () => lO,
      h: () => vK
    });
    pO(5643);
    var XO = pO(63),
      bK = pO(3887),
      eO = pO(976);
    const lO = /\[([^\][\n]{1,200})\]\(([^)\s]{1,500})\)|\*\*([^*]+)\*\*|__([^_]+)__|\*([^*\s][^*]*)\*|`([^`]+)`/g;

    function vK(OO, KO) {
      return OO === KO ? OO : `${OO} (${KO})`
    }

    function CO(OO) {
      const KO = [];
      let pO = 0;
      for (const XO of OO.matchAll(lO)) {
        XO.index > pO && KO.push(OO.slice(pO, XO.index));
        const [, bK, lO, CO, hO, DO, MO] = XO;
        void 0 !== bK ? KO.push(vK(bK, lO)) : void 0 !== CO || void 0 !== hO ? KO.push((0, eO.jsx)("strong", {
          children: null !== CO && void 0 !== CO ? CO : hO
        }, XO.index)) : void 0 !== DO ? KO.push((0, eO.jsx)("em", {
          children: DO
        }, XO.index)) : KO.push((0, eO.jsx)("code", {
          children: MO
        }, XO.index)), pO = XO.index + XO[0].length
      }
      return pO < OO.length && KO.push(OO.slice(pO)), KO
    }

    function hO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      const XO = OO.map(((OO, KO) => (0, eO.jsxs)("li", {
        children: [CO(OO.text), OO.children.length > 0 && hO(OO.children, !1)]
      }, KO)));
      return KO ? (0, eO.jsx)("ol", {
        start: pO,
        children: XO
      }) : (0, eO.jsx)("ul", {
        children: XO
      })
    }

    function DO(OO, KO) {
      switch (OO.kind) {
        case "heading":
          return OO.level <= 2 ? (0, eO.jsx)("h3", {
            children: CO(OO.text)
          }, KO) : (0, eO.jsx)("h4", {
            children: CO(OO.text)
          }, KO);
        case "paragraph":
          return (0, eO.jsx)("p", {
            children: CO(OO.text)
          }, KO);
        case "list":
          return (0, eO.jsx)(XO.Fragment, {
            children: hO(OO.items, OO.ordered)
          }, KO);
        case "quote":
          return (0, eO.jsx)("blockquote", {
            children: OO.blocks.map(((OO, KO) => DO(OO, KO)))
          }, KO);
        case "code":
          return (0, eO.jsx)("pre", {
            children: (0, eO.jsx)("code", {
              children: OO.code
            })
          }, KO);
        case "table":
          return (0, eO.jsxs)("table", {
            children: [(0, eO.jsx)("thead", {
              children: (0, eO.jsx)("tr", {
                children: OO.header.map(((OO, KO) => (0, eO.jsx)("th", {
                  children: CO(OO)
                }, KO)))
              })
            }), (0, eO.jsx)("tbody", {
              children: OO.rows.map(((OO, KO) => (0, eO.jsx)("tr", {
                children: OO.map(((OO, KO) => (0, eO.jsx)("td", {
                  children: CO(OO)
                }, KO)))
              }, KO)))
            })]
          }, KO);
        case "rule":
          return (0, eO.jsx)("hr", {}, KO)
      }
    }

    function MO(OO) {
      let {
        markdown: KO
      } = OO, pO = 0;
      return (0, eO.jsx)("div", {
        className: "StudioAiAnswerText",
        children: (0, bK.B)(KO).map(((OO, KO) => {
          if ("list" !== OO.kind || !OO.ordered) return pO = 0, DO(OO, KO);
          const bK = pO + 1;
          return pO += OO.items.length, (0, eO.jsx)(XO.Fragment, {
            children: hO(OO.items, !0, bK)
          }, KO)
        }))
      })
    }
  },
  5639: (OO, KO, pO) => {
    pO.d(KO, {
      e: () => zK,
      m: () => AO,
      i: () => dO,
      q: () => FO
    });
    var XO = pO(5632),
      bK = pO(5594),
      eO = pO(3996);
    const lO = /\b(the prompt (says|asks|wants|tells)|the user (wants|asks|said)|my instructions(?! (?:below|above|here|in step))|the instructions (say|ask)|as instructed(?! (?:below|above|here|in step|by (?!the (?:prompt|user|system)\b))))\b/i;

    function vK(OO) {
      return (0, eO.i)(OO, lO, (KO => !/^my/i.test(KO[0]) || !/follow $/i.test(OO.slice(0, KO.index)))).length > 0
    }
    const CO = /\byou(?:r|'re|'ll)?\b/i,
      hO = /^(?:[-*]\s+|\d+\.\s+)?(actually,|wait[,.!]|hmm\b|let me (think|re-?read|re-?check|reconsider)\b|let's (assume|think|re-?read|reconsider|go with)\b|i will\b|i'll (suggest|go with|pick)\b|i need to\b|i should\b|i don't have\b|since i (can|cannot|can't|don't)\b|okay,? so\b)/i,
      DO = 2;

    function MO(OO) {
      return function(OO) {
        const KO = [];
        let pO = !1;
        for (const XO of OO.split("\n")) {
          if (/^\s*(```|~~~)/.test(XO)) {
            pO = !pO;
            continue
          }
          if (pO || /^\s*>/.test(XO)) continue;
          const OO = XO.replace(/`[^`]*`/g, "code").replace(/"[^"]*"|\u201c[^\u201d]*\u201d/g, '"quote"').trim();
          KO.push(...(0, bK.p)(OO))
        }
        return KO
      }(OO).filter((OO => vK(OO) || hO.test(OO) && !CO.test(OO)))
    }
    const aK = "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions",
      oO = [{
        name: "Qwen3.6-27B",
        temperature: .7,
        reasoningEffort: "none"
      }, {
        name: "Qwen3.5-397B-A17B",
        temperature: .7,
        reasoningEffort: "none"
      }, {
        name: "Mistral-Small-3.2-24B-Instruct-2506",
        temperature: .15
      }];

    function FO(OO) {
      const KO = oO.findIndex((KO => KO.name === OO));
      return -1 === KO ? oO.length : KO
    }
    const VO = 2500,
      LO = 12e4;
    class QO extends Error {
      constructor(OO) {
        super(`Studio AI chat ${OO}`), this.reason = OO
      }
    }

    function zK(OO, KO) {
      const pO = new AbortController,
        XO = () => {
          pO.abort()
        },
        bK = setTimeout(XO, OO);
      return null !== KO && void 0 !== KO && KO.aborted && XO(), null === KO || void 0 === KO || KO.addEventListener("abort", XO, {
        once: !0
      }), {
        signal: pO.signal,
        clear: () => {
          clearTimeout(bK), null === KO || void 0 === KO || KO.removeEventListener("abort", XO)
        }
      }
    }

    function AO(OO, KO, pO) {
      return new Promise(((bK, eO) => {
        const lO = new AbortController,
          vK = () => {
            lO.abort(), eO((0, XO.c)(pO))
          };
        if (null !== pO && void 0 !== pO && pO.aborted) return void vK();
        null === pO || void 0 === pO || pO.addEventListener("abort", vK, {
          once: !0
        });
        const CO = oO.map((() => !1));
        let hO = null;
        const DO = oO.map((() => !1)),
          MO = oO.map((() => !1));
        oO.forEach(((XO, aK) => {
          const FO = zK(LO, lO.signal);
          TO(XO, [{
            role: "user",
            content: OO
          }], FO.signal).then((OO => {
            lO.signal.aborted || ("busy" === OO || "failed" === OO ? (DO[aK] = "busy" === OO, MO[aK] = !0) : null !== OO && (null === hO || aK < hO.rank) && (hO = {
              rank: aK,
              answer: {
                text: OO.text,
                model: XO.name
              }
            }, KO(hO.answer)))
          }), (OO => {
            lO.signal.aborted || (MO[aK] = !0, console.warn(`Studio AI: ${XO.name} couldn't be reached`, OO))
          })).finally((() => {
            FO.clear(), CO[aK] = !0, lO.signal.aborted || (() => {
              var OO, KO;
              const XO = null !== (OO = null === (KO = hO) || void 0 === KO ? void 0 : KO.rank) && void 0 !== OO ? OO : oO.length;
              CO.slice(0, XO).includes(!1) || (null === pO || void 0 === pO || pO.removeEventListener("abort", vK), lO.abort(), null !== hO ? bK({
                ...hO.answer,
                isFinal: !MO.slice(0, hO.rank).includes(!0)
              }) : eO(new QO(DO.includes(!0) ? "busy" : "failed")))
            })()
          })).catch((OO => {
            console.error("Studio AI: showing an answer failed", OO)
          }))
        }))
      }))
    }

    function fO(OO) {
      var KO, pO;
      return "length" === (null === OO || void 0 === OO || null === (KO = OO.choices) || void 0 === KO || null === (pO = KO[0]) || void 0 === pO ? void 0 : pO.finish_reason)
    }
    async function dO(OO, KO, pO) {
      const XO = oO.find((KO => KO.name === OO));
      if (void 0 === XO) return "failed";
      const bK = zK(LO, pO);
      try {
        const OO = await TO(XO, KO, bK.signal);
        return null !== OO && "object" === typeof OO ? OO.isCutOff ? (console.warn(`Studio AI: ${XO.name}'s answer was cut off at the token limit`), null) : {
          text: OO.text
        } : OO
      } finally {
        bK.clear()
      }
    }
    async function TO(OO, KO, pO) {
      const XO = await fetch(aK, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: OO.name,
          messages: KO,
          max_tokens: VO,
          temperature: OO.temperature,
          reasoning_effort: OO.reasoningEffort
        }),
        credentials: "omit",
        referrerPolicy: "no-referrer",
        signal: pO
      });
      if (429 === XO.status) return "busy";
      if (!XO.ok) return console.warn(`Studio AI: ${OO.name} answered ${XO.status}`), "failed";
      const bK = await XO.json().catch((() => null)),
        eO = function(OO) {
          var KO, pO, XO;
          const bK = null === OO || void 0 === OO || null === (KO = OO.choices) || void 0 === KO || null === (pO = KO[0]) || void 0 === pO || null === (XO = pO.message) || void 0 === XO ? void 0 : XO.content;
          if ("string" !== typeof bK) return null;
          const eO = bK.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
          return "" === eO ? null : eO
        }(bK);
      return null !== eO && function(OO) {
        const KO = MO(OO);
        return KO.length >= DO || KO.some((OO => vK(OO)))
      }(eO) ? (console.warn(`Studio AI: ${OO.name} thought out loud instead of answering`), "failed") : null === eO ? null : {
        text: eO,
        isCutOff: fO(bK)
      }
    }
  },
  5594: (OO, KO, pO) => {
    pO.d(KO, {
      A: () => fO,
      E: () => TO,
      I: () => LO,
      J: () => AO,
      N: () => dO,
      R: () => zK,
      V: () => MO,
      X: () => hO,
      Y: () => oO,
      d: () => FO,
      h: () => vK,
      j: () => lO,
      k: () => VO,
      l: () => aK,
      p: () => DO,
      s: () => eO,
      w: () => bK
    });
    var XO = pO(3996);
    const bK = 2e3,
      eO = 2e4;

    function lO(OO) {
      return OO.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
    }

    function vK(OO) {
      return OO.replace(/\$/g, "\\$")
    }
    const CO = /[.!?](?=\s|\*|_|$)|\n|$/g;

    function hO(OO, KO) {
      CO.lastIndex = KO;
      const pO = CO.exec(OO);
      return pO.index + pO[0].length
    }

    function DO(OO) {
      return (0, XO.B)(OO, /\s+/g, (0, XO.x)(".!?")).flatMap((OO => OO.split("\n")))
    }

    function MO(OO, KO) {
      let pO = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : KO;
      const XO = [...OO.matchAll(/[.!?](?!\d)(?=\s|$)/g)].map((OO => OO.index)),
        bK = XO.filter((OO => OO < KO)),
        eO = XO.find((OO => OO >= pO));
      return [0 === bK.length ? 0 : bK.at(-1) + 1, void 0 === eO ? OO.length : eO + 1]
    }

    function aK(OO, KO) {
      const pO = OO.charCodeAt(KO - 1);
      return OO.slice(0, KO > 0 && KO < OO.length && pO >= 55296 && pO <= 56319 ? KO - 1 : KO)
    }

    function oO(OO, KO) {
      return `${KO}${OO.replace(/\\/g,"\\\\").split(KO).join(`\\${KO}`)}${KO}`
    }

    function FO(OO) {
      return OO.charAt(0).toUpperCase() + OO.slice(1)
    }

    function VO(OO) {
      return Math.round(OO).toLocaleString("en-US")
    }

    function LO(OO) {
      return OO.replace(/([a-z\d])([A-Z])/g, "$1 $2").toLowerCase().split(/[^a-z\d]+/).filter((OO => "" !== OO))
    }
    const QO = 3;

    function zK(OO, KO) {
      return LO(OO).filter((OO => OO.length >= QO && !/\d/.test(OO))).map((OO => `${OO} ${KO}`))
    }

    function AO(OO) {
      return OO.split(/[\s:_]+/).filter((OO => "" !== OO)).map(lO).join("[`:_\\s]+")
    }

    function fO(OO) {
      return LO(OO.split(".").pop())
    }

    function dO(OO) {
      return OO.replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim()
    }

    function TO(OO) {
      let KO = null;
      return () => {
        const pO = KO ??= OO();
        return pO.catch((() => {
          KO === pO && (KO = null)
        })), pO
      }
    }
  },
  5632: (OO, KO, pO) => {
    pO.d(KO, {
      c: () => eO,
      g: () => bK,
      j: () => lO
    });
    const XO = new WeakMap;

    function bK(OO, KO) {
      OO.signal.aborted || XO.set(OO.signal, KO), OO.abort(KO)
    }

    function eO(OO) {
      var KO;
      const pO = null !== (KO = null === OO || void 0 === OO ? void 0 : OO.reason) && void 0 !== KO ? KO : OO && XO.get(OO);
      if (void 0 !== pO && null !== pO) return pO;
      const bK = new DOMException("signal is aborted without reason", "AbortError");
      return null !== OO && void 0 !== OO && OO.aborted && XO.set(OO, bK), bK
    }

    function lO(OO) {
      if (null !== OO && void 0 !== OO && OO.aborted) throw eO(OO)
    }
  },
  3996: (OO, KO, pO) => {
    function XO(OO) {
      return {
        notAfter: OO
      }
    }
    pO.d(KO, {
      B: () => MO,
      e: () => CO,
      i: () => hO,
      l: () => vK,
      o: () => XO,
      s: () => bK,
      u: () => eO,
      x: () => lO,
      z: () => DO
    });
    const bK = XO("\\w$."),
      eO = XO("\\w.,");

    function lO(OO) {
      return KO => CO(KO, OO)
    }

    function vK(OO) {
      return KO => !OO.test(KO.input.slice(0, KO.index))
    }

    function CO(OO, KO) {
      return OO.index > 0 && new RegExp(`[${KO}]`).test(OO.input[OO.index - 1])
    }

    function hO(OO, KO, pO) {
      return function(OO) {
        return void 0 !== OO && "function" !== typeof OO
      }(pO) ? function(OO, KO, pO) {
        const XO = KO.flags.replace(/[gy]/g, ""),
          bK = new RegExp(`[^${pO}](?:${KO.source})`, `${XO}g`),
          eO = [],
          lO = pO => {
            const XO = pO.index + pO[0].length;
            return ("" === pO[0] ? aK(OO, KO, XO) : XO) - 1
          },
          vK = new RegExp(`(?:${KO.source})`, `${XO}y`).exec(OO);
        if (vK) {
          if (eO.push(vK), !KO.global) return eO;
          bK.lastIndex = lO(vK)
        }
        for (let CO = bK.exec(OO); CO; CO = bK.exec(OO)) {
          const pO = aK(OO, KO, CO.index) - CO.index;
          if (CO[0] = CO[0].slice(pO), CO.index += pO, eO.push(CO), !KO.global) break;
          bK.lastIndex = lO(CO)
        }
        return eO
      }(OO, KO, pO.notAfter) : function(OO, KO, pO) {
        const XO = new RegExp(KO.source, `${KO.flags.replace(/[gy]/g,"")}g`),
          bK = [];
        for (let eO = XO.exec(OO); eO; eO = XO.exec(OO))
          if (!pO || pO(eO)) {
            if (bK.push(eO), !KO.global) break;
            "" === eO[0] && (XO.lastIndex = aK(OO, KO, XO.lastIndex))
          } else XO.lastIndex = aK(OO, KO, eO.index);
        return bK
      }(OO, KO, pO)
    }

    function DO(OO, KO, pO, XO) {
      let bK = "",
        eO = 0;
      for (const lO of hO(OO, KO, pO)) bK += OO.slice(eO, lO.index) + XO(lO), eO = lO.index + lO[0].length;
      return bK + OO.slice(eO)
    }

    function MO(OO, KO, pO) {
      const XO = [];
      let bK = 0;
      for (const eO of hO(OO, KO, pO)) XO.push(OO.slice(bK, eO.index)), bK = eO.index + eO[0].length;
      return [...XO, OO.slice(bK)]
    }

    function aK(OO, KO, pO) {
      var XO;
      return pO + (KO.unicode && (null !== (XO = OO.codePointAt(pO)) && void 0 !== XO ? XO : 0) > 65535 ? 2 : 1)
    }
  },
  5643: () => {}
};
Object.freeze(modules);
for (const OO in modules) Object.freeze(modules[OO]);