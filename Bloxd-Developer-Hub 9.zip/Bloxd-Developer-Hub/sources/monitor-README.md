# Bloxd Build Monitor

Latest Bloxd build per environment, detected by the external Cloudflare Worker in `cloudflare/` (one poll per minute). GitHub Actions is dispatched only when a bundle changes; its built-in schedule is a six-hour fallback.
Every bundle is beautified and archived under stable logical paths: main.js, main.css, chunks/js/<chunk-id-or-name>.js, and matching CSS paths. Original CDN file names, URLs, and hashes are retained in .monitor-state.json.
This keeps each Webpack chunk on the same Git path across builds, so GitHub shows a normal file modification instead of delete/add. The last 5 build snapshots are kept for diff browsing; older snapshots are squashed into a rolling baseline.
`CHANGES.md` summarizes each build change without minification noise.

| Environment | Checked at (JST) | Build | Main bundle |
|---|---|---|---|
| bloxd.io | 2026-11-17T01:34:27+09:00 | vjxd5n.542dd0f9 | `bundles/bloxd.io/main.js` · 3.43 MB · `f0edd2afe723…` |
| preprod.bloxd.io | 2026-11-17T01:34:28+09:00 | vjxd5n.542dd0f9 | `bundles/preprod.bloxd.io/main.js` · 3.43 MB · `f0edd2afe723…` |
| staging.bloxd.io | 2026-11-17T01:34:29+09:00 | vjxd5n.542dd0f9 | `bundles/staging.bloxd.io/main.js` · 3.43 MB · `f0edd2afe723…` |

## Main bundle details

- **bloxd.io** — source: https://bloxd.io/static/js/vjxd5n.main.542dd0f9.js
  - file: `bundles/bloxd.io/main.js` · 3,601,203 bytes (3.43 MB)
  - sha256: `f0edd2afe723e2d2589573f92048f65942b697b522837e9cbd824720ebc27761`
  - archived build files: 417 (44.70 MB total, full manifest in `.monitor-state.json`)
- **preprod.bloxd.io** — source: https://preprod.bloxd.io/static/js/vjxd5n.main.542dd0f9.js
  - file: `bundles/preprod.bloxd.io/main.js` · 3,601,203 bytes (3.43 MB)
  - sha256: `f0edd2afe723e2d2589573f92048f65942b697b522837e9cbd824720ebc27761`
  - archived build files: 417 (44.70 MB total, full manifest in `.monitor-state.json`)
- **staging.bloxd.io** — source: https://staging.bloxd.io/static/js/vjxd5n.main.542dd0f9.js
  - file: `bundles/staging.bloxd.io/main.js` · 3,601,203 bytes (3.43 MB)
  - sha256: `f0edd2afe723e2d2589573f92048f65942b697b522837e9cbd824720ebc27761`
  - archived build files: 417 (44.70 MB total, full manifest in `.monitor-state.json`)
