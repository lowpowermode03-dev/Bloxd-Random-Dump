import test from "node:test";
import assert from "node:assert/strict";
import {
  mainJsName,
  parseUpdateLogs,
  resolveUpdateLogChunkId,
  buildVarDateTable,
} from "../src/index.js";

test("mainJsName extracts the exact hashed main bundle", () => {
  assert.equal(
    mainJsName('<script src="/static/js/tykq5g.main.937fd517.js"></script>'),
    "tykq5g.main.937fd517.js",
  );
  assert.equal(mainJsName("<html>no bundle</html>"), null);
});

test("resolveUpdateLogChunkId follows the updateLogsData lazy import", () => {
  const main = 'SL.e(105).then(()=>SL(28924)).then(({updateLogsData:oL})=>oL)';
  assert.equal(resolveUpdateLogChunkId(main), "105");
});

test("buildVarDateTable resolves unambiguous exported date constants", () => {
  const main = 'x.d(y,{e:()=>Tb});const Tb=new Date("2026-11-18T12:00:00Z")}';
  assert.deepEqual(
    buildVarDateTable(main, Date.parse("2026-11-16T00:00:00Z")),
    { e: "2026-11-18T12:00:00Z" },
  );
});

test("parseUpdateLogs supports inline dates, variable dates, and descriptions", () => {
  const now = Date.parse("2026-11-16T00:00:00Z");
  const main = 'x.d(y,{e:()=>Tb});const Tb=new Date("2026-11-20T12:00:00Z")}';
  const chunk =
    '({date:new Date("2026-11-15T12:00:00Z"),title:"Published update",description:"Line one\\nLine two"},{author:"A"}),' +
    '({date:Tb.e,title:"Upcoming update",description:"Soon"},{author:"B"})';
  const entries = parseUpdateLogs(chunk, main, now);
  assert.equal(entries.length, 2);
  assert.equal(entries[0].title, "Published update");
  assert.equal(entries[0].description, "Line one\nLine two");
  assert.equal(entries[1].date, "2026-11-20T12:00:00Z");
  assert.equal(entries[1].title, "Upcoming update");
});

test("ambiguous date exports are not guessed", () => {
  const now = Date.parse("2026-11-16T00:00:00Z");
  const main =
    'x.d(y,{e:()=>Tb});const Tb=new Date("2026-11-20T12:00:00Z")}' +
    'z.d(w,{e:()=>Ub});const Ub=new Date("2026-11-21T12:00:00Z")}';
  assert.equal(buildVarDateTable(main, now), null);
  const entries = parseUpdateLogs(
    '({date:Tb.e,title:"Ambiguous",description:"No guessed date"},{author:"A"})',
    main,
    now,
  );
  assert.equal(entries[0].date, "");
});
